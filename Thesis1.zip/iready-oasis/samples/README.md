# Sample licences for testing

Working licences for every tier, and which method each one needs.

The app verifies against the **development** signing key baked into
`server/licensing/keys.js` — the one it warns about at startup:

```
license: WARNING — using the development verification key. Do not ship this build.
```

So everything here unlocks a development build and nothing else. None of it is
a credential, and none of it works against a production build signed with a real
key.

---

## Which method each tier needs

| Tier | How to activate | Needs the dev licence service? |
|---|---|---|
| `viewer` | licence key `OASIS-VIEW-0001-0001` | yes |
| `viewer-security` | licence key `OASIS-VWSC-0001-0001` | yes |
| `enterprise` | the licence **file** in this directory | no |
| any tier | `node tools/license-dev.js install <state>` | no |

Only `enterprise` may activate from a file — `offlineActivation` is true for
that tier alone (`server/licensing/tiers.js`), and the API refuses any other:

```
Offline activation is available on enterprise licences only (this file is viewer-security).
```

That is deliberate, not a gap: the per-seat tiers are seat-counted, and a file
that activates without contacting the service has no seat to claim.

---

## 1. Licence keys (viewer, viewer-security)

Start the app with the dev licence service, then paste the key into the
activation screen:

```bash
./start-licensed.sh --reset
```

| Key | Unlocks |
|---|---|
| `OASIS-VIEW-0001-0001` | Version Watch |
| `OASIS-VWSC-0001-0001` | Version Watch and Security |
| `OASIS-ENTR-0001-0001` | everything |
| `OASIS-TEAM-TINY-0002` | 2 seats only — for reaching seat exhaustion |

## 2. The enterprise licence file (no service needed)

`license-enterprise.txt` is a real signed licence. In the app: **Enterprise:
activate offline** → paste the file's contents into step 2 → **Activate
offline**. Or over the API:

```bash
curl -s -X POST localhost:3000/api/license/offline \
  -H 'content-type: application/json' \
  -d "$(python3 -c "import json;print(json.dumps({'license':open('samples/license-enterprise.txt').read().strip()}))")"
```

**It is bound to the machine that minted it.** `machineId` is inside the signed
payload, and the app refuses a file issued for a different machine:

```
That licence file was issued for a different machine.
```

So the checked-in copy is useless to you — `samples/*.txt` is gitignored for
exactly that reason. Mint your own:

```bash
node tools/license-dev.js mint --tier enterprise --offline --days 365 \
  --customer "OASIS Test" > samples/license-enterprise.txt
```

This needs the dev signing key at `~/.oasis-license-dev/private.pem`. If you do
not have it, `tools/license-dev.js` prints the command to generate a fresh pair
and the flag to point the app at it.

## 3. Skipping activation entirely

Fastest for driving the UI — writes a signed entitlement straight into
`~/.oasis-license.json`, no service and no activation screen:

```bash
node tools/license-dev.js states                    # list them
node tools/license-dev.js install viewer-security
node tools/license-dev.js show                      # what the app now sees
node tools/license-dev.js clear                     # back to unregistered
```

Or in one step, launching the app with enforcement on:

```bash
./start-licensed.sh --state viewer-security
```

---

## What each tier should look like

| Tier | Tabs |
|---|---|
| no licence, no trial | none — lock screen |
| trial (7 days) | Home, Local Repos, Dependency Graph, Docker Services, JIRA |
| `viewer` | the above + Version Watch |
| `viewer-security` | the above + Security |
| `enterprise` | everything |

The trial deliberately excludes Version Watch and Security: they are what a
licence buys, and showing them for a week and then withdrawing them
demonstrates a loss rather than a value.
