#!/usr/bin/env node
'use strict';
// Local licensing test harness.
//
// The licence service does not exist yet (sub-project 2), so there is nothing
// to issue a trial or answer an activation. This writes a signed entitlement
// straight into ~/.oasis-license.json instead, which is enough to drive every
// screen the licensing UI can show.
//
// It lives in tools/ rather than scripts/ or server/ on purpose: electron-
// builder packages electron/, server/, public/, config/ and docs/, so a
// licence-minting tool in any of those would ship inside the product.
//
// Signing needs the private key matching the public key the app verifies with
// (server/licensing/keys.js). By default that is the development key, whose
// private half is expected at ~/.oasis-license-dev/private.pem.
//
// Usage:
//   node tools/license-dev.js states                 list the scenarios
//   node tools/license-dev.js install <state>        write that state, then reload the app
//   node tools/license-dev.js mint --tier enterprise --offline --days 365
//   node tools/license-dev.js show                   what the app currently sees
//   node tools/license-dev.js clear                  back to unregistered

const fs = require('fs');
const os = require('os');
const path = require('path');
const { signToken } = require('../server/licensing/token');
const { evaluate } = require('../server/licensing/state');
const { verifyToken } = require('../server/licensing/token');
const { trustedKeys, DEV_KID } = require('../server/licensing/keys');
const store = require('../server/licensing/store');
const { machineFingerprint } = require('../server/licensing/fingerprint');

const DAY = 86400000;
const KEY_PATH = process.env.OASIS_LICENSE_PRIVATE_KEY || path.join(os.homedir(), '.oasis-license-dev', 'private.pem');

function privateKey() {
  try {
    return fs.readFileSync(KEY_PATH, 'utf8');
  } catch (_) {
    console.error(`No signing key at ${KEY_PATH}.

The app verifies against the development public key baked into
server/licensing/keys.js, so tokens must be signed with its private half.

If you do not have it, generate a fresh pair and point the app at it instead:

  node -e "const{generateKeyPair}=require('./server/licensing/token');
           const fs=require('fs'),os=require('os'),p=require('path');
           const d=p.join(os.homedir(),'.oasis-license-dev'); fs.mkdirSync(d,{recursive:true});
           const k=generateKeyPair();
           fs.writeFileSync(p.join(d,'private.pem'),k.privateKey,{mode:0o600});
           fs.writeFileSync(p.join(d,'public.pem'),k.publicKey);
           console.log('wrote '+d);"

then start the app with:

  OASIS_LICENSE_ENABLED=1 OASIS_LICENSE_PUBLIC_KEY=~/.oasis-license-dev/public.pem npm start
`);
    process.exit(1);
  }
}

function token(overrides = {}) {
  const now = Date.now();
  return signToken(
    {
      licenseId: 'lic_dev_0001',
      tier: 'team',
      customer: 'Globex Corporation',
      // The legacy team default. Only the two paid keys mean anything now —
      // every tier includes the rest — so this is Version Watch alone.
      features: ['version-watch'],
      seats: 10,
      issuedAt: now,
      exp: now + 365 * DAY,
      graceUntil: now + 14 * DAY,
      ...overrides,
    },
    privateKey(),
    { kid: DEV_KID }
  );
}

// Each scenario is the stored state that produces one screen. The comment is
// what you should see once the app reloads.
const STATES = {
  unregistered: {
    describe: 'Lock screen with "Start 7-day free trial" and a key field',
    build: () => ({}),
  },
  trial: {
    describe: 'Core tabs only, amber "Trial — 20h left" chip in the topbar',
    build: () => ({
      token: token({ tier: 'trial', features: [], exp: Date.now() + 20 * 3600000 }),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  'trial-ending': {
    describe: 'Core tabs only, amber "Trial — 1h left" chip',
    build: () => ({
      token: token({ tier: 'trial', features: [], exp: Date.now() + 1 * 3600000 }),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  'trial-expired': {
    describe: 'Lock screen: "Your trial has ended" — core tabs stop too',
    build: () => ({
      token: token({ tier: 'trial', features: [], exp: Date.now() - DAY }),
      lastCheckAt: Date.now() - 2 * DAY,
    }),
  },
  licensed: {
    describe: 'Legacy team licence in good standing — every tab except Security',
    build: () => ({
      token: token(),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  individual: {
    describe: 'Legacy tier — core tabs only, both paid tabs hidden',
    build: () => ({
      token: token({ tier: 'individual', seats: 1, features: [] }),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  viewer: {
    describe: 'Core tabs and Version Watch — Security hidden, /api/security 403s',
    build: () => ({
      token: token({ tier: 'viewer', seats: 10, features: ['version-watch'] }),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  'viewer-security': {
    describe: 'Every tab — the upgrade SKU',
    build: () => ({
      token: token({ tier: 'viewer-security', seats: 10, features: ['version-watch', 'security'] }),
      lastCheckAt: Date.now(),
      lastServerTimeSeen: Date.now(),
    }),
  },
  enterprise: {
    describe: 'Unlocked, every feature, offline response code bound to THIS machine',
    build: () => ({
      token: token({
        tier: 'enterprise',
        features: '*',
        seats: null,
        offline: true,
        machineId: machineFingerprint().id,
      }),
      lastCheckAt: null,
      lastServerTimeSeen: null,
    }),
  },
  grace: {
    describe: 'Unlocked, amber "Offline — locks in 3d" chip',
    build: () => ({
      token: token({ graceUntil: Date.now() + 3 * DAY }),
      lastCheckAt: Date.now() - 2 * DAY,
      lastServerTimeSeen: Date.now() - 2 * DAY,
    }),
  },
  'grace-exhausted': {
    describe: 'Lock screen: could not reach the licence service in time',
    build: () => ({
      token: token({ graceUntil: Date.now() - DAY }),
      lastCheckAt: Date.now() - 20 * DAY,
      lastServerTimeSeen: Date.now() - 20 * DAY,
    }),
  },
  expired: {
    describe: 'Lock screen: "Your licence has expired"',
    build: () => ({
      token: token({ exp: Date.now() - DAY }),
      lastCheckAt: Date.now() - 2 * DAY,
    }),
  },
  revoked: {
    describe: 'Lock screen: "Licence revoked"',
    build: () => ({
      token: token(),
      lastCheckAt: Date.now() - 3600000,
      revokedAt: Date.now(),
    }),
  },
  'clock-tampered': {
    describe: 'Lock screen: system clock is behind the last verified time',
    build: () => ({
      token: token(),
      lastCheckAt: Date.now() - 3600000,
      lastServerTimeSeen: Date.now() + 10 * DAY,
    }),
  },
  tampered: {
    describe: 'Lock screen with a red banner: the stored licence failed verification',
    build: () => {
      // Upgrade yourself to a decade of enterprise by editing the payload —
      // the JWS signature covers header and payload together, so it fails.
      const [header, body, sig] = token({ tier: 'individual' }).split('.');
      const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
      payload.tier = 'enterprise';
      payload.exp = Date.now() + 3650 * DAY;
      return {
        token: `${header}.${Buffer.from(JSON.stringify(payload)).toString('base64url')}.${sig}`,
        lastCheckAt: Date.now(),
      };
    },
  },
};

function parseFlags(argv) {
  const flags = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) continue;
    const name = argv[i].slice(2);
    const next = argv[i + 1];
    if (next && !next.startsWith('--')) {
      flags[name] = next;
      i++;
    } else {
      flags[name] = true;
    }
  }
  return flags;
}

function showCurrent() {
  const state = store.load();
  const verified = state.token ? verifyToken(state.token, trustedKeys()) : { valid: false };
  const status = evaluate({
    entitlement: verified.valid ? verified.payload : null,
    lastCheckAt: state.lastCheckAt,
    lastServerTimeSeen: state.lastServerTimeSeen,
    revokedAt: state.revokedAt,
    now: Date.now(),
  });
  console.log(`file      ${store.DEFAULT_PATH}`);
  console.log(`status    ${status.status}${status.locked ? '  (LOCKED)' : ''}`);
  console.log(`tier      ${status.tier || '—'}`);
  console.log(`customer  ${status.customer || '—'}`);
  if (status.daysRemaining !== null) console.log(`expires   in ${status.daysRemaining} days`);
  if (status.graceDaysRemaining !== null) console.log(`grace     ${status.graceDaysRemaining} days left`);
  if (status.warn) console.log(`warn      ${status.warn}`);
  if (!verified.valid && state.token) console.log(`token     INVALID (${verified.reason})`);
}

const [command, arg] = process.argv.slice(2);
const flags = parseFlags(process.argv.slice(2));

switch (command) {
  case 'states':
    for (const [name, s] of Object.entries(STATES)) {
      console.log(`  ${name.padEnd(17)} ${s.describe}`);
    }
    break;

  case 'install': {
    const scenario = STATES[arg];
    if (!scenario) {
      console.error(`Unknown state "${arg}". Run: node tools/license-dev.js states`);
      process.exit(1);
    }
    if (arg === 'unregistered') store.clear();
    else store.save(store.DEFAULT_PATH, scenario.build());
    console.log(`${arg} — ${scenario.describe}\n`);
    showCurrent();
    console.log('\nReload the app to see it.');
    break;
  }

  case 'mint': {
    const days = Number(flags.days || 365);
    const out = token({
      tier: flags.tier || 'enterprise',
      features: flags.features ? String(flags.features).split(',') : '*',
      offline: flags.offline === true,
      // An offline response code is refused unless it names a machine, so mint
      // binds to this one by default. --machine <id> targets another.
      machineId: flags.offline === true ? (flags.machine || machineFingerprint().id) : undefined,
      seats: flags.tier === 'enterprise' || !flags.tier ? null : Number(flags.seats || 10),
      exp: Date.now() + days * DAY,
      customer: flags.customer || 'Globex Corporation',
    });
    console.log(out);
    break;
  }

  // Stands in for the administrator's trip to the vendor portal. Reads a
  // request code on stdin so it composes with the clipboard:
  //   pbpaste | node tools/license-dev.js portal | pbcopy
  case 'portal': {
    const chunks = [];
    process.stdin.on('data', c => chunks.push(c));
    process.stdin.on('end', async () => {
      const requestCode = Buffer.concat(chunks).toString('utf8').trim();
      if (!requestCode) {
        console.error('No request code on stdin. Copy it from the lock screen and pipe it in:\n  pbpaste | node tools/license-dev.js portal | pbcopy');
        process.exit(1);
      }
      const base = (process.env.OASIS_LICENSE_URL || 'http://localhost:4010').replace(/\/+$/, '');
      try {
        const resp = await require('axios').post(`${base}/portal/offline-response`, {
          requestCode,
          licenseKey: flags.key || 'OASIS-ENTR-0001-0001',
        });
        process.stdout.write(resp.data.responseCode);
      } catch (err) {
        const body = err.response && err.response.data;
        // A refused connection arrives as an aggregate error with no message,
        // so fall through to the code before giving up and stringifying.
        const why = (body && body.message) || err.message || err.code || String(err);
        console.error(`Portal refused: ${why}`);
        console.error(`(is the dev licence service running? ${base})`);
        process.exit(1);
      }
    });
    break;
  }

  case 'show':
    showCurrent();
    break;

  case 'clear':
    store.clear();
    console.log('Cleared. The app is unregistered.');
    break;

  default:
    console.log(`node tools/license-dev.js <command>

  states              list the scenarios you can install
  install <state>     write that state to ${store.DEFAULT_PATH}
  mint [--tier T] [--days N] [--offline] [--features a,b] [--customer C]
  portal [--key K]    stdin: a request code -> stdout: a response code
                      (pbpaste | node tools/license-dev.js portal | pbcopy)
  show                what the app currently sees
  clear               back to unregistered
`);
}