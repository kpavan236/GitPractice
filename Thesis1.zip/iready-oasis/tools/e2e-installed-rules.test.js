'use strict';
// A REAL release, built in-process by the rules service's own pack builder from the sibling oasis-analyzer and the seeded rules
// (no database needed), signed with a throwaway key, installed by the real loader through a fake fetch, and scanned with the
// installed engine and the bundled one: the findings must be identical. Skipped, with the reason, when a sibling checkout is missing.
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const SIBLINGS = path.resolve(__dirname, '..', '..');
const RULE_SERVER = path.join(SIBLINGS, 'oasis-rule-server');
const ANALYZER = path.join(SIBLINGS, 'oasis-analyzer');
const SEED_RULES = path.join(RULE_SERVER, 'seed', 'rules');
const SEED_LANGS = path.join(RULE_SERVER, 'seed', 'languages.json');
const GRAMMARS = path.join(ANALYZER, 'src', 'ast', 'grammars');
const need = [SEED_RULES, SEED_LANGS, GRAMMARS, path.join(RULE_SERVER, 'src', 'packs', 'build.js'), path.join(ANALYZER, 'package.json')];
const missing = need.find((p) => !fs.existsSync(p));
const skip = missing ? `the sibling checkouts oasis-rule-server and oasis-analyzer are needed to build a real release (not found: ${missing})` : false;

function* jsonFiles(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) yield* jsonFiles(full);
    else if (e.name.endsWith('.json')) yield full;
  }
}

test('a real release (core from oasis-analyzer + language packs with grammars) installs and the installed engine reports what the bundled one does', { skip, timeout: 120000 }, async (t) => {
  const { buildPacks } = require(path.join(RULE_SERVER, 'src', 'packs', 'build.js'));
  const { createBlobStore } = require(path.join(RULE_SERVER, 'src', 'packs', 'blobs.js'));
  const { signManifest } = require('../server/security/engine-loader/manifest');
  const { createEngineLoader } = require('../server/security/engine-loader');
  const { createRulesUpdater } = require('../server/security/rules-updates');
  const { supportFromFlags } = require('../server/security/engine-loader/run');
  const { proveInstalledEngine } = require('./e2e-installed-rules');

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-real-pack-'));
  t.after(() => fs.rmSync(tmp, { recursive: true, force: true }));

  const languages = JSON.parse(fs.readFileSync(SEED_LANGS, 'utf8'));
  const rules = [...jsonFiles(SEED_RULES)].map((f) => JSON.parse(fs.readFileSync(f, 'utf8')));
  const blobs = createBlobStore(path.join(tmp, 'blobs'));
  const built = await buildPacks({ rules, languages, analyzerDir: ANALYZER, grammarDir: GRAMMARS, blobs });
  assert.ok(built.some((p) => p.packId === 'core') && built.filter((p) => p.kind === 'language').length > 10);

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const manifest = {
    release: 1, channel: 'beta', createdAt: new Date().toISOString(), minLoader: 1,
    packs: built.map((p) => ({ packId: p.packId, kind: p.kind, language: p.language, version: p.version, sha256: p.sha256, size: p.size })),
  };
  const signed = signManifest(manifest, privateKey.export({ type: 'pkcs8', format: 'pem' }), 'dev-1');
  const fetchImpl = async (url) => {
    const u = new URL(url);
    if (u.pathname === '/v1/releases/latest') return Response.json({ ...signed, changedPackIds: manifest.packs.map((p) => p.packId) });
    const m = /^\/v1\/blobs\/([0-9a-f]{64})$/.exec(u.pathname);
    return m && (await blobs.has(m[1])) ? new Response(await blobs.get(m[1])) : new Response('{}', { status: 404 });
  };

  const keyFile = path.join(tmp, 'dev-keys.json');
  fs.writeFileSync(keyFile, JSON.stringify({ 'dev-1': publicKey.export({ type: 'spki', format: 'pem' }) }));
  const logs = [];
  const loader = createEngineLoader({ dir: path.join(tmp, 'rules'), baseUrl: 'https://rules.example.test', channel: 'beta', fetchImpl, env: { OASIS_DEV_RULES_PUBLIC_KEYS: keyFile }, log: (m) => logs.push(m) });
  const updater = createRulesUpdater({ loader, log: () => {} });
  assert.equal((await updater.update()).status, 'updated');
  assert.deepEqual(loader.devKeys(), ['dev-1']);

  const open = supportFromFlags(process.allowedNodeEnvironmentFlags).netDenial ? {} : { OASIS_ALLOW_OPEN_NETWORK_ENGINE: '1' };
  const out = await proveInstalledEngine({ updater, env: { OASIS_ENGINE: 'installed', ...open } });
  assert.ok(out.findings >= 50, `expected a meaningful sample, got ${out.findings} findings`);
  for (const id of ['AST_SAST', 'BUILTIN_SECRETS', 'IAC_POLICY', 'PATTERN_SAST']) assert.ok(out.bySource[id] > 0, `${id} found nothing`);
  assert.ok(out.grammars.includes('tree-sitter-javascript.wasm'), 'language-pack grammars reached the engine');
});
