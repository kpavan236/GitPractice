'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createTrialReviewer, WEAK_FINGERPRINT, MANY_FROM_ONE_SOURCE } = require('./trial-review');

const HOUR = 3600000;
const make = (over = {}) => {
  let t = 1_000_000;
  const reviewer = createTrialReviewer({ now: () => t, ...over });
  return { reviewer, advance: ms => { t += ms; } };
};
const IP = '203.0.113.9';

test('an ordinary first trial from a hardware fingerprint is not flagged', () => {
  const { reviewer } = make();
  assert.deepEqual(reviewer.review({ source: IP, fingerprintSource: 'darwin' }), { flagged: false, reasons: [] });
});

test('a fallback fingerprint is flagged as weak, because hostname and home directory can be changed', () => {
  const { reviewer } = make();
  assert.deepEqual(reviewer.review({ source: IP, fingerprintSource: 'fallback' }), { flagged: true, reasons: [WEAK_FINGERPRINT] });
});

test('a missing fingerprint source is treated as weak, not trusted', () => {
  const { reviewer } = make();
  assert.deepEqual(reviewer.review({ source: IP }).reasons, [WEAK_FINGERPRINT]);
});

test('the first three trials from one source pass; the fourth within the window is flagged', () => {
  const { reviewer } = make();
  for (let i = 0; i < 3; i++) assert.equal(reviewer.review({ source: IP, fingerprintSource: 'darwin' }).flagged, false, `trial ${i + 1}`);
  const fourth = reviewer.review({ source: IP, fingerprintSource: 'darwin' });
  assert.deepEqual(fourth, { flagged: true, reasons: [MANY_FROM_ONE_SOURCE] });
});

test('trials outside the window no longer count, and other sources are counted separately', () => {
  const { reviewer, advance } = make();
  for (let i = 0; i < 3; i++) reviewer.review({ source: IP, fingerprintSource: 'darwin' });
  assert.equal(reviewer.review({ source: '198.51.100.7', fingerprintSource: 'darwin' }).flagged, false);
  advance(25 * HOUR);
  assert.equal(reviewer.review({ source: IP, fingerprintSource: 'darwin' }).flagged, false);
});

test('both reasons can apply at once', () => {
  const { reviewer } = make({ maxPerSource: 1 });
  reviewer.review({ source: IP, fingerprintSource: 'darwin' });
  assert.deepEqual(reviewer.review({ source: IP, fingerprintSource: 'fallback' }).reasons, [WEAK_FINGERPRINT, MANY_FROM_ONE_SOURCE]);
});

test('no raw address is kept: sources are held only as salted hashes, and two reviewers cannot compare them', () => {
  const a = make().reviewer; const b = make().reviewer;
  a.review({ source: IP, fingerprintSource: 'darwin' });
  b.review({ source: IP, fingerprintSource: 'darwin' });
  const keysA = a.heldKeys(); const keysB = b.heldKeys();
  assert.equal(keysA.length, 1);
  assert.doesNotMatch(JSON.stringify(keysA), /203\.0\.113\.9/);
  assert.notEqual(keysA[0], keysB[0], 'the salt differs per process, so hashes are not linkable across restarts');
});

test('memory is bounded: sources whose window has passed are dropped', () => {
  const { reviewer, advance } = make();
  for (let i = 0; i < 50; i++) reviewer.review({ source: `192.0.2.${i}`, fingerprintSource: 'darwin' });
  assert.equal(reviewer.heldKeys().length, 50);
  advance(25 * HOUR);
  reviewer.review({ source: '192.0.2.250', fingerprintSource: 'darwin' });
  assert.equal(reviewer.heldKeys().length, 1);
});
