'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');

// Starts the real dev licence service, with a throwaway key and database on a free port, and
// talks to it over HTTP. Nothing of the developer's own data is touched.

const freePort = () => new Promise(resolve => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const MACHINE_A = 'a'.repeat(32);
const MACHINE_B = 'b'.repeat(32);
const MACHINE_C = 'c'.repeat(32);

let child, base, dir;
const post = (route, body) => fetch(`${base}${route}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }).then(async r => ({ status: r.status, body: await r.json().catch(() => ({})) }));
const get = route => fetch(`${base}${route}`).then(async r => ({ status: r.status, body: await r.json().catch(() => ({})) }));
const payloadOf = token => JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString('utf8'));

async function code(email) { return (await get(`/admin/last-otp?email=${encodeURIComponent(email)}`)).body.code; }
async function activate(email, machineId) {
  const sent = await post('/domain/otp', { email, machineId });
  assert.equal(sent.status, 200, JSON.stringify(sent.body));
  return post('/domain/activate', { email, machineId, code: await code(email) });
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lic-dev-'));
  const { privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(dir, 'private.pem'), privateKey.export({ type: 'pkcs8', format: 'pem' }));
  const port = await freePort();
  base = `http://127.0.0.1:${port}`;
  child = spawn(process.execPath, [path.join(__dirname, 'license-service-dev.js')], {
    env: { ...process.env, LICENSE_SERVICE_PORT: String(port), LICENSE_SERVICE_DB: path.join(dir, 'db.json'), OASIS_LICENSE_PRIVATE_KEY: path.join(dir, 'private.pem') },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  child.stdout.on('data', d => { output += d; });
  child.stderr.on('data', d => { output += d; });
  for (let i = 0; i < 50; i++) { try { if ((await fetch(`${base}/admin/state`)).ok) return; } catch (_) { /* not up yet */ } await sleep(100); }
  throw new Error(`the dev service did not start: ${output}`);
});
test.after(() => { if (child) child.kill(); if (dir) fs.rmSync(dir, { recursive: true, force: true }); });

test('a code is sent only to an address whose company holds a licence', async () => {
  const ok = await post('/domain/otp', { email: 'Pat@Acme.Example.Test', machineId: MACHINE_A });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.sentTo, 'p***@acme.example.test', 'the address is masked in the answer');
  const none = await post('/domain/otp', { email: 'pat@nobody.example.test', machineId: MACHINE_A });
  assert.equal(none.status, 404);
  assert.equal(none.body.reason, 'no_domain_licence');
  assert.match(none.body.message, /No licence was found for nobody\.example\.test/);
  assert.equal((await post('/domain/otp', { email: 'not-an-email', machineId: MACHINE_A })).body.reason, 'bad_email');
});

test('the right code activates: a token for the organisation, with its tier and expiry', async () => {
  const r = await activate('sam@acme.example.test', MACHINE_A);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const p = payloadOf(r.body.token);
  assert.equal(p.tier, 'team');
  assert.equal(p.customer, 'Acme Example Ltd');
  assert.ok(p.exp > Date.now() + 300 * 86400000, 'a year-long licence');
  assert.doesNotMatch(JSON.stringify(p), /sam@/, 'the person\'s address is not in the token');
});

test('a wrong code is refused with the tries left, and a used code cannot be used again', async () => {
  const email = 'wrong@acme.example.test';
  await post('/domain/otp', { email, machineId: MACHINE_B });
  const bad = await post('/domain/activate', { email, machineId: MACHINE_B, code: '000000' });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.reason, 'wrong_code');
  assert.match(bad.body.message, /4 tries left/);
  const good = await code(email);
  assert.equal((await post('/domain/activate', { email, machineId: MACHINE_B, code: good })).status, 200);
  const again = await post('/domain/activate', { email, machineId: MACHINE_B, code: good });
  assert.equal(again.body.reason, 'no_code');
});

test('a licence that has ended is reported after the code succeeds, with its date', async () => {
  const r = await activate('lee@expired.example.test', MACHINE_A);
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'expired');
  assert.match(r.body.message, /licence ended on \d{4}-\d{2}-\d{2}/);
  assert.match(r.body.expiredOn, /^\d{4}-\d{2}-\d{2}$/);
});

test('the seat limit applies to activating by email, and the same machine can come back', async () => {
  assert.equal((await activate('one@tiny.example.test', MACHINE_A)).status, 200);
  assert.equal((await activate('two@tiny.example.test', MACHINE_A)).status, 200, 'the same machine again is free');
  const second = await activate('three@tiny.example.test', MACHINE_C);
  assert.equal(second.status, 403);
  assert.equal(second.body.reason, 'seats_full');
});

test('codes cannot be requested without limit for one address', async () => {
  const email = 'spam@acme.example.test';
  for (let i = 0; i < 3; i++) assert.equal((await post('/domain/otp', { email, machineId: `m${i}`.padEnd(32, 'x') })).status, 200);
  const r = await post('/domain/otp', { email, machineId: MACHINE_A });
  assert.equal(r.status, 429);
  assert.equal(r.body.reason, 'too_many_requests');
  assert.ok(r.body.retryAfterSeconds > 0);
});

test('a purchase request is checked, stored, and visible to support', async () => {
  const bad = await post('/purchase-request', { organization: '', employees: 'lots' });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.reason, 'invalid');
  assert.ok(bad.body.errors.organization && bad.body.errors.employees && bad.body.errors.email && bad.body.errors.contactName);

  const ok = await post('/purchase-request', {
    organization: 'Globex Example', employees: 120, email: 'Buyer@Globex.Example.Test', contactName: 'Buyer Example',
    status: 'AGREED', expiry: '2099-01-01',
  });
  assert.equal(ok.status, 200);
  assert.match(ok.body.reference, /^PR-\d{4}$/);

  const list = (await get('/admin/purchase-requests')).body;
  const mine = list.find(r => r.reference === ok.body.reference);
  assert.equal(mine.organization, 'Globex Example');
  assert.equal(mine.email, 'buyer@globex.example.test');
  assert.equal(mine.employees, 120);
  assert.equal(mine.contactName, 'Buyer Example');
  assert.equal(mine.phone, undefined, 'the form no longer asks for a phone number');
  assert.equal(mine.status, 'NEW', 'a customer cannot set the status');
  assert.equal(mine.expiry, undefined, 'or invent an expiry');
});

test('a repeated submit with the same Idempotency-Key is one request, with the first reference', async () => {
  const body = { organization: 'Retry Example', employees: 7, email: 'retry@retry.example.test', contactName: 'R' };
  const send = key => fetch(`${base}/purchase-request`, { method: 'POST', headers: { 'content-type': 'application/json', 'Idempotency-Key': key }, body: JSON.stringify(body) });
  const first = await send('buy-retry-0001');
  const again = await send('buy-retry-0001');
  const other = await send('buy-retry-0002');
  const [a, b, c] = [await first.json(), await again.json(), await other.json()];
  assert.equal(b.reference, a.reference, 'the repeat gets the first answer');
  assert.equal(again.headers.get('idempotent-replay'), 'true');
  assert.notEqual(c.reference, a.reference, 'a different key is a different request');
  const mine = (await get('/admin/purchase-requests')).body.filter(r => r.email === 'retry@retry.example.test');
  assert.equal(mine.length, 2, 'two requests stored, not three');
});

test('the same address cannot flood the support team', async () => {
  const body = { organization: 'Flood Ltd', employees: 5, email: 'flood@flood.example.test', contactName: 'F' };
  let last;
  for (let i = 0; i < 6; i++) last = await post('/purchase-request', body);
  assert.equal(last.status, 429);
});

test('support records an organisation\'s licence and expiry, and activation then follows it', async () => {
  const bad = await post('/admin/domain-license', { domain: 'Not A Domain', tier: 'team', days: 30 });
  assert.equal(bad.status, 400);
  assert.equal((await post('/admin/domain-license', { domain: 'globex.example.test', tier: 'nonsense', days: 30 })).status, 400);
  assert.equal((await post('/admin/domain-license', { domain: 'globex.example.test', tier: 'team' })).status, 400, 'an expiry is required');

  const made = await post('/admin/domain-license', { domain: 'globex.example.test', tier: 'viewer', customer: 'Globex Example', seats: 5, expiresOn: '2099-12-31' });
  assert.equal(made.status, 200);
  assert.equal(made.body.expires, '2099-12-31');
  const r = await activate('anyone@globex.example.test', MACHINE_A);
  assert.equal(r.status, 200);
  assert.equal(payloadOf(r.body.token).tier, 'viewer');
  assert.equal(new Date(payloadOf(r.body.token).exp).toISOString().slice(0, 10), '2099-12-31');
});

test('activating with a licence key still works as before (the refactor changed nothing)', async () => {
  const key = 'OASIS-TEAM-TINY-0002';
  assert.equal((await post('/activate', { machineId: MACHINE_A, licenseKey: key })).status, 200);
  assert.equal((await post('/activate', { machineId: MACHINE_B, licenseKey: key })).status, 200);
  const third = await post('/activate', { machineId: MACHINE_C, licenseKey: key });
  assert.equal(third.status, 403);
  assert.match(third.body.message, /All 2 seats/);
  assert.equal((await post('/activate', { machineId: MACHINE_A, licenseKey: 'OASIS-NOPE' })).status, 400);
});

test('reset clears the organisation licences and the purchase requests', async () => {
  assert.equal((await post('/admin/reset', {})).status, 200);
  assert.deepEqual((await get('/admin/purchase-requests')).body, []);
  assert.equal(Object.keys((await get('/admin/state')).body.domains).length, 0);
});
