'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createOtpStore } = require('./otp-store');

const MIN = 60 * 1000;
function make(opts = {}) {
  let t = 1_000_000;
  const codes = ['111111', '222222', '333333', '444444', '555555', '666666', '777777', '888888', '999999', '123456', '234567', '345678', '456789'];
  let i = 0;
  const store = createOtpStore({ now: () => t, randomCode: () => codes[i++ % codes.length], ...opts });
  return { store, advance: ms => { t += ms; } };
}
const E = 'pat@acme.example.test';

test('a code is issued, and is a six-digit string', () => {
  const r = make().store.request(E);
  assert.equal(r.ok, true);
  assert.match(r.code, /^\d{6}$/);
});

test('the real generator makes six digits, with leading zeros kept', () => {
  const store = createOtpStore();
  for (let i = 0; i < 200; i++) assert.match(store.request(`u${i}@acme.example.test`).code, /^\d{6}$/);
});

test('the right code works, once; using it again fails', () => {
  const { store } = make();
  const { code } = store.request(E);
  assert.deepEqual(store.verify(E, code), { ok: true });
  assert.equal(store.verify(E, code).reason, 'no_code', 'single use');
});

test('spaces around a code are forgiven; other shapes are simply wrong', () => {
  const { store } = make();
  const { code } = store.request(E);
  assert.equal(store.verify(E, '12 34').ok, false);
  assert.equal(store.verify(E, `  ${code} `).ok, true);
});

test('a wrong code is refused and counts against the limit; five wrong tries lock the code', () => {
  const { store } = make();
  const { code } = store.request(E);
  for (let i = 1; i <= 4; i++) {
    const r = store.verify(E, '000000');
    assert.equal(r.reason, 'wrong_code');
    assert.equal(r.attemptsLeft, 5 - i);
  }
  assert.equal(store.verify(E, '000000').reason, 'too_many_attempts');
  assert.equal(store.verify(E, code).reason, 'too_many_attempts', 'even the right code no longer works once locked');
});

test('a code expires after ten minutes', () => {
  const { store, advance } = make();
  const { code } = store.request(E);
  advance(9 * MIN + 59 * 1000);
  assert.equal(store.verify(E, code).ok, true, 'just inside the limit');
  const second = store.request(E);
  advance(10 * MIN + 1);
  assert.equal(store.verify(E, second.code).reason, 'expired');
});

test('asking again replaces the code: the old one stops working', () => {
  const { store } = make();
  const first = store.request(E).code;
  const second = store.request(E).code;
  assert.notEqual(first, second);
  assert.equal(store.verify(E, first).reason, 'wrong_code');
  assert.equal(store.verify(E, second).ok, true);
});

test('a code only works for the address it was sent to', () => {
  const { store } = make();
  const { code } = store.request(E);
  assert.equal(store.verify('sam@acme.example.test', code).reason, 'no_code');
});

test('three requests per fifteen minutes for one address, then it asks the user to wait', () => {
  const { store, advance } = make();
  for (let i = 0; i < 3; i++) assert.equal(store.request(E).ok, true);
  const r = store.request(E);
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'too_many_requests');
  assert.ok(r.retryAfterSeconds > 0 && r.retryAfterSeconds <= 15 * 60);
  advance(15 * MIN + 1);
  assert.equal(store.request(E).ok, true, 'allowed again once the window has passed');
});

test('one machine cannot send codes to a stream of different addresses', () => {
  const { store } = make();
  let refused = 0;
  for (let i = 0; i < 15; i++) if (!store.request(`user${i}@acme.example.test`, 'machine-1').ok) refused += 1;
  assert.equal(refused, 5, 'ten per machine per window, then refused');
  assert.equal(store.request('other@acme.example.test', 'machine-2').ok, true, 'another machine is unaffected');
});

test('a locked address stays locked until a new code is asked for', () => {
  const { store } = make();
  store.request(E);
  for (let i = 0; i < 5; i++) store.verify(E, '000000');
  const fresh = store.request(E);
  assert.equal(fresh.ok, true);
  assert.equal(store.verify(E, fresh.code).ok, true, 'a new code starts clean');
});

test('no code is kept in the store: only a salted hash, and the same code hashes differently each time', () => {
  const { store } = make({ randomCode: () => '424242' });
  const a = store.request('a@acme.example.test').code;
  store.request('b@acme.example.test');
  const dump = JSON.stringify(store.snapshot());
  assert.equal(a, '424242');
  assert.doesNotMatch(dump, /424242/);
  const hashes = [...dump.matchAll(/"hash":"([0-9a-f]+)"/g)].map(m => m[1]);
  assert.equal(hashes.length, 2);
  assert.notEqual(hashes[0], hashes[1], 'a per-code salt');
});

test('only the development service may read a code back, and only if it asked to', () => {
  assert.equal(make().store.devLastCode(E), undefined);
  const { store } = make({ keepForDev: true });
  const { code } = store.request(E);
  assert.equal(store.devLastCode(E), code);
  store.verify(E, code);
  assert.equal(store.devLastCode(E), undefined, 'gone once used');
});

test('memory stays bounded: old challenges and request records are dropped', () => {
  const { store, advance } = make();
  for (let i = 0; i < 50; i++) store.request(`u${i}@acme.example.test`);
  assert.equal(store.snapshot().challenges.length, 50);
  advance(40 * MIN);
  store.request('late@acme.example.test');
  assert.equal(store.snapshot().challenges.length, 1);
});
