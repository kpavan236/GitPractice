#!/usr/bin/env bash
# Runs the OASIS back-end services as macOS background services (launchd LaunchAgents):
# they start when you log in, restart if they crash, and keep running when a terminal closes.
#
#   licence   oasis-licence-service   4020
#   support   oasis-support-service   4040
#   billing   oasis-billing-service   4060
#   portal    oasis-support-portal    4030
#   rules     oasis-rule-server       5090
#   studio    oasis-rule-studio       4050
#
# The public central release service (oasis-rule-server src/central-server.js, default port 5091) is not managed by this script yet.
#
#   tools/oasis-services.sh install [name]   write the agents, stop any copy started by stack.sh, start all six; with a name, install only that one and leave the rest alone
#   tools/oasis-services.sh status      what is loaded, and whether each one answers
#   tools/oasis-services.sh restart [name]
#   tools/oasis-services.sh stop [name]    stop (and, until the next login or `start`, keep stopped)
#   tools/oasis-services.sh start [name]
#   tools/oasis-services.sh logs [name]    follow a log
#   tools/oasis-services.sh uninstall   stop them and remove the agents (databases and .env files are kept)
#
# Run `oasis-support-portal/scripts/stack.sh init` once first: it creates the databases, the .env files
# and the signing key for the licence, support, billing and portal services ONLY. The Studio's .env and databases
# are created by hand (see oasis-rule-studio/README.md). These agents run each service with its own .env, exactly as
# stack.sh does, so settings stay where they are. LOCAL DEVELOPMENT ONLY: the .env files hold throwaway
# passwords and the email sender is a fake (no provider is approved yet).
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="${OASIS_REPOS_DIR:-$(cd "$HERE/.." && pwd)}"
STATE="${STACK_HOME:-$HOME/.oasis-local-stack}"
AGENTS="$HOME/Library/LaunchAgents"
PREFIX="com.cainc.oasis"
UID_N="$(id -u)"
NODE="${OASIS_NODE:-$(command -v node || true)}"
PG_CONTAINER="${PG_CONTAINER:-oasis-pg}"

NAMES=(licence support billing portal rules studio)
dir_of()  { case "$1" in licence) echo "$ROOT/oasis-licence-service";; support) echo "$ROOT/oasis-support-service";; billing) echo "$ROOT/oasis-billing-service";; portal) echo "$ROOT/oasis-support-portal";; rules) echo "$ROOT/oasis-rule-server";; studio) echo "$ROOT/oasis-rule-studio";; esac; }
port_of() { case "$1" in licence) echo 4020;; support) echo 4040;; billing) echo 4060;; portal) echo 4030;; rules) echo 5090;; studio) echo 4050;; esac; }
path_of() { case "$1" in rules) echo /api/v1/health;; licence) echo /readyz;; *) echo /healthz;; esac; }
label_of() { echo "$PREFIX.$1"; }
plist_of() { echo "$AGENTS/$(label_of "$1").plist"; }

die() { printf 'Error: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

pick() {   # names to act on: the one given, or all
  if [ -n "${1:-}" ]; then
    case " ${NAMES[*]} " in *" $1 "*) echo "$1";; *) die "Unknown service '$1'. Use: ${NAMES[*]}";; esac
  else
    echo "${NAMES[@]}"
  fi
}

write_plist() {   # write_plist <name>
  local name="$1" dir; dir="$(dir_of "$name")"
  local args env_args=""
  if [ "$name" = rules ]; then
    # The rule server has no .env: its settings (port, database file) have defaults.
    args="<string>$NODE</string><string>src/server.js</string>"
  else
    args="<string>$NODE</string><string>--env-file=.env</string><string>src/server.js</string>"
  fi
  cat > "$(plist_of "$name")" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$(label_of "$name")</string>
  <key>ProgramArguments</key><array>$args</array>
  <key>WorkingDirectory</key><string>$dir</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$STATE/logs/$name.log</string>
  <key>StandardErrorPath</key><string>$STATE/logs/$name.log</string>
  <key>EnvironmentVariables</key><dict>
    <key>PATH</key><string>$(dirname "$NODE"):/usr/local/bin:/usr/bin:/bin</string>
  </dict>
</dict>
</plist>
EOF
}

loaded() { launchctl print "gui/$UID_N/$(label_of "$1")" >/dev/null 2>&1; }

answers() { curl -fs -o /dev/null --max-time 3 "http://127.0.0.1:$(port_of "$1")$(path_of "$1")"; }

wait_up() {   # wait_up <name>
  for _ in $(seq 1 40); do answers "$1" && return 0; sleep 0.5; done
  return 1
}

cmd_install() {   # cmd_install [name]: with a name, only that service is installed and the others are left exactly as they are
  local targets; targets="$(pick "${1:-}")"
  [ -n "$NODE" ] || die "node was not found. Install Node 22 or newer, or set OASIS_NODE."
  for n in $targets; do [ -d "$(dir_of "$n")" ] || die "Missing $(dir_of "$n") (set OASIS_REPOS_DIR)."; done
  for n in $targets; do
    if [ ! -f "$(dir_of "$n")/.env" ]; then
      if [ "$n" = studio ]; then die "$(dir_of "$n")/.env is missing. Copy $(dir_of "$n")/.env.example to .env and fill it in, create the databases, then run: npm run migrate"; fi
      die "$(dir_of "$n")/.env is missing. Run once: $ROOT/oasis-support-portal/scripts/stack.sh init"
    fi
  done
  mkdir -p "$AGENTS" "$STATE/logs"

  # Postgres is what the licence, support and portal services need. Make it come back after a reboot,
  # otherwise they would restart in a loop at login until someone started it.
  if command -v docker >/dev/null 2>&1 && docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$PG_CONTAINER"; then
    docker update --restart unless-stopped "$PG_CONTAINER" >/dev/null
    docker ps --format '{{.Names}}' | grep -qx "$PG_CONTAINER" || docker start "$PG_CONTAINER" >/dev/null
    say "PostgreSQL container $PG_CONTAINER: set to restart automatically (Docker Desktop must start at login)."
  else
    say "Note: no Docker container named $PG_CONTAINER, so make sure PostgreSQL is running on the port in each .env."
  fi

  # Copies started by stack.sh or by hand hold the ports; they are the same services, so replace them.
  if [ -z "${1:-}" ] && [ -x "$ROOT/oasis-support-portal/scripts/stack.sh" ]; then "$ROOT/oasis-support-portal/scripts/stack.sh" down >/dev/null 2>&1 || true; fi
  for n in $targets; do
    loaded "$n" && launchctl bootout "gui/$UID_N/$(label_of "$n")" 2>/dev/null || true
    pid="$(lsof -ti :"$(port_of "$n")" -sTCP:LISTEN 2>/dev/null || true)"
    if [ -n "$pid" ]; then say "Stopping the copy on port $(port_of "$n") (PID $pid) so the service can take it."; kill $pid 2>/dev/null || true; sleep 1; fi
  done

  for n in $targets; do
    write_plist "$n"
    launchctl bootstrap "gui/$UID_N" "$(plist_of "$n")"
    say "Installed and started: $n (port $(port_of "$n"))"
  done
  say ""
  local bad=0
  for n in $targets; do
    if wait_up "$n"; then say "  $n is up: http://127.0.0.1:$(port_of "$n")/"; else say "  $n did not answer. Log: $STATE/logs/$n.log"; bad=1; fi
  done
  [ "$bad" -eq 0 ] || exit 1
  say ""
  say "They now start at login and restart if they stop. Check: $0 status"
}

cmd_status() {
  for n in "${NAMES[@]}"; do
    local state="not installed"
    if loaded "$n"; then
      state="loaded"
      pid="$(launchctl print "gui/$UID_N/$(label_of "$n")" 2>/dev/null | awk '/^[[:space:]]*pid = /{print $3; exit}')"
      [ -n "${pid:-}" ] && state="running (pid $pid)" || state="loaded, not running"
    elif [ -f "$(plist_of "$n")" ]; then
      state="installed, stopped"
    fi
    if answers "$n"; then printf '  %-8s %-26s answering on http://127.0.0.1:%s/\n' "$n" "$state" "$(port_of "$n")"
    else printf '  %-8s %-26s not answering on port %s\n' "$n" "$state" "$(port_of "$n")"; fi
  done
}

cmd_start() {
  for n in $(pick "${1:-}"); do
    [ -f "$(plist_of "$n")" ] || die "$n is not installed. Run: $0 install"
    loaded "$n" || launchctl bootstrap "gui/$UID_N" "$(plist_of "$n")"
    say "started $n"
  done
}

cmd_stop() {
  for n in $(pick "${1:-}"); do
    if loaded "$n"; then launchctl bootout "gui/$UID_N/$(label_of "$n")"; say "stopped $n"; else say "$n was not running"; fi
  done
}

cmd_restart() {
  for n in $(pick "${1:-}"); do
    [ -f "$(plist_of "$n")" ] || die "$n is not installed. Run: $0 install"
    if loaded "$n"; then launchctl kickstart -k "gui/$UID_N/$(label_of "$n")"; else launchctl bootstrap "gui/$UID_N" "$(plist_of "$n")"; fi
    wait_up "$n" && say "restarted $n" || say "$n did not answer after restart. Log: $STATE/logs/$n.log"
  done
}

cmd_uninstall() {
  for n in "${NAMES[@]}"; do
    loaded "$n" && launchctl bootout "gui/$UID_N/$(label_of "$n")" 2>/dev/null || true
    rm -f "$(plist_of "$n")"
    say "removed $n"
  done
  say "Databases, .env files and logs were left alone."
}

cmd_logs() {
  local n="${1:-licence}"; pick "$n" >/dev/null
  tail -n 40 -f "$STATE/logs/$n.log"
}

case "${1:-}" in
  install) shift; cmd_install "${1:-}" ;; status) cmd_status ;; start) shift; cmd_start "${1:-}" ;; stop) shift; cmd_stop "${1:-}" ;;
  restart) shift; cmd_restart "${1:-}" ;; logs) shift; cmd_logs "${1:-}" ;; uninstall) cmd_uninstall ;;
  *) sed -n '2,/^set -euo/p' "${BASH_SOURCE[0]}" | sed '$d' | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
