#!/usr/bin/env node
'use strict';

// End-to-end check of the local stack: OASIS, the licence service, the support service,
// the support portal and the rule server, over their real HTTP APIs.
//
//   ../oasis-support-portal/scripts/stack.sh up      licence 4020, support 4040, portal 4030
//   ./start-rule-server.sh                           rule server 5090
//   ./start-licensed.sh --web                        OASIS 3000 (enforcement on)
//   node tools/e2e-stack.js
//
// LOCAL DEVELOPMENT ONLY. It writes test data to the local dev databases (a purchase request,
// a support request, feedback, a customer, a licence, a staff account) and changes this
// machine's stored licence. Every address uses the reserved example.test domain.
//
// Environment: OASIS_URL, LICENCE_URL, SUPPORT_URL, PORTAL_URL, BILLING_URL, RULES_URL, STACK_HOME,
// E2E_PORTAL_REPOS (the folder holding the sibling repos), E2E_STAFF_EMAIL, E2E_STAFF_PASSWORD.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const OASIS = process.env.OASIS_URL || 'http://localhost:3000';
const LICENCE = process.env.LICENCE_URL || 'http://localhost:4020';
const SUPPORT = process.env.SUPPORT_URL || 'http://localhost:4040';
const PORTAL = process.env.PORTAL_URL || 'http://127.0.0.1:4030';
const BILLING = process.env.BILLING_URL || 'http://127.0.0.1:4060';
const RULES = process.env.RULES_URL || 'http://127.0.0.1:5090';
const STACK_HOME = process.env.STACK_HOME || path.join(os.homedir(), '.oasis-local-stack');
const REPOS = process.env.E2E_PORTAL_REPOS || path.resolve(__dirname, '..', '..');
const STAFF_EMAIL = process.env.E2E_STAFF_EMAIL || 'e2e@staff.example.test';
// A throwaway password for a throwaway local account. Not for anywhere shared.
const STAFF_PASSWORD = process.env.E2E_STAFF_PASSWORD || 'E2e-local-only-Pa55phrase-7391';

const RUN = Date.now().toString(36);
const DOMAIN = `e2e-${RUN}.example.test`;
const ORG = `E2E Org ${RUN}`;

const results = [];
const ctx = {};

async function http(method, base, route, { body, headers = {}, token } = {}) {
  const res = await fetch(base + route, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) { /* not JSON */ }
  return { status: res.status, json, text };
}

function expect(cond, message) {
  if (!cond) throw new Error(message);
}

const SKIP = Symbol('skip');

async function step(name, fn) {
  try {
    const note = await fn();
    if (note && note[SKIP]) {
      results.push({ name, ok: true, skipped: true, note: note.reason });
      console.log(`  SKIP  ${name}  (${note.reason})`);
      return true;
    }
    results.push({ name, ok: true, note: note || '' });
    console.log(`  PASS  ${name}${note ? `  (${note})` : ''}`);
    return true;
  } catch (err) {
    results.push({ name, ok: false, note: err.message });
    console.log(`  FAIL  ${name}\n          ${err.message}`);
    return false;
  }
}

const skip = reason => ({ [SKIP]: true, reason });

function readLog(name) {
  try { return fs.readFileSync(path.join(STACK_HOME, 'logs', `${name}.log`), 'utf8'); } catch (_) { return ''; }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function waitForLog(name, re, since, ms = 6000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const hit = readLog(name).slice(since).match(re);
    if (hit) return hit;
    await sleep(250);
  }
  return null;
}

const portalAdmin = (method, route, body) => http(method, PORTAL, `/v1/admin${route}`, { body, token: ctx.staffToken });

async function main() {
  console.log(`\nOASIS end-to-end (run ${RUN})\n`);

  // ── 0. Everything is up ──────────────────────────────────────────────────
  console.log('Services');
  const up = await Promise.all([
    step('OASIS answers', async () => { const r = await http('GET', OASIS, '/api/license/status'); expect(r.status === 200, `HTTP ${r.status}`); expect(String(r.json.serviceUrl || '').startsWith(LICENCE), `OASIS points at ${r.json.serviceUrl}, not ${LICENCE}. Start it with ./start-licensed.sh`); return r.json.serviceUrl; }),
    step('Licence service ready', async () => { const r = await http('GET', LICENCE, '/readyz'); expect(r.status === 200, `HTTP ${r.status}`); }),
    step('Support service healthy', async () => { const r = await http('GET', SUPPORT, '/healthz'); expect(r.status === 200, `HTTP ${r.status}`); }),
    step('Support portal healthy', async () => { const r = await http('GET', PORTAL, '/healthz'); expect(r.status === 200, `HTTP ${r.status}`); }),
    step('Billing service ready', async () => { const r = await http('GET', BILLING, '/readyz'); expect(r.status === 200, `HTTP ${r.status}`); }),
    step('Rule server healthy', async () => { const r = await http('GET', RULES, '/api/v1/health'); expect(r.status === 200, `HTTP ${r.status}`); }),
  ]);
  if (up.includes(false)) { console.log('\nStart the missing services first (see the top of this file).'); return finish(); }

  // ── 1. A new machine: trial and the Buy form ─────────────────────────────
  console.log('\nOASIS and the licence service');
  await step('Fresh machine: stored licence cleared', async () => {
    execFileSync('node', [path.join(__dirname, 'license-dev.js'), 'clear'], { stdio: 'ignore' });
    const r = await http('GET', OASIS, '/api/license/status');
    expect(r.json.status === 'unregistered', `status is ${r.json.status}`);
  });
  await step('Start trial: token from the service is accepted', async () => {
    const r = await http('POST', OASIS, '/api/license/trial', { body: {} });
    if (r.status === 400 && /already has a licence/i.test(r.text)) {
      ctx.noTrial = true;
      return skip('this machine already holds a licence, so it cannot start another trial; use a fresh machine or database to test this');
    }
    expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
    expect(r.json.tier === 'trial' && r.json.locked === false, `tier ${r.json.tier}, locked ${r.json.locked}, tokenError ${r.json.tokenError}`);
    ctx.machineId = r.json.machineId;
    return `${r.json.daysRemaining} days`;
  });
  await step('Trial does not include Security', async () => {
    if (ctx.noTrial) return skip('no trial on this machine');
    const r = await http('GET', OASIS, '/api/security/rules/config');
    expect(r.status === 403 && r.json.error === 'feature_not_licensed', `HTTP ${r.status} ${r.json && r.json.error}`);
  });
  await step('Buy form: a personal address is refused before any code is sent', async () => {
    const r = await http('POST', OASIS, '/api/license/purchase-code', { body: { email: 'buyer@gmail.com' } });
    expect(r.status === 400 && r.json.details && r.json.details.reason === 'not_corporate_email', `HTTP ${r.status} ${r.text.slice(0, 200)}`);
  });
  await step('Buy form: the work email is confirmed with a one-time code', async () => {
    const pos = readLog('licence').length;
    const asked = await http('POST', OASIS, '/api/license/purchase-code', { body: { email: `buyer@${DOMAIN}` } });
    expect(asked.status === 200 && asked.json.ok, `HTTP ${asked.status} ${asked.text.slice(0, 200)}`);
    const hit = await waitForLog('licence', new RegExp(`one-time code for buyer@${DOMAIN.replace(/\./g, '\\.')}: (\\d{6})`), pos);
    expect(hit, 'code not found in the licence log (is DEV_PRINT_CODES=1?)');
    const r = await http('POST', OASIS, '/api/license/purchase-verify', { body: { email: `buyer@${DOMAIN}`, code: hit[1] } });
    expect(r.status === 200 && r.json.verificationToken, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
    ctx.purchaseProof = r.json.verificationToken;
  });
  await step('Buy form: a request without the confirmation is refused', async () => {
    const r = await http('POST', OASIS, '/api/license/purchase-request', {
      body: { organization: ORG, employees: 25, email: `buyer@${DOMAIN}`, contactName: 'E2E Buyer' },
    });
    expect(r.status === 400 && r.json.details && r.json.details.reason === 'email_not_verified', `HTTP ${r.status} ${r.text.slice(0, 200)}`);
  });
  await step('Buy form: request accepted by the licence service', async () => {
    const r = await http('POST', OASIS, '/api/license/purchase-request', {
      body: { organization: ORG, employees: 25, email: `buyer@${DOMAIN}`, contactName: 'E2E Buyer', verificationToken: ctx.purchaseProof },
      headers: { 'idempotency-key': `e2e-${RUN}-purchase` },
    });
    expect(r.status === 200 && r.json.reference, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
    ctx.purchaseRef = r.json.reference;
    return ctx.purchaseRef;
  });
  await step('Buy form: same Idempotency-Key does not create a second request', async () => {
    const r = await http('POST', OASIS, '/api/license/purchase-request', {
      body: { organization: ORG, employees: 25, email: `buyer@${DOMAIN}`, contactName: 'E2E Buyer', verificationToken: ctx.purchaseProof },
      headers: { 'idempotency-key': `e2e-${RUN}-purchase` },
    });
    expect(r.json && r.json.reference === ctx.purchaseRef, `got ${r.json && r.json.reference}, wanted ${ctx.purchaseRef}`);
  });
  await step('Buy form: bad details are refused with field errors', async () => {
    const r = await http('POST', OASIS, '/api/license/purchase-request', { body: { organization: '', email: 'nope' } });
    expect(r.status === 400 && r.json.details && r.json.details.errors, `HTTP ${r.status}`);
  });

  // ── 3. The support portal reads what the services stored ─────────────────
  console.log('\nSupport portal');
  const signedIn = await step('Staff sign-in (local test account)', async () => {
    let r = await http('POST', PORTAL, '/v1/admin/auth/login', { body: { email: STAFF_EMAIL, password: STAFF_PASSWORD } });
    if (r.status !== 200) {
      const env = fs.readFileSync(path.join(REPOS, 'oasis-support-portal', '.env'), 'utf8');
      const customer = (env.match(/^PLATFORM_CUSTOMER_ID=(.+)$/m) || [])[1];
      expect(customer, 'PLATFORM_CUSTOMER_ID missing from oasis-support-portal/.env (run stack.sh init)');
      try {
        execFileSync('node', ['--env-file=.env', 'src/staff-cli.js', '--email', STAFF_EMAIL, '--name', 'E2E Tester', '--role', 'PLATFORM_ADMIN', '--customer', customer],
          { cwd: path.join(REPOS, 'oasis-support-portal'), stdio: 'pipe' });
      } catch (_) { /* already exists */ }
      const since = readLog('portal').length;
      await http('POST', PORTAL, '/v1/admin/auth/password/forgot', { body: { email: STAFF_EMAIL } });
      const hit = await waitForLog('portal', new RegExp(`link for ${STAFF_EMAIL.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}: \\S+#/(?:activate|reset)/([A-Za-z0-9_-]+)`), since);
      expect(hit, 'no link in the portal log (is DEV_PRINT_CODES=1 in oasis-support-portal/.env?)');
      const done = await http('POST', PORTAL, '/v1/admin/auth/link/complete', { body: { token: hit[1], newPassword: STAFF_PASSWORD, confirmPassword: STAFF_PASSWORD } });
      expect(done.status === 200, `link/complete HTTP ${done.status} ${done.text.slice(0, 200)}`);
      r = await http('POST', PORTAL, '/v1/admin/auth/login', { body: { email: STAFF_EMAIL, password: STAFF_PASSWORD } });
    }
    expect(r.status === 200 && r.json.token, `login HTTP ${r.status} ${r.text.slice(0, 200)}`);
    ctx.staffToken = r.json.token;
    return STAFF_EMAIL;
  });
  if (signedIn) {
    const listHas = async (route, ref) => {
      const r = await portalAdmin('GET', route);
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 160)}`);
      return r.text.includes(ref);
    };
    await step('Purchase request from OASIS is listed', async () => { expect(await listHas('/purchase-requests?limit=200', ctx.purchaseRef), `${ctx.purchaseRef} not in the list`); });
    await step('Trial started in OASIS is listed', async () => {
      const r = await portalAdmin('GET', '/trials?limit=200');
      expect(r.status === 200, `HTTP ${r.status}`);
      const rows = Array.isArray(r.json) ? r.json : r.json.trials || r.json.items || [];
      expect(rows.length > 0, 'no trials listed');
      return `${rows.length} trial(s)`;
    });

    // ── 4. Support turns the request into a licence ────────────────────────
    console.log('\nIssue a licence, activate it in OASIS');
    await step('Support contacts the buyer, then agrees the request', async () => {
      for (const status of ['CONTACTED', 'AGREED']) {
        const r = await portalAdmin('PATCH', `/purchase-requests/${ctx.purchaseRef}`, { reason: `E2E ${RUN}: ${status.toLowerCase()}`, status });
        expect(r.status === 200, `${status}: HTTP ${r.status} ${r.text.slice(0, 200)}`);
      }
    });
    await step('Portal issues a Viewer + Security licence from the purchase request', async () => {
      const r = await portalAdmin('POST', '/licenses', { reason: `E2E ${RUN}`, purchaseRequest: ctx.purchaseRef, plan: 'viewer-security', seats: 2 });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      ctx.licenceKey = r.json.licenseKey || r.json.licenceKey || r.json.key;
      ctx.licenceId = r.json.licenseId;
      ctx.customerId = r.json.customerId;
      expect(ctx.licenceKey && ctx.licenceId, `answer has no key or id: ${Object.keys(r.json).join(',')}`);
      return `key ending ${String(ctx.licenceKey).slice(-4)}`;
    });
    await step('Portal attaches a verified email domain to the customer', async () => {
      const r = await portalAdmin('POST', '/domains', { reason: `E2E ${RUN}`, customerId: ctx.customerId, domain: DOMAIN });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
    });
    await step('OASIS activates with the key: Security is licensed', async () => {
      const r = await http('POST', OASIS, '/api/license/activate', { body: { licenseKey: ctx.licenceKey } });
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      expect(r.json.tier === 'viewer-security' && !r.json.locked, `tier ${r.json.tier}, tokenError ${r.json.tokenError}`);
      return `${r.json.tierLabel}, ${r.json.seats} seats`;
    });
    await step('Portal shows the seat in use', async () => {
      const r = await portalAdmin('GET', `/licenses/${ctx.licenceId}`);
      expect(r.status === 200, `HTTP ${r.status}`);
      expect(/ACTIVE/i.test(r.text), 'licence is not ACTIVE in the portal');
    });

    // ── 2. Feedback and Contact Support, from OASIS to the support service ───
    console.log('\nOASIS Feedback and Contact Support');
    await step('Contact Support: stored by the support service, reference returned', async () => {
      const r = await http('POST', OASIS, '/api/support', {
        body: { title: `E2E ${RUN}: cannot connect to Jenkins`, description: 'End-to-end test request.', contactName: 'E2E User', email: `user@${DOMAIN}`, idempotencyKey: `e2e-${RUN}-support` },
      });
      expect(r.status === 200 && r.json.reference, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      ctx.supportRef = r.json.reference;
      return ctx.supportRef;
    });
    await step('Contact Support: the same Idempotency-Key does not create a second request', async () => {
      const r = await http('POST', OASIS, '/api/support', {
        body: { title: `E2E ${RUN}: cannot connect to Jenkins`, description: 'End-to-end test request.', contactName: 'E2E User', email: `user@${DOMAIN}`, idempotencyKey: `e2e-${RUN}-support` },
      });
      expect(r.json && r.json.reference === ctx.supportRef, `got ${r.json && r.json.reference}, wanted ${ctx.supportRef}`);
    });
    await step('Contact Support: a missing email is refused with the service\'s field error', async () => {
      const r = await http('POST', OASIS, '/api/support', { body: { title: 'x', description: 'y', contactName: 'E2E User', email: '' } });
      expect(r.status === 400 && r.json.errors && r.json.errors.email, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
    });
    await step('Feedback: stored by the support service, reference returned', async () => {
      const r = await http('POST', OASIS, '/api/feedback', {
        body: { category: 'idea', message: `E2E ${RUN} feedback`, email: `user@${DOMAIN}`, idempotencyKey: `e2e-${RUN}-feedback` },
      });
      expect(r.status === 200 && r.json.reference, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      ctx.feedbackRef = r.json.reference;
      return ctx.feedbackRef;
    });

    await step('Support request from OASIS is listed in the portal', async () => { expect(await listHas('/support-requests?limit=200', ctx.supportRef), `${ctx.supportRef} not in the list`); });
    await step('Feedback from OASIS is listed in the portal', async () => { expect(await listHas('/feedback?limit=200', ctx.feedbackRef), `${ctx.feedbackRef} not in the list`); });

    // ── 5. OASIS and the rule server ───────────────────────────────────────
    console.log('\nOASIS and the rule server');
    await step('Security tab is open and points at the rule server', async () => {
      const r = await http('GET', OASIS, '/api/security/rules/config');
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      expect(r.json.ruleServer && r.json.ruleServer.configured, 'rule server not configured in OASIS');
      expect(r.json.ruleServer.baseUrl.replace('localhost', '127.0.0.1') === RULES, `OASIS uses ${r.json.ruleServer.baseUrl}, not ${RULES}`);
      return r.json.ruleServer.baseUrl;
    });
    await step('Rule server serves rules and a default profile', async () => {
      const rules = await http('GET', RULES, '/api/v1/rules?fields=summary');
      expect(rules.status === 200 && Array.isArray(rules.json) && rules.json.length > 0, `HTTP ${rules.status}, ${rules.json && rules.json.length} rules`);
      return `${rules.json.length} rules`;
    });
    await step('OASIS fetches the rule profile from the rule server', async () => {
      const { createRuleSyncFromEnv } = require('../server/security/rule-sync');
      const rs = createRuleSyncFromEnv({ OASIS_RULE_SERVER_URL: RULES }, { dir: fs.mkdtempSync(path.join(os.tmpdir(), 'e2e-rules-')), log: () => {} });
      const set = await rs.refresh('e2e');
      expect(set.source === 'rule-server' && !set.stale, `source ${set.source}, stale ${set.stale}`);
      return set.version;
    });

    // ── 6. Seat release and activation by email ────────────────────────────
    console.log('\nDeactivate, then activate by email code');
    await step('OASIS deactivates and releases the seat', async () => {
      const r = await http('POST', OASIS, '/api/license/deactivate', { body: {} });
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      const s = await http('GET', OASIS, '/api/license/status');
      expect(s.json.status !== 'active', `status still ${s.json.status}`);
    });
    await step('Email code requested for an address at the customer\'s domain', async () => {
      ctx.logPos = readLog('licence').length;
      const r = await http('POST', OASIS, '/api/license/email-code', { body: { email: `person@${DOMAIN}` } });
      expect(r.status === 200 && r.json.ok, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
    });
    await step('One-time code activates OASIS', async () => {
      const hit = await waitForLog('licence', new RegExp(`one-time code for person@${DOMAIN.replace(/\./g, '\\.')}: (\\d{6})`), ctx.logPos);
      expect(hit, 'code not found in the licence log (is DEV_PRINT_CODES=1?)');
      const r = await http('POST', OASIS, '/api/license/activate-email', { body: { email: `person@${DOMAIN}`, code: hit[1] } });
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      expect(r.json.tier === 'viewer-security' && !r.json.locked, `tier ${r.json.tier}`);
    });
    await step('A wrong code is refused', async () => {
      const r = await http('POST', OASIS, '/api/license/activate-email', { body: { email: `person@${DOMAIN}`, code: '000000' } });
      expect(r.status === 400, `HTTP ${r.status}`);
    });

    // ── 7. Support suspends and reinstates ─────────────────────────────────
    console.log('\nSupport suspends the licence');
    await step('Portal suspends: OASIS is refused at its next check', async () => {
      const s = await portalAdmin('POST', `/licenses/${ctx.licenceId}/suspend`, { reason: `E2E ${RUN}` });
      expect(s.status === 200 || s.status === 201, `suspend HTTP ${s.status} ${s.text.slice(0, 200)}`);
      const r = await http('POST', OASIS, '/api/license/revalidate', { body: {} });
      const st = await http('GET', OASIS, '/api/license/status');
      expect(r.status !== 200 || st.json.locked || st.json.status !== 'active', `OASIS still active: ${st.json.status}`);
      return `OASIS status ${st.json.status}`;
    });
    await step('Portal reinstates: OASIS recovers', async () => {
      const s = await portalAdmin('POST', `/licenses/${ctx.licenceId}/reinstate`, { reason: `E2E ${RUN}` });
      expect(s.status === 200 || s.status === 201, `reinstate HTTP ${s.status} ${s.text.slice(0, 200)}`);
      const r = await http('POST', OASIS, '/api/license/revalidate', { body: {} });
      const st = await http('GET', OASIS, '/api/license/status');
      expect(r.status === 200 && !st.json.locked, `revalidate HTTP ${r.status}, status ${st.json.status}`);
    });

    // ── 7b. Seat limit: a 20-seat licence admits 20 machines and no more ──
    console.log('\nSeat limit');
    const SEATS = 20;
    const machineId = () => require('node:crypto').randomBytes(16).toString('hex');
    // The licence service allows 60 requests a minute per address; wait out a 429 rather than fail on it.
    const activateOn = async (key, m) => {
      for (let i = 0; i < 3; i++) {
        const r = await http('POST', LICENCE, '/v1/activate', { body: { machineId: m, licenseKey: key, appVersion: '2.0.1' } });
        if (r.status !== 429) return r;
        await new Promise(res => setTimeout(res, ((r.json && r.json.retryAfterSeconds) || 30) * 1000 + 500));
      }
      throw new Error('still rate limited after three waits');
    };
    await step(`Issue a ${SEATS}-seat licence`, async () => {
      const r = await portalAdmin('POST', '/licenses', { reason: `E2E ${RUN} seats`, customer: { name: `E2E Seats ${RUN}` }, plan: 'viewer-security', seats: SEATS });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      ctx.seatKey = r.json.licenseKey || r.json.licenceKey || r.json.key;
      expect(ctx.seatKey && r.json.seats === SEATS, `seats ${r.json.seats}`);
    });
    await step(`${SEATS + 2} machines at once: ${SEATS} are seated, 2 are refused with seats_full`, async () => {
      ctx.seatMachines = Array.from({ length: SEATS + 2 }, machineId);
      const rs = await Promise.all(ctx.seatMachines.map(m => activateOn(ctx.seatKey, m)));
      ctx.seated = ctx.seatMachines.filter((_, i) => rs[i].status === 200);
      ctx.refused = ctx.seatMachines.filter((_, i) => rs[i].status !== 200);
      ctx.seatTokens = Object.fromEntries(ctx.seated.map(m => [m, rs[ctx.seatMachines.indexOf(m)].json.token]));
      const bad = rs.filter(r => r.status !== 200 && !(r.status === 403 && r.json.reason === 'seats_full'));
      expect(ctx.seated.length === SEATS, `${ctx.seated.length} machines were seated`);
      expect(!bad.length, `unexpected refusal ${bad[0] && bad[0].text.slice(0, 200)}`);
      return `${ctx.seated.length} seated, ${ctx.refused.length} refused`;
    });
    await step('A machine that already holds a seat can activate again; a refused one stays refused', async () => {
      expect((await activateOn(ctx.seatKey, ctx.seated[0])).status === 200, 'seated machine was refused');
      const r = await activateOn(ctx.seatKey, ctx.refused[0]);
      expect(r.status === 403 && r.json.reason === 'seats_full', `HTTP ${r.status} ${r.text.slice(0, 200)}`);
    });
    await step('A freed seat goes to the next machine, and the cap holds at 20', async () => {
      const d = await http('POST', LICENCE, '/v1/deactivate', { body: { machineId: ctx.seated[1], token: ctx.seatTokens[ctx.seated[1]] } });
      expect(d.status === 200, `deactivate HTTP ${d.status} ${d.text.slice(0, 200)}`);
      expect((await activateOn(ctx.seatKey, ctx.refused[0])).status === 200, 'the freed seat was not given');
      const r = await activateOn(ctx.seatKey, ctx.refused[1]);
      expect(r.status === 403 && r.json.reason === 'seats_full', `21st machine: HTTP ${r.status} ${r.text.slice(0, 200)}`);
    });

    // ── 7c. Trial, support actions and seat changes, on the licence service ─
    // These use machine ids of their own, so they do not touch this machine's licence.
    const licPost = async (route, body) => {
      for (let i = 0; i < 3; i++) {
        const r = await http('POST', LICENCE, `/v1${route}`, { body });
        if (r.status !== 429) return r;
        await new Promise(res => setTimeout(res, ((r.json && r.json.retryAfterSeconds) || 30) * 1000 + 500));
      }
      throw new Error('still rate limited after three waits');
    };
    const claims = token => JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString());
    const issueFor = async (label, plan, seats) => {
      const r = await portalAdmin('POST', '/licenses', { reason: `E2E ${RUN} ${label}`, customer: { name: `E2E ${label} ${RUN}` }, plan, seats });
      expect(r.status === 201, `issue HTTP ${r.status} ${r.text.slice(0, 200)}`);
      return { id: r.json.licenseId, key: r.json.licenceKey, hint: String(r.json.licenceKey).slice(-4) };
    };

    console.log('\nTrial on the licence service');
    await step('A new machine gets a 7-day trial token; asking again returns the original expiry', async () => {
      ctx.trialMachine = machineId();
      const a = await licPost('/trial', { machineId: ctx.trialMachine, appVersion: '2.0.1' });
      expect(a.status === 200 && claims(a.json.token).tier === 'trial', `HTTP ${a.status} ${a.text.slice(0, 200)}`);
      const days = (claims(a.json.token).exp - Date.now()) / 864e5;
      expect(days > 6.9 && days <= 7.01, `trial is ${days.toFixed(2)} days`);
      const b = await licPost('/trial', { machineId: ctx.trialMachine, appVersion: '2.0.1' });
      expect(claims(b.json.token).exp === claims(a.json.token).exp, 'a second request moved the expiry');
      ctx.trialToken = a.json.token;
    });
    await step('The trial revalidates; another machine, or a tampered token, is refused', async () => {
      expect((await licPost('/revalidate', { machineId: ctx.trialMachine, token: ctx.trialToken })).status === 200, 'own trial did not revalidate');
      const other = await licPost('/revalidate', { machineId: machineId(), token: ctx.trialToken });
      expect(other.status === 403, `another machine: HTTP ${other.status}`);
      const forged = await licPost('/revalidate', { machineId: ctx.trialMachine, token: `${ctx.trialToken.slice(0, -4)}AAAA` });
      expect(forged.status >= 400 && forged.status < 500, `tampered token: HTTP ${forged.status}`);
    });
    await step('Activating a licence from a trial machine converts the trial', async () => {
      const lic = await issueFor('Trial', 'team', 2);
      const a = await licPost('/activate', { machineId: ctx.trialMachine, licenseKey: lic.key, appVersion: '2.0.1' });
      expect(a.status === 200 && claims(a.json.token).tier === 'team', `HTTP ${a.status} ${a.text.slice(0, 200)}`);
      expect((await licPost('/revalidate', { machineId: ctx.trialMachine, token: a.json.token })).status === 200, 'licence did not revalidate');
      expect((await licPost('/activate', { machineId: machineId(), licenseKey: 'OASIS-AAAA-BBBB-CCCC' })).status === 400, 'an unknown key was not refused');
    });

    console.log('\nSupport actions: suspend, revoke, seats, extend');
    await step('Suspend refuses revalidation and new activations; reinstate restores them', async () => {
      const lic = await issueFor('Suspend', 'team', 2);
      const m = machineId();
      const token = (await licPost('/activate', { machineId: m, licenseKey: lic.key })).json.token;
      expect(token, 'first activation failed');
      expect((await portalAdmin('POST', `/licenses/${lic.id}/suspend`, { reason: `E2E ${RUN}` })).status < 300, 'suspend failed');
      const rv = await licPost('/revalidate', { machineId: m, token });
      expect(rv.status === 403 && rv.json.reason === 'suspended', `revalidate: HTTP ${rv.status} ${rv.json.reason}`);
      const act = await licPost('/activate', { machineId: machineId(), licenseKey: lic.key });
      expect(act.status === 403 && act.json.reason === 'suspended', `activate: HTTP ${act.status} ${act.json.reason}`);
      expect((await portalAdmin('POST', `/licenses/${lic.id}/reinstate`, { reason: `E2E ${RUN}` })).status < 300, 'reinstate failed');
      expect((await licPost('/revalidate', { machineId: m, token })).status === 200, 'did not recover after reinstate');
    });
    await step('Seat changes: never below the seats in use, and the new limit applies at once', async () => {
      const lic = await issueFor('Seats', 'viewer-security', 3);
      const [a, b, c] = [machineId(), machineId(), machineId()];
      await licPost('/activate', { machineId: a, licenseKey: lic.key });
      await licPost('/activate', { machineId: b, licenseKey: lic.key });
      const change = body => portalAdmin('POST', `/licenses/${lic.id}/change`, { reason: `E2E ${RUN}`, ...body });
      let r = await change({ seats: 1 });
      expect(r.status === 409 && r.json.reason === 'seats_in_use', `cut to 1: HTTP ${r.status} ${r.json.reason}`);
      expect((await change({ seats: 2 })).status === 200, 'could not drop to the seats in use');
      r = await licPost('/activate', { machineId: c, licenseKey: lic.key });
      expect(r.status === 403 && r.json.reason === 'seats_full', `third machine at limit 2: HTTP ${r.status} ${r.json.reason}`);
      expect((await change({ seats: 5 })).status === 200, 'could not raise seats');
      expect((await licPost('/activate', { machineId: c, licenseKey: lic.key })).status === 200, 'third machine not admitted after raise');
      r = await change({ seats: null });
      expect(r.status === 400 || r.status === 409, `unlimited on a non-enterprise licence: HTTP ${r.status}`);
      r = await portalAdmin('POST', `/licenses/${lic.id}/extend`, { reason: `E2E ${RUN}`, days: 30 });
      expect(r.status === 200, `extend: HTTP ${r.status} ${r.text.slice(0, 150)}`);
    });
    await step('Revoke needs the key\'s last four characters, frees every seat, and cannot be undone', async () => {
      const lic = await issueFor('Revoke', 'viewer-security', 3);
      const m = machineId();
      const token = (await licPost('/activate', { machineId: m, licenseKey: lic.key })).json.token;
      await licPost('/activate', { machineId: machineId(), licenseKey: lic.key });
      const revoke = body => portalAdmin('POST', `/licenses/${lic.id}/revoke`, { reason: `E2E ${RUN}`, ...body });
      let r = await revoke({});
      expect(r.status === 400 && r.json.reason === 'confirmation_required', `no confirm: HTTP ${r.status} ${r.json.reason}`);
      expect((await revoke({ confirm: 'XXXX' })).status === 400, 'a wrong confirm was accepted');
      r = await revoke({ confirm: lic.hint });
      expect(r.status === 200 && r.json.seatsReleased === 2, `revoke: HTTP ${r.status}, seats released ${r.json.seatsReleased}`);
      r = await licPost('/revalidate', { machineId: m, token });
      expect(r.status === 403 && r.json.reason === 'revoked', `revalidate: HTTP ${r.status} ${r.json.reason}`);
      expect((await licPost('/activate', { machineId: machineId(), licenseKey: lic.key })).status === 403, 'a revoked key activated');
      expect((await portalAdmin('POST', `/licenses/${lic.id}/reinstate`, { reason: `E2E ${RUN}` })).status >= 400, 'a revoked licence was reinstated');
    });
    await step('The portal admin API refuses a call with no login', async () => {
      const r = await http('POST', PORTAL, '/v1/admin/licenses', { body: { reason: 'x', customer: { name: 'x' }, plan: 'team', seats: 1 } });
      expect(r.status === 401, `HTTP ${r.status}`);
    });

    // ── 8. Invoicing: the portal and the billing service ───────────────────
    console.log('\nInvoicing');
    const inv = id => `/invoices/${id}`;
    const onBilling = url => url.replace(/^https?:\/\/[^/]+/, BILLING);      // the link names PUBLIC_BASE_URL; reach it where this run can
    await step('Portal pre-fills an invoice from the purchase request (customer, plan, seats)', async () => {
      const r = await portalAdmin('GET', `/purchase-requests/${ctx.purchaseRef}/invoice-draft`);
      expect(r.status === 200, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      expect(r.json.customerId === ctx.customerId, 'the draft is for another customer');
      expect(r.json.lines[0].unitPriceMinor === null, 'the price should be left for staff');
      ctx.draft = r.json;
      return `${r.json.lines[0].quantity} seats`;
    });
    await step('Staff create the invoice: one price line and one discount line', async () => {
      const d = ctx.draft, qty = Number(d.lines[0].quantity);
      const r = await portalAdmin('POST', '/invoices', { customerId: d.customerId, sourcePurchaseRequestId: d.sourcePurchaseRequestId, billTo: { name: ORG, line1: '1 Example Road', city: 'Pune', countryCode: 'IN' },
        lines: [{ description: d.lines[0].description, quantity: qty, unitPriceMinor: 40000 }, { description: 'Early-payment discount', quantity: 1, unitPriceMinor: -10000 }], dueOn: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10) });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 300)}`);
      ctx.invoiceId = r.json.invoice.invoiceId; ctx.invoiceTotal = qty * 40000 - 10000;
      expect(r.json.invoice.totalMinor === ctx.invoiceTotal && r.json.invoice.status === 'DRAFT', `total ${r.json.invoice.totalMinor}, status ${r.json.invoice.status}`);
    });
    await step('Issue gives it an INV number; the owner is the person who created it', async () => {
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/issue`, {});
      expect(r.status === 200 && /^INV-\d{4}-\d{6}$/.test(r.json.invoice.invoiceNumber), `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      ctx.invoiceNumber = r.json.invoice.invoiceNumber;
      return ctx.invoiceNumber;
    });
    await step('A secure link opens the invoice for the customer, with no login', async () => {
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/links`, { days: 7 });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      ctx.link = r.json.link;
      const page = await http('GET', BILLING, new URL(onBilling(ctx.link.url)).pathname);
      expect(page.status === 200 && page.text.includes(ctx.invoiceNumber) && page.text.includes(ORG), `HTTP ${page.status}`);
    });
    await step('A partial payment gives a receipt, and the customer page shows it', async () => {
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/payments`, { amountMinor: 30000, method: 'bank_transfer', reference: `E2E-${RUN}` });
      expect(r.status === 201 && /^RCT-\d{4}-\d{6}$/.test(r.json.payment.receiptNumber), `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      expect(r.json.invoice.status !== 'PAID' && r.json.invoice.balanceMinor === ctx.invoiceTotal - 30000, 'the invoice should still be open');
      const page = await http('GET', BILLING, new URL(onBilling(ctx.link.url)).pathname);
      expect(page.text.includes(r.json.payment.receiptNumber), 'the receipt is not on the customer page');
      expect(!page.text.includes(`E2E-${RUN}`), 'the payment reference must not be on the customer page');
    });
    await step('Staff log a follow-up; the queue and the bell summary count it', async () => {
      const next = new Date().toISOString().slice(0, 10);      // today as the billing database sees it (UTC by default): a follow-up due TODAY is what puts the invoice in the queue
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/follow-ups`, { channel: 'call', outcome: 'Finance office will pay the rest', nextFollowUpOn: next });
      expect(r.status === 201, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      const q = await portalAdmin('GET', '/invoice-follow-ups/queue');
      expect(q.status === 200 && q.text.includes(ctx.invoiceId), 'the invoice is not in the queue');
      const s = await portalAdmin('GET', '/invoice-follow-ups/summary?mine=1');
      expect(s.status === 200 && s.json.followUpsDue >= 1, `summary ${s.text.slice(0, 100)}`);
    });
    await step('The final payment marks it PAID; the Billing screen counts it', async () => {
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/payments`, { amountMinor: ctx.invoiceTotal - 30000, method: 'po' });
      expect(r.status === 201 && r.json.invoice.status === 'PAID' && r.json.invoice.closedAt, `HTTP ${r.status} ${r.text.slice(0, 200)}`);
      const d = await portalAdmin('GET', '/billing/dashboard');
      expect(d.status === 200 && d.json.tiles.PAID.count >= 1 && d.json.byOwner.some(o => o.closedCount >= 1), `dashboard ${d.text.slice(0, 200)}`);
    });
    await step('Revoking the link turns the customer away; the CSV export lists the invoice', async () => {
      const r = await portalAdmin('POST', `${inv(ctx.invoiceId)}/links/${ctx.link.linkId}/revoke`, {});
      expect(r.status === 200, `HTTP ${r.status}`);
      const page = await http('GET', BILLING, new URL(onBilling(ctx.link.url)).pathname);
      expect(page.status === 404 && /no longer valid/i.test(page.text), `HTTP ${page.status}`);
      const csv = await portalAdmin('GET', '/billing/export.csv?status=PAID');
      expect(csv.status === 200 && csv.text.includes(ctx.invoiceNumber), 'the invoice is not in the export');
    });
  }

  finish();
}

function finish() {
  const failed = results.filter(r => !r.ok);
  const skipped = results.filter(r => r.skipped).length;
  console.log(`\n${results.length - failed.length - skipped} passed, ${failed.length} failed, ${skipped} skipped\n`);
  process.exitCode = failed.length ? 1 : 0;
}

main().catch(err => { console.error(err); process.exit(2); });
