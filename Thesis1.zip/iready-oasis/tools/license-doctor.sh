#!/bin/bash
# Diagnoses "Could not reach the licence service".
#
# There are only a few links in the chain and this checks each one, because
# they all surface as the same message in the UI.
#
#   bash tools/license-doctor.sh [app-port] [service-port]

APP_PORT="${1:-3000}"
LS_PORT="${2:-4020}"   # 4020 = oasis-licence-service (routes under /v1); 4010 = the legacy stand-in, tools/license-service-dev.js
ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; }
bad()  { printf "  \033[31m✗\033[0m %s\n" "$1"; }
info() { printf "    %s\n" "$1"; }

echo
echo "1. Is a licence service running on :$LS_PORT ?"
# The real service answers /healthz; the legacy stand-in answers /admin/state.
if curl -sf -m 2 "http://localhost:$LS_PORT/healthz" >/dev/null 2>&1 || curl -sf -m 2 "http://localhost:$LS_PORT/admin/state" >/dev/null 2>&1; then
  ok "yes"
else
  bad "no — nothing is listening on :$LS_PORT"
  info "Start it:  tools/oasis-services.sh restart licence   (or the legacy stand-in:  node tools/license-service-dev.js, port 4010)"
fi

echo
echo "2. Is OASIS running on :$APP_PORT ?"
if curl -sf -m 2 "http://localhost:$APP_PORT/api/health" >/dev/null 2>&1; then
  ok "yes"
else
  bad "no — nothing is listening on :$APP_PORT"
  info "Start it:  OASIS_LICENSE_URL=http://localhost:$LS_PORT/v1 npm start"
  echo; exit 1
fi

echo
echo "3. Is licensing enabled in that OASIS process?"
STATUS=$(curl -s -m 2 "http://localhost:$APP_PORT/api/license/status")
if echo "$STATUS" | head -c 20 | grep -q '<!DOCTYPE'; then
  bad "no — the licence API is not mounted, so enforcement is off"
  info "You started OASIS without OASIS_LICENSE_URL or OASIS_LICENSE_ENABLED=1."
  info "Restart it:  OASIS_LICENSE_URL=http://localhost:$LS_PORT/v1 npm start"
  echo; exit 1
fi
ok "yes"

echo
echo "4. Which licence service is OASIS configured to call?"
CONFIGURED=$(echo "$STATUS" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).serviceUrl||'')}catch(e){console.log('')}})")
if [ -z "$CONFIGURED" ]; then
  bad "the running build predates serviceUrl reporting — restart OASIS"
elif echo "$CONFIGURED" | grep -q '\.invalid'; then
  bad "$CONFIGURED"
  info "This is the placeholder host. OASIS was started with OASIS_LICENSE_ENABLED=1"
  info "but no OASIS_LICENSE_URL, so trial and activation can never succeed."
  info "Restart it:  OASIS_LICENSE_URL=http://localhost:$LS_PORT/v1 npm start"
elif [ "$CONFIGURED" != "http://localhost:$LS_PORT/v1" ] && [ "$CONFIGURED" != "http://localhost:$LS_PORT" ]; then
  bad "$CONFIGURED  (expected http://localhost:$LS_PORT/v1)"
  info "OASIS is pointed somewhere other than the service checked in step 1."
else
  ok "$CONFIGURED"
fi

echo
echo "5. Can OASIS actually complete a trial request?"
BODY=$(curl -s -m 5 -X POST -H 'content-type: application/json' -d '{}' "http://localhost:$APP_PORT/api/license/trial")
CODE=$(curl -s -m 5 -o /dev/null -w '%{http_code}' -X POST -H 'content-type: application/json' -d '{}' "http://localhost:$APP_PORT/api/license/trial")
case "$CODE" in
  200) ok "yes — $(echo "$BODY" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{const j=JSON.parse(d);console.log(j.status+', '+j.daysRemaining+' days left')})")" ;;
  503) bad "503 unreachable — $(echo "$BODY" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).message)}catch(e){console.log('')}})")"
       info "OASIS is running and licensing is on, but it cannot reach the service above." ;;
  400) bad "400 rejected — $(echo "$BODY" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).message)}catch(e){console.log('')}})")"
       info "The service answered and refused. Not a connectivity problem." ;;
  *)   bad "unexpected HTTP $CODE" ;;
esac

echo
echo "Current state:"
# Re-fetched rather than reusing step 3's copy — step 5 starts a trial when it
# succeeds, so the earlier snapshot is already out of date by this point.
curl -s -m 2 "http://localhost:$APP_PORT/api/license/status" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{const j=JSON.parse(d);
console.log('  status    '+j.status+(j.locked?'  (LOCKED)':''));
console.log('  machine   '+(j.machineId||'').slice(0,12));
console.log('  service   '+(j.serviceUrl||'—'));})"
echo