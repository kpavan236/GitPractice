'use strict';
const crypto = require('crypto');

// Decides whether a NEW trial deserves a human look. It never refuses one.
//
// The fingerprint is what stops a reinstall restarting a trial, and where the
// platform exposes no hardware id it falls back to hostname and home directory
// (server/licensing/fingerprint.js) — both things a user can change. Rather
// than pretend the fingerprint is airtight, the service marks the trials most
// likely to be repeats and leaves the decision to a person. Refusing outright
// would lock out a school computer lab where fifty machines share one address.
//
// Two signals:
//   weak_fingerprint            the id came from the fallback, or the app did
//                               not say where it came from
//   many_first_trials_from_one_source   more than `maxPerSource` first trials
//                               from the same source inside `windowMs`
//
// Privacy: the source (the caller's address) is held only as a hash made with a
// salt that exists only in this process, and only until its window passes.
// Nothing here is persisted, so an address is never written to disk and cannot
// be matched against a hash from an earlier run.

const WEAK_FINGERPRINT = 'weak_fingerprint';
const MANY_FROM_ONE_SOURCE = 'many_first_trials_from_one_source';

function createTrialReviewer({ now = Date.now, windowMs = 24 * 60 * 60 * 1000, maxPerSource = 3 } = {}) {
  const salt = crypto.randomBytes(16);
  const seen = new Map(); // salted hash -> timestamps of first trials in the window

  const keyFor = source => crypto.createHash('sha256').update(salt).update(String(source || '')).digest('hex').slice(0, 24);

  function prune(t) {
    for (const [key, stamps] of seen) {
      const kept = stamps.filter(s => t - s < windowMs);
      if (kept.length) seen.set(key, kept); else seen.delete(key);
    }
  }

  // Call once per NEW trial (a machine already known is not a new trial).
  function review({ source, fingerprintSource } = {}) {
    const t = now();
    prune(t);
    const reasons = [];
    if (!fingerprintSource || fingerprintSource === 'fallback') reasons.push(WEAK_FINGERPRINT);
    const key = keyFor(source);
    const stamps = seen.get(key) || [];
    if (stamps.length >= maxPerSource) reasons.push(MANY_FROM_ONE_SOURCE);
    seen.set(key, [...stamps, t]);
    return { flagged: reasons.length > 0, reasons };
  }

  return { review, heldKeys: () => [...seen.keys()] };
}

module.exports = { createTrialReviewer, WEAK_FINGERPRINT, MANY_FROM_ONE_SOURCE };
