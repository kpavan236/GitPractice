'use strict';
// The four sample-data files describe one story with shared ids. This checks, without a database, that
// every id one file points at in another database really is created there, and that the data is invented.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..', 'docs', 'superpowers', 'db');
const seed = (db) => fs.readFileSync(path.join(ROOT, db, '003_seed_dev_data.sql'), 'utf8');
const ids = (text, prefix) => new Set(text.match(new RegExp(`${prefix}0000000-0000-0000-0000-[0-9a-f]{12}`, 'g')) || []);

test('every customer id used by another seed exists in the customer seed', () => {
  const known = ids(seed('customer'), '1');
  for (const db of ['identity', 'license', 'billing']) {
    for (const id of ids(seed(db), '1')) assert.ok(known.has(id), `${db} seed uses customer ${id}, which the customer seed never creates`);
  }
});

test('every user id used by another seed exists in the identity seed', () => {
  const known = ids(seed('identity'), '2');
  for (const db of ['customer', 'license', 'billing']) {
    for (const id of ids(seed(db), '2')) assert.ok(known.has(id), `${db} seed uses user ${id}, which the identity seed never creates`);
  }
});

test('billing points only at licences the licence seed creates', () => {
  const known = ids(seed('license'), '3');
  for (const id of ids(seed('billing'), '3')) assert.ok(known.has(id), `billing seed uses licence ${id}`);
});

test('sample data uses only reserved example addresses and no phone numbers', () => {
  for (const db of ['customer', 'identity', 'license', 'billing']) {
    const text = seed(db);
    for (const email of text.match(/[\w.+-]+@[\w.-]+/g) || []) assert.match(email, /\.(example\.test|test)$/, `${db}: ${email} is not an invented address`);
    assert.doesNotMatch(text, /phone/i, `${db} seed mentions a phone`);
  }
});

test('each seed is guarded so a second run does nothing', () => {
  for (const db of ['customer', 'identity', 'license', 'billing']) {
    const text = seed(db);
    assert.match(text, /\\gset/);
    assert.match(text, /\\if :fresh/);
    assert.match(text, /already loaded/);
  }
});
