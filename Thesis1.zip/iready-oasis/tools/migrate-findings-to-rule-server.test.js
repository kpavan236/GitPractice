'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const store = require('../server/security/store');
const { planMigration, runMigration } = require('./migrate-findings-to-rule-server');

const finding = (fp, repo, status = 'OPEN', extra = {}) => ({ id: `F-${fp}`, fingerprint: fp, repository: repo, type: 'SAST', severity: 'HIGH', status, ...extra });

function localStore(t, data) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-migrate-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const full = { ...store.EMPTY, ...data };
  store.save(full, dir);
  return dir;
}
const data = () => ({
  findings: [finding('a', 'org/a'), finding('b', 'org/a', 'SUPPRESSED', { suppression: { reason: 'r' } }), finding('c', 'org/b', 'RESOLVED')],
  history: [{ at: 1, total: 2, counts: { HIGH: 2 }, byType: { SAST: 2 }, repositories: 2 }],
  baseline: { createdAt: 5, fingerprints: ['a'] },
});
const fakeClient = (existing = []) => {
  const calls = [];
  const options = [];
  return {
    calls, options,
    listFindings: async () => existing,
    importBulk: async (p, o = {}) => { calls.push(p); options.push(o); return { findings: p.findings.length, history: p.history.length, inserted: p.findings.length, adopted: 0, skipped: 0 }; },
  };
};

test('the plan counts what would move, by status and repository', (t) => {
  const plan = planMigration(store.load(localStore(t, data())));
  assert.equal(plan.findings, 3);
  assert.deepEqual(plan.byStatus, { OPEN: 1, SUPPRESSED: 1, RESOLVED: 1 });
  assert.deepEqual(plan.repositories.sort(), ['org/a', 'org/b']);
  assert.equal(plan.history, 1);
  assert.equal(plan.baseline, true);
});

test('a dry run reads and reports but sends nothing', async (t) => {
  const client = fakeClient();
  const result = await runMigration({ dir: localStore(t, data()), client, apply: false, log: () => {} });
  assert.equal(result.applied, false);
  assert.equal(result.plan.findings, 3);
  assert.deepEqual(client.calls, []);
});

test('--apply sends every finding with its triage and every history point in one import', async (t) => {
  const client = fakeClient();
  const result = await runMigration({ dir: localStore(t, data()), client, apply: true, log: () => {} });
  assert.equal(result.applied, true);
  assert.equal(client.calls.length, 1);
  const sent = client.calls[0];
  assert.equal(sent.findings.length, 3);
  assert.equal(sent.findings.find(f => f.fingerprint === 'b').suppression.reason, 'r');
  assert.equal(sent.findings.find(f => f.fingerprint === 'c').status, 'RESOLVED');
  assert.equal(sent.history.length, 1);
  assert.deepEqual([result.imported.findings, result.imported.history], [3, 1]);
});

test('it refuses when the server already holds findings, unless forced', async (t) => {
  const dir = localStore(t, data());
  await assert.rejects(runMigration({ dir, client: fakeClient([finding('z', 'org/z')]), apply: true, log: () => {} }), /already holds findings/);
  const client = fakeClient([finding('z', 'org/z')]);
  const forced = await runMigration({ dir, client, apply: true, force: true, log: () => {} });
  assert.equal(forced.applied, true);
  assert.equal(client.calls.length, 1);
});

test('it never changes or deletes the local store', async (t) => {
  const dir = localStore(t, data());
  const file = store.storePath(dir);
  const before = fs.readFileSync(file, 'utf8');
  await runMigration({ dir, client: fakeClient(), apply: true, log: () => {} });
  assert.equal(fs.readFileSync(file, 'utf8'), before);
});

test('an empty local store has nothing to migrate and sends nothing even with --apply', async (t) => {
  const client = fakeClient();
  const result = await runMigration({ dir: localStore(t, {}), client, apply: true, log: () => {} });
  assert.equal(result.applied, false);
  assert.match(result.reason, /nothing to migrate/i);
  assert.deepEqual(client.calls, []);
});

test('findings the server could not use (no repository or fingerprint) are reported in the plan and skipped, not allowed to sink the import', async (t) => {
  const bad = [finding('x', undefined), { id: 'F-nofp', repository: 'org/a' }];
  const dir = localStore(t, { ...data(), findings: [...data().findings, ...bad] });
  const plan = planMigration(store.load(dir));
  assert.equal(plan.invalid, 2);
  assert.equal(plan.findings, 3, 'only usable findings count toward the migration');
  const client = fakeClient();
  const result = await runMigration({ dir, client, apply: true, log: () => {} });
  assert.equal(client.calls.flatMap(c => c.findings).length, 3);
  assert.equal(result.plan.invalid, 2);
});

test('a large store is sent in batches, with history and the baseline only on the last one', async (t) => {
  const many = Array.from({ length: 5 }, (_, i) => finding(`f${i}`, 'org/a'));
  const client = fakeClient();
  await runMigration({ dir: localStore(t, { ...data(), findings: many }), client, apply: true, batchSize: 2, log: () => {} });
  assert.deepEqual(client.calls.map(c => c.findings.length), [2, 2, 1]);
  assert.deepEqual(client.calls.map(c => c.history.length), [0, 0, 1]);
  assert.deepEqual(client.calls.map(c => !!c.baseline), [false, false, true]);
});

test('--merge keeps what the server already knows and brings the old triage across', async (t) => {
  const dir = localStore(t, data());
  const client = fakeClient([finding('z', 'org/z')]);
  await assert.rejects(runMigration({ dir, client, apply: true, log: () => {} }), /--merge/);
  const result = await runMigration({ dir, client, apply: true, merge: true, log: () => {} });
  assert.equal(result.applied, true);
  assert.ok(client.options.every(o => o.mode === 'merge'));
  assert.equal(client.calls.length, 1);
});
