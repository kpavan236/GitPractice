#!/usr/bin/env node
'use strict';
// A stand-in for the licence service, for local testing only.
//
// The real service is sub-project 2 and does not exist. Without something
// answering /trial and /activate, those buttons can only ever fail — this is
// the smallest thing that makes the full loop clickable: start a trial, let it
// expire, activate a key, run out of seats, revoke, renew.
//
// It is NOT the licence service. No auth, no database, no payment, no
// durability beyond a JSON file, and it hands out licences to anyone who asks
// for one. It lives in tools/ so electron-builder never packages it.
//
//   node tools/license-service-dev.js
//   OASIS_LICENSE_URL=http://localhost:4010 npm start
//
// Signing uses the private key matching the development public key the app
// verifies with — by default ~/.oasis-license-dev/private.pem.

const express = require('express');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { signToken, verifyToken } = require('../server/licensing/token');
const { getTier } = require('../server/licensing/tiers');
const { parseRequestCode } = require('../server/licensing/offline-request');
const { DEV_KID } = require('../server/licensing/keys');
const { createTrialReviewer } = require('./trial-review');
const { sanitizeIntegration } = require('../server/licensing/integration');
const { cleanIdempotencyKey, normaliseEmail, domainOf, validatePurchaseRequest } = require('../server/licensing/forms');
const { createOtpStore } = require('./otp-store');

const DAY = 86400000;
const PORT = Number(process.env.LICENSE_SERVICE_PORT || 4010);
const KEY_PATH = process.env.OASIS_LICENSE_PRIVATE_KEY || path.join(os.homedir(), '.oasis-license-dev', 'private.pem');
const DB_PATH = process.env.LICENSE_SERVICE_DB || path.join(os.homedir(), '.oasis-license-dev', 'service-db.json');

let PRIVATE_KEY;
let PUBLIC_KEY;
try {
  PRIVATE_KEY = fs.readFileSync(KEY_PATH, 'utf8');
  PUBLIC_KEY = require('crypto')
    .createPublicKey(PRIVATE_KEY)
    .export({ type: 'spki', format: 'pem' });
} catch (_) {
  console.error(`No usable signing key at ${KEY_PATH}. See tools/license-dev.js for how to generate one.`);
  process.exit(1);
}

// Keys you can type into the activation screen. A real service would issue
// these at checkout; here they are fixtures, one per tier.
const SEED_LICENSES = {
  'OASIS-INDV-0001-0001': { tier: 'individual', customer: 'Solo Developer' },
  'OASIS-VIEW-0001-0001': { tier: 'viewer', customer: 'Hooli Platform Team' },
  'OASIS-VWSC-0001-0001': { tier: 'viewer-security', customer: 'Hooli AppSec' },
  'OASIS-TEAM-0001-0001': { tier: 'team', customer: 'Globex Corporation' },
  'OASIS-ENTR-0001-0001': { tier: 'enterprise', customer: 'Initech Holdings' },
  // Deliberately small, so seat exhaustion is reachable with two machines.
  'OASIS-TEAM-TINY-0002': { tier: 'team', customer: 'Two Seat Co', seats: 2 },
};

function loadDb() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (_) {
    return { trials: {}, licenses: {}, activations: {}, domains: {}, purchaseRequests: [] };
  }
}

function saveDb(db) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function license(db, key) {
  if (db.licenses[key]) return db.licenses[key];
  const seed = SEED_LICENSES[key];
  if (!seed) return null;
  const tier = getTier(seed.tier);
  db.licenses[key] = {
    licenseId: `lic_${key.slice(-4)}`,
    tier: seed.tier,
    customer: seed.customer,
    seats: seed.seats !== undefined ? seed.seats : tier.seats,
    exp: Date.now() + tier.termDays * DAY,
    revoked: false,
  };
  return db.licenses[key];
}

// Organisations whose COMPANY holds a licence, found by the domain of the email address given in
// "Activate licence". Fixtures for trying every case: use anything@<domain>. Support adds real
// ones with POST /admin/domain-license (the screen for that is later work).
const SEED_DOMAINS = {
  'acme.example.test':    { tier: 'team', customer: 'Acme Example Ltd', seats: 10, days: 365 },
  'expired.example.test': { tier: 'team', customer: 'Expired Example Ltd', seats: 10, days: -30 },
  'tiny.example.test':    { tier: 'team', customer: 'Tiny Example Co', seats: 1, days: 365 },
};

function domainLicense(db, domain) {
  db.domains = db.domains || {};
  const key = db.domains[domain];
  if (key && db.licenses[key]) return { key, record: db.licenses[key] };
  const seed = SEED_DOMAINS[domain];
  if (!seed) return null;
  const k = `DOMAIN:${domain}`;
  db.licenses[k] = {
    licenseId: `lic_dom_${domain.split('.')[0]}`, tier: seed.tier, customer: seed.customer,
    seats: seed.seats, exp: Date.now() + seed.days * DAY, revoked: false,
  };
  db.domains[domain] = k;
  saveDb(db);
  return { key: k, record: db.licenses[k] };
}

// A machine takes a seat on a licence. Returns null on success, or the reason it cannot.
// (An enterprise site licence has seats === null and is uncounted by design.)
function bindSeat(db, licenseKey, record, machineId) {
  const seats = db.activations[licenseKey] || [];
  if (!seats.includes(machineId)) {
    if (record.seats !== null && seats.length >= record.seats) return `All ${record.seats} seats on this licence are in use.`;
    seats.push(machineId);
    db.activations[licenseKey] = seats;
    saveDb(db);
  }
  console.log(`    → ${record.tier} activated, ${seats.length}/${record.seats === null ? '∞' : record.seats} seats`);
  return null;
}

const maskEmail = e => e.replace(/^(.)[^@]*(@.*)$/, '$1***$2');
const fmtDate = ms => new Date(ms).toISOString().slice(0, 10);

function issue(record, extra = {}) {
  const tier = getTier(record.tier);
  const now = Date.now();
  return signToken(
    {
      licenseId: record.licenseId,
      tier: record.tier,
      customer: record.customer,
      seats: record.seats,
      features: tier.features,
      issuedAt: now,
      exp: record.exp,
      graceUntil: now + tier.graceDays * DAY,
      ...extra,
    },
    PRIVATE_KEY,
    { kid: DEV_KID }
  );
}

function reject(res, message, code = 400, extra = {}) {
  return res.status(code).json({ error: 'rejected', message, ...extra });
}

const trialReviewer = createTrialReviewer();
// keepForDev: this stand-in has no mailbox, so it can show a code (in ITS console, and to /admin/last-otp).
let otpStore = createOtpStore({ keepForDev: true });

const app = express();
app.use(express.json());

app.use((req, _res, next) => {
  console.log(`  ${req.method} ${req.path}`, JSON.stringify(req.body || {}).slice(0, 120));
  next();
});

// The anti-reset rule, and the reason trials are server-issued at all: a
// fingerprint we have seen before gets its ORIGINAL expiry back, so uninstall,
// reinstall, and deleting ~/.oasis-license.json buy nothing.
app.post('/trial', (req, res) => {
  const { machineId, platform, arch, appVersion, fingerprintSource, integration } = req.body || {};
  if (!machineId) return reject(res, 'machineId is required');

  const db = loadDb();
  const now = Date.now();
  let trial = db.trials[machineId];
  if (!trial) {
    // Term comes from the tier catalogue so the service and the app can never
    // disagree about how long a trial is (TRIAL_DURATION_DAYS, default 7).
    trial = { startedAt: now, exp: now + getTier('trial').termDays * DAY, source: 'oasis-app', firstSeenAt: now };
    // Only a NEW trial is reviewed. It is flagged for a person to look at, never
    // refused: a lab of machines behind one address is not an attack.
    const verdict = trialReviewer.review({ source: req.ip, fingerprintSource });
    if (verdict.flagged) trial.flags = verdict.reasons;
    db.trials[machineId] = trial;
    console.log(`    → trial_started, expires ${new Date(trial.exp).toISOString()}${verdict.flagged ? `  FLAGGED FOR REVIEW: ${verdict.reasons.join(', ')}` : ''}`);
  } else {
    console.log(`    → machine already seen, returning original expiry ${new Date(trial.exp).toISOString()}`);
  }
  // What we keep about the install: platform, architecture, app version and when
  // we last heard from it. Deliberately no hostname and no address.
  trial.lastSeenAt = now;
  if (typeof platform === 'string') trial.platform = platform.slice(0, 20);
  if (typeof arch === 'string') trial.arch = arch.slice(0, 20);
  if (typeof appVersion === 'string') trial.appVersion = appVersion.slice(0, 20);
  trial.status = trial.exp <= now ? 'expired' : 'active';
  // The customer's Jenkins and GitHub ADDRESSES and organisation, given when setup finished.
  // Cleaned again here (the app already cleaned them): addresses and a name only, no
  // credentials. Kept from the first time they arrive, so a later request cannot rewrite them.
  const details = sanitizeIntegration(integration);
  if (details && !trial.integration) {
    trial.integration = { ...details, providedAt: now };
    console.log(`    → setup details logged: ${Object.keys(details).join(', ')}`);
  }
  saveDb(db);

  if (trial.exp <= now) return reject(res, 'Your trial has already ended.');

  const tier = getTier('trial');
  const token = signToken(
    {
      licenseId: `trial_${machineId.slice(0, 8)}`,
      tier: 'trial',
      customer: null,
      seats: 1,
      features: tier.features,
      issuedAt: now,
      exp: trial.exp,
    },
    PRIVATE_KEY,
    { kid: DEV_KID }
  );
  res.json({ token, serverTime: now });
});

app.post('/activate', (req, res) => {
  const { machineId, licenseKey } = req.body || {};
  if (!machineId || !licenseKey) return reject(res, 'machineId and licenseKey are required');

  const db = loadDb();
  const record = license(db, licenseKey.trim());
  if (!record) return reject(res, 'That licence key was not recognised.');
  if (record.revoked) return reject(res, 'This licence has been revoked.', 403);
  if (record.exp <= Date.now()) return reject(res, 'This licence has expired. Renew it to continue.', 403);

  const full = bindSeat(db, licenseKey, record, machineId);
  if (full) return reject(res, full, 403);

  res.json({ token: issue(record), serverTime: Date.now() });
});

// ── Activate by email: the company holds the licence, the person proves they belong to it ──────
// Step 1: ask for a one-time code for an address whose domain has a licence.
app.post('/domain/otp', (req, res) => {
  const { machineId } = req.body || {};
  const email = normaliseEmail((req.body || {}).email);
  if (!email) return reject(res, 'Enter a valid email address.', 400, { reason: 'bad_email' });
  if (!machineId) return reject(res, 'machineId is required');

  const domain = domainOf(email);
  const db = loadDb();
  if (!domainLicense(db, domain)) {
    return reject(res, `No licence was found for ${domain}.`, 404, { reason: 'no_domain_licence', domain });
  }
  const issued = otpStore.request(email, machineId);
  if (!issued.ok) {
    const mins = Math.ceil(issued.retryAfterSeconds / 60);
    return reject(res, `Too many codes have been requested. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`, 429,
      { reason: 'too_many_requests', retryAfterSeconds: issued.retryAfterSeconds });
  }
  // A real service emails this. The stand-in prints it, so the flow can be completed without a mailbox.
  console.log(`    → one-time code for ${maskEmail(email)}: ${issued.code}   (development only; a real service emails it)`);
  res.json({ ok: true, sentTo: maskEmail(email), expiresInMinutes: 10 });
});

// Step 2: the code, then the licence is checked (expiry, revocation, seats) and a token issued.
app.post('/domain/activate', (req, res) => {
  const { machineId, code } = req.body || {};
  const email = normaliseEmail((req.body || {}).email);
  if (!email || !machineId) return reject(res, 'An email address and machineId are required.');

  const checked = otpStore.verify(email, code);
  if (!checked.ok) {
    const say = {
      no_code: 'There is no code waiting for this address. Ask for a new one.',
      expired: 'That code has expired. Ask for a new one.',
      too_many_attempts: 'Too many wrong codes. Ask for a new one.',
      wrong_code: `That code is not right. ${checked.attemptsLeft} ${checked.attemptsLeft === 1 ? 'try' : 'tries'} left.`,
    };
    return reject(res, say[checked.reason], 400, { reason: checked.reason === 'wrong_code' ? 'wrong_code' : checked.reason });
  }

  const db = loadDb();
  const found = domainLicense(db, domainOf(email));
  if (!found) return reject(res, `No licence was found for ${domainOf(email)}.`, 404, { reason: 'no_domain_licence' });
  const { key, record } = found;
  if (record.revoked) return reject(res, 'This licence has been revoked. Contact support.', 403, { reason: 'revoked' });
  if (record.exp <= Date.now()) {
    return reject(res, `Your organization's licence ended on ${fmtDate(record.exp)}. Contact support to renew it.`, 403, { reason: 'expired', expiredOn: fmtDate(record.exp) });
  }
  const full = bindSeat(db, key, record, machineId);
  if (full) return reject(res, full, 403, { reason: 'seats_full' });

  res.json({ token: issue(record), serverTime: Date.now() });
});

// ── Buy a licence: the request goes to the support team, who contact the customer ─────────────
app.post('/purchase-request', (req, res) => {
  const checked = validatePurchaseRequest(req.body);
  if (!checked.ok) return reject(res, 'Some details need fixing.', 400, { reason: 'invalid', errors: checked.errors });

  const db = loadDb();
  db.purchaseRequests = db.purchaseRequests || [];
  // A repeat of the same submit (same Idempotency-Key) gets the first answer back, as the real service does.
  const key = cleanIdempotencyKey(req.get('Idempotency-Key'));
  const earlier = key && db.purchaseRequests.find(r => r.idempotencyKey === key);
  if (earlier) { res.set('Idempotent-Replay', 'true'); return res.json({ ok: true, reference: earlier.reference }); }
  const recent = db.purchaseRequests.filter(r => r.email === checked.value.email && Date.now() - r.createdAt < 60 * 60 * 1000);
  if (recent.length >= 5) return reject(res, 'Too many requests from this address. Our team will be in touch.', 429, { reason: 'too_many_requests' });

  const request = {
    reference: `PR-${String(db.purchaseRequests.length + 1).padStart(4, '0')}`,
    createdAt: Date.now(),
    idempotencyKey: key || undefined,
    status: 'NEW',                      // NEW -> CONTACTED -> AGREED / DECLINED, by support (screen: later)
    ...checked.value,
  };
  db.purchaseRequests.push(request);
  saveDb(db);
  console.log(`    → purchase request ${request.reference} from ${request.organization} (${request.employees} employees)`);
  res.json({ ok: true, reference: request.reference });
});

app.post('/revalidate', (req, res) => {
  const { machineId, token } = req.body || {};
  // Derived from the signing key rather than read from disk — the public half
  // of a keypair is always recoverable from the private one, so there is no
  // second file to keep in sync or to be missing.
  const decoded = verifyToken(token || '', PUBLIC_KEY);
  const payload = decoded.valid ? decoded.payload : null;

  const db = loadDb();
  const key = Object.keys(db.activations).find(k => (db.activations[k] || []).includes(machineId));

  if (payload && payload.tier === 'trial') {
    const trial = db.trials[machineId];
    if (!trial || trial.exp <= Date.now()) return reject(res, 'Your trial has ended.', 403);
    return res.json({ token, serverTime: Date.now() });
  }

  if (!key) return reject(res, 'This machine is not activated on any licence.', 403);
  const record = db.licenses[key];
  if (record.revoked) return reject(res, 'This licence has been revoked.', 403);
  if (record.exp <= Date.now()) return reject(res, 'This licence has expired.', 403);

  console.log(`    → ok, fresh grace window`);
  res.json({ token: issue(record), serverTime: Date.now() });
});

app.post('/deactivate', (req, res) => {
  const { machineId } = req.body || {};
  const db = loadDb();
  for (const key of Object.keys(db.activations)) {
    db.activations[key] = (db.activations[key] || []).filter(m => m !== machineId);
  }
  saveDb(db);
  console.log('    → seat freed');
  res.json({ ok: true, serverTime: Date.now() });
});

// The vendor portal, standing in for a web page an administrator would use.
// Takes the request code from an air-gapped machine and issues a response code
// bound to the fingerprint inside it — the machine binding that separates
// offline activation from handing out a portable file.
app.post('/portal/offline-response', (req, res) => {
  const { requestCode, licenseKey } = req.body || {};
  const parsed = parseRequestCode(requestCode || '');
  if (!parsed.valid) return reject(res, `That is not a valid request code (${parsed.reason}).`);

  const db = loadDb();
  const record = license(db, (licenseKey || '').trim());
  if (!record) return reject(res, 'That licence key was not recognised.');
  if (record.tier !== 'enterprise') return reject(res, 'Offline activation is enterprise only.');
  if (record.revoked) return reject(res, 'This licence has been revoked.', 403);

  const seats = db.activations[licenseKey] || [];
  if (!seats.includes(parsed.request.machineId)) {
    seats.push(parsed.request.machineId);
    db.activations[licenseKey] = seats;
    saveDb(db);
  }

  console.log(`    → offline response for machine ${parsed.request.machineId.slice(0, 12)}`);
  res.json({
    responseCode: issue(record, { offline: true, machineId: parsed.request.machineId }),
    machineId: parsed.request.machineId,
  });
});

// ── Test levers ────────────────────────────────────────────────────────────
// Not endpoints a real service would expose to anyone. They exist so you can
// watch the app react to revocation and expiry without waiting a year.

app.post('/admin/revoke', (req, res) => {
  const db = loadDb();
  const record = license(db, (req.body || {}).licenseKey);
  if (!record) return reject(res, 'unknown key');
  record.revoked = true;
  saveDb(db);
  console.log('    → REVOKED (app locks at its next revalidation)');
  res.json({ ok: true });
});

app.post('/admin/expire', (req, res) => {
  const db = loadDb();
  const { licenseKey, machineId } = req.body || {};
  if (machineId && db.trials[machineId]) db.trials[machineId].exp = Date.now() - 1000;
  if (licenseKey) {
    const record = license(db, licenseKey);
    if (record) record.exp = Date.now() - 1000;
  }
  saveDb(db);
  res.json({ ok: true });
});

// What support will eventually do from a screen (later work): see who asked to buy, and, after the
// contact with the customer, record the organisation's licence and its expiry date.
app.get('/admin/purchase-requests', (_req, res) => res.json(loadDb().purchaseRequests || []));

app.post('/admin/domain-license', (req, res) => {
  const { domain, tier, customer, seats, days, expiresOn } = req.body || {};
  if (typeof domain !== 'string' || !/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/.test(domain)) return reject(res, 'A lower-case domain is required.');
  if (!getTier(tier)) return reject(res, `Unknown tier "${tier}".`);
  let exp = expiresOn ? Date.parse(expiresOn) : (Number.isFinite(days) ? Date.now() + days * DAY : NaN);
  if (!Number.isFinite(exp)) return reject(res, 'Give expiresOn (a date) or days.');
  const db = loadDb();
  db.domains = db.domains || {};
  const key = `DOMAIN:${domain}`;
  const t = getTier(tier);
  db.licenses[key] = {
    licenseId: `lic_dom_${domain.split('.')[0]}`, tier, customer: customer || domain,
    seats: seats === undefined ? t.seats : seats, exp, revoked: false,
  };
  db.domains[domain] = key;
  saveDb(db);
  console.log(`    → licence recorded for ${domain}: ${tier}, until ${fmtDate(exp)}`);
  res.json({ ok: true, domain, expires: fmtDate(exp) });
});

// Development only: read the code last issued to an address, so a test (or a person) can finish
// the flow without a mailbox.
app.get('/admin/last-otp', (req, res) => {
  const email = normaliseEmail(req.query.email);
  const code = email ? otpStore.devLastCode(email) : undefined;
  return code ? res.json({ code }) : res.status(404).json({ error: 'no code waiting' });
});

app.post('/admin/reset', (_req, res) => {
  otpStore = createOtpStore({ keepForDev: true });
  saveDb({ trials: {}, licenses: {}, activations: {}, domains: {}, purchaseRequests: [] });
  console.log('    → database wiped, all trials available again');
  res.json({ ok: true });
});

app.get('/admin/state', (_req, res) => res.json(loadDb()));

// Trials a person should look at. Machine ids are shortened: a reviewer needs to
// tell them apart, not to be handed the full fingerprint.
app.get('/admin/flagged-trials', (_req, res) => {
  const { trials } = loadDb();
  res.json(Object.entries(trials).filter(([, t]) => t.flags && t.flags.length).map(([id, t]) => ({
    machine: id.slice(0, 8), startedAt: new Date(t.startedAt).toISOString(), status: t.status, platform: t.platform || null, flags: t.flags,
  })));
});

app.listen(PORT, () => {
  console.log(`
Dev licence service on http://localhost:${PORT}   (NOT the real thing — testing only)
  db   ${DB_PATH}
  key  ${KEY_PATH}

Start OASIS against it:
  OASIS_LICENSE_URL=http://localhost:${PORT} npm start

Keys you can activate with:
${Object.entries(SEED_LICENSES)
  .map(([k, v]) => `  ${k}   ${v.tier}${v.seats !== undefined ? ` (${v.seats} seats)` : ''}`)
  .join('\n')}

Test levers:
  curl -X POST localhost:${PORT}/admin/revoke -H 'content-type: application/json' -d '{"licenseKey":"OASIS-TEAM-0001-0001"}'
  curl -X POST localhost:${PORT}/admin/reset
  curl localhost:${PORT}/admin/state
`);
});