#!/usr/bin/env node
'use strict';
const store = require('../server/security/store');
const { createRuleServerClient } = require('../server/security/rule-sync/client');

// Moves the findings, trend history and baseline kept in the scanner's own store
// (~/.oasis-security/store.json) to the rule server, which now owns them.
//
//   node tools/migrate-findings-to-rule-server.js              dry run: report only
//   node tools/migrate-findings-to-rule-server.js --apply      send it
//   node tools/migrate-findings-to-rule-server.js --apply --merge
//                                                              the server already scanned (you scanned before migrating): add what is
//                                                              missing and bring old suppressions across, keeping what the server has
//   node tools/migrate-findings-to-rule-server.js --apply --force
//                                                              overwrite what the server holds with the local copy
//   options: --dir <store dir>  --url <rule server url>
//
// It only READS the local store and never deletes it: the local copy is the
// rollback. Statuses, suppressions, timestamps and the baseline are restored as
// they were, so the next scan merges against what people last saw.

const usable = f => f && typeof f.fingerprint === 'string' && f.fingerprint && typeof f.repository === 'string' && f.repository;

function planMigration(data) {
  const good = data.findings.filter(usable);
  const byStatus = {};
  for (const f of good) byStatus[f.status] = (byStatus[f.status] || 0) + 1;
  return {
    findings: good.length,
    invalid: data.findings.length - good.length,
    byStatus,
    repositories: [...new Set(good.map(f => f.repository))],
    history: (data.history || []).length,
    baseline: !!data.baseline,
  };
}

async function runMigration({ dir = store.DEFAULT_DIR, client, apply = false, force = false, merge = false, batchSize = 5000, log = console.log }) {
  const data = store.load(dir);
  const plan = planMigration(data);

  log(`Local store ${dir}`);
  log(`  ${plan.findings} findings in ${plan.repositories.length} repositories ${JSON.stringify(plan.byStatus)}`);
  if (plan.invalid) log(`  ${plan.invalid} entries have no repository or fingerprint and will be skipped`);
  log(`  ${plan.history} trend points, baseline ${plan.baseline ? 'yes' : 'no'}`);

  if (!plan.findings && !plan.history && !plan.baseline) {
    return { applied: false, plan, reason: 'nothing to migrate: the local store has no findings, history or baseline' };
  }
  if (!apply) {
    log('Dry run: nothing was sent. Run again with --apply to migrate.');
    return { applied: false, plan, reason: 'dry run' };
  }

  const existing = await client.listFindings({ status: 'all' });
  if (existing.length && !force && !merge) {
    throw new Error(`the rule server already holds findings (${existing.length}), probably from a scan made before migrating. `
      + 'Use --merge to add what is missing and bring your old suppressions across without touching what the server has, '
      + 'or --force to overwrite it with the local copy.');
  }

  // Findings first, in batches; the trend history and the baseline ride with the
  // last batch, so a failure part-way leaves nothing duplicated and a re-run is safe
  // (findings are keyed by repository and fingerprint).
  const findings = data.findings.filter(usable);
  const options = merge && existing.length ? { mode: 'merge' } : {};
  const total = { findings: 0, history: 0, inserted: 0, adopted: 0, skipped: 0 };
  const batches = Math.max(1, Math.ceil(findings.length / batchSize));
  for (let i = 0; i < batches; i++) {
    const last = i === batches - 1;
    const sent = await client.importBulk({
      findings: findings.slice(i * batchSize, (i + 1) * batchSize),
      history: last ? (data.history || []) : [],
      ...(last && data.baseline ? { baseline: data.baseline } : {}),
    }, options);
    for (const key of Object.keys(total)) total[key] += sent[key] || 0;
    if (batches > 1) log(`  batch ${i + 1}/${batches} sent`);
  }
  log(options.mode === 'merge'
    ? `Merged: ${total.inserted} findings added, ${total.adopted} old suppressions adopted, ${total.skipped} left as the server had them; ${total.history} trend points.`
    : `Migrated ${total.findings} findings and ${total.history} trend points.`);
  log('The local store was left untouched. Once you have checked the Security tab, you can delete the findings from it.');
  return { applied: true, plan, imported: total };
}

if (require.main === module) {
  const arg = name => { const i = process.argv.indexOf(`--${name}`); return i !== -1 ? process.argv[i + 1] : null; };
  const has = name => process.argv.includes(`--${name}`);
  const url = arg('url') || process.env.OASIS_RULE_SERVER_URL || 'http://127.0.0.1:5090';
  const client = createRuleServerClient({ baseUrl: url, token: process.env.OASIS_RULE_SERVER_TOKEN || null });
  runMigration({ dir: arg('dir') || store.DEFAULT_DIR, client, apply: has('apply'), force: has('force'), merge: has('merge') })
    .then(r => { if (r.reason && !r.applied && r.reason !== 'dry run') console.log(r.reason); })
    .catch(e => { console.error(`migration failed: ${e.message}`); process.exit(1); });
}

module.exports = { planMigration, runMigration };
