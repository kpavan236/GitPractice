'use strict';
const crypto = require('crypto');

// One-time codes for "Activate licence", kept in memory. Used by the dev licence service; the
// rules are the ones the real service must follow:
//
//   * six digits, valid for ten minutes, one live code per address (asking again replaces it);
//   * five wrong tries lock that code, and only a new code unlocks the address;
//   * a code works once, and only for the address it was sent to;
//   * three requests per address and ten per machine per fifteen minutes, so the page cannot be
//     used to flood someone's mailbox;
//   * the code itself is never stored: only a salted hash, compared in constant time.
//
// Nothing here is saved to disk: a restart simply invalidates outstanding codes, which is the safe
// direction.

const TTL_MS = 10 * 60 * 1000;
const WINDOW_MS = 15 * 60 * 1000;

function createOtpStore({
  now = Date.now,
  randomCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0'),
  ttlMs = TTL_MS, windowMs = WINDOW_MS, maxAttempts = 5, maxPerAddress = 3, maxPerSource = 10,
  keepForDev = false,
} = {}) {
  const challenges = new Map();     // address -> { salt, hash, expiresAt, attempts }
  const requestLog = new Map();     // 'a:<address>' / 's:<source>' -> [timestamps]
  const devCodes = new Map();       // only when keepForDev

  const hash = (salt, code) => crypto.createHash('sha256').update(salt).update(code).digest('hex');

  function prune(t) {
    for (const [k, c] of challenges) if (c.expiresAt <= t - windowMs) challenges.delete(k);
    for (const [k, stamps] of requestLog) {
      const kept = stamps.filter(s => t - s < windowMs);
      if (kept.length) requestLog.set(k, kept); else requestLog.delete(k);
    }
  }

  function within(key, limit, t) {
    const stamps = (requestLog.get(key) || []).filter(s => t - s < windowMs);
    if (stamps.length >= limit) return { blocked: true, retryAfterSeconds: Math.max(1, Math.ceil((stamps[0] + windowMs - t) / 1000)) };
    return { blocked: false, stamps };
  }

  function request(address, source = '') {
    const t = now();
    prune(t);
    const a = within(`a:${address}`, maxPerAddress, t);
    const s = source ? within(`s:${source}`, maxPerSource, t) : { blocked: false, stamps: [] };
    if (a.blocked || s.blocked) return { ok: false, reason: 'too_many_requests', retryAfterSeconds: Math.max(a.retryAfterSeconds || 0, s.retryAfterSeconds || 0) };

    const code = randomCode();
    const salt = crypto.randomBytes(16).toString('hex');
    challenges.set(address, { salt, hash: hash(salt, code), expiresAt: t + ttlMs, attempts: 0 });
    requestLog.set(`a:${address}`, [...a.stamps, t]);
    if (source) requestLog.set(`s:${source}`, [...s.stamps, t]);
    if (keepForDev) devCodes.set(address, code);
    return { ok: true, code };
  }

  function verify(address, code) {
    const t = now();
    const c = challenges.get(address);
    if (!c) return { ok: false, reason: 'no_code' };
    if (c.expiresAt <= t) { challenges.delete(address); devCodes.delete(address); return { ok: false, reason: 'expired' }; }
    if (c.attempts >= maxAttempts) return { ok: false, reason: 'too_many_attempts' };

    const given = typeof code === 'string' ? code.trim() : '';
    const good = /^\d{6}$/.test(given)
      && crypto.timingSafeEqual(Buffer.from(hash(c.salt, given), 'hex'), Buffer.from(c.hash, 'hex'));
    if (good) { challenges.delete(address); devCodes.delete(address); return { ok: true }; }

    c.attempts += 1;
    if (c.attempts >= maxAttempts) return { ok: false, reason: 'too_many_attempts' };
    return { ok: false, reason: 'wrong_code', attemptsLeft: maxAttempts - c.attempts };
  }

  return {
    request, verify,
    // For tests: what is held, which must never include a code.
    snapshot: () => ({ challenges: [...challenges].map(([address, c]) => ({ address, hash: c.hash, attempts: c.attempts })) }),
    // The development service only: read a code back so a person (or a test) can finish the flow
    // without a mailbox. Absent unless asked for.
    devLastCode: address => devCodes.get(address),
  };
}

module.exports = { createOtpStore, TTL_MS, WINDOW_MS };
