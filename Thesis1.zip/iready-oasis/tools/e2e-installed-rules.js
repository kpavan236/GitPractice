#!/usr/bin/env node
'use strict';
// Proves the installed-rules path with a REAL release: the OASIS loader downloads and verifies it, a scan runs on the
// installed core pack (OASIS_ENGINE=installed), and the same sample repository is scanned with the bundled engine and
// the same rules; the two must report identical findings.
//
// usage: node tools/e2e-installed-rules.js
// env:   OASIS_RULE_SERVER_URL          the public rules service (required)
//        OASIS_DEV_RULES_PUBLIC_KEYS    JSON file { keyId: public key PEM } that signed the release (required until keys are pinned)
//        OASIS_RULES_CHANNEL            beta | stable (default stable)
//        E2E_REPO                       optional: an existing repository to scan instead of the generated sample (read only)
//        HOME                           where the loader keeps the installed release (~/.oasis-security/rules). Use a throwaway HOME.
// The scan stores are throwaway temp dirs. Prints a report and exits 1 on any difference. Local development only.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createEngineLoader } = require('../server/security/engine-loader');
const { createRulesUpdater } = require('../server/security/rules-updates');
const { createOrchestrator } = require('../server/security/orchestrator');
const { runEngine } = require('../server/security/engine-loader/run');
const { acquireCore } = require('../server/security/engine-workdir');

const ENGINE_SCANNERS = ['secrets-builtin', 'pattern-sast', 'iac-policy', 'sast-ast'];
const SCANNER_IDS = ENGINE_SCANNERS.map((n) => require(`../server/security/scanners/${n}`).scanner.id);
const TOKEN = `ghp_${'aB3dE5gH7jK9mN1pQ3sT5vW7yZ9bC1dE3fG5'}`;   // a made-up shape-only credential

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const say = (m) => console.log(`e2e: ${m}`);

async function finish(o, id) {
  for (let i = 0; i < 2400; i += 1) {
    const s = o.getScan(id);
    if (s && ['COMPLETED', 'FAILED', 'CANCELLED'].includes(s.status)) return s;
    await sleep(100);
  }
  throw new Error('scan did not finish within four minutes');
}

// One directory per rule that carries an example, plus a secret in a config file: every engine gets something to find.
function writeSampleRepo(dir, rules) {
  let written = 0;
  for (const r of rules) {
    if (!r.example || typeof r.example.vulnerable !== 'string' || typeof r.example.file !== 'string') continue;
    const file = path.join(dir, r.id, r.example.file);
    if (!path.resolve(file).startsWith(`${path.resolve(dir)}${path.sep}`)) continue;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, r.example.vulnerable);
    written += 1;
  }
  fs.writeFileSync(path.join(dir, 'config.env'), `GITHUB_TOKEN=${TOKEN}\n`);
  return written;
}

// What a finding is, for comparison: no ids, timestamps or paths that differ by run.
const view = (f) => ({
  sources: f.detections.map((d) => d.source).sort().join(','),
  rules: f.detections.map((d) => d.ruleId).sort().join(','), type: f.type, file: f.file, startLine: f.startLine, endLine: f.endLine,
  severity: f.severity, title: f.title, description: f.description, cwe: f.cwe || null,
});
const key = (v) => JSON.stringify(v);

async function scan(o, repoPath, label) {
  o = Object.assign(o, { scannerIds: SCANNER_IDS });
  const started = Date.now();
  const s = await o.startScan({ targets: [{ repository: 'e2e/sample', repoPath }], only: o.scannerIds });
  const done = await finish(o, s.id);
  if (done.status !== 'COMPLETED') throw new Error(`${label} scan ${done.status}: ${done.error || ''} ${JSON.stringify((done.perRepository || []).map((r) => ({ repository: r.repository, scanners: (r.scanners || []).map((x) => [x.id, x.status, x.error]) })))}`);
  const failed = (done.perRepository || []).flatMap((r) => r.scanners || []).filter((x) => x.status === 'FAILED');
  if (failed.length) throw new Error(`${label}: scanner(s) failed: ${failed.map((x) => `${x.id}: ${x.error}`).join('; ')}`);
  const findings = (await o.listFindings({ repository: 'e2e/sample' })).map(view).sort((a, b) => (key(a) < key(b) ? -1 : 1));
  return { findings, ms: Date.now() - started, done };
}

// The proof proper, on an installed release: the engine child on the real core pack, then the same repository through the
// orchestrator on the installed engine and on the bundled one, with the same rules. Throws on any difference.
// updater: createRulesUpdater(...) over a loader that has a release installed. repoPath: scan this instead of a generated sample.
async function proveInstalledEngine({ updater, repoPath = null, env = { OASIS_ENGINE: 'installed' }, say = () => {}, log = () => {} }) {
  const loader = updater.loader;
  const release = loader.current();
  if (!release) throw new Error('nothing is installed');
  const languages = release.manifest.packs.filter((p) => p.kind === 'language').map((p) => p.language);
  const rules = loader.rulesFor(languages);
  if (!rules.length) throw new Error('the installed release has no rules');
  say(`installed release ${release.release} (${release.manifest.channel}), ${languages.length} language packs, devKeys=${JSON.stringify(loader.devKeys ? loader.devKeys() : [])}`);

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-e2e-installed-'));
  try {
    let repo = repoPath;
    if (repo) say(`scanning the existing repository ${repo}`);
    else {
      repo = path.join(tmp, 'repo');
      fs.mkdirSync(repo);
      say(`sample repository: ${writeSampleRepo(repo, rules)} example files from ${rules.length} installed rules, plus one secret`);
    }
    const scanners = ENGINE_SCANNERS.map((n) => require(`../server/security/scanners/${n}`).scanner);
    const openNetwork = env.OASIS_ALLOW_OPEN_NETWORK_ENGINE === '1';

    // The engine child on the real core pack, called directly: is network denied, did the grammars load, was the answer framed cleanly.
    const lease = await acquireCore({ loader, workDir: path.join(tmp, 'engine-work') });
    let direct;
    try {
      const answer = await runEngine({ corePath: lease.path, repoPath: repo, repository: 'e2e/sample', ruleSet: { rules, version: `release-${release.release}`, source: 'rules-service' }, scannerIds: SCANNER_IDS, allowNetworkOpenEngine: openNetwork });
      const grammars = fs.readdirSync(path.join(lease.path, 'src', 'ast', 'grammars')).filter((n) => n.endsWith('.wasm')).sort();
      say(`runEngine on the installed core: networkDenied=${answer.networkDenied}, grammars=${grammars.join(',')}, results=${answer.results.map(([id, r]) => `${id}:${r.findings.length}${r.error ? ' ERROR' : ''}`).join(' ')}`);
      if (answer.results.some(([, r]) => r.error)) throw new Error('an engine reported an error');
      if (!grammars.length) throw new Error('no grammars reached the engine');
      const secrets = (answer.results.find(([id]) => id === 'BUILTIN_SECRETS') || [, { findings: [] }])[1].findings;
      if (!secrets.some((f) => f.metadata && f.metadata.secretHash)) throw new Error('the real analyzer returned no secret finding with metadata.secretHash: the host cannot key the plaintext');
      direct = { networkDenied: answer.networkDenied, grammars };
    } finally { lease.done(); }

    const installed = createOrchestrator({ scanners, log, dir: path.join(tmp, 'store-installed'), userRulesDir: null, userGrammarsDir: null, loader, env });
    const a = await scan(installed, repo, 'installed engine');
    await installed.shutdown();
    say(`installed engine: ${a.findings.length} findings in ${a.ms} ms; rule set ${a.done.ruleSets.map((r) => `${r.version} (${r.source})`).join(', ')}`);

    // The bundled engine (the oasis-analyzer this app ships, on its worker pool) with exactly the rules the release carries.
    const ruleSync = { refresh: async () => ({ source: 'rule-server', version: `release-${release.release}`, rules, projectKnown: true, createdAt: null, fetchedAt: null }) };
    const bundled = createOrchestrator({ scanners, log, dir: path.join(tmp, 'store-bundled'), userRulesDir: null, userGrammarsDir: null, ruleSync, env: { ...env, OASIS_ENGINE: 'bundled' } });
    const b = await scan(bundled, repo, 'bundled engine');
    await bundled.shutdown();
    say(`bundled engine:   ${b.findings.length} findings in ${b.ms} ms`);

    const inA = new Set(a.findings.map(key));
    const inB = new Set(b.findings.map(key));
    const onlyInstalled = [...inA].filter((k) => !inB.has(k));
    const onlyBundled = [...inB].filter((k) => !inA.has(k));
    if (onlyInstalled.length || onlyBundled.length) {
      for (const k of onlyInstalled.slice(0, 20)) say(`ONLY INSTALLED: ${k}`);
      for (const k of onlyBundled.slice(0, 20)) say(`ONLY BUNDLED:   ${k}`);
      throw new Error(`the engines differ: ${onlyInstalled.length} only on the installed engine, ${onlyBundled.length} only on the bundled one`);
    }
    if (!a.findings.length) throw new Error('both engines found nothing: the proof would be empty');
    const bySource = {};
    for (const f of a.findings) for (const x of f.sources.split(',')) bySource[x] = (bySource[x] || 0) + 1;
    say(`findings by engine: ${JSON.stringify(bySource)}`);
    if (!repoPath) for (const id of SCANNER_IDS) if (!bySource[id]) throw new Error(`the proof is empty for ${id}: it reported no findings on either engine`);
    if (JSON.stringify(a.findings).includes(TOKEN)) throw new Error('the secret plaintext appears in the findings');
    say(`IDENTICAL: ${a.findings.length} findings (rule id, file, lines, severity, title, description, CWE) on both engines`);
    return { findings: a.findings.length, bySource, ...direct, release: release.release };
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

async function main() {
  const baseUrl = process.env.OASIS_RULE_SERVER_URL;
  if (!baseUrl) throw new Error('set OASIS_RULE_SERVER_URL');
  const log = (...a) => say(`log: ${a.join(' ')}`);
  const loader = createEngineLoader({ dir: path.join(os.homedir(), '.oasis-security', 'rules'), baseUrl, channel: process.env.OASIS_RULES_CHANNEL || undefined, log });
  const updater = createRulesUpdater({ loader, log });
  say(`update(): ${JSON.stringify(await updater.update())}`);
  await proveInstalledEngine({
    updater, say, log, repoPath: process.env.E2E_REPO ? path.resolve(process.env.E2E_REPO) : null,
    env: { OASIS_ENGINE: 'installed', ...(process.env.OASIS_ALLOW_OPEN_NETWORK_ENGINE ? { OASIS_ALLOW_OPEN_NETWORK_ENGINE: process.env.OASIS_ALLOW_OPEN_NETWORK_ENGINE } : {}) },
  });
}

module.exports = { proveInstalledEngine };

if (require.main === module) {
  main().then(() => { say('OK'); process.exit(0); }, (e) => { console.error(`e2e: FAILED: ${e.code ? `${e.code}: ` : ''}${e.message}`); process.exit(1); });
}
