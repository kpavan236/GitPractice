#!/usr/bin/env node
'use strict';
const fs = require('fs');
const https = require('https');
const path = require('path');
const zlib = require('zlib');
const { eachEntry } = require('../server/security/advisories/zip');
const { indexPath, INDEX_VERSION, DEFAULT_DIR } = require('../server/security/advisories/mirror');

// Builds the offline advisory mirror from OSV's bulk exports.
//
//   node tools/build-advisories.js Maven npm         → those ecosystems
//   node tools/build-advisories.js --list            → what is available
//   node tools/build-advisories.js --dir /path Maven → somewhere else
//
// ECOSYSTEMS ARE OPT-IN, and that is not laziness. npm's export alone is
// 219 MB; a Java shop mirroring npm downloads a fifth of a gigabyte to answer
// questions it will never ask. Naming what you use keeps the mirror in
// megabytes.
//
// The index keeps ONLY what a finding needs — id, aliases, summary, severity,
// dates, and the affected ranges. The prose, references and credits that make
// an advisory large are dropped, which is what turns hundreds of megabytes into
// a few. The full text is one URL away and the index carries it.

const BASE = 'https://osv-vulnerabilities.storage.googleapis.com';
const TIMEOUT_MS = 300000;

// OSV's own identifiers. Mapped to the ecosystem names the SCA scanners already
// use so a caller never has to know both vocabularies.
const ECOSYSTEMS = {
  npm: 'npm',
  Maven: 'maven',
  PyPI: 'pypi',
  Go: 'go',
  'crates.io': 'cargo',
  NuGet: 'nuget',
  Packagist: 'composer',
  RubyGems: 'rubygems',
  Hex: 'hex',
  Pub: 'pub',
  Hackage: 'hackage',
  CRAN: 'cran',
};

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i !== -1 ? (process.argv[i + 1] || true) : null;
}

function download(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'i-Ready-OASIS-advisory-mirror' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(download(res.headers.location));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.setTimeout(TIMEOUT_MS, () => req.destroy(new Error('timed out')));
    req.on('error', reject);
  });
}

/**
 * Reduces one OSV advisory to what a finding needs.
 *
 * Exported so the shrinking is testable on its own: if this ever starts keeping
 * the full record the index quietly grows back to hundreds of megabytes, and
 * the only symptom is a slow disk.
 */
function compact(advisory) {
  return {
    id: advisory.id,
    aliases: advisory.aliases || [],
    summary: advisory.summary || null,
    published: advisory.published || null,
    modified: advisory.modified || null,
    severity: advisory.severity || undefined,
    database_specific: advisory.database_specific && advisory.database_specific.severity
      ? { severity: advisory.database_specific.severity }
      : undefined,
    // The ranges ARE the data. Everything else here is labelling.
    affected: (advisory.affected || []).map(a => ({
      package: a.package ? { name: a.package.name, ecosystem: a.package.ecosystem } : undefined,
      ranges: a.ranges,
      versions: a.versions,
    })),
  };
}

function buildIndex(zipBuffer, ecosystem) {
  const advisories = {};
  const packages = {};
  let skipped = 0;

  eachEntry(zipBuffer, (name, data) => {
    if (!name.endsWith('.json')) return;

    let advisory;
    try {
      advisory = JSON.parse(data.toString('utf8'));
    } catch (_) {
      // One malformed record must not cost the other quarter of a million.
      skipped += 1;
      return;
    }
    if (!advisory.id) {
      skipped += 1;
      return;
    }

    // Withdrawn advisories are kept out. They were retracted by the publisher,
    // and reporting one is a false positive with an authoritative-looking id.
    if (advisory.withdrawn) return;

    advisories[advisory.id] = compact(advisory);

    for (const entry of advisory.affected || []) {
      const pkg = entry.package && entry.package.name;
      if (!pkg) continue;
      const key = pkg.toLowerCase();
      if (!packages[key]) packages[key] = [];
      if (!packages[key].includes(advisory.id)) packages[key].push(advisory.id);
    }
  });

  return {
    indexVersion: INDEX_VERSION,
    ecosystem,
    builtAt: new Date().toISOString(),
    source: `${BASE}/${ecosystem}/all.zip`,
    license: 'CC0-1.0 — OSV.dev and the GitHub Advisory Database',
    packages,
    advisories,
    skipped,
  };
}

async function buildOne(ecosystem, dir) {
  const url = `${BASE}/${ecosystem}/all.zip`;
  process.stdout.write(`  ${ecosystem}: downloading… `);

  const zip = await download(url);
  process.stdout.write(`${(zip.length / 1024 / 1024).toFixed(1)} MB, indexing… `);

  const index = buildIndex(zip, ecosystem);
  const gz = zlib.gzipSync(Buffer.from(JSON.stringify(index), 'utf8'), { level: 9 });

  const target = indexPath(ECOSYSTEMS[ecosystem] || ecosystem, dir);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, gz);

  const packages = Object.keys(index.packages).length;
  const count = Object.keys(index.advisories).length;
  console.log(
    `${count} advisories over ${packages} packages → ${(gz.length / 1024).toFixed(0)} KB`
    + `${index.skipped ? ` (${index.skipped} unreadable)` : ''}`
  );
  return { ecosystem, advisories: count, packages, bytes: gz.length };
}

async function main() {
  const dir = arg('dir') || DEFAULT_DIR;

  if (arg('list')) {
    console.log('Available ecosystems:\n');
    for (const [osv, internal] of Object.entries(ECOSYSTEMS)) {
      console.log(`  ${osv.padEnd(12)} → ${internal}`);
    }
    console.log('\nMirror only what you use — npm alone is over 200 MB.');
    return;
  }

  const wanted = process.argv.slice(2).filter(a => !a.startsWith('--') && ECOSYSTEMS[a]);
  if (!wanted.length) {
    console.error('Name at least one ecosystem, or --list to see them.');
    console.error('  node tools/build-advisories.js Maven npm');
    process.exit(1);
  }

  console.log(`▶ Building the offline advisory mirror in ${dir}\n`);

  const built = [];
  for (const ecosystem of wanted) {
    try {
      built.push(await buildOne(ecosystem, dir));
    } catch (e) {
      // One ecosystem failing leaves the others — and any previously built
      // index — in place. A network blip must not empty the mirror.
      console.error(`  ${ecosystem}: FAILED — ${e.message}`);
      process.exitCode = 1;
    }
  }

  if (built.length) {
    const total = built.reduce((n, b) => n + b.bytes, 0);
    console.log(`\n✓ ${built.length} ecosystem(s), ${(total / 1024 / 1024).toFixed(1)} MB on disk`);
    console.log('  Set OASIS_ADVISORY_MIRROR=1 to prefer it over api.osv.dev.');
  }
}

if (require.main === module) {
  main().catch(e => {
    console.error(e.message);
    process.exit(1);
  });
}

module.exports = { buildIndex, compact, ECOSYSTEMS };
