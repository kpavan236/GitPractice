#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# One command to run OASIS with licensing, the way a customer's first run goes:
#
#     ./start-dev.sh              the web app on http://localhost:3000
#     ./start-dev.sh --desktop    the Electron desktop app
#     ./start-dev.sh --fresh      first wipe the dev licence data and this machine's licence
#                                 state, so "Start trial" can be tried again from scratch
#
# It starts the development licence service (tools/license-service-dev.js) if one is not
# already running, then the app pointed at it, and stops only what IT started when you
# press Ctrl+C. A service you started yourself is left running.
#
# Environment:
#   PORT                       the web app's port                       (default 3000)
#   LICENSE_SERVICE_PORT       the dev licence service's port           (default 4010)
#   OASIS_LICENSE_PRIVATE_KEY  the dev signing key  (default ~/.oasis-license-dev/private.pem)
#   OASIS_LICENSE_DISABLED=1   run the app with no licensing at all (the service is not started)
#
# This is for DEVELOPMENT. The service it starts is a stand-in, not the real one; see
# start-licensed.sh for the full licence-service setup.

MODE="web"
FRESH=0

usage() {
  cat <<'EOF'

  ./start-dev.sh [options]

    --desktop     run the Electron desktop app instead of the web server
    --fresh       wipe the dev licence data and this machine's licence state first
    -h, --help    this

EOF
}

for arg in "$@"; do
  case "$arg" in
    --desktop) MODE="desktop" ;;
    --web)     MODE="web" ;;
    --fresh)   FRESH=1 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $arg"; usage; exit 2 ;;
  esac
done

APP_PORT="${PORT:-3000}"
LICENSE_PORT="${LICENSE_SERVICE_PORT:-4010}"
LICENSE_URL="http://localhost:${LICENSE_PORT}"
KEY_PATH="${OASIS_LICENSE_PRIVATE_KEY:-$HOME/.oasis-license-dev/private.pem}"
DATA_DIR="$HOME/.oasis-license-dev"
LOG="${DATA_DIR}/service.log"

SERVICE_PID=""
APP_PID=""

die() { echo; echo "  ✗ $*"; echo; exit 1; }

command -v node >/dev/null 2>&1 || die "Node.js is not installed or not on your PATH."

listener_on() { lsof -ti ":$1" -sTCP:LISTEN 2>/dev/null | head -1 || true; }

# Is the thing answering on the licence port really the dev licence service?
is_license_service() {
  curl -s -m 2 "${LICENSE_URL}/admin/state" 2>/dev/null | grep -q '"trials"'
}

cleanup() {
  trap - EXIT INT TERM
  if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
    kill "$APP_PID" 2>/dev/null || true
    wait "$APP_PID" 2>/dev/null || true
  fi
  if [ -n "$SERVICE_PID" ] && kill -0 "$SERVICE_PID" 2>/dev/null; then
    echo "Stopping the dev licence service (started by this script)…"
    kill "$SERVICE_PID" 2>/dev/null || true
    wait "$SERVICE_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

# ── Licensing switched off: nothing to start but the app ───────────────────────────────
if [ "${OASIS_LICENSE_DISABLED:-}" = "1" ]; then
  echo "OASIS_LICENSE_DISABLED=1: running with no licensing; the licence service is not started."
else
  # ── The dev licence service ──────────────────────────────────────────────────────────
  if is_license_service; then
    echo "Dev licence service already running at ${LICENSE_URL}; using it."
  else
    other="$(listener_on "$LICENSE_PORT")"
    if [ -n "$other" ]; then
      die "Port ${LICENSE_PORT} is in use by something that is not the dev licence service (PID ${other}).
    Stop it, or pick another port:  LICENSE_SERVICE_PORT=4011 ./start-dev.sh"
    fi
    [ -f "$KEY_PATH" ] || die "No signing key at ${KEY_PATH}.
    The dev licence service signs trials with it. See tools/license-dev.js for how to get or
    generate one, or point OASIS_LICENSE_PRIVATE_KEY at it."

    mkdir -p "$DATA_DIR"
    echo "Starting the dev licence service on ${LICENSE_URL} …"
    LICENSE_SERVICE_PORT="$LICENSE_PORT" node tools/license-service-dev.js >"$LOG" 2>&1 &
    SERVICE_PID=$!

    for _ in $(seq 1 30); do
      if is_license_service; then break; fi
      if ! kill -0 "$SERVICE_PID" 2>/dev/null; then
        echo; echo "--- last lines of ${LOG} ---"; tail -n 8 "$LOG" || true
        SERVICE_PID=""
        die "The dev licence service stopped as soon as it started (see above)."
      fi
      sleep 0.3
    done
    is_license_service || die "The dev licence service did not answer on ${LICENSE_URL} (log: ${LOG})."
  fi

  # ── A clean slate for trying the first run again ────────────────────────────────────
  if [ "$FRESH" = "1" ]; then
    curl -s -m 5 -X POST "${LICENSE_URL}/admin/reset" >/dev/null || die "Could not reset the dev licence data."
    echo "  • wiped the dev licence data (all trials can start again)"
    if [ -f "$HOME/.oasis-license.json" ]; then
      rm -f "$HOME/.oasis-license.json"
      echo "  • removed this machine's licence state (~/.oasis-license.json)"
    fi
  fi

  export OASIS_LICENSE_URL="${LICENSE_URL}"
fi

# ── The app ──────────────────────────────────────────────────────────────────────────────
echo
if [ "${OASIS_LICENSE_DISABLED:-}" = "1" ]; then
  DETAILS="  licensing: off"
else
  DETAILS="  licence service: ${LICENSE_URL}    data: ${LICENSE_SERVICE_DB:-$DATA_DIR/service-db.json}    log: ${LOG}"
fi

if [ "$MODE" = "web" ]; then
  other="$(listener_on "$APP_PORT")"
  [ -z "$other" ] || die "Port ${APP_PORT} is in use (PID ${other}).
    Stop it, or pick another port:  PORT=3001 ./start-dev.sh"
  echo "Starting OASIS on http://localhost:${APP_PORT}   (Ctrl+C stops everything this script started)"
  echo "$DETAILS"
  echo
  PORT="$APP_PORT" node server/index.js &
else
  echo "Starting the OASIS desktop app   (Ctrl+C stops everything this script started)"
  echo "$DETAILS"
  echo
  npx electron . &
fi
APP_PID=$!
wait "$APP_PID" || true
