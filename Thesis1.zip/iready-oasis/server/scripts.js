'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { detectBash } = require('./shell');

// Choosing the right script for the machine, and refusing to offer one that
// cannot run.
//
// Setup and launch scripts were hardcoded to `.sh`, which meant Windows had
// nothing — the button appeared, the job started, and no output ever came.
// A script now resolves by EXTENSION PREFERENCE for the platform, and
// "available" deliberately means two things at once:
//
//   the file exists, AND something on this machine can execute it
//
// Both halves matter. A .ps1 on a Mac with no PowerShell installed is not an
// available script, and offering it produces the same silent failure in the
// other direction. Anything that cannot be run is reported as unavailable WITH
// A REASON, never presented as a working button.

// Preference order per platform. Windows keeps .sh LAST rather than excluding
// it: every script that exists today is .sh, and Git for Windows — which the
// app already requires for git — can run them. Dropping it would leave Windows
// with nothing at all until .ps1 equivalents are written.
const EXTENSION_ORDER = {
  win32: ['.ps1', '.cmd', '.bat', '.sh'],
  // pwsh is cross-platform, so a .ps1 is a legitimate fallback on POSIX for a
  // team that standardises on it. .sh still wins where both exist.
  default: ['.sh', '.ps1'],
};

function extensionsFor(platform = process.platform) {
  return EXTENSION_ORDER[platform] || EXTENSION_ORDER.default;
}

// Every extension we know how to talk about, whether or not this platform
// prefers it.
//
// Searching only the platform's preferred list made a Windows-only script on a
// Mac indistinguishable from no script at all — the caller got null and fell
// through to auto-detection, so "nobody wrote one" and "the one here does not
// apply to your OS" produced identical behaviour and no explanation. They call
// for different actions, so they are reported differently.
const ALL_EXTENSIONS = ['.sh', '.ps1', '.cmd', '.bat'];

// Preferred extensions first, in order; everything else after, so a
// non-preferred script is still FOUND and can be reported, but never wins over
// one this machine actually prefers.
function searchOrder(platform) {
  const preferred = extensionsFor(platform);
  return [...preferred, ...ALL_EXTENSIONS.filter(e => !preferred.includes(e))];
}

// Cached per command: each check shells out, and the answer cannot change while
// the app is running.
const _probe = new Map();
function canRun(command, versionArgs) {
  if (_probe.has(command)) return _probe.get(command);
  let ok = false;
  try {
    execFileSync(command, versionArgs, { stdio: 'ignore', timeout: 5000 });
    ok = true;
  } catch (_) {
    ok = false;
  }
  _probe.set(command, ok);
  return ok;
}

/**
 * What runs a script of this kind, if anything.
 *
 * Returns `{ available, command, args, trace, hint }`. `args` builds the full
 * argv, so a caller never has to know that PowerShell needs -File and cmd needs
 * /c — getting that wrong is the sort of thing that fails only on the platform
 * nobody develops on.
 */
function interpreterFor(scriptPath, { platform = process.platform } = {}) {
  const ext = path.extname(scriptPath).toLowerCase();

  if (ext === '.sh') {
    const bash = detectBash();
    return {
      kind: 'bash',
      available: bash.available,
      command: bash.path,
      // -x plus a distinctive PS4 is how the UI surfaces each command a setup
      // script runs. OPT-IN, not automatic: launch does not want it, and baking
      // it in filled the launch log with a trace of the application's own
      // startup. `supportsTrace` tells the caller it is available at all — it
      // is a bash feature the other interpreters have no equivalent for.
      supportsTrace: true,
      args: (script, scriptArgs = [], { trace = false } = {}) =>
        [...(trace ? ['-x'] : []), script, ...scriptArgs],
      hint: bash.hint,
    };
  }

  if (ext === '.ps1') {
    // pwsh first: it is PowerShell 7, it is what a cross-platform team
    // installs, and it exists on macOS and Linux. powershell.exe is the
    // Windows-only 5.1 that ships with the OS.
    const pwsh = canRun('pwsh', ['-NoLogo', '-Command', '$PSVersionTable.PSVersion.Major']);
    const legacy = !pwsh && platform === 'win32'
      && canRun('powershell', ['-NoLogo', '-NoProfile', '-Command', '$PSVersionTable.PSVersion.Major']);

    return {
      kind: 'powershell',
      available: pwsh || legacy,
      command: pwsh ? 'pwsh' : 'powershell',
      supportsTrace: false,
      // -NoProfile so a developer's personal profile cannot change what the
      // script does. -ExecutionPolicy Bypass because the default on Windows
      // refuses unsigned local scripts, which is every script we ship.
      args: (script, scriptArgs = []) =>
        ['-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, ...scriptArgs],
      hint: pwsh || legacy
        ? null
        : 'This repository has a PowerShell script but PowerShell was not found. '
          + 'Install PowerShell 7 (https://aka.ms/powershell) and restart OASIS.',
    };
  }

  if (ext === '.cmd' || ext === '.bat') {
    return {
      kind: 'cmd',
      available: platform === 'win32',
      command: 'cmd.exe',
      supportsTrace: false,
      args: (script, scriptArgs = []) => ['/c', script, ...scriptArgs],
      hint: platform === 'win32' ? null : `${ext} scripts only run on Windows.`,
    };
  }

  return {
    kind: 'unknown',
    available: false,
    command: null,
    supportsTrace: false,
    args: () => [],
    hint: `No interpreter is configured for ${ext || 'files with no extension'}.`,
  };
}

/**
 * The best script for this machine at `<dir>/<base><ext>`.
 *
 * Every extension is examined even after a file is found, because a file that
 * exists but cannot be executed must not shadow one that can: on a Mac with no
 * PowerShell, `repo.ps1` present and `repo.sh` present should run the shell
 * script rather than report the repository unrunnable.
 *
 * @returns {null|{ path, ext, interpreter, available, hint, shadowed }}
 */
function findScript(dir, base, { platform = process.platform } = {}) {
  if (!dir) return null;

  const present = [];
  for (const ext of searchOrder(platform)) {
    const candidate = path.join(dir, `${base}${ext}`);
    if (!fs.existsSync(candidate)) continue;
    present.push({ path: candidate, ext, interpreter: interpreterFor(candidate, { platform }) });
  }
  if (!present.length) return null;

  const runnable = present.find(p => p.interpreter.available);
  if (runnable) {
    return {
      path: runnable.path,
      ext: runnable.ext,
      interpreter: runnable.interpreter,
      available: true,
      hint: null,
      // Which higher-preference scripts were passed over, so "why did it run
      // the .sh" has an answer.
      shadowed: present.filter(p => p !== runnable).map(p => p.ext),
    };
  }

  // Something is there and none of it can run. Reported with the reason from
  // the most-preferred candidate rather than as "no script", because those
  // require completely different actions from the user.
  const first = present[0];
  return {
    path: first.path,
    ext: first.ext,
    interpreter: first.interpreter,
    available: false,
    hint: first.interpreter.hint,
    shadowed: [],
  };
}

/**
 * The first runnable script across several roots, in order.
 *
 * Roots are tried in sequence and the FIRST RUNNABLE one wins — not the first
 * that merely exists. A bundled script that cannot run on this machine must not
 * hide a working one in the team's own directory, which is the same rule the
 * extension search follows and for the same reason.
 *
 * When nothing is runnable anywhere, the most-preferred candidate that DOES
 * exist is returned so the caller can say why, rather than reporting the
 * absence of a file that is plainly sitting there.
 */
function findScriptIn(dirs, base, opts = {}) {
  const found = [];
  for (const dir of (dirs || []).filter(Boolean)) {
    const hit = findScript(dir, base, opts);
    if (!hit) continue;
    // Which root it came from, so "why is it running the old script" is
    // answerable without reading the code.
    hit.root = dir;
    if (hit.available) return hit;
    found.push(hit);
  }
  return found[0] || null;
}

/**
 * The argv to execute a resolved script.
 *
 * Throws with the interpreter's hint when nothing can run it — the message a
 * user sees instead of ENOENT.
 */
function commandFor(resolved, scriptArgs = [], { trace = false } = {}) {
  if (!resolved || !resolved.available) {
    throw new Error((resolved && resolved.hint) || 'No runnable script was found.');
  }
  // Tracing is only ever enabled where the interpreter supports it, so a caller
  // asking for it against PowerShell gets untraced output rather than a flag
  // that interpreter would reject.
  const traced = trace && resolved.interpreter.supportsTrace;
  return {
    command: resolved.interpreter.command,
    args: resolved.interpreter.args(resolved.path, scriptArgs, { trace: traced }),
    trace: traced,
  };
}

// Quoting for a shell command line, since the existing execution path builds
// one string rather than an argv.
function quote(value) {
  return `"${String(value).replace(/(["$`\\])/g, '\\$1')}"`;
}

function commandLineFor(resolved, scriptArgs = [], options = {}) {
  const { command, args, trace } = commandFor(resolved, scriptArgs, options);
  return { line: [command, ...args].map(quote).join(' '), trace };
}

function _resetForTests() {
  _probe.clear();
}

module.exports = {
  findScript,
  findScriptIn,
  ALL_EXTENSIONS,
  searchOrder,
  interpreterFor,
  commandFor,
  commandLineFor,
  extensionsFor,
  EXTENSION_ORDER,
  _resetForTests,
};
