'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { HttpLicenseProvider } = require('./provider');

const fakeHttp = () => {
  const calls = [];
  return { calls, post: async (route, body) => { calls.push([route, body]); return { data: { token: 't', serverTime: 1 } }; } };
};

test('a trial request carries the machine id, platform, architecture and app version, and nothing that identifies a person', async () => {
  const http = fakeHttp();
  await new HttpLicenseProvider({ baseUrl: 'http://x', http, appVersion: '1.2.3' }).startTrial({ machineId: 'm1', fingerprintSource: 'darwin' });
  const [route, body] = http.calls[0];
  assert.equal(route, '/trial');
  assert.deepEqual(Object.keys(body).sort(), ['appVersion', 'arch', 'fingerprintSource', 'machineId', 'platform']);
  assert.equal(body.platform, process.platform);
  assert.equal(body.arch, process.arch);
  assert.equal(body.appVersion, '1.2.3');
  assert.equal(body.fingerprintSource, 'darwin');
});

test('the integration details are sent only when there are some', async () => {
  const http = fakeHttp();
  const provider = new HttpLicenseProvider({ baseUrl: 'http://x', http });
  await provider.startTrial({ machineId: 'm1', fingerprintSource: 'darwin', integration: { githubUrl: 'https://github.example.test', githubOrg: 'acme' } });
  assert.deepEqual(http.calls[0][1].integration, { githubUrl: 'https://github.example.test', githubOrg: 'acme' });
  await provider.startTrial({ machineId: 'm1', fingerprintSource: 'darwin', integration: null });
  assert.equal('integration' in http.calls[1][1], false);
});

function fakeHttpAnswering(handler) {
  const calls = [];
  return { calls, post: async (route, body, config) => { calls.push([route, body, config]); return handler(route, body); } };
}

test('asking for an emailed code sends the machine and the address', async () => {
  const http = fakeHttpAnswering(() => ({ data: { ok: true, sentTo: 'p***@acme.example.test' } }));
  const out = await new HttpLicenseProvider({ baseUrl: 'http://x', http }).requestEmailCode({ machineId: 'm1', email: 'pat@acme.example.test' });
  assert.equal(http.calls[0][0], '/domain/otp');
  assert.deepEqual({ machineId: http.calls[0][1].machineId, email: http.calls[0][1].email }, { machineId: 'm1', email: 'pat@acme.example.test' });
  assert.equal(out.sentTo, 'p***@acme.example.test');
});

test('activating by email returns a token like any other activation', async () => {
  const http = fakeHttpAnswering(() => ({ data: { token: 'tok', serverTime: 5 } }));
  const out = await new HttpLicenseProvider({ baseUrl: 'http://x', http }).activateByEmail({ machineId: 'm1', email: 'pat@acme.example.test', code: '123456' });
  assert.equal(http.calls[0][0], '/domain/activate');
  assert.equal(http.calls[0][1].code, '123456');
  assert.equal(out.token, 'tok');
});

test('a purchase request goes to the service as given', async () => {
  const http = fakeHttpAnswering(() => ({ data: { ok: true, reference: 'PR-0001' } }));
  const out = await new HttpLicenseProvider({ baseUrl: 'http://x', http }).submitPurchaseRequest({ organization: 'Acme' });
  assert.equal(http.calls[0][0], '/purchase-request');
  assert.equal(http.calls[0][1].organization, 'Acme');
  assert.equal(out.reference, 'PR-0001');
});

test('a purchase request carries its Idempotency-Key as a header, and no header when there is none', async () => {
  const http = fakeHttpAnswering(() => ({ data: { ok: true, reference: 'PR-0001' } }));
  const provider = new HttpLicenseProvider({ baseUrl: 'http://x', http });
  await provider.submitPurchaseRequest({ organization: 'Acme' }, { idempotencyKey: 'buy-abcdef12' });
  await provider.submitPurchaseRequest({ organization: 'Acme' });
  assert.deepEqual(http.calls[0][2], { headers: { 'Idempotency-Key': 'buy-abcdef12' } });
  assert.equal(http.calls[0][1].idempotencyKey, undefined, 'the key travels as a header, never in the body');
  assert.equal(http.calls[1][2], undefined);
});

test('a refusal from the service keeps its reason and per-field messages; an outage is unreachable', async () => {
  const refused = fakeHttpAnswering(() => { const e = new Error('x'); e.response = { status: 400, data: { message: 'Some details need fixing.', reason: 'invalid', errors: { email: 'bad' } } }; throw e; });
  await assert.rejects(new HttpLicenseProvider({ baseUrl: 'http://x', http: refused }).submitPurchaseRequest({}), err =>
    err.rejected && err.details.reason === 'invalid' && err.details.errors.email === 'bad');
  const down = fakeHttpAnswering(() => { throw new Error('connect ECONNREFUSED'); });
  await assert.rejects(new HttpLicenseProvider({ baseUrl: 'http://x', http: down }).requestEmailCode({ machineId: 'm', email: 'a@b.co' }), err => err.unreachable);
  const empty = fakeHttpAnswering(() => ({ data: {} }));
  await assert.rejects(new HttpLicenseProvider({ baseUrl: 'http://x', http: empty }).activateByEmail({ machineId: 'm', email: 'a@b.co', code: '123456' }), err => err.unreachable,
    'a 200 with no token is our own fault, never a refusal');
});

test('the Buy form asks for a code, and checks it, through the purchase-request routes', async () => {
  const http = fakeHttpAnswering(route => ({ data: route === '/purchase-request/otp' ? { ok: true, sentTo: 'p***@acme.example.test' } : { ok: true, verificationToken: '123.abc' } }));
  const provider = new HttpLicenseProvider({ baseUrl: 'http://x', http });
  const asked = await provider.requestPurchaseCode({ machineId: 'm1', email: 'pat@acme.example.test' });
  const checked = await provider.verifyPurchaseCode({ machineId: 'm1', email: 'pat@acme.example.test', code: '123456' });
  assert.equal(http.calls[0][0], '/purchase-request/otp');
  assert.equal(http.calls[0][1].machineId, 'm1');
  assert.equal(http.calls[1][0], '/purchase-request/verify');
  assert.equal(http.calls[1][1].code, '123456');
  assert.equal(asked.sentTo, 'p***@acme.example.test');
  assert.equal(checked.verificationToken, '123.abc');
});
