'use strict';

// The setup facts the app sends with a trial request, cleaned.
//
// Only addresses and the organisation name ever leave the machine. A token or
// password must not travel with them, so every address is rebuilt from its scheme,
// host and path alone: credentials in the address (https://user:token@host), a
// query string and a fragment are all dropped, and any field that is not on the
// short list below is ignored. The licence service applies the same function again
// to whatever it receives (tools/license-service-dev.js), so neither side trusts
// the other.

const MAX_URL = 300;
const ORG = /^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/;

function cleanUrl(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > MAX_URL) return null;
  let u;
  try { u = new URL(value); } catch (_) { return null; }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  const path = u.pathname.replace(/\/+$/, '');
  return `${u.protocol}//${u.host}${path}`;
}

function sanitizeIntegration(input) {
  if (!input || typeof input !== 'object') return null;
  const out = {};
  const jenkinsUrl = cleanUrl(input.jenkinsUrl);
  const githubUrl = cleanUrl(input.githubUrl);
  if (jenkinsUrl) out.jenkinsUrl = jenkinsUrl;
  if (githubUrl) out.githubUrl = githubUrl;
  // The organisation arrives as `org` from the session, or as `githubOrg` when already cleaned
  // once (the licence service cleans again), so cleaning twice gives the same answer.
  const org = input.org !== undefined ? input.org : input.githubOrg;
  if (typeof org === 'string' && ORG.test(org)) out.githubOrg = org;
  return Object.keys(out).length ? out : null;
}

module.exports = { sanitizeIntegration };
