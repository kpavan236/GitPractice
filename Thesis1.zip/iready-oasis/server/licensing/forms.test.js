'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { normaliseEmail, domainOf, validatePurchaseRequest } = require('./forms');

test('an email is tidied: trimmed and lower-cased', () => {
  assert.equal(normaliseEmail('  Pat.Example@ACME.Example.Test '), 'pat.example@acme.example.test');
});

test('things that are not a single email address are refused', () => {
  for (const bad of ['', '   ', 'no-at-sign', 'two@@signs.com', 'a@b', 'a b@c.com', 'a@b .com', '@acme.com', 'pat@', 'a@b.c',
    'pat@acme.com, sam@acme.com', 'pat@acme.com\nbcc@evil.test', `${'a'.repeat(250)}@acme.com`, null, undefined, 42, {}]) {
    assert.equal(normaliseEmail(bad), null, `${JSON.stringify(bad)} must be refused`);
  }
});

test('the domain is the part after the @, lower-case', () => {
  assert.equal(domainOf('Pat@Sub.ACME.Example.Test'), 'sub.acme.example.test');
  assert.equal(domainOf('nonsense'), null);
});

const GOOD = { organization: 'Acme Example Ltd', employees: '250', email: 'Pat@Acme.Example.Test', contactName: 'Pat Example' };

test('a complete purchase request is accepted and tidied', () => {
  const r = validatePurchaseRequest(GOOD);
  assert.equal(r.ok, true);
  assert.deepEqual(r.value, { organization: 'Acme Example Ltd', employees: 250, email: 'pat@acme.example.test', contactName: 'Pat Example' });
});

test('every missing field is reported, each by name, all at once', () => {
  const r = validatePurchaseRequest({});
  assert.equal(r.ok, false);
  assert.deepEqual(Object.keys(r.errors).sort(), ['contactName', 'email', 'employees', 'organization']);
});

test('the number of employees must be a whole number from 1 to 1,000,000', () => {
  for (const ok of [1, '1', ' 250 ', 1000000, '1000000']) assert.equal(validatePurchaseRequest({ ...GOOD, employees: ok }).ok, true, String(ok));
  for (const bad of [0, '0', -5, '1.5', 'many', '', null, 1000001, '1e3', '12abc', NaN, Infinity]) {
    const r = validatePurchaseRequest({ ...GOOD, employees: bad });
    assert.equal(r.ok, false, `${String(bad)} must be refused`);
    assert.ok(r.errors.employees);
  }
});

test('text fields have sensible limits, and a bad one names only itself', () => {
  const r = validatePurchaseRequest({ ...GOOD, organization: 'x'.repeat(201), contactName: 'y'.repeat(151) });
  assert.deepEqual(Object.keys(r.errors).sort(), ['contactName', 'organization']);
  assert.equal(validatePurchaseRequest({ ...GOOD, organization: '   ' }).ok, false, 'blank is missing');
});

test('control characters are stripped, and a line break in a one-line field becomes a space', () => {
  const r = validatePurchaseRequest({ ...GOOD, organization: 'Acme\u0000\u0007 Ltd', contactName: 'Pat\u0001 Example' });
  assert.equal(r.ok, true);
  assert.equal(r.value.organization, 'Acme Ltd');
  assert.equal(r.value.contactName, 'Pat Example');
  assert.equal(validatePurchaseRequest({ ...GOOD, organization: 'Acme\nLtd' }).value.organization, 'Acme Ltd');
});

test('fields the form no longer asks for, and any other extras, never come through', () => {
  const r = validatePurchaseRequest({ ...GOOD, phone: '+1 555 010 0100', requirement: 'Seats please', status: 'APPROVED', expiry: '2099-01-01', isAdmin: true });
  assert.equal(r.ok, true);
  assert.deepEqual(Object.keys(r.value).sort(), ['contactName', 'email', 'employees', 'organization']);
});

test('the same input gives the same answer when tidied twice', () => {
  const once = validatePurchaseRequest(GOOD).value;
  assert.deepEqual(validatePurchaseRequest(once).value, once);
});
