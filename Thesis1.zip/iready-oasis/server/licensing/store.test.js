'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { load, save, update, clear, EMPTY } = require('./store');

function tmpPath(name) {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-license-')), name);
}

test('a missing file reads as empty state rather than failing', () => {
  const state = load(tmpPath('absent.json'));
  assert.deepEqual(state, EMPTY);
});

test('state survives a save and load round trip', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def', lastCheckAt: 123, machineId: 'm1' });
  const state = load(p);
  assert.equal(state.token, 'abc.def');
  assert.equal(state.lastCheckAt, 123);
  assert.equal(state.machineId, 'm1');
});

test('a saved file keeps the defaults for keys the caller omitted', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def' });
  assert.equal(load(p).revokedAt, null);
});

test('a file written by an older version gains new keys instead of undefined reads', () => {
  const p = tmpPath('license.json');
  fs.writeFileSync(p, JSON.stringify({ token: 'abc.def' }));
  const state = load(p);
  assert.equal(state.token, 'abc.def');
  assert.equal(state.revokedAt, null);
  assert.equal(state.lastServerTimeSeen, null);
});

test('a corrupt file starts clean instead of bricking the app', () => {
  // A truncated write after a power cut must not leave OASIS unable to start.
  const p = tmpPath('license.json');
  fs.writeFileSync(p, '{"token": "abc.de');
  assert.deepEqual(load(p), EMPTY);
});

test('a file containing something other than an object is ignored', () => {
  const p = tmpPath('license.json');
  fs.writeFileSync(p, '["not", "an", "object"]');
  assert.deepEqual(load(p), EMPTY);
});

test('update merges a patch over what is already stored', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def', lastCheckAt: 1 });
  const merged = update(p, { lastCheckAt: 2 });
  assert.equal(merged.token, 'abc.def');
  assert.equal(merged.lastCheckAt, 2);
  assert.equal(load(p).lastCheckAt, 2);
});

test('the licence file is not world readable', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def' });
  assert.equal(fs.statSync(p).mode & 0o077, 0);
});

test('no temporary file is left behind by the atomic write', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def' });
  assert.equal(fs.existsSync(`${p}.tmp`), false);
});

test('clearing removes the file and reads back as empty', () => {
  const p = tmpPath('license.json');
  save(p, { token: 'abc.def' });
  clear(p);
  assert.equal(fs.existsSync(p), false);
  assert.deepEqual(load(p), EMPTY);
});

test('clearing a file that is already gone is not an error', () => {
  assert.doesNotThrow(() => clear(tmpPath('absent.json')));
});

test('saving into an unwritable location reports failure instead of throwing', () => {
  assert.equal(save('/proc/definitely/not/writable/license.json', { token: 'x' }), false);
});