'use strict';
const fs = require('fs');

// The verification key and service endpoint the app is built against.
//
// Only the PUBLIC half is ever in this repository or in a build artifact. The
// private key signs entitlement tokens on the licence service and belongs in a
// secret manager — if it leaks, anyone can mint themselves a perpetual
// enterprise licence and the only remedy is shipping a new build with a new
// public key.

// DEVELOPMENT KEY — generated for local work and tests. It is checked in on
// purpose so the app runs from a fresh clone, and it is worthless: the matching
// private key is not in this repo and not in any build. A release build MUST
// override this with the production public key via OASIS_LICENSE_PUBLIC_KEY or
// by replacing this constant at package time.
const DEV_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEATec32+UVEhOydGu5pGNkmT+01XIelEoBkhH/bjEbdLk=
-----END PUBLIC KEY-----
`;

const DEV_KID = 'dev';

// Where the app looks for the licence service when nothing is configured.
//
// Until a hosted service exists this is the licence service (oasis-licence-service, port 4020, routes under /v1)
// on THIS computer. It is a loopback address on purpose: a build that
// ships without a real address set can only ever talk to the machine it runs on, never
// to somebody else's server, and fails closed (locked, with a plain "could not reach the
// licence service") when nothing is listening. A release build sets OASIS_LICENSE_URL, or
// replaces this constant at package time, with the real address.
const DEFAULT_LICENSE_SERVICE_URL = 'http://localhost:4020/v1';

// Accepts either a PEM string or a path to one, so an installer can drop the
// key on disk instead of threading a multi-line value through the environment.
function resolvePublicKey(value) {
  if (!value) return DEV_PUBLIC_KEY;
  if (value.includes('BEGIN PUBLIC KEY')) return value;
  try {
    return fs.readFileSync(value, 'utf8');
  } catch (_) {
    return DEV_PUBLIC_KEY;
  }
}

function licensePublicKey(env = process.env) {
  return resolvePublicKey(env.OASIS_LICENSE_PUBLIC_KEY);
}

// The set of public keys this build will accept, as [{ kid, pem }].
//
// More than one on purpose. Rotating a signing key is otherwise a flag day:
// the moment the service starts signing with a new key, every already-issued
// licence stops verifying and every customer needs a new build on the same
// afternoon. With a set, the app trusts the retiring and the incoming key at
// once, the service switches over whenever it likes, and the old key is dropped
// from the set a release later.
//
// This matters most in the case you cannot plan for: if the signing key leaks,
// rotation is the remedy, and it has to be something you can do in a hurry.
//
// OASIS_LICENSE_PUBLIC_KEYS takes a JSON array — or a path to one:
//   [{"kid":"2026-08","pem":"-----BEGIN PUBLIC KEY-----\n..."}, ...]
function trustedKeys(env = process.env) {
  const raw = env.OASIS_LICENSE_PUBLIC_KEYS;
  if (raw) {
    const text = raw.trim().startsWith('[') ? raw : readFileOrNull(raw);
    const parsed = parseKeySet(text);
    if (parsed.length) return parsed;
  }
  if (env.OASIS_LICENSE_PUBLIC_KEY) {
    return [{ kid: null, pem: resolvePublicKey(env.OASIS_LICENSE_PUBLIC_KEY) }];
  }
  return [{ kid: DEV_KID, pem: DEV_PUBLIC_KEY }];
}

function readFileOrNull(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch (_) {
    return null;
  }
}

// A malformed key set must not silently fall back to trusting nothing — that
// locks every customer out — nor to trusting the development key, which would
// be worse. Callers get an empty list and trustedKeys() moves to the next
// source, so a typo in one variable is recoverable.
function parseKeySet(text) {
  if (!text) return [];
  try {
    const parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(k => k && typeof k.pem === 'string' && k.pem.includes('BEGIN PUBLIC KEY'))
      .map(k => ({ kid: k.kid || null, pem: k.pem }));
  } catch (_) {
    return [];
  }
}

function licenseServiceUrl(env = process.env) {
  return env.OASIS_LICENSE_URL || DEFAULT_LICENSE_SERVICE_URL;
}

function isDevelopmentKey(pem) {
  return pem.trim() === DEV_PUBLIC_KEY.trim();
}

// Whether this build enforces licensing at all.
//
// ON by default, so the "Start trial" and "Activate licence" options are there from the
// first launch with nothing to configure. A build that must run without licensing (an
// internal tool, a demo) opts out.
//
// Without a reachable licence service an enforced app is locked, because that is what
// "fails closed" means; the way out for a build that wants no licensing at all is
// OASIS_LICENSE_DISABLED=1.
//
// Precedence, highest first:
//   OASIS_LICENSE_DISABLED=1  always off, even on a commercial build
//   anything else             on (OASIS_LICENSE_ENABLED=1 and OASIS_LICENSE_URL still work,
//                             and are now simply what the default already is)
// Where someone with no licence goes to get one.
//
// Only OASIS_PURCHASE_URL names it. The licence service has no pricing page (the lock screen's
// Buy licence form sends a request to the support team instead), so a default derived from
// OASIS_LICENSE_URL would be a broken link. A build without it shows no link, which is why this
// can return null.
function purchaseUrl(env = process.env) {
  return env.OASIS_PURCHASE_URL || null;
}

function licensingEnabled(env = process.env) {
  return env.OASIS_LICENSE_DISABLED !== '1';
}

// True when no address was configured and the built-in default is in use.
function isDefaultServiceUrl(env = process.env) {
  return !env.OASIS_LICENSE_URL;
}

module.exports = {
  DEV_PUBLIC_KEY,
  DEV_KID,
  DEFAULT_LICENSE_SERVICE_URL,
  licensePublicKey,
  trustedKeys,
  parseKeySet,
  licenseServiceUrl,
  isDevelopmentKey,
  licensingEnabled,
  isDefaultServiceUrl,
  purchaseUrl,
  resolvePublicKey,
};