'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  getTier,
  isKnownTier,
  hasFeature,
  grantedFeatures,
  allowsOfflineActivation,
  seatLimit,
  graceDays,
  FEATURES,
  ALL_FEATURES,
} = require('./tiers');

test('the trial grants no paid features', () => {
  // Version Watch and Security are what a licence buys. Showing them for a
  // week and then withdrawing them demonstrates a loss, not a value.
  assert.deepEqual(grantedFeatures(getTier('trial')), []);
  assert.equal(hasFeature(getTier('trial'), 'version-watch'), false);
  assert.equal(hasFeature(getTier('trial'), 'security'), false);
});

test('enterprise is the only tier holding the wildcard', () => {
  assert.equal(getTier('enterprise').features, ALL_FEATURES);
});

test('the trial runs 7 days — it is the only way to run OASIS unlicensed', () => {
  // The core tabs work without a licence for exactly this long. Shortening it
  // shortens the free period for the whole product, not just the paid tabs.
  assert.equal(getTier('trial').termDays, 7);
});

test('enterprise is the only tier that may activate offline', () => {
  assert.equal(allowsOfflineActivation('enterprise'), true);
  for (const tier of ['trial', 'individual', 'team']) {
    assert.equal(allowsOfflineActivation(tier), false, `${tier} must not activate offline`);
  }
});

test('enterprise seats are uncounted rather than zero', () => {
  // null, not 0 — a caller comparing against a number must be forced to think
  // about what "site licence" means instead of reading it as "no seats".
  assert.equal(seatLimit('enterprise'), null);
  assert.equal(seatLimit('team'), 10);
  assert.equal(seatLimit('individual'), 1);
});

test('enterprise gets a longer grace window than the per-seat tiers', () => {
  assert.equal(graceDays('enterprise'), 30);
  assert.equal(graceDays('team'), 14);
  assert.equal(graceDays('trial'), 0);
});

test('an unknown tier is not treated as a licence', () => {
  assert.equal(getTier('platinum'), null);
  assert.equal(isKnownTier('platinum'), false);
  assert.equal(allowsOfflineActivation('platinum'), false);
  assert.equal(seatLimit('platinum'), 0);
});

test('a wildcard entitlement covers features shipped after it was issued', () => {
  // The whole reason '*' is stored rather than an expanded list: the customer
  // bought "everything", not "everything as of this version".
  const entitlement = { features: ALL_FEATURES };
  for (const feature of FEATURES) {
    assert.equal(hasFeature(entitlement, feature), true);
  }
  assert.equal(hasFeature(entitlement, 'a-tab-we-have-not-built-yet'), true);
});

test('an explicit feature list grants only what it lists', () => {
  const entitlement = { features: ['version-watch'] };
  assert.equal(hasFeature(entitlement, 'version-watch'), true);
  assert.equal(hasFeature(entitlement, 'security'), false);
});

test('a missing or malformed entitlement grants nothing', () => {
  assert.equal(hasFeature(null, 'security'), false);
  assert.equal(hasFeature({}, 'security'), false);
  assert.equal(hasFeature({ features: 'everything' }, 'security'), false);
});

test('the expanded feature list drops keys the app does not know', () => {
  const expanded = grantedFeatures({ features: ['security', 'teleportation'] });
  assert.deepEqual(expanded, ['security']);
});

test('only Version Watch and Security are sold separately', () => {
  // Everything else is included in every tier. A key appearing here is a
  // pricing change; a key disappearing hands that feature to every tier.
  assert.deepEqual(FEATURES, ['version-watch', 'security']);
});

test('security is sold separately rather than included in every tier', () => {
  // If this key ever leaves FEATURES, grantedFeatures() silently drops it from
  // every entitlement and the security tab unlocks for everyone — a paid
  // feature given away by a deletion nobody would read as one.
  assert.ok(FEATURES.includes('security'));
  assert.deepEqual(grantedFeatures({ features: ['security'] }), ['security']);
});

test('the viewer tier sells version watch without security', () => {
  const viewer = getTier('viewer');
  assert.equal(hasFeature(viewer, 'version-watch'), true);
  assert.equal(hasFeature(viewer, 'security'), false);
});

test('the viewer-security tier is the viewer tier plus security', () => {
  const upgrade = getTier('viewer-security');
  assert.equal(hasFeature(upgrade, 'version-watch'), true);
  assert.equal(hasFeature(upgrade, 'security'), true);
});

test('the legacy tiers keep exactly what they already unlocked', () => {
  // Shortening FEATURES must not quietly downgrade a licence in the field.
  // team bought Version Watch and keeps it; individual never had it, and
  // everything individual did buy is now included in every tier.
  assert.deepEqual(grantedFeatures(getTier('team')), ['version-watch']);
  assert.deepEqual(grantedFeatures(getTier('individual')), []);
});

test('the narrow SKUs are seat-counted and cannot activate offline', () => {
  for (const id of ['viewer', 'viewer-security']) {
    assert.equal(seatLimit(id), 10, `${id} seats`);
    assert.equal(allowsOfflineActivation(id), false, `${id} must not activate offline`);
    assert.equal(graceDays(id), 14, `${id} grace`);
  }
});
test('the trial length comes from TRIAL_DURATION_DAYS, defaulting to 7', () => {
  const { trialTermDays } = require('./tiers');
  assert.equal(trialTermDays({}), 7);
  assert.equal(trialTermDays({ TRIAL_DURATION_DAYS: '' }), 7);
  assert.equal(trialTermDays({ TRIAL_DURATION_DAYS: '14' }), 14);
  assert.equal(trialTermDays({ TRIAL_DURATION_DAYS: '90' }), 90);
});

test('a bad TRIAL_DURATION_DAYS never changes the trial: it falls back to 7', () => {
  const { trialTermDays } = require('./tiers');
  const warnings = [];
  for (const bad of ['0', '-3', '91', '7.5', 'seven', '1e3', ' 14']) {
    assert.equal(trialTermDays({ TRIAL_DURATION_DAYS: bad }, m => warnings.push(m)), 7, `"${bad}" must be ignored`);
  }
  assert.equal(warnings.length, 7, 'each bad value is reported, not silently swallowed');
  assert.doesNotMatch(warnings[0], /seven/, 'the message names the setting, not the value');
});
