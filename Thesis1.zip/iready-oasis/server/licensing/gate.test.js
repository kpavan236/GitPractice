'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createLicenseGate } = require('./gate');

function fakeRes() {
  return {
    statusCode: null,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    },
  };
}

function run(gate, path) {
  const res = fakeRes();
  let passed = false;
  gate({ path }, res, () => {
    passed = true;
  });
  return { passed, res };
}

const LOCKED = {
  status: () => ({ locked: true, reason: 'trial_expired', message: 'Trial over.', features: [] }),
};

const TEAM = {
  status: () => ({
    locked: false,
    tier: 'team',
    tierLabel: 'Team',
    features: ['version-watch'],
  }),
};

const INDIVIDUAL = {
  status: () => ({
    locked: false,
    tier: 'individual',
    tierLabel: 'Individual',
    features: [],
  }),
};

const VIEWER = {
  status: () => ({
    locked: false,
    tier: 'viewer',
    tierLabel: 'Version Viewer',
    features: ['version-watch'],
  }),
};

const VIEWER_SECURITY = {
  status: () => ({
    locked: false,
    tier: 'viewer-security',
    tierLabel: 'Version Viewer + Security',
    features: ['version-watch', 'security'],
  }),
};

// Every core route, spelled out. These need A licence (or a live trial) but not
// a PARTICULAR one — if any of them starts mapping to a feature key, a tier has
// silently lost a tab it is supposed to include.
const CORE_ROUTES = [
  '/api/repos',
  '/api/setup',
  '/api/jira/issues',
  '/api/docker/containers',
  '/api/schedule/jobs',
  '/api/wellness/summary',
  '/api/dependency-graph',
];

test('a locked app refuses core routes too, once the trial is over', () => {
  // Core is included in every tier, not free: unlicensed OASIS runs for the
  // 7-day trial and then stops. An expired trial takes the whole app, which is
  // what separates "core" from "free".
  for (const path of CORE_ROUTES) {
    const { passed, res } = run(createLicenseGate(LOCKED), path);
    assert.equal(passed, false, `${path} must be refused`);
    assert.equal(res.statusCode, 402);
    assert.equal(res.body.error, 'license_required');
  }
});

test('a locked app refuses the paid routes with 402 as well', () => {
  for (const path of ['/api/version-watch/scan', '/api/security/findings']) {
    const { passed, res } = run(createLicenseGate(LOCKED), path);
    assert.equal(passed, false, `${path} must be refused`);
    assert.equal(res.statusCode, 402);
  }
});

test('a 402 on a paid route names the feature', () => {
  assert.equal(run(createLicenseGate(LOCKED), '/api/security/findings').res.body.feature, 'security');
  // ...and names nothing on a core route, because no single feature buys it.
  assert.equal(run(createLicenseGate(LOCKED), '/api/repos').res.body.feature, null);
});

test('a live trial reaches everything, core and paid alike', () => {
  // The 7-day trial is what makes an unlicensed machine usable at all.
  const TRIAL = {
    status: () => ({ locked: false, tier: 'trial', tierLabel: 'Trial', features: ['version-watch', 'security'] }),
  };
  for (const path of [...CORE_ROUTES, '/api/version-watch/scan', '/api/security/findings']) {
    assert.equal(run(createLicenseGate(TRIAL), path).passed, true, `${path} must be open on trial`);
  }
});

test('the licence API stays reachable while locked, or there is no way out', () => {
  for (const path of ['/api/license/status', '/api/license/activate', '/api/license/offline']) {
    const { passed } = run(createLicenseGate(LOCKED), path);
    assert.equal(passed, true, `${path} must not be gated`);
  }
});

test('health and identity checks stay reachable while locked', () => {
  assert.equal(run(createLicenseGate(LOCKED), '/api/health').passed, true);
  assert.equal(run(createLicenseGate(LOCKED), '/api/whoami').passed, true);
});

test('static assets are never gated, so the lock screen can load', () => {
  const { passed } = run(createLicenseGate(LOCKED), '/js/modules/license.js');
  assert.equal(passed, true);
});

test('a licensed tier reaches the features it paid for', () => {
  assert.equal(run(createLicenseGate(TEAM), '/api/version-watch/scan').passed, true);
});

test('core routes answer on every licensed tier, including one that bought nothing', () => {
  for (const path of CORE_ROUTES) {
    assert.equal(run(createLicenseGate(INDIVIDUAL), path).passed, true, `${path} must stay open`);
  }
});

test('JIRA, Docker, the scheduler and wellness are no longer sold separately', () => {
  // They were feature-gated once. Every tier gets them now — this is the test
  // that fails if one is quietly put back behind its own feature key.
  const { requiredFeature } = require('./gate');
  for (const path of CORE_ROUTES) {
    assert.equal(requiredFeature(path), null, `${path} must map to no feature`);
  }
});

test('a feature outside the tier is refused with 403, not 402', () => {
  // 402 means "buy something"; 403 means "you bought the wrong thing". The UI
  // shows a different message for each, so the codes must not be conflated.
  const { passed, res } = run(createLicenseGate(INDIVIDUAL), '/api/version-watch/scan');
  assert.equal(passed, false);
  assert.equal(res.statusCode, 403);
  assert.equal(res.body.error, 'feature_not_licensed');
  assert.equal(res.body.feature, 'version-watch');
});

test('the security API is gated, so the scanner is not free on every tier', () => {
  // The whole point of the SKU: /api/security answered for anyone with any
  // licence until it was added to FEATURE_ROUTES.
  const { passed, res } = run(createLicenseGate(VIEWER), '/api/security/findings');
  assert.equal(passed, false);
  assert.equal(res.statusCode, 403);
  assert.equal(res.body.feature, 'security');
});

test('the viewer-security tier reaches both halves of what it bought', () => {
  assert.equal(run(createLicenseGate(VIEWER_SECURITY), '/api/version-watch/scan').passed, true);
  assert.equal(run(createLicenseGate(VIEWER_SECURITY), '/api/security/scan').passed, true);
});

test('a viewer licence still reaches version watch', () => {
  assert.equal(run(createLicenseGate(VIEWER), '/api/version-watch/scan').passed, true);
});

test('a route that merely starts with a feature name is not mistaken for it', () => {
  // /api/dockerize is not /api/docker — prefix matching without a boundary
  // would gate routes nobody meant to gate.
  const { passed } = run(createLicenseGate(INDIVIDUAL), '/api/jirassic-park');
  assert.equal(passed, true);
  assert.equal(run(createLicenseGate(VIEWER), '/api/security-headers').passed, true);
});
// The trial starts when setup finishes, so the wizard has to work before any trial exists.
const UNREGISTERED = { status: () => ({ locked: true, status: 'unregistered', reason: 'no_entitlement', message: 'Start your trial.', features: [] }) };

test('the setup wizard works before a trial exists', () => {
  for (const path of ['/api/validate-github', '/api/validate-jenkins', '/api/session', '/api/detect-tools',
                      '/api/pick-directory', '/api/aws-profiles', '/api/prefs', '/api/external-calls', '/api/whoami', '/api/license/status']) {
    assert.equal(run(createLicenseGate(UNREGISTERED), path).passed, true, `${path} must be open during setup`);
  }
});

test('everything the app does after setup stays locked until the trial has started', () => {
  for (const path of ['/api/repos', '/api/repos/count', '/api/existing-repos', '/api/setup', '/api/pull', '/api/branches',
                      '/api/dependency-graph', '/api/jira/history', '/api/version-watch', '/api/security/findings', '/api/notes', '/api/chat']) {
    const { passed, res } = run(createLicenseGate(UNREGISTERED), path);
    assert.equal(passed, false, `${path} must stay locked`);
    assert.equal(res.statusCode, 402, path);
  }
});

test('opening the wizard routes opens nothing next to them (the patterns are exact)', () => {
  for (const path of ['/api/prefs/anything', '/api/session/abc', '/api/validate-github/x', '/api/sessions', '/api/external-calls/x']) {
    assert.equal(run(createLicenseGate(UNREGISTERED), path).passed, false, `${path} must not slip through`);
  }
});
