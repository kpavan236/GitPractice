'use strict';
const { verifyToken } = require('./token');
const { evaluate, REVALIDATE_INTERVAL_MS } = require('./state');
const storeModule = require('./store');
const { allowsOfflineActivation, getTier } = require('./tiers');
const { LicenseServiceError } = require('./provider');
const { createRequestCode } = require('./offline-request');
const { sanitizeIntegration } = require('./integration');
const { cleanIdempotencyKey, normaliseEmail, validatePurchaseRequest } = require('./forms');

// Ties the pieces together: the store holds the token, the provider fetches new
// ones, token.js proves they are ours, and state.js decides what they mean.
// Everything with a side effect lives here so the state machine can stay pure.

function createLicenseService({
  storePath = storeModule.DEFAULT_PATH,
  provider,
  purchaseUrl = null,
  keys,
  machineId,
  // Where the fingerprint came from ('darwin', 'win32', 'linux' or 'fallback'),
  // sent with the trial request so the service can tell a hardware id from a
  // hostname-based guess.
  fingerprintSource = null,
  serviceUrl = null,
  appVersion = null,
  now = () => Date.now(),
  store = storeModule,
  log = () => {},
} = {}) {
  if (!provider) throw new Error('createLicenseService requires a provider');
  if (!keys) throw new Error('createLicenseService requires keys');
  if (!machineId) throw new Error('createLicenseService requires a machineId');

  let timer = null;

  function readEntitlement(state) {
    if (!state.token) return { entitlement: null, tokenError: null };
    const result = verifyToken(state.token, keys);
    if (!result.valid) {
      // A token that does not verify is worth no more than no token at all.
      // The reason is surfaced so the UI can distinguish "you have not
      // activated" from "your licence file is damaged or was tampered with".
      return { entitlement: null, tokenError: result.reason };
    }
    return { entitlement: result.payload, tokenError: null };
  }

  function status() {
    const state = store.load(storePath);
    const { entitlement, tokenError } = readEntitlement(state);
    const evaluated = evaluate({
      entitlement,
      lastCheckAt: state.lastCheckAt,
      lastServerTimeSeen: state.lastServerTimeSeen,
      revokedAt: state.revokedAt,
      rejection: state.rejection,
      now: now(),
    });

    const tier = entitlement ? getTier(entitlement.tier) : null;
    return {
      ...evaluated,
      tierLabel: tier ? tier.label : null,
      // For wording only ("Start 7-day free trial"). The expiry that counts is
      // always the one the service stamped into the token.
      trialDays: getTier('trial').termDays,
      tokenError,
      machineId,
      lastCheckAt: state.lastCheckAt,
      // Surfaced so "could not reach the licence service" can be diagnosed
      // from the UI. Without it, a build pointed at the wrong host looks
      // identical to a service that is genuinely down.
      serviceUrl,
      // Where to send someone who has no key. Null when the build has no idea,
      // in which case the UI shows no link rather than a broken one.
      purchaseUrl,
    };
  }

  // Records a token the service just handed us, along with the service's own
  // clock. That server timestamp is what later makes clock tampering
  // detectable, so it is stored on every successful exchange.
  function acceptToken({ token, serverTime }) {
    const at = now();
    store.update(storePath, {
      token,
      lastCheckAt: at,
      lastServerTimeSeen: typeof serverTime === 'number' ? serverTime : at,
      // Both cleared: the service has just accepted this machine, so whatever
      // it refused for is over. Leaving either set keeps a renewed licence
      // locked against a record of a refusal that no longer applies.
      revokedAt: null,
      rejection: null,
      machineId,
      installedAt: store.load(storePath).installedAt || at,
    });
    return status();
  }

  // `integration` is what the customer entered in the setup wizard (addresses and
  // organisation only). It is cleaned here too, so a token that slipped into an address
  // can never reach the licence service.
  async function startTrial({ integration = null } = {}) {
    const result = await provider.startTrial({ machineId, fingerprintSource, integration: sanitizeIntegration(integration) });
    return acceptToken(result);
  }

  // ── Activate by email: the organisation holds the licence, the person proves they belong to it ──

  async function requestEmailCode({ email } = {}) {
    const address = normaliseEmail(email);
    if (!address) throw new LicenseServiceError('rejected', 'Enter a valid email address.', { reason: 'bad_email' });
    return provider.requestEmailCode({ machineId, email: address });
  }

  async function activateByEmail({ email, code } = {}) {
    const address = normaliseEmail(email);
    if (!address) throw new LicenseServiceError('rejected', 'Enter a valid email address.', { reason: 'bad_email' });
    const digits = typeof code === 'string' ? code.trim() : '';
    // A code that cannot be right is not worth a round trip, and not worth one of the five tries.
    if (!/^\d{6}$/.test(digits)) throw new LicenseServiceError('rejected', 'Enter the 6-digit code from the email.', { reason: 'wrong_code' });
    const result = await provider.activateByEmail({ machineId, email: address, code: digits });
    return acceptToken(result);
  }

  // ── Buy a licence: the request goes to the support team, who contact the customer ──

  // The email on a purchase request is proved with a one-time code first. The service decides who may use a code (work addresses only)
  // and checks the proof again; these checks only save a round trip for what cannot be right.
  async function requestPurchaseCode({ email } = {}) {
    const address = normaliseEmail(email);
    if (!address) throw new LicenseServiceError('rejected', 'Enter a valid email address.', { reason: 'bad_email' });
    return provider.requestPurchaseCode({ machineId, email: address });
  }

  async function verifyPurchaseCode({ email, code } = {}) {
    const address = normaliseEmail(email);
    if (!address) throw new LicenseServiceError('rejected', 'Enter a valid email address.', { reason: 'bad_email' });
    const digits = typeof code === 'string' ? code.trim() : '';
    if (!/^\d{6}$/.test(digits)) throw new LicenseServiceError('rejected', 'Enter the 6-digit code from the email.', { reason: 'wrong_code' });
    return provider.verifyPurchaseCode({ machineId, email: address, code: digits });
  }

  const PROOF = /^\d{1,15}\.[0-9a-f]{64}$/;

  async function submitPurchaseRequest(details, { idempotencyKey = null } = {}) {
    const checked = validatePurchaseRequest(details);
    if (!checked.ok) throw new LicenseServiceError('rejected', 'Some details need fixing.', { reason: 'invalid', errors: checked.errors });
    const token = details && details.verificationToken;
    if (typeof token !== 'string' || !PROOF.test(token)) {
      throw new LicenseServiceError('rejected', 'Verify your email address with the code we send you before submitting.', { reason: 'email_not_verified' });
    }
    return provider.submitPurchaseRequest({ ...checked.value, machineId, verificationToken: token }, { idempotencyKey: cleanIdempotencyKey(idempotencyKey) });
  }

  async function activate(licenseKey) {
    if (!licenseKey || typeof licenseKey !== 'string' || !licenseKey.trim()) {
      throw new LicenseServiceError('rejected', 'Enter a licence key.');
    }
    const result = await provider.activate({ machineId, licenseKey: licenseKey.trim() });
    return acceptToken(result);
  }

  // The code an administrator carries to the vendor portal to obtain a response
  // code for THIS machine. Safe to display, log, and email: it carries a
  // fingerprint digest and a nonce, and nothing that is worth keeping secret.
  function offlineRequestCode() {
    return createRequestCode({ machineId, appVersion, now });
  }

  // Enterprise offline activation, step 4: install the response code the portal
  // issued for this machine. No network call is made at any point in this path
  // — that is the whole reason the tier exists.
  //
  // The response code is bound to a machine and refused on any other. That
  // binding is what separates offline activation from simply handing a customer
  // a file that runs anywhere: an air-gapped site still gets seat integrity,
  // and a leaked licence unlocks exactly one machine.
  function installOfflineLicense(tokenString) {
    const result = verifyToken(typeof tokenString === 'string' ? tokenString.trim() : '', keys);
    if (!result.valid) {
      throw new LicenseServiceError('rejected', 'That licence file is not valid.', {
        reason: result.reason,
      });
    }
    const payload = result.payload;
    if (payload.offline !== true) {
      throw new LicenseServiceError(
        'rejected',
        'That is an online licence. Use "Activate with key" instead.'
      );
    }
    if (!allowsOfflineActivation(payload.tier)) {
      throw new LicenseServiceError(
        'rejected',
        `Offline activation is available on enterprise licences only (this file is ${payload.tier}).`
      );
    }
    if (payload.exp <= now()) {
      throw new LicenseServiceError('rejected', 'That licence file has already expired.');
    }
    // The binding check. An unbound response code is refused outright rather
    // than accepted as a permissive site licence — otherwise the weaker form
    // survives as a quiet fallback and every enterprise deal drifts back to it.
    if (!payload.machineId) {
      throw new LicenseServiceError(
        'rejected',
        'That licence file is not bound to a machine. Request a new one using this machine\'s activation request code.'
      );
    }
    if (payload.machineId !== machineId) {
      throw new LicenseServiceError(
        'rejected',
        'That licence file was issued for a different machine. Use this machine\'s activation request code to request its own.'
      );
    }

    const at = now();
    store.update(storePath, {
      token: tokenString.trim(),
      // Deliberately null: there was no server contact, so there is no
      // freshness to record and no server clock to compare against later.
      lastCheckAt: null,
      lastServerTimeSeen: null,
      revokedAt: null,
      machineId,
      installedAt: store.load(storePath).installedAt || at,
    });
    return status();
  }

  async function deactivate() {
    const state = store.load(storePath);
    if (state.token) {
      try {
        await provider.deactivate({ machineId, token: state.token });
      } catch (err) {
        // Frees the seat locally regardless. A user who cannot reach the
        // service while decommissioning a laptop should not be stuck holding a
        // seat; the service reconciles when that machine fails to revalidate.
        log('license: deactivate could not reach the service', err.message);
      }
    }
    store.clear(storePath);
    return status();
  }

  // Called on a timer and on demand. Never throws: a failed revalidation is an
  // expected condition that the grace window exists to absorb.
  async function revalidateIfDue({ force = false } = {}) {
    const current = status();
    if (!current.revalidateDue && !force) return current;
    if (!current.tier || current.offline) return current;

    const state = store.load(storePath);
    if (!state.token) return current;

    try {
      const result = await provider.revalidate({ machineId, token: state.token });
      return acceptToken(result);
    } catch (err) {
      if (err instanceof LicenseServiceError && err.rejected) {
        // The service answered and said this licence is no longer good here.
        // Record WHY as well as THAT: this used to store `revokedAt` for every
        // rejection, so an expired licence told the customer it had been
        // revoked and sent them to their administrator instead of to renewal.
        //
        // `reason` is the service's machine-readable code (see the licence
        // service's reject()). A service that sends none leaves it null, and
        // state.js reports the service's prose rather than inventing a cause.
        const details = err.details || {};
        store.update(storePath, {
          rejection: {
            at: now(),
            reason: typeof details.reason === 'string' ? details.reason : null,
            message: err.message,
          },
        });
        log('license: revalidation rejected —', details.reason || 'no reason given', '—', err.message);
        return status();
      }
      // Unreachable: keep the cached token and let grace do its job.
      log('license: revalidation deferred —', err.message);
      return status();
    }
  }

  function startRevalidationTimer(intervalMs = REVALIDATE_INTERVAL_MS) {
    if (timer) return;
    timer = setInterval(() => {
      revalidateIfDue().catch(() => {});
    }, intervalMs);
    // Do not hold the process open for a licence check.
    if (typeof timer.unref === 'function') timer.unref();
  }

  function stopRevalidationTimer() {
    if (timer) clearInterval(timer);
    timer = null;
  }

  // The credential an install presents when asking the licence service for
  // something other than a licence — currently the rule bundle.
  //
  // Deliberately NOT part of status(): status() is serialised to the renderer,
  // and a token on that path would put the licence in the browser and in any
  // log that captures an API response. This is a separate, server-side-only
  // accessor for exactly that reason.
  function credential() {
    const state = store.load(storePath);
    if (!state.token) return null;
    return { token: state.token, machineId };
  }

  return {
    status,
    credential,
    startTrial,
    requestEmailCode,
    activateByEmail,
    requestPurchaseCode,
    verifyPurchaseCode,
    submitPurchaseRequest,
    activate,
    offlineRequestCode,
    installOfflineLicense,
    deactivate,
    revalidateIfDue,
    startRevalidationTimer,
    stopRevalidationTimer,
  };
}

module.exports = { createLicenseService };