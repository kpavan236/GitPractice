'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { machineFingerprint, rawMachineId } = require('./fingerprint');

function deps(overrides = {}) {
  return {
    platform: () => 'darwin',
    exec: () => '"IOPlatformUUID" = "AAAA-BBBB-CCCC"',
    readFile: () => null,
    hostname: () => 'test-host',
    homedir: () => '/Users/test',
    ...overrides,
  };
}

test('the macOS platform UUID is read from ioreg', () => {
  assert.equal(rawMachineId(deps()), 'AAAA-BBBB-CCCC');
});

test('the Windows machine GUID is read from the registry', () => {
  const d = deps({
    platform: () => 'win32',
    exec: () =>
      'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography\r\n    MachineGuid    REG_SZ    4d7e1f22-1111-2222-3333-abcdefabcdef\r\n',
  });
  assert.equal(rawMachineId(d), '4d7e1f22-1111-2222-3333-abcdefabcdef');
});

test('the Linux machine id is read from /etc/machine-id', () => {
  const d = deps({
    platform: () => 'linux',
    readFile: file => (file === '/etc/machine-id' ? 'deadbeef1234\n' : null),
  });
  assert.equal(rawMachineId(d), 'deadbeef1234');
});

test('Linux falls through to the dbus machine id', () => {
  const d = deps({
    platform: () => 'linux',
    readFile: file => (file === '/var/lib/dbus/machine-id' ? 'cafebabe\n' : null),
  });
  assert.equal(rawMachineId(d), 'cafebabe');
});

test('the same machine derives the same fingerprint every time', () => {
  assert.equal(machineFingerprint(deps()).id, machineFingerprint(deps()).id);
});

test('different machines derive different fingerprints', () => {
  const a = machineFingerprint(deps());
  const b = machineFingerprint(deps({ exec: () => '"IOPlatformUUID" = "ZZZZ-9999"' }));
  assert.notEqual(a.id, b.id);
});

test('the raw hardware id never appears in the fingerprint', () => {
  // Only the digest is sent to the licence service. Shipping the actual
  // hardware id would turn every install into personal data we then have to
  // protect, for no gain: recognising a returning machine needs a stable
  // token, not an identifying one.
  const result = machineFingerprint(deps());
  assert.equal(result.id.includes('AAAA'), false);
  assert.match(result.id, /^[0-9a-f]{32}$/);
});

test('a locked-down machine that refuses ioreg still gets a fingerprint', () => {
  const d = deps({
    exec: () => {
      throw new Error('operation not permitted');
    },
  });
  const result = machineFingerprint(d);
  assert.equal(result.source, 'fallback');
  assert.match(result.id, /^[0-9a-f]{32}$/);
});

test('an unknown platform falls back rather than failing', () => {
  const result = machineFingerprint(deps({ platform: () => 'aix' }));
  assert.equal(result.source, 'fallback');
});

test('the fallback still distinguishes two machines by hostname', () => {
  const base = deps({ platform: () => 'aix' });
  const a = machineFingerprint(base);
  const b = machineFingerprint({ ...base, hostname: () => 'other-host' });
  assert.notEqual(a.id, b.id);
});

test('empty output from the platform command is treated as no id', () => {
  assert.equal(rawMachineId(deps({ exec: () => '' })), null);
});