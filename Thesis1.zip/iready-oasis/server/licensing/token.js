'use strict';
const crypto = require('crypto');

// Entitlement tokens are JWS in compact serialisation (RFC 7515), signed with
// EdDSA over Ed25519 (RFC 8037):
//
//   base64url(header) . base64url(payload) . base64url(signature)
//
// Standard format, deliberately: enterprise buyers and their security reviewers
// recognise a JWS, existing tooling can inspect one, and the `kid` header gives
// us key rotation without a new build.
//
// THE ALGORITHM IS PINNED. `header.alg` is compared against the one algorithm
// we accept and is never used to *choose* an algorithm. That is the whole
// defence against the `alg:none` and alg-confusion downgrade family, which is
// the bug class we cannot afford in the one check standing between the product
// and free use. Reading `alg` to decide how to verify is how that attack works;
// this code decides first and checks second.
//
// Signing happens only on the licence service, which holds the private key. The
// app ships public keys and verifies. That asymmetry is what makes the offline
// grace window safe: a cached token on the user's disk can be read and deleted,
// but not forged or edited.

const ALG = 'EdDSA';
const TYP = 'JWT';

const PAYLOAD_REQUIRED_FIELDS = ['licenseId', 'tier', 'exp', 'issuedAt'];

function b64urlEncode(buf) {
  return Buffer.from(buf).toString('base64url');
}

function encodeSegment(obj) {
  return b64urlEncode(Buffer.from(JSON.stringify(obj), 'utf8'));
}

function decodeSegment(segment) {
  const json = Buffer.from(segment, 'base64url').toString('utf8');
  const value = JSON.parse(json);
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('not an object');
  return value;
}

/**
 * @param {object} payload
 * @param {string|KeyObject} privateKey
 * @param {string} [kid] identifies which key signed this, so verifiers can
 *                       pick the right one during a rotation.
 */
function signToken(payload, privateKey, { kid = null } = {}) {
  const header = { alg: ALG, typ: TYP };
  if (kid) header.kid = kid;

  const signingInput = `${encodeSegment(header)}.${encodeSegment(payload)}`;
  const signature = crypto.sign(null, Buffer.from(signingInput, 'ascii'), privateKey);
  return `${signingInput}.${b64urlEncode(signature)}`;
}

// Accepts a single PEM, or a set of {kid, pem} entries. The set is what makes
// rotation possible: during a changeover the app trusts both the retiring and
// the incoming key, so licences signed either side of the switch keep working
// and nobody needs a new build on a deadline.
function normaliseKeys(keys) {
  if (!keys) return [];
  if (typeof keys === 'string' || typeof keys.export === 'function') {
    return [{ kid: null, pem: keys }];
  }
  if (Array.isArray(keys)) {
    return keys.filter(k => k && k.pem).map(k => ({ kid: k.kid || null, pem: k.pem }));
  }
  return [];
}

// Which keys may verify this token. A `kid` we recognise narrows it to one; an
// unrecognised `kid` is a hard failure rather than a fallback to trying
// everything, because "signed by a key we retired" should not silently pass.
function candidateKeys(header, keys) {
  if (!header.kid) return keys;
  const matched = keys.filter(k => k.kid === header.kid);
  if (matched.length) return matched;
  // Tokens minted before kids existed, verified against a key set that has not
  // named its keys either.
  return keys.some(k => k.kid) ? [] : keys;
}

/**
 * Verifies that a payload was signed by a trusted key, and nothing more.
 *
 * Split out from verifyToken because signing is used for two different things:
 * licence entitlements and rule bundles. Both need "did we sign this"; only the
 * first needs `licenseId` and `exp`. Requiring licence fields of a rule bundle
 * rejected every valid bundle with a misleading "incomplete_payload".
 *
 * Returns { valid, payload, reason, kid }. Never throws: this runs on whatever
 * happens to be on disk, which may be truncated, hand-edited, or left over from
 * an older format.
 */
function verifySigned(token, keys) {
  if (typeof token !== 'string' || token.length === 0) {
    return { valid: false, payload: null, reason: 'missing', kid: null };
  }

  const parts = token.split('.');
  if (parts.length !== 3 || !parts[0] || !parts[1] || !parts[2]) {
    return { valid: false, payload: null, reason: 'malformed', kid: null };
  }

  let header;
  try {
    header = decodeSegment(parts[0]);
  } catch (_) {
    return { valid: false, payload: null, reason: 'bad_header', kid: null };
  }

  // Pinned, not negotiated. Anything else — including "none" — is refused
  // before a single byte of signature work happens.
  if (header.alg !== ALG) {
    return { valid: false, payload: null, reason: 'unsupported_alg', kid: header.kid || null };
  }

  const trusted = normaliseKeys(keys);
  const candidates = candidateKeys(header, trusted);
  if (!candidates.length) {
    return { valid: false, payload: null, reason: 'unknown_key', kid: header.kid || null };
  }

  let signature;
  try {
    signature = Buffer.from(parts[2], 'base64url');
  } catch (_) {
    return { valid: false, payload: null, reason: 'malformed', kid: header.kid || null };
  }

  const signingInput = Buffer.from(`${parts[0]}.${parts[1]}`, 'ascii');
  const ok = candidates.some(key => {
    try {
      return crypto.verify(null, signingInput, key.pem, signature);
    } catch (_) {
      // An unusable key in the trust set must not take down verification
      // against the other keys in it.
      return false;
    }
  });
  if (!ok) {
    return { valid: false, payload: null, reason: 'bad_signature', kid: header.kid || null };
  }

  let payload;
  try {
    payload = decodeSegment(parts[1]);
  } catch (_) {
    return { valid: false, payload: null, reason: 'bad_payload', kid: header.kid || null };
  }

  return { valid: true, payload, reason: null, kid: header.kid || null };
}

/**
 * Verifies a licence entitlement: signed by us AND carrying the fields the
 * licence state machine depends on.
 *
 * A correctly signed token missing those fields is a bug on our own service
 * rather than an attack — but the app still cannot act on it, and failing here
 * beats reading `undefined` as an expiry date.
 */
function verifyToken(token, keys) {
  const result = verifySigned(token, keys);
  if (!result.valid) return result;

  const payload = result.payload;
  for (const field of PAYLOAD_REQUIRED_FIELDS) {
    if (payload[field] === undefined || payload[field] === null) {
      return { valid: false, payload: null, reason: 'incomplete_payload', kid: result.kid };
    }
  }
  if (typeof payload.exp !== 'number' || typeof payload.issuedAt !== 'number') {
    return { valid: false, payload: null, reason: 'incomplete_payload', kid: result.kid };
  }

  return result;
}

// Reads the header without verifying anything. For diagnostics only — never
// branch on this for an access decision.
function peekHeader(token) {
  try {
    return decodeSegment(String(token).split('.')[0]);
  } catch (_) {
    return null;
  }
}

// Ops helper, also used by the tests. The private key it returns must never be
// written into this repository or into a build: production keys belong in a
// secret manager, and only the public half goes into the app.
function generateKeyPair() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  return {
    publicKey: publicKey.export({ type: 'spki', format: 'pem' }),
    privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' }),
  };
}

module.exports = { signToken, verifyToken, verifySigned, peekHeader, generateKeyPair, ALG, PAYLOAD_REQUIRED_FIELDS };