'use strict';
const crypto = require('crypto');

// Machine-bound offline activation, the way FlexNet, Sentinel and Cryptlex do
// it — and the reason it beats handing the customer a portable licence file.
//
//   1. The air-gapped machine prints a REQUEST CODE carrying its fingerprint.
//   2. An administrator carries that to the vendor portal, by whatever means an
//      air-gapped site allows: email, a ticket, a USB stick, reading it aloud.
//   3. The portal issues a RESPONSE CODE — an ordinary signed entitlement whose
//      `machineId` claim is the fingerprint from step 1.
//   4. The machine installs it, and refuses it if the binding does not match.
//
// The earlier design skipped steps 1 and 2 and issued one portable file per
// customer. That works offline, but the file runs on any machine that has a
// copy, so a site licence had no seat integrity at all. This gets air-gap
// support *and* keeps a licence tied to the machine it was issued for, which is
// what an enterprise security review expects to find.
//
// The request code is not signed: the client has no private key, so there is
// nothing to sign with. It is not a secret either — it carries a fingerprint
// and a nonce, nothing more. The checksum is there to catch transcription
// errors, because these codes get retyped by hand, not to prove anything.

const PREFIX = 'OASIS-REQ';
const VERSION = 1;

function checksum(body) {
  return crypto.createHash('sha256').update(body).digest('hex').slice(0, 8);
}

// Groups of characters, because a human is going to read this off one screen
// and type it into another.
function group(text, size = 48) {
  const out = [];
  for (let i = 0; i < text.length; i += size) out.push(text.slice(i, i + size));
  return out.join('\n');
}

// Carries the machine fingerprint, the app version, and a nonce. Deliberately
// nothing else — in particular not the hostname, which was an early draft of
// this and would have undone the reason the fingerprint is hashed at all:
// hostnames routinely name a person ("janes-macbook"), and this code is sent to
// OUR portal, not one the customer operates. An administrator who needs to tell
// twenty requests apart can label them on the way past; we do not need to know.
function createRequestCode({ machineId, appVersion = null, now = Date.now, nonce = null }) {
  if (!machineId) throw new Error('createRequestCode requires a machineId');
  const body = {
    v: VERSION,
    machineId,
    appVersion,
    requestedAt: now(),
    nonce: nonce || crypto.randomBytes(8).toString('hex'),
  };
  const encoded = Buffer.from(JSON.stringify(body), 'utf8').toString('base64url');
  return group(`${PREFIX}-${checksum(encoded)}-${encoded}`);
}

// Returns { valid, request, reason }. Whitespace and line breaks are stripped
// first: these codes are copied out of emails and terminals, and rejecting one
// because it wrapped would be a support ticket every time.
function parseRequestCode(code) {
  if (typeof code !== 'string' || !code.trim()) {
    return { valid: false, request: null, reason: 'missing' };
  }
  const flat = code.replace(/\s+/g, '');
  if (!flat.startsWith(`${PREFIX}-`)) {
    return { valid: false, request: null, reason: 'not_a_request_code' };
  }

  const rest = flat.slice(PREFIX.length + 1);
  const dash = rest.indexOf('-');
  if (dash === -1) return { valid: false, request: null, reason: 'malformed' };

  const given = rest.slice(0, dash);
  const encoded = rest.slice(dash + 1);
  if (!encoded) return { valid: false, request: null, reason: 'malformed' };
  if (checksum(encoded) !== given) {
    return { valid: false, request: null, reason: 'checksum_mismatch' };
  }

  let body;
  try {
    body = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
  } catch (_) {
    return { valid: false, request: null, reason: 'malformed' };
  }
  if (!body || typeof body !== 'object' || !body.machineId) {
    return { valid: false, request: null, reason: 'malformed' };
  }
  if (body.v !== VERSION) {
    return { valid: false, request: null, reason: 'unsupported_version' };
  }

  return { valid: true, request: body, reason: null };
}

module.exports = { createRequestCode, parseRequestCode, PREFIX, VERSION };