'use strict';
const { createLicenseService } = require('./service');
const { createLicenseRouter } = require('./routes');
const { createLicenseGate } = require('./gate');
const { HttpLicenseProvider } = require('./provider');
const { machineFingerprint } = require('./fingerprint');
const { trustedKeys, licenseServiceUrl, isDevelopmentKey, isDefaultServiceUrl, licensingEnabled, purchaseUrl } = require('./keys');

// One call wires licensing into the Express app. Kept to a single entry point
// so server/index.js — already 350KB — gains three lines rather than a
// subsystem.
//
// Order matters: the router mounts before the gate so /api/license is reachable
// while locked, and the gate mounts before the feature routes it protects.

function installLicensing(app, { appVersion = null, env = process.env, log = console.log, getTrialIntegration } = {}) {
  // On unless this build opted out (OASIS_LICENSE_DISABLED=1) — see licensingEnabled().
  // Read from the environment at startup on purpose:
  // it must not be reachable from the renderer, or the lock screen would ship
  // with a switch to turn itself off.
  if (!licensingEnabled(env)) {
    log('license: enforcement off (OASIS_LICENSE_DISABLED=1)');
    return null;
  }

  const keys = trustedKeys(env);
  const baseUrl = licenseServiceUrl(env);

  if (keys.some(k => isDevelopmentKey(k.pem))) {
    log('license: WARNING — using the development verification key. Do not ship this build.');
  }
  log(`license: trusting ${keys.length} signing key(s): ${keys.map(k => k.kid || '(unnamed)').join(', ')}`);

  // Logged loudly at startup: a build pointing at the wrong host fails exactly
  // like a service outage, and this one line is the difference between the two.
  log(`license: enforcement ON, service ${baseUrl}`);
  if (isDefaultServiceUrl(env)) {
    log(`license: no OASIS_LICENSE_URL set, so using the local development service at ${baseUrl}. ` +
      'Start it with `node tools/license-service-dev.js`, or set OASIS_LICENSE_URL to a real one.');
  }

  const provider = new HttpLicenseProvider({ baseUrl, appVersion });
  const service = createLicenseService({
    provider,
    keys,
    serviceUrl: baseUrl,
    appVersion,
    machineId: machineFingerprint().id,
    fingerprintSource: machineFingerprint().source,
    purchaseUrl: purchaseUrl(env),
    log: (...args) => log(...args),
  });

  app.use('/api/license', createLicenseRouter(service, { getTrialIntegration }));
  app.use(createLicenseGate(service));

  // A check at startup catches revocations and expiries that happened while
  // the app was closed, before the user gets any work done.
  service.revalidateIfDue().catch(() => {});
  service.startRevalidationTimer();

  return service;
}

module.exports = {
  installLicensing,
  createLicenseService,
  createLicenseRouter,
  createLicenseGate,
  HttpLicenseProvider,
};