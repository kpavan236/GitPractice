'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

// Local licence state. Follows the existing convention for OASIS's own state
// files (see VERSION_WATCH_CACHE_PATH in server/index.js): a dotfile in the
// user's home directory.
//
// Nothing stored here is a secret and none of it is trusted. The token is
// signature-verified on every read, and deleting this file only sends the app
// back to the licence service — which recognises the machine fingerprint and
// hands back the *original* trial expiry rather than a fresh seven days. That
// is what makes it safe for this file to be plainly readable and editable.

const DEFAULT_PATH = path.join(os.homedir(), '.oasis-license.json');

const EMPTY = {
  token: null,
  lastCheckAt: null,
  lastServerTimeSeen: null,
  // Kept for installs written by builds before `rejection` existed. A stored
  // revokedAt still means revoked; nothing new writes it.
  revokedAt: null,
  // Why the service last refused this licence: { at, reason, message }. The
  // reason is what stops an expired licence being reported as a revoked one.
  rejection: null,
  machineId: null,
  installedAt: null,
};

function load(storePath = DEFAULT_PATH) {
  try {
    if (!fs.existsSync(storePath)) return { ...EMPTY };
    const parsed = JSON.parse(fs.readFileSync(storePath, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { ...EMPTY };
    // Merge over EMPTY so a file written by an older version is missing keys
    // rather than producing undefined reads downstream.
    return { ...EMPTY, ...parsed };
  } catch (_) {
    // Corrupt or unreadable: start clean. A truncated file after a power cut
    // must not brick the app.
    return { ...EMPTY };
  }
}

function save(storePath = DEFAULT_PATH, data = {}) {
  const next = { ...EMPTY, ...data };
  try {
    fs.mkdirSync(path.dirname(storePath), { recursive: true });
    // Write-then-rename: a crash mid-write leaves the previous good file in
    // place instead of a half-written one that reads as "unlicensed".
    const tmp = `${storePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, storePath);
    return true;
  } catch (_) {
    return false;
  }
}

function update(storePath, patch) {
  const merged = { ...load(storePath), ...patch };
  save(storePath, merged);
  return merged;
}

function clear(storePath = DEFAULT_PATH) {
  try {
    if (fs.existsSync(storePath)) fs.unlinkSync(storePath);
  } catch (_) {}
}

module.exports = { load, save, update, clear, DEFAULT_PATH, EMPTY };