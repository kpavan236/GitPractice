'use strict';
const { hasFeature } = require('./tiers');

// Enforcement, expressed as Express middleware.
//
// This sits in front of the API rather than in the renderer for one reason:
// hiding a tab is cosmetic. The Version Watch tab was hidden by adding a CSS
// class to a button — anyone can delete that class in devtools and the tab is
// back, because the routes behind it were still answering. A licence check that
// only hides UI is the same trick played on ourselves. Locking happens where
// the work happens.

// Routes that must answer even when the app is locked, or the user can never
// get *out* of locked: the licence screen needs to load, read status, and
// submit a key.
const ALWAYS_ALLOWED = [
  /^\/api\/license(\/|$)/,
  /^\/api\/health$/,
  /^\/api\/whoami$/,
  // The setup wizard. The trial starts when setup finishes, so the wizard must work
  // BEFORE any licence or trial exists: it validates the GitHub and Jenkins details,
  // connects, finds local tools, and reads and saves preferences. Everything the app
  // does with that session afterwards is still locked until the trial has started.
  /^\/api\/validate-github$/,
  /^\/api\/validate-jenkins$/,
  /^\/api\/session$/,
  /^\/api\/detect-tools$/,
  /^\/api\/pick-directory$/,
  /^\/api\/aws-profiles$/,
  /^\/api\/prefs$/,
  /^\/api\/external-calls$/,
];

// API prefix → the feature that unlocks it. Anything not listed here is core
// functionality, included in every tier and in the trial.
//
// "Core" means every tier gets it, NOT that it is free: core routes still need
// a licence or a running trial, they just do not need a PARTICULAR one. Only
// these two prefixes are sold separately.
const FEATURE_ROUTES = [
  [/^\/api\/version-watch(\/|$)/, 'version-watch'],
  [/^\/api\/security(\/|$)/, 'security'],
];

function requiredFeature(pathname) {
  for (const [pattern, feature] of FEATURE_ROUTES) {
    if (pattern.test(pathname)) return feature;
  }
  return null;
}

function isAlwaysAllowed(pathname) {
  return ALWAYS_ALLOWED.some(pattern => pattern.test(pathname));
}

function createLicenseGate(service, { featureRoutes = FEATURE_ROUTES } = {}) {
  return function licenseGate(req, res, next) {
    const pathname = req.path;

    // Static assets are never gated: the lock screen is itself served from
    // public/, so blocking it would leave a blank window with no way forward.
    if (!pathname.startsWith('/api/')) return next();
    if (isAlwaysAllowed(pathname)) return next();

    const status = service.status();

    const feature = (function () {
      for (const [pattern, name] of featureRoutes) {
        if (pattern.test(pathname)) return name;
      }
      return null;
    })();

    // Locked outranks the feature check, and blocks CORE routes too. Without a
    // licence or a live trial there is no product — the 7-day trial is the only
    // thing that makes the core tabs work unlicensed, and when it runs out they
    // stop with everything else.
    if (status.locked) {
      // 402 Payment Required is the one status code that means exactly this.
      return res.status(402).json({
        error: 'license_required',
        feature,
        reason: status.reason,
        message: status.message || 'A valid licence is required.',
        status,
      });
    }

    // Licensed, but this particular tab was not part of the deal.
    if (feature && !hasFeature({ features: status.features }, feature)) {
      return res.status(403).json({
        error: 'feature_not_licensed',
        feature,
        message: `Your ${status.tierLabel || status.tier} licence does not include ${feature}.`,
        status,
      });
    }

    return next();
  };
}

module.exports = { createLicenseGate, requiredFeature, isAlwaysAllowed, FEATURE_ROUTES, ALWAYS_ALLOWED };