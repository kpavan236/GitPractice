'use strict';

// The tier catalogue — the sales shape of a licence, in one place.
//
// A tier fixes four things: how many machines may run it, how long it keeps
// working when the licence service is unreachable, whether it may be installed
// from a file with no network call at all, and which features it unlocks.
//
// Nothing here is trusted at runtime. These values are what the licence service
// stamps into a signed entitlement token when it issues one; the app reads the
// token, not this table. The table lives in the app only so that the two sides
// agree on what "team" means and so the UI can describe a tier it has been
// handed.

// Wildcard feature set. Stored in the token as the string '*' rather than an
// expanded list so a negotiated enterprise deal keeps working when we ship a
// new tab — the customer bought "everything", not "everything as of v1.1.4".
const ALL_FEATURES = '*';

// Feature keys match the tab ids in public/js/modules/tabs.js, so the renderer
// can gate a tab by its own name without a translation table.
//
// This list is SHORT on purpose: it names the things a licence sells
// SEPARATELY, not everything a licence is needed for. Repos, setup, dependency
// graph, Docker, JIRA, the scheduler and wellness are core — every tier gets
// them, so none of them is a feature key.
//
// Core is not free, though. It runs unlicensed only for the 7-day trial below;
// after that the app locks like any other unlicensed software. Two levels,
// therefore, and gate.js applies them in order:
//
//   locked (no trial, expired, revoked)  → nothing answers
//   licensed, feature not granted        → that ONE tab does not answer
//
// Adding a key here is a pricing decision. Taking one away hands that feature
// to every tier.
const FEATURES = [
  'version-watch',
  'security',
];

// How long a trial runs, in days. The licence service is the authority: it
// stamps the expiry into the token, so changing this on the service changes
// every new trial and leaves trials already issued alone. An invalid value
// falls back to the default and says so; a typo in an environment variable must
// neither crash the app nor quietly turn a 7-day trial into something else.
const DEFAULT_TRIAL_DAYS = 7;
const MAX_TRIAL_DAYS = 90;

function trialTermDays(env = process.env, warn = m => console.warn(m)) {
  const raw = env.TRIAL_DURATION_DAYS;
  if (raw === undefined || raw === '') return DEFAULT_TRIAL_DAYS;
  const days = /^\d+$/.test(raw) ? Number(raw) : NaN;
  if (!(days >= 1 && days <= MAX_TRIAL_DAYS)) {
    warn(`TRIAL_DURATION_DAYS must be a whole number from 1 to ${MAX_TRIAL_DAYS}; using ${DEFAULT_TRIAL_DAYS}.`);
    return DEFAULT_TRIAL_DAYS;
  }
  return days;
}

const TIERS = {
  // The trial is the ONLY way to run OASIS unlicensed: the core tabs — repos,
  // setup, dependency graph, Docker, JIRA — work for seven days and then stop,
  // which is what makes an expired trial lock the app rather than just hiding
  // two tabs. Seven days because a week spans a working sprint; a single day
  // was over before an evaluator had scanned a real repository.
  //
  // It grants NO features, so Version Watch and Security are absent from a
  // trial exactly as they are from an unlicensed tier. The trial evaluates the
  // core product; the paid tabs are what a licence adds, and showing them for
  // a week and then taking them away demonstrates a loss rather than a value.
  //
  // The countdown reports days until the last one and hours after that — see
  // the trial branch of state.js.
  trial: {
    id: 'trial',
    label: 'Trial',
    seats: 1,
    termDays: trialTermDays(),
    graceDays: 0,
    offlineActivation: false,
    features: [],
  },
  // The two SKUs. Version Watch is the half that sells on its own — a team that
  // wants to know what its dependencies are behind on has no interest in a
  // vulnerability queue — so it is sold alone, and security is the upgrade.
  //
  // `seats` here is the DEFAULT the licence service stamps into a token when a
  // customer record does not override it (tools/license-service-dev.js:78, and
  // state.js:77 reads the token's value, not this one). A 40-seat deal on the
  // viewer tier is a number on the customer record, not a new tier.
  viewer: {
    id: 'viewer',
    label: 'Version Viewer',
    seats: 10,
    termDays: 365,
    graceDays: 14,
    offlineActivation: false,
    features: ['version-watch'],
  },
  'viewer-security': {
    id: 'viewer-security',
    label: 'Version Viewer + Security',
    seats: 10,
    termDays: 365,
    graceDays: 14,
    offlineActivation: false,
    features: ['version-watch', 'security'],
  },

  // ── Legacy ────────────────────────────────────────────────────────────────
  // Kept so tokens already in the field still resolve their term, seats and
  // grace window. Their feature lists are what those tokens ALREADY unlocked,
  // rewritten against the shortened FEATURES list rather than reduced:
  //
  //   individual bought repos + deps + docker, all of which are now free, so it
  //              grants nothing extra — and loses nothing, because its holder
  //              keeps every tab they had.
  //   team       bought version-watch as well, and keeps exactly that.
  //
  // New business goes to viewer / viewer-security.
  individual: {
    id: 'individual',
    label: 'Individual',
    seats: 1,
    termDays: 365,
    graceDays: 14,
    offlineActivation: false,
    features: [],
  },
  team: {
    id: 'team',
    label: 'Team',
    seats: 10,
    termDays: 365,
    graceDays: 14,
    offlineActivation: false,
    features: ['version-watch'],
  },
  // Enterprise is a site licence, and differs from the paid tiers in kind
  // rather than degree:
  //
  //   seats: null            — uncounted. There is no activation slot to claim
  //                            or free, so no seat bookkeeping for the customer
  //                            to administer and none for us to police.
  //   offlineActivation      — may be installed from a signed licence FILE with
  //                            no call to the licence service, ever. Enterprise
  //                            buyers are routinely air-gapped or behind egress
  //                            rules that will never permit a call to a vendor
  //                            host. Losing those deals costs more than the
  //                            seat accounting we give up, and the expiry date
  //                            baked into the file still bounds the term.
  //   graceDays: 30          — a licence service outage during a customer's
  //                            release week must not stop a whole company.
  enterprise: {
    id: 'enterprise',
    label: 'Enterprise',
    seats: null,
    termDays: 365,
    graceDays: 30,
    offlineActivation: true,
    features: ALL_FEATURES,
  },
};

function getTier(id) {
  return Object.prototype.hasOwnProperty.call(TIERS, id) ? TIERS[id] : null;
}

function isKnownTier(id) {
  return getTier(id) !== null;
}

function listTiers() {
  return Object.values(TIERS);
}

// Whether an entitlement grants a feature.
//
// Reads the *entitlement*, not the tier table, because the token is the
// authority: a negotiated enterprise deal may carry a bespoke feature list that
// matches no tier we ship.
function hasFeature(entitlement, feature) {
  if (!entitlement) return false;
  const granted = entitlement.features;
  if (granted === ALL_FEATURES) return true;
  return Array.isArray(granted) && granted.includes(feature);
}

// Expands an entitlement's feature set into concrete keys, for the renderer.
function grantedFeatures(entitlement) {
  if (!entitlement) return [];
  if (entitlement.features === ALL_FEATURES) return [...FEATURES];
  return Array.isArray(entitlement.features)
    ? entitlement.features.filter(f => FEATURES.includes(f))
    : [];
}

function allowsOfflineActivation(tierId) {
  const tier = getTier(tierId);
  return tier ? tier.offlineActivation === true : false;
}

function graceDays(tierId) {
  const tier = getTier(tierId);
  return tier ? tier.graceDays : 0;
}

// Unlimited seats is `null`, which is deliberately not `0` or `Infinity`:
// callers must decide what uncounted means for them rather than accidentally
// comparing against a number.
function seatLimit(tierId) {
  const tier = getTier(tierId);
  return tier ? tier.seats : 0;
}

module.exports = {
  trialTermDays,
  ALL_FEATURES,
  FEATURES,
  TIERS,
  getTier,
  isKnownTier,
  listTiers,
  hasFeature,
  grantedFeatures,
  allowsOfflineActivation,
  graceDays,
  seatLimit,
};