'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { sanitizeIntegration } = require('./integration');

test('a normal set of details is kept, with the addresses tidied', () => {
  assert.deepEqual(
    sanitizeIntegration({ jenkinsUrl: 'https://jenkins.example.test/', githubUrl: 'https://github.example.test', org: 'acme-org' }),
    { jenkinsUrl: 'https://jenkins.example.test', githubUrl: 'https://github.example.test', githubOrg: 'acme-org' });
});

test('a password or token written into an address never gets through', () => {
  const out = sanitizeIntegration({ jenkinsUrl: 'https://alice:s3cret-token@jenkins.example.test/job/x?token=abc#frag', githubUrl: 'https://tok123@github.example.test' });
  assert.equal(out.jenkinsUrl, 'https://jenkins.example.test/job/x', 'credentials, query and fragment are dropped');
  assert.equal(out.githubUrl, 'https://github.example.test');
  assert.doesNotMatch(JSON.stringify(out), /s3cret|tok123|abc|frag|alice/);
});

test('only web addresses are accepted', () => {
  for (const bad of ['file:///etc/passwd', 'javascript:alert(1)', 'ftp://x.example.test', 'jenkins.example.test', 'not a url', '', null, undefined, 42, {}]) {
    assert.equal(sanitizeIntegration({ jenkinsUrl: bad }), null, `${String(bad)} must be rejected`);
  }
});

test('an address that is unreasonably long is rejected', () => {
  assert.equal(sanitizeIntegration({ githubUrl: `https://github.example.test/${'a'.repeat(400)}` }), null);
});

test('the organisation must look like a GitHub organisation name', () => {
  assert.equal(sanitizeIntegration({ org: 'acme-org' }).githubOrg, 'acme-org');
  for (const bad of ['acme org', '-acme', 'acme/../x', 'a'.repeat(60), '<script>', '']) {
    assert.equal(sanitizeIntegration({ org: bad }), null, `"${bad}" must be rejected`);
  }
});

test('a bad field is dropped but the good ones stay', () => {
  assert.deepEqual(sanitizeIntegration({ jenkinsUrl: 'nonsense', githubUrl: 'https://github.example.test', org: 'ok-org' }),
    { githubUrl: 'https://github.example.test', githubOrg: 'ok-org' });
});

test('nothing usable gives null, and unexpected extra fields are ignored (a token cannot ride along)', () => {
  assert.equal(sanitizeIntegration(null), null);
  assert.equal(sanitizeIntegration({}), null);
  const out = sanitizeIntegration({ githubUrl: 'https://github.example.test', token: 'ghp_SECRET', jenkinsToken: 'SECRET2', password: 'p' });
  assert.deepEqual(Object.keys(out), ['githubUrl']);
});

test('cleaning twice gives the same answer (the app cleans, then the licence service cleans again)', () => {
  const once = sanitizeIntegration({ jenkinsUrl: 'https://u:p@jenkins.example.test/?t=1', githubUrl: 'https://github.example.test/', org: 'acme-org', token: 'x' });
  assert.deepEqual(once, { jenkinsUrl: 'https://jenkins.example.test', githubUrl: 'https://github.example.test', githubOrg: 'acme-org' });
  assert.deepEqual(sanitizeIntegration(once), once);
  assert.deepEqual(sanitizeIntegration(sanitizeIntegration(once)), once);
});

test('a bad organisation stays out on the second pass too', () => {
  assert.equal(sanitizeIntegration({ githubOrg: 'bad org!' }), null);
});
