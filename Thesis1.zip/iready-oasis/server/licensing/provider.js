'use strict';
const axios = require('axios');

// The seam between OASIS and whoever issues licences.
//
// Everything above this file — the state machine, the gate, the UI — speaks
// only to this interface:
//
//   startTrial({ machineId, appVersion })     -> { token, serverTime }
//   activate({ machineId, licenseKey, ... })  -> { token, serverTime }
//   revalidate({ machineId, token })          -> { token, serverTime }
//   deactivate({ machineId, token })          -> { ok }
//
// The shipped implementation talks to our own licence service. Moving to a
// vendor (Keygen, Cryptlex, LicenseSpring) later means writing one more class
// with these four methods and changing the wiring in index.js — nothing else
// in the app knows where a token came from.

// The single most important distinction in this file.
//
//   'unreachable' — network error, timeout, or 5xx. We could not ask. The
//                   licence might be perfectly fine, so the caller keeps the
//                   cached entitlement and burns grace.
//   'rejected'    — the service answered and said no (4xx). The licence is
//                   bad, revoked, or out of seats, so the caller acts on it.
//
// Getting these backwards either locks out paying customers during our own
// outage or lets a revoked key run forever.
class LicenseServiceError extends Error {
  constructor(kind, message, details) {
    super(message);
    this.name = 'LicenseServiceError';
    this.kind = kind;
    this.details = details || null;
  }
  get unreachable() {
    return this.kind === 'unreachable';
  }
  get rejected() {
    return this.kind === 'rejected';
  }
}

function classify(err) {
  const status = err && err.response && err.response.status;
  if (typeof status === 'number' && status >= 400 && status < 500) {
    const body = err.response.data || {};
    return new LicenseServiceError(
      'rejected',
      body.message || `Licence service rejected the request (${status})`,
      body
    );
  }
  return new LicenseServiceError('unreachable', 'Could not reach the licence service', {
    cause: err && err.message,
  });
}

class HttpLicenseProvider {
  constructor({ baseUrl, http, timeoutMs = 10000, appVersion = null } = {}) {
    this.baseUrl = String(baseUrl || '').replace(/\/+$/, '');
    this.appVersion = appVersion;
    this.http =
      http ||
      axios.create({
        baseURL: this.baseUrl,
        timeout: timeoutMs,
        // Non-2xx must reach our catch block so classify() can sort it.
        validateStatus: s => s >= 200 && s < 300,
        headers: { 'Content-Type': 'application/json' },
      });
  }

  async _post(route, body) {
    try {
      const res = await this.http.post(route, { ...body, appVersion: this.appVersion });
      const data = res.data || {};
      if (!data.token && route !== '/deactivate') {
        // A 200 with no token is our own service misbehaving. Treat it as an
        // outage rather than as a rejection, so nobody is locked out by a bug
        // on our side.
        throw new LicenseServiceError('unreachable', 'Licence service returned no token', data);
      }
      return {
        token: data.token || null,
        serverTime: typeof data.serverTime === 'number' ? data.serverTime : null,
        ok: true,
      };
    } catch (err) {
      if (err instanceof LicenseServiceError) throw err;
      throw classify(err);
    }
  }

  // Platform and architecture only: enough for the service to tell a Mac from a
  // Windows install and to plan support, and nothing that identifies a person.
  // No hostname, no username, no address. A hostname is personal data we have no
  // need for, and the fingerprint already recognises the machine.
  //
  // `integration` is the customer's Jenkins and GitHub ADDRESSES and organisation, already
  // cleaned by sanitizeIntegration (no credentials). It is sent only when there is something.
  // For answers that carry data rather than a token (an emailed code, a purchase request).
  async _postData(route, body, headers) {
    try {
      const res = await this.http.post(route, { ...body, appVersion: this.appVersion }, headers ? { headers } : undefined);
      return res.data || {};
    } catch (err) {
      throw classify(err);
    }
  }

  // Step 1 of "Activate licence": ask for a one-time code to be emailed to an address whose company
  // holds a licence. Answers { ok, sentTo } (the address, masked).
  requestEmailCode({ machineId, email }) {
    return this._postData('/domain/otp', { machineId, email });
  }

  // Step 2: the code. A good code, a live licence and a free seat give back a token like any other.
  activateByEmail({ machineId, email, code }) {
    return this._post('/domain/activate', { machineId, email, code });
  }

  // "Buy a licence", step 1: a one-time code to a WORK address (the service refuses personal providers). Answers { ok, sentTo }.
  requestPurchaseCode({ machineId, email }) {
    return this._postData('/purchase-request/otp', { machineId, email });
  }

  // Step 2: the code. A good one answers { ok, verificationToken }, the proof the purchase request must carry.
  verifyPurchaseCode({ machineId, email, code }) {
    return this._postData('/purchase-request/verify', { machineId, email, code });
  }

  // "Buy a licence": the details go to the support team. Answers { ok, reference }.
  // The Idempotency-Key makes a retry safe: a dropped connection after the service saved the request
  // gets the same reference back instead of a second request for the support team.
  submitPurchaseRequest(details, { idempotencyKey = null } = {}) {
    return this._postData('/purchase-request', details, idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : null);
  }

  startTrial({ machineId, fingerprintSource = null, integration = null }) {
    const body = { machineId, fingerprintSource, platform: process.platform, arch: process.arch };
    if (integration) body.integration = integration;
    return this._post('/trial', body);
  }

  activate({ machineId, licenseKey }) {
    return this._post('/activate', { machineId, licenseKey });
  }

  revalidate({ machineId, token }) {
    return this._post('/revalidate', { machineId, token });
  }

  deactivate({ machineId, token }) {
    return this._post('/deactivate', { machineId, token });
  }
}

module.exports = { HttpLicenseProvider, LicenseServiceError };