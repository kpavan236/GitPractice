'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createLicenseService } = require('./service');
const { signToken, generateKeyPair } = require('./token');
const { LicenseServiceError } = require('./provider');
const { EMPTY } = require('./store');
const { DAY_MS } = require('./state');

const keys = generateKeyPair();
const NOW = 1700000000000;
const MACHINE = 'machine-fingerprint-abc';

function memoryStore(initial = {}) {
  let data = { ...EMPTY, ...initial };
  return {
    load: () => ({ ...data }),
    save: (_p, d) => {
      data = { ...d };
      return true;
    },
    update: (_p, patch) => {
      data = { ...data, ...patch };
      return { ...data };
    },
    clear: () => {
      data = { ...EMPTY };
    },
    peek: () => ({ ...data }),
  };
}

function token(overrides = {}) {
  return signToken(
    {
      licenseId: 'lic_1',
      tier: 'team',
      customer: 'Acme Corp',
      features: ['repos', 'deps'],
      issuedAt: NOW,
      exp: NOW + 365 * DAY_MS,
      graceUntil: NOW + 14 * DAY_MS,
      ...overrides,
    },
    keys.privateKey
  );
}

function fakeProvider(overrides = {}) {
  return {
    calls: [],
    async startTrial(args) {
      this.calls.push(['startTrial', args]);
      return { token: token({ tier: 'trial', features: '*', exp: NOW + 1 * DAY_MS }), serverTime: NOW };
    },
    async activate(args) {
      this.calls.push(['activate', args]);
      return { token: token(), serverTime: NOW };
    },
    async revalidate(args) {
      this.calls.push(['revalidate', args]);
      return { token: token(), serverTime: NOW };
    },
    async deactivate(args) {
      this.calls.push(['deactivate', args]);
      return { ok: true };
    },
    ...overrides,
  };
}

function makeService({ provider = fakeProvider(), store = memoryStore(), now = () => NOW } = {}) {
  return {
    service: createLicenseService({ provider, store, keys: keys.publicKey, machineId: MACHINE, now }),
    provider,
    store,
  };
}

test('a fresh install is unregistered', () => {
  const { service } = makeService();
  const status = service.status();
  assert.equal(status.status, 'unregistered');
  assert.equal(status.locked, true);
  assert.equal(status.machineId, MACHINE);
});

test('starting a trial stores the server-issued token and unlocks', async () => {
  const { service, provider, store } = makeService();
  const status = await service.startTrial();
  assert.equal(status.status, 'trial');
  assert.equal(status.locked, false);
  assert.equal(status.daysRemaining, 1);
  assert.equal(status.hoursRemaining, 24);
  assert.deepEqual(provider.calls[0], ['startTrial', { machineId: MACHINE, fingerprintSource: null, integration: null }]);
  assert.ok(store.peek().token);
  assert.equal(status.trialDays, 7, 'the status carries the trial length for the lock-screen wording');
});

test('the server clock is recorded on every exchange so tampering stays detectable', async () => {
  const { service, store } = makeService({
    provider: fakeProvider({
      async activate() {
        return { token: token(), serverTime: NOW + 1234 };
      },
    }),
  });
  await service.activate('KEY-1234');
  assert.equal(store.peek().lastServerTimeSeen, NOW + 1234);
});

test('activating with a key licenses the machine', async () => {
  const { service, provider } = makeService();
  const status = await service.activate('  KEY-1234  ');
  assert.equal(status.status, 'licensed');
  assert.equal(status.tier, 'team');
  assert.equal(status.customer, 'Acme Corp');
  // Trimmed before it reaches the service — a pasted key usually brings
  // whitespace with it, and a rejection for that would be baffling.
  assert.deepEqual(provider.calls[0][1], { machineId: MACHINE, licenseKey: 'KEY-1234' });
});

test('an empty key is refused without troubling the service', async () => {
  const { service, provider } = makeService();
  await assert.rejects(() => service.activate('   '), err => err instanceof LicenseServiceError && err.rejected);
  assert.equal(provider.calls.length, 0);
});

test('a rejected revalidation records WHY it was rejected, and locks', async () => {
  const store = memoryStore();
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async revalidate() {
        throw new LicenseServiceError('rejected', 'This licence has been revoked.', { reason: 'revoked' });
      },
    }),
  });
  await service.activate('KEY-1234');
  const status = await service.revalidateIfDue({ force: true });

  assert.equal(status.status, 'revoked');
  assert.equal(status.locked, true);
  assert.equal(store.peek().rejection.reason, 'revoked');
  assert.equal(store.peek().rejection.at, NOW);
});

test('an expired licence is not reported as a revoked one', async () => {
  // The defect: every rejection used to be stored as `revokedAt`, so this case
  // told the customer to contact their administrator instead of to renew.
  const store = memoryStore();
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async revalidate() {
        throw new LicenseServiceError('rejected', 'This licence has expired. Renew it to continue.', {
          reason: 'expired',
        });
      },
    }),
  });
  await service.activate('KEY-1234');
  const status = await service.revalidateIfDue({ force: true });

  assert.equal(status.status, 'expired');
  assert.equal(status.reason, 'license_expired');
  assert.equal(status.locked, true);
  assert.doesNotMatch(status.message, /revoked/i);
});

test('a service that sends no reason gets its own message repeated back', async () => {
  const store = memoryStore();
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async revalidate() {
        throw new LicenseServiceError('rejected', 'Nope.');
      },
    }),
  });
  await service.activate('KEY-1234');
  const status = await service.revalidateIfDue({ force: true });

  assert.equal(status.locked, true);
  assert.equal(status.status, 'rejected');
  assert.equal(status.message, 'Nope.');
  assert.equal(store.peek().rejection.reason, null);
});

test('a licence that comes good again clears the recorded rejection', async () => {
  // Otherwise a renewed licence stays locked against a refusal that no longer
  // applies, and the only cure is deleting the store file.
  const store = memoryStore();
  let refuse = true;
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async revalidate() {
        if (refuse) throw new LicenseServiceError('rejected', 'Expired.', { reason: 'expired' });
        return { token: token(), serverTime: NOW };
      },
    }),
  });
  await service.activate('KEY-1234');
  assert.equal((await service.revalidateIfDue({ force: true })).locked, true);

  refuse = false;
  const status = await service.revalidateIfDue({ force: true });
  assert.equal(status.locked, false);
  assert.equal(store.peek().rejection, null);
});

test('an unreachable service leaves the cached licence alone', async () => {
  const store = memoryStore();
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async revalidate() {
        throw new LicenseServiceError('unreachable', 'ETIMEDOUT');
      },
    }),
  });
  await service.activate('KEY-1234');
  const before = store.peek().token;

  const status = await service.revalidateIfDue({ force: true });

  // This is the outage case: we could not ask, so nothing is concluded. The
  // token survives and the grace window carries the customer.
  assert.equal(status.status, 'licensed');
  assert.equal(status.locked, false);
  assert.equal(store.peek().token, before);
  assert.equal(store.peek().revokedAt, null);
});

test('a licence file that does not verify reads as no licence at all', () => {
  // Well-formed JWS with the last signature bytes corrupted — the shape passes,
  // the cryptography does not.
  const corrupted = token().slice(0, -4) + 'AAAA';
  const { service } = makeService({ store: memoryStore({ token: corrupted }) });
  const status = service.status();
  assert.equal(status.status, 'unregistered');
  assert.equal(status.tokenError, 'bad_signature');
});

test('a token signed by someone else is refused', () => {
  const foreign = signToken(
    { licenseId: 'lic_x', tier: 'enterprise', issuedAt: NOW, exp: NOW + DAY_MS, features: '*' },
    generateKeyPair().privateKey
  );
  const { service } = makeService({ store: memoryStore({ token: foreign }) });
  assert.equal(service.status().tokenError, 'bad_signature');
});

test('an enterprise offline licence installs with no network call', () => {
  const { service, provider } = makeService();
  const file = token({ tier: 'enterprise', features: '*', offline: true, seats: null, machineId: MACHINE });

  const status = service.installOfflineLicense(`\n  ${file}  \n`);

  assert.equal(status.status, 'licensed');
  assert.equal(status.offline, true);
  assert.equal(status.tier, 'enterprise');
  assert.equal(provider.calls.length, 0);
});

test('offline activation is refused for tiers that did not buy it', () => {
  const { service } = makeService();
  const file = token({ tier: 'team', offline: true, machineId: MACHINE });
  assert.throws(
    () => service.installOfflineLicense(file),
    err => err instanceof LicenseServiceError && /enterprise licences only/.test(err.message)
  );
});

test('an online token cannot be installed through the offline path', () => {
  const { service } = makeService();
  assert.throws(
    () => service.installOfflineLicense(token({ tier: 'enterprise' })),
    /Activate with key/
  );
});

test('an expired offline licence file is refused at install time', () => {
  const { service } = makeService();
  const file = token({ tier: 'enterprise', offline: true, exp: NOW - 1, machineId: MACHINE });
  assert.throws(() => service.installOfflineLicense(file), /already expired/);
});

test('an offline licence issued for another machine is refused', () => {
  // The reason offline activation is a request/response exchange rather than a
  // file we hand out: a leaked response code unlocks exactly one machine.
  const { service } = makeService();
  const file = token({ tier: 'enterprise', features: '*', offline: true, machineId: 'someone-elses-laptop' });
  assert.throws(() => service.installOfflineLicense(file), /issued for a different machine/);
});

test('an unbound offline licence is refused rather than treated as a site licence', () => {
  // Otherwise the weaker, portable form survives as a quiet fallback and every
  // enterprise deal drifts back to it.
  const { service } = makeService();
  const file = token({ tier: 'enterprise', features: '*', offline: true });
  assert.throws(() => service.installOfflineLicense(file), /not bound to a machine/);
});

test('the activation request code carries this machine and parses back', () => {
  const { service } = makeService();
  const { parseRequestCode } = require('./offline-request');
  const parsed = parseRequestCode(service.offlineRequestCode());
  assert.equal(parsed.valid, true);
  assert.equal(parsed.request.machineId, MACHINE);
});

test('junk pasted into the offline field is refused clearly', () => {
  const { service } = makeService();
  assert.throws(() => service.installOfflineLicense('hello'), /not valid/);
});

test('deactivating frees the seat locally even when the service is down', async () => {
  const store = memoryStore();
  const { service } = makeService({
    store,
    provider: fakeProvider({
      async deactivate() {
        throw new LicenseServiceError('unreachable', 'ENOTFOUND');
      },
    }),
  });
  await service.activate('KEY-1234');

  const status = await service.deactivate();

  assert.equal(status.status, 'unregistered');
  assert.equal(store.peek().token, null);
});

test('revalidation is skipped when nothing is due', async () => {
  const { service, provider } = makeService();
  await service.activate('KEY-1234');
  const callsAfterActivate = provider.calls.length;

  await service.revalidateIfDue();

  assert.equal(provider.calls.length, callsAfterActivate);
});

test('an offline licence is never revalidated', async () => {
  const { service, provider } = makeService();
  service.installOfflineLicense(token({ tier: 'enterprise', offline: true, machineId: MACHINE }));

  await service.revalidateIfDue({ force: true });

  assert.equal(provider.calls.length, 0);
});
test('the trial carries the customer\'s Jenkins and GitHub details, cleaned: addresses and organisation only', async () => {
  const { service, provider } = makeService();
  await service.startTrial({ integration: {
    jenkinsUrl: 'https://alice:s3cret@jenkins.example.test/?token=q9z-query-token', githubUrl: 'https://github.example.test/', org: 'acme-org',
    token: 'ghp_SECRET', jenkinsToken: 'SECRET2' } });
  assert.deepEqual(provider.calls[0][1].integration, { jenkinsUrl: 'https://jenkins.example.test', githubUrl: 'https://github.example.test', githubOrg: 'acme-org' });
  assert.doesNotMatch(JSON.stringify(provider.calls[0]), /s3cret|ghp_SECRET|SECRET2|q9z-query-token|alice/);
});

// ── Activate by email, and asking to buy ───────────────────────────────────────

test('an emailed code is requested for a tidied address, with this machine', async () => {
  const provider = fakeProvider({ async requestEmailCode(args) { this.calls.push(['requestEmailCode', args]); return { ok: true, sentTo: 'p***@acme.example.test' }; } });
  const { service } = makeService({ provider });
  const out = await service.requestEmailCode({ email: '  Pat@ACME.example.test ' });
  assert.deepEqual(provider.calls[0], ['requestEmailCode', { machineId: MACHINE, email: 'pat@acme.example.test' }]);
  assert.equal(out.sentTo, 'p***@acme.example.test');
});

test('a bad address is refused here, without calling the service', async () => {
  const provider = fakeProvider();
  const { service } = makeService({ provider });
  await assert.rejects(service.requestEmailCode({ email: 'not an email' }), err => err.rejected && err.details.reason === 'bad_email');
  assert.equal(provider.calls.length, 0);
});

test('activating by email stores the token and unlocks, like a key', async () => {
  const provider = fakeProvider({ async activateByEmail(args) { this.calls.push(['activateByEmail', args]); return { token: token(), serverTime: NOW }; } });
  const { service, store } = makeService({ provider });
  const status = await service.activateByEmail({ email: 'Pat@Acme.example.test', code: ' 123456 ' });
  assert.equal(status.status, 'licensed');
  assert.equal(status.locked, false);
  assert.deepEqual(provider.calls[0], ['activateByEmail', { machineId: MACHINE, email: 'pat@acme.example.test', code: '123456' }]);
  assert.ok(store.peek().token);
});

test('a code that is not six digits never reaches the service', async () => {
  const provider = fakeProvider();
  const { service } = makeService({ provider });
  for (const bad of ['', '12345', '1234567', 'abcdef', null, undefined]) {
    await assert.rejects(service.activateByEmail({ email: 'pat@acme.example.test', code: bad }), err => err.rejected && err.details.reason === 'wrong_code', String(bad));
  }
  assert.equal(provider.calls.length, 0);
});

test('a refused activation leaves the machine exactly as it was', async () => {
  const provider = fakeProvider({ async activateByEmail() { throw new LicenseServiceError('rejected', 'Your organization\'s licence ended on 2026-01-01.', { reason: 'expired' }); } });
  const { service, store } = makeService({ provider });
  await assert.rejects(service.activateByEmail({ email: 'pat@acme.example.test', code: '123456' }), err => err.details.reason === 'expired');
  assert.equal(store.peek().token, null);
  assert.equal(service.status().status, 'unregistered');
});

test('a purchase request is checked locally first, with a message for every field that is wrong', async () => {
  const provider = fakeProvider();
  const { service } = makeService({ provider });
  await assert.rejects(service.submitPurchaseRequest({ organization: '' }), err => err.rejected && err.details.reason === 'invalid' && !!err.details.errors.organization && !!err.details.errors.contactName);
  assert.equal(provider.calls.length, 0, 'nothing is sent while it is incomplete');
});

test('a valid Idempotency-Key is passed on; a malformed one is dropped, not refused', async () => {
  const provider = fakeProvider({ async submitPurchaseRequest(d, opts) { this.calls.push(['submitPurchaseRequest', d, opts]); return { ok: true, reference: 'PR-0001' }; } });
  const { service } = makeService({ provider });
  const form = { organization: 'Acme', employees: 5, email: 'a@acme.example.test', contactName: 'A', verificationToken: '1999999999999.' + 'a'.repeat(64) };
  await service.submitPurchaseRequest(form, { idempotencyKey: 'buy-abcdef12' });
  await service.submitPurchaseRequest(form, { idempotencyKey: 'bad key\r\nX-Evil: 1' });
  await service.submitPurchaseRequest(form);
  assert.equal(provider.calls[0][2].idempotencyKey, 'buy-abcdef12');
  assert.equal(provider.calls[1][2].idempotencyKey, null, 'a key with spaces or line breaks never reaches a header');
  assert.equal(provider.calls[2][2].idempotencyKey, null);
});

test('a complete purchase request is sent tidied, and only the known fields', async () => {
  const provider = fakeProvider({ async submitPurchaseRequest(d) { this.calls.push(['submitPurchaseRequest', d]); return { ok: true, reference: 'PR-0001' }; } });
  const { service } = makeService({ provider });
  const out = await service.submitPurchaseRequest({
    organization: ' Acme Example Ltd ', employees: '250', email: 'Pat@Acme.Example.Test', contactName: 'Pat', phone: '555 0100', requirement: 'Seats', status: 'AGREED', verificationToken: '1999999999999.' + 'b'.repeat(64) });
  assert.equal(out.reference, 'PR-0001');
  assert.deepEqual(provider.calls[0][1], { organization: 'Acme Example Ltd', employees: 250, email: 'pat@acme.example.test', contactName: 'Pat', machineId: provider.calls[0][1].machineId, verificationToken: '1999999999999.' + 'b'.repeat(64) },
    'the four form fields, this machine and the proof of the email travel, whatever else was sent');
  assert.ok(provider.calls[0][1].machineId, 'the service ties the proof to this machine');
});

test('a purchase request without a verified email is refused here, with nothing sent', async () => {
  const provider = fakeProvider();
  const { service } = makeService({ provider });
  const form = { organization: 'Acme', employees: 5, email: 'a@acme.example.test', contactName: 'A' };
  for (const verificationToken of [undefined, '', 'junk', 42]) {
    await assert.rejects(service.submitPurchaseRequest({ ...form, verificationToken }), err => err.rejected && err.details.reason === 'email_not_verified');
  }
  assert.equal(provider.calls.length, 0);
});

test('asking for a Buy-form code needs a valid address; a personal-provider refusal from the service reaches the page', async () => {
  const provider = fakeProvider({
    async requestPurchaseCode(a) { this.calls.push(['requestPurchaseCode', a]); throw new LicenseServiceError('rejected', 'Use your work email address.', { reason: 'not_corporate_email' }); },
  });
  const { service } = makeService({ provider });
  await assert.rejects(service.requestPurchaseCode({ email: 'nope' }), err => err.rejected && err.details.reason === 'bad_email');
  assert.equal(provider.calls.length, 0);
  await assert.rejects(service.requestPurchaseCode({ email: 'Pat@Gmail.com' }), err => err.rejected && err.details.reason === 'not_corporate_email');
  assert.equal(provider.calls[0][1].email, 'pat@gmail.com');
});

test('checking a Buy-form code needs six digits, and a good one returns the proof', async () => {
  const provider = fakeProvider({ async verifyPurchaseCode(a) { this.calls.push(['verifyPurchaseCode', a]); return { ok: true, verificationToken: '1.' + 'c'.repeat(64) }; } });
  const { service } = makeService({ provider });
  await assert.rejects(service.verifyPurchaseCode({ email: 'pat@acme.example.test', code: '12' }), err => err.rejected && err.details.reason === 'wrong_code');
  assert.equal(provider.calls.length, 0, 'a code that cannot be right is not worth a round trip');
  const out = await service.verifyPurchaseCode({ email: 'Pat@Acme.Example.Test', code: ' 123456 ' });
  assert.equal(out.verificationToken, '1.' + 'c'.repeat(64));
  assert.equal(provider.calls[0][1].code, '123456');
  assert.equal(provider.calls[0][1].email, 'pat@acme.example.test');
});
