'use strict';
const { getTier, grantedFeatures } = require('./tiers');

// The licence state machine. Pure: it takes the stored entitlement plus a
// clock and returns what the app should do. Every time-dependent decision in
// the product funnels through here, which is what makes the awkward cases
// (expiry, outage, clock tampering) testable without a server or a fake disk.
//
//   UNREGISTERED ──first launch, server issues trial──► TRIAL (7d, full access)
//        │                                               │
//        │                                        key entered
//        ▼                                               ▼
//      LOCKED ◄──────── exp passed ──────────────────  LICENSED
//        ▲                                               │
//        │                                    server unreachable 24h
//        │                                               ▼
//        └──────── graceUntil passed ─────────────────  GRACE
//                                                        │
//                                          revalidation succeeds
//                                                        └──► LICENSED

const DAY_MS = 24 * 60 * 60 * 1000;

// How often we *try* the licence service.
const REVALIDATE_INTERVAL_MS = 6 * 60 * 60 * 1000;

// How stale the last successful contact must be before we call it an outage.
// Deliberately four times the attempt cadence: a single failed request is a
// blip on someone's wifi, not a reason to show a paying customer a countdown
// to being locked out.
const OFFLINE_AFTER_MS = 24 * 60 * 60 * 1000;

// Clocks drift, and NTP corrections move them backwards by seconds.
const CLOCK_SKEW_TOLERANCE_MS = 5 * 60 * 1000;

// Start warning this many days before grace runs out.
const GRACE_WARN_DAYS = 7;

const STATUS = {
  UNREGISTERED: 'unregistered',
  TRIAL: 'trial',
  LICENSED: 'licensed',
  GRACE: 'grace',
  EXPIRED: 'expired',
  REVOKED: 'revoked',
  // The service refused us for a reason we cannot name — an older service that
  // sends no reason code, or a cause this build predates. Locked either way,
  // but reported in the service's own words rather than a cause we guessed.
  REJECTED: 'rejected',
  CLOCK_TAMPERED: 'clock_tampered',
};

const HOUR_MS = 60 * 60 * 1000;

function daysBetween(from, to) {
  return Math.max(0, Math.ceil((to - from) / DAY_MS));
}

// Inside the final day, days are the wrong unit: a ceiling to days reports
// "1 day left" for the whole of it, including the last ten minutes.
function hoursBetween(from, to) {
  return Math.max(0, Math.ceil((to - from) / HOUR_MS));
}

// Where the grace window ends. The token's value wins — the licence service
// decides how much rope a given customer gets — and the tier default only
// covers tokens issued before graceUntil existed.
function resolveGraceUntil(entitlement, lastCheckAt) {
  if (typeof entitlement.graceUntil === 'number') return entitlement.graceUntil;
  const tier = getTier(entitlement.tier);
  const days = tier ? tier.graceDays : 0;
  return (lastCheckAt || entitlement.issuedAt) + days * DAY_MS;
}

// What the service told us, turned into what the user should be told.
//
// This exists because every rejection used to be recorded as a revocation. An
// expired licence then said "This licence has been revoked. Contact your
// administrator." — sending a customer whose card lapsed to their IT department
// instead of to renewal, and making a self-service problem into a support call.
//
// An unrecognised reason deliberately does NOT fall back to revoked. Guessing
// the cause is the bug; saying what the service said is the fix.
const REJECTIONS = {
  revoked: {
    status: STATUS.REVOKED,
    reason: 'revoked',
    message: 'This licence has been revoked. Contact your administrator.',
  },
  expired: {
    status: STATUS.EXPIRED,
    reason: 'license_expired',
    message: 'This licence has expired. Renew it to continue.',
  },
  trial_ended: {
    status: STATUS.EXPIRED,
    reason: 'trial_expired',
    message: 'Your trial has ended. Enter a licence key to continue.',
  },
  not_activated: {
    status: STATUS.REJECTED,
    reason: 'seat_released',
    message:
      'This machine is no longer activated on that licence. Enter the key again, or ask your administrator for a seat.',
  },
};

function describeRejection(rejection) {
  const known = rejection && rejection.reason ? REJECTIONS[rejection.reason] : null;
  if (known) return known;
  return {
    status: STATUS.REJECTED,
    reason: 'rejected',
    // The service's own words. It knows why it refused; we do not.
    message: (rejection && rejection.message) || 'The licence service refused this licence.',
  };
}

function describe(entitlement, extra) {
  return Object.assign(
    {
      tier: entitlement ? entitlement.tier : null,
      licenseId: entitlement ? entitlement.licenseId : null,
      customer: entitlement ? entitlement.customer || null : null,
      seats: entitlement && entitlement.seats !== undefined ? entitlement.seats : null,
      features: grantedFeatures(entitlement),
      expiresAt: entitlement ? entitlement.exp : null,
      offline: entitlement ? entitlement.offline === true : false,
      daysRemaining: null,
      hoursRemaining: null,
      graceDaysRemaining: null,
      revalidateDue: false,
      warn: null,
    },
    extra
  );
}

/**
 * @param {object}      input
 * @param {object|null} input.entitlement        decoded, signature-verified token payload
 * @param {number|null} input.lastCheckAt        ms of the last successful licence-service contact
 * @param {number|null} input.lastServerTimeSeen ms, the service's own clock at that contact
 * @param {number|null} input.revokedAt          ms the service told us this licence was revoked
 * @param {number}      input.now                current local time in ms
 */
function evaluate({
  entitlement,
  lastCheckAt = null,
  lastServerTimeSeen = null,
  revokedAt = null,
  rejection = null,
  now,
}) {
  // A refusal from the service outranks everything, including a token still
  // within its expiry. It is the only remedy for non-payment or a leaked key,
  // and it must arrive faster than the token it overrules.
  if (rejection) {
    return describe(entitlement, { locked: true, ...describeRejection(rejection) });
  }

  // Written by builds that recorded every refusal as a revocation. Still
  // honoured, so upgrading does not silently unlock a licence we already know
  // the service refuses.
  if (revokedAt) {
    return describe(entitlement, {
      status: STATUS.REVOKED,
      locked: true,
      reason: 'revoked',
      message: 'This licence has been revoked. Contact your administrator.',
    });
  }

  if (!entitlement) {
    return describe(null, {
      status: STATUS.UNREGISTERED,
      locked: true,
      reason: 'no_entitlement',
      // Names all three ways forward. It used to offer two, one of which
      // (entering a key) is useless to someone who has never bought one.
      message: `Start your ${getTier('trial').termDays}-day trial, buy a licence, or enter a key you already have.`,
    });
  }

  // Rolling the system clock back is the obvious attack on any local expiry
  // check, so a local clock that reads earlier than the licence service's own
  // clock did at our last contact is treated as tampering. Clearing it needs a
  // live check — which sets a fresh server time — not a reboot.
  //
  // Enterprise offline licences are exempt: they never contact the service, so
  // there is no server time to compare against, and the expiry in the signed
  // file is the only control by design.
  if (
    !entitlement.offline &&
    typeof lastServerTimeSeen === 'number' &&
    now < lastServerTimeSeen - CLOCK_SKEW_TOLERANCE_MS
  ) {
    return describe(entitlement, {
      status: STATUS.CLOCK_TAMPERED,
      locked: true,
      reason: 'clock_moved_backwards',
      message: 'System clock is behind the last verified time. Reconnect to verify this licence.',
    });
  }

  if (now >= entitlement.exp) {
    const wasTrial = entitlement.tier === 'trial';
    return describe(entitlement, {
      status: STATUS.EXPIRED,
      locked: true,
      reason: wasTrial ? 'trial_expired' : 'license_expired',
      message: wasTrial
        ? 'Your trial has ended. Buy a licence, or enter a key you already have.'
        : 'This licence expired. Renew it to continue.',
      daysRemaining: 0,
    });
  }

  // An enterprise offline licence is bounded by its expiry alone. There is no
  // revalidation to be due and no grace window to burn, because there was
  // never a connection to lose.
  if (entitlement.offline) {
    return describe(entitlement, {
      status: STATUS.LICENSED,
      locked: false,
      reason: 'offline_license',
      daysRemaining: daysBetween(now, entitlement.exp),
    });
  }

  // The trial has no grace window. Its expiry was issued by the server and is
  // short; extending it for an evaluator who cannot reach us would hand back
  // the reinstall-reset hole that server-issued trials exist to close.
  if (entitlement.tier === 'trial') {
    const daysRemaining = daysBetween(now, entitlement.exp);
    const hoursRemaining = hoursBetween(now, entitlement.exp);
    // Inside the last day the countdown switches to hours. "1 day left" for
    // the final twenty-four is the reading this avoids — an evaluator on the
    // last morning should see the hours they actually have.
    const warn =
      hoursRemaining <= 24
        ? `Your trial ends in ${hoursRemaining} hour${hoursRemaining === 1 ? '' : 's'}.`
        : daysRemaining <= 2
          ? `Your trial ends in ${daysRemaining} day${daysRemaining === 1 ? '' : 's'}.`
          : null;
    return describe(entitlement, {
      status: STATUS.TRIAL,
      locked: false,
      reason: 'trial_active',
      daysRemaining,
      hoursRemaining,
      warn,
    });
  }

  const graceUntil = resolveGraceUntil(entitlement, lastCheckAt);
  const staleFor = lastCheckAt === null ? Infinity : now - lastCheckAt;
  const revalidateDue = lastCheckAt === null || staleFor >= REVALIDATE_INTERVAL_MS;

  if (now > graceUntil) {
    return describe(entitlement, {
      status: STATUS.EXPIRED,
      locked: true,
      reason: 'grace_exhausted',
      message: 'This copy could not reach the licence service in time. Reconnect to unlock.',
      revalidateDue: true,
      graceDaysRemaining: 0,
    });
  }

  if (staleFor >= OFFLINE_AFTER_MS) {
    const graceDaysRemaining = daysBetween(now, graceUntil);
    return describe(entitlement, {
      status: STATUS.GRACE,
      locked: false,
      reason: 'service_unreachable',
      daysRemaining: daysBetween(now, entitlement.exp),
      graceDaysRemaining,
      revalidateDue: true,
      warn: graceDaysRemaining <= GRACE_WARN_DAYS
        ? `Offline for ${Math.floor(staleFor / DAY_MS)} days — this copy locks in ${graceDaysRemaining} day${graceDaysRemaining === 1 ? '' : 's'} without a connection.`
        : null,
    });
  }

  return describe(entitlement, {
    status: STATUS.LICENSED,
    locked: false,
    reason: 'active',
    daysRemaining: daysBetween(now, entitlement.exp),
    revalidateDue,
  });
}

module.exports = {
  evaluate,
  STATUS,
  DAY_MS,
  REVALIDATE_INTERVAL_MS,
  OFFLINE_AFTER_MS,
  CLOCK_SKEW_TOLERANCE_MS,
  GRACE_WARN_DAYS,
};