'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createRequestCode, parseRequestCode, PREFIX } = require('./offline-request');

const NOW = 1700000000000;
const MACHINE = '7606014e477fabcd1234567890abcdef';

function code(overrides = {}) {
  return createRequestCode({
    machineId: MACHINE,
    appVersion: '1.1.4',
    now: () => NOW,
    nonce: 'fixednonce',
    ...overrides,
  });
}

test('a request code round trips', () => {
  const parsed = parseRequestCode(code());
  assert.equal(parsed.valid, true);
  assert.equal(parsed.request.machineId, MACHINE);
  assert.equal(parsed.request.appVersion, '1.1.4');
  assert.equal(parsed.request.requestedAt, NOW);
});

test('a request code carries no hostname or other identifying detail', () => {
  // The fingerprint is hashed precisely so we do not learn whose machine this
  // is; shipping a hostname alongside it to our own portal would undo that.
  const parsed = parseRequestCode(code());
  assert.deepEqual(Object.keys(parsed.request).sort(), ['appVersion', 'machineId', 'nonce', 'requestedAt', 'v']);
});

test('a request code is recognisable at a glance', () => {
  assert.ok(code().startsWith(PREFIX));
});

test('a code survives the line wrapping it picks up in an email', () => {
  // These get pasted through mail clients and ticket systems, which wrap and
  // re-indent freely. Rejecting one for that would be a support ticket every
  // time.
  const mangled = `\n  ${code().replace(/\n/g, '\n   ')}  \n`;
  assert.equal(parseRequestCode(mangled).valid, true);
});

test('a mistyped character is caught by the checksum', () => {
  const original = code().replace(/\s+/g, '');
  const flipped = original.slice(0, -3) + (original.slice(-3, -2) === 'A' ? 'B' : 'A') + original.slice(-2);
  const parsed = parseRequestCode(flipped);
  assert.equal(parsed.valid, false);
  assert.equal(parsed.reason, 'checksum_mismatch');
});

test('a truncated code is refused', () => {
  const parsed = parseRequestCode(code().replace(/\s+/g, '').slice(0, 30));
  assert.equal(parsed.valid, false);
});

test('something that is not a request code is named as such', () => {
  assert.equal(parseRequestCode('hello there').reason, 'not_a_request_code');
  assert.equal(parseRequestCode('').reason, 'missing');
  assert.equal(parseRequestCode(null).reason, 'missing');
});

test('a future format version is refused rather than misread', () => {
  const body = Buffer.from(JSON.stringify({ v: 99, machineId: MACHINE })).toString('base64url');
  const sum = require('crypto').createHash('sha256').update(body).digest('hex').slice(0, 8);
  assert.equal(parseRequestCode(`${PREFIX}-${sum}-${body}`).reason, 'unsupported_version');
});

test('two machines produce different codes', () => {
  assert.notEqual(code(), code({ machineId: 'a'.repeat(32) }));
});

test('the same machine produces a different code each time', () => {
  // The nonce keeps a portal from silently reusing a stale request, and gives
  // an administrator a way to tell two requests from one laptop apart.
  const a = parseRequestCode(createRequestCode({ machineId: MACHINE })).request;
  const b = parseRequestCode(createRequestCode({ machineId: MACHINE })).request;
  assert.notEqual(a.nonce, b.nonce);
});

test('a machineId is required to build a code', () => {
  assert.throws(() => createRequestCode({}), /requires a machineId/);
});