'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluate, STATUS, DAY_MS, OFFLINE_AFTER_MS, REVALIDATE_INTERVAL_MS } = require('./state');

const NOW = 1700000000000;
const HOUR_MS = 60 * 60 * 1000;

function entitlement(overrides = {}) {
  return {
    licenseId: 'lic_123',
    tier: 'team',
    customer: 'Acme Corp',
    features: ['version-watch'],
    issuedAt: NOW - DAY_MS,
    exp: NOW + 200 * DAY_MS,
    graceUntil: NOW + 14 * DAY_MS,
    ...overrides,
  };
}

test('no entitlement leaves the app unregistered and locked', () => {
  const result = evaluate({ entitlement: null, now: NOW });
  assert.equal(result.status, STATUS.UNREGISTERED);
  assert.equal(result.locked, true);
  assert.equal(result.tier, null);
});

test('an expired licence says expired, not revoked', () => {
  // The defect this replaced: every rejection was recorded as a revocation, so
  // a customer whose card lapsed was told to contact their administrator
  // instead of being sent to renew.
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: 'expired', message: 'This licence has expired. Renew it to continue.' },
    now: NOW,
  });
  assert.equal(result.status, STATUS.EXPIRED);
  assert.equal(result.locked, true);
  assert.equal(result.reason, 'license_expired');
  assert.match(result.message, /renew/i);
  assert.doesNotMatch(result.message, /revoked/i);
});

test('a released seat is reported as a seat problem, not a dead licence', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: 'not_activated', message: 'This machine is not activated on any licence.' },
    now: NOW,
  });
  assert.equal(result.status, STATUS.REJECTED);
  assert.equal(result.reason, 'seat_released');
  assert.equal(result.locked, true);
  assert.match(result.message, /activated/i);
});

test('a trial refused by the service reads in trial terms', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial' }),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: 'trial_ended', message: 'Your trial has ended.' },
    now: NOW,
  });
  assert.equal(result.reason, 'trial_expired');
  assert.match(result.message, /trial/i);
});

test('an unrecognised reason repeats the service, rather than guessing a cause', () => {
  // Guessing is what produced the original bug. A service we do not fully
  // understand still knows why it refused, so its words are the honest answer.
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: 'account_suspended', message: 'Your account is suspended.' },
    now: NOW,
  });
  assert.equal(result.status, STATUS.REJECTED);
  assert.equal(result.locked, true);
  assert.equal(result.message, 'Your account is suspended.');
  assert.doesNotMatch(result.message, /revoked/i);
});

test('a rejection with no reason at all still locks and still explains', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: null, message: 'Not today.' },
    now: NOW,
  });
  assert.equal(result.locked, true);
  assert.equal(result.message, 'Not today.');
});

test('a revokedAt from an older build is still honoured', () => {
  // Upgrading must not unlock a licence we already know the service refuses.
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    revokedAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.REVOKED);
  assert.equal(result.locked, true);
});

test('revocation locks even while the token is still within its expiry', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    rejection: { at: NOW, reason: 'revoked', message: 'This licence has been revoked.' },
    now: NOW,
  });
  assert.equal(result.status, STATUS.REVOKED);
  assert.equal(result.locked, true);
  assert.match(result.message, /administrator/i);
});

test('an active trial runs unlocked and reports days remaining', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', features: '*', exp: NOW + 5 * DAY_MS }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.TRIAL);
  assert.equal(result.locked, false);
  assert.equal(result.daysRemaining, 5);
  assert.equal(result.warn, null);
});

test('the final day of the trial counts down in hours, not days', () => {
  // A ceiling to days would report "1 day left" for the whole of it, including
  // the last ten minutes.
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', exp: NOW + 20 * HOUR_MS }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.hoursRemaining, 20);
  assert.equal(result.daysRemaining, 1);
  assert.match(result.warn, /ends in 20 hours\./);
});

test('the final hour of a trial is singular', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', exp: NOW + 40 * 60 * 1000 }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.hoursRemaining, 1);
  assert.match(result.warn, /ends in 1 hour\./);
});

test('a trial with days left warns in days', () => {
  // The tier is seven days today, but the state machine is not hard-coded to
  // any term — whatever the service issues still reads sensibly.
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', exp: NOW + 2 * DAY_MS }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.daysRemaining, 2);
  assert.match(result.warn, /ends in 2 days\./);
});

test('an expired trial locks and says so in trial terms', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', exp: NOW - 1 }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.EXPIRED);
  assert.equal(result.locked, true);
  assert.equal(result.reason, 'trial_expired');
  assert.match(result.message, /trial has ended/);
});

test('a trial never gets a grace window when the service is unreachable', () => {
  // Stale by well past the grace any paid tier would receive, yet the trial's
  // own expiry is what governs — it simply keeps running until it expires.
  const result = evaluate({
    entitlement: entitlement({ tier: 'trial', exp: NOW + 2 * DAY_MS }),
    lastCheckAt: NOW - 30 * DAY_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.TRIAL);
  assert.equal(result.graceDaysRemaining, null);
});

test('a freshly checked licence is active and not due for revalidation', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
  assert.equal(result.locked, false);
  assert.equal(result.revalidateDue, false);
});

test('revalidation falls due once the check interval has elapsed', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - REVALIDATE_INTERVAL_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
  assert.equal(result.revalidateDue, true);
});

test('a missed check within the interval does not scare the user into grace', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - (OFFLINE_AFTER_MS - HOUR_MS),
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
});

test('a day without contact moves a licence into grace but keeps it working', () => {
  const result = evaluate({
    entitlement: entitlement({ graceUntil: NOW + 3 * DAY_MS }),
    lastCheckAt: NOW - (OFFLINE_AFTER_MS + HOUR_MS),
    now: NOW,
  });
  assert.equal(result.status, STATUS.GRACE);
  assert.equal(result.locked, false);
  assert.equal(result.graceDaysRemaining, 3);
  assert.match(result.warn, /locks in 3 days/);
});

test('grace stays quiet while there is plenty of it left', () => {
  const result = evaluate({
    entitlement: entitlement({ graceUntil: NOW + 13 * DAY_MS }),
    lastCheckAt: NOW - (OFFLINE_AFTER_MS + HOUR_MS),
    now: NOW,
  });
  assert.equal(result.status, STATUS.GRACE);
  assert.equal(result.warn, null);
});

test('an exhausted grace window locks the app', () => {
  const result = evaluate({
    entitlement: entitlement({ graceUntil: NOW - 1 }),
    lastCheckAt: NOW - 40 * DAY_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.EXPIRED);
  assert.equal(result.locked, true);
  assert.equal(result.reason, 'grace_exhausted');
});

test('a token without graceUntil falls back to the tier default', () => {
  // team = 14 grace days, measured from the last successful check.
  const lastCheckAt = NOW - 2 * DAY_MS;
  const result = evaluate({
    entitlement: entitlement({ graceUntil: undefined }),
    lastCheckAt,
    now: NOW,
  });
  assert.equal(result.status, STATUS.GRACE);
  assert.equal(result.graceDaysRemaining, 12);
});

test('an expired licence locks regardless of remaining grace', () => {
  const result = evaluate({
    entitlement: entitlement({ exp: NOW - 1, graceUntil: NOW + 10 * DAY_MS }),
    lastCheckAt: NOW - HOUR_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.EXPIRED);
  assert.equal(result.reason, 'license_expired');
});

test('a clock rolled back past the last verified server time is treated as tampering', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    lastServerTimeSeen: NOW + 10 * DAY_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.CLOCK_TAMPERED);
  assert.equal(result.locked, true);
});

test('ordinary clock drift is tolerated', () => {
  const result = evaluate({
    entitlement: entitlement(),
    lastCheckAt: NOW - HOUR_MS,
    lastServerTimeSeen: NOW + 60 * 1000,
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
});

test('an enterprise offline licence runs with no contact and nothing due', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'enterprise', features: '*', offline: true, exp: NOW + 100 * DAY_MS }),
    lastCheckAt: null,
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
  assert.equal(result.locked, false);
  assert.equal(result.offline, true);
  assert.equal(result.revalidateDue, false);
  assert.equal(result.daysRemaining, 100);
});

test('an offline licence is exempt from the clock check, having no server time to compare', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'enterprise', offline: true }),
    lastServerTimeSeen: NOW + 10 * DAY_MS,
    now: NOW,
  });
  assert.equal(result.status, STATUS.LICENSED);
});

test('an offline licence still expires', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'enterprise', offline: true, exp: NOW - 1 }),
    now: NOW,
  });
  assert.equal(result.status, STATUS.EXPIRED);
  assert.equal(result.locked, true);
});

test('the granted feature list is expanded for the renderer', () => {
  const result = evaluate({
    entitlement: entitlement({ tier: 'enterprise', features: '*' }),
    lastCheckAt: NOW,
    now: NOW,
  });
  // Only the paid features are ever listed — 'wellness' and the rest are core
  // and belong to everyone, so a wildcard does not "grant" them.
  assert.deepEqual(result.features.sort(), ['security', 'version-watch']);
});
test('a build with no licence host offers no purchase link', () => {
  // A dead "buy" link on a lock screen is worse than no link: it is the one
  // place a stuck user has left to click.
  const { purchaseUrl } = require('./keys');
  assert.equal(purchaseUrl({}), null);
  // The licence service has no pricing page, so its address never becomes a purchase link.
  assert.equal(purchaseUrl({ OASIS_LICENSE_URL: 'https://lic.example.com' }), null);
  assert.equal(purchaseUrl({ OASIS_LICENSE_URL: 'https://lic.example.com/' }), null);
  // Only an explicit marketing-site address is offered.
  assert.equal(
    purchaseUrl({ OASIS_LICENSE_URL: 'https://lic.example.com', OASIS_PURCHASE_URL: 'https://oasis.example.com/buy' }),
    'https://oasis.example.com/buy'
  );
});

test('an unregistered machine is told the trial length, and an ended trial is not tied to a number', () => {
  const fresh = evaluate({ entitlement: null, now: NOW });
  assert.match(fresh.message, /Start your \d+-day trial/);
  const ended = evaluate({ entitlement: entitlement({ tier: 'trial', exp: NOW - 1 }), now: NOW });
  assert.match(ended.message, /Your trial has ended/);
  assert.doesNotMatch(ended.message, /\d+-day/, 'the length may have changed since this trial was issued');
});
