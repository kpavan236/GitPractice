'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const { createLicenseRouter } = require('./routes');

async function boot(getTrialIntegration) {
  const calls = [];
  const service = { startTrial: async args => { calls.push(args); return { status: 'trial' }; } };
  const app = express();
  app.use(express.json());
  app.use('/api/license', createLicenseRouter(service, getTrialIntegration ? { getTrialIntegration } : undefined));
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  return { calls, url: `http://127.0.0.1:${server.address().port}`, close: () => server.close() };
}
const post = (url, body) => fetch(`${url}/api/license/trial`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

test('starting a trial passes on the Jenkins and GitHub details of the setup session', async () => {
  const seen = [];
  const { calls, url, close } = await boot(id => { seen.push(id); return { jenkinsUrl: 'https://jenkins.example.test', githubUrl: 'https://github.example.test', org: 'acme' }; });
  try {
    assert.equal((await post(url, { session: 'sess-1' })).status, 200);
    assert.deepEqual(seen, ['sess-1']);
    assert.deepEqual(calls[0], { integration: { jenkinsUrl: 'https://jenkins.example.test', githubUrl: 'https://github.example.test', org: 'acme' } });
  } finally { close(); }
});

test('a trial still starts when there is no session or no details', async () => {
  const { calls, url, close } = await boot(() => null);
  try {
    assert.equal((await post(url, {})).status, 200);
    assert.equal((await post(url, { session: 'unknown' })).status, 200);
    assert.deepEqual(calls.map(c => c.integration), [null, null]);
  } finally { close(); }
});

test('with no lookup configured at all, a trial starts with no details', async () => {
  const { calls, url, close } = await boot();
  try {
    assert.equal((await post(url, { session: 'x' })).status, 200);
    assert.equal(calls[0].integration, null);
  } finally { close(); }
});

async function bootWith(service) {
  const app = express();
  app.use(express.json());
  app.use('/api/license', createLicenseRouter(service));
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  return { url: `http://127.0.0.1:${server.address().port}`, close: () => server.close() };
}
const json = async (url, body) => { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, body: await r.json() }; };
const { LicenseServiceError } = require('./provider');

test('emailing a code, activating by email and asking to buy are all reachable', async () => {
  const seen = [];
  const { url, close } = await bootWith({
    requestEmailCode: async a => { seen.push(['code', a]); return { ok: true, sentTo: 'p***@acme.example.test' }; },
    activateByEmail: async a => { seen.push(['activate', a]); return { status: 'licensed', locked: false }; },
    submitPurchaseRequest: async a => { seen.push(['buy', a]); return { ok: true, reference: 'PR-0001' }; },
  });
  try {
    assert.equal((await json(`${url}/api/license/email-code`, { email: 'pat@acme.example.test' })).body.sentTo, 'p***@acme.example.test');
    assert.equal((await json(`${url}/api/license/activate-email`, { email: 'pat@acme.example.test', code: '123456' })).body.status, 'licensed');
    assert.equal((await json(`${url}/api/license/purchase-request`, { organization: 'Acme' })).body.reference, 'PR-0001');
    assert.deepEqual(seen.map(s => s[0]), ['code', 'activate', 'buy']);
  } finally { close(); }
});

test('the Idempotency-Key header on a purchase request reaches the service', async () => {
  const seen = [];
  const { url, close } = await bootWith({ submitPurchaseRequest: async (a, opts) => { seen.push(opts); return { ok: true, reference: 'PR-0001' }; } });
  try {
    await fetch(`${url}/api/license/purchase-request`, { method: 'POST', headers: { 'content-type': 'application/json', 'Idempotency-Key': 'buy-abcdef12' }, body: '{}' });
    await fetch(`${url}/api/license/purchase-request`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
    assert.equal(seen[0].idempotencyKey, 'buy-abcdef12');
    assert.equal(seen[1].idempotencyKey, undefined);
  } finally { close(); }
});

test('a refusal is a 400 that carries its reason and field messages; an outage is a 503', async () => {
  const { url, close } = await bootWith({
    requestEmailCode: async () => { throw new LicenseServiceError('rejected', 'No licence was found for acme.com.', { reason: 'no_domain_licence' }); },
    activateByEmail: async () => { throw new LicenseServiceError('unreachable', 'Could not reach the licence service'); },
    submitPurchaseRequest: async () => { throw new LicenseServiceError('rejected', 'Some details need fixing.', { reason: 'invalid', errors: { email: 'Enter a valid email address.' } }); },
  });
  try {
    const none = await json(`${url}/api/license/email-code`, { email: 'x@acme.com' });
    assert.equal(none.status, 400);
    assert.equal(none.body.details.reason, 'no_domain_licence');
    const down = await json(`${url}/api/license/activate-email`, { email: 'x@acme.com', code: '123456' });
    assert.equal(down.status, 503);
    const bad = await json(`${url}/api/license/purchase-request`, {});
    assert.equal(bad.status, 400);
    assert.equal(bad.body.details.errors.email, 'Enter a valid email address.');
  } finally { close(); }
});

test('a missing body does not crash any of the three', async () => {
  const { url, close } = await bootWith({
    requestEmailCode: async a => { assert.deepEqual(a, { email: undefined }); return { ok: true }; },
    activateByEmail: async () => ({ status: 'licensed' }),
    submitPurchaseRequest: async () => ({ ok: true }),
  });
  try {
    for (const route of ['email-code', 'activate-email', 'purchase-request']) {
      const r = await fetch(`${url}/api/license/${route}`, { method: 'POST' });
      assert.equal(r.status, 200, route);
    }
  } finally { close(); }
});

test('the Buy form can ask for a code and check it', async () => {
  const seen = [];
  const { url, close } = await bootWith({
    requestPurchaseCode: async a => { seen.push(['code', a]); return { ok: true, sentTo: 'p***@acme.example.test' }; },
    verifyPurchaseCode: async a => { seen.push(['verify', a]); return { ok: true, verificationToken: '1.' + 'd'.repeat(64) }; },
  });
  try {
    assert.equal((await json(`${url}/api/license/purchase-code`, { email: 'pat@acme.example.test' })).body.sentTo, 'p***@acme.example.test');
    assert.equal((await json(`${url}/api/license/purchase-verify`, { email: 'pat@acme.example.test', code: '123456' })).body.verificationToken, '1.' + 'd'.repeat(64));
    assert.deepEqual(seen, [['code', { email: 'pat@acme.example.test' }], ['verify', { email: 'pat@acme.example.test', code: '123456' }]]);
  } finally { close(); }
});

test('a Buy-form code refusal is a 400 with its reason', async () => {
  const { url, close } = await bootWith({
    requestPurchaseCode: async () => { throw new LicenseServiceError('rejected', 'Use your work email address.', { reason: 'not_corporate_email' }); },
  });
  try {
    const r = await json(`${url}/api/license/purchase-code`, { email: 'pat@gmail.com' });
    assert.equal(r.status, 400);
    assert.equal(r.body.details.reason, 'not_corporate_email');
  } finally { close(); }
});
