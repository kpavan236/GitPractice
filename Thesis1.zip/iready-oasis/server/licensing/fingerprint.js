'use strict';
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// A stable, opaque id for this machine, used to claim an activation slot.
//
// The raw platform identifiers never leave the device: they are hashed with a
// fixed salt and only the digest is sent. The licence service needs to
// recognise a machine it has seen before, which a one-way digest does. It has
// no need to know *which* machine, and hardware ids we don't need would turn
// every customer's install base into personal data we then have to protect.

const SALT = 'oasis-license-v1';

// Bumped only if the derivation changes. A change here re-fingerprints every
// install, which the licence service sees as a fleet of new machines — so it
// must be paired with a migration on the service side, never shipped alone.
const SCHEME_VERSION = 1;

function readDarwin(deps) {
  const out = deps.exec('ioreg -rd1 -c IOPlatformExpertDevice');
  const match = /"IOPlatformUUID"\s*=\s*"([^"]+)"/.exec(out);
  return match ? match[1] : null;
}

function readWindows(deps) {
  const out = deps.exec('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid');
  const match = /MachineGuid\s+REG_SZ\s+([0-9a-fA-F-]+)/.exec(out);
  return match ? match[1] : null;
}

function readLinux(deps) {
  for (const file of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
    const value = deps.readFile(file);
    if (value) return value.trim();
  }
  return null;
}

const READERS = {
  darwin: readDarwin,
  win32: readWindows,
  linux: readLinux,
};

const defaultDeps = {
  platform: () => process.platform,
  exec: cmd => execSync(cmd, { encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] }),
  readFile: file => {
    try {
      return fs.readFileSync(file, 'utf8');
    } catch (_) {
      return null;
    }
  },
  hostname: () => os.hostname(),
  homedir: () => os.homedir(),
};

// Returns the raw platform identifier, or null if this platform has none we
// know how to read.
function rawMachineId(deps = defaultDeps) {
  const reader = READERS[deps.platform()];
  if (!reader) return null;
  try {
    return reader(deps) || null;
  } catch (_) {
    // A locked-down machine can refuse ioreg or reg query. Falling back beats
    // failing to start.
    return null;
  }
}

// The fallback is genuinely weaker than a hardware id: hostname and home
// directory are both things a user can change, and two freshly imaged laptops
// in the same fleet can collide. It is here so the app still runs where the
// platform id is unreadable, and the licence service should treat fallback
// fingerprints as advisory when counting seats.
function fallbackSeed(deps) {
  return ['fallback', deps.platform(), process.arch, deps.hostname(), deps.homedir()].join('|');
}

function derive(seed) {
  return crypto
    .createHash('sha256')
    .update(`${SALT}|v${SCHEME_VERSION}|${seed}`)
    .digest('hex')
    .slice(0, 32);
}

let cached = null;

function machineFingerprint(deps) {
  // Only the no-argument production path is cached; tests pass deps and must
  // get a fresh derivation each time.
  if (!deps && cached) return cached;
  const d = deps || defaultDeps;

  const raw = rawMachineId(d);
  const result = {
    id: derive(raw ? `${d.platform()}|${raw}` : fallbackSeed(d)),
    source: raw ? d.platform() : 'fallback',
    schemeVersion: SCHEME_VERSION,
  };

  if (!deps) cached = result;
  return result;
}

function _resetCache() {
  cached = null;
}

module.exports = { machineFingerprint, rawMachineId, defaultDeps, SCHEME_VERSION, _resetCache };