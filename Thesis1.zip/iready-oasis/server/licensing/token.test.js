'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { signToken, verifyToken, peekHeader, generateKeyPair, ALG } = require('./token');

const keys = generateKeyPair();
const otherKeys = generateKeyPair();
const PEM = keys.publicKey;

function payload(overrides = {}) {
  return {
    licenseId: 'lic_abc',
    tier: 'team',
    exp: 1800000000000,
    issuedAt: 1700000000000,
    features: ['repos'],
    ...overrides,
  };
}

function reSign(header, body, privateKey) {
  const enc = o => Buffer.from(JSON.stringify(o), 'utf8').toString('base64url');
  const input = `${enc(header)}.${enc(body)}`;
  const sig = require('crypto').sign(null, Buffer.from(input, 'ascii'), privateKey);
  return `${input}.${sig.toString('base64url')}`;
}

test('a token is compact JWS: three segments with an EdDSA header', () => {
  const token = signToken(payload(), keys.privateKey, { kid: '2026-08' });
  assert.equal(token.split('.').length, 3);
  const header = peekHeader(token);
  assert.equal(header.alg, ALG);
  assert.equal(header.typ, 'JWT');
  assert.equal(header.kid, '2026-08');
});

test('a token signed with the private key verifies against the public key', () => {
  const result = verifyToken(signToken(payload(), keys.privateKey), PEM);
  assert.equal(result.valid, true);
  assert.equal(result.payload.licenseId, 'lic_abc');
});

test('a token signed by a different key is rejected', () => {
  const result = verifyToken(signToken(payload(), otherKeys.privateKey), PEM);
  assert.equal(result.valid, false);
  assert.equal(result.reason, 'bad_signature');
});

test('editing the payload invalidates the signature', () => {
  const token = signToken(payload({ tier: 'individual' }), keys.privateKey);
  const [header, body, sig] = token.split('.');
  const decoded = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
  decoded.tier = 'enterprise';
  decoded.exp = 9999999999999;
  const tampered = `${header}.${Buffer.from(JSON.stringify(decoded)).toString('base64url')}.${sig}`;

  assert.equal(verifyToken(tampered, PEM).reason, 'bad_signature');
});

test('alg:none is refused', () => {
  // The classic JWS downgrade. The algorithm is pinned before any signature
  // work happens, so the header cannot talk us out of checking.
  const enc = o => Buffer.from(JSON.stringify(o), 'utf8').toString('base64url');
  const forged = `${enc({ alg: 'none', typ: 'JWT' })}.${enc(payload({ tier: 'enterprise' }))}.`;
  const result = verifyToken(forged, PEM);
  assert.equal(result.valid, false);
  assert.equal(result.reason, 'malformed'); // empty signature segment
});

test('a header naming another algorithm is refused even when otherwise well formed', () => {
  const forged = reSign({ alg: 'HS256', typ: 'JWT' }, payload(), keys.privateKey);
  const result = verifyToken(forged, PEM);
  assert.equal(result.valid, false);
  assert.equal(result.reason, 'unsupported_alg');
});

test('a two-segment token from the pre-JWS format no longer verifies', () => {
  const body = Buffer.from(JSON.stringify(payload())).toString('base64url');
  assert.equal(verifyToken(`${body}.sig`, PEM).reason, 'malformed');
});

// ── Key rotation ───────────────────────────────────────────────────────────

test('a key set verifies tokens signed by any key in it', () => {
  // The point of rotation: during a changeover, licences signed either side of
  // the switch both keep working.
  const set = [
    { kid: 'old', pem: otherKeys.publicKey },
    { kid: 'new', pem: keys.publicKey },
  ];
  assert.equal(verifyToken(signToken(payload(), otherKeys.privateKey, { kid: 'old' }), set).valid, true);
  assert.equal(verifyToken(signToken(payload(), keys.privateKey, { kid: 'new' }), set).valid, true);
});

test('a retired key stops verifying once it leaves the set', () => {
  const set = [{ kid: 'new', pem: keys.publicKey }];
  const old = signToken(payload(), otherKeys.privateKey, { kid: 'old' });
  assert.equal(verifyToken(old, set).reason, 'unknown_key');
});

test('an unknown kid does not fall back to trying every trusted key', () => {
  // Otherwise "signed by a key we deliberately retired" would silently pass
  // whenever any other key in the set happened to match.
  const set = [{ kid: 'new', pem: keys.publicKey }];
  const mislabelled = signToken(payload(), keys.privateKey, { kid: 'nonsense' });
  assert.equal(verifyToken(mislabelled, set).reason, 'unknown_key');
});

test('a token with no kid verifies against an unnamed key set', () => {
  assert.equal(verifyToken(signToken(payload(), keys.privateKey), [{ pem: PEM }]).valid, true);
});

test('one unusable key in the set does not break the others', () => {
  const set = [
    { kid: 'broken', pem: 'not-a-key' },
    { kid: 'good', pem: keys.publicKey },
  ];
  assert.equal(verifyToken(signToken(payload(), keys.privateKey), set).valid, true);
});

test('an empty key set verifies nothing', () => {
  assert.equal(verifyToken(signToken(payload(), keys.privateKey), []).reason, 'unknown_key');
});

// ── Malformed input ────────────────────────────────────────────────────────

test('garbage in the licence file is reported, not thrown', () => {
  for (const junk of ['', 'not-a-token', 'a.b', '..', 'a.b.c.d', '!!!.???.***']) {
    const result = verifyToken(junk, PEM);
    assert.equal(result.valid, false, `expected ${JSON.stringify(junk)} to be invalid`);
    assert.equal(result.payload, null);
  }
});

test('a non-string token is rejected without throwing', () => {
  for (const value of [null, undefined, 42, {}, []]) {
    assert.equal(verifyToken(value, PEM).valid, false);
  }
});

test('an unusable public key fails verification instead of crashing', () => {
  assert.equal(verifyToken(signToken(payload(), keys.privateKey), 'not-a-key').reason, 'bad_signature');
});

test('a correctly signed token missing required fields is refused', () => {
  const incomplete = signToken({ licenseId: 'lic_abc', tier: 'team' }, keys.privateKey);
  assert.equal(verifyToken(incomplete, PEM).reason, 'incomplete_payload');
});

test('an expiry that is not a number is refused', () => {
  // Guards against reading a string date as a timestamp and comparing it to
  // Date.now(), which would silently evaluate to "never expires".
  assert.equal(verifyToken(signToken(payload({ exp: '2030-01-01' }), keys.privateKey), PEM).reason, 'incomplete_payload');
});

test('a signed JSON array is refused as a payload', () => {
  const token = reSign({ alg: ALG, typ: 'JWT' }, [1, 2, 3], keys.privateKey);
  assert.equal(verifyToken(token, PEM).reason, 'bad_payload');
});

test('peekHeader never throws on rubbish', () => {
  assert.equal(peekHeader('nonsense'), null);
  assert.equal(peekHeader(''), null);
});