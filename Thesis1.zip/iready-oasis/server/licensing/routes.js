'use strict';
const express = require('express');
const { LicenseServiceError } = require('./provider');
const { listTiers } = require('./tiers');

// The licence API the renderer talks to. Mounted at /api/license and exempt
// from the gate (see gate.js ALWAYS_ALLOWED) — the lock screen has to be able
// to reach these or there is no way to become licensed.

// Maps a provider failure onto an HTTP status the UI can act on:
//   400 — you gave us a bad key; fix the input
//   503 — we could not ask; try again later
// Conflating the two would tell a customer with a valid key that their key is
// invalid every time our service hiccups.
function sendError(res, err) {
  if (err instanceof LicenseServiceError) {
    const code = err.rejected ? 400 : 503;
    return res.status(code).json({
      error: err.kind,
      message: err.message,
      details: err.details || undefined,
    });
  }
  return res.status(500).json({ error: 'internal', message: err.message });
}

// getTrialIntegration(sessionId) returns the Jenkins and GitHub details of that setup session
// (addresses and organisation; the service cleans them again before anything is sent).
function createLicenseRouter(service, { getTrialIntegration = () => null } = {}) {
  const router = express.Router();

  router.get('/status', (_req, res) => {
    res.json(service.status());
  });

  router.get('/tiers', (_req, res) => {
    res.json({ tiers: listTiers() });
  });

  router.post('/trial', async (_req, res) => {
    try {
      res.json(await service.startTrial({ integration: getTrialIntegration(String((_req.body || {}).session || '')) }));
    } catch (err) {
      sendError(res, err);
    }
  });

  // Activate by email. Step 1: a one-time code is emailed to an address whose company holds a licence.
  router.post('/email-code', async (req, res) => {
    try {
      res.json(await service.requestEmailCode({ email: (req.body || {}).email }));
    } catch (err) {
      sendError(res, err);
    }
  });

  // Step 2: the code; a live licence and a free seat unlock the app.
  router.post('/activate-email', async (req, res) => {
    try {
      const { email, code } = req.body || {};
      res.json(await service.activateByEmail({ email, code }));
    } catch (err) {
      sendError(res, err);
    }
  });

  // Buy a licence, step 1: a one-time code to a work address. Step 2: the code, answered with the proof the request must carry.
  router.post('/purchase-code', async (req, res) => {
    try {
      res.json(await service.requestPurchaseCode({ email: (req.body || {}).email }));
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/purchase-verify', async (req, res) => {
    try {
      const { email, code } = req.body || {};
      res.json(await service.verifyPurchaseCode({ email, code }));
    } catch (err) {
      sendError(res, err);
    }
  });

  // Buy a licence: the details go to the support team.
  router.post('/purchase-request', async (req, res) => {
    try {
      res.json(await service.submitPurchaseRequest(req.body || {}, { idempotencyKey: req.get('Idempotency-Key') }));
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/activate', async (req, res) => {
    try {
      res.json(await service.activate((req.body || {}).licenseKey));
    } catch (err) {
      sendError(res, err);
    }
  });

  // Step 1 of offline activation: the code the administrator carries to the
  // portal. Reachable while locked, like the rest of this router.
  router.get('/offline-request', (_req, res) => {
    res.json({ code: service.offlineRequestCode() });
  });

  // Step 4: install the response code the portal issued for this machine.
  // Synchronous by nature — the signed code in the body is the whole
  // transaction, which is the point of an offline path.
  router.post('/offline', (req, res) => {
    try {
      res.json(service.installOfflineLicense((req.body || {}).license));
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/revalidate', async (_req, res) => {
    try {
      res.json(await service.revalidateIfDue({ force: true }));
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/deactivate', async (_req, res) => {
    try {
      res.json(await service.deactivate());
    } catch (err) {
      sendError(res, err);
    }
  });

  return router;
}

module.exports = { createLicenseRouter };