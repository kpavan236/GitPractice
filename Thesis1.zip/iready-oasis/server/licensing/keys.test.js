'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  licensingEnabled,
  licensePublicKey,
  licenseServiceUrl,
  isDefaultServiceUrl,
  isDevelopmentKey,
  DEV_PUBLIC_KEY,
  DEFAULT_LICENSE_SERVICE_URL,
} = require('./keys');

test('licensing is ON by default, with nothing configured', () => {
  // The trial and activation options must be there from the first launch, with no
  // environment variable to remember. An internal build that wants none opts OUT.
  assert.equal(licensingEnabled({}), true);
});

test('configuring a licence service turns enforcement on', () => {
  assert.equal(licensingEnabled({ OASIS_LICENSE_URL: 'https://license.example.com' }), true);
});

test('enforcement can be switched on without a service, to exercise the lock screen', () => {
  assert.equal(licensingEnabled({ OASIS_LICENSE_ENABLED: '1' }), true);
});

test('the disable switch beats everything else', () => {
  const env = {
    OASIS_LICENSE_DISABLED: '1',
    OASIS_LICENSE_ENABLED: '1',
    OASIS_LICENSE_URL: 'https://license.example.com',
  };
  assert.equal(licensingEnabled(env), false);
});

test('an unset service URL falls back to the local licence service, and only to this machine', () => {
  // Until a hosted service exists the default is the licence service on this computer (port 4020, under /v1). It is a
  // loopback address, so a build that forgets to set a real one talks to nobody else's server
  // and fails closed (locked) when that service is not running.
  assert.equal(licenseServiceUrl({}), DEFAULT_LICENSE_SERVICE_URL);
  assert.equal(DEFAULT_LICENSE_SERVICE_URL, 'http://localhost:4020/v1');
  assert.ok(isDefaultServiceUrl({}));
  assert.ok(!isDefaultServiceUrl({ OASIS_LICENSE_URL: 'https://license.example.com' }));
});

test('an explicitly configured service URL still wins over the default', () => {
  assert.equal(licenseServiceUrl({ OASIS_LICENSE_URL: 'https://license.example.com' }), 'https://license.example.com');
});

test('a PEM passed through the environment is used directly', () => {
  const pem = '-----BEGIN PUBLIC KEY-----\nabc\n-----END PUBLIC KEY-----\n';
  assert.equal(licensePublicKey({ OASIS_LICENSE_PUBLIC_KEY: pem }), pem);
});

test('a path to a PEM is read from disk', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-keys-'));
  const file = path.join(dir, 'pub.pem');
  const pem = '-----BEGIN PUBLIC KEY-----\nxyz\n-----END PUBLIC KEY-----\n';
  fs.writeFileSync(file, pem);
  assert.equal(licensePublicKey({ OASIS_LICENSE_PUBLIC_KEY: file }), pem);
});

test('an unreadable key path falls back to the development key rather than crashing', () => {
  assert.equal(licensePublicKey({ OASIS_LICENSE_PUBLIC_KEY: '/no/such/key.pem' }), DEV_PUBLIC_KEY);
});

test('the development key is recognisable, so a release build can warn about it', () => {
  assert.equal(isDevelopmentKey(DEV_PUBLIC_KEY), true);
  assert.equal(isDevelopmentKey('-----BEGIN PUBLIC KEY-----\nother\n-----END PUBLIC KEY-----'), false);
});