'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');

// Stopgap local logging for features that don't have a real backend yet
// (feedback, support, error reports — see TODO.md). One shared home so all
// three read/write the same way instead of three near-identical copies.
const OASIS_DIR = path.join(os.homedir(), 'oasis');
const PREFS_PATH = path.join(os.homedir(), '.oasis-prefs.json');

function appendOasisLog(filename, text) {
  fs.mkdirSync(OASIS_DIR, { recursive: true });
  fs.appendFileSync(path.join(OASIS_DIR, filename), text, 'utf8');
}

// Error reporting is opt-in — checked fresh from prefs on every call (rather
// than cached at startup) so flipping the Settings toggle takes effect
// immediately, and so nothing is ever written for someone who never opted in.
function isErrorReportingEnabled() {
  try {
    const prefs = JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8'));
    return !!(prefs.cfg && prefs.cfg.errorReportingEnabled);
  } catch (_) {
    return false;
  }
}

// One entry point for the main process's own crash handlers (uncaught
// exceptions, unhandled rejections, a renderer that died) — same opt-in
// check and same file as renderer/server errors reported over HTTP.
function reportError(source, err) {
  if (!isErrorReportingEnabled()) return;
  const detail = (err && err.stack) || String(err);
  try {
    appendOasisLog('error.txt', `[${new Date().toISOString()}] ${source}\n${detail}\n---\n`);
  } catch (_) { /* best-effort — must never itself throw during error handling */ }
}

module.exports = { appendOasisLog, isErrorReportingEnabled, reportError, OASIS_DIR };
