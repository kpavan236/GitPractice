'use strict';
const { isRangeDeclaration } = require('./compare-versions');

// Turns a Conan reference ("zlib/1.2.13", "zlib/1.2.13@company/stable",
// "zlib/[>=1.2 <2.0]") into an entry, or null when there is no version.
//
// The @user/channel suffix is dropped: it identifies which build of the recipe
// was consumed, not which version of the library, and keeping it would split one
// package into several rows.
function conanEntry(reference) {
  const withoutChannel = String(reference).split('@')[0].trim();
  const separator = withoutChannel.indexOf('/');
  if (separator === -1) return null;

  const name = withoutChannel.slice(0, separator).trim();
  let version = withoutChannel.slice(separator + 1).trim();
  if (!name || !version) return null;
  // An interpolated recipe attribute — resolvable only by running the recipe.
  if (version.includes('{') || version.includes('$')) return null;

  // Conan writes ranges in brackets: "[>=1.2 <2.0]".
  const bracketed = version.match(/^\[(.+)\]$/);
  const isRange = Boolean(bracketed) || isRangeDeclaration(version);
  if (bracketed) version = bracketed[1].trim();
  if (!/\d/.test(version)) return null;

  return isRange ? { name, version, versionIsRange: true } : { name, version };
}

// Parses conanfile.txt's [requires] / [tool_requires] / [build_requires]
// sections. Other sections ([generators], [options], [layout]) describe how to
// build, not what is depended on.
const CONAN_REQUIRE_SECTIONS = new Set(['requires', 'tool_requires', 'build_requires', 'test_requires']);

function parseConanfileTxt(text) {
  const dependencies = [];
  let unresolvedCount = 0;
  let inRequires = false;

  for (const rawLine of String(text).split(/\r?\n/)) {
    const line = rawLine.replace(/#.*$/, '').trim();
    if (!line) continue;

    const section = line.match(/^\[([^\]]+)\]$/);
    if (section) { inRequires = CONAN_REQUIRE_SECTIONS.has(section[1].trim().toLowerCase()); continue; }
    if (!inRequires) continue;

    const entry = conanEntry(line);
    if (!entry) { unresolvedCount++; continue; }
    dependencies.push(entry);
  }

  return { dependencies, unresolvedCount };
}

// Parses conanfile.py, which is a Python recipe rather than a data file. Two
// declaration styles are read: the `self.requires("ref")` calls inside
// requirements(), and the older `requires = "ref", "ref"` class attribute.
//
// Lossy by the same logic as Gradle and sbt: a reference assembled from recipe
// attributes is only knowable by running the recipe, so it is counted rather
// than guessed.
function parseConanfilePy(text) {
  const source = String(text).replace(/^\s*#.*$/gm, '');

  const dependencies = [];
  let unresolvedCount = 0;
  const seen = new Set();

  const add = (reference) => {
    const entry = conanEntry(reference);
    if (!entry) { unresolvedCount++; return; }
    const key = `${entry.name}:${entry.version}`;
    if (seen.has(key)) return;
    seen.add(key);
    dependencies.push(entry);
  };

  // self.requires("zlib/1.2.13") / self.tool_requires(...) / self.test_requires(...)
  for (const match of source.matchAll(/self\.(?:tool_|build_|test_)?requires\s*\(\s*f?["']([^"']+)["']/g)) {
    add(match[1]);
  }

  // requires = "zlib/1.2.13", "openssl/3.1.4"
  for (const match of source.matchAll(/^\s*(?:tool_|build_|test_)?requires\s*=\s*(.+)$/gm)) {
    for (const reference of match[1].matchAll(/["']([^"']+)["']/g)) add(reference[1]);
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseConanfileTxt, parseConanfilePy, conanEntry };
