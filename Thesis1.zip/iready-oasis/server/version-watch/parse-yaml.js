'use strict';

// A deliberately partial YAML reader, sized for one job: the dependency blocks
// in pubspec.yaml (Dart) and environment.yml (Conda).
//
// Written rather than taken from npm for the same reason as parse-toml: this
// ships as a signed Electron bundle, where a runtime dependency carries review
// and supply-chain cost out of proportion to reading indented key/value pairs.
//
// Deliberately out of scope: anchors and aliases, multi-document streams, block
// scalars (| and >), flow mappings ({a: 1}), explicit tags, and typed scalars —
// every value comes back as a string, which is all a version comparison needs.
// Malformed lines are skipped rather than thrown on, so a file we only partly
// understand still yields the dependencies we do understand.

// Strips a comment while respecting quotes, so a URL fragment inside a quoted
// value survives. A '#' only starts a comment at the start of a line or after
// whitespace — otherwise it is part of the value.
function stripComment(line) {
  let quote = null;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quote) {
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '#' && (i === 0 || /\s/.test(line[i - 1]))) return line.slice(0, i);
  }
  return line;
}

function unquote(text) {
  const value = text.trim();
  if (value.length >= 2 && (value[0] === '"' || value[0] === "'") && value[value.length - 1] === value[0]) {
    return value.slice(1, -1);
  }
  return value;
}

// Splits "key: value" at the first colon that acts as a separator — one
// followed by whitespace or at end of line. That keeps a colon inside the value
// ("https://x") from being mistaken for the separator.
function splitKeyValue(text) {
  let quote = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === ':' && (i + 1 === text.length || /\s/.test(text[i + 1]))) {
      return { key: unquote(text.slice(0, i)), value: text.slice(i + 1).trim() };
    }
  }
  return null;
}

// A frame pushed for a "- key:" entry does not yet know whether the block below
// is a map or a sequence — only its first child line reveals that. This creates
// the container on demand with the shape that line implies, and is idempotent so
// later sibling lines reuse it.
function resolvePendingFrame(frame, emptyShape) {
  if (frame.pendingKey === undefined) return frame.container;
  const existing = frame.container[frame.pendingKey];
  if (typeof existing === 'object' && existing !== null) return existing;
  frame.container[frame.pendingKey] = emptyShape;
  return emptyShape;
}

function parseYaml(text) {
  const root = {};
  // Each frame owns a container and the indent column its children sit at.
  // `indent` starts as -1 for the root so any top-level key is deeper than it.
  const stack = [{ indent: -1, container: root }];

  const lines = [];
  for (const rawLine of String(text).split(/\r?\n/)) {
    const withoutComment = stripComment(rawLine);
    if (!withoutComment.trim()) continue;
    if (/^\s*---\s*$/.test(withoutComment) || /^\s*\.\.\.\s*$/.test(withoutComment)) continue;
    lines.push(withoutComment);
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const indent = line.match(/^\s*/)[0].length;
    const content = line.trim();

    // Unwind to the frame this line belongs to.
    while (stack.length > 1 && indent <= stack[stack.length - 1].indent) stack.pop();
    const parent = stack[stack.length - 1];

    // ── sequence entry ──
    if (content.startsWith('- ') || content === '-') {
      // A frame created by "- key:" learns here that its block is a sequence.
      const sequence = resolvePendingFrame(parent, []);
      if (!Array.isArray(sequence)) continue;   // malformed — skip
      const entry = content.slice(1).trim();
      const pair = entry ? splitKeyValue(entry) : null;
      if (pair && pair.value === '') {
        // "- pip:" — a single-key map whose value is the nested block below.
        // The block's shape is decided when its first child line is read, which
        // is why the frame carries the key rather than a container.
        const child = {};
        sequence.push(child);
        stack.push({ indent, container: child, pendingKey: pair.key });
        continue;
      }
      if (pair && pair.value !== '') {
        sequence.push({ [pair.key]: unquote(pair.value) });
        continue;
      }
      if (entry) sequence.push(unquote(entry));
      continue;
    }

    // ── key: value ──
    const pair = splitKeyValue(content);
    if (!pair) continue;   // not a declaration — skip rather than throw

    const container = resolvePendingFrame(parent, {});
    if (Array.isArray(container)) continue;   // a key cannot sit inside a sequence

    if (pair.value !== '') {
      container[pair.key] = unquote(pair.value);
      continue;
    }

    // Empty value: the child block decides the shape. Look ahead to the next
    // more-indented line — a leading dash means a sequence, otherwise a map.
    // A key with no child block at all is null (a dependency declared with no
    // constraint), which callers must distinguish from an empty map.
    const next = lines[i + 1];
    const nextIndent = next ? next.match(/^\s*/)[0].length : -1;
    if (!next || nextIndent <= indent) {
      container[pair.key] = null;
      continue;
    }
    const child = next.trim().startsWith('-') ? [] : {};
    container[pair.key] = child;
    stack.push({ indent, container: child });
  }

  // Resolve any frame whose pendingKey never received children.
  return root;
}

module.exports = { parseYaml };
