'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseComposerJson, parseComposerLock } = require('./parse-composer');

test('reads require and require-dev entries', () => {
  const json = JSON.stringify({
    require: { 'monolog/monolog': '^3.5' },
    'require-dev': { 'phpunit/phpunit': '^10.5' },
  });
  const { dependencies } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['monolog/monolog', 'phpunit/phpunit']);
});

test('flags a caret declaration as a range', () => {
  const json = JSON.stringify({ require: { 'monolog/monolog': '^3.5' } });
  const { dependencies } = parseComposerJson(json);
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('prefers the exact version from composer.lock over the declared range', () => {
  const json = JSON.stringify({ require: { 'monolog/monolog': '^3.5' } });
  const { dependencies } = parseComposerJson(json, {
    lockVersions: { 'monolog/monolog': '3.5.0' },
  });
  assert.strictEqual(dependencies[0].version, '3.5.0');
  assert.notStrictEqual(dependencies[0].versionIsRange, true);
});

test('skips the php platform requirement', () => {
  const json = JSON.stringify({ require: { php: '>=8.1', 'monolog/monolog': '^3.5' } });
  const { dependencies } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['monolog/monolog']);
});

test('skips ext- and lib- platform requirements', () => {
  const json = JSON.stringify({
    require: { 'ext-json': '*', 'lib-curl': '*', 'monolog/monolog': '^3.5' },
  });
  const { dependencies } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['monolog/monolog']);
});

test('skips composer runtime requirements', () => {
  const json = JSON.stringify({
    require: { 'composer-plugin-api': '^2.0', 'composer-runtime-api': '^2.0', 'monolog/monolog': '^3.5' },
  });
  const { dependencies } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['monolog/monolog']);
});

test('counts a wildcard-only requirement as unresolved', () => {
  const json = JSON.stringify({ require: { 'some/pkg': '*' } });
  const { dependencies, unresolvedCount } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads exact versions out of composer.lock', () => {
  const lock = JSON.stringify({
    packages: [{ name: 'monolog/monolog', version: '3.5.0' }],
    'packages-dev': [{ name: 'phpunit/phpunit', version: '10.5.2' }],
  });
  assert.deepStrictEqual(parseComposerLock(lock), {
    'monolog/monolog': '3.5.0',
    'phpunit/phpunit': '10.5.2',
  });
});

test('strips the leading v from a composer.lock version', () => {
  // Packagist tags are often "v3.5.0"; the registry lists them normalized.
  const lock = JSON.stringify({ packages: [{ name: 'x/y', version: 'v3.5.0' }] });
  assert.deepStrictEqual(parseComposerLock(lock), { 'x/y': '3.5.0' });
});

test('returns no dependencies for a manifest with no require sections', () => {
  assert.deepStrictEqual(parseComposerJson('{"name":"x/y"}'), {
    dependencies: [], unresolvedCount: 0,
  });
});

test('counts a dev branch requirement as unresolved', () => {
  // "dev-main" tracks a branch, not a release — Packagist has no such version
  // to compare against.
  const json = JSON.stringify({ require: { 'some/pkg': 'dev-main' } });
  const { dependencies, unresolvedCount } = parseComposerJson(json);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});
