'use strict';

// Splits a version string into dot-separated segments, each further split
// into numeric and non-numeric runs (e.g. "1.0.0-beta1" -> ["1","0","0-beta1"]
// -> compared segment by segment). Not a full semver implementation — just
// enough to correctly order the plain numeric version strings these
// registries actually return, without treating "2.10.0" as less than
// "2.9.0" the way a bare string comparison would.
function compareVersions(a, b) {
  const partsA = String(a).split('.');
  const partsB = String(b).split('.');
  const len = Math.max(partsA.length, partsB.length);
  for (let i = 0; i < len; i++) {
    const segA = partsA[i] ?? '';
    const segB = partsB[i] ?? '';
    const numA = parseInt(segA, 10);
    const numB = parseInt(segB, 10);
    if (!Number.isNaN(numA) && !Number.isNaN(numB) && numA !== numB) return numA - numB;
    if (segA !== segB) {
      // The numeric portions of this segment are equal (or both non-numeric)
      // but the raw text differs — typically a pre-release suffix glued
      // directly onto the number with no dot separator (e.g. "0" vs
      // "0rc1", "0" vs "0-RC1"). A bare numeric segment must outrank the
      // same number carrying a suffix — a plain release is newer than its
      // own pre-release, not older.
      const isPlainA = /^\d+$/.test(segA);
      const isPlainB = /^\d+$/.test(segB);
      if (isPlainA && !isPlainB) return 1;
      if (!isPlainA && isPlainB) return -1;
      return segA < segB ? -1 : 1;
    }
  }
  return 0;
}

// Recognizes common pre-release markers across the ecosystems this tool
// tracks: npm/semver hyphen suffixes ("-beta.1", "-rc.1"), release-channel
// tags ("-canary-<hash>", "-next.5", "-nightly", "-experimental-<hash>"),
// glued suffixes often seen in Maven coordinates ("2.32.0rc1"),
// Maven-specific milestone/snapshot conventions ("-M1", "-SNAPSHOT"), and
// PEP 440's short forms ("4.2a1", "1.26.0b1") — the short-letter check
// requires a digit immediately after the letter, so an unrelated suffix
// like "-alpine" is never mistaken for the "a" (alpha) marker. Deliberately
// does NOT flag Maven's "final"/post-release markers ("-Final", "-RELEASE",
// "-GA", ".post1"), which denote a stable (or newer-than-base) release, not
// a pre-release.
function isPrerelease(version) {
  const str = String(version);
  const numericPrefix = str.match(/^[\d.]+/);
  const rest = numericPrefix ? str.slice(numericPrefix[0].length) : str;
  if (!rest) return false;
  if (/^[.-]?(alpha|beta|pre|dev|snapshot|canary|next|nightly|experimental|milestone|rc)/i.test(rest)) return true;
  if (/^[.-]?[abc]\d/i.test(rest)) return true;
  if (/^[.-]?m\d/i.test(rest)) return true;
  return false;
}

// Strips any leading run of range/comparison-operator characters (npm's
// ^ ~ >= <= > < =, and PEP 440's ~= == != which combine several of those
// characters) and surrounding whitespace, so a declared range like
// "^2.14.1" or "~=2.5" compares by its actual version ("2.14.1"/"2.5")
// instead of a literal "^2"/leaving a stray trailing "=".
function stripRangePrefix(v) {
  return String(v).trim().replace(/^[\^~<>=!]+/, '').trim();
}

// True when a declared version expresses a RANGE of acceptable versions
// rather than a single pinned one ("^1.2.3", ">=2.28", "6.0.*", "1.x",
// ">=1.0,<2.0", "~> 7.0") — as opposed to an exact pin, which includes the
// bare "1.2.3" form and the explicit "=1.0.0"/"==2.28.1" spellings.
//
// The distinction drives a row's `versionIsRange` marker. It matters because
// the vulnerability lookup is issued against the range's floor, so a finding
// on a range row says "the floor you declared is vulnerable", not "the version
// this build resolves to is vulnerable" — and the up-to-date comparison is
// likewise against the floor.
//
// Ecosystem-specific semantics are NOT decided here: Cargo reads a bare "1.0"
// as a caret range, so parse-cargo makes that call itself. This function only
// judges the notation.
function isRangeDeclaration(v) {
  const s = String(v ?? '').trim();
  if (!s) return false;
  // A leading run of "=" is a pin in every notation that uses it, even though
  // "=" also appears in comparison operators like ">=".
  if (/^=+[^=]/.test(s) || /^=+$/.test(s)) return false;
  if (/[\^~><|*!,\s]/.test(s)) return true;
  // An "x" standing alone as a segment is a wildcard ("1.x", "1.2.x"). The
  // word boundaries keep it from firing on suffixes like "-x86".
  return /(^|\.)x(\.|$)/i.test(s);
}

// True when two version strings share the same first (major) segment.
function sameMajor(a, b) {
  return stripRangePrefix(a).split('.')[0] === stripRangePrefix(b).split('.')[0];
}

// True when two version strings share the same first TWO (major.minor)
// segments — i.e. they sit on the same patch line, where an upgrade is the
// lowest-risk kind available.
//
// A version with no minor segment at all (a bare "4", which Maven
// coordinates do occasionally use) only ever matches another bare major.
// Treating the absent segment as a wildcard would let "4.1.2" count as a
// patch bump from "4" and report a minor jump as low-risk.
function sameMinor(a, b) {
  const partsA = stripRangePrefix(a).split('.');
  const partsB = stripRangePrefix(b).split('.');
  return partsA[0] === partsB[0] && (partsA[1] ?? '') === (partsB[1] ?? '');
}

// Returns the highest STABLE version in the list, or null if the list is
// empty. Falls back to considering pre-releases only when nothing stable
// has ever been published — better to show something than nothing — since
// otherwise a package (or a major line) that has only ever shipped
// milestone/RC builds would always show "—" for "latest".
function pickLatest(versions) {
  if (!versions.length) return null;
  const stable = versions.filter(v => !isPrerelease(v));
  const candidates = stable.length ? stable : versions;
  return candidates.reduce((best, v) => (compareVersions(v, best) > 0 ? v : best));
}

// Returns the highest version sharing versionInUse's major segment, or null
// if no version in the list shares that major.
function pickLatestSameMajor(versions, versionInUse) {
  const sameMajorVersions = versions.filter(v => sameMajor(v, versionInUse));
  return pickLatest(sameMajorVersions);
}

// Returns the highest version sharing versionInUse's major.minor segments, or
// null if no version in the list sits on that patch line.
function pickLatestSamePatchLine(versions, versionInUse) {
  const samePatchLineVersions = versions.filter(v => sameMinor(v, versionInUse));
  return pickLatest(samePatchLineVersions);
}

module.exports = { compareVersions, sameMajor, sameMinor, pickLatest, pickLatestSameMajor, pickLatestSamePatchLine, stripRangePrefix, isPrerelease, isRangeDeclaration };
