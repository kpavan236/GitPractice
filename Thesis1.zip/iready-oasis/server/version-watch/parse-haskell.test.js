'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseCabal, parseStackYaml } = require('./parse-haskell');

test('reads build-depends from a cabal file', () => {
  const cabal = `
name: my-app
version: 0.1.0.0

library
  build-depends:
      base >=4.17 && <5
    , aeson ==2.1.2.1
    , text
  default-language: Haskell2010
`;
  const { dependencies } = parseCabal(cabal);
  const byName = new Map(dependencies.map(d => [d.name, d]));
  assert.strictEqual(byName.get('aeson').version, '2.1.2.1');
  assert.strictEqual(byName.get('base').versionIsRange, true);
});

test('counts a dependency with no version constraint as unresolved', () => {
  // "text" with no bound resolves to whatever the solver picks.
  const cabal = `
library
  build-depends: aeson ==2.1.2.1, text
`;
  const { dependencies, unresolvedCount } = parseCabal(cabal);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['aeson']);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads build-depends from several stanzas', () => {
  const cabal = `
library
  build-depends: aeson ==2.1.2.1

test-suite spec
  build-depends: hspec ==2.11.7
`;
  const { dependencies } = parseCabal(cabal);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['aeson', 'hspec']);
});

test('ignores a cabal comment', () => {
  const cabal = `
library
  -- build-depends: removed ==1.0
  build-depends: kept ==2.0
`;
  const { dependencies } = parseCabal(cabal);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['kept']);
});

test('reads a caret-bounded constraint as a range', () => {
  const { dependencies } = parseCabal('library\n  build-depends: aeson ^>=2.1');
  assert.strictEqual(dependencies[0].name, 'aeson');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('does not read a field that merely follows build-depends', () => {
  const cabal = `
library
  build-depends: aeson ==2.1.2.1
  hs-source-dirs: src
  ghc-options: -Wall
`;
  const { dependencies } = parseCabal(cabal);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['aeson']);
});

test('reads extra-deps from a stack.yaml', () => {
  // stack pins packages outside the resolver here, exactly.
  const yaml = `
resolver: lts-21.25
extra-deps:
  - aeson-2.1.2.1
  - text-2.0.2
`;
  const { dependencies } = parseStackYaml(yaml);
  assert.deepStrictEqual(dependencies, [
    { name: 'aeson', version: '2.1.2.1' },
    { name: 'text', version: '2.0.2' },
  ]);
});

test('splits a hyphenated package name from its version correctly', () => {
  // "unordered-containers-0.2.19.1" — the name itself contains hyphens, so the
  // split must be at the last hyphen followed by a digit.
  const { dependencies } = parseStackYaml('extra-deps:\n  - unordered-containers-0.2.19.1');
  assert.deepStrictEqual(dependencies, [{ name: 'unordered-containers', version: '0.2.19.1' }]);
});

test('counts a git extra-dep as unresolved', () => {
  const yaml = `
extra-deps:
  - git: https://github.test/x/y.git
    commit: abc123
`;
  const { dependencies, unresolvedCount } = parseStackYaml(yaml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('returns no dependencies for a stack.yaml with no extra-deps', () => {
  assert.deepStrictEqual(parseStackYaml('resolver: lts-21.25'), { dependencies: [], unresolvedCount: 0 });
});

test('returns no dependencies for a cabal file with none', () => {
  assert.deepStrictEqual(parseCabal('name: my-app\nversion: 0.1.0.0'), {
    dependencies: [], unresolvedCount: 0,
  });
});
