'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseCsproj, parsePackagesConfig, parseDirectoryPackagesProps } = require('./parse-nuget');

test('reads a PackageReference with a Version attribute', () => {
  const csproj = `
<Project Sdk="Microsoft.NET.Sdk">
  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
</Project>
`;
  const { dependencies } = parseCsproj(csproj);
  assert.deepStrictEqual(dependencies, [{ name: 'Newtonsoft.Json', version: '13.0.3' }]);
});

test('reads a PackageReference whose version is a child element', () => {
  const csproj = `
<ItemGroup>
  <PackageReference Include="Serilog">
    <Version>3.1.1</Version>
  </PackageReference>
</ItemGroup>
`;
  const { dependencies } = parseCsproj(csproj);
  assert.deepStrictEqual(dependencies, [{ name: 'Serilog', version: '3.1.1' }]);
});

test('reads attributes declared in either order', () => {
  const csproj = '<PackageReference Version="8.0.0" Include="Microsoft.Extensions.Logging" />';
  const { dependencies } = parseCsproj(csproj);
  assert.deepStrictEqual(dependencies, [
    { name: 'Microsoft.Extensions.Logging', version: '8.0.0' },
  ]);
});

test('resolves a versionless PackageReference from central package management', () => {
  // Modern .NET moves versions into Directory.Packages.props; without this
  // join every dependency in a CPM repo would report as unresolved.
  const csproj = '<PackageReference Include="Newtonsoft.Json" />';
  const { dependencies } = parseCsproj(csproj, { packageVersions: { 'Newtonsoft.Json': '13.0.3' } });
  assert.deepStrictEqual(dependencies, [{ name: 'Newtonsoft.Json', version: '13.0.3' }]);
});

test('counts a versionless PackageReference as unresolved when no central version exists', () => {
  const { dependencies, unresolvedCount } = parseCsproj('<PackageReference Include="Newtonsoft.Json" />');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('prefers VersionOverride over the central package version', () => {
  const csproj = '<PackageReference Include="Newtonsoft.Json" VersionOverride="12.0.1" />';
  const { dependencies } = parseCsproj(csproj, { packageVersions: { 'Newtonsoft.Json': '13.0.3' } });
  assert.deepStrictEqual(dependencies, [{ name: 'Newtonsoft.Json', version: '12.0.1' }]);
});

test('flags a floating version as a range', () => {
  const { dependencies } = parseCsproj('<PackageReference Include="Foo" Version="6.0.*" />');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('flags a bracketed version range as a range', () => {
  const { dependencies } = parseCsproj('<PackageReference Include="Foo" Version="[6.0,7.0)" />');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('ignores ProjectReference entries', () => {
  const csproj = `
<ItemGroup>
  <ProjectReference Include="../Other/Other.csproj" />
  <PackageReference Include="Foo" Version="1.0.0" />
</ItemGroup>
`;
  const { dependencies } = parseCsproj(csproj);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['Foo']);
});

test('ignores a commented-out PackageReference', () => {
  const csproj = `
<!-- <PackageReference Include="Removed" Version="1.0.0" /> -->
<PackageReference Include="Kept" Version="2.0.0" />
`;
  const { dependencies } = parseCsproj(csproj);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['Kept']);
});

test('reads PackageVersion entries out of Directory.Packages.props', () => {
  const props = `
<Project>
  <ItemGroup>
    <PackageVersion Include="Newtonsoft.Json" Version="13.0.3" />
    <PackageVersion Include="Serilog" Version="3.1.1" />
  </ItemGroup>
</Project>
`;
  assert.deepStrictEqual(parseDirectoryPackagesProps(props), {
    'Newtonsoft.Json': '13.0.3',
    Serilog: '3.1.1',
  });
});

test('reads a legacy packages.config', () => {
  const config = `
<?xml version="1.0" encoding="utf-8"?>
<packages>
  <package id="Newtonsoft.Json" version="11.0.2" targetFramework="net472" />
  <package id="NLog" version="4.5.11" targetFramework="net472" />
</packages>
`;
  const { dependencies } = parsePackagesConfig(config);
  assert.deepStrictEqual(dependencies, [
    { name: 'Newtonsoft.Json', version: '11.0.2' },
    { name: 'NLog', version: '4.5.11' },
  ]);
});

test('returns no dependencies for a project file with none', () => {
  assert.deepStrictEqual(parseCsproj('<Project Sdk="Microsoft.NET.Sdk"></Project>'), {
    dependencies: [], unresolvedCount: 0,
  });
});

test('strips NuGet bracket syntax from an exact pin', () => {
  // "[13.0.3]" is NuGet's notation for exactly-this-version. Left as-is the
  // brackets would be sent to the registry as part of the version string.
  const { dependencies } = parseCsproj('<PackageReference Include="Foo" Version="[13.0.3]" />');
  assert.deepStrictEqual(dependencies, [{ name: 'Foo', version: '13.0.3' }]);
});

test('counts an MSBuild property version as unresolved', () => {
  // The property is defined elsewhere in the build; guessing is worse than
  // reporting it honestly as unresolved.
  const { dependencies, unresolvedCount } = parseCsproj('<PackageReference Include="Foo" Version="$(FooVersion)" />');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});
