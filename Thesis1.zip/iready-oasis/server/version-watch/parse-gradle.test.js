'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseGradleBuild, parseVersionCatalog } = require('./parse-gradle');

// ── build.gradle / build.gradle.kts ────────────────────────────────────────

test('reads a single-quoted Groovy coordinate', () => {
  const gradle = `
dependencies {
    implementation 'com.google.guava:guava:32.1.2-jre'
}
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, [
    { name: 'com.google.guava:guava', version: '32.1.2-jre' },
  ]);
});

test('reads a Kotlin DSL coordinate in parentheses', () => {
  const gradle = `
dependencies {
    implementation("org.jetbrains:annotations:24.0.1")
}
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, [
    { name: 'org.jetbrains:annotations', version: '24.0.1' },
  ]);
});

test('reads a map-style declaration', () => {
  const gradle = "testImplementation group: 'junit', name: 'junit', version: '4.13.2'";
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, [{ name: 'junit:junit', version: '4.13.2' }]);
});

test('reads a coordinate declared inside platform()', () => {
  // The BOM artifact itself carries an explicit version, so it is a real
  // dependency in use — distinct from a dependency whose version the BOM
  // supplies.
  const gradle = "implementation platform('org.springframework.boot:spring-boot-dependencies:3.2.0')";
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, [
    { name: 'org.springframework.boot:spring-boot-dependencies', version: '3.2.0' },
  ]);
});

test('counts an interpolated version as unresolved', () => {
  // The variable is defined elsewhere in the build (often a parent script);
  // Groovy is not a data format and this is not resolvable from one file.
  const gradle = `
dependencies {
    implementation "org.slf4j:slf4j-api:$slf4jVersion"
}
`;
  const { dependencies, unresolvedCount } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a curly-brace interpolated version as unresolved', () => {
  const gradle = 'implementation "org.slf4j:slf4j-api:${versions.slf4j}"';
  const { dependencies, unresolvedCount } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a versionless coordinate as unresolved', () => {
  // Two-part coordinates get their version from an imported BOM, which this
  // file does not contain.
  const gradle = "implementation 'org.springframework.boot:spring-boot-starter-web'";
  const { dependencies, unresolvedCount } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores a version catalog accessor without counting it unresolved', () => {
  // `libs.guava` is declared in gradle/libs.versions.toml, which is scanned as
  // its own manifest — counting the reference too would double-report it as a
  // failure when it is in fact fully resolved elsewhere.
  const gradle = `
dependencies {
    implementation(libs.guava)
    implementation libs.jackson.databind
}
`;
  const { dependencies, unresolvedCount } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 0);
});

test('ignores a line comment', () => {
  const gradle = `
dependencies {
    // implementation 'com.removed:removed:1.0.0'
    implementation 'com.kept:kept:2.0.0'
}
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['com.kept:kept']);
});

test('ignores a block comment', () => {
  const gradle = `
/*
implementation 'com.removed:removed:1.0.0'
*/
implementation 'com.kept:kept:2.0.0'
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['com.kept:kept']);
});

test('does not mistake a repository URL for a coordinate', () => {
  const gradle = `
repositories {
    maven { url 'https://repo.example.test/releases' }
}
`;
  const { dependencies, unresolvedCount } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 0);
});

test('does not mistake a plugin id for a coordinate', () => {
  const gradle = `
plugins {
    id 'java'
    id 'org.springframework.boot' version '3.2.0'
}
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, []);
});

test('reads a buildscript classpath coordinate', () => {
  const gradle = `
buildscript {
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.0'
    }
}
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.deepStrictEqual(dependencies, [
    { name: 'com.android.tools.build:gradle', version: '8.2.0' },
  ]);
});

test('reports the same coordinate once when it is declared twice', () => {
  const gradle = `
implementation 'com.google.guava:guava:32.1.2-jre'
testImplementation 'com.google.guava:guava:32.1.2-jre'
`;
  const { dependencies } = parseGradleBuild(gradle);
  assert.strictEqual(dependencies.length, 1);
});

test('returns no dependencies for a build file with none', () => {
  assert.deepStrictEqual(parseGradleBuild('plugins { id "java" }'), {
    dependencies: [], unresolvedCount: 0,
  });
});

// ── gradle/libs.versions.toml ──────────────────────────────────────────────

test('reads a catalog library with a literal version', () => {
  const toml = `
[libraries]
jackson = { group = "com.fasterxml.jackson.core", name = "jackson-databind", version = "2.15.0" }
`;
  const { dependencies } = parseVersionCatalog(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'com.fasterxml.jackson.core:jackson-databind', version: '2.15.0' },
  ]);
});

test('resolves a catalog version reference against the versions table', () => {
  const toml = `
[versions]
guava = "32.1.2-jre"

[libraries]
guava = { module = "com.google.guava:guava", version.ref = "guava" }
`;
  const { dependencies } = parseVersionCatalog(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'com.google.guava:guava', version: '32.1.2-jre' },
  ]);
});

test('reads a catalog library declared as a plain coordinate string', () => {
  const toml = `
[libraries]
commons = "org.apache.commons:commons-lang3:3.13.0"
`;
  const { dependencies } = parseVersionCatalog(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'org.apache.commons:commons-lang3', version: '3.13.0' },
  ]);
});

test('counts a catalog library with an unresolvable version reference as unresolved', () => {
  const toml = `
[libraries]
guava = { module = "com.google.guava:guava", version.ref = "missing" }
`;
  const { dependencies, unresolvedCount } = parseVersionCatalog(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a catalog library with no version as unresolved', () => {
  const toml = `
[libraries]
boot = { module = "org.springframework.boot:spring-boot-starter" }
`;
  const { dependencies, unresolvedCount } = parseVersionCatalog(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('returns no dependencies for a catalog with only a versions table', () => {
  assert.deepStrictEqual(parseVersionCatalog('[versions]\nguava = "32.1.2-jre"'), {
    dependencies: [], unresolvedCount: 0,
  });
});
