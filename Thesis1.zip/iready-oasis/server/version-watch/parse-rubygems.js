'use strict';

// Parses Gemfile.lock into DIRECT gems at their exact resolved versions.
//
// A lockfile carries both halves of what we need but in different places, and
// using either alone would be wrong:
//
//   - `specs:` lists every resolved gem, including the whole transitive
//     closure. Taking all of it would make Ruby rows mean something different
//     from every other ecosystem in this table, which reports direct
//     dependencies only.
//   - `DEPENDENCIES` names exactly what the Gemfile asked for, but carries
//     declared constraints ("rack (~> 2.2)") rather than resolved versions.
//
// Intersecting them yields direct gems at exact versions — better than parsing
// the Gemfile, which would give direct gems at ranges.
//
// A trailing "!" in DEPENDENCIES marks a gem sourced from GIT or PATH rather
// than rubygems.org. There is no registry release to compare such a gem
// against, so it is counted unresolved.
function parseGemfileLock(text) {
  const specs = new Map();
  const direct = [];

  let section = null;
  let inSpecs = false;

  for (const rawLine of String(text).split(/\r?\n/)) {
    if (!rawLine.trim()) continue;

    // Section headers sit at column zero (GEM, GIT, PATH, DEPENDENCIES,
    // PLATFORMS, BUNDLED WITH, CHECKSUMS, RUBY VERSION).
    if (/^\S/.test(rawLine)) {
      section = rawLine.trim();
      inSpecs = false;
      continue;
    }

    if (/^ {2}specs:\s*$/.test(rawLine)) { inSpecs = true; continue; }

    if (inSpecs) {
      // Exactly four spaces: a resolved gem. Six or more: one of that gem's
      // own dependency edges, which is how the transitive closure is expressed
      // and is deliberately skipped.
      const spec = rawLine.match(/^ {4}(\S+) \(([^)]+)\)\s*$/);
      if (spec) specs.set(spec[1], spec[2].trim());
      continue;
    }

    if (section === 'DEPENDENCIES') {
      const entry = rawLine.match(/^ {2}(\S+?)(!?)(?:\s+\([^)]*\))?\s*$/);
      if (entry) direct.push({ name: entry[1], fromSourceOtherThanRubygems: entry[2] === '!' });
    }
  }

  const dependencies = [];
  let unresolvedCount = 0;
  for (const { name, fromSourceOtherThanRubygems } of direct) {
    if (fromSourceOtherThanRubygems || !specs.has(name)) { unresolvedCount++; continue; }
    dependencies.push({ name, version: specs.get(name) });
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseGemfileLock };
