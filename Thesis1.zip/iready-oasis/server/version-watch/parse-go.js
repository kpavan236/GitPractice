'use strict';

// Parses go.mod into direct { name, version } entries.
//
// Unlike the other manifests this tool reads, go.mod lists transitive
// dependencies alongside direct ones, distinguished only by an `// indirect`
// comment. Those are skipped: every other ecosystem here reports direct
// dependencies, and including Go's transitive closure would make Go rows mean
// something different from every other row in the table.
//
// `replace`, `exclude`, and `retract` are ignored — none of them declares a
// dependency that is actually in use.
function parseGoMod(text) {
  const dependencies = [];
  let unresolvedCount = 0;

  // Which kind of parenthesised block we are inside, if any. Only `require`
  // blocks contribute dependencies, but the others must still be tracked so
  // their contents aren't read as bare require entries.
  let block = null;

  const addRequire = (spec, isIndirect) => {
    // Not counted as unresolved — an indirect dependency is deliberately out
    // of scope, not a version we failed to determine.
    if (isIndirect) return;
    const tokens = spec.trim().split(/\s+/).filter(Boolean);
    if (tokens.length < 2) { unresolvedCount++; return; }
    const [name, rawVersion] = tokens;
    // The module path keeps any /vN suffix: OSV and proxy.golang.org both
    // address `github.com/foo/bar/v2` as its own module, so dropping the
    // suffix would look up something else entirely.
    dependencies.push({ name, version: rawVersion.replace(/^v/, '') });
  };

  for (const rawLine of String(text).split(/\r?\n/)) {
    const isIndirect = /\/\/.*\bindirect\b/.test(rawLine);
    const line = rawLine.replace(/\/\/.*$/, '').trim();
    if (!line) continue;

    if (block) {
      if (line === ')') { block = null; continue; }
      if (block === 'require') addRequire(line, isIndirect);
      continue;
    }

    const blockOpen = line.match(/^(require|replace|exclude|retract)\s*\($/);
    if (blockOpen) { block = blockOpen[1]; continue; }

    const singleRequire = line.match(/^require\s+(.+)$/);
    if (singleRequire) { addRequire(singleRequire[1], isIndirect); continue; }

    // module / go / toolchain / single-line replace|exclude|retract — none of
    // these is a dependency in use.
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseGoMod };