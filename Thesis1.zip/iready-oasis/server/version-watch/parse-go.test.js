'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseGoMod } = require('./parse-go');

test('reads a single-line require directive', () => {
  const { dependencies } = parseGoMod('require github.com/pkg/errors v0.9.1');
  assert.deepStrictEqual(dependencies, [
    { name: 'github.com/pkg/errors', version: '0.9.1' },
  ]);
});

test('reads every entry in a require block', () => {
  const gomod = `
module github.com/cainc/example

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/stretchr/testify v1.8.4
)
`;
  const { dependencies } = parseGoMod(gomod);
  assert.deepStrictEqual(dependencies.map(d => d.name), [
    'github.com/gin-gonic/gin',
    'github.com/stretchr/testify',
  ]);
});

test('strips the leading v from the version', () => {
  // Every other ecosystem in this tool reports bare numeric versions, and
  // compareVersions segments on dots — a leading "v" would sort as a
  // non-numeric segment against a registry list that has been normalized.
  const { dependencies } = parseGoMod('require golang.org/x/sys v0.15.0');
  assert.strictEqual(dependencies[0].version, '0.15.0');
});

test('skips dependencies marked // indirect', () => {
  const gomod = `
require (
	github.com/gin-gonic/gin v1.9.1
	golang.org/x/sys v0.15.0 // indirect
	github.com/bytedance/sonic v1.10.0 // indirect
)
`;
  const { dependencies } = parseGoMod(gomod);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['github.com/gin-gonic/gin']);
});

test('keeps a major-version suffix as part of the module path', () => {
  // OSV and proxy.golang.org both address this module as .../v2 — dropping
  // the suffix would look up an entirely different module.
  const { dependencies } = parseGoMod('require github.com/foo/bar/v2 v2.1.0');
  assert.strictEqual(dependencies[0].name, 'github.com/foo/bar/v2');
});

test('ignores replace directives', () => {
  const gomod = `
require github.com/real/dep v1.0.0

replace github.com/real/dep => ./vendored/dep

replace (
	github.com/other/dep => github.com/fork/dep v1.2.3
)
`;
  const { dependencies } = parseGoMod(gomod);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['github.com/real/dep']);
});

test('ignores exclude and retract directives', () => {
  const gomod = `
exclude github.com/bad/pkg v1.0.0

retract v1.9.9

require github.com/good/pkg v2.0.0
`;
  const { dependencies } = parseGoMod(gomod);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['github.com/good/pkg']);
});

test('ignores the module and go directives', () => {
  const { dependencies } = parseGoMod('module github.com/x/y\n\ngo 1.21\n');
  assert.deepStrictEqual(dependencies, []);
});

test('reports go.mod versions as exact rather than ranges', () => {
  // go.mod records a resolved minimum, not a range — so the vulnerability
  // lookup result applies to a real version and needs no caveat marker.
  const { dependencies } = parseGoMod('require github.com/pkg/errors v0.9.1');
  assert.notStrictEqual(dependencies[0].versionIsRange, true);
});

test('keeps a pseudo-version so an untagged commit pin stays visible', () => {
  const gomod = 'require golang.org/x/net v0.0.0-20231025123456-abcdef123456';
  const { dependencies } = parseGoMod(gomod);
  assert.strictEqual(dependencies[0].version, '0.0.0-20231025123456-abcdef123456');
});

test('counts a require entry with no version as unresolved', () => {
  const { dependencies, unresolvedCount } = parseGoMod('require (\n\tgithub.com/x/y\n)');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('returns no dependencies for an empty file', () => {
  assert.deepStrictEqual(parseGoMod(''), { dependencies: [], unresolvedCount: 0 });
});