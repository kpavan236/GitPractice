'use strict';
const realAxios = require('axios');
const https = require('https');
const tls = require('tls');
const { execFileSync } = require('child_process');

// Node ships its own Mozilla CA bundle and ignores the OS trust store. On a
// managed machine behind a TLS-intercepting proxy (Zscaler, Netskope, etc.)
// the proxy re-signs traffic with a corporate root that lives in the system
// keychain but not in Node's bundle, so requests die with "unable to get
// local issuer certificate" — even though curl and Chrome, which do read the
// system store, connect fine. Package registries are typically on such a
// proxy's bypass list; api.osv.dev is not, which is why only the OSV lookup
// failed while npm/PyPI/Maven Central kept working.
//
// Merging the OS roots into Node's set fixes that without weakening anything:
// verification stays on, we just trust what the OS already trusts. Disabling
// rejectUnauthorized would be the wrong trade for a feed whose whole purpose
// is reporting security findings.
//
// Built once and cached — shelling out per request across hundreds of rows
// would be absurd. On platforms where the roots can't be read the agent falls
// back to Node's defaults, and any resulting failure surfaces honestly through
// `cvesUnavailable` rather than as a clean bill of health.
const PEM_BLOCK = /-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----/g;
let _osvAgent;
function osvHttpsAgent() {
  if (_osvAgent !== undefined) return _osvAgent;
  const extra = [];
  if (process.platform === 'darwin') {
    for (const keychain of [
      '/Library/Keychains/System.keychain',
      '/System/Library/Keychains/SystemRootCertificates.keychain',
    ]) {
      try {
        const pem = execFileSync('security', ['find-certificate', '-a', '-p', keychain],
          { encoding: 'utf8', timeout: 5000, maxBuffer: 8 * 1024 * 1024 });
        extra.push(...(pem.match(PEM_BLOCK) || []));
      } catch (_) { /* keychain unreadable — fall through to whatever we have */ }
    }
  }
  _osvAgent = new https.Agent({ ca: [...tls.rootCertificates, ...extra], keepAlive: true });
  return _osvAgent;
}

// Caps a stored advisory summary. The full `details` field runs to paragraphs of
// Markdown, the UI only ever renders the first ~120 characters, and a single
// long-stale artifact can match 70 advisories — across an org-wide scan that
// text was the bulk of a cache file that already exceeds a megabyte and is
// shipped to the browser in full on every load.
const SUMMARY_MAX_LENGTH = 200;

function truncateSummary(text) {
  const summary = String(text || '');
  return summary.length > SUMMARY_MAX_LENGTH ? `${summary.slice(0, SUMMARY_MAX_LENGTH - 1)}…` : summary;
}

// Looks up known vulnerabilities for one package version in any OSV-covered
// ecosystem — 'Maven', 'npm', 'PyPI', 'Go', 'crates.io', 'NuGet', 'RubyGems',
// 'Packagist'. One feed for every ecosystem this tool tracks means findings
// carry the same provenance and the same severity vocabulary regardless of
// language.
//
// Uses /v1/query rather than /v1/querybatch: the batch endpoint returns only
// {id, modified} per hit, so a heavily-affected artifact (jackson-databind
// 2.9.0 matches 69 advisories) would need one extra GET per advisory to render
// anything. /v1/query returns complete records in a single call.
//
// Never throws — enrichment failures are per-row, non-fatal (see `error`), not
// scan-fatal.
// OSV's ecosystem names are not the ones the mirror files are keyed by, and the
// mapping already exists in the mirror builder — imported rather than repeated,
// so the two cannot drift into disagreeing about what "Packagist" is called.
function mirrorKeyFor(ecosystem) {
  const { ECOSYSTEMS } = require('../../../tools/build-advisories');
  return ECOSYSTEMS[ecosystem] || String(ecosystem || '').toLowerCase();
}

let _mirror;
function advisoryMirror() {
  if (_mirror === undefined) {
    const { createMirror } = require('../../security/advisories/mirror');
    _mirror = createMirror();
  }
  return _mirror;
}

async function fetchOsvVulnerabilities(ecosystem, name, version, httpClient = realAxios, options = {}) {
  const { mirror = advisoryMirror(), env = process.env } = options;

  // The offline mirror, when one has been built for this ecosystem.
  //
  // Tried FIRST rather than as a fallback, because its main job is to remove a
  // network round trip per dependency — on a Maven tree of four hundred
  // coordinates that is most of the scan's wall time — and its second job is to
  // work at all on a network that cannot reach api.osv.dev.
  //
  // `lookup` returns null for an ecosystem that is not mirrored, which is NOT
  // the same as an empty result. Only a real array short-circuits the network;
  // null falls through, so an unmirrored ecosystem is never silently reported
  // as clean.
  if (mirror) {
    const hits = mirror.lookup(mirrorKeyFor(ecosystem), name, version);
    if (hits) {
      return {
        cves: hits.map(v => ({
          id: (v.aliases || []).find(a => a.startsWith('CVE-')) || v.id || null,
          severity: typeof v.severity === 'string' ? v.severity.toLowerCase() : null,
          summary: truncateSummary(v.summary || ''),
          url: v.url,
        })),
        error: null,
        source: 'mirror',
      };
    }
  }

  // Air-gapped installs say so explicitly. Without this, an unmirrored
  // ecosystem on a network with no route to api.osv.dev spends eight seconds
  // timing out per dependency and then reports nothing — slowly, and looking
  // exactly like a clean result.
  if (env.OASIS_ADVISORY_OFFLINE === '1') {
    return {
      cves: [],
      error: `${ecosystem} is not in the offline advisory mirror, and the network is disabled`,
      source: 'offline',
    };
  }

  try {
    const resp = await httpClient.post(
      'https://api.osv.dev/v1/query',
      { package: { name, ecosystem }, version },
      { timeout: 8000, httpsAgent: osvHttpsAgent() }
    );
    const vulns = resp.data?.vulns || [];
    return {
      cves: vulns
        // OSV keeps retracted advisories in the corpus, flagged with a
        // `withdrawn` timestamp — reporting those as live findings would be wrong.
        .filter(v => !v.withdrawn)
        .map(v => ({
          // Prefer the CVE alias over OSV's own id (usually a GHSA). OSV lists
          // aliases in no guaranteed order, and a GHSA id shown where a CVE
          // exists is harder to cross-reference.
          id: (v.aliases || []).find(a => a.startsWith('CVE-')) || v.id || null,
          // `database_specific.severity` is the plain CRITICAL/HIGH/MODERATE/LOW
          // label, present on GitHub-reviewed advisories. Lowercased to match
          // npm's convention so one casing reaches the UI. Left null when
          // absent — rendered as "unknown", which is distinct from "low".
          severity: (v.database_specific?.severity || '').toLowerCase() || null,
          summary: truncateSummary(v.summary || v.details || ''),
          url: (v.references || []).find(r => r.type === 'ADVISORY')?.url
            || (v.id ? `https://osv.dev/vulnerability/${v.id}` : null),
        })),
      error: null,
      source: 'api',
    };
  } catch (e) {
    return { cves: [], error: e.message, source: 'api' };
  }
}

module.exports = { fetchOsvVulnerabilities, osvHttpsAgent, truncateSummary, mirrorKeyFor, SUMMARY_MAX_LENGTH };
