'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published releases of an Elixir/Erlang package from hex.pm.
//
// `latest_stable_version` is preferred over `latest_version`, which includes
// release candidates — an rc is not an upgrade target.
async function fetchHexLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://hex.pm/api/packages/${encodeURIComponent(name)}`, { timeout: 8000 });
    const releases = (resp.data?.releases || []).filter(r => r?.version);
    const releaseDates = new Map(releases.map(r => [r.version, r.inserted_at || null]));

    const tiers = await resolveTiers({
      versions: releases.map(r => r.version),
      versionInUse,
      latestVersion: resp.data?.latest_stable_version || resp.data?.latest_version || null,
      dateForVersion: version => releaseDates.get(version) || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on hex.pm — normal for a package from a private Hex repository.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchHexLatest };
