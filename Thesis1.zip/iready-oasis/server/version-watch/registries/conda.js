'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the versions available for a conda package.
//
// Queries conda-forge, which is where the overwhelming majority of conda
// dependencies come from. A package published only to defaults or to a private
// channel will 404 here, which is reported as "not found" rather than as an
// error — the same treatment an internal Maven coordinate gets.
//
// The API's version list carries no publication dates (they live in the much
// larger per-file payload), so dates are reported as null.
async function fetchCondaLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(
      `https://api.anaconda.org/package/conda-forge/${encodeURIComponent(name)}`,
      { timeout: 8000 }
    );
    const tiers = await resolveTiers({
      versions: (resp.data?.versions || []).filter(Boolean).map(String),
      versionInUse,
      latestVersion: resp.data?.latest_version || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchCondaLatest };
