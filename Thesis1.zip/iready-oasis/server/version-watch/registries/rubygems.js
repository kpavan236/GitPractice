'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published versions of a gem. One request returns every version
// with its publication date, so no per-version lookups are needed.
//
// Prereleases are left in the list rather than filtered on the API's
// `prerelease` flag — pickLatest already prefers stable versions and falls back
// to prereleases only when a gem has never published a stable one, which is the
// behaviour every other ecosystem here gets.
async function fetchRubygemsLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(
      `https://rubygems.org/api/v1/versions/${encodeURIComponent(name)}.json`,
      { timeout: 8000 }
    );
    const published = (Array.isArray(resp.data) ? resp.data : []).filter(v => v?.number);
    const releaseDates = new Map(published.map(v => [v.number, v.created_at || null]));

    const tiers = await resolveTiers({
      versions: published.map(v => v.number),
      versionInUse,
      dateForVersion: version => releaseDates.get(version) || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on rubygems.org — normal for a gem vendored from a private source.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchRubygemsLatest };
