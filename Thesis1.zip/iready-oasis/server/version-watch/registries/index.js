'use strict';

// Barrel for the per-registry modules.
//
// This directory replaced a single 314-line registries.js. That file already
// repeated the tier-resolution block three times; carrying nine ecosystems in
// the same shape would have meant repeating it nine times in a file past 700
// lines. The shared logic now lives in tiers.js and osv.js, and each registry
// module holds only what is genuinely specific to that registry's API.
//
// `require('./registries')` resolves here, so scan.js's injectable `registries`
// seam and the existing tests keep working unchanged.

const { fetchMavenLatest, fetchMavenVulnerabilities } = require('./maven');
const { fetchNpmLatest, fetchNpmAdvisories } = require('./npm');
const { fetchPipLatest, fetchPipVulnerabilities } = require('./pip');
const { fetchGoLatest } = require('./go');
const { fetchCargoLatest } = require('./cargo');
const { fetchNugetLatest } = require('./nuget');
const { fetchRubygemsLatest } = require('./rubygems');
const { fetchComposerLatest } = require('./composer');
const { fetchPubLatest } = require('./pub');
const { fetchHexLatest } = require('./hex');
const { fetchHackageLatest } = require('./hackage');
const { fetchCpanLatest } = require('./cpan');
const { fetchConanLatest } = require('./conan');
const { fetchCondaLatest } = require('./conda');
const { fetchOsvVulnerabilities } = require('./osv');

module.exports = {
  fetchMavenLatest, fetchMavenVulnerabilities,
  fetchNpmLatest, fetchNpmAdvisories,
  fetchPipLatest, fetchPipVulnerabilities,
  fetchGoLatest, fetchCargoLatest, fetchNugetLatest,
  fetchRubygemsLatest, fetchComposerLatest,
  fetchPubLatest, fetchHexLatest, fetchHackageLatest,
  fetchCpanLatest, fetchConanLatest, fetchCondaLatest,
  fetchOsvVulnerabilities,
};
