'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchRubygemsLatest } = require('./rubygems');

const VERSIONS = [
  { number: '2.2.8', created_at: '2024-02-01T00:00:00Z', prerelease: false },
  { number: '2.2.6.4', created_at: '2023-03-01T00:00:00Z', prerelease: false },
  { number: '3.0.0.beta1', created_at: '2024-04-01T00:00:00Z', prerelease: true },
];

test('reads the version list from the rubygems API', async () => {
  let recordedUrl = null;
  const fakeClient = { get: async (url) => { recordedUrl = url; return { data: VERSIONS }; } };
  await fetchRubygemsLatest('rack', '2.2.6.4', fakeClient);
  assert.equal(recordedUrl, 'https://rubygems.org/api/v1/versions/rack.json');
});

test('prefers the highest stable version over a prerelease', async () => {
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchRubygemsLatest('rack', '2.2.6.4', fakeClient);
  assert.equal(result.latestVersion, '2.2.8');
});

test('reads the release date from the matching version entry', async () => {
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchRubygemsLatest('rack', '2.2.6.4', fakeClient);
  assert.equal(result.latestReleaseDate, '2024-02-01T00:00:00Z');
});

test('resolves the tier within the current major', async () => {
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchRubygemsLatest('rack', '2.2.6.4', fakeClient);
  assert.equal(result.latestMinorVersion, '2.2.8');
});

test('reports no error for a gem that is not on rubygems.org', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; } };
  const result = await fetchRubygemsLatest('internal-gem', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('returns an error message when the request fails outright', async () => {
  const fakeClient = { get: async () => { throw new Error('rubygems timeout'); } };
  const result = await fetchRubygemsLatest('rack', '2.2.6.4', fakeClient);
  assert.equal(result.error, 'rubygems timeout');
});
