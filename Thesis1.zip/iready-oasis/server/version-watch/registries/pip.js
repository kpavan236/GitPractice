'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');
const { fetchOsvVulnerabilities } = require('./osv');

// Looks up latest version, release date, and the latest versions within the
// current major and patch line for a PyPI project. Every tier and date comes
// out of the `releases` object already present in this one response.
//
// `latestVersion` uses PyPI's own `info.version` rather than the highest key in
// `releases`, for the same reason npm uses dist-tags: it is the maintainer's
// statement about what should be installed.
async function fetchPipLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://pypi.org/pypi/${encodeURIComponent(name)}/json`, { timeout: 8000 });
    const releases = resp.data?.releases || {};
    const tiers = await resolveTiers({
      versions: Object.keys(releases),
      versionInUse,
      latestVersion: resp.data?.info?.version || null,
      dateForVersion: version => releases[version]?.[0]?.upload_time_iso_8601 || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    return { ...NO_TIERS, error: e.message };
  }
}

// Looks up known vulnerabilities for a PyPI project + version through OSV.
//
// PyPI's own per-version JSON carries a `vulnerabilities` field sourced from
// the same OSV corpus, but strips the severity out of it — every Python finding
// came back with a null severity and rendered as "unknown", which is
// indistinguishable from an advisory that genuinely has no rating. Querying OSV
// directly restores real severity labels and puts Python rows on the same feed
// as every other ecosystem here.
async function fetchPipVulnerabilities(name, version, httpClient = realAxios) {
  return fetchOsvVulnerabilities('PyPI', name, version, httpClient);
}

module.exports = { fetchPipLatest, fetchPipVulnerabilities };
