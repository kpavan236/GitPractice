'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchNugetLatest } = require('./nuget');

const VERSIONS = { versions: ['12.0.1', '13.0.1', '13.0.3', '14.0.0-beta1'] };

test('reads the version list from the flat container', async () => {
  let recordedUrl = null;
  const fakeClient = { get: async (url) => { recordedUrl = url; return { data: VERSIONS }; } };
  await fetchNugetLatest('Newtonsoft.Json', '13.0.1', fakeClient);
  assert.equal(recordedUrl, 'https://api.nuget.org/v3-flatcontainer/newtonsoft.json/index.json');
});

test('lowercases the package id because the flat container requires it', async () => {
  // api.nuget.org's flat container addresses packages by lowercased id; the
  // PascalCase id from the project file 404s.
  let recordedUrl = null;
  const fakeClient = { get: async (url) => { recordedUrl = url; return { data: VERSIONS }; } };
  await fetchNugetLatest('Microsoft.Extensions.Logging', '8.0.0', fakeClient);
  assert.ok(recordedUrl.includes('/microsoft.extensions.logging/'));
});

test('prefers the highest stable version over a prerelease', async () => {
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchNugetLatest('Newtonsoft.Json', '12.0.1', fakeClient);
  assert.equal(result.latestVersion, '13.0.3');
});

test('resolves the tier within the current major', async () => {
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchNugetLatest('Newtonsoft.Json', '13.0.1', fakeClient);
  assert.equal(result.latestMinorVersion, '13.0.3');
});

test('reports null release dates because the flat container carries none', async () => {
  // The flat container is one cheap request per package and lists every
  // version, but no timestamps. The paginated registration index does carry
  // them, at the cost of extra requests per package across an org-wide scan —
  // and this table treats the date as decoration beside the version. So the
  // version is reported and the date is honestly null.
  const fakeClient = { get: async () => ({ data: VERSIONS }) };
  const result = await fetchNugetLatest('Newtonsoft.Json', '12.0.1', fakeClient);
  assert.equal(result.latestVersion, '13.0.3');
  assert.equal(result.latestReleaseDate, null);
});

test('reports no error for a package that is not on nuget.org', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; } };
  const result = await fetchNugetLatest('Internal.Package', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('returns an error message when the request fails outright', async () => {
  const fakeClient = { get: async () => { throw new Error('nuget timeout'); } };
  const result = await fetchNugetLatest('Newtonsoft.Json', '13.0.1', fakeClient);
  assert.equal(result.error, 'nuget timeout');
});
