'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchPubLatest } = require('./pub');
const { fetchHexLatest } = require('./hex');
const { fetchHackageLatest } = require('./hackage');
const { fetchCpanLatest } = require('./cpan');
const { fetchConanLatest } = require('./conan');
const { fetchCondaLatest } = require('./conda');

// Every one of these follows the same contract as the original three: never
// throw, report `error: null` when a package simply is not on the registry
// (normal for internal packages), and report a message when the request itself
// failed.

// ── pub.dev (Dart) ──────────────────────────────────────────────────────────

const PUB_RESPONSE = {
  name: 'http',
  latest: { version: '1.1.2', published: '2024-01-05T00:00:00Z' },
  versions: [
    { version: '1.1.0', published: '2023-08-01T00:00:00Z' },
    { version: '1.1.2', published: '2024-01-05T00:00:00Z' },
    { version: '2.0.0-beta', published: '2024-02-01T00:00:00Z' },
  ],
};

test('pub reads the package metadata from the pub.dev API', async () => {
  let url = null;
  const client = { get: async (u) => { url = u; return { data: PUB_RESPONSE }; } };
  await fetchPubLatest('http', '1.1.0', client);
  assert.equal(url, 'https://pub.dev/api/packages/http');
});

test('pub prefers the registry own latest pointer over a newer prerelease', async () => {
  const client = { get: async () => ({ data: PUB_RESPONSE }) };
  const result = await fetchPubLatest('http', '1.1.0', client);
  assert.equal(result.latestVersion, '1.1.2');
  assert.equal(result.latestReleaseDate, '2024-01-05T00:00:00Z');
});

test('pub reports no error for a package that is not on pub.dev', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  const result = await fetchPubLatest('internal_pkg', '1.0.0', client);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('pub returns an error message when the request fails outright', async () => {
  const client = { get: async () => { throw new Error('pub timeout'); } };
  assert.equal((await fetchPubLatest('http', '1.0.0', client)).error, 'pub timeout');
});

// ── hex.pm (Elixir) ─────────────────────────────────────────────────────────

const HEX_RESPONSE = {
  name: 'phoenix',
  latest_stable_version: '1.7.11',
  latest_version: '1.8.0-rc.0',
  releases: [
    { version: '1.7.11', inserted_at: '2024-01-15T00:00:00Z' },
    { version: '1.7.10', inserted_at: '2023-11-01T00:00:00Z' },
    { version: '1.8.0-rc.0', inserted_at: '2024-03-01T00:00:00Z' },
  ],
};

test('hex reads the package metadata from the hex.pm API', async () => {
  let url = null;
  const client = { get: async (u) => { url = u; return { data: HEX_RESPONSE }; } };
  await fetchHexLatest('phoenix', '1.7.10', client);
  assert.equal(url, 'https://hex.pm/api/packages/phoenix');
});

test('hex prefers the latest stable version over a release candidate', async () => {
  const client = { get: async () => ({ data: HEX_RESPONSE }) };
  const result = await fetchHexLatest('phoenix', '1.7.10', client);
  assert.equal(result.latestVersion, '1.7.11');
  assert.equal(result.latestReleaseDate, '2024-01-15T00:00:00Z');
});

test('hex reports no error for a package that is not on hex.pm', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  assert.equal((await fetchHexLatest('internal', '1.0.0', client)).error, null);
});

// ── Hackage (Haskell) ───────────────────────────────────────────────────────

test('hackage reads the preferred-versions endpoint as JSON', async () => {
  let url = null, config = null;
  const client = {
    get: async (u, c) => { url = u; config = c; return { data: { 'normal-version': ['2.1.2.1', '2.1.0.0'] } }; },
  };
  await fetchHackageLatest('aeson', '2.1.0.0', client);
  assert.equal(url, 'https://hackage.haskell.org/package/aeson/preferred');
  // Hackage serves HTML by default and only returns JSON when asked.
  assert.match(config.headers.Accept, /json/);
});

test('hackage picks the highest normal version', async () => {
  const client = { get: async () => ({ data: { 'normal-version': ['2.1.0.0', '2.2.0.0', '2.1.2.1'] } }) };
  const result = await fetchHackageLatest('aeson', '2.1.0.0', client);
  assert.equal(result.latestVersion, '2.2.0.0');
});

test('hackage reports null release dates because the endpoint carries none', async () => {
  const client = { get: async () => ({ data: { 'normal-version': ['2.2.0.0'] } }) };
  const result = await fetchHackageLatest('aeson', '2.1.0.0', client);
  assert.equal(result.latestVersion, '2.2.0.0');
  assert.equal(result.latestReleaseDate, null);
});

test('hackage reports no error for a package it does not know', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  assert.equal((await fetchHackageLatest('nope', '1.0', client)).error, null);
});

// ── MetaCPAN (Perl) ─────────────────────────────────────────────────────────

test('cpan looks the module up by name, not by distribution', async () => {
  // A cpanfile names modules (Test::More); MetaCPAN's module endpoint maps one
  // to whichever distribution currently ships it.
  let url = null;
  const client = { get: async (u) => { url = u; return { data: { version: '0.98', date: '2023-01-01T00:00:00Z' } }; } };
  await fetchCpanLatest('Test::More', '0.98', client);
  assert.equal(url, 'https://fastapi.metacpan.org/v1/module/Test::More');
});

test('cpan reports the latest indexed version and its date', async () => {
  const client = { get: async () => ({ data: { version: '1.0049', date: '2024-02-02T00:00:00Z' } }) };
  const result = await fetchCpanLatest('Plack', '1.0048', client);
  assert.equal(result.latestVersion, '1.0049');
  assert.equal(result.latestReleaseDate, '2024-02-02T00:00:00Z');
});

test('cpan reports no error for a module MetaCPAN does not index', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  assert.equal((await fetchCpanLatest('Internal::Module', '1.0', client)).error, null);
});

// ── Conan Center (C/C++) ────────────────────────────────────────────────────

test('conan reads the recipe config from the conan-center-index repository', async () => {
  // Conan Center exposes no version API; the index repository's config.yml is
  // the authoritative list of packaged versions.
  let url = null;
  const client = { get: async (u) => { url = u; return { data: 'versions:\n  "1.2.13":\n    folder: all\n' }; } };
  await fetchConanLatest('zlib', '1.2.11', client);
  assert.match(url, /conan-center-index\/master\/recipes\/zlib\/config\.yml$/);
});

test('conan picks the highest packaged version', async () => {
  const yaml = 'versions:\n  "1.2.11":\n    folder: all\n  "1.3.1":\n    folder: all\n  "1.2.13":\n    folder: all\n';
  const client = { get: async () => ({ data: yaml }) };
  const result = await fetchConanLatest('zlib', '1.2.11', client);
  assert.equal(result.latestVersion, '1.3.1');
  // The patch tier is the same-major.minor line; 1.3.1 is the same-major tier.
  assert.equal(result.latestPatchVersion, '1.2.13');
});

test('conan reports no error for a package not in Conan Center', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  assert.equal((await fetchConanLatest('internal-lib', '1.0', client)).error, null);
});

// ── anaconda.org (Conda) ────────────────────────────────────────────────────

test('conda reads the package metadata from the anaconda.org API', async () => {
  let url = null;
  const client = { get: async (u) => { url = u; return { data: { latest_version: '1.26.4', versions: ['1.24.3', '1.26.4'] } }; } };
  await fetchCondaLatest('numpy', '1.24.3', client);
  assert.equal(url, 'https://api.anaconda.org/package/conda-forge/numpy');
});

test('conda reports the channel latest version', async () => {
  const client = { get: async () => ({ data: { latest_version: '1.26.4', versions: ['1.24.3', '1.25.0', '1.26.4'] } }) };
  const result = await fetchCondaLatest('numpy', '1.24.3', client);
  assert.equal(result.latestVersion, '1.26.4');
});

test('conda reports no error for a package not on conda-forge', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const client = { get: async () => { throw notFound; } };
  assert.equal((await fetchCondaLatest('internal', '1.0', client)).error, null);
});
