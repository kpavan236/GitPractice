'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchGoLatest } = require('./go');

const VERSION_LIST = 'v1.8.0\nv1.9.0\nv1.9.1\nv2.0.0\n';

function clientReturning(list, info = {}) {
  return {
    get: async (url) => {
      if (url.endsWith('/@v/list')) return { data: list };
      const version = url.match(/@v\/(.+)\.info$/)?.[1];
      return { data: info[version] || {} };
    },
  };
}

test('reads the version list from the module proxy', async () => {
  let recordedUrl = null;
  const fakeClient = {
    get: async (url) => { if (url.endsWith('/list')) { recordedUrl = url; return { data: VERSION_LIST }; } return { data: {} }; },
  };
  await fetchGoLatest('github.com/pkg/errors', '0.9.1', fakeClient);
  assert.equal(recordedUrl, 'https://proxy.golang.org/github.com/pkg/errors/@v/list');
});

test('escapes uppercase letters in the module path', async () => {
  // The Go module proxy requires uppercase letters to be escaped as !lower,
  // because module paths are case-sensitive but many filesystems are not.
  // Unescaped, every module with a capitalised path segment 404s.
  let recordedUrl = null;
  const fakeClient = {
    get: async (url) => { if (url.endsWith('/list')) { recordedUrl = url; return { data: '' }; } return { data: {} }; },
  };
  await fetchGoLatest('github.com/Azure/azure-sdk-for-go', '1.0.0', fakeClient);
  assert.equal(recordedUrl, 'https://proxy.golang.org/github.com/!azure/azure-sdk-for-go/@v/list');
});

test('strips the leading v from every listed version', async () => {
  const result = await fetchGoLatest('github.com/x/y', '1.8.0', clientReturning(VERSION_LIST));
  assert.equal(result.latestVersion, '2.0.0');
  assert.equal(result.latestMinorVersion, '1.9.1');
});

test('resolves the patch tier within the current minor line', async () => {
  const result = await fetchGoLatest('github.com/x/y', '1.9.0', clientReturning(VERSION_LIST));
  assert.equal(result.latestPatchVersion, '1.9.1');
});

test('reads a release date from the version info endpoint', async () => {
  const info = { 'v2.0.0': { Version: 'v2.0.0', Time: '2024-03-01T10:00:00Z' } };
  const result = await fetchGoLatest('github.com/x/y', '1.8.0', clientReturning(VERSION_LIST, info));
  assert.equal(result.latestReleaseDate, '2024-03-01T10:00:00Z');
});

test('reports no error for a module the proxy does not know', async () => {
  // Internal modules are not on the public proxy. That is expected, not a
  // failed lookup — reporting it as an error would flag every in-house module.
  const notFound = Object.assign(new Error('Request failed with status code 404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; } };
  const result = await fetchGoLatest('github.internal/x/y', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('reports no error when the proxy returns gone for a withdrawn module', async () => {
  const gone = Object.assign(new Error('Request failed with status code 410'), { response: { status: 410 } });
  const fakeClient = { get: async () => { throw gone; } };
  const result = await fetchGoLatest('github.com/x/y', '1.0.0', fakeClient);
  assert.equal(result.error, null);
});

test('returns an error message when the proxy request fails outright', async () => {
  const fakeClient = { get: async () => { throw new Error('proxy timeout'); } };
  const result = await fetchGoLatest('github.com/x/y', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, 'proxy timeout');
});

test('returns null tiers for a module with no published versions', async () => {
  const result = await fetchGoLatest('github.com/x/y', '1.0.0', clientReturning(''));
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});
