'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the latest indexed version of a Perl module.
//
// A cpanfile names MODULES (Test::More), while CPAN releases DISTRIBUTIONS
// (Test-Simple). MetaCPAN's module endpoint resolves that mapping for us and
// returns the version of the module itself, which is what the cpanfile
// constrains — going via the distribution would compare against a different
// version number entirely.
//
// Only the latest version is available from this endpoint, so the minor and
// patch tiers cannot be offered; resolveTiers is given the one version it knows.
async function fetchCpanLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(
      `https://fastapi.metacpan.org/v1/module/${name}`,
      { timeout: 8000 }
    );
    const latestVersion = resp.data?.version != null ? String(resp.data.version) : null;
    const releaseDate = resp.data?.date || null;

    const tiers = await resolveTiers({
      versions: latestVersion ? [latestVersion] : [],
      versionInUse,
      latestVersion,
      dateForVersion: () => releaseDate,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not indexed on MetaCPAN — normal for an in-house module.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchCpanLatest };
