'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published versions of a Packagist package.
//
// Packagist reports the git tag verbatim, so one package's history routinely
// mixes "3.5.0" and "v3.4.0". The prefix is stripped here so the whole list
// compares on one convention — left in place, a "v" would be read as a
// non-numeric leading segment and sort unpredictably against its siblings.
//
// The package name is interpolated unescaped because Packagist's path is
// literally `vendor/name`: percent-encoding the separator would break the URL.
// Names come from a parsed composer.json `require` key and are constrained to
// the vendor/name shape by parse-composer.
async function fetchComposerLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://repo.packagist.org/p2/${name}.json`, { timeout: 8000 });
    const releases = resp.data?.packages?.[name] || [];

    const versions = [];
    const releaseDates = new Map();
    for (const release of releases) {
      if (!release?.version) continue;
      const version = String(release.version).replace(/^v/, '');
      versions.push(version);
      // Packagist lists newest first; keeping the first date seen means a
      // duplicate tag can't overwrite the canonical release with an older one.
      if (!releaseDates.has(version)) releaseDates.set(version, release.time || null);
    }

    const tiers = await resolveTiers({
      versions,
      versionInUse,
      dateForVersion: version => releaseDates.get(version) || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on Packagist — normal for a package from a private VCS repository.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchComposerLatest };
