'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');
const { fetchOsvVulnerabilities } = require('./osv');

const MAVEN_CENTRAL_BASE = 'https://repo1.maven.org/maven2';

// Reads a single version's publication date from the Last-Modified header of
// its .pom. maven-metadata.xml lists versions but carries no per-version
// timestamps, and the UI shows a release date beside each version.
//
// Best-effort by design: the date is decoration, the version is the point, so
// a failed HEAD yields null rather than discarding a version we already
// resolved successfully.
async function fetchMavenReleaseDate(artifactBase, artifactId, version, httpClient) {
  if (!version) return null;
  try {
    const resp = await httpClient.head(`${artifactBase}/${version}/${artifactId}-${version}.pom`, { timeout: 8000 });
    const lastModified = resp.headers?.['last-modified'];
    return lastModified ? new Date(lastModified).toISOString() : null;
  } catch (_) {
    return null;
  }
}

// Looks up the latest version + release date for a Maven artifact, plus the
// latest versions within the current major and patch line.
//
// Reads maven-metadata.xml straight from the repo1 CDN rather than Maven
// Central's Solr search API. The search API hard-caps at roughly 10 concurrent
// requests and drops everything above it: measured against a burst of 20, it
// served 10 and hung on the rest, which is exactly the shape of this scan's
// throttle — so most Maven rows came back empty with timeouts and 403s. The
// CDN answered the same burst 20/20 in well under a second each, because it
// exists to be hammered by build tools.
//
// The metadata file also lists EVERY published version, removing the old
// rows:100 truncation that could hide the real latest version for long-lived
// artifacts (mysql-connector-java alone has 92).
//
// Never throws — enrichment failures are per-row, non-fatal (see `error`),
// not scan-fatal.
async function fetchMavenLatest(groupId, artifactId, versionInUse, httpClient = realAxios) {
  const artifactBase = `${MAVEN_CENTRAL_BASE}/${groupId.replace(/\./g, '/')}/${artifactId}`;
  try {
    const resp = await httpClient.get(`${artifactBase}/maven-metadata.xml`, { timeout: 8000 });
    const versions = [...String(resp.data || '').matchAll(/<version>([^<]+)<\/version>/g)]
      .map(m => m[1].trim())
      // SNAPSHOTs are unreleased builds — never an upgrade target. The old
      // Solr `gav` core excluded them implicitly; metadata.xml does not.
      .filter(v => v && !/-SNAPSHOT$/i.test(v));

    const tiers = await resolveTiers({
      versions,
      versionInUse,
      dateForVersion: version => fetchMavenReleaseDate(artifactBase, artifactId, version, httpClient),
    });
    return { ...tiers, error: null };
  } catch (e) {
    // A 404 means the artifact simply isn't on Central — normal for in-house
    // coordinates (com.cainc.*). The old Solr query expressed this as an empty
    // result set with no error, and it must stay a non-error here, or every
    // internal dependency would be reported as a failed lookup.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

// Maven Central serves no advisory data of its own, so Java vulnerabilities
// come from OSV under the coordinate's group:artifact name.
async function fetchMavenVulnerabilities(groupId, artifactId, version, httpClient = realAxios) {
  return fetchOsvVulnerabilities('Maven', `${groupId}:${artifactId}`, version, httpClient);
}

module.exports = { fetchMavenLatest, fetchMavenVulnerabilities, fetchMavenReleaseDate };
