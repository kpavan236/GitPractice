'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published versions of a Dart/Flutter package. One request
// returns every version with its publication date.
//
// `latest.version` is pub.dev's own pointer at what should be installed, so it
// is preferred over the highest version in the list — which can be a prerelease.
async function fetchPubLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://pub.dev/api/packages/${encodeURIComponent(name)}`, { timeout: 8000 });
    const published = (resp.data?.versions || []).filter(v => v?.version);
    const releaseDates = new Map(published.map(v => [v.version, v.published || null]));

    const tiers = await resolveTiers({
      versions: published.map(v => v.version),
      versionInUse,
      latestVersion: resp.data?.latest?.version || null,
      dateForVersion: version => releaseDates.get(version) || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on pub.dev — normal for a package hosted on a private pub server.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchPubLatest };
