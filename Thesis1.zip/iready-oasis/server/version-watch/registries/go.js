'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Go module paths are case-sensitive, but the proxy serves them from storage
// that may not be. The module protocol resolves that by escaping every
// uppercase letter as "!" followed by its lowercase form, so
// github.com/Azure/... is requested as github.com/!azure/... . Without this,
// every module with a capitalised path segment 404s.
function escapeModulePath(modulePath) {
  return String(modulePath).replace(/[A-Z]/g, c => `!${c.toLowerCase()}`);
}

// Looks up the published versions of a Go module from the public module proxy.
//
// Versions are reported without their "v" prefix, matching every other
// ecosystem in this table — and necessary for comparison, since a leading "v"
// would be read as a non-numeric leading segment.
async function fetchGoLatest(name, versionInUse, httpClient = realAxios) {
  const versionBase = `https://proxy.golang.org/${escapeModulePath(name)}/@v`;
  try {
    const resp = await httpClient.get(`${versionBase}/list`, { timeout: 8000 });
    const versions = String(resp.data || '')
      .split(/\r?\n/)
      .map(v => v.trim())
      .filter(Boolean)
      .map(v => v.replace(/^v/, ''));

    const tiers = await resolveTiers({
      versions,
      versionInUse,
      // One request per upgrade tier, memoized and skipped for non-upgrades by
      // resolveTiers — the proxy carries no bulk timestamp listing.
      dateForVersion: async (version) => {
        const info = await httpClient.get(`${versionBase}/v${version}.info`, { timeout: 8000 });
        return info.data?.Time || null;
      },
    });
    return { ...tiers, error: null };
  } catch (e) {
    // 404 means the proxy has never seen this module — normal for in-house
    // modules on an internal host. 410 means it was withdrawn. Neither is a
    // failed lookup, and reporting them as errors would flag every internal
    // module as broken.
    const status = e.response?.status;
    if (status === 404 || status === 410) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchGoLatest, escapeModulePath };
