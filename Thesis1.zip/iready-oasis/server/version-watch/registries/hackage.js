'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published versions of a Hackage package.
//
// Uses the /preferred endpoint, which lists versions split into "normal" and
// "deprecated" — deprecated versions are excluded from the tiers, since a
// deprecated release is not an upgrade target.
//
// Hackage serves HTML by default and only returns JSON when explicitly asked,
// hence the Accept header. The endpoint carries no publication dates, so those
// are reported as null rather than costing a request per version.
async function fetchHackageLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(
      `https://hackage.haskell.org/package/${encodeURIComponent(name)}/preferred`,
      { timeout: 8000, headers: { Accept: 'application/json' } }
    );
    const versions = (resp.data?.['normal-version'] || []).filter(Boolean);
    const tiers = await resolveTiers({ versions, versionInUse });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on Hackage — normal for a package from a private or vendored source.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchHackageLatest };
