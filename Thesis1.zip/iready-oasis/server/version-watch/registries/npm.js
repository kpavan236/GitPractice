'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');
const { truncateSummary } = require('./osv');

// Looks up latest version, release date, deprecated status, and the latest
// versions within the current major and patch line, all from the public
// registry's own metadata endpoint. Every tier and date comes out of this one
// response — no extra network call needed.
//
// `latestVersion` comes from dist-tags rather than from the highest published
// version: the `latest` tag is a maintainer's deliberate choice about what
// consumers should install, and can sit below the newest publish when a
// prerelease or a backport went out more recently.
async function fetchNpmLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://registry.npmjs.org/${encodeURIComponent(name)}`, { timeout: 8000 });
    const data = resp.data || {};
    const distTagLatest = data['dist-tags']?.latest || null;
    const tiers = await resolveTiers({
      versions: Object.keys(data.versions || {}),
      versionInUse,
      latestVersion: distTagLatest,
      dateForVersion: version => data.time?.[version] || null,
    });
    return {
      ...tiers,
      deprecated: distTagLatest ? (data.versions?.[distTagLatest]?.deprecated || null) : null,
      error: null,
    };
  } catch (e) {
    return { ...NO_TIERS, deprecated: null, error: e.message };
  }
}

// Looks up known advisories for a specific npm package + version-in-use via
// the registry's own bulk advisory endpoint.
//
// npm keeps its own endpoint rather than going through OSV because this one
// accepts semver RANGES, so a package.json-declared "^4.17.21" can be passed
// through unmodified and matched properly. OSV's /v1/query takes a single
// concrete version, which for npm's range-heavy manifests would mean querying
// the range's floor instead of what it actually permits.
async function fetchNpmAdvisories(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.post(
      'https://registry.npmjs.org/-/npm/v1/security/advisories/bulk',
      { [name]: [versionInUse] },
      { timeout: 8000 }
    );
    const advisories = resp.data?.[name] || [];
    return {
      cves: advisories.map(a => {
        // npm's bulk advisory endpoint doesn't expose CVE data directly — it
        // returns its own internal numeric `id` plus a GHSA advisory `url`.
        // Many advisories only ever get a GHSA ID, never a CVE number.
        const ghsaMatch = (a.url || '').match(/GHSA-[\w-]+/);
        return {
          id: ghsaMatch ? ghsaMatch[0] : `npm-advisory-${a.id}`,
          severity: a.severity || null,
          summary: truncateSummary(a.title || a.overview || ''),
          url: a.url || null,
        };
      }),
      error: null,
    };
  } catch (e) {
    return { cves: [], error: e.message };
  }
}

module.exports = { fetchNpmLatest, fetchNpmAdvisories };
