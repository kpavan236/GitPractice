'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchCargoLatest } = require('./cargo');

const CRATE_RESPONSE = {
  crate: { max_stable_version: '1.0.188', newest_version: '1.1.0-beta.1' },
  versions: [
    { num: '1.0.188', created_at: '2024-01-15T00:00:00Z', yanked: false },
    { num: '1.0.150', created_at: '2023-06-01T00:00:00Z', yanked: false },
    { num: '0.9.0', created_at: '2022-01-01T00:00:00Z', yanked: false },
  ],
};

test('reads the crate metadata from the crates.io API', async () => {
  let recordedUrl = null;
  const fakeClient = { get: async (url) => { recordedUrl = url; return { data: CRATE_RESPONSE }; } };
  await fetchCargoLatest('serde', '1.0.150', fakeClient);
  assert.equal(recordedUrl, 'https://crates.io/api/v1/crates/serde');
});

test('sends a User-Agent because crates.io rejects requests without one', async () => {
  let recordedConfig = null;
  const fakeClient = { get: async (_url, config) => { recordedConfig = config; return { data: CRATE_RESPONSE }; } };
  await fetchCargoLatest('serde', '1.0.150', fakeClient);
  assert.ok(recordedConfig?.headers?.['User-Agent'], 'crates.io returns 403 to an anonymous client');
});

test('prefers the max stable version over a newer prerelease', async () => {
  const fakeClient = { get: async () => ({ data: CRATE_RESPONSE }) };
  const result = await fetchCargoLatest('serde', '1.0.150', fakeClient);
  assert.equal(result.latestVersion, '1.0.188');
});

test('reads the release date from the matching version entry', async () => {
  const fakeClient = { get: async () => ({ data: CRATE_RESPONSE }) };
  const result = await fetchCargoLatest('serde', '1.0.150', fakeClient);
  assert.equal(result.latestReleaseDate, '2024-01-15T00:00:00Z');
});

test('excludes yanked versions from the tiers', async () => {
  // A yanked release is withdrawn and must never be offered as an upgrade.
  const data = {
    crate: { max_stable_version: '1.0.150' },
    versions: [
      { num: '1.0.200', created_at: '2024-05-01T00:00:00Z', yanked: true },
      { num: '1.0.150', created_at: '2023-06-01T00:00:00Z', yanked: false },
    ],
  };
  const fakeClient = { get: async () => ({ data }) };
  const result = await fetchCargoLatest('serde', '1.0.100', fakeClient);
  assert.equal(result.latestMinorVersion, '1.0.150');
});

test('reports no error for a crate that is not on crates.io', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; } };
  const result = await fetchCargoLatest('internal-crate', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('returns an error message when the request fails outright', async () => {
  const fakeClient = { get: async () => { throw new Error('crates.io timeout'); } };
  const result = await fetchCargoLatest('serde', '1.0.0', fakeClient);
  assert.equal(result.error, 'crates.io timeout');
});
