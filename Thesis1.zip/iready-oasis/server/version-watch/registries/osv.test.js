'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchOsvVulnerabilities, SUMMARY_MAX_LENGTH } = require('./osv');

test('queries OSV with the given ecosystem and package name', async () => {
  let recordedUrl = null, recordedBody = null;
  const fakeClient = {
    post: async (url, body) => { recordedUrl = url; recordedBody = body; return { data: {} }; },
  };
  await fetchOsvVulnerabilities('crates.io', 'serde', '1.0.100', fakeClient);
  assert.equal(recordedUrl, 'https://api.osv.dev/v1/query');
  assert.deepEqual(recordedBody, {
    package: { name: 'serde', ecosystem: 'crates.io' },
    version: '1.0.100',
  });
});

test('carries the OS-trust-root agent for every ecosystem, not just Maven', async () => {
  // api.osv.dev is not on a corporate TLS proxy's bypass list. Any ecosystem
  // that loses this agent silently reports every package as clean.
  let recordedConfig = null;
  const fakeClient = { post: async (_u, _b, config) => { recordedConfig = config; return { data: {} }; } };
  await fetchOsvVulnerabilities('Go', 'golang.org/x/net', '0.1.0', fakeClient);
  assert.ok(recordedConfig.httpsAgent, 'request config must carry an httpsAgent');
  assert.ok(
    Array.isArray(recordedConfig.httpsAgent.options?.ca) && recordedConfig.httpsAgent.options.ca.length > 0,
    'the agent must supply an explicit CA list'
  );
  assert.notEqual(
    recordedConfig.httpsAgent.options.rejectUnauthorized, false,
    'must not disable TLS verification — this feed is a security signal'
  );
});

test('preserves a critical severity label distinctly from high', async () => {
  // The UI renders critical as its own badge, so the label must survive the
  // mapping rather than being folded into a generic "high".
  const fakeClient = {
    post: async () => ({ data: { vulns: [{ id: 'GHSA-x', database_specific: { severity: 'CRITICAL' } }] } }),
  };
  const result = await fetchOsvVulnerabilities('Maven', 'g:a', '1.0.0', fakeClient);
  assert.equal(result.cves[0].severity, 'critical');
});

test('truncates a long advisory summary', async () => {
  // A single stale artifact can match ~70 advisories whose `details` run to
  // paragraphs of Markdown. Stored in full, that text dominated a cache file
  // that already exceeds a megabyte and ships to the browser on every load —
  // while the UI never renders more than the first ~120 characters.
  const longDetails = 'x'.repeat(5000);
  const fakeClient = { post: async () => ({ data: { vulns: [{ id: 'GHSA-x', details: longDetails }] } }) };
  const result = await fetchOsvVulnerabilities('npm', 'lodash', '4.17.20', fakeClient);
  assert.ok(
    result.cves[0].summary.length <= SUMMARY_MAX_LENGTH,
    `summary was ${result.cves[0].summary.length} chars, expected at most ${SUMMARY_MAX_LENGTH}`
  );
  assert.ok(result.cves[0].summary.endsWith('…'), 'a truncated summary should be marked as cut off');
});

test('leaves a short summary untouched', async () => {
  const fakeClient = { post: async () => ({ data: { vulns: [{ id: 'GHSA-x', summary: 'Prototype pollution' }] } }) };
  const result = await fetchOsvVulnerabilities('npm', 'lodash', '4.17.20', fakeClient);
  assert.equal(result.cves[0].summary, 'Prototype pollution');
});

test('returns an empty list and an error message on request failure', async () => {
  const fakeClient = { post: async () => { throw new Error('osv unreachable'); } };
  const result = await fetchOsvVulnerabilities('Go', 'x', '1.0.0', fakeClient);
  assert.deepEqual(result.cves, []);
  assert.equal(result.error, 'osv unreachable');
});
