'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { fetchComposerLatest } = require('./composer');

const PACKAGE_RESPONSE = {
  packages: {
    'monolog/monolog': [
      { version: '3.5.0', time: '2024-01-10T00:00:00Z' },
      { version: 'v3.4.0', time: '2023-09-01T00:00:00Z' },
      { version: '2.9.1', time: '2023-02-01T00:00:00Z' },
    ],
  },
};

test('reads the package metadata from the Packagist v2 endpoint', async () => {
  let recordedUrl = null;
  const fakeClient = { get: async (url) => { recordedUrl = url; return { data: PACKAGE_RESPONSE }; } };
  await fetchComposerLatest('monolog/monolog', '3.4.0', fakeClient);
  assert.equal(recordedUrl, 'https://repo.packagist.org/p2/monolog/monolog.json');
});

test('strips the leading v that Packagist carries on tagged releases', async () => {
  // Packagist reports the git tag verbatim, so the same package mixes "3.5.0"
  // and "v3.4.0". Left alone, the "v" sorts as a non-numeric segment.
  const fakeClient = { get: async () => ({ data: PACKAGE_RESPONSE }) };
  const result = await fetchComposerLatest('monolog/monolog', '2.9.1', fakeClient);
  assert.equal(result.latestVersion, '3.5.0');
  assert.equal(result.latestMinorVersion, '2.9.1');
});

test('reads the release date from the matching version entry', async () => {
  const fakeClient = { get: async () => ({ data: PACKAGE_RESPONSE }) };
  const result = await fetchComposerLatest('monolog/monolog', '2.9.1', fakeClient);
  assert.equal(result.latestReleaseDate, '2024-01-10T00:00:00Z');
});

test('matches a release date for a version whose tag carried a v prefix', async () => {
  const fakeClient = { get: async () => ({ data: PACKAGE_RESPONSE }) };
  const result = await fetchComposerLatest('monolog/monolog', '3.3.0', fakeClient);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestMinorVersion, '3.5.0');
});

test('reports no error for a package that is not on Packagist', async () => {
  const notFound = Object.assign(new Error('404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; } };
  const result = await fetchComposerLatest('internal/package', '1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('returns an error message when the request fails outright', async () => {
  const fakeClient = { get: async () => { throw new Error('packagist timeout'); } };
  const result = await fetchComposerLatest('monolog/monolog', '3.4.0', fakeClient);
  assert.equal(result.error, 'packagist timeout');
});
