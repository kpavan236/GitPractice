'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// Looks up the published versions of a NuGet package.
//
// Uses the flat container rather than the registration index. The registration
// index is the only endpoint carrying per-version `published` timestamps, but it
// is paginated — for a package with many versions the inner items are replaced
// by page links, so reading dates would cost several extra requests per package
// across an org-wide scan. The flat container answers with every version in one
// cheap request and no timestamps.
//
// This table treats the release date as decoration beside the version, so the
// trade is made in favour of the version: NuGet rows report their versions and
// report a null date honestly, rather than paying for dates on every row.
async function fetchNugetLatest(name, versionInUse, httpClient = realAxios) {
  // The flat container addresses packages by lowercased id; the PascalCase id
  // that appears in a project file 404s.
  const packageId = String(name).toLowerCase();
  try {
    const resp = await httpClient.get(
      `https://api.nuget.org/v3-flatcontainer/${encodeURIComponent(packageId)}/index.json`,
      { timeout: 8000 }
    );
    const tiers = await resolveTiers({
      versions: (resp.data?.versions || []).filter(Boolean),
      versionInUse,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on nuget.org — normal for packages published to an internal feed.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchNugetLatest };
