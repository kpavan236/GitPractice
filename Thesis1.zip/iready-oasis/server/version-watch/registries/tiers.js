'use strict';
const {
  pickLatest, pickLatestSameMajor, pickLatestSamePatchLine, compareVersions, stripRangePrefix,
} = require('../compare-versions');

const NO_TIERS = {
  latestVersion: null, latestMinorVersion: null, latestPatchVersion: null,
  latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null,
};

// Resolves the three upgrade tiers the UI renders — latest overall, latest
// within the current major, latest on the current patch line — plus a release
// date for each. Shared by every registry so the rules below are stated once
// rather than re-derived per ecosystem.
//
// `latestVersion` may be overridden by registries that publish their own
// "latest" pointer: npm's dist-tags.latest and PyPI's info.version are
// deliberate maintainer choices and can sit BELOW the highest published
// version when a prerelease or a backport has been published more recently.
// Where no such pointer exists (Maven Central, Go, crates.io) the highest
// stable version is used instead.
//
// `dateForVersion` is called at most once per distinct version, and never for a
// version that isn't actually an upgrade over what's in use:
//
//   - Tiers frequently coincide. An artifact with no newer major has
//     latestVersion === latestMinorVersion; one with no newer minor collapses
//     all three. Memoizing keeps that a single lookup instead of three.
//   - A date is only ever displayed beside an upgrade target, so fetching one
//     for a tier that resolved to the version already in use would be a
//     network round trip whose result is never rendered.
//
// A lookup that throws yields a null date rather than discarding the version
// itself — the version is the point, the date is decoration.
async function resolveTiers({ versions = [], versionInUse, dateForVersion = () => null, latestVersion: latestOverride } = {}) {
  const hasVersions = versions.length > 0;
  const latestVersion = latestOverride !== undefined
    ? latestOverride
    : (hasVersions ? pickLatest(versions) : null);
  const latestMinorVersion = hasVersions ? pickLatestSameMajor(versions, versionInUse) : null;
  const latestPatchVersion = hasVersions ? pickLatestSamePatchLine(versions, versionInUse) : null;

  const currentVersion = stripRangePrefix(versionInUse);
  const pending = new Map();
  const dateFor = (version) => {
    if (!version || compareVersions(version, currentVersion) <= 0) return null;
    if (!pending.has(version)) {
      pending.set(version, (async () => {
        try { return await dateForVersion(version); } catch (_) { return null; }
      })());
    }
    return pending.get(version);
  };

  const [latestReleaseDate, latestMinorReleaseDate, latestPatchReleaseDate] = await Promise.all([
    dateFor(latestVersion), dateFor(latestMinorVersion), dateFor(latestPatchVersion),
  ]);

  return {
    latestVersion, latestMinorVersion, latestPatchVersion,
    latestReleaseDate, latestMinorReleaseDate, latestPatchReleaseDate,
  };
}

module.exports = { resolveTiers, NO_TIERS };
