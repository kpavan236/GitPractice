'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');
const { parseYaml } = require('../parse-yaml');

// Looks up the versions Conan Center packages for a recipe.
//
// Conan Center exposes no public version API, so this reads the authoritative
// source directly: each recipe in the conan-center-index repository carries a
// config.yml listing every packaged version. No publication dates exist there,
// so those are reported as null.
async function fetchConanLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(
      `https://raw.githubusercontent.com/conan-io/conan-center-index/master/recipes/${encodeURIComponent(name)}/config.yml`,
      { timeout: 8000 }
    );
    const config = parseYaml(String(resp.data || ''));
    const versions = config.versions && typeof config.versions === 'object' && !Array.isArray(config.versions)
      ? Object.keys(config.versions)
      : [];
    const tiers = await resolveTiers({ versions, versionInUse });
    return { ...tiers, error: null };
  } catch (e) {
    // Not in Conan Center — normal for an in-house recipe on a private remote.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchConanLatest };
