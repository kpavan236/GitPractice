'use strict';
const realAxios = require('axios');
const { resolveTiers, NO_TIERS } = require('./tiers');

// crates.io returns 403 to a request with no User-Agent, and asks that clients
// identify themselves.
const CRATES_USER_AGENT = 'iready-oasis/1.0 (version-watch)';

// Looks up the published versions of a crate.
//
// `max_stable_version` is crates.io's own pointer at what should be installed,
// which is why it is preferred over the highest version in the list — the list
// includes prereleases that are newer but not intended for general use.
//
// Yanked releases are withdrawn from the registry and must never be offered as
// an upgrade target, so they are filtered out before the tiers are resolved.
async function fetchCargoLatest(name, versionInUse, httpClient = realAxios) {
  try {
    const resp = await httpClient.get(`https://crates.io/api/v1/crates/${encodeURIComponent(name)}`, {
      timeout: 8000,
      headers: { 'User-Agent': CRATES_USER_AGENT },
    });
    const published = (resp.data?.versions || []).filter(v => v?.num && !v.yanked);
    const releaseDates = new Map(published.map(v => [v.num, v.created_at || null]));

    const tiers = await resolveTiers({
      versions: published.map(v => v.num),
      versionInUse,
      latestVersion: resp.data?.crate?.max_stable_version || null,
      dateForVersion: version => releaseDates.get(version) || null,
    });
    return { ...tiers, error: null };
  } catch (e) {
    // Not on crates.io — expected for a path/git crate that slipped through, or
    // a private registry. Not a failed lookup.
    if (e.response?.status === 404) return { ...NO_TIERS, error: null };
    return { ...NO_TIERS, error: e.message };
  }
}

module.exports = { fetchCargoLatest };
