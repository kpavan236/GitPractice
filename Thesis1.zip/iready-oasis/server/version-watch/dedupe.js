'use strict';

// Builds the identity key for a (ecosystem, package, version) row. Uses
// JSON.stringify of a tuple rather than a delimiter-joined string (e.g.
// `${ecosystem}::${pkg}::${version}`) so a package or version string that
// happens to contain the delimiter can't collide two otherwise-distinct rows.
function rowKey(ecosystem, pkg, version) {
  return JSON.stringify([ecosystem, pkg, version]);
}

// Groups per-repo dependency entries into unique (ecosystem, package,
// version) rows, each listing every repo that uses that exact version.
function dedupeRows(entries) {
  const byKey = new Map();
  for (const { repo, ecosystem, package: pkg, version, versionIsRange } of entries) {
    const key = rowKey(ecosystem, pkg, version);
    if (!byKey.has(key)) {
      byKey.set(key, { ecosystem, package: pkg, versionInUse: version, usedBy: new Set() });
    }
    const row = byKey.get(key);
    row.usedBy.add(repo);
    // Two repos can reach the same version string from different notations —
    // Cargo's "1.0" (a caret range) and "=1.0" (a pin) both normalize to "1.0".
    // When they disagree the range wins, because it is the weaker claim: the
    // row's vulnerability finding applies to a floor some repo merely permits,
    // not to a version every repo is definitely on.
    //
    // Set only when true, so an exactly-pinned row carries no marker at all
    // rather than an explicit false on every row in the cache.
    if (versionIsRange) row.versionIsRange = true;
  }
  return [...byKey.values()].map(row => ({ ...row, usedBy: [...row.usedBy].sort() }));
}

module.exports = { dedupeRows, rowKey };
