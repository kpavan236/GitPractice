'use strict';

// Extracts <properties><key>value</key>...</properties> as a plain object —
// used to resolve "${some.version}" placeholders in <version> tags below.
function extractProperties(pomXml) {
  const props = {};
  const block = pomXml.match(/<properties>([\s\S]*?)<\/properties>/);
  if (!block) return props;
  const re = /<([\w.-]+)>([^<]*)<\/\1>/g;
  let m;
  while ((m = re.exec(block[1]))) props[m[1]] = m[2].trim();
  return props;
}

// Resolves a raw <version> value that may be a Maven property placeholder
// (e.g. "${log4j.version}"), using only this same pom.xml's <properties>
// block. Recurses (depth-bounded) because a property's value can itself be
// another placeholder. Returns null when it can't be resolved locally
// (inherited from a parent POM/BOM not present in this file) — the caller
// skips the dependency rather than guessing at an external value.
function resolveVersion(raw, props, depth = 0) {
  if (!raw) return null;
  const m = raw.match(/^\$\{([^}]+)\}$/);
  if (!m) return raw;
  if (depth > 5) return null;
  const next = props[m[1]];
  if (!next) return null;
  return resolveVersion(next, props, depth + 1);
}

// Strips XML comments (<!-- ... -->, including multi-line ones) so that
// commented-out properties/dependencies are never seen by the parser below.
function stripComments(xmlText) {
  return xmlText.replace(/<!--[\s\S]*?-->/g, '');
}

// Parses a pom.xml's direct <dependencies> (excluding anything nested inside
// <dependencyManagement>, which declares versions for BOM imports, not deps
// actually in use) into { groupId, artifactId, version } entries.
function parsePomXml(xmlText) {
  const uncommented = stripComments(xmlText);
  const props = extractProperties(uncommented);
  const withoutMgmt = uncommented.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
  const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];

  const dependencies = [];
  let unresolvedCount = 0;

  for (const section of sections) {
    const depBlocks = section.match(/<dependency>[\s\S]*?<\/dependency>/g) || [];
    for (const dep of depBlocks) {
      const groupId = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
      const artifactId = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
      const rawVersion = dep.match(/<version>([^<]+)<\/version>/)?.[1]?.trim() || '';
      if (!groupId || !artifactId || !rawVersion) { unresolvedCount++; continue; }
      const version = resolveVersion(rawVersion, props);
      if (!version) { unresolvedCount++; continue; }
      dependencies.push({ groupId, artifactId, version });
    }
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parsePomXml };
