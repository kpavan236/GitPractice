'use strict';
const os    = require('os');
const path  = require('path');
const axios = require('axios');
const { runScan } = require('./scan');
const { loadCache, saveCache, markChangedSinceLastScan } = require('./cache');

// Org-wide Maven/npm/pip/etc dependency version + CVE scan. Mounts
// /api/version-watch and /api/version-watch/scan, and runs the scan
// automatically every 24h in the background.
const CACHE_PATH = path.join(os.homedir(), '.oasis-version-watch.json');
const AUTO_SCAN_INTERVAL_MS  = 24 * 60 * 60 * 1000;
const AUTO_CHECK_INTERVAL_MS = 30 * 60 * 1000;
// How long to back off auto-scanning after a failed attempt (network error,
// bad/expired credentials, GitHub outage, etc.) — without this, a
// permanently-broken session would retry a full paginated org scan every
// AUTO_CHECK_INTERVAL_MS forever. Does not affect the manual "Rescan"
// button, which a user can always click regardless of this timer.
const AUTO_FAILURE_BACKOFF_MS = 2 * 60 * 60 * 1000;

function installVersionWatch(app, { sessions, broadcast, broadcastAll, externalCalls }) {
  if (!externalCalls) throw new Error('installVersionWatch needs externalCalls: a scan lists the organisation\'s repositories on GitHub');
  let scanInFlight = false;
  let lastFailureAt = 0;

  // Runs a full org-wide Version Watch scan for the given session and
  // broadcasts progress/completion/error over the WebSocket channel. Shared by
  // the manual "Rescan" route and the automatic 24h background trigger below —
  // both need identical scan/cache/broadcast behavior, just different callers.
  // `broadcastFn` defaults to targeting only the triggering session, but the
  // automatic background trigger passes `broadcastAll` instead — sessions are
  // never cleaned up from memory, so "the session that happened to trigger
  // this" can easily be a stale, disconnected one by the time an unattended
  // scan runs; broadcasting to every connected client instead means whichever
  // tab is actually open sees live progress.
  async function runVersionWatchScan(sess, sessionIdParam, broadcastFn = (payload) => broadcast(sessionIdParam, payload)) {
    if (scanInFlight) return;
    scanInFlight = true;

    try {
      // Fired immediately (before the potentially-slow repo-listing pagination
      // below) so any open tab can disable its own Rescan button and show
      // progress right away, rather than only reacting once the first
      // per-repo/per-dependency progress event arrives. Inside the try/finally
      // so a throw here (e.g. the manual path's `broadcast` sending on a
      // socket that errors) still clears scanInFlight instead of leaving it
      // stuck true forever.
      // With GitHub calls switched off the scan ends here with a clear message,
      // shown by the same error path as any other failed scan.
      externalCalls.assertAllowed('GitHub');

      broadcastFn({ type: 'version_scan_started' });

      const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
      const ghHeaders = {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      };

      let repos = [];
      let page = 1;
      while (true) {
        const r = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
          headers: ghHeaders, params: { page, per_page: 100, type: 'all' }, timeout: 10000,
        });
        repos = repos.concat(r.data);
        if (!r.headers['link']?.includes('rel="next"')) break;
        page++;
      }

      // Lists every file in a repo in ONE request, so the scan can discover which
      // ecosystems the repo actually uses instead of blind-probing for a fixed set
      // of filenames at the repo root. That also picks up manifests below the root
      // — multi-module Maven builds and JS monorepos, which the old root-only
      // probes could never see.
      //
      // GitHub caps a recursive tree response and sets `truncated` when it does.
      // That flag is passed through rather than swallowed: a truncated tree means
      // the manifest list was incomplete, and the scan reports how many repos were
      // affected instead of presenting a partial result as a complete one.
      const listRepoFiles = async (repoName, defaultBranch) => {
        try {
          const r = await axios.get(
            `${apiBase}/repos/${sess.org}/${repoName}/git/trees/${encodeURIComponent(defaultBranch || 'HEAD')}`,
            { headers: ghHeaders, params: { recursive: 1 }, timeout: 15000 }
          );
          return {
            paths: (r.data?.tree || []).filter(e => e.type === 'blob').map(e => e.path),
            truncated: !!r.data?.truncated,
          };
        } catch (e) {
          // 404: no such ref. 409: the repository is empty. Both are normal states
          // for a repo that simply has nothing to scan, not API failures — and
          // treating them as failures would flag every empty repo in the org.
          const status = e.response?.status;
          if (status === 404 || status === 409) return { paths: [], truncated: false };
          throw e;
        }
      };

      const fetchManifest = async (repoName, filePath) => {
        try {
          const r = await axios.get(
            `${apiBase}/repos/${sess.org}/${repoName}/contents/${encodeURI(filePath)}`,
            { headers: ghHeaders, timeout: 8000 }
          );
          const content = r.data?.content;
          return content ? Buffer.from(content.replace(/\n/g, ''), 'base64').toString('utf8') : null;
        } catch (e) {
          if (e.response?.status === 404) return null;   // vanished since the tree listing
          throw e;                                        // real failure — surface it
        }
      };

      // Enrichment fires one progress event per unique dependency (can be
      // thousands for a large org) — only forward every 5th one, plus always
      // the very last, so the WebSocket isn't flooded with messages a
      // progress bar doesn't need at that resolution. Every "scanning" (i.e.
      // per-repo) event is forwarded as-is — there are far fewer of those.
      let enrichEventCount = 0;
      const { rows, scanSummary } = await runScan({
        repos,
        fetchManifest,
        listRepoFiles,
        onProgress: (p) => {
          if (p.phase === 'enriching') {
            enrichEventCount++;
            if (enrichEventCount % 5 !== 0 && p.current !== p.total) return;
          }
          broadcastFn({ type: 'version_scan_progress', phase: p.phase, current: p.current, total: p.total, label: p.label });
        },
      });

      const previous = loadCache(CACHE_PATH);

      if (rows.length === 0 && scanSummary.repoFetchErrors > 0 && (previous.rows || []).length > 0) {
        lastFailureAt = Date.now();
        broadcastFn({
          type: 'version_scan_error',
          error: 'Scan failed for all repos (GitHub API errors) — previous results preserved.',
        });
        return;
      }

      const finalRows = markChangedSinceLastScan(rows, previous.rows || []);
      const result = { lastScanAt: new Date().toISOString(), rows: finalRows, scanSummary };
      saveCache(CACHE_PATH, result);

      broadcastFn({ type: 'version_scan_done', ...result });
    } catch (e) {
      lastFailureAt = Date.now();
      broadcastFn({ type: 'version_scan_error', error: e.message });
    } finally {
      scanInFlight = false;
    }
  }

  app.get('/api/version-watch', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    // Include whether a scan is currently running (manual or automatic) so a
    // tab opened or reloaded mid-scan can reflect that immediately, instead
    // of showing an enabled Rescan button that would just 409 if clicked —
    // broadcastAll (used for automatic scans) has no reconnect-replay, so
    // this is the only way a freshly-loaded tab can learn about it.
    res.json({ ...loadCache(CACHE_PATH), scanInFlight });
  });

  app.post('/api/version-watch/scan', async (req, res) => {
    const sessionIdParam = req.body?.session;
    const sess = sessions[sessionIdParam];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    if (scanInFlight) {
      return res.status(409).json({ error: 'A scan is already running' });
    }

    // Respond immediately — the scan can take a while across the whole org, so
    // progress/completion streams over the existing WebSocket channel instead
    // of holding this HTTP request open.
    res.json({ started: true });
    runVersionWatchScan(sess, sessionIdParam);
  });

  // Automatic background scan: once every AUTO_CHECK_INTERVAL_MS (30 min),
  // reusing whatever GitHub session is currently in memory — same "first
  // session with a token" pattern the Scheduled Jobs background timer uses.
  // Checked on a shorter interval than the 24h scan cadence so a stale scan
  // doesn't wait for the app to be closed and reopened, and once immediately
  // whenever a new login session is created (see the /api/session handler),
  // so opening the app after a stale scan triggers a fresh one right away.
  function maybeAutoScanVersionWatch() {
    if (!externalCalls.isEnabled()) return;   // an unattended scan must not call GitHub while the switch is off
    if (scanInFlight) return;
    if (Date.now() - lastFailureAt < AUTO_FAILURE_BACKOFF_MS) return;

    const sessionEntry = Object.entries(sessions).find(([, s]) => s.githubUrl && s.token);
    if (!sessionEntry) return;
    const [sessionId, sess] = sessionEntry;

    const cache = loadCache(CACHE_PATH);
    const dueForAutoScan = !cache.lastScanAt
      || (Date.now() - new Date(cache.lastScanAt).getTime()) >= AUTO_SCAN_INTERVAL_MS;
    if (!dueForAutoScan) return;

    // Broadcast to every connected client, not just whichever session happens
    // to be first in memory — sessions are never cleaned up, so that session
    // could easily be a stale, disconnected one by the time this unattended
    // trigger fires.
    runVersionWatchScan(sess, sessionId, broadcastAll);
  }

  setInterval(maybeAutoScanVersionWatch, AUTO_CHECK_INTERVAL_MS);

  return {
    maybeAutoScanVersionWatch,
    // SCA reuses Version Watch's dependency scan rather than re-resolving
    // every manifest. null means "no scan has run yet", which the security
    // adapter reports as a skip instead of as zero vulnerabilities.
    loadVersionWatchRows: () => {
      const cache = loadCache(CACHE_PATH);
      if (!cache || !Array.isArray(cache.rows) || !cache.rows.length) return null;
      // lastScanAt travels with the rows so the security tab can report how
      // old the dependency data is rather than implying it is current.
      // lastScanAt is an ISO string in the cache; the adapter does arithmetic
      // on it, and `Date.now() - "2026-08-12T…"` is NaN. Normalised here, at
      // the one place the two formats meet.
      const scannedAt = cache.lastScanAt ? new Date(cache.lastScanAt).getTime() : null;
      return { rows: cache.rows, scannedAt: Number.isFinite(scannedAt) ? scannedAt : null };
    },
  };
}

module.exports = { installVersionWatch };