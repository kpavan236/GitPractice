'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parsePyproject, parsePipfile } = require('./parse-pyproject');

// ── PEP 621 ([project] dependencies) ───────────────────────────────────────

test('reads PEP 621 project dependencies', () => {
  const toml = `
[project]
name = "my-app"
dependencies = [
  "requests>=2.28",
  "flask==3.0.0",
]
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'requests', version: '>=2.28', versionIsRange: true },
    { name: 'flask', version: '3.0.0' },
  ]);
});

test('strips extras from a PEP 621 requirement name', () => {
  const toml = `
[project]
dependencies = ["celery[redis]==5.3.6"]
`;
  const { dependencies } = parsePyproject(toml);
  assert.strictEqual(dependencies[0].name, 'celery');
  assert.strictEqual(dependencies[0].version, '5.3.6');
});

test('drops an environment marker from a PEP 621 requirement', () => {
  const toml = `
[project]
dependencies = ["tomli==2.0.1 ; python_version < '3.11'"]
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [{ name: 'tomli', version: '2.0.1' }]);
});

test('reads PEP 621 optional dependency groups', () => {
  const toml = `
[project.optional-dependencies]
dev = ["pytest==7.4.4"]
docs = ["sphinx==7.2.6"]
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['pytest', 'sphinx']);
});

test('reads PEP 735 dependency groups', () => {
  const toml = `
[dependency-groups]
test = ["pytest==7.4.4"]
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [{ name: 'pytest', version: '7.4.4' }]);
});

test('counts a requirement with no version specifier as unresolved', () => {
  const toml = `
[project]
dependencies = ["requests"]
`;
  const { dependencies, unresolvedCount } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

// ── Poetry ([tool.poetry.dependencies]) ────────────────────────────────────

test('reads Poetry dependencies', () => {
  const toml = `
[tool.poetry.dependencies]
requests = "^2.28.0"
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'requests', version: '^2.28.0', versionIsRange: true },
  ]);
});

test('skips the python interpreter constraint in Poetry dependencies', () => {
  const toml = `
[tool.poetry.dependencies]
python = "^3.11"
requests = "^2.28.0"
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['requests']);
});

test('reads the version out of a Poetry inline-table declaration', () => {
  const toml = `
[tool.poetry.dependencies]
requests = { version = "2.31.0", extras = ["socks"] }
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
});

test('reads Poetry group dependencies', () => {
  const toml = `
[tool.poetry.group.dev.dependencies]
pytest = "7.4.4"
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, [{ name: 'pytest', version: '7.4.4' }]);
});

test('counts a Poetry git dependency as unresolved', () => {
  const toml = `
[tool.poetry.dependencies]
mylib = { git = "https://github.test/x/mylib.git" }
`;
  const { dependencies, unresolvedCount } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a Poetry wildcard dependency as unresolved', () => {
  const toml = `
[tool.poetry.dependencies]
requests = "*"
`;
  const { dependencies, unresolvedCount } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('returns no dependencies for a pyproject that declares none', () => {
  assert.deepStrictEqual(parsePyproject('[build-system]\nrequires = []'), {
    dependencies: [], unresolvedCount: 0,
  });
});

test('ignores build-system requires', () => {
  // These build the package; they are not dependencies of the shipped code,
  // and treating them as such would report setuptools in every Python repo.
  const toml = `
[build-system]
requires = ["setuptools>=61.0"]

[project]
dependencies = ["requests==2.31.0"]
`;
  const { dependencies } = parsePyproject(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['requests']);
});

// ── Pipfile ────────────────────────────────────────────────────────────────

test('reads Pipfile packages and dev-packages', () => {
  const toml = `
[packages]
requests = "==2.31.0"

[dev-packages]
pytest = "==7.4.4"
`;
  const { dependencies } = parsePipfile(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['pytest', 'requests']);
});

test('reads a pinned Pipfile version without its operator', () => {
  const { dependencies } = parsePipfile('[packages]\nrequests = "==2.31.0"');
  assert.deepStrictEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
});

test('counts a Pipfile wildcard as unresolved', () => {
  const { dependencies, unresolvedCount } = parsePipfile('[packages]\nrequests = "*"');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads the version out of a Pipfile inline table', () => {
  const toml = '[packages]\nrequests = { version = "==2.31.0", extras = ["socks"] }';
  const { dependencies } = parsePipfile(toml);
  assert.deepStrictEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
});

test('returns no dependencies for an empty Pipfile', () => {
  assert.deepStrictEqual(parsePipfile(''), { dependencies: [], unresolvedCount: 0 });
});
