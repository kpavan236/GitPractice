'use strict';
const { parseToml } = require('./parse-toml');
const { isRangeDeclaration } = require('./compare-versions');

function isTable(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

// Turns a PEP 440 specifier into an entry, or null when there is no usable
// version to report ("*", an empty specifier, a bare name).
//
// A single "==x"/"===x" pin becomes an exact version with the operator
// stripped, matching how requirements.txt rows already read. Anything else
// keeps its operator in the displayed version — the same convention npm rows
// follow for declared ranges — and is flagged as a range.
function pythonSpecEntry(name, spec) {
  const s = String(spec ?? '').trim();
  if (!s || !/\d/.test(s)) return null;
  const pin = s.match(/^={2,3}\s*([^\s,]+)$/);
  if (pin) return { name, version: pin[1] };
  return isRangeDeclaration(s) ? { name, version: s, versionIsRange: true } : { name, version: s };
}

// Parses one PEP 508 requirement string, as found in PEP 621's
// `[project] dependencies` arrays: "celery[redis]==5.3.6",
// "tomli==2.0.1 ; python_version < '3.11'", "requests (>=2.0)".
function parseRequirementString(raw) {
  // The environment marker decides WHETHER the requirement applies, not which
  // version — a dependency that only installs on old Pythons is still a
  // dependency, so the marker is dropped rather than used to skip the entry.
  const withoutMarker = String(raw ?? '').split(';')[0].trim();
  if (!withoutMarker) return null;
  const m = withoutMarker.match(/^([A-Za-z0-9][A-Za-z0-9._-]*)\s*(?:\[[^\]]*\])?\s*(.*)$/);
  if (!m) return null;
  let spec = m[2].trim();
  // PEP 508 permits the specifier in parentheses: "requests (>=2.0)".
  if (spec.startsWith('(') && spec.endsWith(')')) spec = spec.slice(1, -1).trim();
  return { name: m[1], spec };
}

// Poetry (and Pipfile) declare a dependency either as a bare specifier string
// or as an inline table. git/path/url sources have no registry release to
// compare against, so they yield null and are counted unresolved.
function tableDeclarationSpec(declaration) {
  if (typeof declaration === 'string') return declaration;
  if (!isTable(declaration)) return null;
  if (declaration.git || declaration.path || declaration.url) return null;
  return typeof declaration.version === 'string' ? declaration.version : null;
}

// Parses pyproject.toml, covering the three ways a Python project declares
// dependencies in it: PEP 621's `[project]` tables, PEP 735's
// `[dependency-groups]`, and Poetry's `[tool.poetry...]` tables. A repo can
// legitimately use more than one, so all are read.
//
// `[build-system] requires` is deliberately ignored: those packages build the
// distribution rather than ship in it, and counting them would report
// setuptools as a dependency of nearly every Python repo.
function parsePyproject(text) {
  const doc = parseToml(text);
  const dependencies = [];
  let unresolvedCount = 0;

  const addRequirementList = (list) => {
    if (!Array.isArray(list)) return;
    for (const raw of list) {
      if (typeof raw !== 'string') { unresolvedCount++; continue; }
      const parsed = parseRequirementString(raw);
      const entry = parsed && pythonSpecEntry(parsed.name, parsed.spec);
      if (!entry) { unresolvedCount++; continue; }
      dependencies.push(entry);
    }
  };

  const addDependencyTable = (table) => {
    if (!isTable(table)) return;
    for (const [name, declaration] of Object.entries(table)) {
      // Poetry lists the interpreter constraint alongside real packages.
      if (name === 'python') continue;
      const entry = pythonSpecEntry(name, tableDeclarationSpec(declaration));
      if (!entry) { unresolvedCount++; continue; }
      dependencies.push(entry);
    }
  };

  // PEP 621
  addRequirementList(doc.project?.dependencies);
  if (isTable(doc.project?.['optional-dependencies'])) {
    for (const group of Object.values(doc.project['optional-dependencies'])) addRequirementList(group);
  }

  // PEP 735
  if (isTable(doc['dependency-groups'])) {
    for (const group of Object.values(doc['dependency-groups'])) addRequirementList(group);
  }

  // Poetry
  const poetry = doc.tool?.poetry;
  addDependencyTable(poetry?.dependencies);
  addDependencyTable(poetry?.['dev-dependencies']);   // pre-1.2 Poetry layout
  if (isTable(poetry?.group)) {
    for (const group of Object.values(poetry.group)) addDependencyTable(group?.dependencies);
  }

  return { dependencies, unresolvedCount };
}

// Parses a Pipfile's [packages] and [dev-packages] tables. Pipenv always
// writes an operator ("==2.31.0") or a bare "*", so this reuses the same
// specifier handling as Poetry.
function parsePipfile(text) {
  const doc = parseToml(text);
  const dependencies = [];
  let unresolvedCount = 0;

  for (const key of ['packages', 'dev-packages']) {
    const table = doc[key];
    if (!isTable(table)) continue;
    for (const [name, declaration] of Object.entries(table)) {
      const entry = pythonSpecEntry(name, tableDeclarationSpec(declaration));
      if (!entry) { unresolvedCount++; continue; }
      dependencies.push(entry);
    }
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parsePyproject, parsePipfile };
