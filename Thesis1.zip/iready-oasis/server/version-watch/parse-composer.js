'use strict';
const { isRangeDeclaration } = require('./compare-versions');

// Parses composer.json's `require` + `require-dev`.
//
// When `ctx.lockVersions` is supplied (read from a sibling composer.lock) the
// declared range is replaced by the exact version the lock resolved, which is
// both more accurate and removes the range caveat from the row. Falling back to
// the declared range keeps repos without a committed lockfile reporting
// something rather than nothing.
//
// Platform requirements — php, ext-*, lib-*, composer-plugin-api and friends —
// are not Packagist packages and have no release to compare against. They are
// recognised by having no vendor prefix: every real Packagist package is
// `vendor/name`, so the absence of a slash is a reliable and future-proof test.
function parseComposerJson(text, ctx = {}) {
  const lockVersions = ctx.lockVersions || {};
  const manifest = JSON.parse(text);
  // `require` wins over `require-dev` when a package somehow appears in both.
  const merged = Object.assign({}, manifest['require-dev'], manifest.require);

  const dependencies = [];
  let unresolvedCount = 0;

  for (const [name, declared] of Object.entries(merged)) {
    if (!name.includes('/')) continue;   // platform requirement, not a package

    const locked = lockVersions[name];
    if (locked) { dependencies.push({ name, version: locked }); continue; }

    const raw = String(declared || '').trim();
    // "dev-main" tracks a branch and "*" accepts anything — neither has a floor
    // that Packagist could resolve to a release.
    if (!raw || raw.startsWith('dev-') || !/\d/.test(raw)) { unresolvedCount++; continue; }

    dependencies.push(
      isRangeDeclaration(raw) ? { name, version: raw, versionIsRange: true } : { name, version: raw }
    );
  }

  return { dependencies, unresolvedCount };
}

// Reads composer.lock into a { packageName: exactVersion } map. Packagist tags
// are commonly written "v3.5.0" while the registry lists them normalized, so
// the prefix is stripped here to keep comparisons on one convention.
function parseComposerLock(text) {
  const lock = JSON.parse(text);
  const versions = {};
  for (const group of [lock.packages, lock['packages-dev']]) {
    if (!Array.isArray(group)) continue;
    for (const pkg of group) {
      if (pkg?.name && pkg?.version) versions[pkg.name] = String(pkg.version).replace(/^v/, '');
    }
  }
  return versions;
}

module.exports = { parseComposerJson, parseComposerLock };
