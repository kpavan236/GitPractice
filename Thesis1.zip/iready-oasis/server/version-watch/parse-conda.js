'use strict';
const { parseYaml } = require('./parse-yaml');
const { isRangeDeclaration } = require('./compare-versions');

// Packages that describe the environment itself rather than a tracked library.
// `python` is the interpreter; a bare `pip` entry exists only so the pip: block
// below it can run, which is why it is skipped WITHOUT being counted unresolved.
const CONDA_PLUMBING = new Set(['python', 'pip']);

// Parses one conda dependency spec: "numpy=1.24.3", "numpy=1.24.3=py311h...",
// "numpy>=1.24", "conda-forge::numpy=1.24.3".
function condaEntry(spec) {
  // A channel prefix says where to fetch from, not what version is in use.
  const withoutChannel = String(spec).includes('::') ? spec.split('::').pop() : String(spec);
  const text = withoutChannel.trim();
  if (!text) return null;

  const comparison = text.match(/^([A-Za-z0-9_.-]+)\s*(<=|>=|<|>|!=)\s*(.+)$/);
  if (comparison) {
    const [, name, operator, version] = comparison;
    if (CONDA_PLUMBING.has(name.toLowerCase())) return { skip: true };
    if (!/\d/.test(version)) return null;
    return { entry: { ecosystem: 'conda', name, version: `${operator}${version.trim()}`, versionIsRange: true } };
  }

  // "name=version" or "name=version=build" — conda's own pinning syntax. The
  // build string identifies the compiled artifact, not the library version.
  const parts = text.split('=').filter(p => p !== '');
  const name = parts[0]?.trim();
  if (!name) return null;
  if (CONDA_PLUMBING.has(name.toLowerCase())) return { skip: true };
  const version = parts[1]?.trim();
  if (!version || !/\d/.test(version)) return null;

  return isRangeDeclaration(version)
    ? { entry: { ecosystem: 'conda', name, version, versionIsRange: true } }
    : { entry: { ecosystem: 'conda', name, version } };
}

// Parses one PEP 440 requirement from the nested pip: block.
function pipEntry(spec) {
  const text = String(spec).split(';')[0].trim();
  const match = text.match(/^([A-Za-z0-9][A-Za-z0-9._-]*)\s*(?:\[[^\]]*\])?\s*(.*)$/);
  if (!match) return null;
  const [, name, constraint] = match;
  const pin = constraint.match(/^={2,3}\s*([^\s,]+)$/);
  if (pin) return { entry: { ecosystem: 'pip', name, version: pin[1] } };
  if (!constraint || !/\d/.test(constraint)) return null;
  return { entry: { ecosystem: 'pip', name, version: constraint, versionIsRange: true } };
}

// Parses environment.yml.
//
// Unlike every other manifest, this one can declare dependencies from TWO
// ecosystems: conda packages in the main list, and PyPI packages in a nested
// `pip:` block. Each entry therefore carries its own `ecosystem`, so the pip
// packages are looked up against PyPI rather than against a conda channel —
// their names and versions genuinely belong to PyPI.
function parseCondaEnvironment(text) {
  const doc = parseYaml(text);
  const list = doc.dependencies;

  const dependencies = [];
  let unresolvedCount = 0;

  if (!Array.isArray(list)) return { dependencies, unresolvedCount };

  const collect = (result) => {
    if (!result) { unresolvedCount++; return; }
    if (result.skip) return;
    dependencies.push(result.entry);
  };

  for (const item of list) {
    if (typeof item === 'string') { collect(condaEntry(item)); continue; }
    // A nested map is the pip: block (the only such form conda defines).
    if (item && typeof item === 'object' && Array.isArray(item.pip)) {
      for (const requirement of item.pip) {
        if (typeof requirement === 'string') collect(pipEntry(requirement));
      }
    }
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseCondaEnvironment };
