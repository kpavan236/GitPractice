'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  fetchMavenLatest, fetchMavenVulnerabilities,
  fetchNpmLatest, fetchNpmAdvisories, fetchPipLatest, fetchPipVulnerabilities,
} = require('./registries');

// Builds a maven-metadata.xml body plus a `head` stub that answers with a
// Last-Modified per version, mirroring how repo1.maven.org actually responds.
function fakeCentral(versions, lastModifiedByVersion = {}) {
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<metadata><versioning><versions>
${versions.map(v => `  <version>${v}</version>`).join('\n')}
</versions></versioning></metadata>`;
  const calls = { get: [], head: [] };
  return {
    calls,
    client: {
      get: async (url) => { calls.get.push(url); return { data: xml }; },
      head: async (url) => {
        calls.head.push(url);
        const version = url.match(/\/([^/]+)\/[^/]+\.pom$/)?.[1];
        const lm = lastModifiedByVersion[version];
        if (!lm) return { headers: {} };
        return { headers: { 'last-modified': lm } };
      },
    },
  };
}

test('fetchMavenLatest reads maven-metadata.xml from the repo1 CDN, not the rate-limited Solr search API', async () => {
  const { client, calls } = fakeCentral(['2.17.0']);
  await fetchMavenLatest('org.apache.logging.log4j', 'log4j-core', '2.14.1', client);
  assert.equal(
    calls.get[0],
    'https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/maven-metadata.xml'
  );
});

test('fetchMavenLatest returns the latest version and an ISO release date on success', async () => {
  const { client } = fakeCentral(['2.14.1', '2.17.0'], { '2.17.0': 'Tue, 07 Mar 2023 16:15:54 GMT' });
  const result = await fetchMavenLatest('org.apache.logging.log4j', 'log4j-core', '2.14.1', client);
  assert.equal(result.latestVersion, '2.17.0');
  assert.equal(result.latestReleaseDate, new Date('Tue, 07 Mar 2023 16:15:54 GMT').toISOString());
  assert.equal(result.error, null);
});

test('fetchMavenLatest returns nulls and an error message on request failure', async () => {
  const fakeClient = { get: async () => { throw new Error('network down'); }, head: async () => ({ headers: {} }) };
  const result = await fetchMavenLatest('org.apache.logging.log4j', 'log4j-core', '2.14.1', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.latestMinorVersion, null);
  assert.equal(result.error, 'network down');
});

// Internal artifacts (com.cainc.*) simply aren't on Central. The old Solr
// query answered with zero docs and no error; a 404 here means the same thing
// and must not be reported as a lookup failure, or every in-house dependency
// would show up as broken.
test('fetchMavenLatest treats a 404 as "not published to Central", not as an error', async () => {
  const notFound = Object.assign(new Error('Request failed with status code 404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; }, head: async () => ({ headers: {} }) };
  const result = await fetchMavenLatest('com.cainc.commons', 'internal-lib', '1.3', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.error, null);
});

test('fetchMavenLatest picks the overall highest version and the highest version sharing versionInUse\'s major', async () => {
  const { client } = fakeCentral(['2.9.0', '2.10.0', '3.0.0'], {
    '3.0.0': 'Wed, 01 Jan 2025 00:00:00 GMT',
    '2.10.0': 'Mon, 01 Jan 2024 00:00:00 GMT',
  });
  const result = await fetchMavenLatest('g', 'a', '2.9.0', client);
  assert.equal(result.latestVersion, '3.0.0');
  assert.equal(result.latestMinorVersion, '2.10.0');
  assert.equal(result.latestReleaseDate, new Date('Wed, 01 Jan 2025 00:00:00 GMT').toISOString());
  assert.equal(result.latestMinorReleaseDate, new Date('Mon, 01 Jan 2024 00:00:00 GMT').toISOString());
});

test('fetchMavenLatest returns null for latestMinorVersion when no published version shares versionInUse\'s major', async () => {
  const { client } = fakeCentral(['3.0.0'], { '3.0.0': 'Wed, 01 Jan 2025 00:00:00 GMT' });
  const result = await fetchMavenLatest('g', 'a', '1.0.0', client);
  assert.equal(result.latestMinorVersion, null);
  assert.equal(result.latestMinorReleaseDate, null);
});

test('fetchMavenLatest ignores SNAPSHOT builds when picking the latest version', async () => {
  const { client } = fakeCentral(['2.17.0', '2.18.0-SNAPSHOT']);
  const result = await fetchMavenLatest('g', 'a', '2.17.0', client);
  assert.equal(result.latestVersion, '2.17.0');
});

// The full version list is now available, so the old rows:100 truncation that
// could hide the real latest version is gone.
test('fetchMavenLatest considers every published version, not just the first hundred', async () => {
  const many = Array.from({ length: 150 }, (_, i) => `1.0.${i}`);
  const { client } = fakeCentral(many);
  const result = await fetchMavenLatest('g', 'a', '1.0.0', client);
  assert.equal(result.latestVersion, '1.0.149');
});

test('fetchMavenLatest issues only one date lookup when the latest version is also the latest in its major', async () => {
  const { client, calls } = fakeCentral(['2.9.0', '2.17.0'], { '2.17.0': 'Tue, 07 Mar 2023 16:15:54 GMT' });
  const result = await fetchMavenLatest('g', 'a', '2.9.0', client);
  assert.equal(result.latestVersion, '2.17.0');
  assert.equal(result.latestMinorVersion, '2.17.0');
  assert.equal(calls.head.length, 1, 'must not re-request the same .pom twice');
  assert.equal(result.latestMinorReleaseDate, result.latestReleaseDate);
});

// The date is decoration; the version is the point. A flaky HEAD must not
// blank out a version we successfully resolved.
test('fetchMavenLatest still reports the version when the release-date lookup fails', async () => {
  // versionInUse must be OLDER than the latest, or the date lookup is skipped
  // as a non-upgrade and the throwing stub below is never reached — leaving the
  // test passing without ever exercising a failed HEAD.
  const { client } = fakeCentral(['2.14.1', '2.17.0']);
  let headAttempted = false;
  client.head = async () => { headAttempted = true; throw new Error('HEAD blew up'); };
  const result = await fetchMavenLatest('g', 'a', '2.14.1', client);
  assert.ok(headAttempted, 'the date lookup must actually have been attempted');
  assert.equal(result.latestVersion, '2.17.0');
  assert.equal(result.latestReleaseDate, null);
  assert.equal(result.error, null);
});

test('fetchMavenLatest resolves all three upgrade tiers with their own release dates', async () => {
  const { client } = fakeCentral(['1.2.3', '1.2.9', '1.9.4', '3.0.1'], {
    '1.2.9': 'Tue, 14 Jul 2026 00:00:00 GMT',
    '1.9.4': 'Mon, 02 Mar 2026 00:00:00 GMT',
    '3.0.1': 'Sun, 09 Aug 2026 00:00:00 GMT',
  });
  const result = await fetchMavenLatest('g', 'a', '1.2.3', client);
  assert.equal(result.latestPatchVersion, '1.2.9');
  assert.equal(result.latestMinorVersion, '1.9.4');
  assert.equal(result.latestVersion, '3.0.1');
  assert.equal(result.latestPatchReleaseDate, new Date('Tue, 14 Jul 2026 00:00:00 GMT').toISOString());
  assert.equal(result.latestMinorReleaseDate, new Date('Mon, 02 Mar 2026 00:00:00 GMT').toISOString());
  assert.equal(result.latestReleaseDate, new Date('Sun, 09 Aug 2026 00:00:00 GMT').toISOString());
});

test('fetchMavenLatest returns null for latestPatchVersion when no published version sits on versionInUse\'s minor line', async () => {
  const { client } = fakeCentral(['1.9.4', '3.0.1']);
  const result = await fetchMavenLatest('g', 'a', '1.2.3', client);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
});

// The date memo must key on the resolved version, so tiers that land on the
// same version share one HEAD. Three tiers × hundreds of Maven rows makes an
// unshared lookup the difference between a brisk scan and a slow one.
test('fetchMavenLatest issues one date lookup per DISTINCT tier version, not one per tier', async () => {
  const { client, calls } = fakeCentral(['1.2.3', '1.2.9'], { '1.2.9': 'Tue, 14 Jul 2026 00:00:00 GMT' });
  const result = await fetchMavenLatest('g', 'a', '1.2.3', client);
  assert.equal(result.latestPatchVersion, '1.2.9');
  assert.equal(result.latestMinorVersion, '1.2.9');
  assert.equal(result.latestVersion, '1.2.9');
  assert.equal(calls.head.length, 1, 'all three tiers resolved to 1.2.9 — one .pom request expected');
  assert.equal(result.latestPatchReleaseDate, result.latestReleaseDate);
  assert.equal(result.latestMinorReleaseDate, result.latestReleaseDate);
});

// A release date is only ever shown beside an upgrade target, and a tier that
// resolves to the version already in use is not one. Skipping those saves a
// .pom HEAD on every Maven row that is already current on its patch line —
// which, across hundreds of rows, is the difference the memo alone can't make.
test('fetchMavenLatest skips the date lookup for a tier that resolves to the version already in use', async () => {
  const { client, calls } = fakeCentral(['2.9.0', '2.17.0'], { '2.17.0': 'Tue, 07 Mar 2023 16:15:54 GMT' });
  const result = await fetchMavenLatest('g', 'a', '2.9.0', client);
  assert.equal(result.latestPatchVersion, '2.9.0', 'the 2.9 line really does top out at the version in use');
  assert.equal(result.latestPatchReleaseDate, null);
  assert.equal(calls.head.length, 1, 'only 2.17.0 is an upgrade, so only its .pom is requested');
});

test('fetchMavenLatest requests no dates at all when every tier is the version already in use', async () => {
  const { client, calls } = fakeCentral(['1.9.3', '1.9.4'], { '1.9.4': 'Mon, 02 Mar 2026 00:00:00 GMT' });
  const result = await fetchMavenLatest('g', 'a', '1.9.4', client);
  assert.equal(result.latestVersion, '1.9.4');
  assert.equal(result.latestReleaseDate, null);
  assert.equal(calls.head.length, 0);
});

test('fetchMavenLatest returns a null latestPatchVersion on request failure', async () => {
  const fakeClient = { get: async () => { throw new Error('network down'); }, head: async () => ({ headers: {} }) };
  const result = await fetchMavenLatest('g', 'a', '1.2.3', fakeClient);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
});

test('fetchMavenLatest returns a null latestPatchVersion for an artifact that 404s off Central', async () => {
  const notFound = Object.assign(new Error('Request failed with status code 404'), { response: { status: 404 } });
  const fakeClient = { get: async () => { throw notFound; }, head: async () => ({ headers: {} }) };
  const result = await fetchMavenLatest('com.cainc.commons', 'internal-lib', '1.3', fakeClient);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.error, null);
});

test('fetchMavenVulnerabilities queries OSV with groupId:artifactId under the Maven ecosystem', async () => {
  let recordedUrl = null, recordedBody = null;
  const fakeClient = {
    post: async (url, body) => { recordedUrl = url; recordedBody = body; return { data: {} }; },
  };
  await fetchMavenVulnerabilities('com.fasterxml.jackson.core', 'jackson-databind', '2.9.0', fakeClient);
  assert.equal(recordedUrl, 'https://api.osv.dev/v1/query');
  assert.deepEqual(recordedBody, {
    package: { name: 'com.fasterxml.jackson.core:jackson-databind', ecosystem: 'Maven' },
    version: '2.9.0',
  });
});

// Node ignores the OS trust store, so behind a TLS-intercepting proxy the OSV
// call dies with "unable to get local issuer certificate" while curl and the
// browser succeed. The agent carrying the system roots must actually reach the
// request config, or the lookup silently fails for every Maven row.
test('fetchMavenVulnerabilities sends an httpsAgent so OS trust roots apply behind a TLS-intercepting proxy', async () => {
  let recordedConfig = null;
  const fakeClient = {
    post: async (_url, _body, config) => { recordedConfig = config; return { data: {} }; },
  };
  await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.ok(recordedConfig.httpsAgent, 'request config must carry an httpsAgent');
  assert.ok(
    Array.isArray(recordedConfig.httpsAgent.options?.ca) && recordedConfig.httpsAgent.options.ca.length > 0,
    'the agent must supply an explicit CA list'
  );
});

test('fetchMavenVulnerabilities keeps certificate verification enabled', async () => {
  let recordedConfig = null;
  const fakeClient = {
    post: async (_url, _body, config) => { recordedConfig = config; return { data: {} }; },
  };
  await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.notEqual(
    recordedConfig.httpsAgent.options.rejectUnauthorized, false,
    'must not disable TLS verification — this feed is a security signal'
  );
});

test('fetchMavenVulnerabilities maps an OSV advisory into a cve, preferring the CVE alias over the GHSA id', async () => {
  const fakeClient = {
    post: async () => ({
      data: {
        vulns: [{
          id: 'GHSA-27xj-rqx5-2255',
          aliases: ['CVE-2020-11619'],
          summary: 'jackson-databind mishandles serialization gadgets',
          details: 'Longer prose that should not win over summary.',
          database_specific: { severity: 'HIGH' },
          references: [
            { type: 'WEB', url: 'https://example.com/thread' },
            { type: 'ADVISORY', url: 'https://nvd.nist.gov/vuln/detail/CVE-2020-11619' },
          ],
        }],
      },
    }),
  };
  const result = await fetchMavenVulnerabilities('g', 'a', '2.9.0', fakeClient);
  assert.deepEqual(result.cves, [{
    id: 'CVE-2020-11619',
    severity: 'high',
    summary: 'jackson-databind mishandles serialization gadgets',
    url: 'https://nvd.nist.gov/vuln/detail/CVE-2020-11619',
  }]);
  assert.equal(result.error, null);
});

test('fetchMavenVulnerabilities falls back to the OSV id and an osv.dev url when there is no CVE alias or ADVISORY reference', async () => {
  const fakeClient = {
    post: async () => ({
      data: { vulns: [{ id: 'GHSA-aaaa-bbbb-cccc', aliases: ['GMS-2021-1'], details: 'Only details here.', database_specific: { severity: 'MODERATE' }, references: [{ type: 'WEB', url: 'https://example.com/x' }] }] },
    }),
  };
  const result = await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.deepEqual(result.cves, [{
    id: 'GHSA-aaaa-bbbb-cccc',
    severity: 'moderate',
    summary: 'Only details here.',
    url: 'https://osv.dev/vulnerability/GHSA-aaaa-bbbb-cccc',
  }]);
});

test('fetchMavenVulnerabilities reports a null severity when OSV carries no database_specific severity', async () => {
  const fakeClient = {
    post: async () => ({ data: { vulns: [{ id: 'OSV-1', summary: 'x', severity: [{ type: 'CVSS_V3', score: 'CVSS:3.1/AV:N' }] }] } }),
  };
  const result = await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.equal(result.cves.length, 1);
  assert.equal(result.cves[0].severity, null);
});

test('fetchMavenVulnerabilities drops withdrawn advisories', async () => {
  const fakeClient = {
    post: async () => ({
      data: {
        vulns: [
          { id: 'OSV-live', summary: 'still valid', database_specific: { severity: 'HIGH' } },
          { id: 'OSV-gone', summary: 'retracted', withdrawn: '2024-01-01T00:00:00Z', database_specific: { severity: 'HIGH' } },
        ],
      },
    }),
  };
  const result = await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.deepEqual(result.cves.map(c => c.id), ['OSV-live']);
});

test('fetchMavenVulnerabilities returns an empty list for an artifact OSV knows nothing about', async () => {
  const fakeClient = { post: async () => ({ data: {} }) };
  const result = await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.deepEqual(result.cves, []);
  assert.equal(result.error, null);
});

test('fetchMavenVulnerabilities returns an empty list and an error message on request failure', async () => {
  const fakeClient = { post: async () => { throw new Error('osv timeout'); } };
  const result = await fetchMavenVulnerabilities('g', 'a', '1.0.0', fakeClient);
  assert.deepEqual(result.cves, []);
  assert.equal(result.error, 'osv timeout');
});

test('fetchNpmLatest returns latest version, release date, and deprecated flag', async () => {
  const fakeClient = {
    get: async () => ({
      data: {
        'dist-tags': { latest: '2.0.0' },
        time: { '2.0.0': '2024-01-01T00:00:00.000Z' },
        versions: { '2.0.0': { deprecated: 'use v3 instead' } },
      },
    }),
  };
  const result = await fetchNpmLatest('some-pkg', '^1.0.0', fakeClient);
  assert.equal(result.latestVersion, '2.0.0');
  assert.equal(result.latestReleaseDate, '2024-01-01T00:00:00.000Z');
  assert.equal(result.deprecated, 'use v3 instead');
  assert.equal(result.error, null);
});

test('fetchNpmLatest computes latestMinorVersion and its release date from all published versions sharing versionInUse\'s major', async () => {
  const fakeClient = {
    get: async () => ({
      data: {
        'dist-tags': { latest: '3.0.0' },
        time: { '3.0.0': '2024-01-01T00:00:00.000Z', '2.10.0': '2023-06-01T00:00:00.000Z' },
        versions: { '1.0.0': {}, '2.9.0': {}, '2.10.0': {}, '3.0.0': {} },
      },
    }),
  };
  const result = await fetchNpmLatest('some-pkg', '^2.5.0', fakeClient);
  assert.equal(result.latestVersion, '3.0.0');
  assert.equal(result.latestMinorVersion, '2.10.0');
  assert.equal(result.latestMinorReleaseDate, '2023-06-01T00:00:00.000Z');
});

// No extra network call: the version map and the date table both come from the
// single metadata response already fetched.
test('fetchNpmLatest computes latestPatchVersion and its release date from the same metadata response', async () => {
  let getCalls = 0;
  const fakeClient = {
    get: async () => {
      getCalls++;
      return {
        data: {
          'dist-tags': { latest: '3.0.1' },
          time: {
            '1.2.9': '2026-07-14T00:00:00.000Z',
            '1.9.4': '2026-03-02T00:00:00.000Z',
            '3.0.1': '2026-08-09T00:00:00.000Z',
          },
          versions: { '1.2.3': {}, '1.2.9': {}, '1.9.4': {}, '3.0.1': {} },
        },
      };
    },
  };
  const result = await fetchNpmLatest('some-pkg', '^1.2.3', fakeClient);
  assert.equal(result.latestPatchVersion, '1.2.9');
  assert.equal(result.latestPatchReleaseDate, '2026-07-14T00:00:00.000Z');
  assert.equal(result.latestMinorVersion, '1.9.4');
  assert.equal(result.latestVersion, '3.0.1');
  assert.equal(getCalls, 1, 'the patch tier must not cost an extra registry request');
});

test('fetchNpmLatest returns null for latestPatchVersion when nothing sits on versionInUse\'s minor line', async () => {
  const fakeClient = {
    get: async () => ({
      data: {
        'dist-tags': { latest: '3.0.1' },
        time: { '3.0.1': '2026-08-09T00:00:00.000Z' },
        versions: { '1.9.4': {}, '3.0.1': {} },
      },
    }),
  };
  const result = await fetchNpmLatest('some-pkg', '^1.2.3', fakeClient);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
});

test('fetchNpmLatest returns nulls and an error message on request failure', async () => {
  const fakeClient = { get: async () => { throw new Error('registry timeout'); } };
  const result = await fetchNpmLatest('some-pkg', '^1.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.latestMinorVersion, null);
  assert.equal(result.latestMinorReleaseDate, null);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
  assert.equal(result.error, 'registry timeout');
});

test('fetchNpmAdvisories maps the bulk advisory response into cves, extracting the GHSA id from the url', async () => {
  const fakeClient = {
    post: async () => ({
      data: {
        'some-pkg': [{
          id: 1097677,
          url: 'https://github.com/advisories/GHSA-xvch-5gv4-984h',
          title: 'Prototype Pollution in minimist',
          severity: 'critical',
          vulnerable_versions: '<0.2.4',
          cwe: ['CWE-1321'],
          cvss: { score: 9.8, vectorString: 'x' },
        }],
      },
    }),
  };
  const result = await fetchNpmAdvisories('some-pkg', '^1.0.0', fakeClient);
  assert.deepEqual(result.cves, [
    {
      id: 'GHSA-xvch-5gv4-984h',
      severity: 'critical',
      summary: 'Prototype Pollution in minimist',
      url: 'https://github.com/advisories/GHSA-xvch-5gv4-984h',
    },
  ]);
  assert.equal(result.error, null);
});

test('fetchNpmAdvisories falls back to a npm-advisory-<id> label when the url has no GHSA id', async () => {
  const fakeClient = {
    post: async () => ({
      data: {
        'some-pkg': [{ id: 42, url: 'https://example.com/not-a-ghsa-link', title: 'Some issue', severity: 'low' }],
      },
    }),
  };
  const result = await fetchNpmAdvisories('some-pkg', '^1.0.0', fakeClient);
  assert.deepEqual(result.cves, [
    { id: 'npm-advisory-42', severity: 'low', summary: 'Some issue', url: 'https://example.com/not-a-ghsa-link' },
  ]);
  assert.equal(result.error, null);
});

test('fetchNpmAdvisories returns an empty list and an error message on request failure', async () => {
  const fakeClient = { post: async () => { throw new Error('advisory endpoint down'); } };
  const result = await fetchNpmAdvisories('some-pkg', '^1.0.0', fakeClient);
  assert.deepEqual(result.cves, []);
  assert.equal(result.error, 'advisory endpoint down');
});

test('fetchPipLatest returns the latest version and release date', async () => {
  const fakeClient = {
    get: async () => ({
      data: { info: { version: '2.31.0' }, releases: { '2.31.0': [{ upload_time_iso_8601: '2023-05-22T00:00:00Z' }] } },
    }),
  };
  const result = await fetchPipLatest('requests', '2.0.0', fakeClient);
  assert.equal(result.latestVersion, '2.31.0');
  assert.equal(result.latestReleaseDate, '2023-05-22T00:00:00Z');
  assert.equal(result.error, null);
});

test('fetchPipLatest computes latestMinorVersion and its release date from all releases sharing versionInUse\'s major', async () => {
  const fakeClient = {
    get: async () => ({
      data: {
        info: { version: '3.0.0' },
        releases: {
          '1.0.0': [{}],
          '2.9.0': [{}],
          '2.10.0': [{ upload_time_iso_8601: '2022-01-01T00:00:00Z' }],
          '3.0.0': [{ upload_time_iso_8601: '2023-05-22T00:00:00Z' }],
        },
      },
    }),
  };
  const result = await fetchPipLatest('requests', '2.0.0', fakeClient);
  assert.equal(result.latestVersion, '3.0.0');
  assert.equal(result.latestMinorVersion, '2.10.0');
  assert.equal(result.latestMinorReleaseDate, '2022-01-01T00:00:00Z');
});

test('fetchPipLatest computes latestPatchVersion and its release date from the same releases response', async () => {
  let getCalls = 0;
  const fakeClient = {
    get: async () => {
      getCalls++;
      return {
        data: {
          info: { version: '3.0.1' },
          releases: {
            '1.2.3': [{}],
            '1.2.9': [{ upload_time_iso_8601: '2026-07-14T00:00:00Z' }],
            '1.9.4': [{ upload_time_iso_8601: '2026-03-02T00:00:00Z' }],
            '3.0.1': [{ upload_time_iso_8601: '2026-08-09T00:00:00Z' }],
          },
        },
      };
    },
  };
  const result = await fetchPipLatest('requests', '1.2.3', fakeClient);
  assert.equal(result.latestPatchVersion, '1.2.9');
  assert.equal(result.latestPatchReleaseDate, '2026-07-14T00:00:00Z');
  assert.equal(result.latestMinorVersion, '1.9.4');
  assert.equal(result.latestVersion, '3.0.1');
  assert.equal(getCalls, 1, 'the patch tier must not cost an extra PyPI request');
});

test('fetchPipLatest returns null for latestPatchVersion when nothing sits on versionInUse\'s minor line', async () => {
  const fakeClient = {
    get: async () => ({
      data: { info: { version: '3.0.1' }, releases: { '1.9.4': [{}], '3.0.1': [{}] } },
    }),
  };
  const result = await fetchPipLatest('requests', '1.2.3', fakeClient);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
});

test('fetchPipLatest returns nulls and an error message on request failure', async () => {
  const fakeClient = { get: async () => { throw new Error('pypi timeout'); } };
  const result = await fetchPipLatest('requests', '2.0.0', fakeClient);
  assert.equal(result.latestVersion, null);
  assert.equal(result.latestMinorVersion, null);
  assert.equal(result.latestMinorReleaseDate, null);
  assert.equal(result.latestPatchVersion, null);
  assert.equal(result.latestPatchReleaseDate, null);
  assert.equal(result.error, 'pypi timeout');
});

// PyPI's own per-version JSON exposes a `vulnerabilities` field built from the
// OSV corpus, but strips the severity out of every entry — so all Python
// findings rendered as "unknown", indistinguishable from an advisory that
// genuinely carries no rating. Querying OSV directly restores real severities
// and puts Python rows on the same feed as every other ecosystem here.
test('fetchPipVulnerabilities queries OSV under the PyPI ecosystem', async () => {
  let recordedUrl = null, recordedBody = null;
  const fakeClient = {
    post: async (url, body) => { recordedUrl = url; recordedBody = body; return { data: {} }; },
  };
  await fetchPipVulnerabilities('requests', '2.0.0', fakeClient);
  assert.equal(recordedUrl, 'https://api.osv.dev/v1/query');
  assert.deepEqual(recordedBody, {
    package: { name: 'requests', ecosystem: 'PyPI' },
    version: '2.0.0',
  });
});

test('fetchPipVulnerabilities reports the severity OSV supplies', async () => {
  const fakeClient = {
    post: async () => ({
      data: { vulns: [{ id: 'PYSEC-2023-1', aliases: ['CVE-2023-9999'], summary: 'Example vuln', database_specific: { severity: 'HIGH' } }] },
    }),
  };
  const result = await fetchPipVulnerabilities('requests', '2.0.0', fakeClient);
  assert.equal(result.cves[0].id, 'CVE-2023-9999');
  assert.equal(result.cves[0].severity, 'high');
  assert.equal(result.error, null);
});

test('fetchPipVulnerabilities returns an empty list and an error message on request failure', async () => {
  const fakeClient = { post: async () => { throw new Error('pypi vuln lookup failed'); } };
  const result = await fetchPipVulnerabilities('requests', '2.0.0', fakeClient);
  assert.deepEqual(result.cves, []);
  assert.equal(result.error, 'pypi vuln lookup failed');
});
