'use strict';
const { dedupeRows } = require('./dedupe');
const { stripRangePrefix } = require('./compare-versions');
const defaultRegistries = require('./registries');
const { matchManifests, detectUntrackedEcosystems, createParseContext } = require('./manifests');
const { ecosystemById } = require('./ecosystems');

// Upper bound on manifests fetched from a single repo. A large monorepo can
// legitimately carry hundreds of package.json files, and one repo should not be
// able to consume the whole scan's request budget.
//
// Whatever this drops is counted in scanSummary.manifestsSkipped and rendered
// in the footer: a silently truncated repo would read as "fully scanned, few
// dependencies", which is exactly the wrong conclusion.
const MAX_MANIFESTS_PER_REPO = 100;

// Simple concurrency-limiting throttle, matching the pattern already used
// elsewhere in server/index.js's dependency-graph handler.
function makeThrottle(maxConcurrent) {
  let active = 0;
  const queue = [];
  return function throttle(fn) {
    return new Promise((resolve, reject) => {
      const run = async () => {
        active++;
        try { resolve(await fn()); } catch (e) { reject(e); } finally {
          active--;
          if (queue.length) queue.shift()();
        }
      };
      active < maxConcurrent ? run() : queue.push(run);
    });
  };
}

async function runScan({ repos, fetchManifest, listRepoFiles, registries = defaultRegistries, onProgress = () => {} }) {
  // Fail loudly rather than letting every repo fall into the catch below and
  // report as a fetch error — that would look like a GitHub outage.
  if (typeof listRepoFiles !== 'function') {
    throw new TypeError('runScan requires a listRepoFiles function');
  }

  const ghThrottle = makeThrottle(8);
  const perRepoEntries = [];
  let unresolvedDependencyVersions = 0;
  // Counts manifests that were fetched but couldn't be parsed at all (e.g. a
  // corrupted package.json fails JSON.parse) — kept separate from
  // `unresolvedDependencyVersions` (individual deps a parser deliberately
  // skips) so a single bad file never crashes the whole org-wide scan.
  let manifestParseErrors = 0;
  // Repos where GitHub reported the file tree as truncated, so the manifest
  // list we matched against was incomplete.
  let reposWithTruncatedTree = 0;
  let manifestsSkipped = 0;
  // Repos where a tree listing or manifest fetch threw a real error
  // (auth/rate-limit/5xx/timeout) rather than returning a normal absence.
  // A Set so a repo with several failing fetches is only counted once.
  const reposWithFetchErrors = new Set();
  // Ecosystems we detected but have no parser for → { label: repoCount }.
  const untrackedRepoCounts = new Map();

  // Reads one repo's file tree, fetches every manifest it matched, then parses
  // them. Fetching completes before any parsing begins because two parsers need
  // cross-file context from the same repo — a .csproj reads its versions from
  // Directory.Packages.props, and composer.json prefers composer.lock's
  // resolved versions over its own declared ranges.
  const scanRepo = async (repo) => {
    const listing = await ghThrottle(() => listRepoFiles(repo.name, repo.default_branch));
    const paths = listing?.paths || [];
    if (listing?.truncated) reposWithTruncatedTree++;

    for (const label of detectUntrackedEcosystems(paths)) {
      untrackedRepoCounts.set(label, (untrackedRepoCounts.get(label) || 0) + 1);
    }

    // Support manifests sort first so the cap below can never discard the props
    // or lock file that a primary manifest depends on for its versions.
    const matches = matchManifests(paths)
      .sort((a, b) => (b.handler.support ? 1 : 0) - (a.handler.support ? 1 : 0));
    const selected = matches.slice(0, MAX_MANIFESTS_PER_REPO);
    manifestsSkipped += matches.length - selected.length;

    const textByPath = new Map();
    let sawFetchError = false;
    await Promise.all(selected.map(({ path }) => ghThrottle(async () => {
      try {
        const text = await fetchManifest(repo.name, path);
        // null means the path vanished between the tree listing and the fetch —
        // a normal race on an active repo, not a failure.
        if (text != null) textByPath.set(path, text);
      } catch (_) {
        sawFetchError = true;
      }
    })));
    if (sawFetchError) reposWithFetchErrors.add(repo.name);

    for (const { path, handler } of selected) {
      if (handler.support) continue;   // context only — declares no dependencies
      const text = textByPath.get(path);
      if (text === undefined) continue;
      try {
        const { dependencies, unresolvedCount = 0 } = handler.parse(text, createParseContext(path, textByPath));
        unresolvedDependencyVersions += unresolvedCount;
        for (const dependency of dependencies) {
          perRepoEntries.push({
            repo: repo.name,
            // A parser may route an individual dependency to a different
            // ecosystem than its manifest's default. environment.yml is the
            // case that requires it: its main list is conda packages, but its
            // nested pip: block declares PyPI packages, whose names and
            // versions genuinely belong to PyPI and must be looked up there.
            ecosystem: dependency.ecosystem || handler.ecosystem,
            package: dependency.name,
            version: dependency.version,
            versionIsRange: dependency.versionIsRange,
          });
        }
      } catch (_) {
        manifestParseErrors++;
      }
    }
  };

  let done = 0;
  for (const repo of repos) {
    try {
      await scanRepo(repo);
    } catch (_) {
      // The tree listing failed, so we never learned what this repo contains.
      reposWithFetchErrors.add(repo.name);
    }
    done++;
    onProgress({ phase: 'scanning', current: done, total: repos.length, label: repo.name });
  }

  const dedupedRows = dedupeRows(perRepoEntries);

  const enrichThrottle = makeThrottle(10);
  let lookupErrorRows = 0;
  let enriched = 0;
  const rows = await Promise.all(dedupedRows.map(row => enrichThrottle(async () => {
    const lookupErrors = [];
    const ecosystem = ecosystemById(row.ecosystem);

    let latest = {};
    let vulnerabilities = { cves: [], error: null };
    // Why no findings can be shown, when that is the case. Three outcomes are
    // genuinely different and must not collapse into one another:
    //   null          — checked successfully
    //   'error'       — the lookup was attempted and failed
    //   'unsupported' — no vulnerability database covers this ecosystem at all
    //                   (Conan, Conda, CPAN), so there was nothing to attempt
    let cvesUnavailableReason = null;
    // Set when no registry can answer "what is the latest version" for this
    // ecosystem — Swift, whose packages resolve from git URLs rather than an
    // index. Distinct from "looked and found nothing newer".
    let latestUnavailable = false;

    if (!ecosystem) {
      // A cached row from an ecosystem this build no longer knows about. Nothing
      // was checked, so nothing may be reported as clean.
      lookupErrors.push(`No registry configured for ecosystem "${row.ecosystem}"`);
      cvesUnavailableReason = 'unsupported';
      latestUnavailable = true;
    } else {
      if (ecosystem.latest) {
        latest = (await ecosystem.latest(registries, row.package, row.versionInUse)) || {};
        if (latest.error) lookupErrors.push(`${ecosystem.latestErrorLabel}: ${latest.error}`);
      } else {
        latestUnavailable = true;
      }

      if (ecosystem.vulnerabilities) {
        vulnerabilities = (await ecosystem.vulnerabilities(registries, row.package, row.versionInUse))
          || { cves: [], error: null };
        if (vulnerabilities.error) {
          cvesUnavailableReason = 'error';
          lookupErrors.push(`${ecosystem.vulnerabilitiesErrorLabel}: ${vulnerabilities.error}`);
        }
      } else {
        // Deliberately NOT recorded in lookupErrors: no request was made and
        // nothing failed, so counting it would inflate the scan summary's
        // "registry lookups failed" tally on every scan of these ecosystems.
        cvesUnavailableReason = 'unsupported';
      }
    }

    const cves = vulnerabilities.cves || [];
    // "Could not check" must never render as "checked and found nothing" — an
    // empty cves list is otherwise ambiguous, and reading the second as the
    // first reports a possibly-vulnerable dependency as clean.
    const cvesUnavailable = cvesUnavailableReason !== null;

    if (lookupErrors.length) lookupErrorRows++;

    enriched++;
    onProgress({ phase: 'enriching', current: enriched, total: dedupedRows.length, label: row.package });

    const latestVersion = latest.latestVersion ?? null;
    return {
      ecosystem: row.ecosystem,
      package: row.package,
      versionInUse: row.versionInUse,
      // Only present when true, so an exactly-pinned row carries no marker at
      // all rather than an explicit false on every row in the cache.
      ...(row.versionIsRange ? { versionIsRange: true } : {}),
      latestVersion,
      latestMinorVersion: latest.latestMinorVersion ?? null,
      latestPatchVersion: latest.latestPatchVersion ?? null,
      latestReleaseDate: latest.latestReleaseDate ?? null,
      latestMinorReleaseDate: latest.latestMinorReleaseDate ?? null,
      latestPatchReleaseDate: latest.latestPatchReleaseDate ?? null,
      deprecated: latest.deprecated ?? null,
      // Only present when true, keeping the cached row shape minimal across
      // thousands of rows that have a perfectly ordinary version source.
      ...(latestUnavailable ? { latestUnavailable: true } : {}),
      cves,
      cvesUnavailable,
      cvesUnavailableReason,
      usedBy: row.usedBy,
      status: {
        needsUpgrade: cves.length > 0,
        // stripRangePrefix is a no-op for exact-pinned ecosystems, but npm's
        // versionInUse is often a declared range (e.g. "^4.17.21") — without
        // stripping the operator this would almost never be true for npm rows
        // even when they're genuinely current.
        upToDate: latestVersion != null && latestVersion === stripRangePrefix(row.versionInUse),
        changedSinceLastScan: false,
      },
      lookupErrors,
    };
  })));

  return {
    rows,
    scanSummary: {
      reposScanned: repos.length,
      repoFetchErrors: reposWithFetchErrors.size,
      manifestParseErrors,
      unresolvedDependencyVersions,
      lookupErrors: lookupErrorRows,
      reposWithTruncatedTree,
      manifestsSkipped,
      untrackedEcosystems: [...untrackedRepoCounts]
        .map(([label, repos]) => ({ label, repos }))
        .sort((a, b) => b.repos - a.repos || a.label.localeCompare(b.label)),
    },
  };
}

module.exports = { runScan, makeThrottle, MAX_MANIFESTS_PER_REPO };
