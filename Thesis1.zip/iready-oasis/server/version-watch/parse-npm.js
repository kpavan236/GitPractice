'use strict';

// Parses a package.json's direct `dependencies` + `devDependencies` into
// { name, version } entries. `version` is kept exactly as declared (often a
// semver range like "^2.14.1") — this module does not read package-lock.json,
// per the spec's documented v1 limitation. When a package appears in both
// `dependencies` and `devDependencies`, the `dependencies` entry wins
// (Object.assign below applies devDependencies first, then dependencies).
function parsePackageJson(jsonText) {
  const pkg = JSON.parse(jsonText);
  const merged = Object.assign({}, pkg.devDependencies, pkg.dependencies);
  const dependencies = Object.entries(merged).map(([name, version]) => ({ name, version }));
  return { dependencies };
}

module.exports = { parsePackageJson };
