'use strict';

// Matches a cpanfile requirement: requires / test_requires / recommends /
// suggests / conflicts, with an optional version argument. Requirements inside
// an `on 'test' => sub { ... }` block use the same syntax, so scanning the whole
// file picks them up without needing to track blocks.
const CPAN_REQUIREMENT =
  /^\s*(?:requires|test_requires|build_requires|configure_requires|author_requires|recommends|suggests)\s+["']([^"']+)["']\s*(?:,\s*["']([^"']*)["']\s*)?;/gm;

// Parses a cpanfile.
//
// CPAN treats a bare version as a MINIMUM, not a pin — "requires 'Plack',
// '1.0048'" means 1.0048 or newer — so every version here is a range floor.
//
// A version of '0' is the idiomatic way to say "any version", so it carries no
// more information than omitting the argument and is counted unresolved.
function parseCpanfile(text) {
  const source = String(text).replace(/^\s*#.*$/gm, '');

  const dependencies = [];
  let unresolvedCount = 0;
  const seen = new Set();

  for (const match of source.matchAll(CPAN_REQUIREMENT)) {
    const [, name, rawVersion] = match;

    // The Perl interpreter itself, not a distribution on CPAN.
    if (name.toLowerCase() === 'perl') continue;

    const version = (rawVersion || '').trim();
    if (!version || !/[1-9]/.test(version)) { unresolvedCount++; continue; }

    const key = `${name}:${version}`;
    if (seen.has(key)) continue;
    seen.add(key);
    dependencies.push({ name, version, versionIsRange: true });
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseCpanfile };
