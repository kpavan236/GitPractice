'use strict';
const { parseYaml } = require('./parse-yaml');
const { isRangeDeclaration } = require('./compare-versions');

// Parses a .cabal file's build-depends fields.
//
// A cabal field's value continues onto following lines while they are indented
// past the field name, and the list is conventionally written with leading
// commas. So the field is gathered as a block first, then split — reading it
// line by line would drop every continuation entry.
function parseCabal(text) {
  const source = String(text).replace(/^\s*--.*$/gm, '');
  const lines = source.split(/\r?\n/);

  const dependencies = [];
  let unresolvedCount = 0;
  const seen = new Set();

  for (let i = 0; i < lines.length; i++) {
    const start = lines[i].match(/^(\s*)build-depends\s*:(.*)$/i);
    if (!start) continue;

    const fieldIndent = start[1].length;
    let block = start[2];
    // Consume continuation lines: anything indented deeper than the field, that
    // is not itself a new field.
    for (let j = i + 1; j < lines.length; j++) {
      const line = lines[j];
      if (!line.trim()) break;
      const indent = line.match(/^\s*/)[0].length;
      if (indent <= fieldIndent) break;
      if (/^\s*[A-Za-z][\w-]*\s*:/.test(line) && !/^\s*,/.test(line)) break;
      block += ' ' + line.trim();
      i = j;
    }

    for (const raw of block.split(',')) {
      const spec = raw.trim();
      if (!spec) continue;
      const match = spec.match(/^([A-Za-z][\w-]*)\s*(.*)$/);
      if (!match) { unresolvedCount++; continue; }
      const [, name, constraint] = match;

      // No bound at all — the solver picks, so there is no version in use.
      if (!constraint || !/\d/.test(constraint)) { unresolvedCount++; continue; }

      // "==2.1.2.1" is a pin; everything else (>=, &&, ^>=) is a range.
      const pin = constraint.match(/^==\s*([\w.]+)$/);
      const entry = pin
        ? { name, version: pin[1] }
        : { name, version: constraint.trim(), versionIsRange: true };

      const key = `${entry.name}:${entry.version}`;
      if (seen.has(key)) continue;
      seen.add(key);
      dependencies.push(entry);
    }
  }

  return { dependencies, unresolvedCount };
}

// Splits a Hackage package id ("unordered-containers-0.2.19.1") into name and
// version. The split is at the LAST hyphen followed by a digit, because package
// names contain hyphens themselves — splitting at the first would yield
// "unordered" at version "containers-0.2.19.1".
function splitPackageId(packageId) {
  const match = String(packageId).match(/^(.*)-(\d[\w.]*)$/);
  return match ? { name: match[1], version: match[2] } : null;
}

// Parses stack.yaml's extra-deps: packages pinned outside the resolver, always
// as exact package ids. A git-sourced entry is a map rather than a string and has
// no Hackage release to compare against.
function parseStackYaml(text) {
  const doc = parseYaml(text);
  const extraDeps = doc['extra-deps'];

  const dependencies = [];
  let unresolvedCount = 0;

  if (!Array.isArray(extraDeps)) return { dependencies, unresolvedCount };

  for (const item of extraDeps) {
    if (typeof item !== 'string') { unresolvedCount++; continue; }
    const split = splitPackageId(item.trim());
    if (!split) { unresolvedCount++; continue; }
    dependencies.push(split);
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseCabal, parseStackYaml, splitPackageId };
