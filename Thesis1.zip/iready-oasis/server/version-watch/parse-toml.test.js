'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseToml } = require('./parse-toml');

// This is a deliberately partial TOML reader — just enough to read dependency
// declarations out of pyproject.toml, Cargo.toml, Pipfile, and Gradle version
// catalogs. These tests pin the subset that dependency manifests actually use;
// dates, multi-line basic strings, and numeric typing are out of scope.

test('reads a top-level key/value string', () => {
  assert.deepStrictEqual(parseToml('name = "requests"'), { name: 'requests' });
});

test('nests values under a table header', () => {
  const toml = `
[project]
name = "my-app"
`;
  assert.deepStrictEqual(parseToml(toml), { project: { name: 'my-app' } });
});

test('nests values under a dotted table header', () => {
  const toml = `
[tool.poetry.dependencies]
requests = "^2.28.0"
`;
  assert.deepStrictEqual(parseToml(toml), {
    tool: { poetry: { dependencies: { requests: '^2.28.0' } } },
  });
});

test('merges sibling tables sharing a parent path', () => {
  const toml = `
[tool.poetry.dependencies]
requests = "2.0"

[tool.poetry.group.dev.dependencies]
pytest = "7.0"
`;
  const result = parseToml(toml);
  assert.strictEqual(result.tool.poetry.dependencies.requests, '2.0');
  assert.strictEqual(result.tool.poetry.group.dev.dependencies.pytest, '7.0');
});

test('parses an inline table into an object', () => {
  const toml = 'serde = { version = "1.0.188", features = ["derive"] }';
  assert.deepStrictEqual(parseToml(toml), {
    serde: { version: '1.0.188', features: ['derive'] },
  });
});

test('parses an array of strings', () => {
  const toml = 'dependencies = ["requests>=2.28", "flask==3.0.0"]';
  assert.deepStrictEqual(parseToml(toml), {
    dependencies: ['requests>=2.28', 'flask==3.0.0'],
  });
});

test('parses an array that spans multiple lines', () => {
  const toml = `
dependencies = [
  "requests>=2.28",
  "flask==3.0.0",
]
`;
  assert.deepStrictEqual(parseToml(toml), {
    dependencies: ['requests>=2.28', 'flask==3.0.0'],
  });
});

test('parses an inline table that spans multiple lines', () => {
  const toml = `
tokio = {
  version = "1.35.0",
  features = ["full"]
}
`;
  assert.deepStrictEqual(parseToml(toml), {
    tokio: { version: '1.35.0', features: ['full'] },
  });
});

test('ignores whole-line and trailing comments', () => {
  const toml = `
# this whole line is a comment
name = "requests"  # and this trailer
`;
  assert.deepStrictEqual(parseToml(toml), { name: 'requests' });
});

test('keeps a hash character that appears inside a quoted string', () => {
  assert.deepStrictEqual(parseToml('url = "https://x.test/#frag"'), {
    url: 'https://x.test/#frag',
  });
});

test('reads a literal single-quoted string without unescaping', () => {
  assert.deepStrictEqual(parseToml("path = 'C:\\deps\\lib'"), {
    path: 'C:\\deps\\lib',
  });
});

test('unescapes a backslash escape inside a basic string', () => {
  assert.deepStrictEqual(parseToml('quote = "say \\"hi\\""'), {
    quote: 'say "hi"',
  });
});

test('reads a quoted key that contains a dot', () => {
  // Gradle version catalogs routinely use these:
  //   [libraries]
  //   "com.google.guava" = { ... }
  const toml = `
[libraries]
"com.fasterxml.jackson" = "2.15.0"
`;
  assert.deepStrictEqual(parseToml(toml), {
    libraries: { 'com.fasterxml.jackson': '2.15.0' },
  });
});

test('assigns a dotted key into nested objects', () => {
  assert.deepStrictEqual(parseToml('a.b.c = "v"'), { a: { b: { c: 'v' } } });
});

test('keeps an unquoted value such as a boolean as raw text', () => {
  // Cargo's `optional = true` must not break the surrounding inline table —
  // the version is what we're after, so untyped raw text is sufficient.
  const toml = 'rand = { version = "0.8", optional = true }';
  assert.deepStrictEqual(parseToml(toml), {
    rand: { version: '0.8', optional: 'true' },
  });
});

test('parses an array of tables into a list', () => {
  const toml = `
[[tool.uv.sources]]
name = "a"

[[tool.uv.sources]]
name = "b"
`;
  assert.deepStrictEqual(parseToml(toml).tool.uv.sources, [
    { name: 'a' },
    { name: 'b' },
  ]);
});

test('returns an empty object for empty input', () => {
  assert.deepStrictEqual(parseToml(''), {});
});

test('ignores a malformed line rather than throwing', () => {
  // A manifest we cannot fully understand must still yield what it can — the
  // scan treats a throw as a parse failure for the whole file.
  const toml = `
this line has no equals sign
name = "requests"
`;
  assert.deepStrictEqual(parseToml(toml), { name: 'requests' });
});