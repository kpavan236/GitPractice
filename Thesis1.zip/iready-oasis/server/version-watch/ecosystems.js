'use strict';
const { stripRangePrefix } = require('./compare-versions');

// The ecosystems a dependency row can belong to, and how to look one up.
//
// This is deliberately separate from the manifest table in manifests.js, because
// manifest identity is not ecosystem identity: a group:artifact coordinate is
// the same artifact whether it was declared in a pom.xml or a build.gradle, and
// must dedupe with itself across both. So Gradle has a parser but no ecosystem,
// and requirements.txt / pyproject.toml / Pipfile all produce `pip` rows.
//
// Every lookup takes the injected `registries` object as its first argument, so
// scan.js keeps its single testable seam instead of each ecosystem reaching for
// the network module directly.

// OSV needs one concrete version, not a range. For a range-declared dependency
// the floor is the honest thing to ask about: it is the oldest version the
// declaration permits, so a finding against it means "the floor you allow is
// vulnerable". Rows carrying a range are marked `versionIsRange` so that
// weaker claim is visible in the UI rather than implied.
const osvLookup = (osvEcosystem) => (registries, packageName, versionInUse) =>
  registries.fetchOsvVulnerabilities(osvEcosystem, packageName, stripRangePrefix(versionInUse));

// Maven coordinates arrive joined as "groupId:artifactId" because that is the
// row's identity; the registry API wants them apart. Splitting on the FIRST
// colon only would be wrong for neither field, but limiting the split keeps a
// stray colon in an artifactId from silently dropping part of the name.
function splitMavenCoordinate(packageName) {
  const separator = String(packageName).indexOf(':');
  if (separator === -1) return [packageName, ''];
  return [packageName.slice(0, separator), packageName.slice(separator + 1)];
}

// OSV's SwiftURL ecosystem names a package by host and path only — no scheme,
// no trailing .git, no trailing slash. Package.swift declares the full clone
// URL, so sending it unmodified would match nothing in the corpus.
function normalizeSwiftPackageUrl(packageUrl) {
  return String(packageUrl)
    .replace(/^[a-z+]+:\/\//i, '')
    .replace(/^[^@/]+@/, '')          // scp-style "git@github.com:org/repo"
    .replace(/\.git$/i, '')
    .replace(/\/+$/, '');
}

const ECOSYSTEMS = [
  {
    id: 'maven',
    label: 'Maven',
    latest: (registries, packageName, versionInUse) => {
      const [groupId, artifactId] = splitMavenCoordinate(packageName);
      return registries.fetchMavenLatest(groupId, artifactId, versionInUse);
    },
    vulnerabilities: (registries, packageName, versionInUse) => {
      const [groupId, artifactId] = splitMavenCoordinate(packageName);
      return registries.fetchMavenVulnerabilities(groupId, artifactId, versionInUse);
    },
    latestErrorLabel: 'Maven Central lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'npm',
    label: 'npm',
    latest: (registries, packageName, versionInUse) => registries.fetchNpmLatest(packageName, versionInUse),
    // Passed through unmodified on purpose: npm's bulk advisory endpoint
    // understands semver ranges, so asking it about "^4.17.21" is a strictly
    // better question than asking about the floor alone.
    vulnerabilities: (registries, packageName, versionInUse) => registries.fetchNpmAdvisories(packageName, versionInUse),
    latestErrorLabel: 'npm registry lookup failed',
    vulnerabilitiesErrorLabel: 'npm advisory lookup failed',
  },
  {
    id: 'pip',
    label: 'Python',
    latest: (registries, packageName, versionInUse) => registries.fetchPipLatest(packageName, versionInUse),
    vulnerabilities: (registries, packageName, versionInUse) =>
      registries.fetchPipVulnerabilities(packageName, stripRangePrefix(versionInUse)),
    latestErrorLabel: 'PyPI lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'go',
    label: 'Go',
    latest: (registries, packageName, versionInUse) => registries.fetchGoLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('Go'),
    latestErrorLabel: 'Go module proxy lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'cargo',
    label: 'Rust',
    latest: (registries, packageName, versionInUse) => registries.fetchCargoLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('crates.io'),
    latestErrorLabel: 'crates.io lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'nuget',
    label: '.NET',
    latest: (registries, packageName, versionInUse) => registries.fetchNugetLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('NuGet'),
    latestErrorLabel: 'NuGet lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'rubygems',
    label: 'Ruby',
    latest: (registries, packageName, versionInUse) => registries.fetchRubygemsLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('RubyGems'),
    latestErrorLabel: 'RubyGems lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'composer',
    label: 'PHP',
    latest: (registries, packageName, versionInUse) => registries.fetchComposerLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('Packagist'),
    latestErrorLabel: 'Packagist lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'swift',
    label: 'Swift',
    // No version source exists. Swift resolves packages from git URLs rather
    // than from a package index, so there is no endpoint that can answer "what
    // is the latest version" — listing tags on each upstream host would mean
    // hundreds of unauthenticated requests to github.com per scan.
    //
    // Declared as an explicit null rather than omitted, so scan.js can report
    // "not tracked" instead of an empty cell that reads as "already current".
    latest: null,
    vulnerabilities: (registries, packageName, versionInUse) =>
      registries.fetchOsvVulnerabilities('SwiftURL', normalizeSwiftPackageUrl(packageName), stripRangePrefix(versionInUse)),
    latestErrorLabel: 'Swift version lookup unavailable',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'pub',
    label: 'Dart',
    latest: (registries, packageName, versionInUse) => registries.fetchPubLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('Pub'),
    latestErrorLabel: 'pub.dev lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'hex',
    label: 'Elixir',
    latest: (registries, packageName, versionInUse) => registries.fetchHexLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('Hex'),
    latestErrorLabel: 'hex.pm lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  {
    id: 'hackage',
    label: 'Haskell',
    latest: (registries, packageName, versionInUse) => registries.fetchHackageLatest(packageName, versionInUse),
    vulnerabilities: osvLookup('Hackage'),
    latestErrorLabel: 'Hackage lookup failed',
    vulnerabilitiesErrorLabel: 'OSV vulnerability lookup failed',
  },
  // ── ecosystems with no vulnerability database in existence ────────────────
  // OSV covers no Conan, Conda or CPAN ecosystem, and no other public feed does
  // either. `vulnerabilities: null` is how that is stated, and scan.js turns it
  // into an explicit "not checked" — these rows must never be presented as
  // clean, which is exactly what an empty findings list would imply.
  {
    id: 'conan',
    label: 'C/C++',
    latest: (registries, packageName, versionInUse) => registries.fetchConanLatest(packageName, versionInUse),
    vulnerabilities: null,
    latestErrorLabel: 'Conan Center lookup failed',
    vulnerabilitiesErrorLabel: 'No vulnerability database covers Conan packages',
  },
  {
    id: 'conda',
    label: 'Conda',
    latest: (registries, packageName, versionInUse) => registries.fetchCondaLatest(packageName, versionInUse),
    vulnerabilities: null,
    latestErrorLabel: 'anaconda.org lookup failed',
    vulnerabilitiesErrorLabel: 'No vulnerability database covers Conda packages',
  },
  {
    id: 'cpan',
    label: 'Perl',
    latest: (registries, packageName, versionInUse) => registries.fetchCpanLatest(packageName, versionInUse),
    vulnerabilities: null,
    latestErrorLabel: 'MetaCPAN lookup failed',
    vulnerabilitiesErrorLabel: 'No vulnerability database covers CPAN modules',
  },
];

const BY_ID = new Map(ECOSYSTEMS.map(eco => [eco.id, eco]));

function ecosystemById(id) {
  return BY_ID.get(id);
}

// Display label for an ecosystem id, falling back to the raw id. The frontend
// derives its filter chips from scanned rows, so a cached row whose ecosystem
// this table no longer lists must still render as something readable rather
// than as "undefined".
function ecosystemLabel(id) {
  return BY_ID.get(id)?.label || id;
}

module.exports = { ECOSYSTEMS, ecosystemById, ecosystemLabel, splitMavenCoordinate, normalizeSwiftPackageUrl };
