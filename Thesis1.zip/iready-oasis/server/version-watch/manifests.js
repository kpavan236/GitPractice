'use strict';
const { parsePomXml } = require('./parse-maven');
const { parsePackageJson } = require('./parse-npm');
const { parseRequirementsTxt } = require('./parse-pip');
const { parsePyproject, parsePipfile } = require('./parse-pyproject');
const { parseGradleBuild, parseVersionCatalog } = require('./parse-gradle');
const { parseGoMod } = require('./parse-go');
const { parseCargoToml } = require('./parse-cargo');
const { parseCsproj, parsePackagesConfig, parseDirectoryPackagesProps } = require('./parse-nuget');
const { parseGemfileLock } = require('./parse-rubygems');
const { parseComposerJson, parseComposerLock } = require('./parse-composer');
const { parseSbt } = require('./parse-sbt');
const { parseSwiftPackage, parsePackageResolved } = require('./parse-swift');
const { parsePubspec, parsePubspecLock } = require('./parse-dart');
const { parseMixExs, parseMixLock } = require('./parse-elixir');
const { parseConanfileTxt, parseConanfilePy } = require('./parse-conan');
const { parseCondaEnvironment } = require('./parse-conda');
const { parseCabal, parseStackYaml } = require('./parse-haskell');
const { parseCpanfile } = require('./parse-cpan');

// Maps a repo file path to the parser that reads it and the ecosystem its
// dependencies belong to.
//
// Deliberately separate from ecosystems.js: several manifests feed one
// ecosystem. A coordinate from build.gradle is the same artifact as one from
// pom.xml and must dedupe with it, so both carry ecosystem 'maven'; likewise all
// three Python manifests carry 'pip'.
//
// A handler marked `support: true` is fetched for context but declares no
// dependencies of its own — Directory.Packages.props holds versions that
// project files reference, and composer.lock holds resolved versions for
// composer.json's declared ranges.

const basename = (path) => String(path).split('/').pop();

// Every parser is normalized to (text, ctx) => { dependencies, unresolvedCount }
// with dependencies as { name, version, versionIsRange? }, so scan.js never
// needs to know which ecosystem it is handling.
const MANIFEST_HANDLERS = [
  {
    id: 'pom',
    ecosystem: 'maven',
    match: p => basename(p) === 'pom.xml',
    // parse-maven reports groupId/artifactId separately; joining them here is
    // what makes the coordinate the row's identity.
    parse: (text) => {
      const { dependencies, unresolvedCount } = parsePomXml(text);
      return {
        dependencies: dependencies.map(d => ({ name: `${d.groupId}:${d.artifactId}`, version: d.version })),
        unresolvedCount,
      };
    },
  },
  {
    id: 'gradle',
    ecosystem: 'maven',
    match: p => /^build\.gradle(\.kts)?$/.test(basename(p)),
    parse: parseGradleBuild,
  },
  {
    id: 'gradle-catalog',
    ecosystem: 'maven',
    // Only at Gradle's conventional location — a libs.versions.toml elsewhere
    // is not a catalog the build actually reads.
    match: p => /(^|\/)gradle\/libs\.versions\.toml$/.test(p),
    parse: parseVersionCatalog,
  },
  {
    id: 'npm',
    ecosystem: 'npm',
    match: p => basename(p) === 'package.json',
    parse: parsePackageJson,
  },
  {
    id: 'requirements',
    ecosystem: 'pip',
    // requirements-dev.txt, requirements/base.txt and similar are all real
    // dependency declarations.
    match: p => /^requirements[\w.-]*\.txt$/.test(basename(p)),
    parse: parseRequirementsTxt,
  },
  {
    id: 'pyproject',
    ecosystem: 'pip',
    match: p => basename(p) === 'pyproject.toml',
    parse: parsePyproject,
  },
  {
    id: 'pipfile',
    ecosystem: 'pip',
    match: p => basename(p) === 'Pipfile',
    parse: parsePipfile,
  },
  {
    id: 'gomod',
    ecosystem: 'go',
    match: p => basename(p) === 'go.mod',
    parse: parseGoMod,
  },
  {
    id: 'cargo',
    ecosystem: 'cargo',
    match: p => basename(p) === 'Cargo.toml',
    parse: parseCargoToml,
  },
  {
    id: 'csproj',
    ecosystem: 'nuget',
    match: p => /\.(csproj|fsproj|vbproj)$/.test(basename(p)),
    parse: (text, ctx) => parseCsproj(text, {
      // MSBuild finds Directory.Packages.props by walking up from the project,
      // which is exactly what ctx.findUp reproduces.
      packageVersions: ctx.findUp('Directory.Packages.props', parseDirectoryPackagesProps) || {},
    }),
  },
  {
    id: 'packages-config',
    ecosystem: 'nuget',
    match: p => basename(p) === 'packages.config',
    parse: parsePackagesConfig,
  },
  {
    id: 'gemfile-lock',
    ecosystem: 'rubygems',
    match: p => basename(p) === 'Gemfile.lock',
    parse: parseGemfileLock,
  },
  {
    id: 'composer',
    ecosystem: 'composer',
    match: p => basename(p) === 'composer.json',
    parse: (text, ctx) => parseComposerJson(text, {
      // Sibling only: a composer.lock one directory up belongs to a different
      // project and would supply the wrong resolved versions.
      lockVersions: ctx.sibling('composer.lock', parseComposerLock) || {},
    }),
  },
  {
    id: 'sbt',
    // An sbt coordinate IS a Maven coordinate, so a library used from both Scala
    // and Java dedupes into a single row rather than appearing twice.
    ecosystem: 'maven',
    match: p => /\.sbt$/.test(basename(p)),
    parse: parseSbt,
  },
  {
    id: 'swift',
    ecosystem: 'swift',
    match: p => basename(p) === 'Package.swift',
    parse: (text, ctx) => parseSwiftPackage(text, {
      pinsVersions: ctx.sibling('Package.resolved', parsePackageResolved) || {},
    }),
  },
  {
    id: 'pubspec',
    ecosystem: 'pub',
    match: p => basename(p) === 'pubspec.yaml',
    parse: (text, ctx) => parsePubspec(text, {
      lockVersions: ctx.sibling('pubspec.lock', parsePubspecLock) || {},
    }),
  },
  {
    id: 'mix',
    ecosystem: 'hex',
    match: p => basename(p) === 'mix.exs',
    parse: (text, ctx) => parseMixExs(text, {
      lockVersions: ctx.sibling('mix.lock', parseMixLock) || {},
    }),
  },
  {
    id: 'conanfile-txt',
    ecosystem: 'conan',
    match: p => basename(p) === 'conanfile.txt',
    parse: parseConanfileTxt,
  },
  {
    id: 'conanfile-py',
    ecosystem: 'conan',
    match: p => basename(p) === 'conanfile.py',
    parse: parseConanfilePy,
  },
  {
    id: 'conda-environment',
    // Declares BOTH conda and PyPI packages: entries from the nested pip: block
    // carry their own ecosystem, which scan.js honours per dependency.
    ecosystem: 'conda',
    match: p => /^environment\.(yml|yaml)$/.test(basename(p)),
    parse: parseCondaEnvironment,
  },
  {
    id: 'cabal',
    ecosystem: 'hackage',
    match: p => /\.cabal$/.test(basename(p)),
    parse: parseCabal,
  },
  {
    id: 'stack',
    ecosystem: 'hackage',
    match: p => basename(p) === 'stack.yaml',
    parse: parseStackYaml,
  },
  {
    id: 'cpanfile',
    ecosystem: 'cpan',
    match: p => basename(p) === 'cpanfile',
    parse: parseCpanfile,
  },
  {
    id: 'cpm-props',
    support: true,
    match: p => basename(p) === 'Directory.Packages.props',
  },
  {
    id: 'composer-lock',
    support: true,
    match: p => basename(p) === 'composer.lock',
  },
  {
    id: 'swift-resolved',
    support: true,
    match: p => basename(p) === 'Package.resolved',
  },
  {
    id: 'pubspec-lock',
    support: true,
    match: p => basename(p) === 'pubspec.lock',
  },
  {
    id: 'mix-lock',
    support: true,
    match: p => basename(p) === 'mix.lock',
  },
];

// Manifests we recognise but do not parse. Reported per repo so an untracked
// stack shows up as a visible gap in the scan summary rather than as an empty
// table indistinguishable from a repo that genuinely has no dependencies.
const UNTRACKED_HINTS = [
  { label: 'CocoaPods', match: p => basename(p) === 'Podfile' },
  { label: 'Docker', match: p => /^Dockerfile(\..+)?$/.test(basename(p)) },
  { label: 'GitHub Actions', match: p => /(^|\/)\.github\/workflows\/[^/]+\.ya?ml$/.test(p) },
  { label: 'Terraform', match: p => /\.tf$/.test(basename(p)) },
  { label: 'Helm', match: p => basename(p) === 'Chart.yaml' },
  { label: 'R', match: p => basename(p) === 'DESCRIPTION' || basename(p) === 'renv.lock' },
  { label: 'Deno', match: p => /^deno\.jsonc?$/.test(basename(p)) },
  { label: 'Bower', match: p => basename(p) === 'bower.json' },
  { label: 'Julia', match: p => basename(p) === 'Project.toml' },
  { label: 'Nix', match: p => basename(p) === 'flake.nix' },
];

// Directories whose contents are copies of someone else's code. Manifests found
// inside them declare another project's dependencies, so counting them would
// report versions this org does not actually control.
//
// Matched as whole path segments, so a directory merely starting with one of
// these names (vendored-libs/) is not excluded.
const VENDORED_SEGMENTS = new Set([
  'node_modules', 'vendor', 'third_party', 'thirdparty', 'testdata', 'target',
  'bower_components', '.git',
]);

function isVendoredPath(path) {
  return String(path).split('/').some(segment => VENDORED_SEGMENTS.has(segment));
}

// Pairs each repo path with the handler that reads it. A path matching no
// handler is simply absent from the result.
function matchManifests(paths) {
  const matches = [];
  for (const path of paths) {
    if (isVendoredPath(path)) continue;
    const handler = MANIFEST_HANDLERS.find(h => h.match(path));
    if (handler) matches.push({ path, handler });
  }
  return matches;
}

// Labels of untracked ecosystems present in this repo, each reported once
// however many of its files appear.
function detectUntrackedEcosystems(paths) {
  const labels = new Set();
  for (const path of paths) {
    if (isVendoredPath(path)) continue;
    for (const hint of UNTRACKED_HINTS) {
      if (hint.match(path)) labels.add(hint.label);
    }
  }
  return [...labels];
}

const directoryOf = (path) => {
  const index = String(path).lastIndexOf('/');
  return index === -1 ? '' : path.slice(0, index);
};

const join = (directory, filename) => (directory ? `${directory}/${filename}` : filename);

// Gives a parser access to other files from the same repo, for the two manifests
// whose versions legitimately live elsewhere.
//
// `textByPath` holds only the manifests this scan actually fetched, which is why
// the files these helpers look for are themselves declared as `support` handlers
// — otherwise they would never have been downloaded.
//
// A support file that fails to parse yields null rather than propagating: one
// malformed props file should not take down the manifest that referenced it.
function createParseContext(manifestPath, textByPath) {
  const read = (path, transform) => {
    const text = textByPath.get(path);
    if (text === undefined) return null;
    try {
      const parsed = transform(text);
      return parsed === undefined ? null : parsed;
    } catch (_) {
      return null;
    }
  };

  return {
    path: manifestPath,

    // Nearest-first walk from the manifest's own directory to the repo root,
    // matching how MSBuild resolves Directory.Packages.props.
    findUp(filename, transform) {
      let directory = directoryOf(manifestPath);
      while (true) {
        const found = read(join(directory, filename), transform);
        if (found !== null) return found;
        if (!directory) return null;
        directory = directoryOf(directory);
      }
    },

    // Same directory only.
    sibling(filename, transform) {
      return read(join(directoryOf(manifestPath), filename), transform);
    },
  };
}

module.exports = {
  MANIFEST_HANDLERS, UNTRACKED_HINTS, VENDORED_SEGMENTS,
  matchManifests, isVendoredPath, detectUntrackedEcosystems, createParseContext,
};
