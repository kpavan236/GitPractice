'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseConanfileTxt, parseConanfilePy } = require('./parse-conan');

test('reads requires from a conanfile.txt', () => {
  const txt = `
[requires]
zlib/1.2.13
openssl/3.1.4

[generators]
CMakeDeps
`;
  const { dependencies } = parseConanfileTxt(txt);
  assert.deepStrictEqual(dependencies, [
    { name: 'zlib', version: '1.2.13' },
    { name: 'openssl', version: '3.1.4' },
  ]);
});

test('reads tool_requires as well as requires', () => {
  const txt = `
[requires]
zlib/1.2.13

[tool_requires]
cmake/3.27.7
`;
  const { dependencies } = parseConanfileTxt(txt);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['cmake', 'zlib']);
});

test('drops a user/channel suffix from a reference', () => {
  // "zlib/1.2.13@company/stable" names the same package; the user/channel is a
  // distribution detail, not part of the version.
  const { dependencies } = parseConanfileTxt('[requires]\nzlib/1.2.13@company/stable');
  assert.deepStrictEqual(dependencies, [{ name: 'zlib', version: '1.2.13' }]);
});

test('flags a version range as a range', () => {
  const { dependencies } = parseConanfileTxt('[requires]\nzlib/[>=1.2 <2.0]');
  assert.strictEqual(dependencies[0].name, 'zlib');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('ignores non-requires sections', () => {
  const txt = `
[generators]
CMakeToolchain

[options]
zlib/*:shared=True

[layout]
cmake_layout
`;
  const { dependencies } = parseConanfileTxt(txt);
  assert.deepStrictEqual(dependencies, []);
});

test('ignores comments in a conanfile.txt', () => {
  const txt = `
[requires]
# zlib/1.0.0
openssl/3.1.4
`;
  const { dependencies } = parseConanfileTxt(txt);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['openssl']);
});

test('counts a reference with no version as unresolved', () => {
  const { dependencies, unresolvedCount } = parseConanfileTxt('[requires]\nzlib');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads a self.requires call from a conanfile.py', () => {
  const py = `
class MyRecipe(ConanFile):
    def requirements(self):
        self.requires("zlib/1.2.13")
        self.tool_requires("cmake/3.27.7")
`;
  const { dependencies } = parseConanfilePy(py);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['cmake', 'zlib']);
});

test('reads a requires attribute tuple from a conanfile.py', () => {
  const py = 'class MyRecipe(ConanFile):\n    requires = "zlib/1.2.13", "openssl/3.1.4"';
  const { dependencies } = parseConanfilePy(py);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['openssl', 'zlib']);
});

test('ignores a python comment in a conanfile.py', () => {
  const py = '    # self.requires("removed/1.0.0")\n    self.requires("kept/2.0.0")';
  const { dependencies } = parseConanfilePy(py);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['kept']);
});

test('counts an interpolated conanfile.py version as unresolved', () => {
  const py = '    self.requires(f"zlib/{self.zlib_version}")';
  const { dependencies, unresolvedCount } = parseConanfilePy(py);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('returns no dependencies for an empty conanfile', () => {
  assert.deepStrictEqual(parseConanfileTxt(''), { dependencies: [], unresolvedCount: 0 });
  assert.deepStrictEqual(parseConanfilePy(''), { dependencies: [], unresolvedCount: 0 });
});
