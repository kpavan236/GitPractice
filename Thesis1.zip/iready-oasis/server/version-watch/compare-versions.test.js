'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { compareVersions, sameMajor, sameMinor, pickLatest, pickLatestSameMajor, pickLatestSamePatchLine, stripRangePrefix, isPrerelease, isRangeDeclaration } = require('./compare-versions');

test('compareVersions orders numeric segments numerically, not lexicographically', () => {
  assert.ok(compareVersions('2.9.0', '2.10.0') < 0);
  assert.ok(compareVersions('2.10.0', '2.9.0') > 0);
});

test('compareVersions treats equal version strings as equal', () => {
  assert.equal(compareVersions('1.2.3', '1.2.3'), 0);
});

test('compareVersions handles differing segment counts', () => {
  assert.ok(compareVersions('1.2', '1.2.1') < 0);
  assert.ok(compareVersions('1.2.1', '1.2') > 0);
});

test('compareVersions falls back to string comparison for non-numeric segments', () => {
  // Not a real semver precedence implementation — just must not throw and
  // must be consistent (a < b or a > b, not both).
  const a = compareVersions('1.0.0-beta', '1.0.0-rc1');
  const b = compareVersions('1.0.0-rc1', '1.0.0-beta');
  assert.ok(a !== 0);
  assert.equal(Math.sign(a), -Math.sign(b));
});

test('sameMajor compares only the first dot-separated segment', () => {
  assert.equal(sameMajor('2.14.1', '2.99.0'), true);
  assert.equal(sameMajor('2.14.1', '3.0.0'), false);
});

test('stripRangePrefix handles multi-character operators (PEP 440 ~=, ==) without leaving a stray character', () => {
  assert.equal(stripRangePrefix('~=2.5'), '2.5');
  assert.equal(stripRangePrefix('==2.5'), '2.5');
  assert.equal(stripRangePrefix('!=2.5'), '2.5');
  assert.equal(stripRangePrefix('^2.14.1'), '2.14.1');
  assert.equal(stripRangePrefix('>=1.0.0'), '1.0.0');
});

test('sameMajor strips a leading npm range operator before comparing majors', () => {
  // npm's versionInUse is often a declared range (e.g. "^2.14.1"), not an
  // exact version — the leading "^"/"~"/">="/etc. must not defeat the
  // major-segment comparison.
  assert.equal(sameMajor('2.99.0', '^2.14.1'), true);
  assert.equal(sameMajor('3.0.0', '^2.14.1'), false);
  assert.equal(sameMajor('1.5.0', '~1.0.0'), true);
  assert.equal(sameMajor('1.5.0', '>=1.0.0'), true);
});

test('pickLatest returns the highest version from a list', () => {
  assert.equal(pickLatest(['1.0.0', '2.10.0', '2.9.0']), '2.10.0');
});

test('pickLatest returns null for an empty list', () => {
  assert.equal(pickLatest([]), null);
});

test('pickLatestSameMajor returns the highest version sharing versionInUse\'s major, or null if none', () => {
  assert.equal(pickLatestSameMajor(['1.0.0', '2.9.0', '2.10.0', '3.0.0'], '2.0.0'), '2.10.0');
  assert.equal(pickLatestSameMajor(['1.0.0', '3.0.0'], '2.0.0'), null);
});

test('compareVersions ranks a plain numeric segment above the same number with a glued pre-release suffix', () => {
  assert.ok(compareVersions('2.32.0', '2.32.0rc1') > 0);
  assert.ok(compareVersions('6.1.0', '6.1.0-RC1') > 0);
  assert.ok(compareVersions('6.1.0', '6.1.0-M1') > 0);
  assert.ok(compareVersions('4.18.0', '4.18.0-beta.1') > 0);
});

test('pickLatest excludes pre-release versions from the candidate pool when a stable release exists', () => {
  // Real-world case: Spring publishes milestone/RC builds ahead of a stable
  // release. "Latest" must mean the latest STABLE release, not whichever
  // build happens to sort highest by raw version number.
  assert.equal(pickLatest(['6.0.13', '6.1.0-M1', '6.1.0-RC1']), '6.0.13');
  assert.equal(pickLatest(['2.31.0', '2.32.0rc1']), '2.31.0');
});

test('pickLatest excludes PEP 440 short-form pre-releases (a1, b1) and npm release-channel tags', () => {
  assert.equal(pickLatest(['4.1.13', '4.2a1']), '4.1.13');
  assert.equal(pickLatest(['1.25.2', '1.26.0b1']), '1.25.2');
  assert.equal(pickLatestSameMajor(['18.2.0', '18.3.0-canary-abc123'], '^18.2.0'), '18.2.0');
  assert.equal(pickLatestSameMajor(['18.2.0', '18.3.0-next.5'], '^18.2.0'), '18.2.0');
  assert.equal(pickLatestSameMajor(['18.2.0', '18.3.0-nightly'], '^18.2.0'), '18.2.0');
});

test('isPrerelease recognizes PEP 440 short forms, npm channel tags, and Maven milestones', () => {
  assert.equal(isPrerelease('4.2a1'), true);
  assert.equal(isPrerelease('1.26.0b1'), true);
  assert.equal(isPrerelease('18.3.0-canary-abc123'), true);
  assert.equal(isPrerelease('18.3.0-next.5'), true);
  assert.equal(isPrerelease('18.3.0-nightly'), true);
  assert.equal(isPrerelease('18.3.0-experimental-abc'), true);
  assert.equal(isPrerelease('2.32.0rc1'), true);
  assert.equal(isPrerelease('6.1.0-M1'), true);
  assert.equal(isPrerelease('4.18.0-beta.1'), true);
});

test('isPrerelease does not flag stable-release markers or unrelated suffixes', () => {
  assert.equal(isPrerelease('2.32.0'), false);
  assert.equal(isPrerelease('1.0.0-Final'), false);
  assert.equal(isPrerelease('1.0.0-RELEASE'), false);
  assert.equal(isPrerelease('1.0.0-GA'), false);
  assert.equal(isPrerelease('1.0.0.post1'), false);
  // The short-letter check (a1/b1/c1) must require a digit immediately
  // after the letter, or an unrelated suffix like "-alpine" would wrongly
  // match on its leading "a".
  assert.equal(isPrerelease('1.0.0-alpine'), false);
});

test('pickLatest falls back to a pre-release when nothing stable has ever been published', () => {
  assert.equal(pickLatest(['1.0.0-alpha', '1.0.0-beta']), '1.0.0-beta');
});

test('pickLatestSameMajor excludes pre-releases the same way pickLatest does', () => {
  assert.equal(pickLatestSameMajor(['4.17.20', '4.17.21', '4.18.0-beta.1'], '^4.17.20'), '4.17.21');
});

test('sameMinor compares the first two dot-separated segments', () => {
  assert.equal(sameMinor('1.2.3', '1.2.9'), true);
  assert.equal(sameMinor('1.2.3', '1.9.4'), false);
  assert.equal(sameMinor('1.2.3', '2.2.3'), false);
});

test('sameMinor strips a leading range operator before comparing, like sameMajor', () => {
  assert.equal(sameMinor('4.17.21', '^4.17.20'), true);
  assert.equal(sameMinor('4.18.0', '^4.17.20'), false);
  assert.equal(sameMinor('2.5.1', '~=2.5'), true);
});

test('sameMinor treats a missing minor segment as its own line, not a wildcard', () => {
  // A Maven coordinate pinned at a bare major ("4") gives us no minor to
  // match on. Treating that as "any 4.x" would silently relabel a genuine
  // minor jump as a low-risk patch bump, so a bare major only ever matches
  // another bare major.
  assert.equal(sameMinor('4', '4'), true);
  assert.equal(sameMinor('4.1.2', '4'), false);
  assert.equal(sameMinor('4', '4.1.2'), false);
});

test('pickLatestSamePatchLine returns the highest version on versionInUse\'s major.minor line', () => {
  assert.equal(pickLatestSamePatchLine(['1.2.3', '1.2.9', '1.9.4', '3.0.1'], '1.2.3'), '1.2.9');
  assert.equal(pickLatestSamePatchLine(['1.2.3', '1.2.10', '1.2.9'], '1.2.3'), '1.2.10');
});

test('pickLatestSamePatchLine returns null when nothing shares the current minor line', () => {
  assert.equal(pickLatestSamePatchLine(['1.9.4', '3.0.1'], '1.2.3'), null);
  assert.equal(pickLatestSamePatchLine([], '1.2.3'), null);
});

test('pickLatestSamePatchLine excludes pre-releases the same way pickLatest does', () => {
  assert.equal(pickLatestSamePatchLine(['1.2.3', '1.2.4', '1.2.5-beta.1'], '1.2.3'), '1.2.4');
  assert.equal(pickLatestSamePatchLine(['2.32.0', '2.32.1rc1'], '2.32.0'), '2.32.0');
});

test('pickLatestSamePatchLine resolves an npm declared range to its own patch line', () => {
  assert.equal(pickLatestSamePatchLine(['4.17.20', '4.17.21', '4.18.0'], '^4.17.20'), '4.17.21');
});

// ── isRangeDeclaration ──────────────────────────────────────────────────────
// Distinguishes "this repo pins exactly this version" from "this repo accepts
// a range whose floor is this version". The distinction drives the row's
// versionIsRange marker, because a vulnerability finding against a floor is
// not the same claim as one against a resolved build.

test('isRangeDeclaration: a plain version is not a range', () => {
  assert.strictEqual(isRangeDeclaration('1.2.3'), false);
});

test('isRangeDeclaration: a caret declaration is a range', () => {
  assert.strictEqual(isRangeDeclaration('^1.2.3'), true);
});

test('isRangeDeclaration: a tilde declaration is a range', () => {
  assert.strictEqual(isRangeDeclaration('~2.5'), true);
});

test('isRangeDeclaration: a comparison declaration is a range', () => {
  assert.strictEqual(isRangeDeclaration('>=2.28'), true);
});

test('isRangeDeclaration: a PEP 440 exclusion is a range', () => {
  assert.strictEqual(isRangeDeclaration('!=1.0'), true);
});

test('isRangeDeclaration: a PEP 440 double-equals pin is not a range', () => {
  assert.strictEqual(isRangeDeclaration('==2.28.1'), false);
});

test('isRangeDeclaration: a single-equals pin is not a range', () => {
  assert.strictEqual(isRangeDeclaration('=1.0.0'), false);
});

test('isRangeDeclaration: a trailing wildcard is a range', () => {
  assert.strictEqual(isRangeDeclaration('6.0.*'), true);
});

test('isRangeDeclaration: an x wildcard segment is a range', () => {
  assert.strictEqual(isRangeDeclaration('1.x'), true);
});

test('isRangeDeclaration: a comma-joined constraint is a range', () => {
  assert.strictEqual(isRangeDeclaration('>=1.0,<2.0'), true);
});

test('isRangeDeclaration: a space-separated constraint is a range', () => {
  assert.strictEqual(isRangeDeclaration('~> 7.0'), true);
});

test('isRangeDeclaration: a semver prerelease is not a range', () => {
  // "-beta.1" must not be mistaken for a constraint operator.
  assert.strictEqual(isRangeDeclaration('1.0.0-beta.1'), false);
});

test('isRangeDeclaration: an architecture suffix is not a wildcard', () => {
  // The x-wildcard check must not fire on the "x" in "x86".
  assert.strictEqual(isRangeDeclaration('1.0.0-x86'), false);
});

test('isRangeDeclaration: an empty declaration is not a range', () => {
  assert.strictEqual(isRangeDeclaration(''), false);
});
