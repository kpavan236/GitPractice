'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseCondaEnvironment } = require('./parse-conda');

test('reads pinned conda dependencies', () => {
  const yaml = `
name: myenv
channels:
  - conda-forge
dependencies:
  - numpy=1.24.3
  - pandas=2.0.1
`;
  const { dependencies } = parseCondaEnvironment(yaml);
  assert.deepStrictEqual(dependencies, [
    { ecosystem: 'conda', name: 'numpy', version: '1.24.3' },
    { ecosystem: 'conda', name: 'pandas', version: '2.0.1' },
  ]);
});

test('reads a doubly-pinned dependency including its build string', () => {
  // "numpy=1.24.3=py311h..." pins the build too; only the version is tracked.
  const { dependencies } = parseCondaEnvironment('dependencies:\n  - numpy=1.24.3=py311h64a7726_0');
  assert.deepStrictEqual(dependencies, [{ ecosystem: 'conda', name: 'numpy', version: '1.24.3' }]);
});

test('reads a comparison-pinned dependency as a range', () => {
  const { dependencies } = parseCondaEnvironment('dependencies:\n  - numpy>=1.24');
  assert.strictEqual(dependencies[0].name, 'numpy');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('routes the pip section to the pip ecosystem', () => {
  // A pip block inside environment.yml declares PyPI packages, which must be
  // looked up against PyPI and not against a conda channel.
  const yaml = `
dependencies:
  - numpy=1.24.3
  - pip
  - pip:
      - requests==2.31.0
`;
  const { dependencies } = parseCondaEnvironment(yaml);
  const requests = dependencies.find(d => d.name === 'requests');
  assert.strictEqual(requests.ecosystem, 'pip');
  assert.strictEqual(requests.version, '2.31.0');
});

test('skips the python interpreter pin', () => {
  const { dependencies } = parseCondaEnvironment('dependencies:\n  - python=3.11\n  - numpy=1.24.3');
  assert.deepStrictEqual(dependencies.map(d => d.name), ['numpy']);
});

test('counts a dependency with no version as unresolved', () => {
  const { dependencies, unresolvedCount } = parseCondaEnvironment('dependencies:\n  - numpy');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('does not count a bare pip entry as unresolved', () => {
  // "- pip" asks conda to install pip itself so the pip: block can run; it is
  // plumbing, not an unresolved dependency.
  const { unresolvedCount } = parseCondaEnvironment('dependencies:\n  - pip\n  - numpy=1.24.3');
  assert.strictEqual(unresolvedCount, 0);
});

test('ignores the channels block', () => {
  const yaml = `
channels:
  - conda-forge
  - defaults
dependencies:
  - numpy=1.24.3
`;
  const { dependencies } = parseCondaEnvironment(yaml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['numpy']);
});

test('drops a channel prefix from a dependency', () => {
  const { dependencies } = parseCondaEnvironment('dependencies:\n  - conda-forge::numpy=1.24.3');
  assert.deepStrictEqual(dependencies, [{ ecosystem: 'conda', name: 'numpy', version: '1.24.3' }]);
});

test('returns no dependencies for an environment file with none', () => {
  assert.deepStrictEqual(parseCondaEnvironment('name: myenv'), { dependencies: [], unresolvedCount: 0 });
});
