'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseCargoToml } = require('./parse-cargo');

test('reads a plain string dependency declaration', () => {
  const toml = `
[dependencies]
serde = "1.0.188"
`;
  const { dependencies } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies, [
    { name: 'serde', version: '1.0.188', versionIsRange: true },
  ]);
});

test('reads the version out of an inline-table declaration', () => {
  const toml = `
[dependencies]
tokio = { version = "1.35.0", features = ["full"] }
`;
  const { dependencies } = parseCargoToml(toml);
  assert.strictEqual(dependencies[0].name, 'tokio');
  assert.strictEqual(dependencies[0].version, '1.35.0');
});

test('treats a bare version as a range because Cargo reads it as a caret', () => {
  // Cargo interprets "1.0" as "^1.0", so the resolved build may be any 1.x.
  // A vulnerability finding against 1.0 is a statement about the floor.
  const { dependencies } = parseCargoToml('[dependencies]\nserde = "1.0"');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('treats an = prefixed version as an exact pin', () => {
  const { dependencies } = parseCargoToml('[dependencies]\nserde = "=1.0.188"');
  assert.strictEqual(dependencies[0].version, '1.0.188');
  assert.notStrictEqual(dependencies[0].versionIsRange, true);
});

test('includes dev and build dependencies', () => {
  const toml = `
[dependencies]
serde = "1.0"

[dev-dependencies]
criterion = "0.5"

[build-dependencies]
cc = "1.0"
`;
  const { dependencies } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['cc', 'criterion', 'serde']);
});

test('includes target-specific dependencies', () => {
  const toml = `
[target.'cfg(unix)'.dependencies]
nix = "0.27.1"
`;
  const { dependencies } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['nix']);
});

test('counts a git dependency as unresolved because it is not from crates.io', () => {
  const toml = `
[dependencies]
mycrate = { git = "https://github.test/x/mycrate" }
`;
  const { dependencies, unresolvedCount } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a path dependency as unresolved', () => {
  const toml = `
[dependencies]
local = { path = "../local" }
`;
  const { dependencies, unresolvedCount } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a workspace-inherited dependency as unresolved', () => {
  // The version lives in the workspace root's Cargo.toml, which this file
  // does not contain — guessing would be worse than reporting it unresolved.
  const toml = `
[dependencies]
serde = { workspace = true }
`;
  const { dependencies, unresolvedCount } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('uses the renamed package name when a dependency declares package', () => {
  // The key is the local alias; `package` names the actual crate on crates.io.
  const toml = `
[dependencies]
serde_alias = { version = "1.0.188", package = "serde" }
`;
  const { dependencies } = parseCargoToml(toml);
  assert.strictEqual(dependencies[0].name, 'serde');
});

test('ignores the package metadata table', () => {
  const toml = `
[package]
name = "my-crate"
version = "0.1.0"

[dependencies]
serde = "1.0"
`;
  const { dependencies } = parseCargoToml(toml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['serde']);
});

test('returns no dependencies for a manifest with none', () => {
  assert.deepStrictEqual(parseCargoToml('[package]\nname = "x"'), {
    dependencies: [], unresolvedCount: 0,
  });
});