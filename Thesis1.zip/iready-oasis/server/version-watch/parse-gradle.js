'use strict';
const { parseToml } = require('./parse-toml');
const { stripSlashComments } = require('./strip-comments');

function isTable(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

const STRING_LITERAL = /'([^'\\]*(?:\\.[^'\\]*)*)'|"([^"\\]*(?:\\.[^"\\]*)*)"/g;
const COORDINATE_SEGMENT = '[A-Za-z0-9_.\\-]+';
const THREE_PART = new RegExp(`^(${COORDINATE_SEGMENT}):(${COORDINATE_SEGMENT}):(.+)$`);
const TWO_PART = new RegExp(`^(${COORDINATE_SEGMENT}):(${COORDINATE_SEGMENT})$`);

// Parses build.gradle / build.gradle.kts for literal Maven coordinates.
//
// This is the one deliberately lossy parser in the set. Groovy and Kotlin build
// scripts are programs, not data: a version can come from a variable, a parent
// script, an imported BOM, or a version catalog accessor, none of which is
// resolvable from a single file. So only literal coordinates are extracted, and
// everything else is counted in `unresolvedCount` — partial reporting with an
// honest count is worth far more than the zero dependencies a Gradle repo
// reports today.
//
// The whole file is scanned rather than just `dependencies { }` blocks, because
// `buildscript { dependencies { classpath ... } }` declares real artifacts too.
// The version-shaped filter below is what keeps unrelated colon-bearing strings
// out.
//
// Version catalog accessors (`libs.guava`) are ignored WITHOUT counting as
// unresolved: gradle/libs.versions.toml is scanned as its own manifest, so the
// dependency is already reported from there. Counting the reference as well
// would report a fully-resolved dependency as a failure.
function parseGradleBuild(text) {
  const source = stripSlashComments(text);
  const byKey = new Map();
  let unresolvedCount = 0;

  // Map-style declarations are read first, per line, so their individual
  // 'junit'-style literals are not later mistaken for anything else.
  for (const line of source.split(/\r?\n/)) {
    if (!/\bgroup\s*:/.test(line) || !/\bname\s*:/.test(line)) continue;
    const group = line.match(/\bgroup\s*:\s*['"]([^'"]+)['"]/)?.[1];
    const name = line.match(/\bname\s*:\s*['"]([^'"]+)['"]/)?.[1];
    const version = line.match(/\bversion\s*:\s*['"]([^'"]+)['"]/)?.[1];
    if (!group || !name) continue;
    if (!version || version.includes('$')) { unresolvedCount++; continue; }
    byKey.set(`${group}:${name}:${version}`, { name: `${group}:${name}`, version });
  }

  for (const match of source.matchAll(STRING_LITERAL)) {
    const literal = (match[1] ?? match[2] ?? '').trim();
    if (!literal.includes(':')) continue;

    const three = literal.match(THREE_PART);
    if (three) {
      const [, group, artifact, version] = three;
      // "$slf4jVersion" / "${versions.slf4j}" — defined outside this file.
      if (version.includes('$')) { unresolvedCount++; continue; }
      // Requiring a digit is what separates a coordinate from an unrelated
      // colon-bearing string that happens to have three segments.
      if (!/\d/.test(version)) continue;
      byKey.set(`${group}:${artifact}:${version}`, { name: `${group}:${artifact}`, version });
      continue;
    }

    const two = literal.match(TWO_PART);
    // A two-part coordinate takes its version from an imported BOM. The dot
    // requirement on the group is what stops unrelated "a:b" strings from
    // being counted as dependencies we failed to resolve.
    if (two && two[1].includes('.')) unresolvedCount++;
  }

  return { dependencies: [...byKey.values()], unresolvedCount };
}

// Reads a version-string declaration from a catalog library entry. Gradle
// allows a bare string, or a table using `ref` (into [versions]) or the
// `require`/`strictly`/`prefer` richer forms.
function catalogVersion(declaredVersion, versions) {
  if (typeof declaredVersion === 'string') return declaredVersion;
  if (!isTable(declaredVersion)) return null;
  if (typeof declaredVersion.ref === 'string') {
    const resolved = versions[declaredVersion.ref];
    return typeof resolved === 'string' ? resolved : null;
  }
  for (const key of ['require', 'strictly', 'prefer']) {
    if (typeof declaredVersion[key] === 'string') return declaredVersion[key];
  }
  return null;
}

// Parses gradle/libs.versions.toml. Unlike build scripts this IS a data
// format, so a catalog resolves fully — which is why Gradle repos that have
// adopted catalogs report accurately here while their build scripts do not.
//
// [plugins] is skipped: a Gradle plugin id is not the artifact coordinate it
// resolves to, and inferring one from the other would invent dependencies.
function parseVersionCatalog(text) {
  const doc = parseToml(text);
  const versions = isTable(doc.versions) ? doc.versions : {};
  const libraries = isTable(doc.libraries) ? doc.libraries : {};

  const dependencies = [];
  let unresolvedCount = 0;

  for (const declaration of Object.values(libraries)) {
    if (typeof declaration === 'string') {
      const parts = declaration.split(':');
      if (parts.length === 3 && parts.every(Boolean)) {
        dependencies.push({ name: `${parts[0]}:${parts[1]}`, version: parts[2] });
      } else {
        unresolvedCount++;
      }
      continue;
    }
    if (!isTable(declaration)) { unresolvedCount++; continue; }

    const module = typeof declaration.module === 'string'
      ? declaration.module
      : (declaration.group && declaration.name ? `${declaration.group}:${declaration.name}` : null);
    const version = catalogVersion(declaration.version, versions);
    if (!module || !version) { unresolvedCount++; continue; }

    dependencies.push({ name: module, version });
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseGradleBuild, parseVersionCatalog };
