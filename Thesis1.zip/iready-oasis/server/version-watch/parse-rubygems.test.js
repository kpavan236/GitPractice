'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseGemfileLock } = require('./parse-rubygems');

// A representative lockfile: `specs:` holds every resolved gem including the
// transitive closure, `DEPENDENCIES` names only what the Gemfile asked for.
// Intersecting the two is what yields direct gems at exact versions.
const LOCK = `GEM
  remote: https://rubygems.org/
  specs:
    actionpack (7.0.4)
      actionview (= 7.0.4)
      activesupport (= 7.0.4)
    actionview (7.0.4)
      activesupport (= 7.0.4)
    activesupport (7.0.4)
    rack (2.2.6.4)

PLATFORMS
  ruby

DEPENDENCIES
  actionpack
  rack (~> 2.2)

BUNDLED WITH
   2.3.7
`;

test('reports only the gems named in DEPENDENCIES', () => {
  // actionview and activesupport are transitive — including them would make
  // Ruby rows mean something different from every other ecosystem here.
  const { dependencies } = parseGemfileLock(LOCK);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['actionpack', 'rack']);
});

test('takes the exact resolved version from the specs section', () => {
  const { dependencies } = parseGemfileLock(LOCK);
  const rack = dependencies.find(d => d.name === 'rack');
  assert.strictEqual(rack.version, '2.2.6.4');
});

test('reports lockfile versions as exact even when the Gemfile declared a range', () => {
  // `rack (~> 2.2)` in DEPENDENCIES is the declaration; the lockfile resolved
  // it to a single version, so there is no range caveat to carry.
  const { dependencies } = parseGemfileLock(LOCK);
  const rack = dependencies.find(d => d.name === 'rack');
  assert.notStrictEqual(rack.versionIsRange, true);
});

test('counts a git-sourced gem as unresolved', () => {
  // The trailing "!" marks a gem that came from a GIT or PATH source rather
  // than rubygems.org, so there is no registry release to compare against.
  const lock = `GIT
  remote: https://github.test/x/mygem.git
  revision: abc123
  specs:
    mygem (1.0.0)

GEM
  remote: https://rubygems.org/
  specs:
    rack (2.2.6)

DEPENDENCIES
  mygem!
  rack
`;
  const { dependencies, unresolvedCount } = parseGemfileLock(lock);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['rack']);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a declared gem missing from specs as unresolved', () => {
  const lock = `GEM
  remote: https://rubygems.org/
  specs:
    rack (2.2.6)

DEPENDENCIES
  rack
  nowhere-to-be-found
`;
  const { dependencies, unresolvedCount } = parseGemfileLock(lock);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['rack']);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores the BUNDLED WITH version', () => {
  const { dependencies } = parseGemfileLock(LOCK);
  assert.ok(!dependencies.some(d => d.name === '2.3.7'));
});

test('returns no dependencies for a lockfile with no DEPENDENCIES section', () => {
  const lock = `GEM
  remote: https://rubygems.org/
  specs:
    rack (2.2.6)
`;
  assert.deepStrictEqual(parseGemfileLock(lock), { dependencies: [], unresolvedCount: 0 });
});

test('returns no dependencies for an empty lockfile', () => {
  assert.deepStrictEqual(parseGemfileLock(''), { dependencies: [], unresolvedCount: 0 });
});
