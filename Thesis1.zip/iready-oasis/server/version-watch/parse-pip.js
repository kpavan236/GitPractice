'use strict';

// Parses requirements.txt into exact-pinned { name, version } entries only.
// Lines that declare a package but use any operator other than "==" or the
// PEP 440 arbitrary-equality "===" (or no version at all) are skipped and
// counted in `unresolvedCount` — there's no single "version in use" to
// report for a range. Blank lines, comment-only lines, and option lines
// (-r, -e, --hash, etc.) are not dependency declarations at all, so they're
// silently ignored, not counted.
function parseRequirementsTxt(text) {
  const dependencies = [];
  let unresolvedCount = 0;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.replace(/#.*$/, '').trim();
    if (!line) continue;
    if (line.startsWith('-')) continue;

    const pinMatch = line.match(/^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*={2,3}\s*([^\s;]+)/);
    if (pinMatch) {
      dependencies.push({ name: pinMatch[1], version: pinMatch[3] });
      continue;
    }
    unresolvedCount++;
  }

  return { dependencies, unresolvedCount };
}

module.exports = { parseRequirementsTxt };
