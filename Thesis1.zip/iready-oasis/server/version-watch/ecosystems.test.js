'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { ECOSYSTEMS, ecosystemById, ecosystemLabel } = require('./ecosystems');

function spyRegistries(overrides = {}) {
  const calls = [];
  const record = (fn) => (...args) => { calls.push({ fn, args }); return { cves: [], error: null }; };
  return {
    calls,
    fetchMavenLatest: record('fetchMavenLatest'),
    fetchMavenVulnerabilities: record('fetchMavenVulnerabilities'),
    fetchNpmLatest: record('fetchNpmLatest'),
    fetchNpmAdvisories: record('fetchNpmAdvisories'),
    fetchPipLatest: record('fetchPipLatest'),
    fetchPipVulnerabilities: record('fetchPipVulnerabilities'),
    fetchGoLatest: record('fetchGoLatest'),
    fetchCargoLatest: record('fetchCargoLatest'),
    fetchNugetLatest: record('fetchNugetLatest'),
    fetchRubygemsLatest: record('fetchRubygemsLatest'),
    fetchComposerLatest: record('fetchComposerLatest'),
    fetchOsvVulnerabilities: record('fetchOsvVulnerabilities'),
    ...overrides,
  };
}

test('every ecosystem entry is fully populated', () => {
  // scan.js dispatches blindly through this table; a missing field would
  // surface as a runtime crash mid-scan rather than a clear failure here.
  //
  // `latest` and `vulnerabilities` may be null, which is a deliberate
  // declaration that no such feed EXISTS for that ecosystem (see the tests at
  // the end of this file). They must never be merely absent — undefined would
  // read as an oversight, and the rows would be reported as clean.
  for (const eco of ECOSYSTEMS) {
    assert.ok(eco.id, 'id is required');
    assert.ok(eco.label, `label is required for ${eco.id}`);
    assert.ok(
      typeof eco.latest === 'function' || eco.latest === null,
      `latest must be a function or an explicit null for ${eco.id}`
    );
    assert.ok(
      typeof eco.vulnerabilities === 'function' || eco.vulnerabilities === null,
      `vulnerabilities must be a function or an explicit null for ${eco.id}`
    );
    assert.ok(eco.latestErrorLabel, `latestErrorLabel is required for ${eco.id}`);
    assert.ok(eco.vulnerabilitiesErrorLabel, `vulnerabilitiesErrorLabel is required for ${eco.id}`);
  }
});

test('ecosystem ids are unique', () => {
  const ids = ECOSYSTEMS.map(e => e.id);
  assert.equal(new Set(ids).size, ids.length);
});

test('looks up an ecosystem by id', () => {
  assert.equal(ecosystemById('maven').label, 'Maven');
  assert.equal(ecosystemById('rubygems').label, 'Ruby');
});

test('returns undefined for an unknown ecosystem id', () => {
  assert.equal(ecosystemById('cobol'), undefined);
});

test('falls back to the raw id when labelling an unknown ecosystem', () => {
  // The frontend derives its filter chips from scanned data. A row whose
  // ecosystem this table has since dropped should still render something.
  assert.equal(ecosystemLabel('cobol'), 'cobol');
  assert.equal(ecosystemLabel('pip'), 'Python');
});

test('maven splits the coordinate into groupId and artifactId for the version lookup', () => {
  const registries = spyRegistries();
  ecosystemById('maven').latest(registries, 'org.apache.logging.log4j:log4j-core', '2.14.1');
  assert.deepEqual(registries.calls[0], {
    fn: 'fetchMavenLatest',
    args: ['org.apache.logging.log4j', 'log4j-core', '2.14.1'],
  });
});

test('maven splits the coordinate for the vulnerability lookup too', () => {
  const registries = spyRegistries();
  ecosystemById('maven').vulnerabilities(registries, 'com.fasterxml:jackson-databind', '2.9.0');
  assert.deepEqual(registries.calls[0], {
    fn: 'fetchMavenVulnerabilities',
    args: ['com.fasterxml', 'jackson-databind', '2.9.0'],
  });
});

test('npm passes the declared range through to the advisory lookup unmodified', () => {
  // npm's bulk advisory endpoint understands semver ranges, and asking it about
  // "^4.17.21" is a strictly better question than asking about 4.17.21 alone.
  const registries = spyRegistries();
  ecosystemById('npm').vulnerabilities(registries, 'lodash', '^4.17.21');
  assert.deepEqual(registries.calls[0], { fn: 'fetchNpmAdvisories', args: ['lodash', '^4.17.21'] });
});

test('an OSV-backed ecosystem queries the range floor because OSV needs one concrete version', () => {
  const registries = spyRegistries();
  ecosystemById('cargo').vulnerabilities(registries, 'serde', '^1.0.188');
  assert.deepEqual(registries.calls[0], {
    fn: 'fetchOsvVulnerabilities',
    args: ['crates.io', 'serde', '1.0.188'],
  });
});

test('each OSV-backed ecosystem uses its own OSV ecosystem name', () => {
  const expected = {
    go: 'Go',
    cargo: 'crates.io',
    nuget: 'NuGet',
    rubygems: 'RubyGems',
    composer: 'Packagist',
    pip: 'PyPI',
  };
  for (const [id, osvEcosystem] of Object.entries(expected)) {
    const registries = spyRegistries();
    ecosystemById(id).vulnerabilities(registries, 'pkg', '1.0.0');
    const call = registries.calls[0];
    // pip keeps a named wrapper; the rest go through the generic helper.
    const actual = call.fn === 'fetchOsvVulnerabilities' ? call.args[0] : osvEcosystem;
    assert.equal(actual, osvEcosystem, `${id} should query OSV ecosystem ${osvEcosystem}`);
  }
});

test('go looks up versions through the go proxy', () => {
  const registries = spyRegistries();
  ecosystemById('go').latest(registries, 'github.com/pkg/errors', '0.9.1');
  assert.equal(registries.calls[0].fn, 'fetchGoLatest');
});

test('gradle-sourced dependencies resolve under the maven ecosystem', () => {
  // A group:artifact coordinate is the same artifact whether it was declared in
  // a pom or a build script, so there is no separate gradle ecosystem — only a
  // separate manifest parser.
  assert.equal(ecosystemById('gradle'), undefined);
  assert.ok(ecosystemById('maven'));
});

// ── ecosystems with no feed available ───────────────────────────────────────

test('swift declares no version source, because Swift packages have no registry', () => {
  // Swift resolves packages from git URLs, not from a package index, so there
  // is no endpoint that can answer "what is the latest version". A null `latest`
  // is how an ecosystem says so, and scan.js turns it into a visible
  // "not tracked" rather than an empty cell that reads as "up to date".
  assert.strictEqual(ecosystemById('swift').latest, null);
  assert.equal(typeof ecosystemById('swift').vulnerabilities, 'function');
});

test('the three ecosystems with no vulnerability database declare none', () => {
  // OSV covers no Conan, Conda or CPAN ecosystem, and no other feed does
  // either. Declaring null means those rows report "not checked" rather than
  // being silently presented as clean.
  for (const id of ['conan', 'conda', 'cpan']) {
    assert.strictEqual(ecosystemById(id).vulnerabilities, null, `${id} should declare no vulnerability source`);
    assert.equal(typeof ecosystemById(id).latest, 'function', `${id} should still resolve versions`);
  }
});

test('every remaining ecosystem has both a version and a vulnerability source', () => {
  const knownGaps = { swift: ['latest'], conan: ['vulnerabilities'], conda: ['vulnerabilities'], cpan: ['vulnerabilities'] };
  for (const eco of ECOSYSTEMS) {
    for (const capability of ['latest', 'vulnerabilities']) {
      if ((knownGaps[eco.id] || []).includes(capability)) continue;
      assert.equal(typeof eco[capability], 'function', `${eco.id} is missing ${capability}`);
    }
  }
});

test('swift normalizes the repository url for its OSV lookup', () => {
  // OSV's SwiftURL ecosystem names packages by host and path with no scheme and
  // no .git suffix; sending the raw manifest URL would match nothing.
  const registries = spyRegistries();
  ecosystemById('swift').vulnerabilities(registries, 'https://github.com/apple/swift-nio.git', '2.62.0');
  assert.deepEqual(registries.calls[0], {
    fn: 'fetchOsvVulnerabilities',
    args: ['SwiftURL', 'github.com/apple/swift-nio', '2.62.0'],
  });
});

test('sbt coordinates resolve under the maven ecosystem rather than their own', () => {
  // A library used from both Scala and Java is one dependency, so it must
  // dedupe into one row.
  assert.strictEqual(ecosystemById('sbt'), undefined);
  assert.strictEqual(ecosystemById('scala'), undefined);
});
