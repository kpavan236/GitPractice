'use strict';
const { parseYaml } = require('./parse-yaml');
const { isRangeDeclaration } = require('./compare-versions');

function isMap(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

// Parses pubspec.yaml's `dependencies` and `dev_dependencies`.
//
// `ctx.lockVersions`, read from a sibling pubspec.lock, replaces a declared
// constraint with the version actually resolved.
//
// The `environment` block is never read: its `sdk` entry constrains the Dart
// toolchain, not a package on pub.dev.
function parsePubspec(text, ctx = {}) {
  const lockVersions = ctx.lockVersions || {};
  const doc = parseYaml(text);

  const dependencies = [];
  let unresolvedCount = 0;

  for (const key of ['dependencies', 'dev_dependencies']) {
    const table = doc[key];
    if (!isMap(table)) continue;

    for (const [name, declaration] of Object.entries(table)) {
      const locked = lockVersions[name];
      if (locked) { dependencies.push({ name, version: locked }); continue; }

      let constraint = null;
      if (typeof declaration === 'string') {
        constraint = declaration;
      } else if (isMap(declaration)) {
        // `sdk: flutter` resolves against the installed SDK rather than pub.dev,
        // so it is not a tracked package at all — skipped without counting, the
        // same treatment platform requirements get elsewhere.
        if (declaration.sdk !== undefined) continue;
        if (declaration.git !== undefined || declaration.path !== undefined) { unresolvedCount++; continue; }
        constraint = typeof declaration.version === 'string' ? declaration.version : null;
      }

      // A dependency declared with no constraint ("http:" and nothing else), or
      // one whose constraint carries no version at all ("any").
      if (!constraint || !/\d/.test(constraint)) { unresolvedCount++; continue; }

      dependencies.push(
        isRangeDeclaration(constraint) ? { name, version: constraint, versionIsRange: true } : { name, version: constraint }
      );
    }
  }

  return { dependencies, unresolvedCount };
}

// Reads pubspec.lock into { packageName: exactVersion }, keeping only packages
// resolved from a hosted registry. A git- or path-sourced package has no pub.dev
// release its version could be compared against.
function parsePubspecLock(text) {
  const doc = parseYaml(text);
  const packages = doc.packages;
  if (!isMap(packages)) return {};

  const versions = {};
  for (const [name, entry] of Object.entries(packages)) {
    if (!isMap(entry)) continue;
    if (entry.source !== 'hosted') continue;
    if (typeof entry.version === 'string') versions[name] = entry.version;
  }
  return versions;
}

module.exports = { parsePubspec, parsePubspecLock };
