'use strict';
const { isRangeDeclaration } = require('./compare-versions');

// Reads an MSBuild attribute value, case-insensitively — MSBuild itself treats
// attribute names case-insensitively even though the conventional spelling is
// PascalCase.
function attr(attrsText, name) {
  const m = attrsText.match(new RegExp(`\\b${name}\\s*=\\s*"([^"]*)"`, 'i'));
  return m ? m[1].trim() : null;
}

function stripComments(xmlText) {
  return String(xmlText).replace(/<!--[\s\S]*?-->/g, '');
}

// Turns a raw NuGet version string into either an entry or a reason to count
// it unresolved.
//
// NuGet's version notation has two forms this must handle: interval syntax,
// where "[13.0.3]" pins exactly one version while "[6.0,7.0)" is a genuine
// range, and floating versions like "6.0.*". An unexpanded MSBuild property
// ("$(FooVersion)") is defined elsewhere in the build and is reported
// unresolved rather than guessed at.
function nugetEntry(name, rawVersion) {
  const raw = String(rawVersion || '').trim();
  if (!raw || raw.startsWith('$(')) return null;
  // A bracketed interval with no comma names a single version.
  const exactInterval = raw.match(/^\[([^,[\])]+)\]$/);
  if (exactInterval) return { name, version: exactInterval[1].trim() };
  if (!/\d/.test(raw)) return null;
  return isRangeDeclaration(raw)
    ? { name, version: raw, versionIsRange: true }
    : { name, version: raw };
}

// Parses a .csproj/.fsproj/.vbproj's <PackageReference> items.
//
// `ctx.packageVersions` carries the <PackageVersion> entries from the nearest
// Directory.Packages.props, which is how Central Package Management works:
// under CPM the project file names the package and the props file holds the
// version. Without that join every dependency in a CPM repo would report as
// unresolved, which is most modern .NET repos.
function parseCsproj(text, ctx = {}) {
  const packageVersions = ctx.packageVersions || {};
  const dependencies = [];
  let unresolvedCount = 0;

  const itemRe = /<PackageReference\b([^>]*?)(\/>|>([\s\S]*?)<\/PackageReference>)/gi;
  for (const match of stripComments(text).matchAll(itemRe)) {
    const attrs = match[1] || '';
    const inner = match[3] || '';
    // `Update` rather than `Include` appears when a CPM project adjusts an
    // inherited reference; either way it names the package.
    const name = attr(attrs, 'Include') || attr(attrs, 'Update');
    if (!name) { unresolvedCount++; continue; }

    const childVersion = inner.match(/<Version>([^<]+)<\/Version>/i)?.[1]?.trim() || null;
    const declared = attr(attrs, 'VersionOverride')
      || attr(attrs, 'Version')
      || childVersion
      || packageVersions[name]
      || null;

    const entry = declared ? nugetEntry(name, declared) : null;
    if (!entry) { unresolvedCount++; continue; }
    dependencies.push(entry);
  }

  return { dependencies, unresolvedCount };
}

// Parses the pre-SDK-style packages.config, still present in older .NET repos.
function parsePackagesConfig(text) {
  const dependencies = [];
  let unresolvedCount = 0;
  for (const match of stripComments(text).matchAll(/<package\b([^>]*?)\/?>/gi)) {
    const attrs = match[1] || '';
    const name = attr(attrs, 'id');
    const entry = name ? nugetEntry(name, attr(attrs, 'version')) : null;
    if (!entry) { unresolvedCount++; continue; }
    dependencies.push(entry);
  }
  return { dependencies, unresolvedCount };
}

// Reads Directory.Packages.props into a { packageName: version } map for the
// CPM join above. Declares no dependencies of its own — under CPM this file
// pins versions for packages the project files reference.
function parseDirectoryPackagesProps(text) {
  const versions = {};
  for (const match of stripComments(text).matchAll(/<PackageVersion\b([^>]*?)\/?>/gi)) {
    const attrs = match[1] || '';
    const name = attr(attrs, 'Include') || attr(attrs, 'Update');
    const version = attr(attrs, 'Version');
    if (name && version) versions[name] = version;
  }
  return versions;
}

module.exports = { parseCsproj, parsePackagesConfig, parseDirectoryPackagesProps };
