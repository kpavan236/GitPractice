'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parsePubspec, parsePubspecLock } = require('./parse-dart');

test('reads dependencies and dev_dependencies', () => {
  const yaml = `
name: my_app
dependencies:
  http: ^1.1.0
dev_dependencies:
  test: ^1.24.0
`;
  const { dependencies } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['http', 'test']);
});

test('flags a caret constraint as a range', () => {
  const { dependencies } = parsePubspec('dependencies:\n  http: ^1.1.0');
  assert.deepStrictEqual(dependencies, [{ name: 'http', version: '^1.1.0', versionIsRange: true }]);
});

test('treats a bare version as an exact pin', () => {
  // Unlike Cargo, pub reads "6.0.5" as exactly that version.
  const { dependencies } = parsePubspec('dependencies:\n  provider: 6.0.5');
  assert.deepStrictEqual(dependencies, [{ name: 'provider', version: '6.0.5' }]);
});

test('skips the flutter and dart sdk pseudo-dependencies', () => {
  // These resolve against the installed SDK, not against pub.dev.
  const yaml = `
dependencies:
  flutter:
    sdk: flutter
  http: ^1.1.0
`;
  const { dependencies } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['http']);
});

test('counts a git dependency as unresolved', () => {
  const yaml = `
dependencies:
  mylib:
    git:
      url: https://github.test/x/mylib.git
`;
  const { dependencies, unresolvedCount } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a path dependency as unresolved', () => {
  const yaml = `
dependencies:
  sibling:
    path: ../sibling
`;
  const { unresolvedCount } = parsePubspec(yaml);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads the version out of a hosted dependency block', () => {
  const yaml = `
dependencies:
  mylib:
    hosted: https://pub.internal.test
    version: ^2.0.0
`;
  const { dependencies } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies, [{ name: 'mylib', version: '^2.0.0', versionIsRange: true }]);
});

test('counts a dependency declared with no constraint as unresolved', () => {
  const yaml = `
dependencies:
  http:
  provider: 6.0.5
`;
  const { dependencies, unresolvedCount } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['provider']);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores the environment block', () => {
  // "sdk: '>=3.0.0 <4.0.0'" is a Dart SDK constraint, not a package.
  const yaml = `
environment:
  sdk: ">=3.0.0 <4.0.0"
dependencies:
  http: ^1.1.0
`;
  const { dependencies } = parsePubspec(yaml);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['http']);
});

test('prefers the exact version from pubspec.lock', () => {
  const { dependencies } = parsePubspec('dependencies:\n  http: ^1.1.0', {
    lockVersions: { http: '1.1.2' },
  });
  assert.deepStrictEqual(dependencies, [{ name: 'http', version: '1.1.2' }]);
});

test('reads hosted package versions out of pubspec.lock', () => {
  const lock = `
packages:
  http:
    dependency: "direct main"
    description:
      name: http
    source: hosted
    version: "1.1.2"
`;
  assert.deepStrictEqual(parsePubspecLock(lock), { http: '1.1.2' });
});

test('ignores a pubspec.lock entry that is not hosted', () => {
  // A git- or path-sourced package has no pub.dev release to compare against.
  const lock = `
packages:
  mylib:
    source: git
    version: "0.0.0"
`;
  assert.deepStrictEqual(parsePubspecLock(lock), {});
});

test('returns no dependencies for a pubspec with none', () => {
  assert.deepStrictEqual(parsePubspec('name: my_app'), { dependencies: [], unresolvedCount: 0 });
});
