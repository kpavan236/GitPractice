'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parsePomXml } = require('./parse-maven');

test('parses a direct dependency with a literal version', () => {
  const xml = `
    <project>
      <dependencies>
        <dependency>
          <groupId>org.apache.logging.log4j</groupId>
          <artifactId>log4j-core</artifactId>
          <version>2.14.1</version>
        </dependency>
      </dependencies>
    </project>`;
  const { dependencies, unresolvedCount } = parsePomXml(xml);
  assert.deepEqual(dependencies, [
    { groupId: 'org.apache.logging.log4j', artifactId: 'log4j-core', version: '2.14.1' },
  ]);
  assert.equal(unresolvedCount, 0);
});

test('resolves a version from an in-file <properties> placeholder', () => {
  const xml = `
    <project>
      <properties>
        <log4j.version>2.17.0</log4j.version>
      </properties>
      <dependencies>
        <dependency>
          <groupId>org.apache.logging.log4j</groupId>
          <artifactId>log4j-core</artifactId>
          <version>\${log4j.version}</version>
        </dependency>
      </dependencies>
    </project>`;
  const { dependencies, unresolvedCount } = parsePomXml(xml);
  assert.deepEqual(dependencies, [
    { groupId: 'org.apache.logging.log4j', artifactId: 'log4j-core', version: '2.17.0' },
  ]);
  assert.equal(unresolvedCount, 0);
});

test('resolves a property whose own value is another placeholder', () => {
  const xml = `
    <project>
      <properties>
        <shared.version>\${outer.version}</shared.version>
        <outer.version>3.1.0</outer.version>
      </properties>
      <dependencies>
        <dependency>
          <groupId>com.example</groupId>
          <artifactId>shared-lib</artifactId>
          <version>\${shared.version}</version>
        </dependency>
      </dependencies>
    </project>`;
  const { dependencies } = parsePomXml(xml);
  assert.deepEqual(dependencies, [
    { groupId: 'com.example', artifactId: 'shared-lib', version: '3.1.0' },
  ]);
});

test('skips a version placeholder that cannot be resolved locally', () => {
  const xml = `
    <project>
      <dependencies>
        <dependency>
          <groupId>com.example</groupId>
          <artifactId>some-lib</artifactId>
          <version>\${some-lib.version}</version>
        </dependency>
      </dependencies>
    </project>`;
  const { dependencies, unresolvedCount } = parsePomXml(xml);
  assert.deepEqual(dependencies, []);
  assert.equal(unresolvedCount, 1);
});

test('excludes dependencyManagement entries (BOM imports are not "in use")', () => {
  const xml = `
    <project>
      <dependencyManagement>
        <dependencies>
          <dependency>
            <groupId>com.example</groupId>
            <artifactId>bom-only</artifactId>
            <version>1.0.0</version>
          </dependency>
        </dependencies>
      </dependencyManagement>
      <dependencies>
        <dependency>
          <groupId>com.example</groupId>
          <artifactId>real-dep</artifactId>
          <version>2.0.0</version>
        </dependency>
      </dependencies>
    </project>`;
  const { dependencies } = parsePomXml(xml);
  assert.deepEqual(dependencies, [
    { groupId: 'com.example', artifactId: 'real-dep', version: '2.0.0' },
  ]);
});

test('ignores a dependency that is commented out in XML', () => {
  const xml = `
    <project>
      <dependencies>
        <dependency>
          <groupId>com.example</groupId>
          <artifactId>real-dep</artifactId>
          <version>2.0.0</version>
        </dependency>
        <!--
        <dependency>
          <groupId>com.example</groupId>
          <artifactId>commented-out</artifactId>
          <version>9.9.9</version>
        </dependency>
        -->
      </dependencies>
    </project>`;
  const { dependencies, unresolvedCount } = parsePomXml(xml);
  assert.deepEqual(dependencies, [
    { groupId: 'com.example', artifactId: 'real-dep', version: '2.0.0' },
  ]);
  assert.equal(unresolvedCount, 0);
});

test('returns no dependencies for a pom.xml with no <dependencies> block', () => {
  const xml = `<project><groupId>com.example</groupId></project>`;
  const { dependencies, unresolvedCount } = parsePomXml(xml);
  assert.deepEqual(dependencies, []);
  assert.equal(unresolvedCount, 0);
});
