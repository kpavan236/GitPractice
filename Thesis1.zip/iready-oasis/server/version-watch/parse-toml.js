'use strict';

// A deliberately partial TOML reader, sized for one job: reading dependency
// declarations out of pyproject.toml, Cargo.toml, Pipfile, and Gradle version
// catalogs.
//
// Written rather than taken from npm because this app ships as a signed
// Electron bundle — adding a runtime dependency there carries review and
// supply-chain cost out of proportion to reading `name = "version"` pairs.
//
// Deliberately out of scope: numeric/boolean/date typing (every scalar comes
// back as a string, which is all a version comparison needs), multi-line
// basic strings, and full escape sequences beyond the backslash pairs that
// appear in real manifests. Malformed lines are skipped rather than thrown on,
// because a manifest we only partly understand should still yield the
// dependencies we *do* understand — scan.js treats a throw as total failure
// for the whole file.

// Walks the line tracking quote state so a `#` inside a string (a URL
// fragment, say) is not mistaken for the start of a comment.
function stripComment(line) {
  let quote = null;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quote) {
      // Escapes only apply inside basic strings; literal strings are verbatim.
      if (quote === '"' && ch === '\\') { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '#') return line.slice(0, i);
  }
  return line;
}

// Net bracket/brace depth contributed by a line, ignoring anything inside
// strings. Used to keep consuming lines until a value's brackets balance,
// which is how multi-line arrays and inline tables are joined into one
// logical line before parsing.
function depthDelta(text) {
  let depth = 0;
  let quote = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (quote === '"' && ch === '\\') { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '[' || ch === '{') depth++;
    else if (ch === ']' || ch === '}') depth--;
  }
  return depth;
}

// Splits on `delimiter` only at nesting depth zero and outside strings, so
// the commas inside `features = ["a", "b"]` don't split the enclosing inline
// table.
function splitTopLevel(text, delimiter) {
  const parts = [];
  let current = '';
  let depth = 0;
  let quote = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      current += ch;
      if (quote === '"' && ch === '\\') { current += text[++i] ?? ''; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; current += ch; continue; }
    if (ch === '[' || ch === '{') depth++;
    else if (ch === ']' || ch === '}') depth--;
    if (ch === delimiter && depth === 0) { parts.push(current); current = ''; continue; }
    current += ch;
  }
  parts.push(current);
  return parts.map(p => p.trim()).filter(p => p !== '');
}

function unquote(text) {
  if (text.length >= 2 && text[0] === "'" && text[text.length - 1] === "'") {
    // Literal strings are verbatim — no escape processing at all.
    return text.slice(1, -1);
  }
  if (text.length >= 2 && text[0] === '"' && text[text.length - 1] === '"') {
    return text.slice(1, -1).replace(/\\(.)/g, (_, c) => {
      const named = { n: '\n', t: '\t', r: '\r' };
      return named[c] ?? c;
    });
  }
  return text;
}

function parseValue(raw) {
  const text = raw.trim();
  if (text.startsWith('[') && text.endsWith(']')) {
    return splitTopLevel(text.slice(1, -1), ',').map(parseValue);
  }
  if (text.startsWith('{') && text.endsWith('}')) {
    const table = {};
    for (const pair of splitTopLevel(text.slice(1, -1), ',')) {
      const eq = indexOfTopLevelEquals(pair);
      if (eq === -1) continue;
      assignPath(table, splitKeyPath(pair.slice(0, eq)), parseValue(pair.slice(eq + 1)));
    }
    return table;
  }
  return unquote(text);
}

// Finds the `=` separating key from value, skipping any that sit inside a
// quoted key or nested value.
function indexOfTopLevelEquals(text) {
  let depth = 0;
  let quote = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (quote === '"' && ch === '\\') { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '[' || ch === '{') depth++;
    else if (ch === ']' || ch === '}') depth--;
    else if (ch === '=' && depth === 0) return i;
  }
  return -1;
}

// Splits a key on unquoted dots. A quoted segment keeps its dots as part of
// the key itself — essential for Gradle catalogs and Maven-style coordinates,
// where `"com.fasterxml.jackson"` is one key, not three levels of nesting.
function splitKeyPath(key) {
  return splitTopLevel(key.trim(), '.').map(unquote).filter(seg => seg !== '');
}

function assignPath(root, path, value) {
  if (!path.length) return;
  let node = root;
  for (const segment of path.slice(0, -1)) {
    // A non-object already sitting at this segment would be overwritten by
    // descending into it; replacing it keeps the later declaration, matching
    // how the rest of this reader treats redefinition.
    if (typeof node[segment] !== 'object' || node[segment] === null || Array.isArray(node[segment])) {
      node[segment] = {};
    }
    node = node[segment];
  }
  node[path[path.length - 1]] = value;
}

// Resolves (creating as needed) the container a `[table]` header names.
function tableAt(root, path) {
  let node = root;
  for (const segment of path) {
    if (Array.isArray(node[segment])) {
      // Descending through an array-of-tables header targets its last entry,
      // which is where subsequent key/value lines belong.
      node = node[segment][node[segment].length - 1];
      continue;
    }
    if (typeof node[segment] !== 'object' || node[segment] === null) node[segment] = {};
    node = node[segment];
  }
  return node;
}

// Joins physical lines into logical ones, so a value whose brackets span
// several lines arrives at the parser in one piece.
function logicalLines(text) {
  const lines = [];
  let buffer = null;
  let depth = 0;
  for (const rawLine of String(text).split(/\r?\n/)) {
    const line = stripComment(rawLine);
    if (buffer === null) {
      if (!line.trim()) continue;
      buffer = line.trim();
      depth = depthDelta(line);
      // A table header's own brackets balance on its first line, so this only
      // keeps reading for genuinely unbalanced values.
      if (depth <= 0) { lines.push(buffer); buffer = null; depth = 0; }
      continue;
    }
    buffer += ' ' + line.trim();
    depth += depthDelta(line);
    if (depth <= 0) { lines.push(buffer); buffer = null; depth = 0; }
  }
  // Unterminated value at EOF — take what we have rather than dropping it.
  if (buffer !== null) lines.push(buffer);
  return lines;
}

function parseToml(text) {
  const root = {};
  let currentPath = [];

  for (const line of logicalLines(text)) {
    const arrayHeader = line.match(/^\[\[(.+?)\]\]$/);
    if (arrayHeader) {
      const path = splitKeyPath(arrayHeader[1]);
      const parent = tableAt(root, path.slice(0, -1));
      const key = path[path.length - 1];
      if (!Array.isArray(parent[key])) parent[key] = [];
      parent[key].push({});
      currentPath = path;
      continue;
    }

    const tableHeader = line.match(/^\[(.+?)\]$/);
    if (tableHeader) {
      currentPath = splitKeyPath(tableHeader[1]);
      tableAt(root, currentPath);
      continue;
    }

    const eq = indexOfTopLevelEquals(line);
    if (eq === -1) continue;   // not a declaration — skip, don't throw
    const keyPath = splitKeyPath(line.slice(0, eq));
    if (!keyPath.length) continue;
    assignPath(tableAt(root, currentPath), keyPath, parseValue(line.slice(eq + 1)));
  }

  return root;
}

module.exports = { parseToml };