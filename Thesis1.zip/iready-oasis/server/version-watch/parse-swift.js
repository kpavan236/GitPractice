'use strict';
const { stripSlashComments } = require('./strip-comments');

// Reads the balanced argument list of each `.package(...)` call. A regex cannot
// do this alone because the requirement forms nest their own parentheses
// (`.upToNextMajor(from: "1.0.0")`).
function packageCalls(source) {
  const calls = [];
  const marker = '.package(';
  let index = source.indexOf(marker);
  while (index !== -1) {
    let depth = 0;
    let end = index + marker.length - 1;
    let quote = null;
    for (let i = index + marker.length - 1; i < source.length; i++) {
      const ch = source[i];
      if (quote) {
        if (ch === '\\') { i++; continue; }
        if (ch === quote) quote = null;
        continue;
      }
      if (ch === '"') { quote = ch; continue; }
      if (ch === '(') depth++;
      else if (ch === ')') {
        depth--;
        if (depth === 0) { end = i; break; }
      }
    }
    calls.push(source.slice(index + marker.length, end));
    index = source.indexOf(marker, end + 1);
  }
  return calls;
}

// Parses Package.swift's dependency declarations.
//
// Swift packages are identified by their repository URL rather than by a
// registry name, which is also how OSV addresses them (its `SwiftURL`
// ecosystem). The URL is therefore the row's package identity.
//
// `ctx.pinsVersions`, read from a sibling Package.resolved, replaces the
// declared lower bound with the version actually resolved — both more accurate
// and free of the range caveat.
function parseSwiftPackage(text, ctx = {}) {
  const pinsVersions = ctx.pinsVersions || {};
  const source = stripSlashComments(text);

  const dependencies = [];
  let unresolvedCount = 0;

  for (const args of packageCalls(source)) {
    const url = args.match(/\burl\s*:\s*"([^"]+)"/)?.[1] || null;
    // A path dependency is local code with no release to compare against.
    if (!url) { unresolvedCount++; continue; }

    const pinned = pinsVersions[url];
    if (pinned) { dependencies.push({ name: url, version: pinned }); continue; }

    // A branch or a revision is not a release, so there is no version to track.
    if (/\b(branch|revision)\s*:/.test(args)) { unresolvedCount++; continue; }

    const exact = args.match(/\bexact\s*:\s*"([^"]+)"/)?.[1];
    if (exact) { dependencies.push({ name: url, version: exact }); continue; }

    // Every remaining form is a range; all that can be reported is its floor.
    // `from:` covers both the bare form and .upToNextMajor/.upToNextMinor,
    // while the "a"..<"b" operator form needs its own match.
    const floor = args.match(/\bfrom\s*:\s*"([^"]+)"/)?.[1]
      || args.match(/"([^"]+)"\s*\.\.[.<]\s*"[^"]+"/)?.[1];
    if (!floor) { unresolvedCount++; continue; }

    dependencies.push({ name: url, version: floor, versionIsRange: true });
  }

  return { dependencies, unresolvedCount };
}

// Reads Package.resolved into { repositoryUrl: exactVersion }.
//
// Two formats are in the wild: v1 nests the pin list under `object.pins` and
// names the URL `repositoryURL`, while v2+ puts `pins` at the top level and
// names it `location`. Both are read, since a repo's checked-in file may predate
// the current toolchain.
function parsePackageResolved(text) {
  const resolved = JSON.parse(text);
  const pins = Array.isArray(resolved.pins) ? resolved.pins
    : (Array.isArray(resolved.object?.pins) ? resolved.object.pins : []);

  const versions = {};
  for (const pin of pins) {
    const url = pin?.location || pin?.repositoryURL;
    const version = pin?.state?.version;
    // A branch-pinned entry records a revision but no version — nothing to
    // compare against a release.
    if (url && version) versions[url] = String(version);
  }
  return versions;
}

module.exports = { parseSwiftPackage, parsePackageResolved };
