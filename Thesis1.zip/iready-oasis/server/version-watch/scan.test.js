'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { runScan } = require('./scan');

const POM_XML = `
  <project>
    <dependencies>
      <dependency>
        <groupId>org.apache.logging.log4j</groupId>
        <artifactId>log4j-core</artifactId>
        <version>2.14.1</version>
      </dependency>
    </dependencies>
  </project>`;

const PACKAGE_JSON = JSON.stringify({ dependencies: { lodash: '4.17.21' } });
const REQUIREMENTS_TXT = 'requests==2.31.0\n';

// The GitHub side of a scan: one tree listing per repo, then one fetch per
// discovered path. `files` doubles as both — its keys are what the tree reports.
function fakeGitHub(files) {
  return {
    listRepoFiles: async (repoName) => ({ paths: Object.keys(files[repoName] || {}), truncated: false }),
    fetchManifest: async (repoName, filePath) => (files[repoName] && files[repoName][filePath]) || null,
  };
}

// Like fakeGitHub, but every manifest fetch for a repo in `errorRepos` throws a
// non-404 error (a real GitHub API failure — auth/rate-limit/5xx) instead of
// returning content.
function fakeGitHubWithFetchErrors(files, errorRepos) {
  const real = fakeGitHub(files);
  return {
    ...real,
    fetchManifest: async (repoName, filePath) => {
      if (errorRepos.has(repoName)) {
        throw Object.assign(new Error('rate limited'), { response: { status: 429 } });
      }
      return real.fetchManifest(repoName, filePath);
    },
  };
}

// A repo whose tree listing itself fails — the scan never learns which
// manifests it has, so it can contribute nothing at all.
function fakeGitHubWithListErrors(files, errorRepos) {
  const real = fakeGitHub(files);
  return {
    ...real,
    listRepoFiles: async (repoName) => {
      if (errorRepos.has(repoName)) {
        throw Object.assign(new Error('rate limited'), { response: { status: 429 } });
      }
      return real.listRepoFiles(repoName);
    },
  };
}

const fakeRegistries = {
  fetchMavenLatest: async () => ({ latestVersion: '2.17.0', latestMinorVersion: '2.14.2', latestPatchVersion: '2.14.1', latestReleaseDate: '2021-12-01T00:00:00.000Z', latestMinorReleaseDate: '2021-06-01T00:00:00.000Z', latestPatchReleaseDate: null, error: null }),
  fetchMavenVulnerabilities: async () => ({ cves: [], error: null }),
  fetchNpmLatest: async () => ({ latestVersion: '4.17.21', latestMinorVersion: '4.17.21', latestPatchVersion: '4.17.21', latestReleaseDate: '2021-02-20T00:00:00.000Z', latestMinorReleaseDate: '2021-02-20T00:00:00.000Z', latestPatchReleaseDate: '2021-02-20T00:00:00.000Z', deprecated: null, error: null }),
  fetchNpmAdvisories: async () => ({ cves: [], error: null }),
  fetchPipLatest: async () => ({ latestVersion: '2.31.0', latestMinorVersion: '2.31.0', latestPatchVersion: '2.31.0', latestReleaseDate: '2023-05-22T00:00:00.000Z', latestMinorReleaseDate: '2023-05-22T00:00:00.000Z', latestPatchReleaseDate: '2023-05-22T00:00:00.000Z', error: null }),
  fetchPipVulnerabilities: async () => ({ cves: [{ id: 'CVE-2023-9999', severity: null, summary: 'x', url: null }], error: null }),
};

test('scans repos across all three ecosystems and produces one row per unique version', async () => {
  const repos = [{ name: 'repo-a' }, { name: 'repo-b' }];
  const files = {
    'repo-a': { 'pom.xml': POM_XML, 'package.json': PACKAGE_JSON, 'requirements.txt': REQUIREMENTS_TXT },
    'repo-b': { 'package.json': PACKAGE_JSON },
  };
  const { rows, scanSummary } = await runScan({
    repos, ...fakeGitHub(files), registries: fakeRegistries,
  });

  assert.equal(rows.length, 3); // maven log4j, npm lodash, pip requests
  const lodashRow = rows.find(r => r.package === 'lodash');
  assert.deepEqual(lodashRow.usedBy, ['repo-a', 'repo-b']);
  assert.equal(lodashRow.status.upToDate, true);

  assert.equal(scanSummary.reposScanned, 2);
});

test('an npm row is upToDate when its declared range\'s version matches latestVersion, even with a leading ^/~', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': JSON.stringify({ dependencies: { lodash: '^4.17.21' } }) } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });
  const lodashRow = rows.find(r => r.package === 'lodash');
  assert.equal(lodashRow.versionInUse, '^4.17.21');
  assert.equal(lodashRow.status.upToDate, true);
});

test('a maven row with a known vulnerability sets needsUpgrade', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  const vulnRegistries = {
    ...fakeRegistries,
    fetchMavenVulnerabilities: async () => ({ cves: [{ id: 'CVE-2021-44228', severity: 'critical', summary: 'Log4Shell', url: null }], error: null }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: vulnRegistries });
  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.equal(mavenRow.cves.length, 1);
  assert.equal(mavenRow.cves[0].id, 'CVE-2021-44228');
  assert.equal(mavenRow.status.needsUpgrade, true);
  assert.equal(mavenRow.cvesUnavailable, false);
});

test('a maven row with no known vulnerabilities is reported clean, not unavailable', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });
  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.deepEqual(mavenRow.cves, []);
  assert.equal(mavenRow.status.needsUpgrade, false);
  assert.equal(mavenRow.cvesUnavailable, false);
});

test('the maven vulnerability lookup receives the groupId, artifactId and versionInUse', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  let received = null;
  const spyRegistries = {
    ...fakeRegistries,
    fetchMavenVulnerabilities: async (groupId, artifactId, versionInUse) => {
      received = { groupId, artifactId, versionInUse };
      return { cves: [], error: null };
    },
  };
  await runScan({ repos, ...fakeGitHub(files), registries: spyRegistries });
  assert.deepEqual(received, { groupId: 'org.apache.logging.log4j', artifactId: 'log4j-core', versionInUse: '2.14.1' });
});

test('a failed maven vulnerability lookup marks the row cvesUnavailable instead of reporting it clean', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  const flakyRegistries = {
    ...fakeRegistries,
    fetchMavenVulnerabilities: async () => ({ cves: [], error: 'osv timeout' }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: flakyRegistries });
  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.equal(mavenRow.cvesUnavailable, true);
  assert.equal(mavenRow.status.needsUpgrade, false);
  assert.match(mavenRow.lookupErrors.join(' '), /osv timeout/);
});

test('a failed npm advisory lookup also marks the row cvesUnavailable', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON } };
  const flakyRegistries = {
    ...fakeRegistries,
    fetchNpmAdvisories: async () => ({ cves: [], error: 'advisory endpoint down' }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: flakyRegistries });
  assert.equal(rows[0].cvesUnavailable, true);
});

test('a maven row whose version lookup fails is not marked cvesUnavailable when its vulnerability lookup succeeded', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  const flakyRegistries = {
    ...fakeRegistries,
    fetchMavenLatest: async () => ({ latestVersion: null, latestMinorVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, error: 'maven central timeout' }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: flakyRegistries });
  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.equal(mavenRow.cvesUnavailable, false);
  assert.match(mavenRow.lookupErrors.join(' '), /maven central timeout/);
});

test('a pip row with a known vulnerability sets needsUpgrade', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'requirements.txt': REQUIREMENTS_TXT } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });
  const pipRow = rows.find(r => r.ecosystem === 'pip');
  assert.equal(pipRow.status.needsUpgrade, true);
  assert.equal(pipRow.cves.length, 1);
});

test('rows include latestMinorVersion from the registry lookup, and versionInUse is passed to the registry functions', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML, 'package.json': PACKAGE_JSON, 'requirements.txt': REQUIREMENTS_TXT } };
  const receivedArgs = { maven: null, npm: null, pip: null };
  const spyRegistries = {
    ...fakeRegistries,
    fetchMavenLatest: async (groupId, artifactId, versionInUse) => {
      receivedArgs.maven = versionInUse;
      return fakeRegistries.fetchMavenLatest();
    },
    fetchNpmLatest: async (name, versionInUse) => {
      receivedArgs.npm = versionInUse;
      return fakeRegistries.fetchNpmLatest();
    },
    fetchPipLatest: async (name, versionInUse) => {
      receivedArgs.pip = versionInUse;
      return fakeRegistries.fetchPipLatest();
    },
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: spyRegistries });

  assert.equal(receivedArgs.maven, '2.14.1');
  assert.equal(receivedArgs.npm, '4.17.21');
  assert.equal(receivedArgs.pip, '2.31.0');

  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.equal(mavenRow.latestMinorVersion, '2.14.2');
  assert.equal(mavenRow.latestMinorReleaseDate, '2021-06-01T00:00:00.000Z');
});

test('rows carry latestPatchVersion and its release date through for every ecosystem', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML, 'package.json': PACKAGE_JSON, 'requirements.txt': REQUIREMENTS_TXT } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });

  const mavenRow = rows.find(r => r.ecosystem === 'maven');
  assert.equal(mavenRow.latestPatchVersion, '2.14.1');
  assert.equal(mavenRow.latestPatchReleaseDate, null);

  const npmRow = rows.find(r => r.ecosystem === 'npm');
  assert.equal(npmRow.latestPatchVersion, '4.17.21');
  assert.equal(npmRow.latestPatchReleaseDate, '2021-02-20T00:00:00.000Z');

  const pipRow = rows.find(r => r.ecosystem === 'pip');
  assert.equal(pipRow.latestPatchVersion, '2.31.0');
  assert.equal(pipRow.latestPatchReleaseDate, '2023-05-22T00:00:00.000Z');
});

test('a row gets a null latestPatchVersion when the registry lookup failed', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'pom.xml': POM_XML } };
  const failingRegistries = {
    ...fakeRegistries,
    fetchMavenLatest: async () => ({ latestVersion: null, latestMinorVersion: null, latestPatchVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: 'maven central timeout' }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: failingRegistries });
  assert.equal(rows[0].latestPatchVersion, null);
  assert.equal(rows[0].latestPatchReleaseDate, null);
});

test('a repo with no manifests contributes no rows and is still counted as scanned', async () => {
  const repos = [{ name: 'empty-repo' }];
  const { rows, scanSummary } = await runScan({
    repos, ...fakeGitHub({}), registries: fakeRegistries,
  });
  assert.deepEqual(rows, []);
  assert.equal(scanSummary.reposScanned, 1);
});

test('unresolved dependency versions from parsers are counted in scanSummary', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'requirements.txt': 'requests>=2.0\n' } };
  const { rows, scanSummary } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });
  assert.deepEqual(rows, []);
  assert.equal(scanSummary.unresolvedDependencyVersions, 1);
});

test('a failed registry lookup is recorded in lookupErrors and does not throw', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON } };
  const flakyRegistries = {
    ...fakeRegistries,
    fetchNpmLatest: async () => ({ latestVersion: null, latestReleaseDate: null, deprecated: null, error: 'timeout' }),
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: flakyRegistries });
  assert.equal(rows[0].lookupErrors.length, 1);
  assert.match(rows[0].lookupErrors[0], /timeout/);
});

test('onProgress reports "scanning" phase once per repo with the final total', async () => {
  const repos = [{ name: 'repo-a' }, { name: 'repo-b' }];
  const calls = [];
  await runScan({
    repos, ...fakeGitHub({}), registries: fakeRegistries,
    onProgress: (p) => calls.push(p),
  });
  const scanningCalls = calls.filter(c => c.phase === 'scanning');
  assert.equal(scanningCalls.length, 2);
  assert.deepEqual(scanningCalls.map(c => c.total), [2, 2]);
  assert.deepEqual(scanningCalls.map(c => c.label), ['repo-a', 'repo-b']);
});

test('onProgress reports "enriching" phase once per unique dependency row, after all "scanning" calls', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON, 'requirements.txt': REQUIREMENTS_TXT } };
  const calls = [];
  await runScan({
    repos, ...fakeGitHub(files), registries: fakeRegistries,
    onProgress: (p) => calls.push(p),
  });
  const scanningCalls = calls.filter(c => c.phase === 'scanning');
  const enrichingCalls = calls.filter(c => c.phase === 'enriching');
  assert.equal(scanningCalls.length, 1);
  assert.equal(enrichingCalls.length, 2); // one npm row (lodash), one pip row (requests)
  assert.deepEqual(enrichingCalls.map(c => c.total), [2, 2]);
  assert.deepEqual(new Set(enrichingCalls.map(c => c.label)), new Set(['lodash', 'requests']));
  // enriching only starts once every repo has been scanned
  const lastScanningIndex = calls.map(c => c.phase).lastIndexOf('scanning');
  const firstEnrichingIndex = calls.map(c => c.phase).indexOf('enriching');
  assert.ok(lastScanningIndex < firstEnrichingIndex);
});

test('a malformed package.json does not crash the scan and is counted as a manifest parse error', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': '{ not valid json' } };
  const { rows, scanSummary } = await runScan({ repos, ...fakeGitHub(files), registries: fakeRegistries });
  assert.deepEqual(rows, []);
  assert.equal(scanSummary.manifestParseErrors, 1);
});

test('a repo whose manifest fetches throw non-404 errors contributes no rows, is counted once in repoFetchErrors, and does not crash the scan', async () => {
  const repos = [{ name: 'broken-repo' }, { name: 'repo-a' }];
  const files = {
    'broken-repo': { 'package.json': PACKAGE_JSON },
    'repo-a': { 'package.json': PACKAGE_JSON },
  };
  const { rows, scanSummary } = await runScan({
    repos,
    ...fakeGitHubWithFetchErrors(files, new Set(['broken-repo'])),
    registries: fakeRegistries,
  });
  // broken-repo contributes nothing, but repo-a is still processed normally.
  assert.equal(rows.length, 1);
  assert.equal(rows[0].package, 'lodash');
  assert.equal(scanSummary.repoFetchErrors, 1);
  assert.equal(scanSummary.reposScanned, 2);
});

test('a repo with no manifests (normal 404-style null) does not increment repoFetchErrors', async () => {
  const repos = [{ name: 'empty-repo' }];
  const { scanSummary } = await runScan({
    repos, ...fakeGitHub({}), registries: fakeRegistries,
  });
  assert.equal(scanSummary.repoFetchErrors, 0);
});

// ── tree-based manifest discovery ───────────────────────────────────────────

const GO_MOD = 'module example.test/app\n\nrequire github.com/pkg/errors v0.9.1\n';

// The five newer ecosystems need their own stubs; the base fakeRegistries only
// covers the original three.
const noTiers = async () => ({
  latestVersion: null, latestMinorVersion: null, latestPatchVersion: null,
  latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null,
});

const allRegistries = {
  ...fakeRegistries,
  fetchGoLatest: async () => ({ latestVersion: '0.9.2', latestMinorVersion: '0.9.2', latestPatchVersion: '0.9.2', latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null }),
  fetchCargoLatest: async () => ({ latestVersion: '1.0.200', latestMinorVersion: '1.0.200', latestPatchVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null }),
  fetchNugetLatest: async () => ({ latestVersion: '13.0.3', latestMinorVersion: '13.0.3', latestPatchVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null }),
  fetchRubygemsLatest: async () => ({ latestVersion: '2.2.8', latestMinorVersion: '2.2.8', latestPatchVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null }),
  fetchComposerLatest: async () => ({ latestVersion: '3.5.0', latestMinorVersion: '3.5.0', latestPatchVersion: null, latestReleaseDate: null, latestMinorReleaseDate: null, latestPatchReleaseDate: null, error: null }),
  fetchPubLatest: noTiers, fetchHexLatest: noTiers, fetchHackageLatest: noTiers,
  fetchCpanLatest: noTiers, fetchConanLatest: noTiers, fetchCondaLatest: noTiers,
  fetchOsvVulnerabilities: async () => ({ cves: [], error: null }),
};

test('discovers a manifest in a subdirectory', async () => {
  // Multi-module Maven builds keep their poms below the root and were entirely
  // invisible to the previous root-only probes.
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'services/api/pom.xml': POM_XML } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].package, 'org.apache.logging.log4j:log4j-core');
});

test('fetches only the paths that matched a manifest handler', async () => {
  // The point of the tree listing: no blind probing for files that aren't there.
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON, 'README.md': '# hi', 'src/main.js': 'x' } };
  const requested = [];
  const github = fakeGitHub(files);
  await runScan({
    repos,
    listRepoFiles: github.listRepoFiles,
    fetchManifest: async (repo, path) => { requested.push(path); return github.fetchManifest(repo, path); },
    registries: allRegistries,
  });
  assert.deepEqual(requested, ['package.json']);
});

test('produces rows for an ecosystem beyond the original three', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'go.mod': GO_MOD } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].ecosystem, 'go');
  assert.equal(rows[0].package, 'github.com/pkg/errors');
  assert.equal(rows[0].versionInUse, '0.9.1');
  assert.equal(rows[0].latestVersion, '0.9.2');
});

test('dispatches to the registry lookup for the row own ecosystem', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'go.mod': GO_MOD } };
  const calls = [];
  const spied = {
    ...allRegistries,
    fetchGoLatest: async (...args) => { calls.push({ fn: 'fetchGoLatest', args }); return { latestVersion: null, error: null }; },
    fetchOsvVulnerabilities: async (...args) => { calls.push({ fn: 'fetchOsvVulnerabilities', args }); return { cves: [], error: null }; },
  };
  await runScan({ repos, ...fakeGitHub(files), registries: spied });
  assert.deepEqual(calls.find(c => c.fn === 'fetchGoLatest').args, ['github.com/pkg/errors', '0.9.1']);
  assert.deepEqual(calls.find(c => c.fn === 'fetchOsvVulnerabilities').args, ['Go', 'github.com/pkg/errors', '0.9.1']);
});

test('collapses dependencies of one ecosystem declared through different manifests', async () => {
  // The same coordinate from a pom and from a build script is one dependency,
  // so it must produce one row listing both repos — not two maven rows.
  const repos = [{ name: 'repo-a' }, { name: 'repo-b' }];
  const files = {
    'repo-a': { 'pom.xml': POM_XML },
    'repo-b': { 'build.gradle': "implementation 'org.apache.logging.log4j:log4j-core:2.14.1'" },
  };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].ecosystem, 'maven');
  assert.deepEqual(rows[0].usedBy, ['repo-a', 'repo-b']);
});

test('carries versionIsRange onto a row declared as a range', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'Cargo.toml': '[dependencies]\nserde = "1.0"' } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.equal(rows[0].versionIsRange, true);
});

test('does not fetch manifests inside vendored directories', async () => {
  const repos = [{ name: 'repo-a' }];
  const files = { 'repo-a': { 'vendor/other/pom.xml': POM_XML, 'package.json': PACKAGE_JSON } };
  const { rows } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.deepEqual(rows.map(r => r.ecosystem), ['npm']);
});

test('joins a versionless PackageReference to Directory.Packages.props from an ancestor directory', async () => {
  // Exercises the cross-file parse context end to end: without it, every
  // dependency in a Central Package Management repo reports as unresolved.
  const repos = [{ name: 'repo-a' }];
  const files = {
    'repo-a': {
      'src/Api/Api.csproj': '<PackageReference Include="Newtonsoft.Json" />',
      'Directory.Packages.props': '<PackageVersion Include="Newtonsoft.Json" Version="13.0.3" />',
    },
  };
  const { rows, scanSummary } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].package, 'Newtonsoft.Json');
  assert.equal(rows[0].versionInUse, '13.0.3');
  assert.equal(scanSummary.unresolvedDependencyVersions, 0);
});

test('counts a repo whose tree was truncated so an under-reported repo stays visible', async () => {
  const repos = [{ name: 'huge-repo' }];
  const { scanSummary } = await runScan({
    repos,
    listRepoFiles: async () => ({ paths: ['package.json'], truncated: true }),
    fetchManifest: async () => PACKAGE_JSON,
    registries: allRegistries,
  });
  assert.equal(scanSummary.reposWithTruncatedTree, 1);
});

test('caps manifests fetched per repo and counts what it skipped', async () => {
  const { MAX_MANIFESTS_PER_REPO } = require('./scan');
  const paths = {};
  for (let i = 0; i < MAX_MANIFESTS_PER_REPO + 5; i++) paths[`module-${i}/package.json`] = PACKAGE_JSON;
  const { scanSummary } = await runScan({
    repos: [{ name: 'monorepo' }],
    ...fakeGitHub({ monorepo: paths }),
    registries: allRegistries,
  });
  assert.equal(scanSummary.manifestsSkipped, 5);
});

test('reports ecosystems detected but not tracked, with a repo count', async () => {
  const repos = [{ name: 'repo-a' }, { name: 'repo-b' }];
  const files = {
    'repo-a': { 'ios/Podfile': 'x', 'Dockerfile': 'FROM node:20' },
    'repo-b': { 'ios/Podfile': 'x' },
  };
  const { scanSummary } = await runScan({ repos, ...fakeGitHub(files), registries: allRegistries });
  const byLabel = new Map(scanSummary.untrackedEcosystems.map(e => [e.label, e.repos]));
  assert.equal(byLabel.get('CocoaPods'), 2);
  assert.equal(byLabel.get('Docker'), 1);
});

test('reports nothing untracked when every manifest is supported', async () => {
  const { scanSummary } = await runScan({
    repos: [{ name: 'repo-a' }],
    ...fakeGitHub({ 'repo-a': { 'package.json': PACKAGE_JSON } }),
    registries: allRegistries,
  });
  assert.deepEqual(scanSummary.untrackedEcosystems, []);
});

test('a repo whose tree listing fails contributes nothing and is counted once', async () => {
  const repos = [{ name: 'broken-repo' }, { name: 'repo-a' }];
  const files = {
    'broken-repo': { 'package.json': PACKAGE_JSON },
    'repo-a': { 'requirements.txt': REQUIREMENTS_TXT },
  };
  const { rows, scanSummary } = await runScan({
    repos,
    ...fakeGitHubWithListErrors(files, new Set(['broken-repo'])),
    registries: allRegistries,
  });
  assert.deepEqual(rows.map(r => r.ecosystem), ['pip']);
  assert.equal(scanSummary.repoFetchErrors, 1);
  assert.equal(scanSummary.reposScanned, 2);
});

// ── ecosystems whose feeds do not exist ─────────────────────────────────────

test('routes a dependency to the ecosystem the parser assigned it, not the manifest', async () => {
  // environment.yml declares conda packages AND, in its pip: block, PyPI
  // packages. Looking the latter up against a conda channel would ask the wrong
  // registry about the wrong name.
  const files = {
    'repo-a': { 'environment.yml': 'dependencies:\n  - numpy=1.24.3\n  - pip:\n      - requests==2.31.0\n' },
  };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: allRegistries,
  });
  const byName = new Map(rows.map(r => [r.package, r.ecosystem]));
  assert.equal(byName.get('numpy'), 'conda');
  assert.equal(byName.get('requests'), 'pip');
});

test('marks a row as not-checked when no vulnerability database covers its ecosystem', async () => {
  // No public feed covers Conan. An empty findings list would render as "none",
  // which claims the package was checked and found clean.
  const files = { 'repo-a': { 'conanfile.txt': '[requires]\nzlib/1.2.13\n' } };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: allRegistries,
  });
  assert.equal(rows[0].ecosystem, 'conan');
  assert.equal(rows[0].cvesUnavailable, true);
  assert.equal(rows[0].cvesUnavailableReason, 'unsupported');
  assert.equal(rows[0].status.needsUpgrade, false);
});

test('does not count a missing vulnerability feed as a failed registry lookup', async () => {
  // The feed does not exist; nothing failed. Counting it would inflate the
  // footer's "registry lookups failed" tally on every scan.
  const files = { 'repo-a': { 'conanfile.txt': '[requires]\nzlib/1.2.13\n' } };
  const { rows, scanSummary } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: allRegistries,
  });
  assert.deepEqual(rows[0].lookupErrors, []);
  assert.equal(scanSummary.lookupErrors, 0);
});

test('distinguishes a failed vulnerability lookup from an absent feed', async () => {
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON } };
  const flaky = { ...allRegistries, fetchNpmAdvisories: async () => ({ cves: [], error: 'npm 503' }) };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: flaky,
  });
  assert.equal(rows[0].cvesUnavailable, true);
  assert.equal(rows[0].cvesUnavailableReason, 'error');
});

test('marks the latest version as not tracked when the ecosystem has no version source', async () => {
  // Swift resolves from git URLs, so no registry can answer "what is latest".
  // A plain null would render as "—", which reads as "nothing newer exists".
  const files = {
    'repo-a': { 'Package.swift': '.package(url: "https://github.com/apple/swift-log.git", exact: "1.5.3")' },
  };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: allRegistries,
  });
  assert.equal(rows[0].ecosystem, 'swift');
  assert.equal(rows[0].latestUnavailable, true);
  assert.equal(rows[0].latestVersion, null);
});

test('still checks vulnerabilities for an ecosystem that has no version source', async () => {
  const files = {
    'repo-a': { 'Package.swift': '.package(url: "https://github.com/apple/swift-log.git", exact: "1.5.3")' },
  };
  const withFinding = {
    ...allRegistries,
    fetchOsvVulnerabilities: async () => ({ cves: [{ id: 'CVE-2024-0001', severity: 'high', summary: 'x', url: null }], error: null }),
  };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: withFinding,
  });
  assert.equal(rows[0].cvesUnavailable, false);
  assert.equal(rows[0].status.needsUpgrade, true);
});

test('leaves latestUnavailable absent for an ecosystem that does have a version source', async () => {
  const files = { 'repo-a': { 'package.json': PACKAGE_JSON } };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }], ...fakeGitHub(files), registries: allRegistries,
  });
  assert.notEqual(rows[0].latestUnavailable, true);
});

test('reads an sbt build as a maven row so it dedupes with a pom coordinate', async () => {
  const files = {
    'repo-a': { 'pom.xml': POM_XML },
    'repo-b': { 'build.sbt': 'scalaVersion := "2.13.12"\nlibraryDependencies += "org.apache.logging.log4j" % "log4j-core" % "2.14.1"' },
  };
  const { rows } = await runScan({
    repos: [{ name: 'repo-a' }, { name: 'repo-b' }], ...fakeGitHub(files), registries: allRegistries,
  });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].ecosystem, 'maven');
  assert.deepEqual(rows[0].usedBy, ['repo-a', 'repo-b']);
});
