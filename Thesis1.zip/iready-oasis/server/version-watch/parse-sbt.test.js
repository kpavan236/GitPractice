'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseSbt } = require('./parse-sbt');

test('reads a single-percent coordinate as a literal artifactId', () => {
  // A single % means the artifactId is used verbatim — typical for Java
  // libraries consumed from Scala.
  const sbt = 'libraryDependencies += "com.google.guava" % "guava" % "32.1.2-jre"';
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, [
    { name: 'com.google.guava:guava', version: '32.1.2-jre' },
  ]);
});

test('appends the scala binary version for a double-percent coordinate', () => {
  // %% means sbt appends the Scala binary version to the artifactId, so the
  // artifact actually published to Maven Central is cats-core_2.13. Resolving
  // this is what makes the coordinate findable at all.
  const sbt = `
scalaVersion := "2.13.12"
libraryDependencies += "org.typelevel" %% "cats-core" % "2.10.0"
`;
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, [
    { name: 'org.typelevel:cats-core_2.13', version: '2.10.0' },
  ]);
});

test('uses a bare major for a scala 3 binary version', () => {
  // Scala 3 publishes against "_3", not "_3.3".
  const sbt = `
scalaVersion := "3.3.1"
libraryDependencies += "org.typelevel" %% "cats-core" % "2.10.0"
`;
  const { dependencies } = parseSbt(sbt);
  assert.strictEqual(dependencies[0].name, 'org.typelevel:cats-core_3');
});

test('counts a double-percent coordinate as unresolved when no scalaVersion is declared', () => {
  // The version lives in a parent build or plugin; guessing a binary version
  // would produce a coordinate that does not exist.
  const sbt = 'libraryDependencies += "org.typelevel" %% "cats-core" % "2.10.0"';
  const { dependencies, unresolvedCount } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('reads every entry of a Seq of dependencies', () => {
  const sbt = `
scalaVersion := "2.13.12"
libraryDependencies ++= Seq(
  "org.typelevel" %% "cats-effect" % "3.5.2",
  "com.typesafe.akka" %% "akka-actor" % "2.8.5",
  "org.postgresql" % "postgresql" % "42.7.1"
)
`;
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), [
    'com.typesafe.akka:akka-actor_2.13',
    'org.postgresql:postgresql',
    'org.typelevel:cats-effect_2.13',
  ]);
});

test('ignores a configuration scope suffix', () => {
  const sbt = `
scalaVersion := "2.13.12"
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.17" % Test
`;
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, [
    { name: 'org.scalatest:scalatest_2.13', version: '3.2.17' },
  ]);
});

test('counts an interpolated version as unresolved', () => {
  const sbt = `
scalaVersion := "2.13.12"
libraryDependencies += "org.typelevel" %% "cats-core" % catsVersion
`;
  const { dependencies, unresolvedCount } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores a line comment', () => {
  const sbt = `
scalaVersion := "2.13.12"
// libraryDependencies += "com.removed" % "removed" % "1.0.0"
libraryDependencies += "com.kept" % "kept" % "2.0.0"
`;
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['com.kept:kept']);
});

test('does not treat addSbtPlugin as a project dependency', () => {
  // An sbt plugin is part of the build, not of the shipped artifact.
  const sbt = 'addSbtPlugin("com.eed3si9n" % "sbt-assembly" % "2.1.5")';
  const { dependencies } = parseSbt(sbt);
  assert.deepStrictEqual(dependencies, []);
});

test('reports the same coordinate once when declared twice', () => {
  const sbt = `
scalaVersion := "2.13.12"
libraryDependencies += "org.typelevel" %% "cats-core" % "2.10.0"
libraryDependencies += "org.typelevel" %% "cats-core" % "2.10.0"
`;
  assert.strictEqual(parseSbt(sbt).dependencies.length, 1);
});

test('returns no dependencies for a build file with none', () => {
  assert.deepStrictEqual(parseSbt('name := "my-project"'), {
    dependencies: [], unresolvedCount: 0,
  });
});
