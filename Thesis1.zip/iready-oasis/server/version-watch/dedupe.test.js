'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { dedupeRows } = require('./dedupe');

test('collapses the same ecosystem+package+version used by multiple repos into one row', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'npm', package: 'lodash', version: '4.17.21' },
    { repo: 'repo-b', ecosystem: 'npm', package: 'lodash', version: '4.17.21' },
  ]);
  assert.deepEqual(rows, [
    { ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', usedBy: ['repo-a', 'repo-b'] },
  ]);
});

test('keeps different versions of the same package as separate rows', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'npm', package: 'lodash', version: '4.17.21' },
    { repo: 'repo-b', ecosystem: 'npm', package: 'lodash', version: '3.0.0' },
  ]);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.find(r => r.versionInUse === '4.17.21').usedBy, ['repo-a']);
  assert.deepEqual(rows.find(r => r.versionInUse === '3.0.0').usedBy, ['repo-b']);
});

test('keeps the same package name in different ecosystems as separate rows', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'npm', package: 'requests', version: '1.0.0' },
    { repo: 'repo-b', ecosystem: 'pip', package: 'requests', version: '1.0.0' },
  ]);
  assert.equal(rows.length, 2);
  assert.deepEqual(new Set(rows.map(r => r.ecosystem)), new Set(['npm', 'pip']));
});

test('deduplicates a repo listed twice for the same key', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'npm', package: 'lodash', version: '4.17.21' },
    { repo: 'repo-a', ecosystem: 'npm', package: 'lodash', version: '4.17.21' },
  ]);
  assert.deepEqual(rows[0].usedBy, ['repo-a']);
});

test('returns an empty array for no entries', () => {
  assert.deepEqual(dedupeRows([]), []);
});

test('does not collide package/version pairs that would match under a naive delimiter-joined key', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'npm', package: 'a', version: 'b::c' },
    { repo: 'repo-b', ecosystem: 'npm', package: 'a::b', version: 'c' },
  ]);
  assert.equal(rows.length, 2);
  const rowOne = rows.find(r => r.package === 'a' && r.versionInUse === 'b::c');
  const rowTwo = rows.find(r => r.package === 'a::b' && r.versionInUse === 'c');
  assert.ok(rowOne, 'expected a row with package "a" and version "b::c"');
  assert.ok(rowTwo, 'expected a row with package "a::b" and version "c"');
  assert.deepEqual(rowOne.usedBy, ['repo-a']);
  assert.deepEqual(rowTwo.usedBy, ['repo-b']);
});

test('carries versionIsRange onto the deduped row', () => {
  // The marker is what tells the UI that a vulnerability finding applies to a
  // declared floor rather than a resolved version. Dropped here, the row would
  // silently overstate its own precision.
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'cargo', package: 'serde', version: '1.0', versionIsRange: true },
  ]);
  assert.equal(rows[0].versionIsRange, true);
});

test('leaves versionIsRange absent for an exactly pinned row', () => {
  const rows = dedupeRows([
    { repo: 'repo-a', ecosystem: 'maven', package: 'g:a', version: '1.0.0' },
  ]);
  assert.notEqual(rows[0].versionIsRange, true);
});
