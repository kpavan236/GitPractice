'use strict';
const { stripSlashComments } = require('./strip-comments');
const { isRangeDeclaration } = require('./compare-versions');

// Matches an sbt coordinate: "group" % "artifact" % version, where the middle
// operator is either % (artifactId used verbatim) or %% (Scala binary version
// appended). The version is either a literal string or an identifier defined
// elsewhere in the build.
const SBT_COORDINATE = /"([^"]+)"\s*(%{1,2})\s*"([^"]+)"\s*%\s*(?:"([^"]+)"|([A-Za-z_][\w.]*))/g;

// sbt's %% operator appends the Scala BINARY version, which is not the full
// scalaVersion: Scala 2 publishes against major.minor ("_2.13") while Scala 3
// publishes against the bare major ("_3"). Getting this wrong produces a
// coordinate that does not exist on Maven Central.
function scalaBinaryVersion(scalaVersion) {
  const parts = String(scalaVersion).trim().split('.');
  if (!parts[0]) return null;
  if (Number(parts[0]) >= 3) return parts[0];
  return parts[1] ? `${parts[0]}.${parts[1]}` : null;
}

// Parses build.sbt (and project/*.sbt) for literal Maven coordinates.
//
// Lossy for the same reason as parse-gradle: an sbt build file is a Scala
// program, so a version held in a variable or a shared Dependencies.scala is not
// resolvable from one file and is counted rather than guessed.
//
// Coordinates resolve under the `maven` ecosystem, so a library used from both
// Scala and Java dedupes into a single row.
function parseSbt(text) {
  // addSbtPlugin declares build tooling, not a dependency of the shipped
  // artifact — removed before scanning so its coordinate is never picked up.
  const source = stripSlashComments(text).replace(/addSbtPlugin\s*\([\s\S]*?\)/g, '');

  const scalaVersion = source.match(/scalaVersion\s*:=\s*"([^"]+)"/)?.[1] || null;
  const binaryVersion = scalaVersion ? scalaBinaryVersion(scalaVersion) : null;

  const byKey = new Map();
  let unresolvedCount = 0;

  for (const match of source.matchAll(SBT_COORDINATE)) {
    const [, group, operator, artifact, literalVersion, identifierVersion] = match;

    // A version held in an identifier is defined elsewhere in the build.
    if (!literalVersion && identifierVersion) { unresolvedCount++; continue; }
    if (!literalVersion) { unresolvedCount++; continue; }

    let artifactId = artifact;
    if (operator === '%%') {
      // Without a scalaVersion in this file there is no way to know which
      // binary suffix was published; inventing one would be worse than
      // reporting it unresolved.
      if (!binaryVersion) { unresolvedCount++; continue; }
      artifactId = `${artifact}_${binaryVersion}`;
    }

    const name = `${group}:${artifactId}`;
    const entry = isRangeDeclaration(literalVersion)
      ? { name, version: literalVersion, versionIsRange: true }
      : { name, version: literalVersion };
    byKey.set(`${name}:${literalVersion}`, entry);
  }

  return { dependencies: [...byKey.values()], unresolvedCount };
}

module.exports = { parseSbt, scalaBinaryVersion };
