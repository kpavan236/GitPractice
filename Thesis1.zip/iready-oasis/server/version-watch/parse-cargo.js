'use strict';
const { parseToml } = require('./parse-toml');

const DEPENDENCY_TABLES = ['dependencies', 'dev-dependencies', 'build-dependencies'];

function isTable(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

// Parses Cargo.toml into { name, version } entries from the normal, dev,
// build, and target-specific dependency tables.
//
// Cargo reads a bare version as a caret range — "1.0" means "^1.0" — so
// almost every Cargo declaration is a range rather than a pin, and only an
// explicit "=1.0.0" is exact. Rows are flagged with `versionIsRange`
// accordingly, because a vulnerability finding against a range's floor is a
// statement about the floor and not about whatever the lockfile resolved.
//
// git, path, and workspace-inherited dependencies have no crates.io version to
// look up (the workspace root that carries it is a different file), so they go
// to `unresolvedCount` rather than being guessed at.
function parseCargoToml(text) {
  const doc = parseToml(text);
  const dependencies = [];
  let unresolvedCount = 0;

  const tables = [];
  for (const key of DEPENDENCY_TABLES) {
    if (isTable(doc[key])) tables.push(doc[key]);
  }
  // [target.'cfg(unix)'.dependencies] and friends — the cfg expression itself
  // is irrelevant here; a dependency that ships on any platform still counts.
  if (isTable(doc.target)) {
    for (const cfg of Object.values(doc.target)) {
      if (!isTable(cfg)) continue;
      for (const key of DEPENDENCY_TABLES) {
        if (isTable(cfg[key])) tables.push(cfg[key]);
      }
    }
  }

  for (const table of tables) {
    for (const [alias, declaration] of Object.entries(table)) {
      if (typeof declaration === 'string') {
        dependencies.push(cargoEntry(alias, declaration));
        continue;
      }
      if (!isTable(declaration)) { unresolvedCount++; continue; }
      if (declaration.git || declaration.path || declaration.workspace) { unresolvedCount++; continue; }
      if (typeof declaration.version !== 'string' || !declaration.version.trim()) { unresolvedCount++; continue; }
      // The table key is the local alias; `package` names the real crate.
      dependencies.push(cargoEntry(declaration.package || alias, declaration.version));
    }
  }

  return { dependencies, unresolvedCount };
}

function cargoEntry(name, declaredVersion) {
  const declared = declaredVersion.trim();
  const isExact = declared.startsWith('=');
  const version = isExact ? declared.replace(/^=+\s*/, '') : declared;
  return isExact ? { name, version } : { name, version, versionIsRange: true };
}

module.exports = { parseCargoToml };