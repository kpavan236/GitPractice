'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseRequirementsTxt } = require('./parse-pip');

test('parses an exact-pinned requirement', () => {
  const { dependencies, unresolvedCount } = parseRequirementsTxt('requests==2.31.0\n');
  assert.deepEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
  assert.equal(unresolvedCount, 0);
});

test('strips a trailing inline comment before parsing', () => {
  const { dependencies } = parseRequirementsTxt('requests==2.31.0  # pinned for CVE fix\n');
  assert.deepEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
});

test('strips extras in brackets from the package name', () => {
  const { dependencies } = parseRequirementsTxt('flask[async]==2.3.0\n');
  assert.deepEqual(dependencies, [{ name: 'flask', version: '2.3.0' }]);
});

test('skips a range/non-exact requirement and counts it as unresolved', () => {
  const { dependencies, unresolvedCount } = parseRequirementsTxt('requests>=2.0\n');
  assert.deepEqual(dependencies, []);
  assert.equal(unresolvedCount, 1);
});

test('ignores blank lines and full-line comments without counting them as unresolved', () => {
  const { dependencies, unresolvedCount } = parseRequirementsTxt('\n# a comment\n\nrequests==2.31.0\n');
  assert.deepEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
  assert.equal(unresolvedCount, 0);
});

test('ignores option lines like -r and -e without counting them as unresolved', () => {
  const { dependencies, unresolvedCount } = parseRequirementsTxt('-r base.txt\n-e .\nrequests==2.31.0\n');
  assert.deepEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
  assert.equal(unresolvedCount, 0);
});

test('parses a PEP 440 arbitrary-equality (===) pin the same as ==', () => {
  const { dependencies, unresolvedCount } = parseRequirementsTxt('requests===2.31.0\n');
  assert.deepEqual(dependencies, [{ name: 'requests', version: '2.31.0' }]);
  assert.equal(unresolvedCount, 0);
});
