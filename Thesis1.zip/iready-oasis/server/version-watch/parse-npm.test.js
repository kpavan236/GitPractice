'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parsePackageJson } = require('./parse-npm');

test('parses dependencies and devDependencies, keeping the raw version string', () => {
  const json = JSON.stringify({
    name: 'example',
    dependencies: { express: '^4.18.2', axios: '1.6.0' },
    devDependencies: { nodemon: '~3.0.2' },
  });
  const { dependencies } = parsePackageJson(json);
  assert.deepEqual(
    [...dependencies].sort((a, b) => a.name.localeCompare(b.name)),
    [
      { name: 'axios', version: '1.6.0' },
      { name: 'express', version: '^4.18.2' },
      { name: 'nodemon', version: '~3.0.2' },
    ]
  );
});

test('a dependency listed in both dependencies and devDependencies uses the dependencies version', () => {
  const json = JSON.stringify({
    dependencies: { lodash: '4.17.21' },
    devDependencies: { lodash: '^3.0.0' },
  });
  const { dependencies } = parsePackageJson(json);
  assert.deepEqual(dependencies, [{ name: 'lodash', version: '4.17.21' }]);
});

test('returns an empty list for a package.json with no dependencies', () => {
  const json = JSON.stringify({ name: 'example' });
  const { dependencies } = parsePackageJson(json);
  assert.deepEqual(dependencies, []);
});
