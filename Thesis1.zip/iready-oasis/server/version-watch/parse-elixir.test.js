'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseMixExs, parseMixLock } = require('./parse-elixir');

test('reads a dependency declared as a two-element tuple', () => {
  const mix = `
  defp deps do
    [
      {:phoenix, "~> 1.7.10"},
      {:jason, "~> 1.4"}
    ]
  end
`;
  const { dependencies } = parseMixExs(mix);
  assert.deepStrictEqual(dependencies, [
    { name: 'phoenix', version: '~> 1.7.10', versionIsRange: true },
    { name: 'jason', version: '~> 1.4', versionIsRange: true },
  ]);
});

test('treats a bare version as an exact pin', () => {
  const { dependencies } = parseMixExs('{:jason, "1.4.1"}');
  assert.deepStrictEqual(dependencies, [{ name: 'jason', version: '1.4.1' }]);
});

test('reads a dependency with trailing options', () => {
  const { dependencies } = parseMixExs('{:credo, "~> 1.7", only: [:dev, :test], runtime: false}');
  assert.deepStrictEqual(dependencies, [{ name: 'credo', version: '~> 1.7', versionIsRange: true }]);
});

test('counts a git dependency as unresolved', () => {
  const { dependencies, unresolvedCount } = parseMixExs('{:mylib, git: "https://github.test/x/mylib.git"}');
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a path dependency as unresolved', () => {
  const { unresolvedCount } = parseMixExs('{:sibling, path: "../sibling"}');
  assert.strictEqual(unresolvedCount, 1);
});

test('counts an in-umbrella dependency as unresolved', () => {
  // An umbrella sibling is local code, not a Hex release.
  const { unresolvedCount } = parseMixExs('{:my_app_web, in_umbrella: true}');
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores a comment', () => {
  const mix = `
      # {:removed, "~> 1.0"},
      {:kept, "~> 2.0"}
`;
  const { dependencies } = parseMixExs(mix);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['kept']);
});

test('prefers the exact version from mix.lock', () => {
  const { dependencies } = parseMixExs('{:phoenix, "~> 1.7.10"}', {
    lockVersions: { phoenix: '1.7.11' },
  });
  assert.deepStrictEqual(dependencies, [{ name: 'phoenix', version: '1.7.11' }]);
});

test('reads hex package versions out of mix.lock', () => {
  const lock = `%{
  "phoenix": {:hex, :phoenix, "1.7.11", "abcd", [:mix], [], "hexpm", "ef01"},
  "jason": {:hex, :jason, "1.4.1", "beef", [:mix], [], "hexpm", "cafe"},
}`;
  assert.deepStrictEqual(parseMixLock(lock), { phoenix: '1.7.11', jason: '1.4.1' });
});

test('ignores a mix.lock entry that is not from hex', () => {
  const lock = '%{\n  "mylib": {:git, "https://github.test/x/mylib.git", "abc123", []},\n}';
  assert.deepStrictEqual(parseMixLock(lock), {});
});

test('reports the same dependency once when declared twice', () => {
  const { dependencies } = parseMixExs('{:jason, "1.4.1"}\n{:jason, "1.4.1"}');
  assert.strictEqual(dependencies.length, 1);
});

test('returns no dependencies for a mix file with none', () => {
  assert.deepStrictEqual(parseMixExs('defmodule MyApp.MixProject do\nend'), {
    dependencies: [], unresolvedCount: 0,
  });
});
