'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseYaml } = require('./parse-yaml');

// A deliberately partial YAML reader, sized for the dependency blocks in
// pubspec.yaml and environment.yml. Anchors, multi-document files, block
// scalars, and flow mappings are out of scope.

test('reads a top-level key and scalar value', () => {
  assert.deepStrictEqual(parseYaml('name: my_app'), { name: 'my_app' });
});

test('nests keys by indentation', () => {
  const yaml = `
dependencies:
  http: ^1.1.0
  provider: 6.0.5
`;
  assert.deepStrictEqual(parseYaml(yaml), {
    dependencies: { http: '^1.1.0', provider: '6.0.5' },
  });
});

test('nests several levels deep', () => {
  const yaml = `
dependencies:
  flutter:
    sdk: flutter
`;
  assert.deepStrictEqual(parseYaml(yaml), {
    dependencies: { flutter: { sdk: 'flutter' } },
  });
});

test('returns to an outer level when indentation decreases', () => {
  const yaml = `
dependencies:
  http: ^1.1.0
dev_dependencies:
  test: ^1.24.0
`;
  const result = parseYaml(yaml);
  assert.deepStrictEqual(result.dependencies, { http: '^1.1.0' });
  assert.deepStrictEqual(result.dev_dependencies, { test: '^1.24.0' });
});

test('reads a sequence of scalars', () => {
  const yaml = `
dependencies:
  - numpy=1.24.3
  - pandas=2.0.1
`;
  assert.deepStrictEqual(parseYaml(yaml), {
    dependencies: ['numpy=1.24.3', 'pandas=2.0.1'],
  });
});

test('reads a nested sequence under a key inside a sequence', () => {
  // environment.yml expresses its pip section exactly this way.
  const yaml = `
dependencies:
  - numpy=1.24.3
  - pip:
      - requests==2.31.0
      - flask==3.0.0
`;
  const result = parseYaml(yaml);
  assert.strictEqual(result.dependencies[0], 'numpy=1.24.3');
  assert.deepStrictEqual(result.dependencies[1], { pip: ['requests==2.31.0', 'flask==3.0.0'] });
});

test('strips a full-line comment', () => {
  const yaml = `
# a comment
name: my_app
`;
  assert.deepStrictEqual(parseYaml(yaml), { name: 'my_app' });
});

test('strips a trailing comment', () => {
  assert.deepStrictEqual(parseYaml('name: my_app  # trailing'), { name: 'my_app' });
});

test('keeps a hash inside a quoted value', () => {
  assert.deepStrictEqual(parseYaml('url: "https://x.test/#frag"'), { url: 'https://x.test/#frag' });
});

test('unquotes a single-quoted value', () => {
  assert.deepStrictEqual(parseYaml("version: '1.2.3'"), { version: '1.2.3' });
});

test('reads a key whose value is empty as an empty map', () => {
  // A dependency declared with no constraint at all: "http:" with nothing after.
  const yaml = `
dependencies:
  http:
  provider: 6.0.5
`;
  const result = parseYaml(yaml);
  assert.deepStrictEqual(result.dependencies.http, null);
  assert.strictEqual(result.dependencies.provider, '6.0.5');
});

test('keeps a colon that appears inside a value', () => {
  assert.deepStrictEqual(parseYaml('url: https://x.test/a'), { url: 'https://x.test/a' });
});

test('returns an empty object for empty input', () => {
  assert.deepStrictEqual(parseYaml(''), {});
});

test('ignores a document separator rather than throwing', () => {
  assert.deepStrictEqual(parseYaml('---\nname: my_app\n'), { name: 'my_app' });
});

test('reads a value containing a version range with spaces', () => {
  assert.deepStrictEqual(parseYaml('sdk: ">=3.0.0 <4.0.0"'), { sdk: '>=3.0.0 <4.0.0' });
});
