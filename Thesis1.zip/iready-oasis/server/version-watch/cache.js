'use strict';
const fs = require('fs');
const { rowKey } = require('./dedupe');

function loadCache(cachePath) {
  try {
    if (fs.existsSync(cachePath)) return JSON.parse(fs.readFileSync(cachePath, 'utf8'));
  } catch (_) {}
  return { lastScanAt: null, rows: [], scanSummary: null };
}

function saveCache(cachePath, data) {
  try { fs.writeFileSync(cachePath, JSON.stringify(data, null, 2)); } catch (_) {}
}

// Marks each new row's `status.changedSinceLastScan` by comparing all three
// upgrade tiers (latestVersion, latestMinorVersion, latestPatchVersion) and
// cves against the previous scan's row for the same (ecosystem, package,
// versionInUse) key. A key with no
// match in a REAL
// previous scan (a dependency that's new since that scan) counts as
// changed — but on the very first scan ever (no scan history exists at
// all), nothing is "changed" since there's nothing to compare against;
// flagging every row as changed on a tool's first run is misleading, not
// informative.
function markChangedSinceLastScan(newRows, previousRows) {
  const isFirstScanEver = previousRows.length === 0;
  const prevByKey = new Map(
    previousRows.map(r => [rowKey(r.ecosystem, r.package, r.versionInUse), r])
  );
  return newRows.map(row => {
    const key = rowKey(row.ecosystem, row.package, row.versionInUse);
    const prev = prevByKey.get(key);
    const changed = !isFirstScanEver && (
      !prev
      || prev.latestVersion !== row.latestVersion
      || prev.latestMinorVersion !== row.latestMinorVersion
      || prev.latestPatchVersion !== row.latestPatchVersion
      || JSON.stringify(prev.cves) !== JSON.stringify(row.cves)
    );
    return { ...row, status: { ...row.status, changedSinceLastScan: changed } };
  });
}

module.exports = { loadCache, saveCache, markChangedSinceLastScan };
