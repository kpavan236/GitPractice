'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const {
  matchManifests, isVendoredPath, detectUntrackedEcosystems, createParseContext,
} = require('./manifests');

function matchedIds(paths) {
  return matchManifests(paths).map(m => `${m.handler.id}@${m.path}`);
}

test('matches a manifest at the repo root', () => {
  assert.deepEqual(matchedIds(['pom.xml']), ['pom@pom.xml']);
});

test('matches manifests in subdirectories', () => {
  // Multi-module Maven builds and JS monorepos keep their manifests below the
  // root, and were invisible to the previous root-only probes.
  const matches = matchManifests(['services/api/pom.xml', 'web/package.json']);
  assert.deepEqual(matches.map(m => m.path).sort(), ['services/api/pom.xml', 'web/package.json']);
});

test('matches both Groovy and Kotlin Gradle build scripts', () => {
  const matches = matchManifests(['build.gradle', 'app/build.gradle.kts']);
  assert.equal(matches.length, 2);
  assert.ok(matches.every(m => m.handler.ecosystem === 'maven'));
});

test('matches a Gradle version catalog only at its conventional path', () => {
  assert.equal(matchManifests(['gradle/libs.versions.toml']).length, 1);
  assert.equal(matchManifests(['docs/libs.versions.toml']).length, 0);
});

test('matches requirements files with a suffix', () => {
  const matches = matchManifests(['requirements.txt', 'requirements-dev.txt']);
  assert.equal(matches.length, 2);
  assert.ok(matches.every(m => m.handler.ecosystem === 'pip'));
});

test('matches any project file extension .NET uses', () => {
  const matches = matchManifests(['src/App.csproj', 'src/Lib.fsproj', 'src/Old.vbproj']);
  assert.equal(matches.length, 3);
  assert.ok(matches.every(m => m.handler.ecosystem === 'nuget'));
});

test('does not treat a .csproj-shaped name inside another word as a project file', () => {
  assert.equal(matchManifests(['notes-about-csproj.md']).length, 0);
});

test('matches a support manifest that declares no dependencies of its own', () => {
  // Directory.Packages.props carries versions for other files to use, so it is
  // fetched for context but contributes no rows itself.
  const matches = matchManifests(['Directory.Packages.props']);
  assert.equal(matches.length, 1);
  assert.equal(matches[0].handler.support, true);
  assert.equal(matches[0].handler.ecosystem, undefined);
});

test('assigns Gradle and pom manifests to the same ecosystem', () => {
  const byPath = new Map(matchManifests(['pom.xml', 'build.gradle']).map(m => [m.path, m.handler.ecosystem]));
  assert.equal(byPath.get('pom.xml'), 'maven');
  assert.equal(byPath.get('build.gradle'), 'maven');
});

test('assigns every Python manifest to the pip ecosystem', () => {
  const matches = matchManifests(['requirements.txt', 'pyproject.toml', 'Pipfile']);
  assert.equal(matches.length, 3);
  assert.ok(matches.every(m => m.handler.ecosystem === 'pip'));
});

// ── vendored paths ──────────────────────────────────────────────────────────

test('skips manifests inside vendored directories', () => {
  // A committed vendor tree contributes dependencies the repo does not declare,
  // and would report another project's versions as this org's.
  for (const path of [
    'vendor/github.com/x/y/go.mod',
    'node_modules/left-pad/package.json',
    'third_party/lib/pom.xml',
    'testdata/fixtures/Cargo.toml',
    'target/classes/pom.xml',
  ]) {
    assert.equal(isVendoredPath(path), true, `${path} should be treated as vendored`);
    assert.equal(matchManifests([path]).length, 0, `${path} should not be matched`);
  }
});

test('does not treat a directory that merely starts with a vendored name as vendored', () => {
  assert.equal(isVendoredPath('vendored-libs/pom.xml'), false);
  assert.equal(matchManifests(['vendored-libs/pom.xml']).length, 1);
});

// ── untracked ecosystems ────────────────────────────────────────────────────

test('reports ecosystems that are detected but have no parser', () => {
  // An untracked stack must show up as a visible gap rather than as an empty
  // table indistinguishable from a repo with no dependencies.
  const labels = detectUntrackedEcosystems(['ios/Podfile', 'Dockerfile']);
  assert.ok(labels.includes('CocoaPods'));
  assert.ok(labels.includes('Docker'));
});

test('reports an untracked ecosystem once even when several of its files are present', () => {
  const labels = detectUntrackedEcosystems(['ios/Podfile', 'other/Podfile']);
  assert.deepEqual(labels.filter(l => l === 'CocoaPods').length, 1);
});

test('reports nothing untracked for a repo of fully supported manifests', () => {
  assert.deepEqual(detectUntrackedEcosystems(['pom.xml', 'package.json']), []);
});

test('ignores untracked manifests inside vendored directories', () => {
  assert.deepEqual(detectUntrackedEcosystems(['vendor/x/Podfile']), []);
});

// ── parse context ───────────────────────────────────────────────────────────

test('finds a support file in the manifest own directory', () => {
  const texts = new Map([
    ['src/App.csproj', '<Project/>'],
    ['src/Directory.Packages.props', 'props'],
  ]);
  const ctx = createParseContext('src/App.csproj', texts);
  assert.equal(ctx.findUp('Directory.Packages.props', t => t.toUpperCase()), 'PROPS');
});

test('walks up to an ancestor directory to find a support file', () => {
  // MSBuild discovers Directory.Packages.props by walking up from the project,
  // which is how a repo pins versions once for many projects.
  const texts = new Map([
    ['src/api/App.csproj', '<Project/>'],
    ['Directory.Packages.props', 'root props'],
  ]);
  const ctx = createParseContext('src/api/App.csproj', texts);
  assert.equal(ctx.findUp('Directory.Packages.props', t => t), 'root props');
});

test('prefers the nearest ancestor when several levels define the same support file', () => {
  const texts = new Map([
    ['src/api/App.csproj', '<Project/>'],
    ['src/Directory.Packages.props', 'nearer'],
    ['Directory.Packages.props', 'further'],
  ]);
  const ctx = createParseContext('src/api/App.csproj', texts);
  assert.equal(ctx.findUp('Directory.Packages.props', t => t), 'nearer');
});

test('returns null from findUp when no ancestor has the file', () => {
  const ctx = createParseContext('src/App.csproj', new Map([['src/App.csproj', '<Project/>']]));
  assert.equal(ctx.findUp('Directory.Packages.props', t => t), null);
});

test('finds a sibling file without walking up', () => {
  const texts = new Map([
    ['api/composer.json', '{}'],
    ['api/composer.lock', 'lock'],
    ['composer.lock', 'root lock'],
  ]);
  const ctx = createParseContext('api/composer.json', texts);
  assert.equal(ctx.sibling('composer.lock', t => t), 'lock');
});

test('returns null from sibling when only an ancestor has the file', () => {
  // A composer.lock one directory up belongs to a different project and would
  // report the wrong resolved versions.
  const texts = new Map([['api/composer.json', '{}'], ['composer.lock', 'root lock']]);
  const ctx = createParseContext('api/composer.json', texts);
  assert.equal(ctx.sibling('composer.lock', t => t), null);
});

test('returns null rather than throwing when a support file fails to parse', () => {
  // One malformed props file must not take down the manifest that referenced it.
  const texts = new Map([['App.csproj', '<Project/>'], ['Directory.Packages.props', 'not xml']]);
  const ctx = createParseContext('App.csproj', texts);
  assert.equal(ctx.findUp('Directory.Packages.props', () => { throw new Error('bad'); }), null);
});

// ── the remaining ecosystems ────────────────────────────────────────────────

test('matches every newly supported manifest to its ecosystem', () => {
  const expected = {
    'build.sbt': 'maven',            // sbt coordinates ARE maven coordinates
    'project/Dependencies.sbt': 'maven',
    'Package.swift': 'swift',
    'pubspec.yaml': 'pub',
    'mix.exs': 'hex',
    'conanfile.txt': 'conan',
    'conanfile.py': 'conan',
    'environment.yml': 'conda',
    'my-app.cabal': 'hackage',
    'stack.yaml': 'hackage',
    'cpanfile': 'cpan',
  };
  for (const [path, ecosystem] of Object.entries(expected)) {
    const matches = matchManifests([path]);
    assert.equal(matches.length, 1, `${path} should match exactly one handler`);
    assert.equal(matches[0].handler.ecosystem, ecosystem, `${path} should map to ${ecosystem}`);
  }
});

test('matches the lockfiles that supply exact versions as support manifests', () => {
  for (const path of ['Package.resolved', 'pubspec.lock', 'mix.lock']) {
    const matches = matchManifests([path]);
    assert.equal(matches.length, 1, `${path} should match`);
    assert.equal(matches[0].handler.support, true, `${path} should be a support manifest`);
  }
});

test('no longer reports a supported ecosystem as untracked', () => {
  // Every one of these now has a parser, so continuing to list them in the
  // footer would report a gap that no longer exists.
  const paths = ['build.sbt', 'Package.swift', 'pubspec.yaml', 'mix.exs',
                 'conanfile.txt', 'environment.yml', 'stack.yaml', 'cpanfile'];
  assert.deepEqual(detectUntrackedEcosystems(paths), []);
});

test('detects the project kinds that still have no parser', () => {
  // Widened so the next scan reports what else is actually in the org, rather
  // than us guessing which ecosystems matter.
  const labels = detectUntrackedEcosystems([
    'Dockerfile', '.github/workflows/ci.yml', 'main.tf', 'chart/Chart.yaml', 'DESCRIPTION', 'deno.json',
  ]);
  for (const expected of ['Docker', 'GitHub Actions', 'Terraform', 'Helm', 'R', 'Deno']) {
    assert.ok(labels.includes(expected), `expected ${expected} among ${JSON.stringify(labels)}`);
  }
});

test('does not mistake an arbitrary yaml file for a GitHub Actions workflow', () => {
  assert.deepEqual(detectUntrackedEcosystems(['config/settings.yml']), []);
});
