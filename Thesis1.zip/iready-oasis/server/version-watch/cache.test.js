'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { loadCache, saveCache, markChangedSinceLastScan } = require('./cache');

function tempCachePath() {
  return path.join(os.tmpdir(), `oasis-version-watch-test-${Date.now()}-${Math.random().toString(36).slice(2)}.json`);
}

test('loadCache returns an empty default when the file does not exist', () => {
  const result = loadCache(tempCachePath());
  assert.deepEqual(result, { lastScanAt: null, rows: [], scanSummary: null });
});

test('saveCache then loadCache round-trips the same data', () => {
  const cachePath = tempCachePath();
  const data = { lastScanAt: '2026-08-07T00:00:00.000Z', rows: [{ ecosystem: 'npm', package: 'lodash' }], scanSummary: { reposScanned: 3 } };
  saveCache(cachePath, data);
  assert.deepEqual(loadCache(cachePath), data);
  fs.unlinkSync(cachePath);
});

test('markChangedSinceLastScan flags a row whose latestVersion changed', () => {
  const previous = [{ ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.17.21', cves: [] }];
  const next = [{ ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.18.0', cves: [], status: {} }];
  const result = markChangedSinceLastScan(next, previous);
  assert.equal(result[0].status.changedSinceLastScan, true);
});

test('markChangedSinceLastScan flags a row whose latestMinorVersion changed even if latestVersion did not', () => {
  const previous = [{ ecosystem: 'maven', package: 'g:a', versionInUse: '2.9.0', latestVersion: '3.0.0', latestMinorVersion: '2.9.5', cves: [] }];
  const next = [{ ecosystem: 'maven', package: 'g:a', versionInUse: '2.9.0', latestVersion: '3.0.0', latestMinorVersion: '2.10.0', cves: [], status: {} }];
  const result = markChangedSinceLastScan(next, previous);
  assert.equal(result[0].status.changedSinceLastScan, true);
});

test('markChangedSinceLastScan flags a row whose latestPatchVersion changed even if the other tiers did not', () => {
  const previous = [{ ecosystem: 'maven', package: 'g:a', versionInUse: '1.2.3', latestVersion: '3.0.1', latestMinorVersion: '1.9.4', latestPatchVersion: '1.2.8', cves: [] }];
  const next = [{ ecosystem: 'maven', package: 'g:a', versionInUse: '1.2.3', latestVersion: '3.0.1', latestMinorVersion: '1.9.4', latestPatchVersion: '1.2.9', cves: [], status: {} }];
  const result = markChangedSinceLastScan(next, previous);
  assert.equal(result[0].status.changedSinceLastScan, true);
});

test('markChangedSinceLastScan does not flag an identical row', () => {
  const previous = [{ ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.18.0', cves: [] }];
  const next = [{ ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.18.0', cves: [], status: {} }];
  const result = markChangedSinceLastScan(next, previous);
  assert.equal(result[0].status.changedSinceLastScan, false);
});

test('markChangedSinceLastScan does not flag anything as changed on the very first scan ever (no scan history at all)', () => {
  const result = markChangedSinceLastScan(
    [{ ecosystem: 'npm', package: 'new-pkg', versionInUse: '1.0.0', latestVersion: '1.0.0', cves: [], status: {} }],
    []
  );
  // There is nothing to compare against yet — a brand-new tool run should
  // never present every row as "changed" on its very first scan.
  assert.equal(result[0].status.changedSinceLastScan, false);
});

test('markChangedSinceLastScan flags a genuinely new row that appeared since a REAL previous scan', () => {
  const previous = [
    { ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.17.21', cves: [] },
  ];
  const next = [
    { ecosystem: 'npm', package: 'lodash', versionInUse: '4.17.21', latestVersion: '4.17.21', cves: [], status: {} },
    { ecosystem: 'npm', package: 'new-pkg', versionInUse: '1.0.0', latestVersion: '1.0.0', cves: [], status: {} },
  ];
  const result = markChangedSinceLastScan(next, previous);
  // A dependency that wasn't in the last real scan but is now IS a real
  // change worth flagging — unlike the "no scan history at all yet" case.
  assert.equal(result.find(r => r.package === 'new-pkg').status.changedSinceLastScan, true);
  assert.equal(result.find(r => r.package === 'lodash').status.changedSinceLastScan, false);
});

test('markChangedSinceLastScan uses the same collision-safe key as dedupe.js — rows that would collide under a `::`-joined key stay distinct', () => {
  // { package: 'a', versionInUse: 'b::c' } and { package: 'a::b', versionInUse: 'c' }
  // both produce the string "npm::a::b::c" under the old delimiter-joined
  // scheme, but are two distinct rows.
  const previous = [
    { ecosystem: 'npm', package: 'a', versionInUse: 'b::c', latestVersion: '1.0.0', cves: [] },
  ];
  const next = [
    { ecosystem: 'npm', package: 'a', versionInUse: 'b::c', latestVersion: '1.0.0', cves: [], status: {} },
    { ecosystem: 'npm', package: 'a::b', versionInUse: 'c', latestVersion: '9.9.9', cves: [], status: {} },
  ];
  const result = markChangedSinceLastScan(next, previous);

  const matched = result.find(r => r.package === 'a' && r.versionInUse === 'b::c');
  const unmatched = result.find(r => r.package === 'a::b' && r.versionInUse === 'c');

  // The row matching the previous scan's tuple exactly is unchanged...
  assert.equal(matched.status.changedSinceLastScan, false);
  // ...while the other tuple has no counterpart in the previous scan, so it's
  // correctly treated as new/changed, rather than the two being merged into
  // one key and one of them silently matching the wrong previous row.
  assert.equal(unmatched.status.changedSinceLastScan, true);
});

test('markChangedSinceLastScan preserves other status fields already set on the row', () => {
  const result = markChangedSinceLastScan(
    [{ ecosystem: 'npm', package: 'x', versionInUse: '1.0.0', latestVersion: '1.0.0', cves: [], status: { needsUpgrade: true, upToDate: true } }],
    []
  );
  assert.equal(result[0].status.needsUpgrade, true);
  assert.equal(result[0].status.upToDate, true);
});
