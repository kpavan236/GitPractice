'use strict';

// Comment strippers shared by the parsers whose manifests are source code
// rather than a data format (Gradle, sbt, Swift, Elixir).
//
// Both are quote-aware, which is the whole point: a naive strip would cut
// `maven { url 'https://repo.test' }` at the "//" in the URL, and would cut an
// Elixir string containing a "#".

// Removes // line comments and /* */ block comments.
function stripSlashComments(text) {
  const source = String(text);
  let out = '';
  let quote = null;
  let i = 0;
  while (i < source.length) {
    const ch = source[i];
    if (quote) {
      out += ch;
      if (ch === '\\') { out += source[i + 1] ?? ''; i += 2; continue; }
      if (ch === quote) quote = null;
      i++;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; out += ch; i++; continue; }
    if (ch === '/' && source[i + 1] === '/') {
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && source[i + 1] === '*') {
      i += 2;
      while (i < source.length && !(source[i] === '*' && source[i + 1] === '/')) i++;
      i += 2;
      continue;
    }
    out += ch;
    i++;
  }
  return out;
}

// Removes # line comments.
function stripHashComments(text) {
  const source = String(text);
  let out = '';
  let quote = null;
  let i = 0;
  while (i < source.length) {
    const ch = source[i];
    if (quote) {
      out += ch;
      if (ch === '\\') { out += source[i + 1] ?? ''; i += 2; continue; }
      if (ch === quote) quote = null;
      i++;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; out += ch; i++; continue; }
    if (ch === '#') {
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    out += ch;
    i++;
  }
  return out;
}

module.exports = { stripSlashComments, stripHashComments };
