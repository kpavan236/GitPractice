'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseSwiftPackage, parsePackageResolved } = require('./parse-swift');

test('reads a package dependency declared with from', () => {
  const manifest = `
dependencies: [
    .package(url: "https://github.com/apple/swift-log.git", from: "1.5.3"),
]
`;
  const { dependencies } = parseSwiftPackage(manifest);
  assert.deepStrictEqual(dependencies, [
    { name: 'https://github.com/apple/swift-log.git', version: '1.5.3', versionIsRange: true },
  ]);
});

test('reads a package dependency declared with exact', () => {
  const manifest = '.package(url: "https://github.com/apple/swift-nio.git", exact: "2.62.0")';
  const { dependencies } = parseSwiftPackage(manifest);
  assert.deepStrictEqual(dependencies, [
    { name: 'https://github.com/apple/swift-nio.git', version: '2.62.0' },
  ]);
});

test('reads the lower bound of an upToNextMajor requirement', () => {
  const manifest = '.package(url: "https://github.com/x/y.git", .upToNextMajor(from: "3.1.0"))';
  const { dependencies } = parseSwiftPackage(manifest);
  assert.strictEqual(dependencies[0].version, '3.1.0');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('reads the lower bound of a version range', () => {
  const manifest = '.package(url: "https://github.com/x/y.git", "1.2.0"..<"2.0.0")';
  const { dependencies } = parseSwiftPackage(manifest);
  assert.strictEqual(dependencies[0].version, '1.2.0');
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('counts a branch requirement as unresolved', () => {
  // A branch is not a release, so there is no version to compare.
  const manifest = '.package(url: "https://github.com/x/y.git", branch: "main")';
  const { dependencies, unresolvedCount } = parseSwiftPackage(manifest);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('counts a revision requirement as unresolved', () => {
  const manifest = '.package(url: "https://github.com/x/y.git", revision: "abc123")';
  const { unresolvedCount } = parseSwiftPackage(manifest);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores a local path dependency', () => {
  const manifest = '.package(path: "../SiblingPackage")';
  const { dependencies, unresolvedCount } = parseSwiftPackage(manifest);
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('prefers the exact version pinned in Package.resolved', () => {
  const manifest = '.package(url: "https://github.com/apple/swift-log.git", from: "1.5.0")';
  const resolved = { pinsVersions: { 'https://github.com/apple/swift-log.git': '1.5.3' } };
  const { dependencies } = parseSwiftPackage(manifest, resolved);
  assert.deepStrictEqual(dependencies, [
    { name: 'https://github.com/apple/swift-log.git', version: '1.5.3' },
  ]);
});

test('reads pins from the v2 Package.resolved format', () => {
  const resolved = JSON.stringify({
    pins: [{ identity: 'swift-log', location: 'https://github.com/apple/swift-log.git', state: { version: '1.5.3' } }],
    version: 2,
  });
  assert.deepStrictEqual(parsePackageResolved(resolved), {
    'https://github.com/apple/swift-log.git': '1.5.3',
  });
});

test('reads pins from the v1 Package.resolved format', () => {
  const resolved = JSON.stringify({
    object: { pins: [{ package: 'swift-log', repositoryURL: 'https://github.com/apple/swift-log.git', state: { version: '1.5.3' } }] },
    version: 1,
  });
  assert.deepStrictEqual(parsePackageResolved(resolved), {
    'https://github.com/apple/swift-log.git': '1.5.3',
  });
});

test('ignores a pin with no resolved version', () => {
  // A branch-pinned entry records a revision but no version.
  const resolved = JSON.stringify({ pins: [{ location: 'https://x/y.git', state: { revision: 'abc' } }] });
  assert.deepStrictEqual(parsePackageResolved(resolved), {});
});

test('returns no dependencies for a manifest with none', () => {
  assert.deepStrictEqual(parseSwiftPackage('let package = Package(name: "X")'), {
    dependencies: [], unresolvedCount: 0,
  });
});
