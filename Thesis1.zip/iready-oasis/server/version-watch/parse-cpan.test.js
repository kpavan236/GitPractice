'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const { parseCpanfile } = require('./parse-cpan');

test('reads a requires line with a version', () => {
  // Flagged as a range even though no operator is written: CPAN reads a bare
  // version as "this or newer", so the value is a floor rather than a pin.
  const cpanfile = "requires 'Plack', '1.0048';";
  const { dependencies } = parseCpanfile(cpanfile);
  assert.deepStrictEqual(dependencies, [{ name: 'Plack', version: '1.0048', versionIsRange: true }]);
});

test('reads several requirement kinds', () => {
  const cpanfile = `
requires 'Plack', '1.0048';
test_requires 'Test::More', '0.98';
recommends 'JSON::XS', '4.03';
`;
  const { dependencies } = parseCpanfile(cpanfile);
  assert.deepStrictEqual(dependencies.map(d => d.name).sort(), ['JSON::XS', 'Plack', 'Test::More']);
});

test('reads a double-quoted module name', () => {
  const { dependencies } = parseCpanfile('requires "Moose", "2.2015";');
  assert.deepStrictEqual(dependencies, [{ name: 'Moose', version: '2.2015', versionIsRange: true }]);
});

test('treats a minimum-version requirement as a range', () => {
  // CPAN reads a bare version as "this or newer", so it is a floor.
  const { dependencies } = parseCpanfile("requires 'Plack', '>= 1.0048';");
  assert.strictEqual(dependencies[0].versionIsRange, true);
});

test('counts a requirement with no version as unresolved', () => {
  const { dependencies, unresolvedCount } = parseCpanfile("requires 'Plack';");
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('treats a zero version as no constraint', () => {
  // "requires 'Plack', '0'" is the idiomatic way to say "any version".
  const { dependencies, unresolvedCount } = parseCpanfile("requires 'Plack', '0';");
  assert.deepStrictEqual(dependencies, []);
  assert.strictEqual(unresolvedCount, 1);
});

test('ignores a comment', () => {
  const cpanfile = `
# requires 'Removed', '1.0';
requires 'Kept', '2.0';
`;
  const { dependencies } = parseCpanfile(cpanfile);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['Kept']);
});

test('ignores a perl version requirement', () => {
  const { dependencies } = parseCpanfile("requires 'perl', '5.032';\nrequires 'Plack', '1.0048';");
  assert.deepStrictEqual(dependencies.map(d => d.name), ['Plack']);
});

test('reads requirements inside an on block', () => {
  const cpanfile = `
on 'test' => sub {
    requires 'Test::More', '0.98';
};
`;
  const { dependencies } = parseCpanfile(cpanfile);
  assert.deepStrictEqual(dependencies.map(d => d.name), ['Test::More']);
});

test('returns no dependencies for an empty cpanfile', () => {
  assert.deepStrictEqual(parseCpanfile(''), { dependencies: [], unresolvedCount: 0 });
});
