'use strict';
const { stripHashComments } = require('./strip-comments');
const { isRangeDeclaration } = require('./compare-versions');

// Matches a Mix dependency tuple: {:name, ...}. The options part stops at the
// closing brace, which is sufficient because Mix options use keyword lists in
// square brackets (`only: [:dev, :test]`) rather than nested braces.
const MIX_DEPENDENCY = /\{\s*:([a-z_][\w?!]*)\s*,([^}]*)\}/g;

// Parses mix.exs dependency tuples.
//
// Lossy in the same way as Gradle and sbt — mix.exs is Elixir code, and a
// version held in a module attribute is not resolvable from the file alone.
//
// `ctx.lockVersions`, read from a sibling mix.lock, replaces a declared
// requirement with the version actually resolved.
function parseMixExs(text, ctx = {}) {
  const lockVersions = ctx.lockVersions || {};
  const source = stripHashComments(text);

  const byKey = new Map();
  let unresolvedCount = 0;

  for (const match of source.matchAll(MIX_DEPENDENCY)) {
    const [, name, rawOptions] = match;
    const options = rawOptions.trim();

    const locked = lockVersions[name];
    if (locked) { byKey.set(`${name}:${locked}`, { name, version: locked }); continue; }

    // A version requirement is always the first element after the name. When the
    // options start with a keyword instead (git:, path:, in_umbrella:), this is
    // not a Hex release — checking position rather than scanning for any quoted
    // string is what keeps a git URL from being read as a version.
    const requirement = options.startsWith('"') ? options.match(/^"([^"]*)"/)?.[1] : null;
    if (!requirement || !/\d/.test(requirement)) { unresolvedCount++; continue; }

    const entry = isRangeDeclaration(requirement)
      ? { name, version: requirement, versionIsRange: true }
      : { name, version: requirement };
    byKey.set(`${name}:${requirement}`, entry);
  }

  return { dependencies: [...byKey.values()], unresolvedCount };
}

// Reads mix.lock into { packageName: exactVersion }, keeping only :hex entries.
// A :git entry has no Hex release to compare against.
//
// mix.lock is an Elixir map literal whose values are tuples:
//   "phoenix": {:hex, :phoenix, "1.7.11", "checksum", [:mix], [], "hexpm", ...}
const MIX_LOCK_HEX_ENTRY = /"([^"]+)"\s*:\s*\{\s*:hex\s*,\s*:\w+\s*,\s*"([^"]+)"/g;

function parseMixLock(text) {
  const versions = {};
  for (const match of String(text).matchAll(MIX_LOCK_HEX_ENTRY)) {
    versions[match[1]] = match[2];
  }
  return versions;
}

module.exports = { parseMixExs, parseMixLock };
