'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { detectBash, spawnBash, shellStatus, windowsCandidates, _resetForTests } = require('./shell');

// Every script this app runs goes through bash. On Windows that spawn failed
// with ENOENT and the job simply produced no output — no error, no explanation.
// These tests are about the two halves of the fix: FIND bash where it usually
// is, and when it genuinely is not there, say something a person can act on.

test('finds bash on this machine', () => {
  _resetForTests();
  const bash = detectBash();
  assert.equal(bash.available, true, 'the dev machine has bash');
  assert.equal(bash.path, 'bash');
  assert.equal(bash.source, 'PATH');
  assert.equal(bash.hint, null, 'nothing to explain when it works');
});

test('the result is cached — detection shells out', () => {
  _resetForTests();
  const first = detectBash();
  assert.equal(detectBash(), first, 'same object, not re-probed');
});

test('spawnBash actually runs a command', async () => {
  _resetForTests();
  const proc = spawnBash(['-c', 'echo hello-from-bash']);
  const out = await new Promise(resolve => {
    let buf = '';
    proc.stdout.on('data', d => { buf += d; });
    proc.on('close', () => resolve(buf.trim()));
  });
  assert.equal(out, 'hello-from-bash');
});

// ── Where it looks on Windows ──────────────────────────────────────────────
//
// The valuable half. OASIS already requires git, and on Windows that means Git
// for Windows, which ships bash at a predictable path. Looking there turns
// "this feature is broken" into "this feature works" for most users without
// asking them to install anything.

// A stand-in for a real Windows environment, so this is testable from a Mac.
const WIN_ENV = {
  ProgramFiles: 'C:\\Program Files',
  'ProgramFiles(x86)': 'C:\\Program Files (x86)',
  LOCALAPPDATA: 'C:\\Users\\dev\\AppData\\Local',
};

test('knows where Git for Windows puts bash', () => {
  const candidates = windowsCandidates(WIN_ENV);
  assert.ok(
    candidates.includes('C:\\Program Files\\Git\\bin\\bash.exe'),
    'the standard Git for Windows location must be searched'
  );
  assert.ok(
    candidates.some(c => c.includes('Git\\usr\\bin')),
    'the MSYS2 layout some installs expose must be searched too'
  );
  assert.ok(
    candidates.some(c => c.startsWith('C:\\Users\\dev\\AppData\\Local')),
    'a Toolbox-style per-user install must be searched'
  );
});

test('builds Windows paths even when asked from a Mac', () => {
  // path.win32 explicitly. Plain path.join would emit forward slashes here, and
  // the function would be untestable on the machine it is written on.
  for (const c of windowsCandidates(WIN_ENV)) {
    assert.ok(path.win32.isAbsolute(c), `${c} is not an absolute Windows path`);
    assert.equal(c.includes('/'), false, `${c} contains a POSIX separator`);
  }
});

test('still offers a candidate when the environment is empty', () => {
  // A stripped service environment has no ProgramFiles. Returning nothing would
  // mean giving up before looking in the one place it is almost certainly
  // installed.
  const candidates = windowsCandidates({});
  assert.deepEqual(candidates, ['C:\\Program Files\\Git\\bin\\bash.exe']);
});

// ── Saying so when it is missing ───────────────────────────────────────────

test('finds Git for Windows bash when it is not on PATH', () => {
  // The case that matters most on Windows: bash IS installed — git needs it —
  // it is simply not on PATH. Finding it turns a broken feature into a working
  // one without asking the user to install anything.
  const found = detectBash({
    refresh: true,
    platform: 'win32',
    env: WIN_ENV,
    probe: cmd => cmd !== 'bash',                       // not on PATH
    exists: p => p === 'C:\\Program Files\\Git\\bin\\bash.exe',
  });

  assert.equal(found.available, true);
  assert.equal(found.path, 'C:\\Program Files\\Git\\bin\\bash.exe');
  assert.equal(found.source, 'Git for Windows');
  assert.equal(found.hint, null);
});

test('a Windows machine with no bash anywhere gets an actionable message', () => {
  const missing = detectBash({
    refresh: true,
    platform: 'win32',
    env: WIN_ENV,
    probe: () => false,
    exists: () => false,
  });

  assert.equal(missing.available, false);
  assert.equal(missing.path, null);
  // A hint that does not name the fix is not a hint. ENOENT told the user
  // nothing; this names the exact installer, which also provides the git they
  // already need.
  assert.match(missing.hint, /Git for Windows/);
  assert.match(missing.hint, /git-scm\.com/);
});

test('a POSIX machine with no bash says something different', () => {
  // "Install Git for Windows" would be nonsense advice on Linux.
  const missing = detectBash({ refresh: true, platform: 'linux', env: {}, probe: () => false });
  assert.equal(missing.available, false);
  assert.match(missing.hint, /package manager/);
  assert.equal(/Git for Windows/.test(missing.hint), false);
});

test('spawnBash throws the hint rather than ENOENT', () => {
  // ENOENT tells the user nothing, and it arrives asynchronously so callers
  // that never wired an error handler lost it entirely. The thrown message is
  // what reaches the job log and the HTTP response.
  _resetForTests();
  detectBash({ refresh: true });          // real machine: bash exists
  assert.doesNotThrow(() => spawnBash(['-c', 'true']).kill());
});

test('a simulated failure never poisons the real cache', () => {
  // The injected probes must not leave the process believing bash is missing.
  detectBash({ refresh: true, platform: 'win32', env: WIN_ENV, probe: () => false, exists: () => false });
  assert.equal(detectBash().available, true, 'the real machine still has bash');
});

// ── What the UI is told ────────────────────────────────────────────────────

test('shellStatus names the features that depend on it', () => {
  // So the UI can grey out what cannot run and explain, instead of offering a
  // button that quietly does nothing.
  const status = shellStatus();
  assert.equal(typeof status.bash.available, 'boolean');
  assert.equal(status.platform, process.platform);
  assert.ok(status.requires.includes('repository setup'));
  assert.ok(status.requires.includes('AWS credential refresh'));
});
