'use strict';
const fs    = require('fs');
const path  = require('path');
const os    = require('os');
const https = require('https');
const axios = require('axios');
const { execSync } = require('child_process');

const JIRA_HISTORY_PATH = path.join(os.homedir(), '.oasis-jira.json');
const JIRA_HTTPS_AGENT  = new https.Agent({ rejectUnauthorized: false });

/**
 * Fetch all issues matching a JQL query, transparently handling both:
 *  - The new enhanced search endpoint (/rest/api/3/search/jql) which replaced
 *    the legacy one that Atlassian removed (returns 410 Gone). Uses token-based
 *    pagination (nextPageToken / isLast) and has no `total`.
 *  - The legacy endpoint (/rest/api/2/search) on older Jira Server/DC, which
 *    uses startAt/total pagination.
 * Tries the new endpoint first; falls back to legacy on 404/410.
 *
 * Exported so other modules that query Jira can share this pagination/
 * fallback logic.
 *
 * `expand` is optional (e.g. 'changelog' to include status/assignee history).
 * The enhanced endpoint takes it as a string, the legacy one as an array.
 */
async function jiraSearchAll(base, auth, jql, fields, expand) {
  const MAX = 5000;  // safety cap
  const cfg = { auth, timeout: 30000, httpsAgent: JIRA_HTTPS_AGENT };

  // ── Attempt 1: enhanced JQL search (Jira Cloud, post-2025) ────────────────
  try {
    const all = [];
    let nextPageToken;
    do {
      const body = { jql, fields, maxResults: 100 };
      if (expand) body.expand = expand;
      if (nextPageToken) body.nextPageToken = nextPageToken;
      const r = await axios.post(`${base}/rest/api/3/search/jql`, body, cfg);
      const issues = r.data.issues || [];
      all.push(...issues);
      nextPageToken = r.data.isLast ? null : r.data.nextPageToken;
    } while (nextPageToken && all.length < MAX);
    return all;
  } catch (e) {
    const s = e.response?.status;
    // Only fall back when the endpoint itself isn't available; rethrow auth errors
    if (s !== 404 && s !== 410) throw e;
  }

  // ── Attempt 2: legacy search (Jira Server / Data Center) ──────────────────
  const all = [];
  let startAt = 0;
  while (all.length < MAX) {
    const legacyBody = { jql, fields, maxResults: 100, startAt };
    if (expand) legacyBody.expand = [expand];
    const r = await axios.post(`${base}/rest/api/2/search`, legacyBody, cfg);
    const issues = r.data.issues || [];
    all.push(...issues);
    if (all.length >= (r.data.total ?? all.length) || issues.length < 100) break;
    startAt += 100;
  }
  return all;
}

function installJira(app, { sessions, expandHome, execQuiet, isProjectDir, findOpenPrForBranch, findMergedPrForBranch, PREFS_PATH, externalCalls }) {

  function detectJiraEmail() {
    try {
      const email = execSync('git config user.email', { encoding: 'utf8', timeout: 3000 }).trim();
      if (email && email.includes('@')) return email;
    } catch (_) {}
    return '';
  }

  function loadJiraHistory() {
    try {
      if (!fs.existsSync(JIRA_HISTORY_PATH)) return { tickets: {}, sprints: {}, lastSync: null };
      return JSON.parse(fs.readFileSync(JIRA_HISTORY_PATH, 'utf8')) || { tickets: {}, sprints: {}, lastSync: null };
    } catch (_) { return { tickets: {}, sprints: {}, lastSync: null }; }
  }
  function saveJiraHistory(data) {
    try { fs.writeFileSync(JIRA_HISTORY_PATH, JSON.stringify(data, null, 2), 'utf8'); } catch (_) {}
  }

  // Parse the sprint custom field — handles Jira Cloud objects and old string format
  function parseSprintField(sprintField) {
    if (!sprintField) return null;
    const arr = Array.isArray(sprintField) ? sprintField : [sprintField];
    const raw = arr[arr.length - 1];
    if (!raw) return null;
    if (typeof raw === 'object' && raw.id) {
      return { id: raw.id, name: raw.name || `Sprint ${raw.id}`,
               state: (raw.state || '').toLowerCase(),
               startDate: raw.startDate || null, endDate: raw.endDate || null };
    }
    if (typeof raw === 'string') {
      const id    = raw.match(/id=(\d+)/)?.[1];
      const name  = raw.match(/name=([^,\]]+)/)?.[1];
      const state = raw.match(/state=([A-Z]+)/)?.[1]?.toLowerCase();
      const start = raw.match(/startDate=([^,\]]+)/)?.[1];
      const end   = raw.match(/endDate=([^,\]]+)/)?.[1];
      if (id && name) return { id: parseInt(id), name, state: state || 'unknown', startDate: start || null, endDate: end || null };
    }
    return null;
  }

  // Infer PI from fixVersions or labels
  function extractPI(issue) {
    const fv = issue.fields?.fixVersions;
    if (Array.isArray(fv)) {
      for (const v of fv) { if (/^PI[\s_-]?\d/i.test(v.name || '')) return v.name; }
    }
    for (const l of (issue.fields?.labels || [])) { if (/^PI[\s_-]?\d/i.test(l)) return l; }
    return null;
  }

  // Detect which customfield holds Sprint data by scanning the issue's fields.
  // The Sprint field id varies per Jira instance (commonly 10020, but not always).
  function findSprintField(fields) {
    for (const [key, val] of Object.entries(fields)) {
      if (!key.startsWith('customfield_') || val == null) continue;
      const arr = Array.isArray(val) ? val : [val];
      const sample = arr[0];
      if (sample && typeof sample === 'object' && (sample.state || sample.boardId) && sample.name) return key;
      if (typeof sample === 'string' && /greenhopper|sprint/i.test(sample) && /id=\d+/.test(sample)) return key;
    }
    return null;
  }

  // Detect a Story Points field: a numeric customfield (best-effort fallback).
  function findPointsField(fields, preferred) {
    if (preferred && typeof fields[preferred] === 'number') return preferred;
    for (const cf of ['customfield_10016', 'customfield_10026', 'customfield_10002']) {
      if (typeof fields[cf] === 'number') return cf;
    }
    return preferred || 'customfield_10016';
  }

  // Normalize a Jira issue to our storage format
  function extractTicketData(issue, pointsField) {
    const f  = issue.fields || {};
    const sprintKey = findSprintField(f);
    const sp = sprintKey ? parseSprintField(f[sprintKey]) : null;
    const pKey = findPointsField(f, pointsField);
    const pts = f[pKey] ?? f.story_points ?? null;
    return {
      key:           issue.key,
      summary:       f.summary || '',
      type:          f.issuetype?.name || 'Unknown',
      status:        f.status?.name || 'Unknown',
      statusCat:     f.status?.statusCategory?.key || 'new',   // new | indeterminate | done
      priority:      f.priority?.name || 'Medium',
      // Sync's JQL pulls in tickets via "assignee WAS" too (see /api/jira/sync),
      // so a ticket here may no longer actually be assigned to the connected
      // user — the client uses this to drop stale, reassigned "To Do" tickets.
      assigneeAccountId: f.assignee?.accountId || f.assignee?.name || null,
      assigneeName:      f.assignee?.displayName || '',
      points:        typeof pts === 'number' ? pts : (parseFloat(pts) || null),
      sprint:        sp?.name  || null,
      sprintId:      sp?.id    || null,
      sprintState:   sp?.state || null,
      pi:            extractPI(issue),
      labels:        f.labels || [],
      components:    (f.components || []).map(c => c.name),
      created:       f.created       || null,
      updated:       f.updated       || null,
      resolvedDate:  f.resolutiondate || null,
    };
  }

  /**
   * POST /api/jira/connect — validate JIRA credentials and store in session
   * Body: { session, jiraUrl, jiraEmail, jiraToken, pointsField? }
   */
  app.post('/api/jira/connect', async (req, res) => {
    const { session, jiraUrl, jiraToken, jiraPointsField, pointsField, restore } = req.body;
    const jiraEmail = req.body.jiraEmail || detectJiraEmail();
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!jiraUrl || !jiraToken)
      return res.status(400).json({ error: 'jiraUrl and jiraToken are required' });

    const base = jiraUrl.replace(/\/$/, '');

    // Fast restore path — called on app restart to rehydrate session from saved prefs
    // without making an external API call (avoids cert/network issues at startup)
    if (restore) {
      const prefs = fs.existsSync(PREFS_PATH) ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {}) : {};
      sess.jiraUrl         = base;
      sess.jiraEmail       = prefs.jiraEmail       || jiraEmail;
      sess.jiraToken       = jiraToken;
      sess.jiraPointsField = prefs.jiraPointsField || jiraPointsField || pointsField || 'customfield_10016';
      sess.jiraAccountId   = prefs.jiraAccountId   || req.body.jiraAccountId || sess.jiraEmail;
      sess.jiraDisplayName = prefs.jiraDisplayName || req.body.jiraDisplayName || sess.jiraEmail;
      return res.json({ ok: true, displayName: sess.jiraDisplayName, accountId: sess.jiraAccountId });
    }

    try {
      const r = await axios.get(`${base}/rest/api/2/myself`,
        { auth: { username: jiraEmail, password: jiraToken }, timeout: 12000, httpsAgent: JIRA_HTTPS_AGENT });
      const me = r.data;
      sess.jiraUrl          = base;
      sess.jiraEmail        = jiraEmail;
      sess.jiraToken        = jiraToken;
      sess.jiraPointsField  = jiraPointsField || pointsField || 'customfield_10016';
      sess.jiraAccountId    = me.accountId || me.name || jiraEmail;
      sess.jiraDisplayName  = me.displayName || me.name || jiraEmail;

      try {
        const prefs = fs.existsSync(PREFS_PATH) ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {}) : {};
        Object.assign(prefs, { jiraUrl: base, jiraEmail, jiraPointsField: sess.jiraPointsField,
                                jiraAccountId: sess.jiraAccountId, jiraDisplayName: sess.jiraDisplayName });
        fs.writeFileSync(PREFS_PATH, JSON.stringify(prefs, null, 2), 'utf8');
      } catch (_) {}

      res.json({ ok: true, displayName: sess.jiraDisplayName, accountId: sess.jiraAccountId });
    } catch (e) {
      const s = e.response?.status;
      res.status(400).json({ error:
        s === 401 || s === 403 ? 'Authentication failed — check your email and API token'
        : `Could not reach JIRA (${s || e.code || e.message})` });
    }
  });

  /**
   * GET /api/jira/status — is JIRA configured for this session?
   */
  app.get('/api/jira/status', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    res.json({ configured: !!(sess.jiraUrl && sess.jiraToken),
               jiraUrl: sess.jiraUrl || null, jiraEmail: sess.jiraEmail || null });
  });

  /**
   * POST /api/jira/sync — fetch all user tickets from Jira, merge into local history
   * Body: { session }
   */
  app.post('/api/jira/sync', async (req, res) => {
    // The 5-minute automatic sync sends `auto: true`; it is refused while the switch is off.
    // The Sync button does not send it, so a person can still sync by hand.
    if (externalCalls.refuseAutomatic(req, res, 'JIRA background')) return;
    const { session } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!sess.jiraUrl || !sess.jiraToken) return res.status(400).json({ error: 'JIRA not configured' });

    const base      = sess.jiraUrl;
    const auth      = { username: sess.jiraEmail, password: sess.jiraToken };
    const pf        = sess.jiraPointsField || 'customfield_10016';
    const accountId = sess.jiraAccountId || sess.jiraEmail;
    const jql        = `(assignee = "${accountId}" OR assignee WAS "${accountId}") ORDER BY updated DESC`;
    // Request all fields so the Sprint/Story-Points customfields are detected
    // regardless of their per-instance IDs (needed for insights).
    const fieldsList = ['*all'];

    try {
      const allIssues = await jiraSearchAll(base, auth, jql, fieldsList);

      const history = loadJiraHistory();
      for (const issue of allIssues) {
        const t = extractTicketData(issue, pf);
        history.tickets[t.key] = t;
        if (t.sprintId && t.sprint) {
          // Always refresh — a sprint's state changes over time (active → closed),
          // so overwrite rather than keep the first-seen value.
          history.sprints[t.sprintId] = { id: t.sprintId, name: t.sprint, state: t.sprintState };
        }
      }
      history.lastSync = new Date().toISOString();
      saveJiraHistory(history);

      res.json({ ok: true, synced: allIssues.length,
                 total: Object.keys(history.tickets).length, lastSync: history.lastSync });
    } catch (e) {
      const s = e.response?.status;
      res.status(400).json({ error:
        s === 401 || s === 403 ? 'JIRA auth failed — reconnect in Settings'
        : `Sync failed (${s || e.code || ''}): ${e.message?.slice(0, 120)}` });
    }
  });

  /**
   * GET /api/jira/ticket-work?session=SID&keys=PROJ-1,PROJ-2
   * For each ticket key, finds cloned repos with a local branch whose name
   * contains the key (case-insensitive) and returns PR + Jenkins status + pull
   * behind-count so the UI can show "up to date" or "N commits behind".
   * Response: { "PROJ-1": [{ repo, branch, current, behind, pr, jenkins }], ... }
   */
  app.get('/api/jira/ticket-work', async (req, res) => {
    const { session, keys: keysParam } = req.query;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    const keys = String(keysParam || '').split(',').map(k => k.trim()).filter(Boolean);
    if (!keys.length) return res.json({});

    const base = expandHome(sess.cloneDir || '~/dev/projects');
    if (!fs.existsSync(base)) return res.json({});

    // ── Step 1: scan repos for the ticket key in branch names + recent commits ──
    // Processed in batches of 12 to avoid exhausting OS file-descriptor limits.
    const matches = {};
    keys.forEach(k => { matches[k] = []; });
    const keysLc = keys.map(k => k.toLowerCase());

    let repoDirs = [];
    try { repoDirs = fs.readdirSync(base).filter(d => {
      return isProjectDir(base, d);
    }); } catch (_) {}

    const BATCH = 12;
    for (let bi = 0; bi < repoDirs.length; bi += BATCH) {
      await Promise.all(repoDirs.slice(bi, bi + BATCH).map(async repo => {
        const dir = path.join(base, repo);
        const seen = new Set();
        const add = (i, branch, current) => {
          const tag = `${keys[i]}|${branch}`;
          if (seen.has(tag)) return;
          seen.add(tag);
          matches[keys[i]].push({ repo, branch, current });
        };

        // (a) local branches
        let localBranches = [], currentBranch = '';
        try {
          const raw = await execQuiet(`git -C "${dir}" branch --format="%(refname:short)|%(HEAD)"`, { timeout: 6000 });
          raw.split('\n').filter(Boolean).forEach(line => {
            const [name, head] = line.split('|');
            const nm = (name || '').trim();
            const cur = (head || '').trim() === '*';
            if (cur) currentBranch = nm;
            localBranches.push({ name: nm, current: cur });
          });
        } catch (_) {}

        // (b) remote-tracking branches
        let remoteBranches = [];
        try {
          const raw = await execQuiet(`git -C "${dir}" branch -r --format="%(refname:short)"`, { timeout: 6000 });
          remoteBranches = raw.split('\n').map(s => s.trim())
            .filter(s => s && !s.endsWith('/HEAD'))
            .map(s => s.replace(/^origin\//, ''));
        } catch (_) {}

        for (const b of localBranches) {
          const bl = b.name.toLowerCase();
          keysLc.forEach((kl, i) => { if (bl.includes(kl)) add(i, b.name, b.current); });
        }
        for (const name of remoteBranches) {
          const bl = name.toLowerCase();
          keysLc.forEach((kl, i) => { if (bl.includes(kl)) add(i, name, name === currentBranch); });
        }

        // A ticket's branches are matched by branch NAME only (steps a + b).
        // We intentionally do NOT scan commit subjects: a branch cut from another
        // ticket's branch (e.g. AVG-6980 off AVG-6882) inherits its commit history,
        // and integration branches (main/develop) carry every ticket's commits —
        // both cause one ticket's branches to leak into another ticket's card.
      }));
    }

    // ── Step 2: enrich each match with pull-status (behind count), PR, and Jenkins ──
    const apiBase   = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
    const ghHeaders = { Authorization: `token ${sess.token}`,
                        Accept: 'application/vnd.github.v3+json', 'User-Agent': 'iready-oasis/1.0' };
    const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
    const jToken = sess.jenkinsToken || '';
    const jUser  = sess.jenkinsUser  || sess.githubLogin || '';

    // The "behind" count is measured against the repo's DEFAULT branch (e.g.
    // develop/main) — the branch you pull the latest base code from — NOT the
    // ticket branch's own remote. A feature branch that's already current with
    // develop has nothing to pull even if origin/<ticket-branch> carries unrelated
    // commits. Cached per repo so it's resolved once across a repo's branches.
    const defaultBranchCache = {};
    const getDefaultBranch = async (dir) => {
      if (dir in defaultBranchCache) return defaultBranchCache[dir];
      let def = '';
      // Prefer the remote's advertised default: origin/HEAD -> origin/<default>.
      const head = await execQuiet(`git -C "${dir}" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null`, { timeout: 4000 }).catch(() => '');
      if (head) def = head.replace(/^origin\//, '').trim();
      if (!def) {
        // origin/HEAD not set locally — fall back to the usual base branch names.
        for (const cand of ['develop', 'main', 'master']) {
          const ok = await execQuiet(`git -C "${dir}" rev-parse --verify -q "refs/remotes/origin/${cand}" 2>/dev/null`, { timeout: 4000 }).catch(() => '');
          if (ok) { def = cand; break; }
        }
      }
      defaultBranchCache[dir] = def;
      return def;
    };

    const enrich = async (m) => {
      const dir = path.join(base, m.repo);
      const out = { repo: m.repo, branch: m.branch, current: m.current, behind: 0, pr: null, jenkins: null };

      // Does this branch actually have a remote (origin) counterpart? Only then
      // is there something on GitHub to link the branch name to — a local-only
      // branch has no URL and stays plain text in the UI.
      try {
        const ref = await execQuiet(
          `git -C "${dir}" rev-parse --verify -q "refs/remotes/origin/${m.branch}" 2>/dev/null`,
          { timeout: 4000 }).catch(() => '');
        if (ref) {
          out.branchUrl = `${sess.githubUrl.replace(/\/$/, '')}/${sess.org}/${m.repo}/tree/` +
            m.branch.split('/').map(encodeURIComponent).join('/');
        }
      } catch (_) {}

      // Pull status — count commits on the DEFAULT branch the ticket branch hasn't
      // picked up yet (what "pull latest" would bring in). Uses cached remote refs,
      // no network fetch. 0 when the branch is already current with the default
      // branch, regardless of which branch is checked out. A remote-only match (no
      // local branch) or a repo with no resolvable default branch falls back to 0.
      try {
        const def = await getDefaultBranch(dir);
        if (def) {
          const cnt = await execQuiet(
            `git -C "${dir}" rev-list "${m.branch}..origin/${def}" --count 2>/dev/null || echo 0`,
            { timeout: 4000 });
          out.behind = parseInt(cnt) || 0;
        }
      } catch (_) {}

      // Open PR from GitHub
      try {
        let pr = await findOpenPrForBranch({ apiBase, org: sess.org, repo: m.repo, branch: m.branch, headers: ghHeaders });
        let isMerged = false;
        if (!pr) {
          pr = await findMergedPrForBranch({ apiBase, org: sess.org, repo: m.repo, branch: m.branch, headers: ghHeaders });
          if (pr) isMerged = true;
        }
        if (pr) {
          out.pr = { number: pr.number, title: pr.title, url: pr.html_url, review: 'pending', merged: isMerged };
          // Determine review status from reviews (latest decision per reviewer)
          try {
            const rev = await axios.get(
              `${apiBase}/repos/${sess.org}/${m.repo}/pulls/${pr.number}/reviews?per_page=100`,
              { headers: ghHeaders, timeout: 8000 });
            const latest = {};
            for (const v of (rev.data || [])) {
              const state = v.state; // APPROVED, CHANGES_REQUESTED, COMMENTED, DISMISSED, PENDING
              const login = v.user && v.user.login;
              if (!login) continue;
              // Track the latest meaningful state per reviewer
              if (state === 'APPROVED' || state === 'CHANGES_REQUESTED' || state === 'DISMISSED' || state === 'COMMENTED') {
                latest[login] = state;
              }
            }
            const states = Object.values(latest);
            // An approval from ANY reviewer wins outright — including over another
            // reviewer's stale/unaddressed CHANGES_REQUESTED or plain comments.
            // This intentionally diverges from GitHub's own reviewDecision (which
            // keeps CHANGES_REQUESTED sticky until that reviewer clears it) — here
            // "approved" is meant to reflect the current go-ahead, not full history.
            // No reviews at all yet → amber ("created").
            if (states.includes('APPROVED'))                out.pr.review = 'approved';
            else if (states.includes('CHANGES_REQUESTED'))  out.pr.review = 'changes';
            else if (states.includes('COMMENTED'))          out.pr.review = 'changes';
            else                                             out.pr.review = 'pending';
          } catch (_) {}
        }
      } catch (e) {
        // Distinguish "GitHub lookup failed" (token/rate-limit/network) from
        // "branch genuinely has no PR" so the UI can show why instead of nothing.
        if (e && e.isPrLookupError) out.prError = e.message || 'PR lookup failed';
      }

      // Jenkins last build status
      if (!jToken) { out.jenkins = { error: 'no-token' }; }
      else {
        const jApiUrl = `${jUrl}/job/iready/job/${encodeURIComponent(m.repo)}/job/${encodeURIComponent(m.branch)}/lastBuild/api/json`;
        const jWebUrl = `${jUrl}/job/iready/job/${encodeURIComponent(m.repo)}/job/${encodeURIComponent(m.branch)}/`;
        try {
          const jr = await axios.get(jApiUrl, { auth: { username: jUser, password: jToken }, timeout: 8000 });
          const d = jr.data;
          out.jenkins = { result: d.result, url: d.url || jWebUrl, building: d.building, number: d.number };
        } catch (e) {
          const st = e.response?.status;
          out.jenkins = { error: st === 404 ? 'no-build' : (st === 401 || st === 403 ? 'auth' : 'error'), url: jWebUrl };
        }
      }
      return out;
    };

    const result = {};
    await Promise.all(keys.map(async k => {
      result[k] = await Promise.all(matches[k].map(enrich));
    }));
    res.json(result);
  });

  /**
   * POST /api/jira/pull-branch — bring the latest default-branch (e.g. develop)
   * code into a ticket branch by merging origin/<default> into it.
   * Body: { session, repo, branch }
   */
  app.post('/api/jira/pull-branch', async (req, res) => {
    const { session, repo, branch } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!repo) return res.status(400).json({ error: 'repo required' });

    const dir = path.join(expandHome(sess.cloneDir), repo);
    if (!fs.existsSync(dir)) return res.status(400).json({ error: 'Repo not cloned locally' });

    // Don't touch a repo that's already mid-operation — pulling on top of an
    // unfinished rebase/merge is exactly what wedges it into a "(no branch,
    // rebasing …)" state. Tell the user to resolve it first.
    const gitDir = path.join(dir, '.git');
    if (fs.existsSync(path.join(gitDir, 'rebase-merge')) || fs.existsSync(path.join(gitDir, 'rebase-apply'))) {
      return res.status(409).json({ error: `${repo} has an unfinished rebase — run "git rebase --abort" (or finish it) first` });
    }
    if (fs.existsSync(path.join(gitDir, 'MERGE_HEAD'))) {
      return res.status(409).json({ error: `${repo} has an unfinished merge — run "git merge --abort" (or finish it) first` });
    }

    const cur = (await execQuiet(`git -C "${dir}" rev-parse --abbrev-ref HEAD`, { timeout: 6000 }).catch(() => '')).trim();
    if (!cur || cur === 'HEAD') {
      return res.status(409).json({ error: `${repo} is in a detached HEAD state — checkout a branch first` });
    }
    const needSwitch = branch && cur !== branch;
    let stashed = false;
    let def = '';

    try {
      if (needSwitch) {
        // Stash any uncommitted changes on the current branch before switching
        const stashOut = await execQuiet(`git -C "${dir}" stash --include-untracked`, { timeout: 15000 }).catch(() => '');
        stashed = stashOut.includes('Saved working directory');
        await execQuiet(`git -C "${dir}" checkout "${branch}"`, { timeout: 15000 });
      }

      // "Pull latest" = bring the repo's DEFAULT branch (e.g. develop) into the
      // ticket branch — the base code you stay current with — NOT origin/<ticket
      // branch>. This matches the "behind" count (commits on the default branch the
      // ticket branch lacks). Resolve the default branch (origin/HEAD, else the
      // usual base-branch names).
      def = (await execQuiet(`git -C "${dir}" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null`, { timeout: 6000 }).catch(() => '')).replace(/^origin\//, '').trim();
      if (!def) {
        for (const cand of ['develop', 'main', 'master']) {
          const ok = await execQuiet(`git -C "${dir}" rev-parse --verify -q "refs/remotes/origin/${cand}" 2>/dev/null`, { timeout: 6000 }).catch(() => '');
          if (ok) { def = cand; break; }
        }
      }
      if (!def) throw new Error('Could not determine the default branch to pull from');

      // Fetch the latest default branch, then merge it into the ticket branch.
      // Merge (not rebase) keeps the ticket branch's commits intact — no history
      // rewrite, no force-push. A conflict leaves merge state behind, which the
      // catch block aborts so the repo is never left wedged.
      externalCalls.assertAllowed('GitHub');
      await execQuiet(`git -C "${dir}" -c http.version=HTTP/1.1 fetch origin "${def}"`, { timeout: 60000 });
      const out = await execQuiet(`git -C "${dir}" merge --no-edit "origin/${def}"`, { timeout: 60000 });

      if (needSwitch) {
        // Go back to the original branch and restore stashed changes
        await execQuiet(`git -C "${dir}" checkout "${cur}"`, { timeout: 15000 });
        if (stashed) await execQuiet(`git -C "${dir}" stash pop`, { timeout: 15000 }).catch(() => {});
      }

      res.json({ ok: true, message: out.split('\n').slice(-3).join(' ').slice(0, 200) || 'Up to date' });
    } catch (e) {
      // Best-effort recovery so a failed pull never leaves the repo wedged: abort
      // anything the merge/rebase may have started, return to the original branch,
      // and restore the stash. Each step is independent and non-fatal.
      await execQuiet(`git -C "${dir}" merge --abort`, { timeout: 15000 }).catch(() => {});
      await execQuiet(`git -C "${dir}" rebase --abort`, { timeout: 15000 }).catch(() => {});
      if (needSwitch) {
        await execQuiet(`git -C "${dir}" checkout "${cur}"`, { timeout: 15000 }).catch(() => {});
        if (stashed) await execQuiet(`git -C "${dir}" stash pop`, { timeout: 15000 }).catch(() => {});
      }
      let msg = (e.stderr || e.message || 'Pull failed').slice(0, 200);
      if (/conflict|automatic merge failed/i.test(msg)) {
        msg = `Merging the latest ${def || 'base branch'} into ${branch || cur} hit conflicts — resolve them manually`;
      }
      res.status(400).json({ error: msg });
    }
  });

  /**
   * GET /api/jira/history — load saved ticket history + computed metrics
   */
  app.get('/api/jira/history', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    const history = loadJiraHistory();
    const tickets = Object.values(history.tickets);

    // Sprint-level aggregates
    const sprintMap = {};
    for (const t of tickets) {
      if (!t.sprint) continue;
      if (!sprintMap[t.sprint]) {
        sprintMap[t.sprint] = { name: t.sprint, id: t.sprintId, state: t.sprintState,
          pi: null, stories: 0, bugs: 0, tasks: 0, other: 0,
          points: 0, pointsDone: 0, done: 0, inProgress: 0, toDo: 0 };
      }
      const s = sprintMap[t.sprint];
      const isDone = t.statusCat === 'done';
      const pts = t.points || 0;
      if (!s.pi && t.pi) s.pi = t.pi;
      if (t.type === 'Story')                       s.stories++;
      else if (t.type === 'Bug')                    s.bugs++;
      else if (/task/i.test(t.type))                s.tasks++;
      else                                          s.other++;
      s.points += pts;
      if (isDone)                    { s.pointsDone += pts; s.done++; }
      else if (/progress/i.test(t.status)) s.inProgress++;
      else                                 s.toDo++;
    }

    // PI aggregates
    const piMap = {};
    for (const s of Object.values(sprintMap)) {
      if (!s.pi) continue;
      if (!piMap[s.pi]) piMap[s.pi] = { name: s.pi, sprints: 0, stories: 0, bugs: 0, tasks: 0, points: 0, pointsDone: 0 };
      const p = piMap[s.pi];
      p.sprints++; p.stories += s.stories; p.bugs += s.bugs;
      p.tasks += s.tasks; p.points += s.points; p.pointsDone += s.pointsDone;
    }

    const sortedSprints  = Object.values(sprintMap).sort((a, b) => (b.id || 0) - (a.id || 0));
    const sortedPIs      = Object.values(piMap).sort((a, b) => b.name.localeCompare(a.name));
    const completedSprints = sortedSprints.filter(s => s.state === 'closed' || s.done > 0);

    const totalDone       = tickets.filter(t => t.statusCat === 'done');
    const totalPointsDone = totalDone.reduce((s, t) => s + (t.points || 0), 0);
    const totals = {
      totalTickets:  tickets.length,
      totalDone:     totalDone.length,
      totalInProgress: tickets.filter(t => t.statusCat === 'indeterminate').length,
      totalStories:  tickets.filter(t => t.type === 'Story').length,
      totalBugs:     tickets.filter(t => t.type === 'Bug').length,
      totalTasks:    tickets.filter(t => /task/i.test(t.type)).length,
      totalPoints:   tickets.reduce((s, t) => s + (t.points || 0), 0),
      totalPointsDone,
      doneSprints:   completedSprints.length,
      avgVelocity:   completedSprints.length
        ? Math.round((totalPointsDone / completedSprints.length) * 10) / 10 : 0,
    };

    res.json({ ok: true,
               lastSynced: history.lastSync,
               jiraUrl: sess.jiraUrl || '',
               jiraEmail: sess.jiraEmail || '',
               jiraAccountId: sess.jiraAccountId || '',
               jiraPointsField: sess.jiraPointsField || '',
               configured: !!(sess.jiraUrl && sess.jiraToken),
               tickets, sprints: sortedSprints, pis: sortedPIs, totals });
  });
}

module.exports = { installJira, jiraSearchAll, JIRA_HTTPS_AGENT };