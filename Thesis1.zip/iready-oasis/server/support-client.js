'use strict';
const crypto = require('crypto');
const axios = require('axios');

// Sends Feedback and Contact Support to oasis-support-service, which stores them for the
// support portal. OASIS only ever speaks to it over its API.
//
// What happens to a submission:
//   the service took it          -> { ok: true, reference }
//   the service refused it (4xx) -> { ok: false, rejected: true, message, errors }  (the person can fix it)
//   the service is unreachable   -> the words are kept in ~/oasis (as before the service existed) and
//                                   { ok: true, savedLocally: true } comes back, so nothing typed is lost
//
// Unreachable means a network error or a 5xx. A 4xx is the service answering "no", which is not an outage,
// and keeping a refused message locally would hide that it never reached support.

const DEFAULT_SUPPORT_URL = 'http://localhost:4040/v1';
const KEY_PATTERN = /^[A-Za-z0-9_-]{8,100}$/;

function supportServiceUrl(env = process.env) {
  return String(env.OASIS_SUPPORT_URL || DEFAULT_SUPPORT_URL).replace(/\/+$/, '');
}

const clean = value => (typeof value === 'string' ? value.trim() : '');

function createSupportClient({ http, baseUrl = supportServiceUrl(), appVersion = null, machineId = null, saveLocally, timeoutMs = 10000 } = {}) {
  const client = http || axios.create({
    baseURL: baseUrl,
    timeout: timeoutMs,
    // Non-2xx must reach the catch block so it can be sorted into refused or unreachable.
    validateStatus: s => s >= 200 && s < 300,
    headers: { 'Content-Type': 'application/json' },
  });

  async function send(route, body, idempotencyKey) {
    const key = KEY_PATTERN.test(String(idempotencyKey || '')) ? idempotencyKey : crypto.randomUUID();
    const payload = { ...body, appVersion };
    if (machineId) payload.machineId = machineId;
    try {
      const res = await client.post(route, payload, { headers: { 'Idempotency-Key': key } });
      return { ok: true, reference: res.data && res.data.reference };
    } catch (err) {
      const status = err && err.response && err.response.status;
      if (typeof status === 'number' && status >= 400 && status < 500) {
        const data = err.response.data || {};
        return {
          ok: false,
          rejected: true,
          status,
          message: data.message || 'Support could not accept that. Please check the details and try again.',
          // oasis-support-service puts the field errors at the top level of its refusal body.
          errors: data.errors || undefined,
        };
      }
      return null;       // unreachable: the caller keeps the words locally
    }
  }

  function keepLocally(file, text) {
    try {
      saveLocally(file, text);
      return { ok: true, savedLocally: true };
    } catch (_) {
      // No content in the answer: it can reach logs and the screen, and it is the person's words.
      return { ok: false, unreachable: true, message: 'Could not reach support, and the message could not be saved on this computer either.' };
    }
  }

  const stamp = who => `[${new Date().toISOString()}] ${who || 'unknown'}`;

  async function sendFeedback({ category, message, email, idempotencyKey, who } = {}) {
    const body = { category: clean(category), message: clean(message) };
    if (clean(email)) body.email = clean(email);
    const out = await send('/feedback', body, idempotencyKey);
    if (out) return out;
    return keepLocally('feedback.txt', `${stamp(who)}\n${body.category}\n${body.message}\n---\n`);
  }

  async function sendSupportRequest({ subject, message, contactName, email, idempotencyKey, who } = {}) {
    const body = { subject: clean(subject), message: clean(message), contactName: clean(contactName), email: clean(email) };
    const out = await send('/support-request', body, idempotencyKey);
    if (out) return out;
    return keepLocally('support.txt', `${stamp(who)}\n${body.subject}\n${body.message}\n---\n`);
  }

  return { sendFeedback, sendSupportRequest };
}

module.exports = { createSupportClient, supportServiceUrl, DEFAULT_SUPPORT_URL };
