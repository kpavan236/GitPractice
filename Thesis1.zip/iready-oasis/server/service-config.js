'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

// Where OASIS finds the other services (licence, support, rules).
//
// The rest of the app reads these from environment variables (OASIS_LICENSE_URL and so on). This
// module supplies them when they are not already set, so the app works when it is started without
// a launcher script, for example `npx electron .`, and the addresses are written down in files.
//
// Precedence, highest first:
//   1. the environment variable, if set and not empty
//   2. the per-user file: ~/.oasis-services.json, or the file named by OASIS_SERVICES_CONFIG
//      (outside the app, so an update never overwrites it; use it to point one machine elsewhere)
//   3. config/services.json shipped with the app (the local development addresses)
//   4. the default built into each module
//
// The files are merged setting by setting: a per-user file that sets only "supportUrl" leaves the
// licence and rule server addresses to the shipped file. A missing or damaged file is skipped.

const BUNDLED_FILE = path.join(__dirname, '..', 'config', 'services.json');
const DEFAULT_FILE = BUNDLED_FILE;

const userConfigFile = (env = process.env, home = os.homedir()) => env.OASIS_SERVICES_CONFIG || path.join(home, '.oasis-services.json');

// file key -> environment variable
const KEYS = {
  licenseUrl: 'OASIS_LICENSE_URL',
  licensePublicKeyFile: 'OASIS_LICENSE_PUBLIC_KEY',
  supportUrl: 'OASIS_SUPPORT_URL',
  ruleServerUrl: 'OASIS_RULE_SERVER_URL',
};

const expandHome = (p, home) => (p === '~' ? home : p.startsWith('~/') ? path.join(home, p.slice(2)) : p);

function readConfig(file) {
  try {
    const config = JSON.parse(fs.readFileSync(file, 'utf8'));
    return config && typeof config === 'object' && !Array.isArray(config) ? config : null;
  } catch (_) {
    return null;
  }
}

/**
 * Sets the environment variables that are still unset, trying each file in order. Returns the names it set.
 * `exists` is only used for the public key file: a path to a file that is not there is left unset, so
 * the licence code reports that it is using the development key instead of reading a missing file.
 */
function applyServiceConfig(env = process.env, { files, home = os.homedir(), exists = fs.existsSync } = {}) {
  const sources = files || [userConfigFile(env, home), BUNDLED_FILE];
  const applied = [];
  for (const file of sources) {
    const config = readConfig(file);
    if (!config) continue;
    for (const [key, name] of Object.entries(KEYS)) {
      if (env[name]) continue;
      let value = typeof config[key] === 'string' ? config[key].trim() : '';
      if (!value) continue;
      if (key === 'licensePublicKeyFile') {
        value = expandHome(value, home);
        if (!exists(value)) continue;
      }
      env[name] = value;
      applied.push(name);
    }
  }
  return applied;
}

module.exports = { applyServiceConfig, userConfigFile, KEYS, DEFAULT_FILE };
