'use strict';
const express = require('express');
const { localOriginGuard } = require('../security/local-origin');
const { parsePeriod, previousPeriod, PeriodError } = require('./period');
const { computeStats } = require('./metrics');
const { computeReview } = require('./review-metrics');
const { buildCandidates } = require('./suggestions');
const { generateNarrative } = require('./narrative');
const { fetchTickets } = require('./jira-source');
const { fetchReviewData } = require('./github-source');
const { createStore, createPackCache, DraftError } = require('./store');
const { KUDOS, JIRA_TICKET_CAP } = require('./constants');

const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);

// One retry for a transient JIRA failure (no response, or a 5xx). A 4xx is the
// answer, not a glitch, so it is not retried.
async function withRetry(fn) {
  try { return await fn(); } catch (err) {
    const status = err.response && err.response.status;
    if (status && status < 500) throw err;
    return fn();
  }
}

/**
 * Mounts /api/appraisal/*.
 *
 * PRIVACY, in the routes:
 *  - the person is always the SESSION's own JIRA and GitHub identity. No request
 *    field can name another user (none is read), so a pack for someone else
 *    cannot be asked for.
 *  - every route is local-origin only and needs a valid session.
 *  - nothing here reads the prefs file or the Notes: drafts live in their own
 *    owner-only file (see store.js) and the built pack lives in memory only.
 */
function installAppraisal(app, { sessions, aiClientFor, searchAll, http, jiraHttp, githubHttp, storePath, now = () => new Date() }) {
  // JIRA and GitHub are reached differently (JIRA through the app's lenient HTTPS
  // agent for corporate certificates), so each gets its own client. `http` is the
  // fallback for both, which is what the tests use.
  const jira = jiraHttp || http;
  const github = githubHttp || http;
  const store = createStore({ filePath: storePath, now });
  const packs = createPackCache();
  const buildCounter = new Map();
  const router = express.Router();
  router.use(localOriginGuard);

  function session(req) {
    const id = (req.query && req.query.session) || (req.body && req.body.session);
    const sess = sessions[id];
    if (!sess) { const e = new Error('Invalid session'); e.status = 401; throw e; }
    return { id, sess };
  }

  const aiInfoFor = sess => ({ provider: sess.aiProvider || null, model: sess.aiModel || null, local: sess.aiProvider === 'ollama' });

  router.get('/status', wrap(async (req, res) => {
    const { id, sess } = session(req);
    const ai = aiClientFor(sess);
    res.json({
      jira: { connected: !!(sess.jiraUrl && sess.jiraToken), displayName: sess.jiraDisplayName || null },
      github: { connected: !!(sess.githubUrl && sess.token && sess.githubLogin) },
      ai: { available: ai.available(), ...aiInfoFor(sess), noticeAcknowledged: store.aiNoticeAcknowledged() },
      hasPack: packs.get(id) !== null,
    });
  }));

  router.post('/build', wrap(async (req, res) => {
    const { id, sess } = session(req);
    const body = req.body || {};
    const period = parsePeriod({ mode: body.mode, from: body.from, to: body.to, tz: body.tz }, now());
    if (!(sess.jiraUrl && sess.jiraToken)) {
      return res.status(400).json({ error: 'Connect JIRA in the JIRA tab first.', code: 'JIRA_NOT_CONNECTED' });
    }
    const myBuild = (buildCounter.get(id) || 0) + 1;
    buildCounter.set(id, myBuild);

    let fetched;
    try {
      fetched = await withRetry(() => fetchTickets({ sess, period, searchAll, http: jira }));
    } catch (err) {
      const status = err.response && err.response.status;
      if (status === 401 || status === 403) return res.status(502).json({ error: 'JIRA rejected the saved credentials. Reconnect JIRA and try again.', code: 'JIRA_AUTH' });
      return res.status(502).json({ error: 'JIRA could not be reached. Try again in a moment.', code: 'JIRA_UNREACHABLE' });
    }
    const stats = computeStats(fetched.tickets, period, fetched.meta);

    // The previous period is only needed for the "improvement" suggestion, and only
    // if this period has enough closed tickets to compare. Best effort.
    let prevStats = null;
    if (stats.leadTime.n >= KUDOS.improvement.minSample) {
      try {
        const prev = previousPeriod(period);
        const before = await fetchTickets({ sess, period: prev, searchAll, http: jira });
        prevStats = computeStats(before.tickets, prev, before.meta);
      } catch (_) { prevStats = null; }
    }

    let review = { available: false, reason: 'Code review was turned off for this build.' };
    if (body.includeCodeReview !== false) {
      const data = await fetchReviewData({ sess, period, http: github });
      review = data.available ? computeReview(data.authored, data.reviewed, period, { partial: data.partial }) : data;
    }

    const candidates = buildCandidates({ tickets: fetched.tickets, stats, period, prevStats, review });
    const ai = aiClientFor(sess);
    const narrative = await generateNarrative({
      ai, aiInfo: aiInfoFor(sess), useAi: body.useAi !== false, stats, candidates, review: review.available ? review : null,
    });

    if (buildCounter.get(id) !== myBuild) {
      return res.status(409).json({ error: 'A newer build replaced this one.', code: 'SUPERSEDED' });
    }

    const notices = [];
    if (fetched.meta.capped) notices.push(`This period reached JIRA's ${JIRA_TICKET_CAP}-ticket limit, so the figures are partial. Try a shorter period.`);
    if (fetched.meta.historyCapped) notices.push('Status history was read for the first 300 tickets only; the rest use created-to-resolved time.');
    else if (fetched.meta.historyMissing > 0) notices.push(`${fetched.meta.historyMissing} tickets had no usable status history; they are left out of working time.`);
    if (!fetched.meta.sprintsAvailable) notices.push('Rolled-over work is not available because no sprint field was found in this JIRA.');
    if (review.available && review.partial) notices.push('Code review is based on the first pull requests found; the period has more.');

    const pack = {
      period: { key: period.key, label: period.label, mode: period.mode, toDate: period.toDate, days: period.days, tz: period.tz,
        start: period.start.toISOString(), end: period.end.toISOString() },
      generatedAt: now().toISOString(),
      user: { displayName: sess.jiraDisplayName || '' },
      partial: fetched.meta.capped || fetched.meta.historyCapped || (review.available && review.partial) === true,
      notices,
      stats,
      review,
      candidates: candidates.map(({ id: cid, kind, title, text }) => ({ id: cid, kind, title, text })),
      narrative,
    };
    packs.set(id, pack);
    return res.json(pack);
  }));

  router.get('/pack', wrap(async (req, res) => {
    const { id } = session(req);
    const pack = packs.get(id);
    return pack ? res.json(pack) : res.status(404).json({ error: 'No pack built yet.' });
  }));

  router.get('/draft', wrap(async (req, res) => {
    session(req);
    res.json({ draft: store.getDraft(req.query.period) });
  }));

  router.put('/draft', wrap(async (req, res) => {
    session(req);
    const body = req.body || {};
    res.json({ draft: store.putDraft(body.period, body.draft) });
  }));

  router.post('/ai-notice', wrap(async (req, res) => {
    session(req);
    store.acknowledgeAiNotice();
    res.json({ ok: true });
  }));

  router.delete('/data', wrap(async (req, res) => {
    const { id } = session(req);
    store.clear();
    packs.delete(id);
    buildCounter.delete(id);
    res.json({ ok: true });
  }));

  // eslint-disable-next-line no-unused-vars
  router.use((err, req, res, _next) => {
    if (err instanceof PeriodError || err instanceof DraftError) return res.status(400).json({ error: err.message });
    if (err && err.status === 401) return res.status(401).json({ error: err.message });
    // Error type only: never ticket or PR text, never the user's own words.
    console.error('[appraisal] unexpected', err && err.name);
    return res.status(500).json({ error: 'Something went wrong while building the pack.' });
  });

  app.use('/api/appraisal', router);
  return { store, packs };
}

module.exports = { installAppraisal };
