'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parsePeriod, previousPeriod, weekKey, weekKeys, localDate, PeriodError } = require('./period');

const NOW = new Date('2026-10-06T10:00:00Z');
const base = { mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' };

test('a valid range gives inclusive instants, a stable key and a label', () => {
  const p = parsePeriod(base, NOW);
  assert.equal(p.key, '2026-01-01_2026-03-31');
  assert.equal(p.label, '2026-01-01 to 2026-03-31');
  assert.equal(p.start.toISOString(), '2026-01-01T00:00:00.000Z');
  assert.equal(p.end.toISOString(), '2026-03-31T23:59:59.999Z');
  assert.equal(p.toDate, false);
});

test('to-date runs to now and is keyed as to-date', () => {
  const p = parsePeriod({ mode: 'to-date', from: '2026-07-01T00:00:00.000Z', tz: 'UTC' }, NOW);
  assert.equal(p.end.toISOString(), NOW.toISOString());
  assert.equal(p.key, '2026-07-01_to-date');
  assert.equal(p.label, '2026-07-01 to today');
});

test('the key uses the calendar date in the user\'s own time zone', () => {
  // 18:30 UTC on 31 Dec is already 1 Jan in Kolkata.
  const p = parsePeriod({ mode: 'range', from: '2025-12-31T18:30:00.000Z', to: '2026-01-31T18:29:59.999Z', tz: 'Asia/Kolkata' }, NOW);
  assert.equal(p.key, '2026-01-01_2026-01-31');
});

test('bad input is a PeriodError with status 400', () => {
  const bad = [
    [{ ...base, mode: 'forever' }, /mode/],
    [{ ...base, tz: 'Not/AZone' }, /time zone/],
    [{ ...base, tz: undefined }, /time zone/],
    [{ ...base, from: 'yesterday' }, /from/],
    [{ ...base, from: undefined }, /from/],
    [{ ...base, to: 'soon' }, /to must/],
    [{ ...base, from: '2026-04-01T00:00:00.000Z' }, /after the end/],
    [{ ...base, from: '2026-11-01T00:00:00.000Z', to: '2026-12-01T00:00:00.000Z' }, /future/],
    [{ ...base, from: '2023-01-01T00:00:00.000Z', to: '2026-03-01T00:00:00.000Z' }, /24 months/],
  ];
  for (const [input, message] of bad) {
    assert.throws(() => parsePeriod(input, NOW), err => err instanceof PeriodError && err.status === 400 && message.test(err.message));
  }
});

test('exactly 24 months is allowed and one day more is not', () => {
  assert.ok(parsePeriod({ ...base, from: '2024-10-06T00:00:00.000Z', to: '2026-10-05T23:59:59.999Z' }, NOW));
  assert.throws(() => parsePeriod({ ...base, from: '2024-10-04T00:00:00.000Z', to: '2026-10-05T23:59:59.999Z' }, NOW), /24 months/);
});

test('weeks start on Monday in the user\'s zone, including around midnight', () => {
  assert.equal(weekKey(new Date('2026-10-05T12:00:00Z'), 'UTC'), '2026-10-05');   // a Monday
  assert.equal(weekKey(new Date('2026-10-11T23:59:59Z'), 'UTC'), '2026-10-05');   // Sunday night
  assert.equal(weekKey(new Date('2026-10-12T00:00:00Z'), 'UTC'), '2026-10-12');
  // 23:30 UTC Sunday is already Monday in Auckland.
  assert.equal(weekKey(new Date('2026-10-11T23:30:00Z'), 'Pacific/Auckland'), '2026-10-12');
  assert.equal(localDate(new Date('2026-10-11T23:30:00Z'), 'America/Los_Angeles'), '2026-10-11');
});

test('weekKeys lists every week from the first to the last, across a year boundary', () => {
  const keys = weekKeys(new Date('2025-12-29T10:00:00Z'), new Date('2026-01-12T10:00:00Z'), 'UTC');
  assert.deepEqual(keys, ['2025-12-29', '2026-01-05', '2026-01-12']);
  assert.deepEqual(weekKeys(new Date('2026-10-06T00:00:00Z'), new Date('2026-10-06T23:00:00Z'), 'UTC'), ['2026-10-05']);
});

test('previousPeriod is the same length, immediately before, and not to-date', () => {
  const p = parsePeriod(base, NOW);
  const prev = previousPeriod(p);
  assert.equal(prev.end.getTime(), p.start.getTime() - 1);
  assert.equal(prev.end.getTime() - prev.start.getTime(), p.end.getTime() - p.start.getTime());
  assert.equal(prev.toDate, false);
});
