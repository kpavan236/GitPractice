'use strict';
const { AI_TEXT_MAX, AI_PROMPT_MAX, AI_MAX_PROMPTS } = require('./constants');

const PLACEHOLDER = /\{([A-Za-z][A-Za-z0-9]*)\}/g;

// Words that give a text away as having come from outside the supplied facts.
// A digit anywhere outside a placeholder means the model produced a number of
// its own; a URL or address means it produced a reference of its own.
const FORBIDDEN = [/\d/, /https?:/i, /:\/\//, /@/, /www\./i];

function fillPlaceholders(text, vars) {
  return String(text).replace(PLACEHOLDER, (_, name) => {
    const v = vars[name];
    return v === null || v === undefined ? 'n/a' : String(v);
  });
}

/**
 * Accepts or rejects ONE piece of AI text.
 *
 * The model is told to write prose with placeholders and never to write a
 * figure itself; code substitutes the true values afterwards. This check is what
 * makes that rule enforceable rather than hoped for.
 */
function checkText(text, allowed, max = AI_TEXT_MAX) {
  if (typeof text !== 'string') return { ok: false, reason: 'not text' };
  const trimmed = text.trim();
  if (!trimmed) return { ok: false, reason: 'empty' };
  if (trimmed.length > max) return { ok: false, reason: 'too long' };
  const used = [...trimmed.matchAll(PLACEHOLDER)].map(m => m[1]);
  const unknown = used.find(name => !allowed.includes(name));
  if (unknown) return { ok: false, reason: `unknown placeholder ${unknown}` };
  const bare = trimmed.replace(PLACEHOLDER, '');
  if (/[{}]/.test(bare)) return { ok: false, reason: 'stray brace' };
  const bad = FORBIDDEN.find(re => re.test(bare));
  if (bad) return { ok: false, reason: 'contains a figure or reference of its own' };
  return { ok: true, text: trimmed };
}

/**
 * @param {object} raw          parsed model output { summary, kudos: [{id,text}], prompts: [] }
 * @param {object} ctx          { globalVars, candidates: [{ id, vars }] }
 * @returns { summary: string|null, kudos: {id: string}, prompts: string[], rejected: string[] }
 * Every field is judged on its own; a rejected one is simply absent so the
 * caller can fall back to rule-based text for that field alone.
 */
function guardNarrative(raw, { globalVars, candidates }) {
  const out = { summary: null, kudos: {}, prompts: [], rejected: [] };
  const globals = Object.keys(globalVars);
  const body = raw && typeof raw === 'object' ? raw : {};

  const summary = checkText(body.summary, globals);
  if (summary.ok) out.summary = fillPlaceholders(summary.text, globalVars);
  else out.rejected.push(`summary: ${summary.reason}`);

  const byId = new Map(candidates.map(c => [c.id, c]));
  for (const item of Array.isArray(body.kudos) ? body.kudos : []) {
    const cand = item && byId.get(item.id);
    if (!cand) { out.rejected.push('kudos: unknown candidate'); continue; }
    const allowed = [...globals, ...Object.keys(cand.vars || {})];
    const verdict = checkText(item.text, allowed);
    if (verdict.ok) out.kudos[cand.id] = fillPlaceholders(verdict.text, { ...globalVars, ...cand.vars });
    else out.rejected.push(`kudos ${cand.id}: ${verdict.reason}`);
  }

  for (const p of Array.isArray(body.prompts) ? body.prompts : []) {
    if (out.prompts.length >= AI_MAX_PROMPTS) break;
    const verdict = checkText(p, globals, AI_PROMPT_MAX);
    if (verdict.ok) out.prompts.push(fillPlaceholders(verdict.text, globalVars));
    else out.rejected.push(`prompt: ${verdict.reason}`);
  }
  return out;
}

module.exports = { checkText, fillPlaceholders, guardNarrative, PLACEHOLDER };
