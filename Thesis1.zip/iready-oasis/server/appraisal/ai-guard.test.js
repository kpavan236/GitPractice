'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { checkText, fillPlaceholders, guardNarrative } = require('./ai-guard');

const GLOBALS = { opened: 12, closed: 9, median: 3.5, rolled: null };
const CANDS = [{ id: 'quickTurnaround', vars: { count: 4 } }, { id: 'bigDeliveries', vars: { count: 2, points: 13 } }];

test('placeholders are filled from the supplied values, and missing values read n/a', () => {
  assert.equal(fillPlaceholders('You closed {closed} of {opened}; rolled {rolled}.', GLOBALS), 'You closed 9 of 12; rolled n/a.');
});

test('plain prose with allowed placeholders passes', () => {
  assert.deepEqual(checkText('A steady period: you closed {closed} tickets.', ['closed']), { ok: true, text: 'A steady period: you closed {closed} tickets.' });
});

test('any number written by the model is rejected', () => {
  for (const text of ['You closed 14 tickets.', 'Roughly {closed} tickets, about 3 per week.', 'Sprint 7 went well.']) {
    assert.equal(checkText(text, ['closed']).ok, false, text);
  }
});

test('ticket-key-like text, URLs and addresses are rejected', () => {
  for (const text of ['Great work on EX-101.', 'See https://example.test/x', 'Mail jane@example.test', 'Visit www.example.test']) {
    assert.equal(checkText(text, ['closed']).ok, false, text);
  }
});

test('unknown placeholders, stray braces, empty, non-string and over-long text are rejected', () => {
  assert.match(checkText('Closed {tickets}.', ['closed']).reason, /unknown placeholder/);
  assert.equal(checkText('Closed {closed', ['closed']).ok, false);
  assert.equal(checkText('   ', ['closed']).ok, false);
  assert.equal(checkText(42, ['closed']).ok, false);
  assert.equal(checkText({}, ['closed']).ok, false);
  assert.equal(checkText('a'.repeat(601), []).ok, false);
});

test('each field is judged on its own: good fields survive a bad neighbour', () => {
  const raw = {
    summary: 'You closed {closed} of the {opened} tickets you opened.',
    kudos: [
      { id: 'quickTurnaround', text: 'Fast turnaround on {count} tickets.' },
      { id: 'bigDeliveries', text: 'You delivered 13 points.' },            // rejected: own figure
      { id: 'nonexistent', text: 'Hello.' },                                 // rejected: not a candidate
    ],
    prompts: ['What helped you close {closed} tickets?', 'Which of the 3 goals matters most?'],
  };
  const g = guardNarrative(raw, { globalVars: GLOBALS, candidates: CANDS });
  assert.equal(g.summary, 'You closed 9 of the 12 tickets you opened.');
  assert.deepEqual(g.kudos, { quickTurnaround: 'Fast turnaround on 4 tickets.' });
  assert.deepEqual(g.prompts, ['What helped you close 9 tickets?']);
  assert.equal(g.rejected.length, 3);
});

test('a kudos item may use its own candidate\'s figures but not another candidate\'s', () => {
  const g = guardNarrative({ kudos: [
    { id: 'bigDeliveries', text: '{count} big tickets worth {points} points.' },
    { id: 'quickTurnaround', text: '{points} points.' },
  ] }, { globalVars: GLOBALS, candidates: CANDS });
  assert.equal(g.kudos.bigDeliveries, '2 big tickets worth 13 points.');
  assert.equal(g.kudos.quickTurnaround, undefined);
});

test('garbage output yields nothing accepted and never throws', () => {
  for (const raw of [null, undefined, 'text', 42, [], { summary: 5, kudos: 'x', prompts: 'y' }]) {
    const g = guardNarrative(raw, { globalVars: GLOBALS, candidates: CANDS });
    assert.equal(g.summary, null);
    assert.deepEqual(g.kudos, {});
    assert.deepEqual(g.prompts, []);
  }
});

test('at most five prompts are kept', () => {
  const prompts = Array.from({ length: 9 }, () => 'What would you like to raise?');
  assert.equal(guardNarrative({ prompts }, { globalVars: GLOBALS, candidates: [] }).prompts.length, 5);
});
