'use strict';
const { MAX_SPAN_DAYS } = require('./constants');

const DAY = 86400000;

class PeriodError extends Error {
  constructor(message) { super(message); this.name = 'PeriodError'; this.status = 400; }
}

function validTimeZone(tz) {
  if (typeof tz !== 'string' || !tz) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch (_) { return false; }
}

// The calendar date (YYYY-MM-DD) an instant falls on in a given time zone.
function localDate(instant, tz) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' })
    .formatToParts(instant);
  const get = type => parts.find(p => p.type === type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

// The Monday (as YYYY-MM-DD) of the week an instant falls in, in a time zone.
// Weeks start on Monday. The arithmetic is on the LOCAL calendar date, so a
// week never shifts because of the zone's UTC offset.
function weekKey(instant, tz) {
  const [y, m, d] = localDate(instant, tz).split('-').map(Number);
  const utc = new Date(Date.UTC(y, m - 1, d));
  const sinceMonday = (utc.getUTCDay() + 6) % 7;
  return new Date(utc.getTime() - sinceMonday * DAY).toISOString().slice(0, 10);
}

// Every week key from the week containing `start` to the week containing `end`.
function weekKeys(start, end, tz) {
  const keys = [];
  let cursor = weekKey(start, tz);
  const last = weekKey(end, tz);
  while (cursor <= last) {
    keys.push(cursor);
    cursor = new Date(Date.parse(`${cursor}T00:00:00Z`) + 7 * DAY).toISOString().slice(0, 10);
  }
  return keys;
}

function asDate(name, value) {
  const d = new Date(value);
  if (typeof value !== 'string' || Number.isNaN(d.getTime())) throw new PeriodError(`${name} must be a valid date and time.`);
  return d;
}

/**
 * Validates a requested period. The client computes the instants for the start
 * of the first day and the end of the last day in the user's own time zone and
 * sends them with the zone name, so the end day is inclusive without the server
 * having to guess anyone's calendar.
 *
 * @returns { mode, start, end, toDate, tz, key, label, days }
 */
function parsePeriod({ mode, from, to, tz } = {}, now = new Date()) {
  if (mode !== 'range' && mode !== 'to-date') throw new PeriodError('mode must be "range" or "to-date".');
  if (!validTimeZone(tz)) throw new PeriodError('tz must be a valid time zone name.');
  const start = asDate('from', from);
  const toDate = mode === 'to-date';
  const end = toDate ? new Date(now) : asDate('to', to);
  if (start.getTime() > now.getTime()) throw new PeriodError('The period cannot start in the future.');
  if (start.getTime() > end.getTime()) throw new PeriodError('The start date must not be after the end date.');
  const days = Math.ceil((end.getTime() - start.getTime()) / DAY);
  if (days > MAX_SPAN_DAYS) throw new PeriodError('The period can be at most 24 months.');
  const startDay = localDate(start, tz);
  const endDay = toDate ? 'to-date' : localDate(end, tz);
  return { mode, start, end, toDate, tz, key: `${startDay}_${endDay}`, label: `${startDay} to ${toDate ? 'today' : endDay}`, days };
}

// The period of equal length immediately before this one, for "improvement".
function previousPeriod(period) {
  const length = period.end.getTime() - period.start.getTime();
  const end = new Date(period.start.getTime() - 1);
  const start = new Date(end.getTime() - length);
  return { ...period, start, end, toDate: false, mode: 'range', key: `prev_${period.key}` };
}

module.exports = { parsePeriod, previousPeriod, weekKey, weekKeys, localDate, validTimeZone, PeriodError };
