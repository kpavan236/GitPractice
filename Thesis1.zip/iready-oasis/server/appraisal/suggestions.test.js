'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildCandidates } = require('./suggestions');
const { computeStats } = require('./metrics');
const { computeReview } = require('./review-metrics');
const { parsePeriod } = require('./period');

const NOW = new Date('2026-10-06T10:00:00Z');
const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-05T00:00:00.000Z', to: '2026-03-01T23:59:59.999Z', tz: 'UTC' }, NOW);
const d = s => new Date(s);
const t = (over = {}) => ({
  type: 'Story', priority: 'Medium', points: null, created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-15T00:00:00Z'),
  firstInProgress: null, owned: true, reassigned: false, sprints: [], components: [], ...over,
});
const kinds = c => c.map(x => x.kind).sort();
const run = (tickets, extra = {}) => buildCandidates({ tickets, stats: computeStats(tickets, PERIOD), period: PERIOD, ...extra });

test('nothing is suggested from a quiet period', () => {
  assert.deepEqual(run([t()]), []);
});

test('quick turnaround needs at least 3 of a type and 2 tickets at half the type\'s median or less', () => {
  const slow = Array.from({ length: 4 }, () => t({ resolved: d('2026-01-25T00:00:00Z') }));          // 20 days
  const fast = Array.from({ length: 2 }, () => t({ resolved: d('2026-01-07T00:00:00Z') }));          // 2 days
  assert.deepEqual(kinds(run([...slow, ...fast])), ['quickTurnaround']);
  assert.equal(run([...slow, ...fast])[0].vars.count, 2);
  assert.deepEqual(run([...slow, fast[0]]), [], 'only one fast ticket');
  assert.deepEqual(run([t({ resolved: d('2026-01-07T00:00:00Z') }), t({ resolved: d('2026-01-25T00:00:00Z') })]), [], 'too few of the type');
});

test('high-priority delivery counts the top priorities regardless of case', () => {
  const tickets = [t({ priority: 'Highest' }), t({ priority: 'BLOCKER' }), t({ priority: 'Low' })];
  const c = run(tickets);
  assert.deepEqual(kinds(c), ['highPriority']);
  assert.equal(c[0].vars.count, 2);
  assert.deepEqual(run([t({ priority: 'Highest' })]), []);
});

test('big deliveries need at least one ticket of 5 or more points, and report the total', () => {
  const c = run([t({ points: 5 }), t({ points: 8 }), t({ points: 2 })]);
  assert.deepEqual(kinds(c), ['bigDeliveries']);
  assert.deepEqual(c[0].vars, { count: 2, points: 13 });
  assert.deepEqual(run([t({ points: 3 })]), []);
});

test('steady output needs 6 weeks and 75% of them active', () => {
  const week = n => d(new Date(Date.parse('2026-01-05T09:00:00Z') + n * 7 * 86400000).toISOString());
  const make = weeks => weeks.map(n => t({ created: week(n), resolved: new Date(week(n).getTime() + 2 * 86400000) }));   // each takes 2 days
  assert.deepEqual(kinds(run(make([0, 1, 2, 3, 4, 5, 6, 7]))), ['steadyOutput']);
  assert.deepEqual(run(make([0, 1, 2])), [], 'too few active weeks');
});

test('breadth needs closed work across three components', () => {
  const c = run([t({ components: ['api'] }), t({ components: ['ui', 'api'] }), t({ components: ['db'] })]);
  assert.deepEqual(kinds(c), ['breadth']);
  assert.equal(c[0].vars.count, 3);
});

test('clean sprints needs a run of three and a JIRA that exposes sprints', () => {
  const s = (id, a, b) => ({ id, name: `Sprint ${id}`, state: 'closed', start: d(a), end: d(b) });
  const sprints = [s(1, '2026-01-05T00:00:00Z', '2026-01-19T00:00:00Z'), s(2, '2026-01-19T00:00:00Z', '2026-02-02T00:00:00Z'), s(3, '2026-02-02T00:00:00Z', '2026-02-16T00:00:00Z')];
  const tickets = sprints.map((sp, i) => t({ sprints: [sp], resolved: new Date(sp.end.getTime() - 86400000) }));
  assert.deepEqual(kinds(run(tickets)), ['cleanSprints']);
  const noSprints = buildCandidates({ tickets, stats: computeStats(tickets, PERIOD, { sprintsAvailable: false }), period: PERIOD });
  assert.deepEqual(noSprints.filter(c => c.kind === 'cleanSprints'), []);
});

test('improvement compares with the previous period and needs 5 closed tickets in each', () => {
  const quick = Array.from({ length: 5 }, () => t({ resolved: d('2026-01-07T00:00:00Z') }));       // 2 days
  const slowStats = computeStats(Array.from({ length: 5 }, () => t({ resolved: d('2026-01-15T00:00:00Z') })), PERIOD); // 10 days
  const c = buildCandidates({ tickets: quick, stats: computeStats(quick, PERIOD), period: PERIOD, prevStats: slowStats });
  assert.deepEqual(kinds(c).filter(k => k === 'improvement'), ['improvement']);
  assert.equal(c.find(x => x.kind === 'improvement').vars.percent, 80);
  const few = buildCandidates({ tickets: quick.slice(0, 3), stats: computeStats(quick.slice(0, 3), PERIOD), period: PERIOD, prevStats: slowStats });
  assert.equal(few.some(x => x.kind === 'improvement'), false);
});

test('code-review candidates need the thresholds and an available review section', () => {
  const authored = Array.from({ length: 10 }, (_, i) => ({ created: d('2026-01-06T00:00:00Z'), merged: d('2026-01-08T00:00:00Z') }));
  const reviewed = Array.from({ length: 10 }, () => ({ prCreated: d('2026-01-06T00:00:00Z'), reviews: [{ at: d('2026-01-06T05:00:00Z'), state: 'APPROVED' }] }));
  const review = computeReview(authored, reviewed, PERIOD);
  const c = run([t()], { review });
  assert.deepEqual(kinds(c), ['reviewPartner', 'shippingPrs']);
  assert.equal(c.find(x => x.kind === 'reviewPartner').vars.hours, 5);
  assert.deepEqual(run([t()], { review: null }), []);
  assert.deepEqual(run([t()], { review: { available: false } }), []);
});

test('tickets that are not yours never produce kudos', () => {
  assert.deepEqual(run(Array.from({ length: 5 }, () => t({ owned: false, priority: 'Highest', points: 8 }))), []);
});

test('each candidate has wording, figures and no identifiers', () => {
  const c = run([t({ points: 8, priority: 'Highest' }), t({ priority: 'Highest' })]);
  assert.ok(c.length >= 2);
  for (const x of c) {
    assert.ok(x.title && x.template && x.text);
    assert.doesNotMatch(x.text, /\{|\}/);
    assert.doesNotMatch(JSON.stringify(x), /[A-Z][A-Z0-9]+-\d+/);
  }
});
