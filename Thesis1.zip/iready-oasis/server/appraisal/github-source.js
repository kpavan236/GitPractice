'use strict';
const { GITHUB_PR_CAP, GITHUB_SEARCH_CAP } = require('./constants');

// Reads timestamps, states and counts only. No titles, PR numbers or logins are
// kept: the objects returned say WHEN things happened and what they were, never
// WHICH pull request they were.

const REVIEW_STATES = new Set(['APPROVED', 'CHANGES_REQUESTED', 'COMMENTED']);
const day = (d, offset = 0) => new Date(d.getTime() + offset * 86400000).toISOString().slice(0, 10);
const toDate = v => { const d = v ? new Date(v) : null; return d && !Number.isNaN(d.getTime()) ? d : null; };

class GithubUnavailable extends Error {
  constructor(reason) { super(reason); this.name = 'GithubUnavailable'; }
}

function explain(err) {
  const status = err.response && err.response.status;
  if (status === 401) return 'GitHub rejected the saved token. Reconnect GitHub in Settings.';
  if (status === 403 || status === 429) return 'GitHub is limiting requests right now. Try again in a few minutes.';
  if (status === 422) return 'GitHub could not run the search (the organisation or user was not recognised).';
  return 'GitHub could not be reached.';
}

async function searchAll(http, apiBase, headers, q) {
  const items = [];
  let total = 0;
  for (let page = 1; items.length < GITHUB_SEARCH_CAP; page++) {
    let r;
    try {
      r = await http.get(`${apiBase}/search/issues`, { headers, params: { q, per_page: 100, page }, timeout: 20000 });
    } catch (err) { throw new GithubUnavailable(explain(err)); }
    const batch = (r.data && r.data.items) || [];
    total = (r.data && r.data.total_count) || total;
    items.push(...batch);
    if (batch.length < 100) break;
  }
  return { items, truncated: total > items.length };
}

async function reviewsBy(http, headers, login, item) {
  try {
    const r = await http.get(`${item.repository_url}/pulls/${item.number}/reviews`, { headers, params: { per_page: 100 }, timeout: 15000 });
    return (r.data || [])
      .filter(v => v.user && v.user.login === login && REVIEW_STATES.has(v.state) && toDate(v.submitted_at))
      .map(v => ({ at: toDate(v.submitted_at), state: v.state }));
  } catch (err) {
    const status = err.response && err.response.status;
    if (status === 403 || status === 429) throw new GithubUnavailable(explain(err));
    return [];                          // one unreadable PR must not sink the section
  }
}

/**
 * @returns { available: false, reason } or { available: true, partial, authored, reviewed }
 */
async function fetchReviewData({ sess, period, http }) {
  if (!sess.githubUrl || !sess.token || !sess.githubLogin) {
    return { available: false, reason: 'GitHub is not connected, so the code-review section is left out.' };
  }
  const apiBase = `${sess.githubUrl.replace(/\/$/, '')}/api/v3`;
  const headers = { Authorization: `token ${sess.token}`, Accept: 'application/vnd.github+json' };
  const login = sess.githubLogin;
  const org = sess.org ? ` org:${sess.org}` : '';
  const range = `${day(period.start, -1)}..${day(period.end, 1)}`;

  try {
    const created = await searchAll(http, apiBase, headers, `type:pr author:${login}${org} created:${range}`);
    const merged = await searchAll(http, apiBase, headers, `type:pr author:${login}${org} merged:${range}`);
    const reviewedSearch = await searchAll(http, apiBase, headers, `type:pr reviewed-by:${login} -author:${login}${org} updated:${range}`);

    const seen = new Set();
    const authored = [];
    for (const item of [...created.items, ...merged.items]) {
      if (seen.has(item.id)) continue;
      seen.add(item.id);
      authored.push({ created: toDate(item.created_at), merged: toDate(item.pull_request && item.pull_request.merged_at) });
    }

    const toExamine = reviewedSearch.items.slice(0, GITHUB_PR_CAP);
    const reviewed = [];
    for (let i = 0; i < toExamine.length; i += 8) {
      const batch = await Promise.all(toExamine.slice(i, i + 8).map(async item => ({
        prCreated: toDate(item.created_at),
        reviews: await reviewsBy(http, headers, login, item),
      })));
      reviewed.push(...batch);
    }
    return {
      available: true,
      partial: created.truncated || merged.truncated || reviewedSearch.truncated || reviewedSearch.items.length > GITHUB_PR_CAP,
      authored,
      reviewed,
    };
  } catch (err) {
    if (err instanceof GithubUnavailable) return { available: false, reason: err.message };
    throw err;
  }
}

module.exports = { fetchReviewData, GithubUnavailable };
