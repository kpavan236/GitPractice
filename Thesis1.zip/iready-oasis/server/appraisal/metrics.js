'use strict';
const { MIN_PERCENTILE_SAMPLE } = require('./constants');
const { weekKey, weekKeys } = require('./period');

const DAY = 86400000;
const round = (n, places = 2) => (n === null || n === undefined ? null : Math.round(n * 10 ** places) / 10 ** places);
const days = (from, to) => (to.getTime() - from.getTime()) / DAY;
const within = (d, period) => !!d && d.getTime() >= period.start.getTime() && d.getTime() <= period.end.getTime();

function median(values) {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

// Nearest-rank: the smallest value with at least p of the sample at or below it.
function percentile(values, p) {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  return s[Math.max(0, Math.ceil(p * s.length) - 1)];
}

// Median and spread of a list of durations (in days). The 90th percentile is
// withheld for small samples: with 3 tickets it is just "the slowest one" and
// reads as a pattern it is not.
function spread(values) {
  const n = values.length;
  const tooFew = n < MIN_PERCENTILE_SAMPLE;
  return {
    n,
    tooFew,
    median: round(median(values)),
    p90: tooFew ? null : round(percentile(values, 0.9)),
    max: n ? round(Math.max(...values)) : null,
  };
}

function groupSpread(tickets, keyOf, valueOf) {
  const groups = new Map();
  for (const t of tickets) {
    const key = keyOf(t) || 'Unspecified';
    if (!groups.has(key)) groups.set(key, []);
    const v = valueOf(t);
    groups.get(key).push(v);
  }
  return [...groups.entries()]
    .map(([name, values]) => ({ name, closed: values.length, median: round(median(values)) }))
    .sort((a, b) => b.closed - a.closed || a.name.localeCompare(b.name));
}

const HISTOGRAM_EDGES = [0, 1, 2, 3, 5, 8, 13, 21, 34];   // days; the last bin is open-ended

function histogram(values) {
  const bins = HISTOGRAM_EDGES.map((from, i) => {
    const to = i + 1 < HISTOGRAM_EDGES.length ? HISTOGRAM_EDGES[i + 1] : null;
    return { from, to, label: to === null ? `${from}+` : `${from}-${to}`, count: 0 };
  });
  for (const v of values) {
    let i = HISTOGRAM_EDGES.length - 1;
    while (i > 0 && v < HISTOGRAM_EDGES[i]) i -= 1;
    bins[i].count += 1;
  }
  return bins;
}

function sortedSprints(ticket) {
  const stamp = s => (s.end || s.start || new Date(0)).getTime();
  return [...(ticket.sprints || [])].sort((a, b) => stamp(a) - stamp(b));
}

// A "roll" is a ticket that sat in a sprint which ended without it being
// resolved, and then carried on into a later sprint. Counted in the period that
// contains the earlier sprint's end.
function rollEvents(owned, period) {
  const events = [];
  for (const t of owned) {
    const sprints = sortedSprints(t);
    for (let i = 0; i < sprints.length - 1; i++) {
      const s = sprints[i];
      if (s.state !== 'closed' || !s.end) continue;
      if (!within(s.end, period)) continue;
      if (t.resolved && t.resolved.getTime() <= s.end.getTime()) continue;
      events.push(t);
    }
  }
  return events;
}

function sprintTable(owned, period) {
  const bySprint = new Map();
  for (const t of owned) {
    const sprints = sortedSprints(t);
    sprints.forEach((s, i) => {
      if (!s.end || !within(s.end, period)) return;
      if (!bySprint.has(s.id)) bySprint.set(s.id, { id: s.id, name: s.name, end: s.end, committed: 0, completed: 0, rolled: 0, points: 0 });
      const row = bySprint.get(s.id);
      row.committed += 1;
      const doneByEnd = t.resolved && t.resolved.getTime() <= s.end.getTime();
      if (doneByEnd) {
        row.completed += 1;
        if (i === sprints.length - 1 || sprints[i + 1] === undefined) row.points += t.points || 0;
      } else if (i < sprints.length - 1) {
        row.rolled += 1;
      }
    });
  }
  return [...bySprint.values()].sort((a, b) => a.end - b.end).map(({ id, ...rest }) => rest);
}

// The longest run of consecutive sprints in which something was committed and
// nothing rolled.
function longestCleanRun(sprints) {
  let best = 0;
  let run = 0;
  for (const s of sprints) {
    if (s.committed > 0 && s.rolled === 0) { run += 1; best = Math.max(best, run); } else run = 0;
  }
  return best;
}

/**
 * All the statistics for one period.
 *
 * `tickets` hold no ticket ids by design: this module cannot leak what it never
 * receives. Each is { type, priority, points, created, resolved, firstInProgress,
 * owned, reassigned, sprints[], components[] }.
 *
 * @param {object} meta { sprintsAvailable, pointsAvailable }
 */
function computeStats(tickets, period, meta = {}) {
  const owned = tickets.filter(t => t.owned);
  const opened = owned.filter(t => within(t.created, period));
  const closed = owned.filter(t => t.resolved && within(t.resolved, period) && t.created);
  const stillOpen = owned.filter(t => t.created && t.created.getTime() <= period.end.getTime()
    && (!t.resolved || t.resolved.getTime() > period.end.getTime()));
  const reassigned = tickets.filter(t => t.reassigned);

  const lead = closed.map(t => days(t.created, t.resolved)).map(v => Math.max(0, v));
  const withWork = closed.filter(t => t.firstInProgress && t.firstInProgress.getTime() <= t.resolved.getTime());
  const work = withWork.map(t => days(t.firstInProgress, t.resolved));

  const sprintsAvailable = meta.sprintsAvailable !== false;
  const pointsAvailable = meta.pointsAvailable !== false && owned.some(t => typeof t.points === 'number');

  const weeks = weekKeys(period.start, period.end, period.tz);
  const weekly = weeks.map(week => ({
    week,
    opened: opened.filter(t => weekKey(t.created, period.tz) === week).length,
    closed: closed.filter(t => weekKey(t.resolved, period.tz) === week).length,
  }));

  const events = sprintsAvailable ? rollEvents(owned, period) : [];
  const sprints = sprintsAvailable ? sprintTable(owned, period) : [];
  const mixSource = closed.length ? closed : opened;
  const mixTotal = mixSource.length;
  const mix = groupSpread(mixSource, t => t.type, () => 0)
    .map(({ name, closed: count }) => ({ name, count, share: mixTotal ? round(count / mixTotal, 4) : 0 }));

  return {
    opened: opened.length,
    closed: closed.length,
    stillOpen: stillOpen.length,
    reassigned: reassigned.length,
    rolled: {
      available: sprintsAvailable,
      events: sprintsAvailable ? events.length : null,
      tickets: sprintsAvailable ? new Set(events).size : null,
    },
    points: {
      available: pointsAvailable,
      completed: pointsAvailable ? closed.reduce((sum, t) => sum + (t.points || 0), 0) : null,
    },
    leadTime: { ...spread(lead), excludedUnresolved: stillOpen.length },
    workTime: { ...spread(work), missing: closed.length - withWork.length },
    byType: groupSpread(closed, t => t.type, t => Math.max(0, days(t.created, t.resolved))),
    byPriority: groupSpread(closed, t => t.priority, t => Math.max(0, days(t.created, t.resolved))),
    mix,
    weekly,
    histogram: lead.length ? histogram(lead) : [],
    sprints,
    cleanSprintRun: longestCleanRun(sprints),
    activeWeeks: weekly.filter(w => w.closed > 0).length,
    totalWeeks: weekly.length,
    components: new Set(closed.flatMap(t => t.components || [])).size,
  };
}

module.exports = { computeStats, median, percentile, spread, histogram, rollEvents, HISTOGRAM_EDGES };
