'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { fetchTickets, buildJql, parseSprints, findSprintField } = require('./jira-source');
const { parsePeriod } = require('./period');
const { HISTORY_FETCH_CAP } = require('./constants');

const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' }, new Date('2026-10-06T10:00:00Z'));
const SESS = { jiraUrl: 'https://jira.example.test', jiraEmail: 'me@example.test', jiraToken: 'synthetic', jiraAccountId: 'acct-me', jiraPointsField: 'customfield_10016' };

const issue = (key, over = {}) => ({
  key,
  fields: {
    issuetype: { name: 'Story' }, priority: { name: 'Medium' }, created: '2026-01-05T00:00:00.000Z', resolutiondate: null,
    assignee: { accountId: 'acct-me' }, components: [], customfield_10016: 3, ...over,
  },
});
const hist = (when, items) => ({ created: when, items });
const withLog = (i, histories, total) => ({ ...i, changelog: { histories, total: total ?? histories.length } });

// A fake searchAll: the first call returns the candidates, history calls return
// changelog issues looked up by key.
function fakeSearch(candidates, logs = {}) {
  const calls = [];
  const fn = async (base, auth, jql, fields, expand) => {
    calls.push({ jql, fields, expand });
    if (expand === 'changelog') {
      const keys = [...jql.matchAll(/([A-Z][A-Z0-9_]*-\d+)/g)].map(m => m[1]);
      return keys.filter(k => logs[k]).map(k => logs[k]);
    }
    return candidates;
  };
  fn.calls = calls;
  return fn;
}
const http = (statuses = [{ id: '1', statusCategory: { key: 'new' } }, { id: '3', statusCategory: { key: 'indeterminate' } }, { id: '5', statusCategory: { key: 'done' } }]) =>
  ({ get: async () => ({ data: statuses }) });

test('the JQL covers tickets that are yours now or once, around the period, with padded dates', () => {
  const jql = buildJql('acct-me', PERIOD);
  assert.match(jql, /assignee = "acct-me" OR assignee WAS "acct-me"/);
  assert.match(jql, /created >= "2025-12-31"/);
  assert.match(jql, /created <= "2026-04-01"/);
  assert.match(jql, /resolution = EMPTY AND assignee = "acct-me"/);
  assert.match(buildJql('a"b\\c', PERIOD), /a\\"b\\\\c/);
});

test('sprints parse from Cloud objects and legacy strings, keeping every one', () => {
  const objs = parseSprints([{ id: 1, name: 'S1', state: 'CLOSED', startDate: '2026-01-05T00:00:00Z', endDate: '2026-01-19T00:00:00Z' }, { id: 2, name: 'S2', state: 'active' }]);
  assert.deepEqual(objs.map(s => [s.id, s.name, s.state]), [[1, 'S1', 'closed'], [2, 'S2', 'active']]);
  assert.equal(objs[0].end.toISOString(), '2026-01-19T00:00:00.000Z');
  const legacy = parseSprints(['com.atlassian.greenhopper.service.sprint.Sprint@1[id=7,name=Sprint 7,state=CLOSED,startDate=2026-01-05T00:00:00.000Z,endDate=2026-01-19T00:00:00.000Z]']);
  assert.deepEqual([legacy[0].id, legacy[0].name, legacy[0].state], [7, 'Sprint 7', 'closed']);
  assert.deepEqual(parseSprints(null), []);
  assert.deepEqual(parseSprints(['garbage']), []);
});

test('the sprint field is found by its shape, and its absence is reported', () => {
  assert.equal(findSprintField([{ fields: { summary: 'x', customfield_10020: [{ id: 1, name: 'S', state: 'closed', boardId: 4 }] } }]), 'customfield_10020');
  assert.equal(findSprintField([{ fields: { summary: 'x', labels: ['a'] } }]), null);
});

test('your own tickets are owned; others\' are reassigned unless history shows you held them at resolution', async () => {
  const mine = issue('EX-1');
  const heldAtResolution = withLog(
    issue('EX-2', { assignee: { accountId: 'acct-other' }, resolutiondate: '2026-02-01T00:00:00.000Z' }),
    [hist('2026-01-10T00:00:00.000Z', [{ field: 'assignee', to: 'acct-me' }]), hist('2026-02-02T00:00:00.000Z', [{ field: 'assignee', to: 'acct-other' }])]);
  const handedOffEarly = withLog(
    issue('EX-3', { assignee: { accountId: 'acct-other' }, resolutiondate: '2026-02-01T00:00:00.000Z' }),
    [hist('2026-01-10T00:00:00.000Z', [{ field: 'assignee', to: 'acct-me' }]), hist('2026-01-20T00:00:00.000Z', [{ field: 'assignee', to: 'acct-other' }])]);
  const noHistory = issue('EX-4', { assignee: { accountId: 'acct-other' }, resolutiondate: '2026-02-01T00:00:00.000Z' });
  const logs = { 'EX-2': heldAtResolution, 'EX-3': handedOffEarly };
  const { tickets, meta } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([mine, heldAtResolution, handedOffEarly, noHistory], logs), http: http() });
  assert.deepEqual(tickets.map(t => [t.owned, t.reassigned]), [[true, false], [true, false], [false, true], [false, true]]);
  assert.equal(meta.historyMissing, 1);
});

test('the start of work is the first move into an in-progress status', async () => {
  const i = issue('EX-5', { resolutiondate: '2026-01-20T00:00:00.000Z' });
  const log = withLog(i, [
    hist('2026-01-06T00:00:00.000Z', [{ field: 'status', to: '1' }]),
    hist('2026-01-12T00:00:00.000Z', [{ field: 'status', to: '3' }]),
    hist('2026-01-15T00:00:00.000Z', [{ field: 'status', to: '3' }]),
    hist('2026-01-20T00:00:00.000Z', [{ field: 'status', to: '5' }])]);
  const { tickets } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([i], { 'EX-5': log }), http: http() });
  assert.equal(tickets[0].firstInProgress.toISOString(), '2026-01-12T00:00:00.000Z');
});

test('truncated history is not trusted; the ticket falls back to the simple measures', async () => {
  const i = issue('EX-6', { resolutiondate: '2026-01-20T00:00:00.000Z' });
  const log = withLog(i, [hist('2026-01-12T00:00:00.000Z', [{ field: 'status', to: '3' }])], 250);
  const { tickets, meta } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([i], { 'EX-6': log }), http: http() });
  assert.equal(tickets[0].firstInProgress, null);
  assert.equal(meta.historyMissing, 1);
});

test('history is fetched only for tickets resolved in the period or no longer yours, and is capped', async () => {
  const open = issue('EX-7');
  const closedInside = issue('EX-8', { resolutiondate: '2026-02-01T00:00:00.000Z' });
  const closedBefore = issue('EX-9', { resolutiondate: '2025-06-01T00:00:00.000Z' });
  const search = fakeSearch([open, closedInside, closedBefore]);
  await fetchTickets({ sess: SESS, period: PERIOD, searchAll: search, http: http() });
  const historyJql = search.calls.filter(c => c.expand === 'changelog').map(c => c.jql).join(' ');
  assert.match(historyJql, /EX-8/);
  assert.doesNotMatch(historyJql, /EX-7|EX-9/);

  const many = Array.from({ length: HISTORY_FETCH_CAP + 20 }, (_, n) => issue(`EX-${100 + n}`, { resolutiondate: '2026-02-01T00:00:00.000Z' }));
  const capped = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch(many), http: http() });
  assert.equal(capped.meta.historyCapped, true);
});

test('no ticket needing history means no history or status requests at all', async () => {
  const search = fakeSearch([issue('EX-10')]);
  let statusCalls = 0;
  await fetchTickets({ sess: SESS, period: PERIOD, searchAll: search, http: { get: async () => { statusCalls += 1; return { data: [] }; } } });
  assert.equal(search.calls.length, 1);
  assert.equal(statusCalls, 0);
});

test('a failing status lookup degrades to no start-of-work, not an error', async () => {
  const i = issue('EX-11', { resolutiondate: '2026-01-20T00:00:00.000Z' });
  const log = withLog(i, [hist('2026-01-12T00:00:00.000Z', [{ field: 'status', to: '3' }])]);
  const { tickets } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([i], { 'EX-11': log }), http: { get: async () => { throw new Error('nope'); } } });
  assert.equal(tickets[0].firstInProgress, null);
  assert.equal(tickets[0].owned, true);
});

test('points, components and sprints are read; availability flags follow the data', async () => {
  const withSprint = issue('EX-12', { customfield_10020: [{ id: 1, name: 'S1', state: 'closed', boardId: 4 }], components: [{ name: 'api' }, { name: 'ui' }], customfield_10016: 5 });
  const a = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([withSprint]), http: http() });
  assert.deepEqual([a.tickets[0].points, a.tickets[0].components, a.tickets[0].sprints.length], [5, ['api', 'ui'], 1]);
  assert.deepEqual([a.meta.sprintsAvailable, a.meta.pointsAvailable], [true, true]);

  const bare = issue('EX-13', { customfield_10016: undefined });
  const b = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([bare]), http: http() });
  assert.deepEqual([b.meta.sprintsAvailable, b.meta.pointsAvailable], [false, false]);
});

test('returned tickets name nothing: no keys, summaries or other identifiers', async () => {
  const i = issue('EX-14', { summary: 'Rotate the credentials', resolutiondate: '2026-02-01T00:00:00.000Z' });
  const { tickets } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch([i]), http: http() });
  const dump = JSON.stringify(tickets);
  assert.doesNotMatch(dump, /EX-14|Rotate|"key"|"summary"|acct-me|me@example/);
  assert.deepEqual(Object.keys(tickets[0]).sort(), ['components', 'created', 'firstInProgress', 'owned', 'points', 'priority', 'reassigned', 'resolved', 'sprints', 'type']);
});

test('reaching the ticket cap marks the result partial', async () => {
  const many = Array.from({ length: 5000 }, (_, n) => issue(`EX-${n + 1}`));
  const { meta } = await fetchTickets({ sess: SESS, period: PERIOD, searchAll: fakeSearch(many), http: http() });
  assert.equal(meta.capped, true);
});
