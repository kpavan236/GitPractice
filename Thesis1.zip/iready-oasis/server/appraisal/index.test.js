'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const express = require('express');
const { installAppraisal } = require('./index');

const issue = (key, over = {}) => ({
  key,
  fields: {
    summary: 'Rotate the production credentials', issuetype: { name: 'Bug' }, priority: { name: 'High' },
    created: '2026-01-05T00:00:00.000Z', resolutiondate: '2026-01-07T00:00:00.000Z',
    assignee: { accountId: 'acct-me', displayName: 'Pat Example', emailAddress: 'pat@example.test' },
    components: [], customfield_10016: 3, ...over,
  },
});
const batch = (n, over = {}) => Array.from({ length: n }, (_, i) => issue(`EX-${i + 1}`, over));

const BODY = { mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' };

async function start(opts = {}) {
  const sessions = {
    s1: { jiraUrl: 'https://jira.example.test', jiraEmail: 'pat@example.test', jiraToken: 'synthetic', jiraAccountId: 'acct-me', jiraDisplayName: 'Pat Example', ...opts.sess },
    s2: {},
  };
  const calls = [];
  const searchAll = opts.searchAll || (async (base, auth, jql, fields, expand) => { calls.push({ jql, expand }); return expand ? [] : batch(6); });
  const aiClientFor = opts.aiClientFor || (() => ({ available: () => false, complete: async () => '' }));
  const storePath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'appraisal-api-')), 'a.json');
  const app = express();
  app.use(express.json());
  const installed = installAppraisal(app, { sessions, aiClientFor, searchAll, http: { get: async () => ({ data: [] }) }, storePath });
  const server = http.createServer(app);
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, p, body, headers = {}) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
  return { call, calls, storePath, installed, sessions, close: () => new Promise(r => { server.closeAllConnections(); server.close(r); }) };
}

test('every route needs a valid session', async () => {
  const s = await start();
  try {
    for (const [m, p, b] of [['GET', '/api/appraisal/status'], ['POST', '/api/appraisal/build', BODY], ['GET', '/api/appraisal/pack'],
      ['GET', '/api/appraisal/draft?period=2026-01-01_2026-03-31'], ['PUT', '/api/appraisal/draft', {}], ['DELETE', '/api/appraisal/data']]) {
      assert.equal((await s.call(m, p, b)).status, 401, `${m} ${p}`);
      assert.equal((await s.call(m, `${p}${p.includes('?') ? '&' : '?'}session=nope`, b)).status, 401);
    }
  } finally { await s.close(); }
});

test('requests from a non-local origin are refused', async () => {
  const s = await start();
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' }, { Origin: 'https://evil.example' });
    assert.equal(res.status, 403);
    assert.equal((await s.call('GET', '/api/appraisal/status?session=s1', undefined, { Origin: 'http://localhost:3000' })).status, 200);
  } finally { await s.close(); }
});

test('a bad period is a 400 with a reason, and JIRA not connected is a guided 400', async () => {
  const s = await start();
  try {
    const bad = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1', from: '2026-06-01T00:00:00.000Z' });
    assert.equal(bad.status, 400);
    assert.match(bad.body.error, /after the end date/);
    const notConnected = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's2' });
    assert.equal(notConnected.status, 400);
    assert.equal(notConnected.body.code, 'JIRA_NOT_CONNECTED');
  } finally { await s.close(); }
});

test('a build returns a pack of statistics and rule-based text when AI is not available', async () => {
  const s = await start();
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(res.status, 200);
    const p = res.body;
    assert.equal(p.period.key, '2026-01-01_2026-03-31');
    assert.equal(p.user.displayName, 'Pat Example');
    assert.equal(p.stats.opened, 6);
    assert.equal(p.stats.closed, 6);
    assert.equal(p.stats.leadTime.median, 2);
    assert.equal(p.narrative.source, 'rules');
    assert.equal(p.narrative.reason, 'ai-unavailable');
    assert.equal(p.review.available, false);
    assert.ok(Array.isArray(p.candidates));
  } finally { await s.close(); }
});

test('the pack names no ticket, person or title anywhere', async () => {
  const s = await start();
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    const dump = JSON.stringify(res.body);
    assert.doesNotMatch(dump, /EX-\d+|Rotate the production|acct-me|pat@example|jira\.example|synthetic/);
    const status = await s.call('GET', '/api/appraisal/status?session=s1');
    assert.doesNotMatch(JSON.stringify(status.body), /synthetic|jira\.example|pat@example/);
  } finally { await s.close(); }
});

test('only the session\'s own identity is used; any user named in the request is ignored', async () => {
  const s = await start();
  try {
    const res = await s.call('POST', '/api/appraisal/build', {
      ...BODY, session: 's1', user: 'someone-else', accountId: 'acct-victim', login: 'victim', email: 'victim@example.test', assignee: 'acct-victim',
    });
    assert.equal(res.status, 200);
    const jqls = s.calls.map(c => c.jql).join(' ');
    assert.match(jqls, /acct-me/);
    assert.doesNotMatch(jqls, /victim|someone-else/);
    assert.equal(res.body.user.displayName, 'Pat Example');
  } finally { await s.close(); }
});

test('AI is used when it is available, and what it receives holds no identifiers', async () => {
  const requests = [];
  const ai = {
    available: () => true,
    complete: async req => { requests.push(req); return JSON.stringify({ summary: 'A solid period: you closed {closed} of {opened}.', kudos: [], prompts: ['What went well?'] }); },
  };
  const s = await start({ aiClientFor: () => ai, sess: { aiProvider: 'bedrock', aiModel: 'm1' } });
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(res.body.narrative.source, 'ai');
    assert.equal(res.body.narrative.provider, 'bedrock');
    assert.match(res.body.narrative.summary.text, /closed 6 of 6/);
    assert.equal(requests.length, 1);
    assert.doesNotMatch(JSON.stringify(requests[0]), /EX-\d+|Rotate|acct-me|pat@example|Pat Example/);
    const off = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1', useAi: false });
    assert.equal(off.body.narrative.reason, 'ai-off');
    assert.equal(requests.length, 1, 'no AI call when switched off');
  } finally { await s.close(); }
});

test('an AI failure never blocks the pack', async () => {
  const s = await start({ aiClientFor: () => ({ available: () => true, complete: async () => { throw new Error('provider down'); } }) });
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(res.status, 200);
    assert.equal(res.body.narrative.reason, 'ai-failed');
  } finally { await s.close(); }
});

test('JIRA auth failures and outages become clear 502s; one transient failure is retried', async () => {
  const authFail = await start({ searchAll: async () => { const e = new Error('x'); e.response = { status: 401 }; throw e; } });
  try {
    const r = await authFail.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(r.status, 502);
    assert.equal(r.body.code, 'JIRA_AUTH');
  } finally { await authFail.close(); }

  const down = await start({ searchAll: async () => { throw new Error('ETIMEDOUT'); } });
  try {
    const r = await down.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(r.status, 502);
    assert.equal(r.body.code, 'JIRA_UNREACHABLE');
  } finally { await down.close(); }

  let attempts = 0;
  const flaky = await start({ searchAll: async (b, a, jql, f, expand) => { if (!expand && attempts++ === 0) throw new Error('blip'); return expand ? [] : batch(2); } });
  try {
    assert.equal((await flaky.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' })).status, 200);
  } finally { await flaky.close(); }
});

test('code review that is switched off or unavailable is reported, and the rest of the pack stands', async () => {
  const s = await start();
  try {
    const off = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1', includeCodeReview: false });
    assert.match(off.body.review.reason, /turned off/);
    const unavailable = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.match(unavailable.body.review.reason, /not connected/);
    assert.equal(unavailable.status, 200);
  } finally { await s.close(); }
});

test('the previous period is fetched only when there are enough closed tickets, and enables the improvement suggestion', async () => {
  const quick = i => issue(`EX-${i}`, { resolutiondate: '2026-01-06T00:00:00.000Z' });
  const slow = i => issue(`EX-${i + 100}`, { created: '2025-11-01T00:00:00.000Z', resolutiondate: '2025-11-21T00:00:00.000Z' });
  const seen = [];
  const s = await start({ searchAll: async (b, a, jql, f, expand) => {
    seen.push(jql);
    if (expand) return [];
    return /created >= "2025-1/.test(jql) && !/created >= "2025-12-31"/.test(jql) ? Array.from({ length: 6 }, (_, i) => slow(i)) : Array.from({ length: 6 }, (_, i) => quick(i));
  } });
  try {
    const res = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(res.status, 200);
    assert.ok(res.body.candidates.some(c => c.kind === 'improvement'));
  } finally { await s.close(); }

  const few = await start({ searchAll: async (b, a, jql, f, expand) => (expand ? [] : batch(2)), });
  try {
    const res = await few.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(res.body.candidates.some(c => c.kind === 'improvement'), false);
  } finally { await few.close(); }
});

test('building twice: the older build is told it was superseded', async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  let first = true;
  const s = await start({ searchAll: async (b, a, jql, f, expand) => {
    if (expand) return [];
    if (first) { first = false; await gate; }
    return batch(2);
  } });
  try {
    const older = s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    await new Promise(r => setTimeout(r, 50));
    const newer = await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    release();
    assert.equal(newer.status, 200);
    const old = await older;
    assert.equal(old.status, 409);
    assert.equal(old.body.code, 'SUPERSEDED');
  } finally { await s.close(); }
});

test('drafts save and load per period through their own file, never the prefs file', async () => {
  const s = await start();
  try {
    const key = '2026-01-01_2026-03-31';
    assert.equal((await s.call('GET', `/api/appraisal/draft?session=s1&period=${key}`)).body.draft, null);
    const saved = await s.call('PUT', '/api/appraisal/draft', { session: 's1', period: key, draft: { talkingPoints: 'my own words', confirmed: [{ id: 'a', title: 'T', text: 'Kudos text', source: 'own' }] } });
    assert.equal(saved.status, 200);
    const loaded = await s.call('GET', `/api/appraisal/draft?session=s1&period=${key}`);
    assert.equal(loaded.body.draft.talkingPoints, 'my own words');
    assert.equal((fs.statSync(s.storePath).mode & 0o777).toString(8), '600');
    assert.equal((await s.call('GET', '/api/appraisal/draft?session=s1&period=bad')).status, 400);
    assert.equal((await s.call('PUT', '/api/appraisal/draft', { session: 's1', period: 'bad', draft: {} })).status, 400);
  } finally { await s.close(); }
});

test('clearing removes the drafts, the notice acknowledgement and the in-memory pack', async () => {
  const s = await start();
  try {
    await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    await s.call('PUT', '/api/appraisal/draft', { session: 's1', period: '2026-01-01_2026-03-31', draft: { talkingPoints: 'private' } });
    await s.call('POST', '/api/appraisal/ai-notice', { session: 's1' });
    assert.equal((await s.call('GET', '/api/appraisal/status?session=s1')).body.ai.noticeAcknowledged, true);
    assert.equal((await s.call('GET', '/api/appraisal/pack?session=s1')).status, 200);

    assert.equal((await s.call('DELETE', '/api/appraisal/data?session=s1')).status, 200);
    assert.equal((await s.call('GET', '/api/appraisal/pack?session=s1')).status, 404);
    assert.equal((await s.call('GET', '/api/appraisal/draft?session=s1&period=2026-01-01_2026-03-31')).body.draft, null);
    assert.equal((await s.call('GET', '/api/appraisal/status?session=s1')).body.ai.noticeAcknowledged, false);
  } finally { await s.close(); }
});

test('the built pack is never written to disk', async () => {
  const s = await start();
  try {
    await s.call('POST', '/api/appraisal/build', { ...BODY, session: 's1' });
    assert.equal(fs.existsSync(s.storePath), false, 'no file until the user saves a draft');
  } finally { await s.close(); }
});

test('this feature never touches the Notes or the prefs file (static guard on the source)', () => {
  const dir = __dirname;
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js') && !f.endsWith('.test.js'))) {
    const code = fs.readFileSync(path.join(dir, file), 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
    assert.doesNotMatch(code, /oasis-prefs|PREFS_PATH|\/api\/prefs|\bnotes\b/i, file);
  }
});
