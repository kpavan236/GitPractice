'use strict';
const { JIRA_TICKET_CAP, HISTORY_FETCH_CAP, HISTORY_CHUNK } = require('./constants');

// This module is the ONLY place a ticket key exists. Keys are needed to ask JIRA
// for status history, and they are dropped before anything is returned: the
// tickets it hands back carry statistics inputs and nothing that names a ticket.

const KEY_FORMAT = /^[A-Z][A-Z0-9_]*-\d+$/;
const dayBefore = d => new Date(d.getTime() - 86400000).toISOString().slice(0, 10);
const dayAfter = d => new Date(d.getTime() + 86400000).toISOString().slice(0, 10);
const toDate = v => { const d = v ? new Date(v) : null; return d && !Number.isNaN(d.getTime()) ? d : null; };
const quote = s => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

/**
 * Your tickets that could matter to the period: assigned to you now or ever, and
 * created, resolved or updated around it, or still open and yours. Dates are
 * padded by a day either side because JQL compares in the JIRA user's time zone;
 * the exact filtering is done afterwards in code.
 */
function buildJql(accountId, period) {
  const me = quote(accountId);
  return `(assignee = "${me}" OR assignee WAS "${me}") AND `
    + `(created >= "${dayBefore(period.start)}" OR resolutiondate >= "${dayBefore(period.start)}" `
    + `OR updated >= "${dayBefore(period.start)}" OR (resolution = EMPTY AND assignee = "${me}")) `
    + `AND created <= "${dayAfter(period.end)}"`;
}

// Sprint values come as objects (Cloud) or as legacy strings. Returns every
// sprint the ticket has been in, in field order.
function parseSprints(value) {
  const list = Array.isArray(value) ? value : value ? [value] : [];
  const out = [];
  for (const raw of list) {
    if (raw && typeof raw === 'object' && raw.id !== undefined) {
      out.push({ id: raw.id, name: raw.name || `Sprint ${raw.id}`, state: String(raw.state || '').toLowerCase(),
        start: toDate(raw.startDate), end: toDate(raw.endDate || raw.completeDate) });
    } else if (typeof raw === 'string') {
      const id = raw.match(/id=(\d+)/)?.[1];
      const name = raw.match(/name=([^,\]]+)/)?.[1];
      if (!id || !name) continue;
      out.push({ id: Number(id), name, state: (raw.match(/state=([A-Za-z]+)/)?.[1] || '').toLowerCase(),
        start: toDate(raw.match(/startDate=([^,\]]+)/)?.[1]), end: toDate(raw.match(/endDate=([^,\]]+)/)?.[1]) });
    }
  }
  return out;
}

function looksLikeSprintValue(v) {
  if (!Array.isArray(v) || !v.length) return false;
  const first = v[0];
  if (first && typeof first === 'object') return 'boardId' in first || ('id' in first && 'name' in first && 'state' in first);
  return typeof first === 'string' && /greenhopper|sprint/i.test(first);
}

function findSprintField(issues) {
  for (const issue of issues) {
    for (const [key, value] of Object.entries(issue.fields || {})) {
      if (looksLikeSprintValue(value)) return key;
    }
  }
  return null;
}

const sameUser = (value, accountId, email) => {
  if (!value) return false;
  const v = String(value).toLowerCase();
  return v === String(accountId).toLowerCase() || (!!email && v === String(email).toLowerCase());
};

// What the changelog tells us. `truncated` means JIRA returned fewer entries than
// exist, so the history cannot be trusted and the ticket falls back to the
// simple measures.
function readHistory(issue, statusCategory) {
  const log = issue.changelog;
  if (!log || !Array.isArray(log.histories)) return null;
  if (typeof log.total === 'number' && log.total > log.histories.length) return { truncated: true };
  const entries = [...log.histories].sort((a, b) => Date.parse(a.created) - Date.parse(b.created));
  let firstInProgress = null;
  const assigneeChanges = [];
  for (const h of entries) {
    const at = toDate(h.created);
    for (const item of h.items || []) {
      if (item.field === 'status' && !firstInProgress && statusCategory.get(String(item.to)) === 'indeterminate') firstInProgress = at;
      if (item.field === 'assignee') assigneeChanges.push({ at, to: item.to });
    }
  }
  return { truncated: false, firstInProgress, assigneeChanges };
}

function assigneeAt(history, when, accountId, email) {
  let current;
  for (const c of history.assigneeChanges) {
    if (when && c.at && c.at.getTime() > when.getTime()) break;
    current = c.to;
  }
  return sameUser(current, accountId, email);
}

async function fetchStatusCategories({ http, base, auth }) {
  try {
    const r = await http.get(`${base}/rest/api/2/status`, { auth, timeout: 15000 });
    return new Map((r.data || []).map(s => [String(s.id), s.statusCategory?.key]));
  } catch (_) {
    return new Map();
  }
}

/**
 * @param {object} deps  { sess, period, searchAll, http, base?, auth? }
 * @returns { tickets, meta }  tickets have no identifiers.
 */
async function fetchTickets({ sess, period, searchAll, http }) {
  const base = sess.jiraUrl;
  const auth = { username: sess.jiraEmail, password: sess.jiraToken };
  const accountId = sess.jiraAccountId || sess.jiraEmail;
  const email = sess.jiraEmail;
  const pointsField = sess.jiraPointsField || 'customfield_10016';

  const issues = await searchAll(base, auth, buildJql(accountId, period), ['*all']);
  const sprintField = findSprintField(issues);
  const meta = {
    sprintsAvailable: sprintField !== null,
    pointsAvailable: false,
    capped: issues.length >= JIRA_TICKET_CAP,
    historyCapped: false,
    historyMissing: 0,
  };

  const rows = issues.map(issue => {
    const f = issue.fields || {};
    const points = typeof f[pointsField] === 'number' ? f[pointsField] : null;
    if (points !== null) meta.pointsAvailable = true;
    return {
      key: issue.key,
      type: f.issuetype?.name || '',
      priority: f.priority?.name || '',
      points,
      created: toDate(f.created),
      resolved: toDate(f.resolutiondate),
      sprints: sprintField ? parseSprints(f[sprintField]) : [],
      components: (f.components || []).map(c => c.name).filter(Boolean),
      currentIsMe: sameUser(f.assignee?.accountId || f.assignee?.name || f.assignee?.emailAddress, accountId, email),
    };
  });

  // Status history is wanted for tickets resolved in the period and for any that
  // are no longer yours; capped so a long period cannot make the build crawl.
  const inPeriod = d => d && d.getTime() >= period.start.getTime() && d.getTime() <= period.end.getTime();
  const wanted = rows.filter(r => KEY_FORMAT.test(r.key || '') && (inPeriod(r.resolved) || !r.currentIsMe));
  const toFetch = wanted.slice(0, HISTORY_FETCH_CAP);
  meta.historyCapped = wanted.length > HISTORY_FETCH_CAP;

  const histories = new Map();
  if (toFetch.length) {
    const statusCategory = await fetchStatusCategories({ http, base, auth });
    for (let i = 0; i < toFetch.length; i += HISTORY_CHUNK) {
      const keys = toFetch.slice(i, i + HISTORY_CHUNK).map(r => r.key);
      const found = await searchAll(base, auth, `key in (${keys.join(',')})`, ['assignee'], 'changelog');
      for (const issue of found) {
        const h = readHistory(issue, statusCategory);
        if (h && !h.truncated) histories.set(issue.key, h);
      }
    }
  }

  const tickets = rows.map(r => {
    const h = histories.get(r.key);
    let owned = r.currentIsMe;
    let reassigned = false;
    if (!owned) {
      if (h && r.resolved && assigneeAt(h, r.resolved, accountId, email)) owned = true;
      else reassigned = true;
    }
    if (wanted.includes(r) && !h) meta.historyMissing += 1;
    return {
      type: r.type, priority: r.priority, points: r.points, created: r.created, resolved: r.resolved,
      firstInProgress: h ? h.firstInProgress : null,
      owned, reassigned, sprints: r.sprints, components: r.components,
    };
  });
  return { tickets, meta };
}

module.exports = { fetchTickets, buildJql, parseSprints, findSprintField, readHistory, KEY_FORMAT };
