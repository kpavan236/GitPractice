'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { generateNarrative, ruleNarrative, aiRequest, parseJson } = require('./narrative');
const { computeStats } = require('./metrics');
const { parsePeriod } = require('./period');

const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-05T00:00:00.000Z', to: '2026-03-01T23:59:59.999Z', tz: 'UTC' }, new Date('2026-10-06T10:00:00Z'));
const d = s => new Date(s);
const t = (over = {}) => ({
  type: 'Story', priority: 'Medium', points: 3, created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-09T00:00:00Z'),
  firstInProgress: null, owned: true, reassigned: false, sprints: [], components: [], ...over,
});
const STATS = computeStats([t(), t(), t(), t(), t(), t({ resolved: null })], PERIOD);
const CANDS = [{ id: 'bigDeliveries', kind: 'bigDeliveries', title: 'Big deliveries', template: 'x', vars: { count: 2, points: 13 }, text: 'You delivered 2 larger tickets, 13 story points in all.' }];

const fakeAi = (reply, { available = true } = {}) => ({
  available: () => available,
  calls: [],
  async complete(args) { this.calls.push(args); if (reply instanceof Error) throw reply; return typeof reply === 'function' ? reply() : reply; },
});
const GOOD = JSON.stringify({
  summary: 'You closed {closed} of the {opened} tickets you opened, with a median of {median} days.',
  kudos: [{ id: 'bigDeliveries', text: 'You took on {count} larger pieces of work worth {points} points.' }],
  prompts: ['What helped you close {closed} tickets?'],
});

test('rule-based wording states the real figures and adds prompts for what the numbers show', () => {
  const r = ruleNarrative(STATS, CANDS, null);
  assert.match(r.summary, /opened 6 and closed 5 tickets/);
  assert.match(r.summary, /median time to close was 4 days/);
  assert.match(r.summary, /completed 15 story points/);
  assert.equal(r.prompts.length, 4);
  assert.equal(r.kudos.bigDeliveries, CANDS[0].text);
});

test('AI off, unavailable or throwing all fall back to rules with the reason', async () => {
  const base = { stats: STATS, candidates: CANDS };
  assert.equal((await generateNarrative({ ...base, ai: fakeAi(GOOD), useAi: false })).reason, 'ai-off');
  assert.equal((await generateNarrative({ ...base, ai: fakeAi(GOOD, { available: false }) })).reason, 'ai-unavailable');
  assert.equal((await generateNarrative({ ...base, ai: null })).reason, 'ai-unavailable');
  assert.equal((await generateNarrative({ ...base, ai: fakeAi(new Error('boom')) })).reason, 'ai-failed');
  assert.equal((await generateNarrative({ ...base, ai: fakeAi('not json at all') })).reason, 'ai-failed');
  const slow = { available: () => true, complete: () => new Promise(() => {}) };
  assert.equal((await generateNarrative({ ...base, ai: slow, timeoutMs: 20 })).reason, 'ai-failed');
});

test('good AI output is used, with the real figures substituted by code', async () => {
  const n = await generateNarrative({ stats: STATS, candidates: CANDS, ai: fakeAi(GOOD), aiInfo: { provider: 'bedrock', model: 'm1' } });
  assert.equal(n.source, 'ai');
  assert.equal(n.provider, 'bedrock');
  assert.equal(n.summary.ai, true);
  assert.match(n.summary.text, /closed 5 of the 6 tickets you opened, with a median of 4 days/);
  assert.equal(n.kudos[0].text, 'You took on 2 larger pieces of work worth 13 points.');
  assert.equal(n.kudos[0].ai, true);
  assert.deepEqual(n.prompts, [{ text: 'What helped you close 5 tickets?', ai: true }]);
});

test('JSON wrapped in prose or a code fence is still read', () => {
  assert.deepEqual(parseJson('Here you go:\n```json\n{"a":1}\n```'), { a: 1 });
  assert.equal(parseJson('nothing'), null);
  assert.equal(parseJson('{broken'), null);
  assert.equal(parseJson(42), null);
});

test('an AI field that invents a number is replaced by rule text while the others are kept', async () => {
  const reply = JSON.stringify({
    summary: 'You closed 99 tickets, a record.',
    kudos: [{ id: 'bigDeliveries', text: 'Larger pieces of work worth {points} points.' }],
    prompts: ['What went well?'],
  });
  const n = await generateNarrative({ stats: STATS, candidates: CANDS, ai: fakeAi(reply) });
  assert.equal(n.source, 'ai');
  assert.equal(n.summary.ai, false);
  assert.match(n.summary.text, /opened 6 and closed 5/);
  assert.equal(n.kudos[0].ai, true);
  assert.equal(n.rejected, 1);
});

test('when everything the AI wrote is rejected the result is plain rules with a reason', async () => {
  const reply = JSON.stringify({ summary: 'Closed 99.', kudos: [{ id: 'bigDeliveries', text: '13 points!' }], prompts: ['Is 3 enough?'] });
  const n = await generateNarrative({ stats: STATS, candidates: CANDS, ai: fakeAi(reply) });
  assert.equal(n.source, 'rules');
  assert.equal(n.reason, 'ai-rejected');
});

test('the request sent to the AI holds statistics and placeholders only', async () => {
  const ai = fakeAi(GOOD);
  await generateNarrative({ stats: STATS, candidates: CANDS, ai });
  const sent = ai.calls[0];
  const body = sent.messages[0].content;
  const parsed = JSON.parse(body);
  assert.deepEqual(Object.keys(parsed).sort(), ['candidates', 'figures', 'globalPlaceholders']);
  assert.deepEqual(parsed.candidates[0], { id: 'bigDeliveries', title: 'Big deliveries', placeholders: ['count', 'points'], figures: { count: 2, points: 13 } });
  assert.doesNotMatch(body, /[A-Z][A-Z0-9]+-\d+|http|@|"key"|"summary":"[A-Z]/);
  assert.match(sent.system, /NOT write any number/);
  assert.equal(sent.maxTokens, 1500);
  assert.deepEqual(aiRequest(STATS, CANDS, null).messages[0].content, body);
});
