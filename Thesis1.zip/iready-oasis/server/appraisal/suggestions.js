'use strict';
const { KUDOS, HIGH_PRIORITIES, MIN_PERCENTILE_SAMPLE } = require('./constants');
const { median } = require('./metrics');
const { fillPlaceholders } = require('./ai-guard');

const DAY = 86400000;

// Each candidate: { id, kind, title, template, vars, text }.
//   template  rule-written wording with {placeholders}
//   vars      the candidate's own figures
//   text      the template filled in (what the user sees until they edit it)
// Evidence is figures only. A candidate never carries a ticket id, a PR number
// or a title, because nothing here is ever given one.
function candidate(id, title, template, vars) {
  return { id, kind: id, title, template, vars, text: fillPlaceholders(template, vars) };
}

function closedInPeriod(tickets, period) {
  return tickets.filter(t => t.owned && t.created && t.resolved
    && t.resolved.getTime() >= period.start.getTime() && t.resolved.getTime() <= period.end.getTime());
}

const daysTaken = t => Math.max(0, (t.resolved.getTime() - t.created.getTime()) / DAY);

function quickTurnaround(closed) {
  const cfg = KUDOS.quickTurnaround;
  const byType = new Map();
  for (const t of closed) {
    const key = t.type || 'Unspecified';
    if (!byType.has(key)) byType.set(key, []);
    byType.get(key).push(daysTaken(t));
  }
  let count = 0;
  for (const times of byType.values()) {
    if (times.length < cfg.minTypeSample) continue;
    const typical = median(times);
    count += times.filter(v => v <= typical * cfg.fraction).length;
  }
  return count >= cfg.minTickets
    ? candidate('quickTurnaround', 'Quick turnaround',
        'You closed {count} tickets in half the usual time or less for their type.', { count })
    : null;
}

/**
 * Finds the kudos and achievements the numbers support.
 *
 * @param {object} input { tickets, stats, period, prevStats?, review? }
 */
function buildCandidates({ tickets, stats, period, prevStats = null, review = null }) {
  const out = [];
  const closed = closedInPeriod(tickets, period);
  const push = c => { if (c) out.push(c); };

  push(quickTurnaround(closed));

  if (stats.rolled.available && stats.cleanSprintRun >= KUDOS.cleanSprints.minConsecutive) {
    push(candidate('cleanSprints', 'Clean sprints',
      '{count} sprints in a row with nothing rolled over.', { count: stats.cleanSprintRun }));
  }

  const high = closed.filter(t => HIGH_PRIORITIES.includes(String(t.priority || '').toLowerCase())).length;
  if (high >= KUDOS.highPriority.minTickets) {
    push(candidate('highPriority', 'High-priority delivery',
      'You closed {count} tickets of the highest priority.', { count: high }));
  }

  const big = closed.filter(t => typeof t.points === 'number' && t.points >= KUDOS.bigDeliveries.minPoints);
  if (big.length >= 1) {
    push(candidate('bigDeliveries', 'Big deliveries',
      'You delivered {count} larger tickets, {points} story points in all.',
      { count: big.length, points: big.reduce((n, t) => n + t.points, 0) }));
  }

  if (stats.totalWeeks >= KUDOS.steadyOutput.minWeeks
      && stats.activeWeeks / stats.totalWeeks >= KUDOS.steadyOutput.minShare) {
    push(candidate('steadyOutput', 'Steady output',
      'You closed work in {percent} percent of the weeks, {weeks} of {total}.',
      { percent: Math.round((stats.activeWeeks / stats.totalWeeks) * 100), weeks: stats.activeWeeks, total: stats.totalWeeks }));
  }

  const cur = stats.leadTime;
  const prev = prevStats && prevStats.leadTime;
  if (prev && cur.n >= KUDOS.improvement.minSample && prev.n >= KUDOS.improvement.minSample
      && prev.median > 0 && cur.median <= prev.median * KUDOS.improvement.maxRatio) {
    push(candidate('improvement', 'Faster than the previous period',
      'Your median time to close fell by {percent} percent compared with the previous period.',
      { percent: Math.round((1 - cur.median / prev.median) * 100) }));
  }

  if (stats.components >= KUDOS.breadth.minComponents) {
    push(candidate('breadth', 'Breadth of work',
      'You closed work across {count} different components.', { count: stats.components }));
  }

  if (review && review.available) {
    if (review.prsMerged >= KUDOS.shippingPrs.minMerged) {
      push(candidate('shippingPrs', 'Shipping pull requests',
        'You merged {count} pull requests.', { count: review.prsMerged }));
    }
    const first = review.firstReviewHours;
    if (review.reviews.total >= KUDOS.reviewPartner.minReviews && first.median !== null
        && first.median <= KUDOS.reviewPartner.maxFirstReviewHours) {
      push(candidate('reviewPartner', 'Review partner',
        'You gave {count} reviews, usually within {hours} hours of a pull request opening.',
        { count: review.reviews.total, hours: Math.max(1, Math.round(first.median)) }));
    }
  }
  return out;
}

module.exports = { buildCandidates, MIN_PERCENTILE_SAMPLE };
