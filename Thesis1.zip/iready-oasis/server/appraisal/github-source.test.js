'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { fetchReviewData } = require('./github-source');
const { parsePeriod } = require('./period');

const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' }, new Date('2026-10-06T10:00:00Z'));
const SESS = { githubUrl: 'https://ghe.example.test/', token: 'synthetic', githubLogin: 'me-user', org: 'example-org' };
const API = 'https://ghe.example.test/api/v3';

const pr = (id, over = {}) => ({ id, number: id, title: `Secret title ${id}`, created_at: '2026-01-05T00:00:00Z', repository_url: `${API}/repos/example-org/repo-a`, pull_request: { merged_at: null }, ...over });
const review = (login, state, at) => ({ user: { login }, state, submitted_at: at });

// Routes by URL / query so each search gets its own answer.
function fakeHttp({ created = [], merged = [], reviewedItems = [], reviews = {}, fail = null }) {
  const calls = [];
  return {
    calls,
    async get(url, { params } = {}) {
      calls.push({ url, params });
      if (fail) { const e = new Error('x'); e.response = { status: fail }; throw e; }
      if (url.endsWith('/search/issues')) {
        const q = params.q;
        const pick = q.includes('reviewed-by:') ? reviewedItems : q.includes(' merged:') ? merged : created;
        const start = (params.page - 1) * 100;
        return { data: { total_count: pick.length, items: pick.slice(start, start + 100) } };
      }
      const m = url.match(/pulls\/(\d+)\/reviews$/);
      return { data: reviews[m[1]] || [] };
    },
  };
}

test('not connected is reported, not thrown', async () => {
  const r = await fetchReviewData({ sess: {}, period: PERIOD, http: fakeHttp({}) });
  assert.equal(r.available, false);
  assert.match(r.reason, /not connected/);
});

test('authored PRs are the union of created-in-period and merged-in-period, without duplicates', async () => {
  const a = pr(1, { pull_request: { merged_at: '2026-01-06T00:00:00Z' } });
  const b = pr(2, { created_at: '2025-12-20T00:00:00Z', pull_request: { merged_at: '2026-01-02T00:00:00Z' } });
  const r = await fetchReviewData({ sess: SESS, period: PERIOD, http: fakeHttp({ created: [a], merged: [a, b] }) });
  assert.equal(r.available, true);
  assert.equal(r.authored.length, 2);
  assert.equal(r.authored[0].merged.toISOString(), '2026-01-06T00:00:00.000Z');
});

test('reviews are kept only if they are yours, a known state, and dated', async () => {
  const item = pr(10, { created_at: '2026-01-10T00:00:00Z' });
  const reviews = { 10: [
    review('me-user', 'APPROVED', '2026-01-11T00:00:00Z'),
    review('me-user', 'DISMISSED', '2026-01-12T00:00:00Z'),
    review('someone-else', 'APPROVED', '2026-01-11T00:00:00Z'),
    review('me-user', 'COMMENTED', null),
    review('me-user', 'CHANGES_REQUESTED', '2026-01-10T05:00:00Z') ] };
  const r = await fetchReviewData({ sess: SESS, period: PERIOD, http: fakeHttp({ reviewedItems: [item], reviews }) });
  assert.deepEqual(r.reviewed[0].reviews.map(v => v.state).sort(), ['APPROVED', 'CHANGES_REQUESTED']);
  assert.equal(r.reviewed[0].prCreated.toISOString(), '2026-01-10T00:00:00.000Z');
});

test('searches are scoped to the user and organisation with a padded date range', async () => {
  const http = fakeHttp({});
  await fetchReviewData({ sess: SESS, period: PERIOD, http });
  const queries = http.calls.filter(c => c.url.endsWith('/search/issues')).map(c => c.params.q);
  assert.equal(queries.length, 3);
  assert.ok(queries.every(q => q.includes('org:example-org') && q.includes('2025-12-31..2026-04-01')));
  assert.ok(queries.some(q => q.includes('author:me-user') && q.includes('created:')));
  assert.ok(queries.some(q => q.includes('reviewed-by:me-user') && q.includes('-author:me-user')));
  assert.ok(http.calls.every(c => c.url.startsWith(API)));
});

test('more than the PR cap marks the result partial and examines only the cap', async () => {
  const many = Array.from({ length: 230 }, (_, i) => pr(1000 + i));
  const http = fakeHttp({ reviewedItems: many });
  const r = await fetchReviewData({ sess: SESS, period: PERIOD, http });
  assert.equal(r.partial, true);
  assert.equal(r.reviewed.length, 200);
  assert.equal(http.calls.filter(c => /\/reviews$/.test(c.url)).length, 200);
});

test('authentication and rate-limit failures make the section unavailable with a reason', async () => {
  for (const [status, text] of [[401, /rejected the saved token/], [403, /limiting requests/], [429, /limiting requests/], [422, /could not run the search/], [500, /could not be reached/]]) {
    const r = await fetchReviewData({ sess: SESS, period: PERIOD, http: fakeHttp({ fail: status }) });
    assert.equal(r.available, false, String(status));
    assert.match(r.reason, text);
  }
});

test('one unreadable PR does not sink the section', async () => {
  const http = fakeHttp({ reviewedItems: [pr(20), pr(21)] });
  const original = http.get;
  http.get = async (url, opts) => {
    if (/pulls\/20\/reviews$/.test(url)) { const e = new Error('gone'); e.response = { status: 404 }; throw e; }
    return original(url, opts);
  };
  const r = await fetchReviewData({ sess: SESS, period: PERIOD, http });
  assert.equal(r.available, true);
  assert.equal(r.reviewed.length, 2);
});

test('nothing identifying is kept: no titles, numbers, URLs or logins', async () => {
  const a = pr(7, { pull_request: { merged_at: '2026-01-06T00:00:00Z' } });
  const r = await fetchReviewData({ sess: SESS, period: PERIOD, http: fakeHttp({ created: [a], reviewedItems: [pr(8)], reviews: { 8: [review('me-user', 'APPROVED', '2026-01-11T00:00:00Z')] } }) });
  assert.doesNotMatch(JSON.stringify(r), /Secret title|repo-a|example-org|me-user|ghe\.example|"number"|"title"|"id"/);
});
