'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createStore, createPackCache, sanitiseDraft, DraftError } = require('./store');

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'appraisal-')), 'appraisal.json');
const KEY = '2026-01-01_2026-03-31';

test('the draft file is created owner-only and written atomically', () => {
  const file = tmp();
  const store = createStore({ filePath: file });
  store.putDraft(KEY, { talkingPoints: 'raise the on-call load', confirmed: [] });
  assert.equal((fs.statSync(file).mode & 0o777).toString(8), '600');
  assert.deepEqual(fs.readdirSync(path.dirname(file)), ['appraisal.json'], 'no temp file is left behind');
});

test('a draft round-trips per period and other periods are untouched', () => {
  const store = createStore({ filePath: tmp(), now: () => new Date('2026-10-06T10:00:00Z') });
  assert.equal(store.getDraft(KEY), null);
  store.putDraft(KEY, { talkingPoints: 'one', confirmed: [{ id: 'quickTurnaround', title: 'Quick', text: 'Fast.', source: 'suggested' }], dismissed: ['breadth'], include: { codeReview: false } });
  store.putDraft('2026-04-01_to-date', { talkingPoints: 'two' });
  const d = store.getDraft(KEY);
  assert.equal(d.talkingPoints, 'one');
  assert.equal(d.confirmed[0].id, 'quickTurnaround');
  assert.deepEqual(d.dismissed, ['breadth']);
  assert.deepEqual(d.include, { codeReview: false });
  assert.equal(d.updatedAt, '2026-10-06T10:00:00.000Z');
  assert.equal(store.getDraft('2026-04-01_to-date').talkingPoints, 'two');
});

test('period keys are validated, so a key cannot be used to write elsewhere in the file', () => {
  const store = createStore({ filePath: tmp() });
  for (const bad of ['', undefined, '__proto__', 'drafts', '2026-1-1_2026-3-31', '2026-01-01_tomorrow']) {
    assert.throws(() => store.putDraft(bad, {}), DraftError, String(bad));
    assert.throws(() => store.getDraft(bad), DraftError);
  }
});

test('drafts are sanitised: unknown fields dropped, sizes limited, empties removed', () => {
  const d = sanitiseDraft({
    talkingPoints: 'x'.repeat(30000),
    confirmed: [{ id: 'a', title: 't', text: 'ok', source: 'own', extra: 'drop me' }, { id: 'b', text: '   ' }, ...Array.from({ length: 80 }, (_, i) => ({ id: `k${i}`, text: 'y' }))],
    dismissed: ['a', 5, ''],
    include: { summary: true, bogus: 'yes' },
    secret: 'nope',
  });
  assert.equal(d.talkingPoints.length, 20000);
  assert.equal(d.confirmed.length <= 50, true);
  assert.deepEqual(Object.keys(d.confirmed[0]).sort(), ['id', 'source', 'text', 'title']);
  assert.equal(d.confirmed[0].source, 'own');
  assert.deepEqual(d.dismissed, ['a']);
  assert.deepEqual(d.include, { summary: true, bogus: false });
  assert.equal('secret' in d, false);
  assert.throws(() => sanitiseDraft(null), DraftError);
});

test('clear removes drafts and the notice acknowledgement', () => {
  const store = createStore({ filePath: tmp() });
  store.putDraft(KEY, { talkingPoints: 'private' });
  store.acknowledgeAiNotice();
  assert.equal(store.aiNoticeAcknowledged(), true);
  store.clear();
  assert.equal(store.getDraft(KEY), null);
  assert.equal(store.aiNoticeAcknowledged(), false);
  assert.equal(fs.readFileSync(store.filePath, 'utf8'), '{}');
});

test('a corrupt or missing file reads as empty rather than throwing', () => {
  const file = tmp();
  const store = createStore({ filePath: file });
  assert.equal(store.getDraft(KEY), null);
  fs.writeFileSync(file, '{not json');
  assert.equal(store.getDraft(KEY), null);
  fs.writeFileSync(file, '[1,2]');
  assert.equal(store.getDraft(KEY), null);
  store.putDraft(KEY, { talkingPoints: 'recovered' });
  assert.equal(store.getDraft(KEY).talkingPoints, 'recovered');
});

test('the pack cache is per session, expires when idle, and is never written to disk', () => {
  let t = 0;
  const cache = createPackCache({ now: () => t, idleMs: 1000 });
  cache.set('s1', { a: 1 });
  cache.set('s2', { a: 2 });
  assert.deepEqual(cache.get('s1'), { a: 1 });
  t = 900;
  assert.deepEqual(cache.get('s1'), { a: 1 }, 'reading refreshes the idle timer');
  t = 1500;
  assert.equal(cache.get('s2'), null, 's2 went idle');
  assert.deepEqual(cache.get('s1'), { a: 1 });
  cache.delete('s1');
  assert.equal(cache.size(), 0);
  assert.equal(Object.keys(createPackCache()).includes('filePath'), false);
});
