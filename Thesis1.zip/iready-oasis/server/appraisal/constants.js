'use strict';

// Tunable values in one place. The kudos thresholds are first guesses and are
// meant to be adjusted once they have been tried against real data.

const MAX_SPAN_DAYS = 731;            // 24 months
const MIN_PERCENTILE_SAMPLE = 5;      // fewer closed tickets than this: no percentiles
const PACK_IDLE_MS = 15 * 60 * 1000;  // an in-memory pack is dropped after this long unused
const JIRA_TICKET_CAP = 5000;         // jiraSearchAll's own cap; reaching it marks the pack partial
const HISTORY_FETCH_CAP = 300;        // status-history lookups per build
const HISTORY_CHUNK = 50;             // keys per history request
const GITHUB_PR_CAP = 200;            // PRs examined per build for review detail
const GITHUB_SEARCH_CAP = 1000;       // search results read per query (GitHub's own ceiling)
const AI_TIMEOUT_MS = 30000;
const AI_MAX_TOKENS = 1500;
const AI_TEXT_MAX = 600;
const AI_PROMPT_MAX = 200;
const AI_MAX_PROMPTS = 5;

const HIGH_PRIORITIES = ['highest', 'blocker', 'critical'];

const KUDOS = {
  quickTurnaround: { fraction: 0.5, minTypeSample: 3, minTickets: 2 },
  cleanSprints:    { minConsecutive: 3 },
  highPriority:    { minTickets: 2 },
  bigDeliveries:   { minPoints: 5 },
  steadyOutput:    { minWeeks: 6, minShare: 0.75 },
  improvement:     { maxRatio: 0.8, minSample: 5 },
  breadth:         { minComponents: 3 },
  shippingPrs:     { minMerged: 10 },
  reviewPartner:   { minReviews: 10, maxFirstReviewHours: 24 },
};

module.exports = {
  MAX_SPAN_DAYS, MIN_PERCENTILE_SAMPLE, PACK_IDLE_MS, JIRA_TICKET_CAP, HISTORY_FETCH_CAP, HISTORY_CHUNK,
  GITHUB_PR_CAP, GITHUB_SEARCH_CAP, AI_TIMEOUT_MS, AI_MAX_TOKENS, AI_TEXT_MAX, AI_PROMPT_MAX, AI_MAX_PROMPTS,
  HIGH_PRIORITIES, KUDOS,
};
