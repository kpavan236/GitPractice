'use strict';
const { spread } = require('./metrics');
const { weekKey, weekKeys } = require('./period');

const HOUR = 3600000;
const hoursBetween = (from, to) => Math.max(0, (to.getTime() - from.getTime()) / HOUR);
const inPeriod = (d, period) => !!d && d.getTime() >= period.start.getTime() && d.getTime() <= period.end.getTime();

/**
 * Code-review statistics for one period.
 *
 * Input carries timestamps, states and counts only. No titles, numbers or other
 * identifiers: this module cannot leak what it never receives.
 *
 *   authored: [{ created, merged|null }]
 *   reviewed: [{ prCreated, reviews: [{ at, state }] }]   (reviews by YOU, in the period)
 *
 * state is one of APPROVED, CHANGES_REQUESTED, COMMENTED (anything else is ignored).
 */
function computeReview(authored, reviewed, period, meta = {}) {
  const opened = authored.filter(p => inPeriod(p.created, period));
  const merged = authored.filter(p => inPeriod(p.merged, period));
  const toMerge = authored
    .filter(p => p.merged && inPeriod(p.merged, period) && p.created)
    .map(p => hoursBetween(p.created, p.merged));

  const myReviews = reviewed.flatMap(p => (p.reviews || []).filter(r => inPeriod(r.at, period)));
  const count = state => myReviews.filter(r => r.state === state).length;
  const firstReviewHours = reviewed
    .map(p => {
      const inRange = (p.reviews || []).filter(r => inPeriod(r.at, period));
      if (!inRange.length || !p.prCreated) return null;
      const first = inRange.reduce((a, b) => (a.at.getTime() <= b.at.getTime() ? a : b));
      return hoursBetween(p.prCreated, first.at);
    })
    .filter(v => v !== null);

  const weeks = weekKeys(period.start, period.end, period.tz);
  const weekly = weeks.map(week => ({
    week,
    opened: opened.filter(p => weekKey(p.created, period.tz) === week).length,
    merged: merged.filter(p => weekKey(p.merged, period.tz) === week).length,
    reviews: myReviews.filter(r => weekKey(r.at, period.tz) === week).length,
  }));

  return {
    available: true,
    partial: !!meta.partial,
    prsOpened: opened.length,
    prsMerged: merged.length,
    timeToMergeHours: spread(toMerge),
    prsReviewed: reviewed.filter(p => (p.reviews || []).some(r => inPeriod(r.at, period))).length,
    reviews: {
      total: myReviews.length,
      approved: count('APPROVED'),
      changesRequested: count('CHANGES_REQUESTED'),
      commented: count('COMMENTED'),
    },
    firstReviewHours: spread(firstReviewHours),
    weekly,
  };
}

module.exports = { computeReview };
