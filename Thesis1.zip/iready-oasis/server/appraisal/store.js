'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const { PACK_IDLE_MS } = require('./constants');

// Where appraisal text lives, and why it is NOT in the prefs file: GET /api/prefs
// returns the whole prefs file with no session, so anything private put there
// would be readable by whatever can reach that endpoint. This file is created
// owner-only (0600), written atomically, and reached only through session-checked
// routes.

const DEFAULT_PATH = path.join(os.homedir(), '.oasis-appraisal.json');
const PERIOD_KEY = /^\d{4}-\d{2}-\d{2}_(\d{4}-\d{2}-\d{2}|to-date)$/;
const MAX_TEXT = 20000;
const MAX_KUDOS = 50;
const MAX_KUDOS_TEXT = 2000;

class DraftError extends Error {
  constructor(message) { super(message); this.name = 'DraftError'; this.status = 400; }
}

const str = (v, max) => (typeof v === 'string' ? v.slice(0, max) : '');

// Accepts only the fields we know, with size limits, so a draft can never grow
// without bound or smuggle other data into the file.
function sanitiseDraft(input) {
  if (!input || typeof input !== 'object') throw new DraftError('draft must be an object.');
  const confirmed = (Array.isArray(input.confirmed) ? input.confirmed : []).slice(0, MAX_KUDOS).map(k => ({
    id: str(k && k.id, 80),
    title: str(k && k.title, 200),
    text: str(k && k.text, MAX_KUDOS_TEXT),
    source: k && k.source === 'own' ? 'own' : 'suggested',
  })).filter(k => k.text.trim());
  const dismissed = (Array.isArray(input.dismissed) ? input.dismissed : []).slice(0, MAX_KUDOS).map(v => str(v, 80)).filter(Boolean);
  const include = {};
  if (input.include && typeof input.include === 'object') {
    for (const [k, v] of Object.entries(input.include).slice(0, 30)) include[str(k, 40)] = v === true;
  }
  return { confirmed, dismissed, talkingPoints: str(input.talkingPoints, MAX_TEXT), include };
}

function createStore({ filePath = DEFAULT_PATH, now = () => new Date() } = {}) {
  function readAll() {
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_) { return {}; }
  }

  function writeAll(data) {
    const tmp = `${filePath}.tmp-${process.pid}`;
    fs.writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
    fs.chmodSync(tmp, 0o600);
    fs.renameSync(tmp, filePath);
  }

  return {
    filePath,
    getDraft(periodKey) {
      if (!PERIOD_KEY.test(periodKey || '')) throw new DraftError('period is not valid.');
      const d = (readAll().drafts || {})[periodKey];
      return d || null;
    },
    putDraft(periodKey, draft) {
      if (!PERIOD_KEY.test(periodKey || '')) throw new DraftError('period is not valid.');
      const data = readAll();
      data.drafts = data.drafts || {};
      data.drafts[periodKey] = { ...sanitiseDraft(draft), updatedAt: now().toISOString() };
      writeAll(data);
      return data.drafts[periodKey];
    },
    aiNoticeAcknowledged() { return readAll().aiNoticeAcknowledged === true; },
    acknowledgeAiNotice() { const data = readAll(); data.aiNoticeAcknowledged = true; writeAll(data); },
    // Deletes everything this feature has saved, including the notice acknowledgement.
    clear() { writeAll({}); },
  };
}

// The built pack (tickets-derived statistics) is held here and nowhere else: in
// memory, per session, dropped after it has been idle for a while.
function createPackCache({ now = () => Date.now(), idleMs = PACK_IDLE_MS } = {}) {
  const packs = new Map();
  const sweep = () => { for (const [k, v] of packs) if (now() - v.touched > idleMs) packs.delete(k); };
  return {
    set(sessionId, pack) { sweep(); packs.set(sessionId, { pack, touched: now() }); },
    get(sessionId) {
      sweep();
      const entry = packs.get(sessionId);
      if (!entry) return null;
      entry.touched = now();
      return entry.pack;
    },
    delete(sessionId) { packs.delete(sessionId); },
    size() { sweep(); return packs.size; },
  };
}

module.exports = { createStore, createPackCache, sanitiseDraft, DraftError, PERIOD_KEY, DEFAULT_PATH };
