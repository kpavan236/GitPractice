'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { computeStats, median, percentile, spread, histogram } = require('./metrics');
const { parsePeriod } = require('./period');

const NOW = new Date('2026-10-06T10:00:00Z');
const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' }, NOW);
const d = s => new Date(s);

// Synthetic tickets carry no ids at all.
const t = (over = {}) => ({
  type: 'Story', priority: 'Medium', points: null, created: d('2026-01-05T00:00:00Z'), resolved: null,
  firstInProgress: null, owned: true, reassigned: false, sprints: [], components: [], ...over,
});

test('median and nearest-rank percentile on odd, even and tiny samples', () => {
  assert.equal(median([3, 1, 2]), 2);
  assert.equal(median([4, 1, 3, 2]), 2.5);
  assert.equal(median([]), null);
  assert.equal(percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.9), 9);
  assert.equal(percentile([5], 0.9), 5);
  assert.equal(percentile([], 0.9), null);
});

test('percentiles are withheld below 5 closed tickets but the median is still shown', () => {
  const small = spread([1, 2, 3, 4]);
  assert.equal(small.tooFew, true);
  assert.equal(small.p90, null);
  assert.equal(small.median, 2.5);
  const enough = spread([1, 2, 3, 4, 5]);
  assert.equal(enough.tooFew, false);
  assert.equal(enough.p90, 5);
  assert.deepEqual(spread([]), { n: 0, tooFew: true, median: null, p90: null, max: null });
});

test('opened, closed and still-open follow the period boundaries exactly', () => {
  const tickets = [
    t({ created: d('2026-01-01T00:00:00.000Z'), resolved: d('2026-01-03T00:00:00.000Z') }),   // opened at the first instant
    t({ created: d('2025-12-31T23:59:59.999Z'), resolved: d('2026-01-02T00:00:00Z') }),        // opened a ms before: not opened, but closed in
    t({ created: d('2026-03-31T23:59:59.999Z') }),                                              // opened at the last instant, still open
    t({ created: d('2026-04-01T00:00:00.000Z') }),                                              // after the period
    t({ created: d('2026-02-01T00:00:00Z'), resolved: d('2026-04-02T00:00:00Z') }),            // resolved after: still open at the end
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.opened, 3);
  assert.equal(s.closed, 2);
  assert.equal(s.stillOpen, 2);   // the last-instant ticket, and the one resolved after the period ended
});

test('tickets that are not yours do not count; reassigned ones are counted separately', () => {
  const tickets = [
    t({ resolved: d('2026-01-10T00:00:00Z') }),
    t({ owned: false, reassigned: true, resolved: d('2026-01-10T00:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.closed, 1);
  assert.equal(s.opened, 1);
  assert.equal(s.reassigned, 1);
});

test('lead time covers closed tickets only and reports how many unresolved were left out', () => {
  const tickets = [
    t({ created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-07T00:00:00Z') }),   // 2 days
    t({ created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-10T00:00:00Z') }),   // 5 days
    t({ created: d('2026-01-05T00:00:00Z') }),                                          // unresolved
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.leadTime.n, 2);
  assert.equal(s.leadTime.median, 3.5);
  assert.equal(s.leadTime.excludedUnresolved, 1);
});

test('working time uses the start of work where known and reports how many lacked it', () => {
  const tickets = [
    t({ created: d('2026-01-05T00:00:00Z'), firstInProgress: d('2026-01-08T00:00:00Z'), resolved: d('2026-01-10T00:00:00Z') }),
    t({ created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-10T00:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.workTime.n, 1);
  assert.equal(s.workTime.median, 2);
  assert.equal(s.workTime.missing, 1);
  assert.equal(s.leadTime.n, 2);
});

test('a ticket resolved before it was created cannot produce a negative time', () => {
  const s = computeStats([t({ created: d('2026-01-10T00:00:00Z'), resolved: d('2026-01-09T00:00:00Z') })], PERIOD);
  assert.equal(s.leadTime.median, 0);
});

test('weekly buckets count opened and closed per Monday-start week, including empty weeks', () => {
  const tickets = [
    t({ created: d('2026-01-05T09:00:00Z'), resolved: d('2026-01-19T09:00:00Z') }),
    t({ created: d('2026-01-06T09:00:00Z'), resolved: d('2026-01-07T09:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  const wk = Object.fromEntries(s.weekly.map(w => [w.week, w]));
  assert.deepEqual([wk['2026-01-05'].opened, wk['2026-01-05'].closed], [2, 1]);
  assert.deepEqual([wk['2026-01-12'].opened, wk['2026-01-12'].closed], [0, 0]);
  assert.deepEqual([wk['2026-01-19'].opened, wk['2026-01-19'].closed], [0, 1]);
  assert.equal(s.totalWeeks, s.weekly.length);
  assert.equal(s.activeWeeks, 2);
});

test('by type and priority give counts and medians, biggest group first', () => {
  const tickets = [
    t({ type: 'Bug', priority: 'High', created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-06T00:00:00Z') }),
    t({ type: 'Bug', priority: 'Low', created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-08T00:00:00Z') }),
    t({ type: 'Story', priority: 'High', created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-15T00:00:00Z') }),
    t({ type: '', priority: '', created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-07T00:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  assert.deepEqual(s.byType.map(g => [g.name, g.closed, g.median]), [['Bug', 2, 2], ['Story', 1, 10], ['Unspecified', 1, 2]]);
  assert.deepEqual(s.byPriority.map(g => [g.name, g.closed]), [['High', 2], ['Low', 1], ['Unspecified', 1]]);
  assert.equal(s.mix.find(m => m.name === 'Bug').share, 0.5);
});

test('the histogram puts each value in the right bin, including the open-ended last one', () => {
  const bins = histogram([0.5, 1, 1.9, 2, 4, 10, 40, 100]);
  const byLabel = Object.fromEntries(bins.map(b => [b.label, b.count]));
  assert.equal(byLabel['0-1'], 1);
  assert.equal(byLabel['1-2'], 2);
  assert.equal(byLabel['2-3'], 1);
  assert.equal(byLabel['3-5'], 1);
  assert.equal(byLabel['8-13'], 1);
  assert.equal(byLabel['34+'], 2);
  assert.equal(bins.reduce((n, b) => n + b.count, 0), 8);
});

test('points are reported only when the data has them', () => {
  const none = computeStats([t({ resolved: d('2026-01-10T00:00:00Z') })], PERIOD);
  assert.deepEqual(none.points, { available: false, completed: null });
  const some = computeStats([t({ points: 5, resolved: d('2026-01-10T00:00:00Z') }), t({ points: 3, resolved: d('2026-01-11T00:00:00Z') }), t({ points: 8 })], PERIOD);
  assert.deepEqual(some.points, { available: true, completed: 8 });
  const off = computeStats([t({ points: 5, resolved: d('2026-01-10T00:00:00Z') })], PERIOD, { pointsAvailable: false });
  assert.equal(off.points.available, false);
});

const sprint = (id, name, start, end, state = 'closed') => ({ id, name, state, start: d(start), end: d(end) });
const S1 = sprint(1, 'Sprint 1', '2026-01-05T00:00:00Z', '2026-01-19T00:00:00Z');
const S2 = sprint(2, 'Sprint 2', '2026-01-19T00:00:00Z', '2026-02-02T00:00:00Z');
const S3 = sprint(3, 'Sprint 3', '2026-02-02T00:00:00Z', '2026-02-16T00:00:00Z');

test('a roll is a ticket carried out of a sprint that ended without it being done', () => {
  const tickets = [
    t({ sprints: [S1, S2], resolved: d('2026-01-30T00:00:00Z') }),            // rolled S1 -> S2, finished in S2
    t({ sprints: [S1], resolved: d('2026-01-15T00:00:00Z') }),                // finished inside S1
    t({ sprints: [S1, S2, S3], resolved: d('2026-02-10T00:00:00Z') }),        // rolled twice
    t({ sprints: [S1, S2] , resolved: d('2026-01-19T00:00:00.000Z') }),       // done exactly at S1's end: not a roll
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.rolled.available, true);
  assert.equal(s.rolled.events, 3);
  assert.equal(s.rolled.tickets, 2);
});

test('the sprint table shows committed, completed and rolled per sprint that ended in the period', () => {
  const tickets = [
    t({ sprints: [S1, S2], points: 3, resolved: d('2026-01-30T00:00:00Z') }),
    t({ sprints: [S1], points: 5, resolved: d('2026-01-15T00:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  const [one, two] = s.sprints;
  assert.deepEqual([one.name, one.committed, one.completed, one.rolled, one.points], ['Sprint 1', 2, 1, 1, 5]);
  assert.deepEqual([two.name, two.committed, two.completed, two.rolled, two.points], ['Sprint 2', 1, 1, 0, 3]);
});

test('rolled-over is reported as unavailable, not zero, when the JIRA has no sprint field', () => {
  const s = computeStats([t()], PERIOD, { sprintsAvailable: false });
  assert.deepEqual(s.rolled, { available: false, events: null, tickets: null });
  assert.deepEqual(s.sprints, []);
});

test('the longest run of clean sprints counts only sprints with work and no rolls', () => {
  const tickets = [
    t({ sprints: [S1], resolved: d('2026-01-15T00:00:00Z') }),
    t({ sprints: [S2], resolved: d('2026-01-30T00:00:00Z') }),
    t({ sprints: [S3, sprint(4, 'Sprint 4', '2026-02-16T00:00:00Z', '2026-03-02T00:00:00Z')], resolved: d('2026-02-20T00:00:00Z') }),
  ];
  const s = computeStats(tickets, PERIOD);
  assert.equal(s.cleanSprintRun, 2);
});

test('an empty period gives zeros and empty series, never throws', () => {
  const s = computeStats([], PERIOD);
  assert.equal(s.opened, 0);
  assert.equal(s.closed, 0);
  assert.deepEqual(s.histogram, []);
  assert.equal(s.leadTime.median, null);
  assert.ok(s.weekly.length > 0);
});

test('no output contains a ticket id: tickets carry none and the stats object has no such field', () => {
  const s = computeStats([t({ resolved: d('2026-01-10T00:00:00Z') })], PERIOD);
  assert.doesNotMatch(JSON.stringify(s), /[A-Z][A-Z0-9]+-\d+|"key"|"summary"/);
});
