'use strict';
const { AI_TIMEOUT_MS, AI_MAX_TOKENS } = require('./constants');
const { fillPlaceholders, guardNarrative } = require('./ai-guard');

// The figures that may appear in AI-written text, by placeholder. Everything the
// reader sees as a number comes from here, never from the model.
function globalVars(stats, review) {
  return {
    opened: stats.opened,
    closed: stats.closed,
    rolled: stats.rolled.available ? stats.rolled.events : null,
    median: stats.leadTime.median,
    p90: stats.leadTime.p90,
    points: stats.points.available ? stats.points.completed : null,
    prsMerged: review && review.available ? review.prsMerged : null,
    reviews: review && review.available ? review.reviews.total : null,
  };
}

const BASE_PROMPTS = [
  'What are you most proud of from this period?',
  'What was hardest, and what would have helped?',
  'What would you like to learn or take on next?',
  'What support do you need from your manager?',
];

function ruleNarrative(stats, candidates, review) {
  const vars = globalVars(stats, review);
  const parts = [`In this period you opened {opened} and closed {closed} tickets.`];
  if (stats.leadTime.n > 0) parts.push('The median time to close was {median} days.');
  if (stats.rolled.available && stats.rolled.events > 0) parts.push('Work rolled over between sprints {rolled} times.');
  if (vars.points !== null) parts.push('You completed {points} story points.');
  if (review && review.available) parts.push('You merged {prsMerged} pull requests and gave {reviews} reviews.');

  const prompts = [...BASE_PROMPTS];
  if (stats.rolled.available && stats.rolled.events > 0) {
    prompts.push('Some work carried over between sprints. What got in the way, and what would help?');
  }
  if (!stats.leadTime.tooFew && stats.leadTime.median > 0 && stats.leadTime.p90 >= stats.leadTime.median * 3) {
    prompts.push('A few tickets took much longer than usual. What made them different?');
  }
  return {
    summary: fillPlaceholders(parts.join(' '), vars),
    kudos: Object.fromEntries(candidates.map(c => [c.id, c.text])),
    prompts,
  };
}

const SYSTEM = [
  'You help one person prepare for their own appraisal discussion.',
  'Write supportive, factual, plain English. Never give a score or a rating, never compare the person with anyone else, never invent achievements.',
  'You must NOT write any number, ticket id, URL or name of your own. Where a figure belongs, write a placeholder in curly braces, using only the placeholders you are given.',
  'Return ONLY JSON: {"summary": string, "kudos": [{"id": string, "text": string}], "prompts": [string]}.',
  'summary: 2 to 3 sentences about the period. kudos: one reworded sentence per candidate id given, using that candidate\'s own placeholders. prompts: up to 5 short questions that help the person prepare.',
].join(' ');

function aiRequest(stats, candidates, review) {
  const vars = globalVars(stats, review);
  const payload = {
    globalPlaceholders: Object.keys(vars),
    figures: {
      ...vars,
      closedTooFewForPercentiles: stats.leadTime.tooFew,
      stillOpen: stats.stillOpen,
    },
    candidates: candidates.map(c => ({ id: c.id, title: c.title, placeholders: Object.keys(c.vars), figures: c.vars })),
  };
  return {
    system: SYSTEM,
    messages: [{ role: 'user', content: JSON.stringify(payload) }],
    maxTokens: AI_MAX_TOKENS,
  };
}

function parseJson(raw) {
  if (typeof raw !== 'string') return null;
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(raw.slice(start, end + 1)); } catch (_) { return null; }
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('AI timed out')), ms); });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/**
 * The narrative the tab shows: AI wording when AI is available and its output
 * passes the guard, rule-based wording otherwise, decided field by field.
 *
 * @param {object} p { ai, aiInfo, useAi, stats, candidates, review, timeoutMs }
 *   ai      a client with available() and complete({ messages, system, maxTokens })
 *   aiInfo  { provider, model, local } for labelling
 */
async function generateNarrative({ ai, aiInfo = {}, useAi = true, stats, candidates, review = null, timeoutMs = AI_TIMEOUT_MS }) {
  const rules = ruleNarrative(stats, candidates, review);
  const fromRules = reason => ({
    source: 'rules', reason, provider: null, model: null, local: false,
    summary: { text: rules.summary, ai: false },
    kudos: candidates.map(c => ({ id: c.id, text: rules.kudos[c.id], ai: false })),
    prompts: rules.prompts.map(text => ({ text, ai: false })),
    rejected: 0,
  });

  if (!useAi) return fromRules('ai-off');
  if (!ai || !ai.available()) return fromRules('ai-unavailable');

  let guarded;
  try {
    const raw = await withTimeout(ai.complete(aiRequest(stats, candidates, review)), timeoutMs);
    const parsed = parseJson(raw);
    if (!parsed) return fromRules('ai-failed');
    guarded = guardNarrative(parsed, { globalVars: globalVars(stats, review), candidates });
  } catch (_) {
    return fromRules('ai-failed');
  }

  const usedAi = guarded.summary !== null || Object.keys(guarded.kudos).length > 0 || guarded.prompts.length > 0;
  if (!usedAi) return fromRules('ai-rejected');
  return {
    source: 'ai', reason: null,
    provider: aiInfo.provider || null, model: aiInfo.model || null, local: !!aiInfo.local,
    summary: guarded.summary !== null ? { text: guarded.summary, ai: true } : { text: rules.summary, ai: false },
    kudos: candidates.map(c => (guarded.kudos[c.id] !== undefined
      ? { id: c.id, text: guarded.kudos[c.id], ai: true }
      : { id: c.id, text: rules.kudos[c.id], ai: false })),
    prompts: guarded.prompts.length
      ? guarded.prompts.map(text => ({ text, ai: true }))
      : rules.prompts.map(text => ({ text, ai: false })),
    rejected: guarded.rejected.length,
  };
}

module.exports = { generateNarrative, ruleNarrative, aiRequest, globalVars, parseJson };
