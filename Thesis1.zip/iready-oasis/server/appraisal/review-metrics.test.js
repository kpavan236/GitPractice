'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { computeReview } = require('./review-metrics');
const { parsePeriod } = require('./period');

const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-01T00:00:00.000Z', to: '2026-03-31T23:59:59.999Z', tz: 'UTC' }, new Date('2026-10-06T10:00:00Z'));
const d = s => new Date(s);

test('PRs opened and merged are counted inside the period only, with time to merge in hours', () => {
  const authored = [
    { created: d('2026-01-05T00:00:00Z'), merged: d('2026-01-05T10:00:00Z') },    // 10h
    { created: d('2026-01-06T00:00:00Z'), merged: d('2026-01-08T00:00:00Z') },    // 48h
    { created: d('2025-12-20T00:00:00Z'), merged: d('2026-01-02T00:00:00Z') },    // opened before, merged in
    { created: d('2026-02-01T00:00:00Z'), merged: null },                          // still open
    { created: d('2026-05-01T00:00:00Z'), merged: d('2026-05-02T00:00:00Z') },    // after the period
  ];
  const r = computeReview(authored, [], PERIOD);
  assert.equal(r.prsOpened, 3);
  assert.equal(r.prsMerged, 3);
  assert.equal(r.timeToMergeHours.n, 3);
  assert.equal(r.timeToMergeHours.max > 100, true);
  assert.equal(r.timeToMergeHours.tooFew, true);
});

test('reviews are counted by outcome and only those inside the period', () => {
  const reviewed = [
    { prCreated: d('2026-01-05T00:00:00Z'), reviews: [
      { at: d('2026-01-05T06:00:00Z'), state: 'COMMENTED' },
      { at: d('2026-01-06T00:00:00Z'), state: 'APPROVED' },
      { at: d('2026-01-07T00:00:00Z'), state: 'DISMISSED' } ] },
    { prCreated: d('2026-02-01T00:00:00Z'), reviews: [{ at: d('2026-02-01T12:00:00Z'), state: 'CHANGES_REQUESTED' }] },
    { prCreated: d('2026-03-30T00:00:00Z'), reviews: [{ at: d('2026-04-02T00:00:00Z'), state: 'APPROVED' }] },   // after the period
  ];
  const r = computeReview([], reviewed, PERIOD);
  assert.deepEqual(r.reviews, { total: 4, approved: 1, changesRequested: 1, commented: 1 });
  assert.equal(r.prsReviewed, 2);
});

test('time to first review is from the PR opening to your earliest review in the period', () => {
  const reviewed = [
    { prCreated: d('2026-01-05T00:00:00Z'), reviews: [{ at: d('2026-01-05T08:00:00Z'), state: 'COMMENTED' }, { at: d('2026-01-06T00:00:00Z'), state: 'APPROVED' }] },
    { prCreated: d('2026-01-10T00:00:00Z'), reviews: [{ at: d('2026-01-10T04:00:00Z'), state: 'APPROVED' }] },
  ];
  const r = computeReview([], reviewed, PERIOD);
  assert.equal(r.firstReviewHours.n, 2);
  assert.equal(r.firstReviewHours.median, 6);
});

test('weekly series cover every week and line up with the totals', () => {
  const authored = [{ created: d('2026-01-06T00:00:00Z'), merged: d('2026-01-13T00:00:00Z') }];
  const reviewed = [{ prCreated: d('2026-01-05T00:00:00Z'), reviews: [{ at: d('2026-01-20T00:00:00Z'), state: 'APPROVED' }] }];
  const r = computeReview(authored, reviewed, PERIOD);
  const wk = Object.fromEntries(r.weekly.map(w => [w.week, w]));
  assert.equal(wk['2026-01-05'].opened, 1);
  assert.equal(wk['2026-01-12'].merged, 1);
  assert.equal(wk['2026-01-19'].reviews, 1);
  assert.equal(r.weekly.reduce((n, w) => n + w.opened, 0), r.prsOpened);
});

test('empty input is all zeros and the partial flag is passed through', () => {
  const r = computeReview([], [], PERIOD, { partial: true });
  assert.equal(r.prsOpened, 0);
  assert.equal(r.reviews.total, 0);
  assert.equal(r.firstReviewHours.median, null);
  assert.equal(r.partial, true);
});

test('output carries no titles, numbers or identifiers', () => {
  const r = computeReview([{ created: d('2026-01-06T00:00:00Z'), merged: null }], [], PERIOD);
  assert.doesNotMatch(JSON.stringify(r), /title|number|url|login|"id"/i);
});
