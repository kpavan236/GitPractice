'use strict';
const fs = require('fs');

// One switch for every call OASIS makes to GitHub and Jenkins.
//
// Why a single module: these calls come from many places — a dozen routes, git
// commands, a background branch refresher, scheduled jobs, the Version Watch
// timer, the badges inside the JIRA tab. Patching each tab leaves the next
// one to be missed. This module is the one place that knows whether they are
// allowed, and it is enforced on the SERVER in three ways that back each other up:
//
//   1. an HTTP gate on the shared HTTP client (installAxiosGate): any request to
//      a configured GitHub or Jenkins host is refused while the switch is off,
//      whoever makes it, including code written next year;
//   2. explicit checks (assertAllowed) in front of the git commands that contact
//      GitHub, and in the background jobs;
//   3. a route gate (routeGate) that answers a clear 503 for the known routes
//      before any work starts, so the screen can say why instead of failing oddly.
//
// The same switch also stops the one thing JIRA does on its own, the 5-minute automatic sync
// (refuseAutomatic below); a person pressing Sync, and signing in to JIRA, are never blocked.
//
// Login is the one exception: validating a token in the setup wizard and creating
// the session mark their calls { oasisLogin: true } and always go through.
//
// The switch starts OFF. Order of precedence: the choice saved in Settings, then
// the OASIS_EXTERNAL_CALLS environment variable, then off. Anything unrecognised
// means off: a typo must never open the gate.

const PREF_KEY = 'externalCallsEnabled';
const ENV_KEY = 'OASIS_EXTERNAL_CALLS';
const CODE = 'EXTERNAL_CALLS_DISABLED';
const MESSAGE = 'GitHub and Jenkins calls are switched off. Turn them on in Settings to use this.';

class ExternalCallsDisabledError extends Error {
  constructor(what) {
    super(what ? `${what} calls are switched off. Turn them on in Settings to use this.` : MESSAGE);
    this.name = 'ExternalCallsDisabledError';
    this.code = CODE;
    this.status = 503;
  }
}

// True for the error above, including when something wrapped it.
const isDisabledError = err => !!err && (err.code === CODE || (err.cause && err.cause.code === CODE));

function parseFlag(value) {
  if (typeof value !== 'string') return undefined;
  const v = value.trim() === value ? value.toLowerCase() : null;   // " on" is not a clear choice
  if (v === null) return undefined;
  if (['on', '1', 'true', 'yes'].includes(v)) return true;
  if (['off', '0', 'false', 'no'].includes(v)) return false;
  return undefined;
}

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (_) { return null; }
}

function createExternalCalls({ prefsPath, env = process.env, getHosts = () => [], fsImpl = fs } = {}) {
  let cache = { mtimeMs: -1, prefs: {} };

  function readPrefs() {
    try {
      const { mtimeMs } = fsImpl.statSync(prefsPath);
      if (mtimeMs !== cache.mtimeMs) cache = { mtimeMs, prefs: JSON.parse(fsImpl.readFileSync(prefsPath, 'utf8')) || {} };
      return cache.prefs;
    } catch (_) {
      cache = { mtimeMs: -1, prefs: {} };
      return {};                                   // missing or damaged: fall through to the environment, then off
    }
  }

  function state() {
    const saved = readPrefs()[PREF_KEY];
    if (typeof saved === 'boolean') return { enabled: saved, source: 'settings' };
    const fromEnv = parseFlag(env[ENV_KEY]);
    if (fromEnv !== undefined) return { enabled: fromEnv, source: 'environment' };
    return { enabled: false, source: 'default' };
  }

  const isEnabled = () => state().enabled;

  function setEnabled(enabled) {
    if (typeof enabled !== 'boolean') throw new Error('The setting must be true or false.');
    let current = {};
    try { current = JSON.parse(fsImpl.readFileSync(prefsPath, 'utf8')) || {}; } catch (_) { /* start a new file */ }
    fsImpl.writeFileSync(prefsPath, JSON.stringify({ ...current, [PREF_KEY]: enabled }, null, 2), 'utf8');
    cache = { mtimeMs: -1, prefs: {} };           // re-read next time
  }

  function assertAllowed(what) {
    if (!isEnabled()) throw new ExternalCallsDisabledError(what);
  }

  function isExternalHost(url) {
    const host = hostOf(url);
    return host !== null && getHosts().some(h => String(h).toLowerCase() === host);
  }

  function installAxiosGate(axios) {
    axios.interceptors.request.use(config => {
      if (config.oasisLogin) return config;
      const full = /^https?:\/\//i.test(config.url || '') ? config.url : `${config.baseURL || ''}${config.url || ''}`;
      if (isExternalHost(full) && !isEnabled()) return Promise.reject(new ExternalCallsDisabledError());
      return config;
    });
  }

  function routeGate(patterns) {
    return function externalCallsRouteGate(req, res, next) {
      // Express hides the mount point from req.path (a gate mounted at /api sees /repos),
      // so the full path is rebuilt before matching.
      const fullPath = `${req.baseUrl || ''}${req.path}`;
      if (!patterns.some(p => p.test(fullPath)) || isEnabled()) return next();
      return res.status(503).json({ error: 'external_calls_disabled', code: CODE, message: MESSAGE });
    };
  }

  // For a route used both by a person (a button) and by a timer: while the switch is off, only
  // the timer's requests (marked `auto: true`) are refused. The person's click goes through,
  // as it is their own action. Returns true when it has already answered.
  function refuseAutomatic(req, res, what) {
    if (!(req.body && req.body.auto === true) || isEnabled()) return false;
    const err = new ExternalCallsDisabledError(what);
    res.status(503).json({ error: 'external_calls_disabled', code: err.code, message: err.message });
    return true;
  }

  return { state, isEnabled, setEnabled, assertAllowed, isExternalHost, installAxiosGate, routeGate, refuseAutomatic };
}

module.exports = { createExternalCalls, ExternalCallsDisabledError, isDisabledError, parseFlag, hostOf, PREF_KEY, ENV_KEY, CODE, MESSAGE };
