'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { findScript, interpreterFor, commandFor, commandLineFor, extensionsFor, _resetForTests } = require('./scripts');

// Scripts were hardcoded to .sh, so Windows had nothing: the button appeared,
// the job started, and no output ever came. These tests are about picking the
// right file for the machine AND refusing to offer one nothing can execute —
// both halves, because either alone reproduces the original silent failure in
// a different direction.

function scriptDir(names) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-scripts-'));
  for (const n of names) fs.writeFileSync(path.join(dir, n), '# script\n');
  return dir;
}

test('Windows prefers PowerShell, POSIX prefers shell', () => {
  assert.deepEqual(extensionsFor('win32'), ['.ps1', '.cmd', '.bat', '.sh']);
  assert.deepEqual(extensionsFor('darwin'), ['.sh', '.ps1']);
  assert.deepEqual(extensionsFor('linux'), ['.sh', '.ps1']);
});

test('.sh is LAST on Windows, not excluded', () => {
  // Every script that exists today is .sh, and Git for Windows can run them.
  // Excluding .sh would leave Windows with nothing until .ps1 files are written
  // — which is the state this work is meant to get out of, not into.
  assert.ok(extensionsFor('win32').includes('.sh'));
  assert.equal(extensionsFor('win32').at(-1), '.sh');
});

test('picks the shell script on a Mac', () => {
  const dir = scriptDir(['iready-core.sh', 'iready-core.ps1']);
  const found = findScript(dir, 'iready-core', { platform: 'darwin' });
  assert.equal(path.extname(found.path), '.sh');
  assert.equal(found.available, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('finds a launch script by its compound base name', () => {
  const dir = scriptDir(['iready-core.launch.sh', 'iready-core.sh']);
  const found = findScript(dir, 'iready-core.launch', { platform: 'darwin' });
  assert.equal(path.basename(found.path), 'iready-core.launch.sh');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('no script at all is null, not an error', () => {
  const dir = scriptDir([]);
  assert.equal(findScript(dir, 'nothing-here', { platform: 'darwin' }), null);
  assert.equal(findScript(null, 'x'), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Availability means the interpreter exists too ──────────────────────────

test('a script whose interpreter is missing does not shadow one that runs', () => {
  // The subtle one. On a Mac with no PowerShell, a repo shipping both .ps1 and
  // .sh must run the .sh. Preference order alone would stop at the first file
  // it found and report the repository unrunnable.
  const dir = scriptDir(['repo.ps1', 'repo.sh']);
  const found = findScript(dir, 'repo', { platform: 'win32' });   // prefers .ps1

  if (found.interpreter.kind === 'powershell' && found.available) {
    // This machine has pwsh installed — the preference genuinely wins.
    assert.equal(path.extname(found.path), '.ps1');
  } else {
    assert.equal(path.extname(found.path), '.sh', 'must fall through to a runnable script');
    assert.equal(found.available, true);
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a present-but-unrunnable script reports WHY, not "no script"', () => {
  // Those need completely different actions from the user: write a script,
  // versus install an interpreter.
  const dir = scriptDir(['repo.bat']);
  const found = findScript(dir, 'repo', { platform: 'darwin' });

  assert.notEqual(found, null, 'the file exists, so this is not "no script"');
  assert.equal(found.available, false);
  assert.match(found.hint, /only run on Windows/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('records which higher-preference scripts were passed over', () => {
  // So "why did it run the .sh when a .ps1 is right there" has an answer.
  const dir = scriptDir(['repo.bat', 'repo.sh']);
  const found = findScript(dir, 'repo', { platform: 'darwin' });
  assert.equal(path.extname(found.path), '.sh');
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Interpreters ───────────────────────────────────────────────────────────

test('bash tracing is opt-in, not automatic', () => {
  // Setup wants -x so the UI can surface each command. Launch does not: baking
  // it in filled the launch log with a trace of the application's own startup.
  const i = interpreterFor('/x/repo.sh');
  assert.equal(i.kind, 'bash');
  assert.deepEqual(i.args('/x/repo.sh', ['/clone']), ['/x/repo.sh', '/clone']);
  assert.deepEqual(i.args('/x/repo.sh', ['/clone'], { trace: true }), ['-x', '/x/repo.sh', '/clone']);
  assert.equal(i.supportsTrace, true);
});

test('asking for tracing where the interpreter has none is ignored, not passed on', () => {
  // -x is meaningless to PowerShell and would be rejected as an argument.
  const dir = scriptDir(['repo.ps1']);
  const found = findScript(dir, 'repo', { platform: 'win32' });
  if (found.available) {
    const built = commandFor(found, ['/clone'], { trace: true });
    assert.equal(built.trace, false);
    assert.equal(built.args.includes('-x'), false);
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a PowerShell script gets the flags it actually needs', () => {
  const i = interpreterFor('C:\\x\\repo.ps1', { platform: 'win32' });
  assert.equal(i.kind, 'powershell');
  const args = i.args('C:\\x\\repo.ps1', ['C:\\clone']);
  // Bypass, because the Windows default refuses unsigned local scripts — which
  // is every script we ship.
  assert.ok(args.includes('-ExecutionPolicy') && args.includes('Bypass'));
  // -File, not -Command: -Command would re-parse the path as an expression.
  assert.ok(args.includes('-File'));
  // -NoProfile so a personal profile cannot change what the script does.
  assert.ok(args.includes('-NoProfile'));
  assert.equal(i.supportsTrace, false, 'xtrace is a bash feature');
});

test('a batch file runs through cmd, and only on Windows', () => {
  const win = interpreterFor('C:\\x\\repo.cmd', { platform: 'win32' });
  assert.equal(win.command, 'cmd.exe');
  assert.deepEqual(win.args('C:\\x\\repo.cmd', ['C:\\clone']), ['/c', 'C:\\x\\repo.cmd', 'C:\\clone']);
  assert.equal(win.available, true);

  assert.equal(interpreterFor('/x/repo.cmd', { platform: 'darwin' }).available, false);
});

test('an unknown extension is refused with a reason', () => {
  const i = interpreterFor('/x/repo.rb');
  assert.equal(i.available, false);
  assert.match(i.hint, /No interpreter/);
});

// ── Building the command ───────────────────────────────────────────────────

test('builds an argv for the resolved script', () => {
  const dir = scriptDir(['repo.sh']);
  const found = findScript(dir, 'repo', { platform: 'darwin' });
  const { command, args, trace } = commandFor(found, ['/clone/dir'], { trace: true });

  assert.ok(command.includes('bash'));
  assert.deepEqual(args.slice(-2), [found.path, '/clone/dir']);
  assert.equal(trace, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('quotes paths containing spaces', () => {
  // "C:\\Program Files" and "~/My Projects" both exist in the wild, and an
  // unquoted command line splits them into two arguments.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis has space-'));
  fs.writeFileSync(path.join(dir, 'repo.sh'), '# x\n');
  const found = findScript(dir, 'repo', { platform: 'darwin' });

  const { line } = commandLineFor(found, ['/clone dir/x']);
  assert.match(line, /"[^"]*oasis has space[^"]*repo\.sh"/);
  assert.match(line, /"\/clone dir\/x"/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('refuses to build a command for something that cannot run', () => {
  const dir = scriptDir(['repo.bat']);
  const found = findScript(dir, 'repo', { platform: 'darwin' });
  assert.throws(() => commandFor(found, []), /only run on Windows/);
  assert.throws(() => commandFor(null, []), /No runnable script/);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Searching several roots ────────────────────────────────────────────────
//
// Scripts live in two places: the ones bundled with the app, and a team's own
// `oasis-scripts` directory checked out beside their repositories. Bundled
// wins, so a shipped script is what runs unless it is missing.

const { findScriptIn } = require('./scripts');

test('the bundled root wins when both have the script', () => {
  const bundled = scriptDir(['repo.sh']);
  const team = scriptDir(['repo.sh']);
  const found = findScriptIn([bundled, team], 'repo', { platform: 'darwin' });

  assert.equal(found.root, bundled);
  fs.rmSync(bundled, { recursive: true, force: true });
  fs.rmSync(team, { recursive: true, force: true });
});

test('falls through to the team directory when the bundled one has nothing', () => {
  // The whole point: a repository nobody wrote a bundled script for still gets
  // set up, from a script the team maintains themselves.
  const bundled = scriptDir([]);
  const team = scriptDir(['repo.sh']);
  const found = findScriptIn([bundled, team], 'repo', { platform: 'darwin' });

  assert.equal(found.root, team);
  assert.equal(found.available, true);
  fs.rmSync(bundled, { recursive: true, force: true });
  fs.rmSync(team, { recursive: true, force: true });
});

test('an unrunnable bundled script does not hide a working team one', () => {
  // The same rule the extension search follows. A bundled .bat on a Mac must
  // not shadow the team's .sh, or the repository looks unrunnable when it is
  // not.
  const bundled = scriptDir(['repo.bat']);
  const team = scriptDir(['repo.sh']);
  const found = findScriptIn([bundled, team], 'repo', { platform: 'darwin' });

  assert.equal(found.root, team);
  assert.equal(path.extname(found.path), '.sh');
  assert.equal(found.available, true);
  fs.rmSync(bundled, { recursive: true, force: true });
  fs.rmSync(team, { recursive: true, force: true });
});

test('when nothing anywhere can run, the reason still comes back', () => {
  // Reporting "no script" for a file plainly sitting there sends the user off
  // to write one that already exists.
  const bundled = scriptDir(['repo.bat']);
  const team = scriptDir([]);
  const found = findScriptIn([bundled, team], 'repo', { platform: 'darwin' });

  assert.equal(found.available, false);
  assert.match(found.hint, /only run on Windows/);
  fs.rmSync(bundled, { recursive: true, force: true });
  fs.rmSync(team, { recursive: true, force: true });
});

test('a missing fallback directory is normal, not an error', () => {
  // Most installs will never create oasis-scripts.
  const bundled = scriptDir(['repo.sh']);
  const found = findScriptIn([bundled, '/nonexistent/oasis-scripts'], 'repo', { platform: 'darwin' });
  assert.equal(found.root, bundled);

  assert.equal(findScriptIn(['/nope/a', '/nope/b'], 'repo', { platform: 'darwin' }), null);
  assert.equal(findScriptIn([], 'repo'), null);
  assert.equal(findScriptIn(null, 'repo'), null);
  fs.rmSync(bundled, { recursive: true, force: true });
});

test('a null root in the list is skipped rather than throwing', () => {
  // scriptRoots() builds its list from optional config, so a hole is possible.
  const bundled = scriptDir(['repo.sh']);
  const found = findScriptIn([null, undefined, bundled], 'repo', { platform: 'darwin' });
  assert.equal(found.root, bundled);
  fs.rmSync(bundled, { recursive: true, force: true });
});
