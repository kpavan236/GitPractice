'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createAiClient, AiNotConfiguredError, AiAuthError, AiRateLimitError, AiNetworkError } = require('./client');

test('available() is false when aiEnabled is false', () => {
  const ai = createAiClient({ aiEnabled: false, aiProvider: 'openai', aiModel: 'gpt-4o', aiApiKey: 'k' });
  assert.equal(ai.available(), false);
});

test('available() is false when provider is missing', () => {
  const ai = createAiClient({ aiEnabled: true, aiProvider: '', aiModel: 'gpt-4o', aiApiKey: 'k' });
  assert.equal(ai.available(), false);
});

test('available() is false when model is missing', () => {
  const ai = createAiClient({ aiEnabled: true, aiProvider: 'openai', aiModel: '', aiApiKey: 'k' });
  assert.equal(ai.available(), false);
});

test('available() is true when provider and model are set', () => {
  const ai = createAiClient({ aiEnabled: true, aiProvider: 'openai', aiModel: 'gpt-4o', aiApiKey: 'k' });
  assert.equal(ai.available(), true);
});

test('complete() throws AiNotConfiguredError when not available', async () => {
  const ai = createAiClient({ aiEnabled: false, aiProvider: 'openai', aiModel: 'gpt-4o' });
  await assert.rejects(() => ai.complete({ messages: [{ role: 'user', content: 'hi' }] }), AiNotConfiguredError);
});

test('complete() dispatches to provider complete() with correct args', async () => {
  let called = null;
  const fakeProvider = { complete: async (args) => { called = args; return 'reply'; } };
  const ai = createAiClient(
    { aiEnabled: true, aiProvider: '__fake__', aiModel: 'model-x', aiApiKey: 'key-y', aiHost: 'host-z' },
    { _overrideProviders: { __fake__: fakeProvider } }
  );
  const result = await ai.complete({ messages: [{ role: 'user', content: 'hello' }], system: 'be helpful', maxTokens: 512 });
  assert.equal(result, 'reply');
  assert.equal(called.model, 'model-x');
  assert.equal(called.apiKey, 'key-y');
  assert.equal(called.host, 'host-z');
  assert.equal(called.system, 'be helpful');
  assert.equal(called.maxTokens, 512);
});

test('complete() wraps 401 from provider as AiAuthError', async () => {
  const fakeProvider = { complete: async () => { const e = new Error('auth'); e.response = { status: 401 }; throw e; } };
  const ai = createAiClient(
    { aiEnabled: true, aiProvider: '__fake__', aiModel: 'm', aiApiKey: 'k' },
    { _overrideProviders: { __fake__: fakeProvider } }
  );
  await assert.rejects(() => ai.complete({ messages: [] }), AiAuthError);
});

test('complete() wraps 429 from provider as AiRateLimitError', async () => {
  const fakeProvider = { complete: async () => { const e = new Error('rate'); e.response = { status: 429 }; throw e; } };
  const ai = createAiClient(
    { aiEnabled: true, aiProvider: '__fake__', aiModel: 'm', aiApiKey: 'k' },
    { _overrideProviders: { __fake__: fakeProvider } }
  );
  await assert.rejects(() => ai.complete({ messages: [] }), AiRateLimitError);
});

test('error classes carry .code', () => {
  assert.equal(new AiNotConfiguredError().code, 'AI_NOT_CONFIGURED');
  assert.equal(new AiAuthError().code, 'AI_AUTH');
  assert.equal(new AiRateLimitError().code, 'AI_RATE_LIMIT');
  assert.equal(new AiNetworkError('x').code, 'AI_NETWORK');
});
