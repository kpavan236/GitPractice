'use strict';

module.exports = {
  id: 'bedrock',
  label: 'AWS Bedrock',
  fields: [
    { key: 'model', label: 'Model ID or ARN', type: 'text', placeholder: 'anthropic.claude-3-haiku-20240307-v1:0' },
  ],

  async complete({ messages, system, model, maxTokens = 1024, bedrockRuntime }) {
    if (!bedrockRuntime || typeof bedrockRuntime.send !== 'function') {
      throw new Error('Bedrock runtime not provided — pass { bedrockRuntime } to createAiClient');
    }
    const { ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');
    const modelId = model;
    if (!modelId) throw new Error('Bedrock model not configured');

    const resp = await bedrockRuntime.send(() => new ConverseCommand({
      modelId,
      ...(system ? { system: [{ text: system }] } : {}),
      messages: messages.map(m => ({
        role: m.role,
        content: [{ text: String(m.content) }],
      })),
      inferenceConfig: { maxTokens, temperature: 0.2 },
    }));
    return (resp?.output?.message?.content || []).map(b => b.text).filter(Boolean).join('\n').trim();
  },
};