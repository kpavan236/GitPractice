'use strict';
const axios = require('axios');

// Chat-capable model families. /v1/models also returns embeddings, whisper,
// tts, dall-e, and moderation models — none of them usable for a chat
// completion, so a raw dump would bury the handful of models someone actually
// wants under dozens of irrelevant ones.
const CHAT_PREFIXES = ['gpt-', 'o1', 'o3', 'o4', 'chatgpt-'];

module.exports = {
  id: 'openai',
  label: 'OpenAI',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password' },
    { key: 'model', label: 'Model', type: 'model-select' },
  ],

  async listModels({ apiKey }) {
    if (!apiKey) throw new Error('API key is required');
    const r = await axios.get('https://api.openai.com/v1/models', {
      headers: { Authorization: `Bearer ${apiKey}` }, timeout: 10000,
    });
    return (r.data.data || [])
      .map(m => m.id)
      .filter(id => CHAT_PREFIXES.some(p => id.startsWith(p)))
      .sort();
  },

  async complete({ messages, system, model, maxTokens = 1024, apiKey }) {
    if (!apiKey) throw new Error('OpenAI API key required');
    const r = await axios.post('https://api.openai.com/v1/chat/completions', {
      model,
      max_tokens: maxTokens,
      messages: [
        ...(system ? [{ role: 'system', content: system }] : []),
        ...messages.map(m => ({ role: m.role, content: String(m.content) })),
      ],
    }, {
      headers: { Authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
      timeout: 60000,
    });
    return r.data.choices?.[0]?.message?.content?.trim() || '';
  },
};