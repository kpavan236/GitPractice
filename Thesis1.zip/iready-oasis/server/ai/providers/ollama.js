'use strict';
const axios = require('axios');

module.exports = {
  id: 'ollama',
  label: 'Ollama (local)',
  fields: [
    { key: 'host', label: 'Host URL', type: 'text', placeholder: 'http://localhost:11434' },
    { key: 'model', label: 'Model', type: 'model-select' },
  ],

  async listModels({ host }) {
    if (!host) throw new Error('Host URL is required');
    const r = await axios.get(`${host.replace(/\/$/, '')}/api/tags`, { timeout: 8000 });
    return (r.data.models || []).map(m => m.name).sort();
  },

  async complete({ messages, system, model, maxTokens = 1024, host }) {
    if (!host) throw new Error('Ollama host URL required');
    const r = await axios.post(`${host.replace(/\/$/, '')}/api/chat`, {
      model,
      stream: false,
      options: { num_predict: maxTokens },
      messages: [
        ...(system ? [{ role: 'system', content: system }] : []),
        ...messages.map(m => ({ role: m.role, content: String(m.content) })),
      ],
    }, { timeout: 120000 });
    return r.data.message?.content?.trim() || '';
  },
};