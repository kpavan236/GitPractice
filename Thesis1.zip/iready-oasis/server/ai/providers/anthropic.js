'use strict';
const axios = require('axios');

module.exports = {
  id: 'anthropic',
  label: 'Anthropic (direct API)',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password' },
    { key: 'model', label: 'Model', type: 'model-select' },
  ],

  async listModels({ apiKey }) {
    if (!apiKey) throw new Error('API key is required');
    const r = await axios.get('https://api.anthropic.com/v1/models', {
      headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' }, timeout: 10000,
    });
    return (r.data.data || []).map(m => m.id).sort();
  },

  async complete({ messages, system, model, maxTokens = 1024, apiKey }) {
    if (!apiKey) throw new Error('Anthropic API key required');
    const r = await axios.post('https://api.anthropic.com/v1/messages', {
      model,
      max_tokens: maxTokens,
      ...(system ? { system } : {}),
      messages: messages.map(m => ({ role: m.role, content: String(m.content) })),
    }, {
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      timeout: 60000,
    });
    return (r.data.content || []).map(b => b.text).filter(Boolean).join('\n').trim();
  },
};