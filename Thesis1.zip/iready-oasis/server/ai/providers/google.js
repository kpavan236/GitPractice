'use strict';
const axios = require('axios');

module.exports = {
  id: 'google',
  label: 'Google (Gemini)',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password' },
    { key: 'model', label: 'Model', type: 'model-select' },
  ],

  async listModels({ apiKey }) {
    if (!apiKey) throw new Error('API key is required');
    const r = await axios.get('https://generativelanguage.googleapis.com/v1beta/models', {
      params: { key: apiKey }, timeout: 10000,
    });
    return (r.data.models || [])
      // Only models this key can actually use for a chat-style call — the
      // list also includes embedding/vision-only entries that would 400 if
      // sent a generateContent request.
      .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
      .map(m => (m.name || '').replace(/^models\//, ''))
      .filter(Boolean)
      .sort();
  },

  async complete({ messages, system, model, maxTokens = 1024, apiKey }) {
    if (!apiKey) throw new Error('Google API key required');
    const contents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m.content) }],
    }));
    const r = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
        contents,
        generationConfig: { maxOutputTokens: maxTokens },
      },
      { params: { key: apiKey }, timeout: 60000 }
    );
    return (r.data.candidates?.[0]?.content?.parts || [])
      .map(p => p.text).filter(Boolean).join('\n').trim();
  },
};