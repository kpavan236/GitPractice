'use strict';
const bedrock   = require('./providers/bedrock');
const openai    = require('./providers/openai');
const anthropic = require('./providers/anthropic');
const google    = require('./providers/google');
const ollama    = require('./providers/ollama');

// Every provider adapter, keyed by id. Adding a new provider later is one new
// file here plus one line in this map — nothing else in the app needs to
// change, since Settings renders whatever `fields` each adapter declares and
// /api/ai/models just dispatches by id.
const PROVIDERS = { bedrock, openai, anthropic, google, ollama };

function installAI(app, { sessions, bedrockRuntimeFactory }) {
  /** GET /api/ai/providers?session=SID — the provider list + what each needs, for Settings to render */
  app.get('/api/ai/providers', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    res.json({
      providers: Object.values(PROVIDERS).map(p => ({ id: p.id, label: p.label, fields: p.fields })),
    });
  });

  /**
   * POST /api/ai/models — live model list for one provider.
   * Body: { session, provider, apiKey?, host? }
   * A provider with no listModels() (Bedrock) or a fetch failure both return
   * a normal JSON error — the caller falls back to a plain text field either way.
   */
  app.post('/api/ai/models', async (req, res) => {
    const { session, provider, apiKey, host } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    const adapter = PROVIDERS[provider];
    if (!adapter) return res.status(400).json({ error: `Unknown provider: ${provider}` });
    if (!adapter.listModels) return res.status(400).json({ error: `${adapter.label} has no live model list — enter the model manually` });

    try {
      const models = await adapter.listModels({ apiKey, host });
      res.json({ models });
    } catch (e) {
      const status = e.response?.status;
      res.status(502).json({ error:
        status === 401 || status === 403 ? 'Invalid API key'
        : `Could not fetch models: ${e.message}` });
    }
  });

  /**
   * POST /api/ai/test — verify a provider's credentials/host/model actually
   * work, without requiring Settings to be saved first. Body: { session,
   * provider, apiKey?, host?, model }. Bedrock has no apiKey/host field of its
   * own — it authenticates via the session's AWS profile, so its runtime is
   * built from bedrockRuntimeFactory instead.
   */
  app.post('/api/ai/test', async (req, res) => {
    const { session, provider, apiKey, host, model } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    const adapter = PROVIDERS[provider];
    if (!adapter) return res.status(400).json({ error: `Unknown provider: ${provider}` });
    if (!model) return res.status(400).json({ error: 'Model is required' });

    try {
      const reply = await adapter.complete({
        messages: [{ role: 'user', content: 'Reply with just the word OK.' }],
        maxTokens: 10,
        model, apiKey, host,
        bedrockRuntime: provider === 'bedrock' ? bedrockRuntimeFactory?.(sess) : undefined,
      });
      res.json({ ok: true, message: reply?.trim() || 'Connected' });
    } catch (e) {
      const status = e.response?.status;
      res.status(502).json({ ok: false, error:
        status === 401 || status === 403 ? 'Invalid API key'
        : e.message || 'Connection failed' });
    }
  });
}

module.exports = { installAI };