'use strict';

class AiNotConfiguredError extends Error {
  constructor() { super('AI not configured'); this.code = 'AI_NOT_CONFIGURED'; }
}
class AiAuthError extends Error {
  constructor(msg) { super(msg || 'Invalid API key'); this.code = 'AI_AUTH'; }
}
class AiRateLimitError extends Error {
  constructor() { super('AI rate limit'); this.code = 'AI_RATE_LIMIT'; }
}
class AiNetworkError extends Error {
  constructor(msg) { super(msg); this.code = 'AI_NETWORK'; }
}

const DEFAULT_PROVIDERS = {
  bedrock:   require('./providers/bedrock'),
  openai:    require('./providers/openai'),
  anthropic: require('./providers/anthropic'),
  google:    require('./providers/google'),
  ollama:    require('./providers/ollama'),
};

function createAiClient(sess, { bedrockRuntime, _overrideProviders } = {}) {
  const { aiEnabled, aiProvider, aiModel, aiApiKey, aiHost } = sess || {};
  const providers = _overrideProviders || DEFAULT_PROVIDERS;

  function available() {
    return aiEnabled !== false && !!aiProvider && !!aiModel;
  }

  async function complete({ messages = [], system, maxTokens = 1024 } = {}) {
    if (!available()) throw new AiNotConfiguredError();

    const adapter = providers[aiProvider];
    if (!adapter || typeof adapter.complete !== 'function') throw new AiNotConfiguredError();

    try {
      return await adapter.complete({
        messages,
        system,
        model:   aiModel,
        maxTokens,
        apiKey:  aiApiKey,
        host:    aiHost,
        bedrockRuntime,
      });
    } catch (e) {
      if (e instanceof AiNotConfiguredError || e instanceof AiAuthError ||
          e instanceof AiRateLimitError   || e instanceof AiNetworkError) throw e;

      const status = e.response?.status || e.status;
      if (status === 401 || status === 403) throw new AiAuthError();
      if (status === 429)                   throw new AiRateLimitError();
      if (e.code === 'ECONNREFUSED' || e.code === 'ENOTFOUND') throw new AiNetworkError(e.message);
      throw e;
    }
  }

  return { available, complete };
}

module.exports = {
  createAiClient,
  AiNotConfiguredError,
  AiAuthError,
  AiRateLimitError,
  AiNetworkError,
};
