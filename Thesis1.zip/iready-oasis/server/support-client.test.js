'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createSupportClient, supportServiceUrl, DEFAULT_SUPPORT_URL } = require('./support-client');

function fakeHttp(reply) {
  const calls = [];
  return {
    calls,
    post: async (route, body, config) => {
      calls.push({ route, body, headers: (config && config.headers) || {} });
      if (reply instanceof Error) throw reply;
      return reply || { data: { ok: true, reference: 'SR-000001' } };
    },
  };
}

const httpError = (status, data) => Object.assign(new Error(`status ${status}`), { response: { status, data } });

function clientWith(http, extra = {}) {
  const saved = [];
  const client = createSupportClient({
    http, appVersion: '2.0.1', machineId: 'abcdef0123456789abcdef', saveLocally: (file, text) => saved.push([file, text]), ...extra,
  });
  return { client, saved };
}

test('feedback goes to /feedback with the category, message, app version, machine id and the caller\'s Idempotency-Key', async () => {
  const http = fakeHttp({ data: { ok: true, reference: 'FB-000007' } });
  const { client, saved } = clientWith(http);
  const out = await client.sendFeedback({ category: 'idea', message: 'Add dark mode', email: 'a@example.test', idempotencyKey: 'key-12345678' });
  assert.deepEqual(out, { ok: true, reference: 'FB-000007' });
  assert.equal(http.calls[0].route, '/feedback');
  assert.deepEqual(http.calls[0].body, { category: 'idea', message: 'Add dark mode', email: 'a@example.test', appVersion: '2.0.1', machineId: 'abcdef0123456789abcdef' });
  assert.equal(http.calls[0].headers['Idempotency-Key'], 'key-12345678');
  assert.equal(saved.length, 0, 'nothing is written locally when the service took it');
});

test('a support request goes to /support-request with subject, message, name and email', async () => {
  const http = fakeHttp();
  const { client } = clientWith(http);
  const out = await client.sendSupportRequest({ subject: 'Cannot connect', message: 'Jenkins says no', contactName: 'Nia', email: 'nia@example.test', idempotencyKey: 'key-87654321' });
  assert.deepEqual(out, { ok: true, reference: 'SR-000001' });
  assert.equal(http.calls[0].route, '/support-request');
  assert.deepEqual(http.calls[0].body, { subject: 'Cannot connect', message: 'Jenkins says no', contactName: 'Nia', email: 'nia@example.test', appVersion: '2.0.1', machineId: 'abcdef0123456789abcdef' });
});

test('an email left blank on feedback is not sent at all', async () => {
  const http = fakeHttp();
  await clientWith(http).client.sendFeedback({ category: 'bug', message: 'x', email: '   ' });
  assert.equal('email' in http.calls[0].body, false);
});

test('without a usable Idempotency-Key from the caller one is made, so a retry of THIS call is still safe', async () => {
  const http = fakeHttp();
  await clientWith(http).client.sendFeedback({ category: 'bug', message: 'x', idempotencyKey: 'bad key!' });
  assert.match(http.calls[0].headers['Idempotency-Key'], /^[A-Za-z0-9_-]{8,100}$/);
});

test('when the service refuses the details, the field errors come back and nothing is saved locally', async () => {
  const http = fakeHttp(httpError(400, { error: 'rejected', message: 'Some details need fixing.', reason: 'invalid', errors: { email: 'Enter a valid email address.' } }));
  const { client, saved } = clientWith(http);
  const out = await client.sendSupportRequest({ subject: 's', message: 'm', contactName: 'n', email: 'nope' });
  assert.equal(out.ok, false);
  assert.equal(out.rejected, true);
  assert.equal(out.message, 'Some details need fixing.');
  assert.deepEqual(out.errors, { email: 'Enter a valid email address.' });
  assert.equal(saved.length, 0);
});

test('a rate limit (429) is a refusal, not an outage', async () => {
  const http = fakeHttp(httpError(429, { message: 'Too many requests. Please try later.' }));
  const out = await clientWith(http).client.sendFeedback({ category: 'bug', message: 'x' });
  assert.equal(out.rejected, true);
  assert.equal(out.message, 'Too many requests. Please try later.');
});

test('when the service cannot be reached the words are kept on this computer and the caller is told so', async () => {
  const http = fakeHttp(Object.assign(new Error('connect ECONNREFUSED'), { code: 'ECONNREFUSED' }));
  const { client, saved } = clientWith(http);
  const out = await client.sendFeedback({ category: 'idea', message: 'Please add X', email: 'a@example.test', who: 'octocat' });
  assert.deepEqual({ ok: out.ok, savedLocally: out.savedLocally }, { ok: true, savedLocally: true });
  assert.equal(saved.length, 1);
  assert.equal(saved[0][0], 'feedback.txt');
  assert.match(saved[0][1], /octocat/);
  assert.match(saved[0][1], /idea/);
  assert.match(saved[0][1], /Please add X/);
});

test('a 5xx from the service is also an outage and is kept locally', async () => {
  const http = fakeHttp(httpError(503, { error: 'internal' }));
  const { client, saved } = clientWith(http);
  const out = await client.sendSupportRequest({ subject: 'S', message: 'M', contactName: 'N', email: 'n@example.test' });
  assert.equal(out.savedLocally, true);
  assert.equal(saved[0][0], 'support.txt');
  assert.match(saved[0][1], /S\nM/);
});

test('if even the local save fails the caller gets a plain failure and the error text carries no message content', async () => {
  const http = fakeHttp(new Error('boom'));
  const { client } = clientWith(http, { saveLocally: () => { throw new Error('disk full'); } });
  const out = await client.sendFeedback({ category: 'bug', message: 'secret words' });
  assert.equal(out.ok, false);
  assert.equal(out.unreachable, true);
  assert.equal(/secret words/.test(JSON.stringify(out)), false);
});

test('the service address comes from OASIS_SUPPORT_URL, without a trailing slash, and defaults to the local service', () => {
  assert.equal(supportServiceUrl({}), DEFAULT_SUPPORT_URL);
  assert.equal(DEFAULT_SUPPORT_URL, 'http://localhost:4040/v1');
  assert.equal(supportServiceUrl({ OASIS_SUPPORT_URL: 'https://support.example.test/v1/' }), 'https://support.example.test/v1');
});
