'use strict';
const fs   = require('fs');
const path = require('path');

// Branch listing, switching, and the background cache that keeps it warm.
//
// Listing branches is slow: it runs `git ls-remote` against github.cainc.com
// (30s timeout, up to 3 retries). To make opening a repo's branch list feel
// instant we cache results per session+repo and keep them warm in the
// background. Mirrors the sess._badgeCache convention used elsewhere.
const BRANCH_CACHE_TTL_MS = 15 * 60 * 1000; // serve cached branches for 15 min
const BRANCH_WARM_MS      = 10 * 60 * 1000; // re-warm local repos every 10 min

function installBranches(app, { sessions, expandHome, execQuiet, isProjectDir, externalCalls }) {
  if (!externalCalls) throw new Error('installBranches needs externalCalls: it runs git commands that contact GitHub');

  /** List cloned-repo directory names under `base` (immediate subdirs containing a .git). */
  function scanLocalRepoDirs(base) {
    if (!base || !fs.existsSync(base)) return [];
    try {
      return fs.readdirSync(base).filter(d => isProjectDir(base, d));
    } catch { return []; }
  }

  /** Run the git commands that produce { branches, remoteBranches } for one repo dir. */
  async function computeBranches(dir) {
    // Local branches
    const localRaw = await execQuiet(`git -C "${dir}" branch --format="%(refname:short)|%(HEAD)"`, { timeout: 8000 });
    const local = localRaw.split('\n').filter(Boolean).map(line => {
      const [name, head] = line.split('|');
      return { name: name.trim(), current: head.trim() === '*', remote: false };
    });
    const localNames = new Set(local.map(b => b.name));

    // Remote branches — OASIS clones are shallow+single-branch, so
    // `git branch -r` only ever shows the one cloned branch. Query the server
    // directly with ls-remote (names only, no history download) so all branches
    // are visible regardless of local clone state. Falls back to local
    // remote-tracking refs when offline. Forces HTTP/1.1 because
    // github.cainc.com's HTTP/2 endpoint intermittently drops connections.
    let remote = [];
    try {
      // With GitHub calls switched off this throws and we land in the catch below,
      // which lists the remote branches already known on disk.
      let lsRaw = null, lastErr = null;
      externalCalls.assertAllowed('GitHub');       // not inside the retry loop below: a switched-off error must not be retried
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          lsRaw = await execQuiet(`git -C "${dir}" -c http.version=HTTP/1.1 ls-remote --heads origin`, { timeout: 30000 });
          lastErr = null; break;
        } catch (err) {
          lastErr = err;
          if (attempt < 3) await new Promise(r => setTimeout(r, 5000));
        }
      }
      if (lastErr) throw lastErr;
      remote = lsRaw.split('\n').filter(Boolean)
        .map(line => (line.split('\t')[1] || ''))
        .filter(ref => ref.startsWith('refs/heads/'))
        .map(ref => ref.slice('refs/heads/'.length))
        .filter(name => !localNames.has(name))
        .map(name => ({ name, remoteFull: `origin/${name}`, remote: true, current: false }));
    } catch {
      const remoteRaw = await execQuiet(`git -C "${dir}" branch -r --format="%(refname:short)"`, { timeout: 8000 });
      remote = remoteRaw.split('\n').filter(Boolean)
        .map(r => r.trim())
        .filter(r => !r.endsWith('/HEAD'))
        .map(r => ({ name: r.replace(/^origin\//, ''), remoteFull: r, remote: true, current: false }))
        .filter(r => !localNames.has(r.name));
    }
    return { branches: local, remoteBranches: remote };
  }

  /**
   * Load branches for one repo into the session cache. Coalesces concurrent
   * loads of the same repo so a user click and the background warmer don't both
   * fire `ls-remote` at once. Returns the { branches, remoteBranches } payload.
   */
  function refreshBranchCache(sess, repo, dir) {
    if (!sess._branchCache)   sess._branchCache   = {};
    if (!sess._branchLoading) sess._branchLoading = {};
    if (sess._branchLoading[repo]) return sess._branchLoading[repo];
    const p = computeBranches(dir)
      .then(data => { sess._branchCache[repo] = { data, ts: Date.now() }; return data; })
      .finally(() => { delete sess._branchLoading[repo]; });
    sess._branchLoading[repo] = p;
    return p;
  }

  /** GET /api/branches?session=SID&repo=REPO[&force=1] — lists local and remote branches */
  app.get('/api/branches', async (req, res) => {
    const { session, repo, force } = req.query;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const dir = path.join(expandHome(sess.cloneDir), repo);
    if (!sess._branchCache) sess._branchCache = {};
    try {
      const hit = sess._branchCache[repo];
      if (hit && !force) {
        // Serve the cached list immediately; if it's gone stale, refresh in the
        // background so the next open is fresh without making this one wait.
        if ((Date.now() - hit.ts) >= BRANCH_CACHE_TTL_MS) refreshBranchCache(sess, repo, dir).catch(() => {});
        return res.json(hit.data);
      }
      res.json(await refreshBranchCache(sess, repo, dir));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  /** POST /api/switch-branch — git checkout <branch> (local) or create tracking branch (remote) */
  app.post('/api/switch-branch', async (req, res) => {
    const { session, repo, branch, remoteFull } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const dir = path.join(expandHome(sess.cloneDir), repo);
    try {
      // Does a local branch with this name already exist?
      let localExists = false;
      try {
        await execQuiet(`git -C "${dir}" rev-parse --verify --quiet "refs/heads/${branch}"`, { timeout: 10000 });
        localExists = true;
      } catch { /* no local branch */ }

      if (localExists) {
        await execQuiet(`git -C "${dir}" checkout "${branch}"`, { timeout: 15000 });
      } else if (remoteFull) {
        // Remote branch from ls-remote — objects/tracking ref don't exist locally
        // yet (shallow+single-branch clone). Fetch just this one branch's tip,
        // then check out at the fetched ref and write tracking config directly
        // (checkout --track and --set-upstream-to both fail because our manual
        // fetch doesn't register the branch in .git/config's remote tracking
        // config, so we write branch.remote and branch.merge ourselves).
        const shallow = fs.existsSync(path.join(dir, '.git', 'shallow'));
        const depthFlag = shallow ? '--depth=1' : '';
        externalCalls.assertAllowed('GitHub');
        const fetchCmd = `git -C "${dir}" -c http.version=HTTP/1.1 -c http.postBuffer=524288000 fetch ${depthFlag} origin "${branch}:refs/remotes/origin/${branch}"`;
        let lastErr = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
          try { await execQuiet(fetchCmd, { timeout: 300000 }); lastErr = null; break; }
          catch (err) { lastErr = err; }
        }
        if (lastErr) throw lastErr;
        await execQuiet(`git -C "${dir}" checkout -b "${branch}" "refs/remotes/origin/${branch}"`, { timeout: 20000 });
        await execQuiet(`git -C "${dir}" config "branch.${branch}.remote" "origin"`, { timeout: 5000 }).catch(() => {});
        await execQuiet(`git -C "${dir}" config "branch.${branch}.merge" "refs/heads/${branch}"`, { timeout: 5000 }).catch(() => {});
      } else {
        await execQuiet(`git -C "${dir}" checkout "${branch}"`, { timeout: 15000 });
      }
      res.json({ ok: true });
    } catch (e) {
      let msg = e.message.slice(0, 300);
      if (/resolve your current index first/i.test(msg)) {
        msg = `The "${repo}" repo has an unresolved merge/rebase or conflicted index. ` +
              `Run \`git -C "${dir}" merge --abort\` or \`git rebase --abort\` first, then retry.`;
      }
      res.status(500).json({ error: msg });
    }
  });

  /** POST /api/create-branch — git checkout -b <branch> */
  app.post('/api/create-branch', async (req, res) => {
    const { session, repo, branch } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const dir = path.join(expandHome(sess.cloneDir), repo);
    try {
      await execQuiet(`git -C "${dir}" checkout -b "${branch}"`, { timeout: 10000 });
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message.slice(0, 200) }); }
  });

  /** POST /api/delete-branch — git branch -d <branch> */
  app.post('/api/delete-branch', async (req, res) => {
    const { session, repo, branch, force } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const dir = path.join(expandHome(sess.cloneDir), repo);
    try {
      const flag = force ? '-D' : '-d';
      await execQuiet(`git -C "${dir}" branch ${flag} "${branch}"`, { timeout: 10000 });
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message.slice(0, 200) }); }
  });

  // Keep each local repo's branch list warm in the cache so opening the branch
  // modal is instant instead of waiting on a fresh `git ls-remote`. Refreshes
  // missing/soon-stale entries a few repos at a time to avoid spawning dozens of
  // concurrent network git calls.
  function initBranchWarmer() {
    let warming = false;
    const warm = async () => {
      if (warming) return;
      if (!externalCalls.isEnabled()) return;   // the background refresh is exactly what the switch stops
      const entry = Object.entries(sessions).find(([, s]) => s.githubUrl && s.token && s.cloneDir);
      if (!entry) return;
      const [, sess] = entry;
      const base = expandHome(sess.cloneDir);
      const dirs = scanLocalRepoDirs(base);
      if (!dirs.length) return;

      warming = true;
      try {
        if (!sess._branchCache) sess._branchCache = {};
        const stale = repo => {
          const hit = sess._branchCache[repo];
          // Refresh anything missing or close to expiry so the cache stays warm
          // between warm cycles.
          return !hit || (Date.now() - hit.ts) >= (BRANCH_WARM_MS - 60 * 1000);
        };
        const BATCH = 3;
        for (let i = 0; i < dirs.length; i += BATCH) {
          const batch = dirs.slice(i, i + BATCH).filter(stale);
          if (!batch.length) continue;
          await Promise.all(batch.map(repo =>
            refreshBranchCache(sess, repo, path.join(base, repo)).catch(() => {})
          ));
        }
      } finally { warming = false; }
    };
    setTimeout(warm, 15000);            // first pass shortly after startup/login
    setInterval(warm, BRANCH_WARM_MS);  // keep it warm
  }

  initBranchWarmer();
}

module.exports = { installBranches };