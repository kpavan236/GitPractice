'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { applyServiceConfig, userConfigFile, KEYS } = require('./service-config');

function configFile(content) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'svc-config-'));
  const file = path.join(dir, 'services.json');
  fs.writeFileSync(file, typeof content === 'string' ? content : JSON.stringify(content));
  return file;
}

const GOOD = {
  licenseUrl: 'http://localhost:4020/v1',
  licensePublicKeyFile: '~/.oasis-local-stack/licence-public.pem',
  supportUrl: 'http://localhost:4040/v1',
  ruleServerUrl: 'http://127.0.0.1:5090',
};

test('the file supplies each address the app reads from its environment', () => {
  const env = {};
  const applied = applyServiceConfig(env, { files: [configFile(GOOD)], home: '/home/me', exists: () => true });
  assert.equal(env.OASIS_LICENSE_URL, 'http://localhost:4020/v1');
  assert.equal(env.OASIS_SUPPORT_URL, 'http://localhost:4040/v1');
  assert.equal(env.OASIS_RULE_SERVER_URL, 'http://127.0.0.1:5090');
  assert.deepEqual(applied.sort(), ['OASIS_LICENSE_PUBLIC_KEY', 'OASIS_LICENSE_URL', 'OASIS_RULE_SERVER_URL', 'OASIS_SUPPORT_URL']);
});

test('a leading ~ in the key file is the home folder', () => {
  const env = {};
  applyServiceConfig(env, { files: [configFile(GOOD)], home: '/home/me', exists: () => true });
  assert.equal(env.OASIS_LICENSE_PUBLIC_KEY, '/home/me/.oasis-local-stack/licence-public.pem');
});

test('a key file that is not on disk is not set, so the app says plainly that it is using the development key instead of failing on a missing path', () => {
  const env = {};
  const applied = applyServiceConfig(env, { files: [configFile(GOOD)], home: '/home/me', exists: () => false });
  assert.equal('OASIS_LICENSE_PUBLIC_KEY' in env, false);
  assert.equal(applied.includes('OASIS_LICENSE_PUBLIC_KEY'), false);
});

test('anything already in the environment wins over the file', () => {
  const env = { OASIS_LICENSE_URL: 'https://licence.example.test/v1', OASIS_SUPPORT_URL: '' };
  applyServiceConfig(env, { files: [configFile(GOOD)], home: '/h' });
  assert.equal(env.OASIS_LICENSE_URL, 'https://licence.example.test/v1');
  assert.equal(env.OASIS_SUPPORT_URL, 'http://localhost:4040/v1', 'an empty variable is "not set"');
});

test('a missing file changes nothing', () => {
  const env = {};
  assert.deepEqual(applyServiceConfig(env, { files: [path.join(os.tmpdir(), 'no-such-dir', 'services.json')] }), []);
  assert.deepEqual(env, {});
});

test('a damaged file changes nothing and does not throw', () => {
  const env = {};
  assert.deepEqual(applyServiceConfig(env, { files: [configFile('{ not json')] }), []);
  assert.deepEqual(applyServiceConfig(env, { files: [configFile('[1,2]')] }), []);
  assert.deepEqual(env, {});
});

test('only known settings with text values are used; anything else in the file is ignored', () => {
  const env = {};
  applyServiceConfig(env, { files: [configFile({ ...GOOD, supportUrl: 4040, extra: 'x', licenseUrl: '  http://localhost:4020/v1  ' })], home: '/h' });
  assert.equal('OASIS_SUPPORT_URL' in env, false, 'a number is not an address');
  assert.equal('extra' in env, false);
  assert.equal(env.OASIS_LICENSE_URL, 'http://localhost:4020/v1', 'surrounding spaces are trimmed');
});

test('the settings table maps each file key to one environment variable', () => {
  assert.deepEqual(Object.values(KEYS).sort(), ['OASIS_LICENSE_PUBLIC_KEY', 'OASIS_LICENSE_URL', 'OASIS_RULE_SERVER_URL', 'OASIS_SUPPORT_URL']);
});

test('a per-user file overrides the bundled one, setting by setting', () => {
  const user = configFile({ licenseUrl: 'http://localhost:5020/v1', supportUrl: 'http://localhost:5040/v1' });
  const bundled = configFile(GOOD);
  const env = {};
  applyServiceConfig(env, { files: [user, bundled], home: '/h', exists: () => true });
  assert.equal(env.OASIS_LICENSE_URL, 'http://localhost:5020/v1');
  assert.equal(env.OASIS_SUPPORT_URL, 'http://localhost:5040/v1');
  assert.equal(env.OASIS_RULE_SERVER_URL, 'http://127.0.0.1:5090', 'a setting the user file leaves out still comes from the bundled file');
});

test('a missing or damaged per-user file does not stop the bundled one being used', () => {
  const env = {};
  applyServiceConfig(env, { files: [path.join(os.tmpdir(), 'nope', 'u.json'), configFile('{ bad'), configFile(GOOD)], home: '/h', exists: () => true });
  assert.equal(env.OASIS_LICENSE_URL, 'http://localhost:4020/v1');
});

test('OASIS_SERVICES_CONFIG names the per-user file, and the default is ~/.oasis-services.json', () => {
  assert.equal(userConfigFile({ OASIS_SERVICES_CONFIG: '/etc/oasis/services.json' }, '/h'), '/etc/oasis/services.json');
  assert.equal(userConfigFile({}, '/home/me'), path.join('/home/me', '.oasis-services.json'));
});
