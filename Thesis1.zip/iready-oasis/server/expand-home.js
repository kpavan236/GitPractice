'use strict';
const os = require('os');
const path = require('path');

// Expands a leading `~` to the user's home directory.
//
// Extracted because it is load-bearing in ~30 places and none of them could be
// tested while it lived inside a 5,000-line Express file.
//
// It replaces `.replace('~', process.env.HOME || '/tmp')`, which was wrong in
// two ways at once on Windows: HOME is normally UNSET there — the variable is
// USERPROFILE — so every call fell through to `/tmp` and resolved to
// `C:\tmp\dev\projects\iready`. Not a crash, which is worse: the app carried on
// cloning, scanning and hunting for scripts in a directory nobody had ever
// used.
//
// `os.homedir()` reads USERPROFILE on Windows and HOME elsewhere, so it is
// correct on both. Only a LEADING `~` is expanded — a bare `.replace()` would
// happily rewrite a tilde in the middle of a legitimate path, and `~` is a
// legal character in a filename.
function expandHome(p) {
  const text = String(p == null ? '' : p);
  if (text !== '~' && !text.startsWith('~/') && !text.startsWith('~\\')) return text;
  // path.join normalises the separator, so `~/dev` yields a backslash path on
  // Windows without the caller having to care.
  return path.join(os.homedir(), text.slice(1));
}

module.exports = { expandHome };
