'use strict';
const fs    = require('fs');
const os    = require('os');
const path  = require('path');
const axios = require('axios');

// Docker Services tab: search Docker Hub, add images to a personal catalog,
// and manage their containers. No dependency on any cloned repo — the
// catalog is just what you've explicitly added, stored locally.
const CATALOG_PATH = path.join(os.homedir(), '.oasis-docker-catalog.json');
const HUB_API       = 'https://hub.docker.com/v2';
const POPULAR_TTL_MS = 60 * 60 * 1000; // 1 hour

const humanize = s => String(s).replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
const slugify  = s => String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

function loadCatalog() {
  try {
    if (!fs.existsSync(CATALOG_PATH)) return [];
    return JSON.parse(fs.readFileSync(CATALOG_PATH, 'utf8')) || [];
  } catch (_) { return []; }
}
function saveCatalog(list) {
  fs.writeFileSync(CATALOG_PATH, JSON.stringify(list, null, 2), 'utf8');
}

function containerFor(name) { return `oasis-${name}`; }

function catalogEntryToService(entry) {
  return {
    name:      entry.name,
    label:     humanize(entry.name),
    image:     entry.image,
    tag:       entry.tag || 'latest',
    fullImage: `${entry.image}:${entry.tag || 'latest'}`,
    ports:     (entry.ports || []).map(p => p.host).filter(Boolean),
    group:     entry.group || 'Ungrouped',
    container: containerFor(entry.name),
  };
}

// A repo name Docker Hub returns unnamespaced official images as e.g. "redis" —
// docker run needs no prefix for those, but the Hub API paths do (library/redis).
function hubRepoPath(repo) { return repo.includes('/') ? repo : `library/${repo}`; }

function installDocker(app, { sessions, execQuiet, spawn, spawnBash, broadcast, enqueueLog }) {

  let popularCache = null, popularCacheAt = 0;

  async function fetchPopular() {
    if (popularCache && (Date.now() - popularCacheAt) < POPULAR_TTL_MS) return popularCache;
    // Docker Hub's `ordering` param on this endpoint doesn't actually sort by
    // pull_count, so fetch one page of official images and sort client-side.
    // (Anonymous requests 403 past page 1 on this endpoint — "pagination
    // offset too large for anonymous requests" — so this is the full budget.)
    const r = await axios.get(`${HUB_API}/repositories/library/?page_size=100`, { timeout: 10000 });
    const sorted = (r.data.results || [])
      .sort((a, b) => (b.pull_count || 0) - (a.pull_count || 0))
      .slice(0, 30)
      .map(r => ({
        repo: r.name, description: r.description || '',
        pullCount: r.pull_count || 0, starCount: r.star_count || 0, isOfficial: true,
      }));
    popularCache = sorted; popularCacheAt = Date.now();
    return sorted;
  }

  /** GET /api/docker/hub/popular?session=SID — Hub's official images, most-pulled first */
  app.get('/api/docker/hub/popular', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    try { res.json({ results: await fetchPopular() }); }
    catch (e) { res.status(502).json({ error: `Could not reach Docker Hub: ${e.message}` }); }
  });

  /** GET /api/docker/hub/search?session=SID&q=TERM — proxies Docker Hub search */
  app.get('/api/docker/hub/search', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const q = String(req.query.q || '').trim();
    if (!q) return res.json({ results: [] });
    try {
      const r = await axios.get(`${HUB_API}/search/repositories/`,
        { params: { query: q, page_size: 25 }, timeout: 10000 });
      const results = (r.data.results || []).map(x => ({
        repo: x.repo_name, description: x.short_description || '',
        pullCount: x.pull_count || 0, starCount: x.star_count || 0, isOfficial: !!x.is_official,
      }));
      res.json({ results });
    } catch (e) { res.status(502).json({ error: `Docker Hub search failed: ${e.message}` }); }
  });

  /** GET /api/docker/hub/tags?session=SID&repo=NAME — version tags for one image */
  app.get('/api/docker/hub/tags', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const repo = String(req.query.repo || '').trim();
    if (!repo) return res.status(400).json({ error: 'repo required' });
    const repoPath = hubRepoPath(repo);
    try {
      // `ordering` on this endpoint is silently ignored — it always returns
      // tags oldest-first, so an unqualified fetch surfaces ancient versions
      // (e.g. redis:2.8.19 from 2015, whose image manifest format modern
      // Docker/containerd rejects outright). Ask for "latest" specifically
      // and put it first when it exists; sort the rest by last_updated
      // ourselves as a best-effort fallback for images with no "latest" tag.
      const [latestR, listR] = await Promise.all([
        axios.get(`${HUB_API}/repositories/${repoPath}/tags`, { params: { page_size: 1, name: 'latest' }, timeout: 10000 }),
        axios.get(`${HUB_API}/repositories/${repoPath}/tags`, { params: { page_size: 25 }, timeout: 10000 }),
      ]);
      const hasLatest = (latestR.data.results || []).some(t => t.name === 'latest');
      const rest = (listR.data.results || [])
        .filter(t => t.name !== 'latest')
        .sort((a, b) => new Date(b.last_updated || 0) - new Date(a.last_updated || 0))
        .map(t => t.name);
      res.json({ tags: hasLatest ? ['latest', ...rest] : rest });
    } catch (e) { res.status(502).json({ error: `Could not fetch tags: ${e.message}` }); }
  });

  /**
   * GET /api/docker/services?session=SID
   * Docker availability + your saved catalog, grouped by tag.
   */
  app.get('/api/docker/services', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });

    let dockerOk = false, version = '';
    try {
      version = String(await execQuiet('docker info --format "{{.ServerVersion}}"', { timeout: 6000 })).trim();
      dockerOk = true;
    } catch (_) { dockerOk = false; }

    const catalog = loadCatalog();
    const services = catalog.map(catalogEntryToService);
    const groups = [...new Set(services.map(s => s.group))].sort().map(g => ({ id: g, label: g }));
    res.json({ dockerOk, version, services, groups });
  });

  /**
   * POST /api/docker/catalog — add an image to your catalog
   * Body: { session, name, image, tag, ports: [{host,container}], env: {K:V}, group }
   */
  app.post('/api/docker/catalog', (req, res) => {
    const { session, image, tag, ports, env, group } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!image) return res.status(400).json({ error: 'image is required' });

    const name = slugify(req.body.name || image.split('/').pop());
    if (!name) return res.status(400).json({ error: 'Could not derive a name — provide one' });

    const catalog = loadCatalog();
    if (catalog.some(e => e.name === name)) return res.status(409).json({ error: `"${name}" is already in your catalog` });

    const entry = {
      name, image, tag: tag || 'latest',
      ports: Array.isArray(ports) ? ports.filter(p => p && p.host && p.container) : [],
      env: (env && typeof env === 'object') ? env : {},
      group: (group || '').trim() || 'Ungrouped',
      addedAt: new Date().toISOString(),
    };
    catalog.push(entry);
    saveCatalog(catalog);
    res.json({ ok: true, service: catalogEntryToService(entry) });
  });

  /** DELETE /api/docker/catalog/:name?session=SID — remove from catalog (and its container, best-effort) */
  app.delete('/api/docker/catalog/:name', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const { name } = req.params;
    const catalog = loadCatalog();
    const idx = catalog.findIndex(e => e.name === name);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });
    catalog.splice(idx, 1);
    saveCatalog(catalog);
    await execQuiet(`docker rm -f ${containerFor(name)}`, { timeout: 10000 }).catch(() => {});
    res.json({ ok: true });
  });

  /** GET /api/docker/containers — all containers with status */
  app.get('/api/docker/containers', async (req, res) => {
    try {
      const raw = await execQuiet("docker ps -a --format '{{json .}}'", { timeout: 8000 });
      const containers = String(raw || '').trim().split('\n')
        .filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      res.json({ containers });
    } catch (e) {
      res.json({ containers: [], error: e.message });
    }
  });

  /**
   * POST /api/docker/op
   * Body: { session, operation, services: [{name, container}], opId }
   *   install  — docker run -d from the catalog entry's image/ports/env
   *   start    — docker start <container>
   *   stop     — docker stop <container>
   *   restart  — docker restart <container>
   *   delete   — docker rm -f <container>
   *   logs     — docker logs --tail 200 <container>
   * Streams output via the shared log channel (jobId = opId); docker_op_done at end.
   */
  app.post('/api/docker/op', (req, res) => {
    const { session, operation, services = [], opId } = req.body;
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (operation !== 'logs-stop' && !services.length) return res.status(400).json({ error: 'No services specified' });
    res.json({ ok: true });
    runDockerOp(session, sess, operation, services, opId).catch(e => {
      broadcast(session, { type: 'docker_op_done', opId, success: false, error: e.message });
    });
  });

  function dockerLog(sessionId, opId, level, msg) {
    enqueueLog(sessionId, { jobId: opId, level, message: msg, ts: Date.now() });
  }

  // Stream a shell command's output to the docker op log. Resolves on exit 0.
  function streamDocker(sessionId, opId, cmd) {
    return new Promise((resolve, reject) => {
      dockerLog(sessionId, opId, 'cmd', `$ ${cmd}`);
      const proc = spawnBash(['-c', cmd], { stdio: ['ignore', 'pipe', 'pipe'] });
      const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');
      const mk = lvl => { let buf = ''; return d => {
        buf += d.toString();
        const parts = buf.split(/\r\n|\r|\n/); buf = parts.pop();
        parts.forEach(l => { if (l.trim()) dockerLog(sessionId, opId, lvl, stripAnsi(l)); });
      }; };
      proc.stdout.on('data', mk('out'));
      proc.stderr.on('data', mk('err'));
      proc.on('exit', code => code === 0 ? resolve() : reject(new Error(`exit ${code}`)));
      proc.on('error', reject);
    });
  }

  // Stop any live `docker logs -f` follow attached to this session.
  function stopDockerLogsFollow(sess) {
    if (sess._dockerLogsProc) {
      try { sess._dockerLogsProc.kill('SIGKILL'); } catch (_) {}
      sess._dockerLogsProc = null;
    }
  }

  function runCmdFor(operation, entry, container) {
    if (operation === 'install') {
      const parts = ['docker', 'run', '-d', '--name', container, '--network', 'iready'];
      for (const p of (entry.ports || [])) parts.push('-p', `${p.host}:${p.container}`);
      for (const [k, v] of Object.entries(entry.env || {})) parts.push('-e', `${k}=${JSON.stringify(String(v)).slice(1, -1)}`);
      parts.push(`${entry.image}:${entry.tag || 'latest'}`);
      return parts.map(p => /[\s"]/.test(p) ? `"${p.replace(/"/g, '\\"')}"` : p).join(' ');
    }
    if (['start', 'stop', 'restart'].includes(operation)) return `docker ${operation} ${container}`;
    if (operation === 'delete') return `docker rm -f ${container}`;
    return null;
  }

  async function runDockerOp(sessionId, sess, operation, selectedServices, opId) {
    // ── Live log follow (always single-service) ──────────────────────────────
    if (operation === 'logs') {
      stopDockerLogsFollow(sess);
      const c = selectedServices[0]?.container;
      if (!c) { broadcast(sessionId, { type: 'docker_op_done', opId, success: false, error: 'No container' }); return; }
      const proc = spawn('docker', ['logs', '--tail', '200', '-f', c], { stdio: ['ignore', 'pipe', 'pipe'] });
      sess._dockerLogsProc = proc;
      const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');
      const mk = () => { let buf = ''; return d => {
        buf += d.toString(); const p = buf.split(/\r\n|\r|\n/); buf = p.pop();
        p.forEach(l => dockerLog(sessionId, opId, 'out', stripAnsi(l)));
      }; };
      proc.stdout.on('data', mk());
      proc.stderr.on('data', mk());
      proc.on('error', e => { dockerLog(sessionId, opId, 'err', `Could not read logs: ${e.message}`);
        broadcast(sessionId, { type: 'docker_op_done', opId, success: false, error: e.message }); });
      proc.on('exit', () => { if (sess._dockerLogsProc === proc) sess._dockerLogsProc = null;
        broadcast(sessionId, { type: 'docker_op_done', opId, success: true }); });
      return;
    }
    if (operation === 'logs-stop') {
      stopDockerLogsFollow(sess);
      broadcast(sessionId, { type: 'docker_op_done', opId, success: true });
      return;
    }

    if (operation === 'install') {
      try { await execQuiet('docker network create iready 2>/dev/null || true', { timeout: 8000 }); } catch (_) {}
    }

    const catalog = loadCatalog();
    let anyError = false;
    for (const svc of selectedServices) {
      const c = svc.container;
      try {
        const entry = catalog.find(e => e.name === svc.name);
        const cmd = runCmdFor(operation, entry, c);
        if (!cmd) throw new Error(`Unknown operation: ${operation}`);
        if (operation === 'install' && !entry) throw new Error(`"${svc.name}" is no longer in your catalog`);
        await streamDocker(sessionId, opId, cmd);
        dockerLog(sessionId, opId, 'ok', `✓ ${operation} ${svc.name}`);
      } catch (e) {
        dockerLog(sessionId, opId, 'err', `✗ ${operation} ${svc.name}: ${e.message}`);
        anyError = true;
      }
    }
    broadcast(sessionId, { type: 'docker_op_done', opId, success: !anyError });
  }
}

module.exports = { installDocker };