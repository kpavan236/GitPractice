/**
 * i-Ready OASIS — Server
 * Express + WebSocket backend
 *  - Proxies GitHub Enterprise API calls (avoids CORS from browser)
 *  - Runs per-repo setup scripts and streams logs via WebSocket
 *  - Stores session credentials in memory (never written to disk)
 */

'use strict';

// Addresses of the licence, support and rule servers come from config/services.json when the
// environment does not set them. Must run before anything below reads those variables.
const configured = require('./service-config').applyServiceConfig();
if (configured.length) console.log(`config: service addresses set from the services config files: ${configured.join(', ')}`);

const express    = require('express');
const http       = require('http');
const https      = require('https');
const path       = require('path');
const fs         = require('fs');
const os         = require('os');

const { appendOasisLog, isErrorReportingEnabled } = require('./oasis-log');
const { expandHome } = require('./expand-home');
const { spawnBash, shellStatus, detectBash } = require('./shell');
const { findScript, findScriptIn, commandLineFor, ALL_EXTENSIONS } = require('./scripts');
const { exec, spawn, execSync } = require('child_process');
const WebSocket  = require('ws');
const axios      = require('axios');
const cors       = require('cors');
const yaml       = require('js-yaml');
const { installLicensing } = require('./licensing');
const { createSupportClient } = require('./support-client');
const { createExternalCalls } = require('./external-calls');
const { installSecurity, stopSecurity } = require('./security');
const { installBranches } = require('./branches');
const { installJira, jiraSearchAll, JIRA_HTTPS_AGENT } = require('./jira');
const { installAppraisal } = require('./appraisal');
const { installPerfDiagnostics } = require('./perf');
const { installDocker } = require('./docker');
const { installVersionWatch } = require('./version-watch');
const { installAI } = require('./ai');
const { createAiClient, AiNotConfiguredError, AiAuthError } = require('./ai/client');
require('dotenv').config();

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

const PORT         = process.env.PORT || 3000;
// Paths can be overridden when packaged (Electron) — scripts live in a writable
// location so users can add their own <repo>.sh and keep them across updates.
const SCRIPTS_DIR  = process.env.OASIS_SCRIPTS_DIR || path.join(__dirname, '..', 'scripts');
const PUBLIC_DIR   = process.env.OASIS_PUBLIC_DIR  || path.join(__dirname, '..', 'public');
const CONFIG_PATH    = process.env.OASIS_CONFIG      || path.join(__dirname, '..', 'config', 'oasis.yml');
const PREFS_PATH     = path.join(os.homedir(), '.oasis-prefs.json');
const CACHE_TTL_MS = 5 * 60 * 1000; // 5-minute TTL for pull-status and badge caches

// Load the YAML config fresh each read so edits apply without a restart.
function loadConfig() {
  try { return yaml.load(fs.readFileSync(CONFIG_PATH, 'utf8')) || {}; }
  catch (e) { return {}; }
}

// Config for Bedrock calls, with the AWS profile resolved from (in priority):
// the user's Settings pick (sess.awsProfile) → config/oasis.yml (cfg.aws.profile)
// → ambient AWS_PROFILE env. Without this, Bedrock ignored the Settings profile
// and resolved creds against the default profile — so on a named-SSO-profile setup
// credentials never resolved and every call tried to re-login.
function cfgForBedrock(sess) {
  const cfg = loadConfig();
  const profile = (sess && sess.awsProfile)
    || cfg?.aws?.profile
    || process.env.AWS_PROFILE
    || process.env.AWS_DEFAULT_PROFILE
    || undefined;
  return { ...cfg, aws: { ...(cfg.aws || {}), profile } };
}

// Simple exec wrapper — used for git status checks and fire-and-forget IDE launch.
// Git ops run non-interactively: an HTTPS remote with no cached credential must
// fail fast, not block on a `Username for 'https://…':` terminal prompt (there's
// no tty here, so the prompt would just leak to stderr and hang until timeout).
function execQuiet(cmd, opts = {}) {
  return new Promise((resolve, reject) => {
    const env = {
      ...process.env,
      GIT_TERMINAL_PROMPT: '0',
      GIT_ASKPASS: 'echo',
      GCM_INTERACTIVE: 'never',
      ...(opts.env || {}),
    };
    exec(cmd, { timeout: 25000, ...opts, env }, (err, stdout) => {
      err ? reject(err) : resolve(stdout.trim());
    });
  });
}

// Distinctive PS4 prefix for `bash -x` so xtrace lines can be told apart from
// real stderr. bash replicates the first char of PS4 per nesting level, so a
// top-level command is "▶ cmd" and nested ones are "▶▶ cmd", etc.
const TRACE_PS4     = '▶ ';
const TRACE_RE      = /^▶+ /;   // any xtrace line
const TRACE_TOP_RE  = /^▶ /;    // top-level command only

// ── In-memory session store (keyed by sessionId) ──────────────────────────
const sessions = {};

// One switch for every call to GitHub and Jenkins (see external-calls.js). It starts
// OFF; login (the setup wizard's checks and the session connect) always works.
const externalCalls = createExternalCalls({
  prefsPath: PREFS_PATH,
  getHosts: () => Object.values(sessions)
    .flatMap(s => [s.githubUrl, s.jenkinsUrl])
    .filter(Boolean)
    .map(u => { try { return new URL(u).hostname; } catch (_) { return null; } })
    .filter(Boolean),
});
externalCalls.installAxiosGate(axios);

// Routes that exist to talk to GitHub or Jenkins. While the switch is off they answer
// a clear 503 before doing any work. (Anything missed here is still stopped by the
// HTTP gate and the git guards.) Not listed on purpose: /api/branches, which falls
// back to the branches already on disk, and the login routes.
const EXTERNAL_ROUTES = [
  /^\/api\/repos(\/|$)/, /^\/api\/generate-scripts$/, /^\/api\/pull-status$/, /^\/api\/repo-contributors$/,
  /^\/api\/repo-badges$/, /^\/api\/pull$/, /^\/api\/jenkins-discover$/, /^\/api\/launch-fuselage$/,
  /^\/api\/dependency-graph$/, /^\/api\/setup$/,
];

// ── Middleware ────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
// index: false — prevent express.static from auto-serving index.html for GET /
// so the catch-all route can inject the saved theme before first paint.
app.use(express.static(PUBLIC_DIR, { etag: false, lastModified: false, index: false, setHeaders: (res) => { res.setHeader('Cache-Control', 'no-store'); } }));

// ── Licensing ─────────────────────────────────────────────────────────────
// Mounts /api/license and puts the licence gate in front of every other /api
// route, so this must stay above the route definitions below. Static assets
// are already served above and are deliberately never gated — the lock screen
// is itself served from public/.
// Returns null (and gates nothing) when OASIS_LICENSE_DISABLED=1.
const licenseService = installLicensing(app, {
  appVersion: require('../package.json').version,
  // The trial starts when setup finishes, so the licence service is told which Jenkins,
  // GitHub and organisation the customer connected (addresses only, never a token).
  getTrialIntegration: (sessionId) => {
    const s = sessions[sessionId];
    return s ? { jenkinsUrl: s.jenkinsUrl, githubUrl: s.githubUrl, org: s.org } : null;
  },
});
app.use('/api', externalCalls.routeGate(EXTERNAL_ROUTES));

/**
 * GET  /api/external-calls — { enabled, source }  (source: settings | environment | default)
 * POST /api/external-calls — { enabled: true|false } saves the choice and takes effect at once.
 * Answers even when the app is locked, and is never itself switched off.
 */
app.get('/api/external-calls', (_req, res) => res.json(externalCalls.state()));
app.post('/api/external-calls', (req, res) => {
  const { enabled } = req.body || {};
  if (typeof enabled !== 'boolean') return res.status(400).json({ error: 'enabled must be true or false' });
  try {
    externalCalls.setEnabled(enabled);
    // Anything cached while the switch was in the other position is stale: results
    // gathered with the calls off are incomplete, and vice versa.
    for (const s of Object.values(sessions)) { delete s._branchCache; delete s._badgeCache; delete s._pullCache; }
    res.json(externalCalls.state());
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Version Watch ─────────────────────────────────────────────────────────
// Mounts /api/version-watch + /api/version-watch/scan and starts the 24h
// automatic background scan. Installed before Security so its
// loadVersionWatchRows can be wired into the SCA scanner below.
const { maybeAutoScanVersionWatch, loadVersionWatchRows } = installVersionWatch(app, { sessions, broadcast, broadcastAll, externalCalls });

// ── AI provider configuration ────────────────────────────────────────────
// Mounts /api/ai/providers + /api/ai/models (live model lists for Settings).
// Each session's own provider/model/key choice is stored on the session
// object itself by /api/session below — this just serves the provider
// catalog and proxies live model-list lookups.
installAI(app, { sessions, bedrockRuntimeFactory: makeBedrockRuntime });

// ── Security ──────────────────────────────────────────────────────────────
// Mounts /api/security. Scanners read local clones only — nothing here fetches
// or executes remote code, and the repository name is restricted to a single
// path segment so a crafted name cannot walk out of the clone directory.
const security = installSecurity(app, {
  appVersion: require('../package.json').version,
  // SCA reuses Version Watch's dependency scan rather than re-resolving every
  // manifest. null means "no scan has run yet", which the adapter reports as a
  // skip instead of as zero vulnerabilities.
  loadVersionWatchRows,
  // Every locally cloned repository, for the "all repositories" option and the
  // selection list.
  listRepositories: () => {
    const sess = Object.values(sessions).find(s => s && s.cloneDir);
    const base = expandHome(sess?.cloneDir || '~/dev/projects');
    try {
      return fs.readdirSync(base).filter(d => {
        return isProjectDir(base, d);
      }).sort();
    } catch (_) {
      return [];
    }
  },
  resolveRepoPath: (repo) => {
    // isPlainName, not the bare character class this used to use: that regex
    // ACCEPTS `..` — a dot is a legal filename character — so path.join climbed
    // out of the clone base. Reaching a directory that also had to contain a
    // .git made it hard to exploit, but "hard to exploit" is not the same as
    // "cannot", and the fix costs nothing.
    if (!isPlainName(repo)) return null;
    const sess = Object.values(sessions).find(s => s && s.cloneDir);
    const base = expandHome(sess?.cloneDir || '~/dev/projects');
    return isProjectDir(base, repo) ? path.join(base, repo) : null;
  },
});

// Whether a directory in the clone base is a PROJECT repository.
//
// `oasis-scripts` lives beside the repositories and is usually a git checkout
// itself — a team clones it to share setup scripts. That made it appear in
// every repository list as something to set up, scan and launch, which it is
// not: it is tooling, and scanning the scripts directory for vulnerabilities in
// the code it is supposed to be running is noise nobody asked for.
//
// Excluded by NAME rather than by inspecting its contents, because the name is
// the contract — it is the same constant the script resolver looks for.
function isProjectDir(base, name) {
  if (name === FALLBACK_SCRIPTS_DIRNAME) return false;
  try {
    return fs.statSync(path.join(base, name)).isDirectory()
      && fs.existsSync(path.join(base, name, '.git'));
  } catch (_) {
    return false;
  }
}

// ── WebSocket connections map: sessionId → [ws, ...] ─────────────────────
const wsClients = {};

// ── Pending-event buffer ───────────────────────────────────────────────────
// When broadcast() is called but no WebSocket client is connected for the
// session (e.g. during the 2-second auto-reconnect window), the event is
// queued here instead of being silently dropped. On the next connection for
// that session the queued events are replayed in order before the "connected"
// handshake, so the UI never misses a job_start and hangs at "Waiting".
// Log batches (type:'logs') are excluded — missing a few log lines while
// briefly disconnected is acceptable; missing job_start/step_done/job_done is not.
const _pendingBroadcasts = {};  // sessionId -> [payload, ...]
const PENDING_CAP = 200;        // max queued events per session (oldest dropped first)

wss.on('connection', (ws, req) => {
  const url    = new URL(req.url, `http://localhost`);
  const sid    = url.searchParams.get('session');
  if (!sid) { ws.close(); return; }
  if (!wsClients[sid]) wsClients[sid] = [];
  wsClients[sid].push(ws);

  ws.on('close', () => {
    wsClients[sid] = (wsClients[sid] || []).filter(c => c !== ws);
  });

  // Flush any events that were queued while the client was disconnected.
  // Send them before the 'connected' handshake so the UI receives job state
  // updates first and the "Waiting" card transitions correctly.
  const pending = _pendingBroadcasts[sid];
  if (pending && pending.length) {
    delete _pendingBroadcasts[sid];
    pending.forEach(p => ws.send(JSON.stringify(p)));
  }

  ws.send(JSON.stringify({ type: 'connected', session: sid }));
});

function _rawSend(sessionId, payload) {
  const clients = wsClients[sessionId] || [];
  const msg = JSON.stringify(payload);
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

// ── Log batching ────────────────────────────────────────────────────────────
// A setup/build emits thousands of lines. One WS frame per line floods the
// socket and the browser event loop, so the UI falls far behind the real
// process — it still shows "running" long after the script has finished. We
// coalesce log lines per session and flush them as a single framed batch a few
// times per second. Any non-log event (step/job/sudo/launch) flushes the
// pending log buffer first, so the relative ordering of logs and events is
// preserved.
const _logBuf   = {};   // sessionId -> [{ jobId, level, message, ts }]
const _logTimer = {};   // sessionId -> setTimeout handle
const LOG_FLUSH_MS  = 40;
const LOG_FLUSH_MAX = 500;   // also flush early once the buffer gets this big

function flushLogs(sessionId) {
  if (_logTimer[sessionId]) { clearTimeout(_logTimer[sessionId]); delete _logTimer[sessionId]; }
  const entries = _logBuf[sessionId];
  if (entries && entries.length) {
    delete _logBuf[sessionId];
    _rawSend(sessionId, { type: 'logs', entries });
  }
}

function enqueueLog(sessionId, entry) {
  (_logBuf[sessionId] ||= []).push(entry);
  if (_logBuf[sessionId].length >= LOG_FLUSH_MAX) { flushLogs(sessionId); return; }
  if (!_logTimer[sessionId]) {
    _logTimer[sessionId] = setTimeout(() => flushLogs(sessionId), LOG_FLUSH_MS);
  }
}

function broadcast(sessionId, payload) {
  flushLogs(sessionId);   // preserve ordering: emit buffered logs before this event

  const openClients = (wsClients[sessionId] || []).filter(ws => ws.readyState === WebSocket.OPEN);
  if (openClients.length > 0) {
    const msg = JSON.stringify(payload);
    openClients.forEach(ws => ws.send(msg));
  } else if (payload.type !== 'logs') {
    // No client connected — queue non-log events so they are replayed on reconnect.
    const q = (_pendingBroadcasts[sessionId] ||= []);
    q.push(payload);
    if (q.length > PENDING_CAP) q.splice(0, q.length - PENDING_CAP); // drop oldest
  }
}

// ── ROUTES ────────────────────────────────────────────────────────────────

/** Health check */
app.get('/api/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));

/** Returns the local Mac username — used to personalise the Jenkins token page link. */
app.get('/api/whoami', (_req, res) => res.json({ username: process.env.USER || '' }));

/**
 * GET /api/aws-profiles
 * Lists the AWS CLI profiles configured on this machine so the user can pick
 * the one whose credentials the launched apps should use. Best-effort: returns
 * an empty list (not an error) when the AWS CLI is missing or unconfigured.
 */
app.get('/api/aws-profiles', async (_req, res) => {
  try {
    const out = await execQuiet('aws configure list-profiles 2>/dev/null');
    const profiles = String(out || '').split('\n').map(s => s.trim()).filter(Boolean);
    res.json({ profiles });
  } catch (_e) {
    res.json({ profiles: [] });
  }
});

/**
 * POST /api/launch-fuselage
 * Triggers the "Launch Fuselage" Jenkins job.
 * Fetches a fresh crumb first (anti-CSRF), then POSTs to the build endpoint.
 */
app.post('/api/launch-fuselage', async (req, res) => {
  const { session, launch = true, doDelete = false } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser  || sess.githubLogin || '';
  if (!jToken) return res.status(400).json({ error: 'Jenkins API token not configured — add it in Settings.' });

  const auth = { username: jUser, password: jToken };

  try {
    // 1. Fetch a fresh crumb
    const crumbResp = await axios.get(`${jUrl}/crumbIssuer/api/json`, { auth, timeout: 8000 });
    const crumbField = crumbResp.data.crumbRequestField;
    const crumb      = crumbResp.data.crumb;

    // 2. Trigger the build
    const params = new URLSearchParams();
    params.append('json', JSON.stringify({
      parameter: [{ name: 'LAUNCH', value: !!launch }, { name: 'DELETE', value: !!doDelete }],
      statusCode: '303', redirectTo: '.',
    }));

    await axios.post(
      `${jUrl}/job/utility/job/Launch%20Fuselage/build?delay=0sec`,
      params.toString(),
      {
        auth,
        headers: { [crumbField]: crumb, 'Content-Type': 'application/x-www-form-urlencoded' },
        maxRedirects: 0,
        validateStatus: s => s < 400,
        timeout: 15000,
      }
    );

    res.json({ ok: true });
  } catch (e) {
    const status = e.response?.status;
    const msg = status === 401 || status === 403
      ? 'Jenkins auth failed — check your API token in Settings'
      : e.message?.slice(0, 200);
    res.status(500).json({ error: msg });
  }
});

/**
 * POST /api/validate-github
 * Body: { githubUrl, token }
 * Validates a GitHub PAT only — does NOT create a session.
 */
app.post('/api/validate-github', async (req, res) => {
  const { githubUrl, token } = req.body;
  if (!githubUrl || !token) return res.json({ ok: false, error: 'githubUrl and token are required' });
  const apiBase = githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const userResp = await axios.get(`${apiBase}/user`, {
      oasisLogin: true,
      headers: {
        Authorization: `token ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      timeout: 12000,
    });
    res.json({ ok: true, githubLogin: userResp.data?.login || '' });
  } catch (err) {
    const status = err.response?.status;
    const ghMsg  = err.response?.data?.message || '';
    if (status === 401) return res.json({ ok: false, error: `Invalid token — ${ghMsg || 'bad credentials'}. Re-generate your PAT and try again.` });
    if (status === 403) return res.json({ ok: false, error: `Token lacks required permissions — ${ghMsg || 'check the repo scope'}. Re-generate your PAT with repo access.` });
    if (status === 404) return res.json({ ok: false, error: `GitHub API not reachable at ${apiBase} — check the GitHub Enterprise URL.` });
    res.json({ ok: false, error: `Could not reach GitHub (${err.code || status || err.message})` });
  }
});

/**
 * POST /api/validate-jenkins
 * Body: { token, user }
 * Validates a Jenkins API token by hitting the Jenkins user profile API.
 * Does NOT require an existing session — used during wizard before session exists.
 */
app.post('/api/validate-jenkins', async (req, res) => {
  const { jenkinsUrl, token, user } = req.body;
  if (!jenkinsUrl || !token || !user) return res.json({ ok: false, error: 'Jenkins URL, token and username required' });
  const jUrl = jenkinsUrl.replace(/\/$/, '');
  try {
    await axios.get(`${jUrl}/me/api/json`, {
      oasisLogin: true,
      auth: { username: user, password: token },
      timeout: 8000,
    });
    res.json({ ok: true });
  } catch (e) {
    const status = e.response?.status;
    const msg = status === 401 || status === 403
      ? 'Invalid token or username'
      : `Could not reach Jenkins (${status || e.code || e.message})`;
    res.json({ ok: false, error: msg });
  }
});

/** GET /api/jenkins-discover?session=SID — finds the Jenkins job structure */
app.get('/api/jenkins-discover', async (req, res) => {
  const { session } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser || sess.githubLogin || '';
  if (!jToken) return res.json({ error: 'No Jenkins token' });

  const auth = { username: jUser, password: jToken };
  try {
    const root = await axios.get(`${jUrl}/api/json?depth=2`, { auth, timeout: 12000 });
    const jobs = root.data?.jobs || [];
    res.json({ jobs: jobs.map(j => ({ name: j.name, type: j._class, url: j.url, jobs: (j.jobs||[]).map(jj => ({ name: jj.name, type: jj._class })) })) });
  } catch (e) {
    res.json({ error: e.message, status: e.response?.status });
  }
});

/**
 * GET /api/prefs — read persisted user preferences (no session required)
 * POST /api/prefs — merge-write preferences to ~/.oasis-prefs.json
 */
app.get('/api/prefs', (req, res) => {
  try {
    if (!fs.existsSync(PREFS_PATH)) return res.json({});
    const prefs = JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {};
    res.json(prefs);
  } catch (e) { res.json({}); }
});

app.post('/api/prefs', (req, res) => {
  try {
    const current = fs.existsSync(PREFS_PATH)
      ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {})
      : {};
    const merged = { ...current, ...req.body };
    delete merged.token;
    if (merged.cfg) delete merged.cfg.token;
    fs.writeFileSync(PREFS_PATH, JSON.stringify(merged, null, 2), 'utf8');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/**
 * POST /api/session
 * Body: { githubUrl, org, token, cloneDir, intellijPath, mavenArgs, extraEnv }
 * Creates a session, returns sessionId
 */
app.post('/api/session', async (req, res) => {
  const { githubUrl, org, token, intellijPath, mavenArgs, extraEnv,
          awsProfile, jenkinsUrl, jenkinsUser, jenkinsToken, jenkinsPattern,
          aiEnabled, aiProvider, aiModel, aiApiKey, aiHost } = req.body;
  const cloneDir = req.body.cloneDir;
  if (!githubUrl || !org || !token || !cloneDir) {
    return res.status(400).json({ error: 'githubUrl, org, token and cloneDir are required' });
  }
  if (!jenkinsUrl) {
    return res.status(400).json({ error: 'Jenkins Base URL is required.' });
  }

  // Validate credentials and capture the GitHub login (used as Jenkins username).
  const apiBase = githubUrl.replace(/\/$/, '') + '/api/v3';
  let githubLogin = '';
  try {
    const userResp = await axios.get(`${apiBase}/user`, {
      oasisLogin: true,
      headers: {
        Authorization: `token ${token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      timeout: 12000,
    });
    githubLogin = userResp.data?.login || '';
  } catch (err) {
    const status = err.response?.status;
    const ghMsg  = err.response?.data?.message || '';
    if (status === 401) {
      return res.status(401).json({ error: `Invalid token — ${ghMsg || 'bad credentials'}. Re-generate your PAT and try again.` });
    }
    if (status === 403) {
      return res.status(403).json({ error: `Token lacks required permissions — ${ghMsg || 'check the repo scope'}. Re-generate your PAT with repo access.` });
    }
    if (status === 404) {
      return res.status(404).json({ error: `GitHub API not reachable at ${apiBase} — check the GitHub Enterprise URL.` });
    }
    return res.status(503).json({ error: `GitHub not reachable (${err.code || status || err.message}). Check your network and GitHub Enterprise URL.` });
  }

  // Jenkins token is mandatory — validate it before creating the session
  if (!jenkinsToken) {
    return res.status(400).json({ error: 'Jenkins API token is required.' });
  }
  const jValidUrl = jenkinsUrl.replace(/\/$/, '');
  try {
    await axios.get(`${jValidUrl}/me/api/json`, {
      oasisLogin: true,
      auth: { username: githubLogin, password: jenkinsToken },
      timeout: 8000,
    });
  } catch (e) {
    const jStatus = e.response?.status;
    const jMsg = jStatus === 401 || jStatus === 403
      ? 'Invalid Jenkins token — re-generate it from your Jenkins security page.'
      : `Could not reach Jenkins (${jStatus || e.code || e.message})`;
    return res.status(401).json({ error: jMsg });
  }

  const sid = `sess_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  sessions[sid] = { githubUrl, org, token, cloneDir, intellijPath, mavenArgs, extraEnv,
    awsProfile:   (awsProfile   || '').trim(),
    aiEnabled:    aiEnabled !== false,
    aiProvider:   (aiProvider || '').trim(),
    aiModel:      (aiModel    || '').trim(),
    aiApiKey:     (aiApiKey   || '').trim(),
    aiHost:       (aiHost     || '').trim(),
    githubLogin,
    jenkinsUrl,
    jenkinsUser: githubLogin,   // same as CA GitHub login
    jenkinsToken,
    // Per-session FIFO used to hand a Mac password to an already-running setup
    // script that asked for sudo mid-run (see /api/sudo-password + buildEnv).
    _sudoFifo: `/tmp/.oasis-sudo-${sid}.fifo`,
    jobs: {}, sudoPassword: null };
  // Fire-and-forget: check whether Version Watch's data is stale (24h+) and,
  // if so, kick off a scan in the background — doesn't block the response.
  maybeAutoScanVersionWatch();
  res.json({ sessionId: sid, githubLogin });
});

/**
 * POST /api/sudo-password
 * Body: { session, password }
 * Validates the Mac login password via `sudo -S -v` and stores it in the
 * session (memory only, never written to disk). Passed to every setup script
 * as OASIS_SUDO_PW so dl_prime_sudo never needs to pop a dialog.
 */
app.post('/api/sudo-password', async (req, res) => {
  const { session, password } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!password) return res.status(400).json({ error: 'password is required' });

  const valid = await validateSudoPassword(password);
  if (!valid) return res.json({ ok: false, error: 'Incorrect password — try again' });

  sess.sudoPassword = password;
  // Hand the (validated) password to any script that is currently blocked
  // waiting for it, so the in-flight setup resumes without a restart.
  deliverSudoPassword(sess, password);
  res.json({ ok: true });
});

// Feedback and Contact Support go to oasis-support-service (OASIS_SUPPORT_URL), which the support
// portal reads. If it cannot be reached the words are kept in ~/oasis and the person is told so.
const supportClient = createSupportClient({
  appVersion: require('../package.json').version,
  machineId: require('./licensing/fingerprint').machineFingerprint().id,
  saveLocally: appendOasisLog,
});
const supportWho = session => sessions[session]?.githubLogin || sessions[session]?.jiraEmail || 'unknown';

// Sent back as the service's answer: 200 with a reference, 202 when it was only saved on this computer,
// 400 with the field errors when the service refused it, 503 when it could not be kept anywhere.
function sendSupportOutcome(res, out) {
  if (out.ok && out.savedLocally) return res.status(202).json({ ok: true, savedLocally: true });
  if (out.ok) return res.json({ ok: true, reference: out.reference });
  if (out.rejected) return res.status(400).json({ error: out.message, errors: out.errors });
  return res.status(503).json({ error: out.message });
}

// Only what the two forms prefill: an address and a name. Never a token.
app.get('/api/support/prefill', (req, res) => {
  const sess = sessions[req.query.session] || {};
  res.json({ email: sess.jiraEmail || '', name: sess.githubLogin || '' });
});

app.post('/api/feedback', async (req, res) => {
  const { session, message, category, email, idempotencyKey } = req.body;
  if (!String(message || '').trim()) return res.status(400).json({ error: 'message is required' });
  sendSupportOutcome(res, await supportClient.sendFeedback({ category, message, email, idempotencyKey, who: supportWho(session) }));
});

app.post('/api/support', async (req, res) => {
  const { session, title, description, contactName, email, idempotencyKey } = req.body;
  if (!String(title || '').trim() || !String(description || '').trim()) return res.status(400).json({ error: 'title and description are required' });
  sendSupportOutcome(res, await supportClient.sendSupportRequest({ subject: title, message: description, contactName, email, idempotencyKey, who: supportWho(session) }));
});

// Opt-in (Settings → Diagnostics, off by default) — a renderer-side error
// handler posts here. Silently a no-op (not an error) when reporting is off,
// so a leftover handler on an old page load can never write anything for
// someone who has since opted out, or never opted in at all.
app.post('/api/error-report', (req, res) => {
  if (!isErrorReportingEnabled()) return res.json({ ok: true, skipped: true });

  const { source, message, stack, url, line, col } = req.body || {};
  const where = url ? `${url}:${line || '?'}:${col || '?'}` : '';
  const text = `[${new Date().toISOString()}] ${source || 'renderer'}\n${message || ''}\n${stack || ''}${where ? '\n' + where : ''}\n---\n`;
  try {
    appendOasisLog('error.txt', text);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Write the password into the session FIFO so a setup script blocked in
// _dl_wait_password_from_ui picks it up immediately. Opened O_RDWR so the write
// never blocks the event loop when no reader is attached yet (it just buffers in
// the pipe for the next reader). The secret never touches a regular file.
function deliverSudoPassword(sess, password) {
  const fifo = sess._sudoFifo;
  if (!fifo) return;
  try {
    if (!fs.existsSync(fifo)) {
      try { execSync(`mkfifo -m 600 "${fifo}"`); } catch (_) { /* script may create it */ }
    }
    const fd = fs.openSync(fifo, fs.constants.O_RDWR);
    try { fs.writeSync(fd, password + '\n'); } finally { fs.closeSync(fd); }
  } catch (e) {
    console.warn('Could not deliver sudo password to running script:', e.message);
  }
}

/**
 * GET /api/sudo-status?session=SID
 * Returns whether the session has a stored password and whether sudo is
 * currently valid (timestamp still warm).
 */
app.get('/api/sudo-status', async (req, res) => {
  const sess = sessions[req.query.session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const hasPassword = !!sess.sudoPassword;
  // Check whether the sudo timestamp is still live without using the password.
  const timestampValid = await new Promise(resolve => {
    const p = spawn('sudo', ['-n', '-v'], { stdio: 'ignore' });
    p.on('close', code => resolve(code === 0));
  });
  res.json({ hasPassword, timestampValid });
});

// Returns the user's full interactive login environment (Homebrew, nvm, etc.
// all on PATH) by sourcing ~/.zshrc in a login shell. Cached after first call.
let _loginEnv = null;
async function getLoginEnv() {
  if (_loginEnv) return _loginEnv;

  // Sourcing a login shell is POSIX by definition — there is no `bash -lc` to
  // ask on Windows, and the hardcoded PATH below names directories that do not
  // exist there. Returning the process environment unchanged is the honest
  // answer rather than spawning something guaranteed to fail.
  if (process.platform === 'win32') {
    _loginEnv = { ...process.env };
    return _loginEnv;
  }

  try {
    const raw = await execQuiet(
      'bash -lc "env"',
      {
        timeout: 10000,
        // A deliberately minimal PATH: the point is to discover what the user's
        // login shell adds, so seeding it with our own inherited PATH would
        // make the answer circular. os.homedir() rather than process.env.HOME,
        // which is not always set even on macOS when launched from the GUI.
        env: { ...process.env, HOME: os.homedir(), PATH: '/bin:/usr/bin:/usr/local/bin:/opt/homebrew/bin' },
      }
    );
    const env = {};
    raw.split('\n').forEach(line => {
      const idx = line.indexOf('=');
      if (idx > 0) env[line.slice(0, idx)] = line.slice(idx + 1);
    });
    _loginEnv = env;
  } catch {
    _loginEnv = { ...process.env };
  }
  return _loginEnv;
}

function validateSudoPassword(pw) {
  return new Promise(resolve => {
    const proc = spawn('sudo', ['-S', '-p', '', '-v'], {
      stdio: ['pipe', 'ignore', 'pipe'],
    });
    proc.stdin.write(pw + '\n');
    proc.stdin.end();
    proc.on('close', code => resolve(code === 0));
  });
}

/**
 * GET /api/repos?session=SID&page=1&per_page=100
 * Fetches org repos from GitHub Enterprise via server (avoids browser CORS)
 */
app.get('/api/repos', async (req, res) => {
  const { session, page = 1, per_page = 100 } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0'
      },
      params: { page, per_page, type: 'all', sort: 'updated', direction: 'desc' }
    });

    // Enrich: resolve which local setup script each repo would run
    const repos = resp.data.map(enrichRepo);

    // Pagination info from Link header
    const link    = resp.headers['link'] || '';
    const hasNext = link.includes('rel="next"');
    // Parse the last-page number from the Link header so the UI can show X/total.
    const lastMatch = link.match(/[?&]page=(\d+)[^>]*>;\s*rel="last"/);
    const lastPage  = lastMatch ? Number(lastMatch[1]) : Number(page);
    const estimatedTotal = hasNext ? lastPage * Number(per_page) : (Number(page) - 1) * Number(per_page) + repos.length;
    res.json({ repos, hasNext, page: Number(page), estimatedTotal });
  } catch (err) {
    const status = err.response?.status || 500;
    const msg    = err.response?.data?.message || err.message;
    res.status(status).json({ error: msg });
  }
});

/**
 * GET /api/repos/count?session=SID
 * Returns the exact total number of repos in the org via the search API.
 * Called once on startup so the UI can show "100 / 308" from the first page.
 */
app.get('/api/repos/count', async (req, res) => {
  const sess = sessions[req.query.session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/search/repositories`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      params: { q: `org:${sess.org}`, per_page: 1 },
      timeout: 8000,
    });
    res.json({ total: resp.data.total_count });
  } catch (err) {
    res.status(err.response?.status || 500).json({ error: err.message });
  }
});

/**
 * GET /api/repos/search?session=SID&q=QUERY
 * Searches ALL repos in the org via GitHub's search API (not just loaded pages).
 * Returns up to 30 matches enriched with the same script-resolution fields.
 */
app.get('/api/repos/search', async (req, res) => {
  const { session, q } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!q || !q.trim()) return res.json({ repos: [] });

  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  try {
    const resp = await axios.get(`${apiBase}/search/repositories`, {
      headers: {
        Authorization: `token ${sess.token}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'iready-oasis/1.0',
      },
      params: { q: `${q.trim()}+org:${sess.org}`, per_page: 30, sort: 'updated' },
      timeout: 10000,
    });
    const repos = (resp.data.items || []).map(enrichRepo);
    res.json({ repos, total: resp.data.total_count });
  } catch (err) {
    const status = err.response?.status || 500;
    const msg    = err.response?.data?.message || err.message;
    res.status(status).json({ error: msg });
  }
});

/**
 * POST /api/generate-scripts
 * Body: { session }
 * For every repo in the org that has no dedicated <repo-name>.sh:
 *   1. Fetches the README from GitHub.
 *   2. Asks Claude (Bedrock) whether the README describes setup steps beyond a
 *      standard Maven/npm build. If yes, Claude returns a complete bash script.
 *   3. Writes the script to scripts/<repo-name>.sh (skips repos that already
 *      have one, and repos where Claude says the default setup.sh is enough).
 * Progress is broadcast over WebSocket as script_gen_* events.
 */
app.post('/api/generate-scripts', async (req, res) => {
  const { session } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const ai = aiClientFor(sess);
  if (!ai.available()) {
    return res.status(400).json({ error: 'AI not configured — add a provider and model in Settings.' });
  }

  res.json({ ok: true });
  generateScriptsForOrg(session, sess).catch(e =>
    broadcast(session, { type: 'script_gen_error', message: e.message })
  );
});

async function generateScriptsForOrg(sessionId, sess) {
  const apiBase = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  const ghHeaders = {
    Authorization: `token ${sess.token}`,
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'iready-oasis/1.0',
  };

  // Collect all repos (paginated)
  broadcast(sessionId, { type: 'script_gen_start', message: 'Fetching repository list…' });
  let allRepos = [], page = 1;
  while (true) {
    const r = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
      headers: ghHeaders,
      params: { page, per_page: 100, type: 'all', sort: 'updated' },
    });
    allRepos = allRepos.concat(r.data);
    if (!r.headers['link']?.includes('rel="next"')) break;
    page++;
  }

  // Only process repos that don't already have a dedicated script
  const candidates = allRepos.filter(r => {
    const scriptPath = path.join(SCRIPTS_DIR, `${r.name}.sh`);
    const folderPath = path.join(SCRIPTS_DIR, r.name, 'setup.sh');
    return !fs.existsSync(scriptPath) && !fs.existsSync(folderPath);
  });

  broadcast(sessionId, {
    type: 'script_gen_progress',
    message: `${allRepos.length} repos found — ${candidates.length} need evaluation (${allRepos.length - candidates.length} already have scripts)`,
    total: candidates.length, done: 0,
  });

  const SCRIPT_TEMPLATE = fs.readFileSync(path.join(SCRIPTS_DIR, 'setup.sh'), 'utf8');

  const results = { generated: [], skipped: [], failed: [] };

  for (let i = 0; i < candidates.length; i++) {
    const repo = candidates[i];
    broadcast(sessionId, {
      type: 'script_gen_progress',
      message: `Analyzing ${repo.name} (${i + 1}/${candidates.length})…`,
      total: candidates.length, done: i,
    });

    try {
      // Fetch README — GitHub returns base64-encoded content
      let readme = '';
      try {
        const rmResp = await axios.get(`${apiBase}/repos/${sess.org}/${repo.name}/readme`, {
          headers: { ...ghHeaders, Accept: 'application/vnd.github.raw' },
          timeout: 10000,
        });
        readme = typeof rmResp.data === 'string' ? rmResp.data : '';
      } catch (e) {
        if (e.response?.status === 404) {
          results.skipped.push({ name: repo.name, reason: 'no README' });
          continue;
        }
        throw e;
      }

      // Trim README to fit in context (keep first ~4 000 chars where setup docs live)
      const readmeTrimmed = readme.slice(0, 4000);

      const script = await generateScriptFromReadme(repo.name, repo.language || 'unknown', readmeTrimmed, sess);

      if (!script) {
        results.skipped.push({ name: repo.name, reason: 'no special setup steps' });
        continue;
      }

      const scriptPath = path.join(SCRIPTS_DIR, `${repo.name}.sh`);
      fs.writeFileSync(scriptPath, script, { mode: 0o755 });
      results.generated.push(repo.name);
      broadcast(sessionId, { type: 'script_gen_created', repo: repo.name, path: scriptPath });

    } catch (e) {
      results.failed.push({ name: repo.name, error: e.message });
      broadcast(sessionId, { type: 'script_gen_failed', repo: repo.name, error: e.message });
    }

    // Brief pause to avoid hammering Bedrock rate limits
    await new Promise(r => setTimeout(r, 300));
  }

  broadcast(sessionId, {
    type: 'script_gen_done',
    generated: results.generated,
    skipped: results.skipped.length,
    failed: results.failed.length,
    message: `Done — ${results.generated.length} scripts created, ${results.skipped.length} repos use default setup, ${results.failed.length} failed.`,
  });
}

const SCRIPT_GEN_SYSTEM = `You are a DevOps engineer creating non-interactive bash setup scripts for "i-Ready OASIS", an internal Curriculum Associates developer tool for macOS. The tool clones repos and runs bash setup scripts non-interactively (no stdin, no tty).

Given a repository name, language, and README, decide whether the repo needs a CUSTOM setup script beyond what the default setup already handles (Maven clean install / npm install / standard build).

Output SKIP if the README only shows: standard Maven/npm/gradle build, standard git clone, or has no dev-setup section. The default script handles those automatically.

Output a complete bash script ONLY if the README describes steps that are NOT in the default flow, such as:
- Specific environment variables required before building
- Database setup, seeding or migrations
- Docker Compose or extra local services to start
- Custom .env / config file population beyond .env.example
- AWS credential setup, localstack, or non-standard ports
- Steps unique to THIS repo not covered by a generic build

SCRIPT RULES (must follow exactly):
- First line: #!/usr/bin/env bash
- set -euo pipefail
- CLONE_DIR="\${1:?Usage: <repo>.sh <clone_dir>}"
- SCRIPT_DIR=$( cd -- "$( dirname -- "\${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
- cd "$CLONE_DIR"
- Source the common lib: source "$SCRIPT_DIR/lib/oasis-common.sh"
- Call dl_prime_sudo before any sudo operations
- Never use interactive prompts (read, sudo -p with a tty, etc.)
- Use \${ENV_VAR:-default} for optional vars
- For Java/Maven builds, end with: mvn clean install \${MAVEN_ARGS:--DskipTests -Dplugin.prettier.goal=skip}
- For Node, end with: npm install (or yarn/pnpm if lock file present)
- Keep script under 80 lines; only include the EXTRA steps from the README
- No markdown, no code fences, no explanation — raw bash only`;

// ── Shared Bedrock helper — used by chat, suggest, scheduled tasks, script gen ──
function broadcastAll(payload) {
  const msg = JSON.stringify(payload);
  wss.clients.forEach(ws => { if (ws.readyState === WebSocket.OPEN) try { ws.send(msg); } catch (_) {} });
}

let _toastWin = null;

// A small corner toast shown WITHOUT focusing or raising the main app, so a job
// result is visible even when OASIS is minimized or behind another window —
// and it's never suppressed by Do Not Disturb / Focus (it's our own window, not an
// OS notification). Critically we do NOT call setVisibleOnAllWorkspaces here: that
// call is what previously hid the main window on macOS. `focusable:false` +
// showInactive() guarantee the toast never steals focus or opens the app.
function showToastWindow(title, body) {
  const { BrowserWindow, screen } = require('electron');
  if (!screen || !BrowserWindow) return;
  if (_toastWin && !_toastWin.isDestroyed()) { try { _toastWin.destroy(); } catch (_) {} }
  _toastWin = null;

  const W = 380, MARGIN = 20;
  const area = screen.getPrimaryDisplay().workArea;
  const x = area.x + area.width - W - MARGIN;
  const MAX_H = Math.round(area.height * 0.6);   // cap very long messages

  // On macOS, clicking ANY window of an app activates the whole app and raises all
  // its visible windows, even with focusable:false (same limitation the wellness
  // popup below already works around). Hide the main window first so there's
  // nothing for macOS to raise; electron/main.js's 'activate' handler skips
  // restoring it while _schedPopupActive is set, same pattern as _wellnessPopupActive.
  const mainWinForSched = BrowserWindow.getAllWindows().find(w => !w.isDestroyed() && w !== _toastWin && w !== _wellnessToastWin);
  if (process.platform === 'darwin' && mainWinForSched && mainWinForSched.isVisible() && !mainWinForSched.isMinimized() && !mainWinForSched.isFocused()) {
    mainWinForSched.hide();
  }
  global._schedPopupActive = true;

  // Colors are needed before window creation so the window backgroundColor matches
  // the card (we use a SOLID, non-transparent window: transparent windows are
  // unreliable in packaged/hardened macOS apps and were invisible there).
  const warn = /⚠️|fail/i.test(title);
  const esc  = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const base = warn ? '#3b1018' : '#1e1b4b';   // solid window bg = gradient's start color
  const grad = warn ? 'linear-gradient(135deg,#3b1018 0%,#7f1d1d 100%)'
                    : 'linear-gradient(135deg,#1e1b4b 0%,#312e81 100%)';
  const bord = warn ? '#ef4444' : '#6366f1';
  const lab  = warn ? '#fca5a5' : '#a5b4fc';
  const msg  = warn ? '#fee2e2' : '#e0e7ff';

  const tw = new BrowserWindow({
    width: W, height: 120, x, y: area.y + area.height - 120 - MARGIN,
    frame: false, backgroundColor: base, resizable: false, movable: false,
    minimizable: false, maximizable: false, skipTaskbar: true,
    focusable: false, show: false, hasShadow: true, alwaysOnTop: true,
    roundedCorners: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  });
  _toastWin = tw;
  tw.setAlwaysOnTop(true, 'screen-saver');   // above other windows; NOT all-workspaces
  // Clear the popup flag on close; do NOT proactively re-show the main window here
  // (that reintroduces the bug) — it only comes back via an explicit dock-icon
  // click, handled by electron/main.js's 'activate' handler.
  tw.once('closed', () => { if (_toastWin === tw) _toastWin = null; global._schedPopupActive = false; });

  // Look mirrors the in-app funny-comment banner (.funny-comment-banner / .fcb-* in
  // public/css/app.css): indigo gradient, uppercase label, slide-in (red variant for
  // warnings). The card fills the solid window edge-to-edge (no CSS radius — the
  // native macOS window provides rounded corners), and the window is resized to the
  // content height so the full message is always visible.
  const html = `<!doctype html><meta charset="utf-8"><style>
    html,body{margin:0;background:${base};overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;}
    .b{box-sizing:border-box;width:${W}px;position:relative;display:flex;align-items:flex-start;gap:12px;
       padding:16px 30px 16px 18px;background:${grad};border:1px solid ${bord};
       animation:slide .35s cubic-bezier(.16,1,.3,1);}
    @keyframes slide{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
    .ic{font-size:26px;line-height:1;flex-shrink:0;margin-top:2px}
    .c{flex:1;min-width:0}
    .r{font-size:11px;color:${lab};font-weight:600;text-transform:uppercase;letter-spacing:.06em;
       margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .m{font-size:14px;color:${msg};line-height:1.5;word-break:break-word;white-space:pre-wrap}
    .x{position:absolute;top:8px;right:8px;width:20px;height:20px;border:none;background:transparent;
       color:${lab};font-size:15px;line-height:1;cursor:pointer;padding:0;opacity:.65;border-radius:4px}
    .x:hover{opacity:1;background:rgba(255,255,255,.12)}
  </style><div class="b"><button class="x" onclick="window.close()" title="Dismiss">✕</button>
    <div class="ic">${warn ? '⚠️' : '🎉'}</div>
    <div class="c"><div class="r">${esc(title)}</div><div class="m">${esc(body)}</div></div></div>`;

  let shown = false;
  const reveal = () => { if (_toastWin === tw && !tw.isDestroyed() && !shown) { shown = true; tw.showInactive(); } };
  // Measure the rendered card and resize the window to fit, keeping it bottom-anchored.
  tw.webContents.once('did-finish-load', async () => {
    try {
      const h = await tw.webContents.executeJavaScript('Math.ceil(document.querySelector(".b").getBoundingClientRect().height)');
      const newH = Math.max(70, Math.min(Math.round(h), MAX_H));
      tw.setBounds({ x, y: area.y + area.height - newH - MARGIN, width: W, height: newH });
    } catch (_) {}
    reveal();
  });
  setTimeout(reveal, 600);   // fallback if measurement is slow
  tw.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  setTimeout(() => { if (tw && !tw.isDestroyed()) { try { tw.destroy(); } catch (_) {} } if (_toastWin === tw) _toastWin = null; }, 8000);
}

// ── Wellness corner toast ──────────────────────────────────────────────────
// ── Wellness timer + popup window ─────────────────────────────────────────────
// Timer lives in the MAIN PROCESS so it fires even when the renderer is
// minimized or throttled by Chromium.  When OASIS is the focused window it
// calls the renderer to show the in-app overlay; otherwise it creates a corner
// BrowserWindow popup that floats above every other app.

let _wellnessToastWin = null;

// Authoritative wellness state — owned by the main process
const _ws = {
  timer:        null,
  enabled:      false,
  screenMs:     0,       // cumulative screen-on time (used for eye / stretch)
  lastWaterMs:  0,       // screenMs checkpoint for water (active screen time)
  lastEyeMs:    0,       // screenMs checkpoint for eye break
  lastDeepMs:   0,       // screenMs checkpoint for body stretch (90 min)
  lastTickAt:   null,
  glasses:      1,
  screenLocked: false,   // true while screen is locked (powerMonitor lock-screen event)
  wasIdle:      false,   // idle state from the previous tick (for transition detection)
};

// ── Production timings ───────────────────────────────────────────────────────
// All notification types use screen-on time and require the machine to be active (not idle/locked).
const W_IDLE_THRESHOLD_S = 180;         // >180 s of no input = idle; suppress all notifications
const W_WATER_MS  = 45 * 60 * 1000;     // every 45 min  screen time
const W_EYE_MS    = 60 * 60 * 1000;     // every 60 min  screen time
const W_DEEP_MS   = 90 * 60 * 1000;     // every 90 min  screen time
const W_SNOOZE_MS = 10 * 60 * 1000;     // 10 min snooze
const W_TICK_MS   = 60 * 1000;          //  1 min tick
const W_MAX_GLASS = 3;

// ── TEST timings — uncomment to test quickly ─────────────────────────────────
// const W_WATER_MS  = 30 * 1000;
// const W_EYE_MS    = 40 * 1000;
// const W_DEEP_MS   = 90 * 1000;
// const W_SNOOZE_MS = 15 * 1000;
// const W_TICK_MS   =  5 * 1000;

function wellnessTick() {
  const now = Date.now();

  // Detect idle/locked — used to gate eye & stretch notifications
  let isIdle = _ws.screenLocked;
  if (!isIdle) {
    try {
      const { powerMonitor } = require('electron');
      isIdle = powerMonitor.getSystemIdleTime() >= W_IDLE_THRESHOLD_S;
    } catch (_) {}
  }

  // When returning from idle, reset eye/stretch checkpoints — the user just had a break,
  // so they get a fresh window before the next notification.
  if (_ws.wasIdle && !isIdle) {
    _ws.lastWaterMs = _ws.screenMs;
    _ws.lastEyeMs   = _ws.screenMs;
    _ws.lastDeepMs  = _ws.screenMs;
  }
  _ws.wasIdle = isIdle;

  // Only advance screen-on time when the user is actually at the machine
  if (!isIdle) {
    // Cap elapsed so long gaps (sleep/suspend) don't inflate screen time
    _ws.screenMs += Math.min(now - (_ws.lastTickAt || now), W_TICK_MS * 2);
  }
  _ws.lastTickAt = now;
  // Priority: body stretch > eye > water
  // (only one notification per tick; others fire on subsequent ticks)
  let type = null;
  if (_ws.screenMs - _ws.lastDeepMs >= W_DEEP_MS) {
    type = 'stretch-deep';
  } else if (_ws.screenMs - _ws.lastEyeMs >= W_EYE_MS) {
    type = 'eye';
  } else if (_ws.screenMs - _ws.lastWaterMs >= W_WATER_MS) {
    type = 'water';
  }
  if (!type) return;

  // Suppress all notifications when idle or locked
  if (isIdle) return;

  try {
    const { BrowserWindow } = require('electron');
    const main = BrowserWindow.getAllWindows().find(w => !w.isDestroyed() && w !== _wellnessToastWin && w !== _toastWin);
    if (main && main.isFocused() && !main.isMinimized()) {
      const d = JSON.stringify({ type, count: _ws.glasses });
      main.webContents.executeJavaScript('typeof wellnessShowFromServer==="function"&&wellnessShowFromServer(' + d + ')').catch(() => {});
    } else {
      showWellnessToast(type, _ws.glasses);
    }
    // Mark this reminder as delivered so the tick loop doesn't re-fire it every
    // few seconds while the toast is still on screen — that re-fire is what made
    // the popup window destroy + recreate itself (looked like a "reload"). The
    // user's response in wellnessApplyResult refines the timing (snooze shortens it).
    markWellnessShown(type);
  } catch (e) { console.warn('[wellness/tick]', e.message); }
}

// Advance a reminder's checkpoint to "now" so it won't re-trigger until the next
// full interval (or until the user responds). Called the moment a toast is shown.
function markWellnessShown(type) {
  if (type === 'water')             _ws.lastWaterMs = _ws.screenMs;
  else if (type === 'eye')          _ws.lastEyeMs   = _ws.screenMs;
  else if (type === 'stretch-deep') _ws.lastDeepMs  = _ws.screenMs;
}

function wellnessApplyResult(type, clicked, total, snooze) {
  const now = Date.now();
  if (type === 'water') {
    if (snooze) {
      _ws.lastWaterMs = _ws.screenMs - W_WATER_MS + W_SNOOZE_MS;
    } else {
      _ws.lastWaterMs = _ws.screenMs;
      if (Number(clicked) >= Number(total)) {
        _ws.glasses = 1;
      } else if (Number(clicked) === 0) {
        _ws.glasses = Math.min(W_MAX_GLASS, Number(total) + 1);
      } else {
        _ws.glasses = Math.max(1, Number(total) - Number(clicked));
      }
    }
  } else if (type === 'eye') {
    // Snooze: re-fire in W_SNOOZE_MS. Completion: always a fresh full interval from now,
    // regardless of how many times the user snoozed before completing.
    if (snooze) {
      _ws.lastEyeMs = _ws.screenMs - W_EYE_MS + W_SNOOZE_MS;
    } else {
      _ws.lastEyeMs = _ws.screenMs;
    }
  } else if (type === 'stretch-deep') {
    if (snooze) {
      _ws.lastDeepMs = _ws.screenMs - W_DEEP_MS + W_SNOOZE_MS;
    } else {
      _ws.lastDeepMs = _ws.screenMs;
    }
  }
}

function buildWellnessHtml(type, count, port) {
  const C = {
    water:          { bg:'#0c2340', grad:'linear-gradient(135deg,#0c2340 0%,#075985 100%)', bord:'#38bdf8', acc:'#7dd3fc', txt:'#e0f2fe' },
    eye:            { bg:'#0f1629', grad:'linear-gradient(135deg,#0f1629 0%,#1e3a8a 100%)', bord:'#4f8cff', acc:'#93c5fd', txt:'#dbeafe' },
    'stretch-deep': { bg:'#1a0a3d', grad:'linear-gradient(135deg,#1a0a3d 0%,#4c1d95 100%)', bord:'#a78bfa', acc:'#c4b5fd', txt:'#ede9fe' },
  };
  const c = C[type] || C.water;

  // The popup window loads via a data: URL, so relative asset paths won't resolve —
  // reference the express-served public/svg files by absolute URL on the listening port.
  const origin = 'http://127.0.0.1:' + port;

  // Base styles shared by all popup types.
  // body background matches the gradient so no dark strip shows if window height is
  // off by a pixel. .wrap has no border-radius — the window's native roundedCorners
  // handles rounding, so the card fills edge-to-edge (same pattern as job toast).
  const base = '*{box-sizing:border-box;margin:0;padding:0}'
    + 'html,body{background:' + c.grad + ';overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:' + c.txt + '}'
    + '.wrap{padding:15px 17px 14px;background:' + c.grad + ';animation:sl .35s cubic-bezier(.16,1,.3,1)}'
    + '@keyframes sl{from{transform:translateY(22px);opacity:0}to{transform:translateY(0);opacity:1}}'
    + '.hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}'
    + '.badge{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:' + c.acc + '}'
    + '.xbtn{background:none;border:none;color:#64748b;font-size:16px;cursor:pointer;padding:2px 6px;border-radius:4px;line-height:1}'
    + '.xbtn:hover{color:' + c.txt + '}'
    + '.msg{font-size:13px;opacity:.85;line-height:1.45;margin-bottom:10px}'
    + '.ftr{display:flex;gap:8px;margin-top:10px}'
    + '.btnp{padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:none;background:' + c.bord + ';color:' + c.bg + '}'
    + '.btnp:hover{opacity:.85}'
    + '.btng{padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid ' + c.bord + ';background:transparent;color:' + c.acc + '}'
    + '.btng:hover{background:rgba(255,255,255,.06)}';

  const sendFn = 'function send(d){fetch("http://localhost:' + port + '/api/wellness/result",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)}).catch(function(){});}';

  // ── WATER ──────────────────────────────────────────────────────────────────
  if (type === 'water') {
    const MSGS = [
      'Your body is 60% water — top it off!',
      'H₂O calling! Answer the hydration hotline!',
      'Every sip is a high-five to your kidneys!',
      'Drink water or your brain will file a complaint.',
      'Future you says: please drink some water!',
    ];
    const msg = MSGS[Math.floor(Date.now() / 60000) % MSGS.length];
    const penalty = count > 1
      ? '<div style="font-size:11px;color:#fbbf24;margin-bottom:8px">⚠️ You skipped last time — drink all ' + count + ' glasses!</div>' : '';

    // Same SVG structure and class names as the in-app overlay so animations match
    const glassBtns = Array.from({ length: count }, (_, i) => {
      const cp = 'wlpc' + i;
      return '<button class="wl-glass-btn" id="gb' + i + '" onclick="gc(' + i + ')" title="Click to drink!">'
        + '<svg class="wl-gsv" viewBox="0 0 70 100" xmlns="http://www.w3.org/2000/svg">'
        + '<defs>'
        + '<clipPath id="' + cp + '"><path d="M10 14 L6 92 Q6 97 12 97 L58 97 Q64 97 64 92 L60 14 Z"/></clipPath>'
        + '<linearGradient id="wlwg' + i + '" x1="0" y1="0" x2="1" y2="0">'
        + '<stop offset="0%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#0ea5e9"/></linearGradient>'
        + '</defs>'
        + '<g clip-path="url(#' + cp + ')">'
        + '<rect class="wl-water" x="6" y="35" width="58" height="62" fill="url(#wlwg' + i + ')"/>'
        + '<rect class="wl-wave" x="-18" y="32" width="106" height="9" rx="4" fill="#7dd3fc" opacity="0.65"/>'
        + '<circle class="wl-b1" cx="24" cy="72" r="3" fill="white" opacity="0.4"/>'
        + '<circle class="wl-b2" cx="46" cy="60" r="2.5" fill="white" opacity="0.35"/>'
        + '<circle class="wl-b3" cx="35" cy="80" r="2" fill="white" opacity="0.3"/>'
        + '</g>'
        + '<rect class="wl-ice1" clip-path="url(#' + cp + ')" x="14" y="56" width="14" height="14" rx="3" fill="#bfdbfe" opacity="0.55"/>'
        + '<rect class="wl-ice2" clip-path="url(#' + cp + ')" x="40" y="63" width="14" height="14" rx="3" fill="#bfdbfe" opacity="0.45"/>'
        + '<path d="M10 14 L6 92 Q6 97 12 97 L58 97 Q64 97 64 92 L60 14 Z" fill="none" stroke="#7dd3fc" stroke-width="2.5" stroke-linejoin="round"/>'
        + '<line x1="11" y1="14" x2="59" y2="14" stroke="white" stroke-width="2" opacity="0.25" stroke-linecap="round"/>'
        + '</svg>'
        + '<span class="glbl">Drink!</span></button>';
    }).join('');

    return '<!doctype html><meta charset="utf-8"><style>'
      + base
      // Glass layout
      + '.wl-glass-btn{background:none;border:none;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px;border-radius:8px;transition:transform .1s;color:#7dd3fc}'
      + '.wl-glass-btn:hover{transform:scale(1.06);background:rgba(255,255,255,.05)}'
      + '.wl-glass-btn.wl-drunk{pointer-events:none;opacity:.5}'
      + '.wl-gsv{width:80px;height:114px;overflow:visible}'
      + '.glbl{font-size:11px;color:#7dd3fc}'
      + '.wl-glasses{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;align-items:center;min-height:130px;margin-bottom:4px}'
      // Same glass animations as app.css
      + '.wl-water{transform-box:fill-box;transform-origin:bottom center;transition:transform .85s cubic-bezier(.16,1,.3,1)}'
      + '.wl-glass-btn.wl-drunk .wl-water{transform:scaleY(0)}'
      + '.wl-glass-btn.wl-drunk .wl-wave,.wl-glass-btn.wl-drunk .wl-b1,.wl-glass-btn.wl-drunk .wl-b2,.wl-glass-btn.wl-drunk .wl-b3{opacity:0!important;transition:opacity .4s}'
      + '.wl-wave{animation:wlWave 2s ease-in-out infinite}'
      + '.wl-b1{animation:wlBub 3s ease-in-out infinite}'
      + '.wl-b2{animation:wlBub 4s ease-in-out infinite .8s}'
      + '.wl-b3{animation:wlBub 3.5s ease-in-out infinite .4s}'
      + '@keyframes wlWave{0%,100%{transform:translateX(-15px)}50%{transform:translateX(15px)}}'
      + '@keyframes wlBub{0%,100%{transform:translateY(0);opacity:.35}50%{transform:translateY(-8px);opacity:.1}}'
      + '</style>'
      + '<div class="wrap">'
      + '<div class="hdr"><span class="badge">💧 OASIS — Hydration Time!</span>'
      + '<button class="xbtn" onclick="dm(false)">✕</button></div>'
      + '<p class="msg">' + msg + '</p>'
      + penalty
      + '<div class="wl-glasses" id="gl">' + glassBtns + '</div>'
      + '<div class="ftr" id="ft"><button class="btng" onclick="dm(true)">⏰ Snooze 10 min</button></div>'
      + '</div>'
      + '<script>var clicked=0,total=' + count + ';'
      + 'function gc(i){'
      + 'var b=document.getElementById("gb"+i);if(!b||b.classList.contains("wl-drunk"))return;'
      + 'b.classList.add("wl-drunk");clicked++;'
      // After drain animation (900ms), send result — server closes the window
      + 'if(clicked>=total){setTimeout(function(){send({type:"water",clicked:clicked,total:total,snooze:false});},950);}}'
      + 'function dm(snooze){send({type:"water",clicked:clicked,total:total,snooze:snooze});}'
      + sendFn
      + '<\/script>';
  }

  // ── EYE ───────────────────────────────────────────────────────────────────
  if (type === 'eye') {
    // Self-animating SVG (SMIL) — the pupils trace a path on their own, so <img> is enough.
    const eyeSvg = '<img class="wl-eye-img" src="' + origin + '/svg/eye.svg" alt="Animated eyes tracing a path">';

    return '<!doctype html><meta charset="utf-8"><style>'
      + base
      + '.anim{display:flex;justify-content:center;position:relative;margin:8px 0 4px;min-height:140px}'
      + '.wl-eye-img{width:160px;height:160px;object-fit:contain}'
      + '.rule{font-size:12px;color:' + c.acc + ';line-height:1.6;margin-bottom:6px}'
      + '.tnum{font-size:32px;font-weight:700;color:' + c.bord + ';text-align:center;line-height:1}'
      + '.tlbl{font-size:11px;opacity:.6;text-align:center;margin-top:2px}'
      + '</style>'
      + '<div class="wrap">'
      + '<div class="hdr"><span class="badge">👁️ OASIS — Eye Break!</span>'
      + '<button class="xbtn" onclick="done()">✕</button></div>'
      + '<p class="msg">Follow the eyes — keep your head still!</p>'
      + '<div class="anim">' + eyeSvg + '</div>'
      + '<div class="rule"><strong>Eye Reset:</strong> Trace the motion to loosen tired focus muscles.<br>Blink slowly and let your eyes relax.</div>'
      + '<div class="tnum" id="tc">20</div>'
      + '<div class="tlbl">seconds remaining</div>'
      + '<div class="ftr"><button class="btnp" onclick="done()">Done! 👍</button></div>'
      + '</div>'
      + '<script>var s=20,iv=setInterval(function(){s--;document.getElementById("tc").textContent=s;if(s<=0){clearInterval(iv);done();}},1000);'
      + 'function done(){clearInterval(iv);' + sendFn + 'send({type:"eye"});}'
      + '<\/script>';
  }

  // ── STRETCH ───────────────────────────────────────────────────────────────
  // All 7 yoga poses crossfading over 21s.
  // Files are served by express from public/svg; data: URL popups need absolute URLs.
  let figSvgDeep = '<div class="wl-dp">';
  for (let i = 1; i <= 7; i++) {
    figSvgDeep += '<img class="wl-dsv wl-pd' + i + '" src="' + origin + '/svg/yoga-' + i + '.svg" alt="">';
  }
  figSvgDeep += '</div>';

  let figCssDeep = '.anim{display:flex;justify-content:center;margin:6px 0 4px}'
    + '.wl-dp{position:relative;width:140px;height:140px}'
    + '.wl-dsv{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain;opacity:0;filter:drop-shadow(0 2px 8px rgba(167,139,250,0.3))}';
  for (let i = 1; i <= 7; i++) {
    figCssDeep += '.wl-pd' + i + '{animation:wlFD 21s ' + ((i - 1) * 3) + 's ease-in-out infinite backwards}';
  }
  figCssDeep += '@keyframes wlFD{0%{opacity:0}3%{opacity:1}11%{opacity:1}14%{opacity:0}100%{opacity:0}}';

  // ── BODY STRETCH (every 90 min) ───────────────────────────────────────────
  const DEEP_MOVES = [
    { n: 'Touch Your Toes 🖐️',   d: 'Stand, hinge at hips, reach toward the floor. Hold 20s. Loosen tight hamstrings.' },
    { n: 'Standing Quad Stretch 🦵', d: 'Balance on one foot, pull the other heel to your glute. Hold 15s each side.' },
    { n: 'Chest Opener 🙌',       d: 'Interlace fingers behind back, straighten arms and lift slightly. Hold 15s. Counter the keyboard hunch.' },
    { n: 'Wrist & Forearm Stretch 🤙', d: 'Extend arm forward, palm up. Gently pull fingers down with the other hand. 15s each side.' },
    { n: 'Hip Flexor Lunge 🏋️',  d: 'Step one foot forward into a lunge, drop the back knee to the floor. Hold 20s each side. Releases hip tension from sitting.' },
  ];
  const dm = DEEP_MOVES[Math.floor(Date.now() / (90 * 60000)) % DEEP_MOVES.length];
  return '<!doctype html><meta charset="utf-8"><style>'
    + base + figCssDeep
    + '.dur{display:inline-block;font-size:11px;font-weight:700;background:' + c.bord + ';color:' + c.bg + ';padding:2px 8px;border-radius:10px;margin-bottom:8px}'
    + '.sn{font-size:14px;font-weight:700;color:' + c.acc + ';margin-bottom:5px}'
    + '.sd{font-size:12px;opacity:.8;line-height:1.55}'
    + '.steps{margin-top:8px;font-size:11px;opacity:.65;line-height:1.6;border-left:2px solid ' + c.bord + ';padding-left:8px}'
    + '</style>'
    + '<div class="wrap">'
    + '<div class="hdr"><span class="badge">🤸 OASIS — Body Stretch!</span>'
    + '<button class="xbtn" onclick="dm2()">✕</button></div>'
    + '<span class="dur">⏱ 5 minutes — step away from your desk</span>'
    + '<div class="anim">' + figSvgDeep + '</div>'
    + '<div class="sn">' + dm.n + '</div>'
    + '<div class="sd">' + dm.d + '</div>'
    + '<div class="steps">Sequence: touch toes → quad stretch → chest opener → wrist stretch → hip flexor lunge</div>'
    + '<div class="ftr">'
    + '<button class="btnp" onclick="dm2()">Done! 💪</button>'
    + '<button class="btng" onclick="snz()">⏰ Snooze 10 min</button>'
    + '</div></div>'
    + '<script>' + sendFn + 'function dm2(){send({type:"stretch-deep",snooze:false});}function snz(){send({type:"stretch-deep",snooze:true});}<\/script>';
}

function showWellnessToast(type, count) {
  const { BrowserWindow, screen, app } = require('electron');
  if (!screen || !BrowserWindow) return;
  if (_wellnessToastWin && !_wellnessToastWin.isDestroyed()) {
    try { _wellnessToastWin.destroy(); } catch (_) {}
  }
  _wellnessToastWin = null;

  const W = 400, MARGIN = 20;
  const area = screen.getPrimaryDisplay().workArea;
  const x = area.x + area.width - W - MARGIN;
  const BGCOL = { water: '#0c2340', eye: '#0f1629', 'stretch-deep': '#1a0a3d' };
  // Use the actual listening port — Electron starts server on port 0 (OS-assigned),
  // so PORT constant (3000) would be wrong and all popup fetch calls would fail.
  const actualPort = (server.address() && server.address().port) || PORT;
  const html = buildWellnessHtml(type, count, actualPort);

  // On macOS, clicking ANY window of an app activates the whole app and raises all
  // its visible windows — even with focusable:false. Fix: hide the main window before
  // the popup appears so macOS has nothing to raise. We set a global flag so the
  // electron/main.js activate handler knows NOT to restore the window on popup clicks
  // (only on explicit dock-icon clicks after the popup is gone).
  const mainWin = BrowserWindow.getAllWindows().find(w => !w.isDestroyed() && w !== _wellnessToastWin && w !== _toastWin);
  let hidMain = false;
  if (process.platform === 'darwin' && mainWin && mainWin.isVisible() && !mainWin.isMinimized() && !mainWin.isFocused()) {
    mainWin.hide();
    hidMain = true;
  }
  global._wellnessPopupActive = true;

  const initH = type === 'water' ? (count > 3 ? 380 : count > 1 ? 330 : 290) : 270;
  const tw = new BrowserWindow({
    width: W, height: initH,
    x, y: area.y + area.height - initH - MARGIN,
    frame: false, backgroundColor: BGCOL[type] || BGCOL.water,
    resizable: false, movable: false,
    minimizable: false, maximizable: false, skipTaskbar: true,
    focusable: false, show: false, hasShadow: true, alwaysOnTop: true,
    roundedCorners: true,
    webPreferences: { contextIsolation: false, nodeIntegration: false },
  });
  _wellnessToastWin = tw;
  tw.setAlwaysOnTop(true, 'screen-saver');

  // Clear the popup flag when closed; do NOT call showInactive() here —
  // that's what caused OASIS to appear over the user's other app.
  // If the user wants OASIS back, they click its dock icon (handled in
  // electron/main.js activate handler which checks _wellnessPopupActive).
  tw.once('closed', () => {
    if (_wellnessToastWin === tw) _wellnessToastWin = null;
    global._wellnessPopupActive = false;
  });

  let shown = false;
  const reveal = () => {
    if (_wellnessToastWin === tw && !tw.isDestroyed() && !shown) {
      shown = true; tw.showInactive();
    }
  };
  tw.webContents.once('did-finish-load', async () => {
    try {
      const h = await tw.webContents.executeJavaScript(
        'Math.ceil(document.querySelector(".wrap").getBoundingClientRect().height)'
      );
      const newH = Math.max(100, Math.min(h, 500));
      tw.setBounds({ x, y: area.y + area.height - newH - MARGIN, width: W, height: newH });
    } catch (_) {}
    reveal();
  });
  setTimeout(reveal, 800);
  tw.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));

  // Auto-destroy after 25 s to give time for glass interactions
  setTimeout(() => {
    if (tw && !tw.isDestroyed()) { try { tw.destroy(); } catch (_) {} }
    if (_wellnessToastWin === tw) _wellnessToastWin = null;
  }, 25000);
}

function wellnessPersist(enabled) {
  try {
    const current = fs.existsSync(PREFS_PATH)
      ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {}) : {};
    fs.writeFileSync(PREFS_PATH, JSON.stringify({ ...current, wellnessEnabled: enabled }, null, 2), 'utf8');
  } catch (e) { console.warn('[wellness] prefs write failed:', e.message); }
}

function wellnessStartTimer() {
  if (!_ws.timer) {
    const now = Date.now();
    _ws.lastTickAt  = now;
    _ws.lastWaterMs = 0;
    _ws.timer = setInterval(wellnessTick, W_TICK_MS);

    // Track screen lock so eye/stretch are never shown on a locked machine
    try {
      const { powerMonitor } = require('electron');
      if (!_ws._lockHandler) {
        _ws._lockHandler   = () => { _ws.screenLocked = true; };
        _ws._unlockHandler = () => { _ws.screenLocked = false; };
        powerMonitor.on('lock-screen',   _ws._lockHandler);
        powerMonitor.on('unlock-screen', _ws._unlockHandler);
      }
    } catch (_) {}
  }
}

// POST /api/wellness/start — renderer toggle calls this to enable
app.post('/api/wellness/start', (req, res) => {
  _ws.enabled = true;
  wellnessStartTimer();
  wellnessPersist(true);
  res.json({ ok: true, enabled: true });
});

// POST /api/wellness/stop — renderer toggle calls this to disable
app.post('/api/wellness/stop', (req, res) => {
  _ws.enabled = false;
  if (_ws.timer) { clearInterval(_ws.timer); _ws.timer = null; }
  if (_wellnessToastWin && !_wellnessToastWin.isDestroyed()) {
    try { _wellnessToastWin.destroy(); } catch (_) {}
    _wellnessToastWin = null;
  }
  try {
    const { powerMonitor } = require('electron');
    if (_ws._lockHandler)   { powerMonitor.off('lock-screen',   _ws._lockHandler);   _ws._lockHandler   = null; }
    if (_ws._unlockHandler) { powerMonitor.off('unlock-screen', _ws._unlockHandler); _ws._unlockHandler = null; }
  } catch (_) {}
  _ws.screenLocked = false;
  wellnessPersist(false);
  res.json({ ok: true, enabled: false });
});

// GET /api/wellness/state — renderer reads this on init to restore toggle button state
app.get('/api/wellness/state', (req, res) => {
  res.json({ enabled: _ws.enabled, glasses: _ws.glasses });
});

// POST /api/wellness/result — popup window calls this after user interaction
app.post('/api/wellness/result', (req, res) => {
  const { type = 'water', clicked = 0, total = 1, snooze = false } = req.body || {};
  if (_wellnessToastWin && !_wellnessToastWin.isDestroyed()) {
    try { _wellnessToastWin.destroy(); } catch (_) {}
    _wellnessToastWin = null;
  }
  wellnessApplyResult(type, clicked, total, snooze);
  // Close any open overlay in the renderer
  try {
    const { BrowserWindow } = require('electron');
    const main = BrowserWindow.getAllWindows().find(w => !w.isDestroyed() && w !== _wellnessToastWin && w !== _toastWin);
    if (main) main.webContents.executeJavaScript('typeof wellnessExternalResult==="function"&&wellnessExternalResult()').catch(() => {});
  } catch (e) { console.warn('[wellness/result]', e.message); }
  res.json({ ok: true });
});

// POST /api/wellness/overlay-result — renderer overlay calls this after user interaction
app.post('/api/wellness/overlay-result', (req, res) => {
  const { type = 'water', clicked = 0, total = 1, snooze = false } = req.body || {};
  wellnessApplyResult(type, clicked, total, snooze);
  // Also close popup if it's open
  if (_wellnessToastWin && !_wellnessToastWin.isDestroyed()) {
    try { _wellnessToastWin.destroy(); } catch (_) {}
    _wellnessToastWin = null;
  }
  res.json({ ok: true });
});

function nativeNotify(title, body) {
  const safeBody = String(body || '').replace(/\n{2,}/g, '\n').trim().slice(0, 600);

  try {
    const { app } = require('electron');
    showToastWindow(title, safeBody);
    // A single dock-icon hop draws the eye without stealing focus or raising the window.
    if (process.platform === 'darwin') app.dock?.bounce('informational');
  } catch (e) {
    console.warn('[notify]', e.message);
  }
}

// Open a URL in the user's default browser. The embedded server runs inside the
// Electron main process, so Electron's shell.openExternal is the most reliable
// opener; fall back to the OS opener if it isn't available.
function openExternalUrl(url) {
  if (!url) return;
  try {
    const { shell } = require('electron');
    if (shell?.openExternal) { shell.openExternal(url); return; }
  } catch (_) {}
  const cmd = process.platform === 'darwin' ? `open "${url}"`
            : process.platform === 'win32'  ? `start "" "${url}"`
            :                                 `xdg-open "${url}"`;
  exec(cmd, () => {});
}

// Use the AWS CLI to get live credentials — it transparently refreshes role
// creds while the SSO session is valid, with no SDK cache issues. Returns
// { creds } on success or { creds: null, error } with the CLI's error text so
// callers can tell EXPIRY ("run aws sso login") apart from a broken profile
// ("sso-session does not exist") — only the former is fixable by a re-login.
function exportCliCredentials(profile) {
  return new Promise(resolve => {
    const profileArg = profile ? `--profile ${profile}` : '';
    exec(`aws configure export-credentials ${profileArg}`,
      { env: { ...process.env }, timeout: 12000 },
      (err, stdout, stderr) => {
        if (err || !stdout?.trim()) {
          resolve({ creds: null, error: String(stderr || err?.message || 'no output').trim() });
          return;
        }
        try {
          const c = JSON.parse(stdout);
          if (!c.AccessKeyId) { resolve({ creds: null, error: 'no AccessKeyId in CLI output' }); return; }
          resolve({ creds: { accessKeyId: c.AccessKeyId, secretAccessKey: c.SecretAccessKey, sessionToken: c.SessionToken || undefined } });
        } catch (e) { resolve({ creds: null, error: `bad CLI output: ${e.message}` }); }
      }
    );
  });
}

// Remembered across calls: the profile that last yielded working credentials
// (null = default chain, undefined = not yet discovered). Tried first on the
// next call so a broken profile earlier in the candidate list is skipped.
let _workingAwsProfile;

// Resolve live AWS credentials by trying candidate profiles in priority order:
// last-known-working → configured (Settings/yml via cfg) → AWS_PROFILE env →
// `default` → default chain. The FIRST profile with valid credentials wins —
// so if ANY usable token exists, requests proceed with no refresh and no
// prompt. Returns { creds, profile } or { creds: null, profile, errors }.
async function resolveAwsCredentials(cfg) {
  const candidates = [];
  const push = p => { if (!candidates.some(c => c === p)) candidates.push(p); };
  if (_workingAwsProfile !== undefined) push(_workingAwsProfile);
  if (cfg?.aws?.profile) push(cfg.aws.profile);
  if (process.env.AWS_PROFILE) push(process.env.AWS_PROFILE);
  push('default');
  push(null); // default provider chain (no --profile)

  const errors = [];
  for (const p of candidates) {
    const { creds, error } = await exportCliCredentials(p || undefined);
    if (creds) {
      if (_workingAwsProfile !== p) console.log(`[bedrock] using AWS profile: ${p || '(default chain)'}`);
      _workingAwsProfile = p;
      return { creds, profile: p };
    }
    errors.push(`${p || '(default chain)'}: ${(error || '').split('\n')[0]}`);
  }
  return { creds: null, profile: cfg?.aws?.profile || 'default', errors };
}

// True ONLY for genuine credential/SSO EXPIRY (which a re-login fixes) — not for
// generic "couldn't load credentials" / missing-profile errors, which a browser
// login won't fix and which must not trigger an SSO login on every call.
function isExpiredCredentialError(e) {
  const name = String(e.name || e.Code || '');
  const msg  = String(e.message || '');
  return /ExpiredToken(Exception)?/i.test(name) ||
         /run aws sso login/i.test(msg) ||
         (/sso session/i.test(msg)     && /(expired|invalid)/i.test(msg)) ||
         (/security token/i.test(msg)  && /(expired|invalid)/i.test(msg)) ||
         (/\btoken\b/i.test(msg)       && /expired/i.test(msg));
}

let _ssoLoginPromise = null;

// Run `aws sso login` once and resolve on success. Rather than rely on the AWS
// CLI's own browser auto-open (which silently no-ops in some GUI/non-tty Electron
// contexts), we run with `--no-browser` so the CLI prints the verification URL,
// then open that URL ourselves via shell.openExternal AND broadcast it to the UI
// as a clickable fallback. `extraArgs` lets us retry without `--no-browser` on
// older AWS CLI versions that don't support the flag.
function runAwsSsoLogin(profileArg, extraArgs) {
  return new Promise((resolve, reject) => {
    let output = '', opened = false;

    const detectAndOpen = () => {
      if (opened) return;
      // Prefer the device-authorization URL (carries ?user_code= on recent CLIs).
      const url = (output.match(/https:\/\/\S*device\.sso\.\S+/i)
                || output.match(/https:\/\/\S+/i) || [])[0];
      if (!url) return;
      opened = true;
      const code = (output.match(/\b[A-Z0-9]{4}-[A-Z0-9]{4}\b/) || [])[0] || null;
      // Open the *complete* verification URL (code embedded as ?user_code=) so the
      // browser pre-fills the device code and the user only clicks "Allow" — no
      // manual code entry, even on older AWS CLIs that print the bare URL + code
      // separately. A genuine portal sign-in still appears only when the SSO
      // session itself has expired; nothing here can skip that.
      let openUrl = url;
      if (code && !/[?&]user_code=/i.test(url)) {
        openUrl = url + (url.includes('?') ? '&' : '?') + 'user_code=' + encodeURIComponent(code);
      }
      console.log('[aws-sso] verification URL:', openUrl, code ? `(code ${code})` : '');
      openExternalUrl(openUrl);
      broadcastAll({ type: 'aws_sso_login', status: 'url', url: openUrl, code });
    };

    const cmd = `aws sso login ${profileArg} ${extraArgs}`.trim();
    const proc = exec(cmd, { timeout: 180000, env: { ...process.env } }, (err) => {
      if (err) { reject(Object.assign(err, { output })); return; }
      resolve();
    });
    const onData = d => { output += d.toString(); console.log('[aws-sso]', d.toString().trim()); detectAndOpen(); };
    proc.stdout?.on('data', onData);
    proc.stderr?.on('data', onData);
  });
}

async function awsSsoLogin(profile) {
  if (_ssoLoginPromise) return _ssoLoginPromise;   // coalesce concurrent callers

  const profileArg = profile ? `--profile ${profile}` : '';
  console.log(`[aws-sso] launching: aws sso login ${profileArg} --no-browser`);
  broadcastAll({ type: 'aws_sso_login', status: 'started', profile: profile || 'default' });
  nativeNotify('🔑 i-Ready OASIS — AWS Login', `AWS credentials expired. Opening browser for SSO login (profile: ${profile || 'default'})…`);

  _ssoLoginPromise = (async () => {
    try {
      await runAwsSsoLogin(profileArg, '--no-browser');
    } catch (e) {
      // Older AWS CLI without `--no-browser` → retry letting the CLI open the
      // browser itself (we still capture/open any URL it prints).
      const blob = `${e.output || ''} ${e.message || ''}`;
      if (/no-browser|unknown option|unrecognized arguments|invalid choice/i.test(blob)) {
        await runAwsSsoLogin(profileArg, '');
      } else {
        throw e;
      }
    }
  })()
    .then(() => {
      broadcastAll({ type: 'aws_sso_login', status: 'done' });
      nativeNotify('✅ i-Ready OASIS — AWS Login Done', 'SSO login complete. Retrying your request…');
      console.log('[aws-sso] login completed');
    })
    .catch((err) => {
      const errMsg = err?.killed ? 'AWS SSO login timed out (3 min)' : `AWS SSO login failed: ${err.message}`;
      broadcastAll({ type: 'aws_sso_login', status: 'error', message: errMsg });
      nativeNotify('⚠️ i-Ready OASIS — AWS Login Failed', errMsg);
      throw new Error(errMsg);
    })
    .finally(() => { _ssoLoginPromise = null; });

  return _ssoLoginPromise;
}

// Build a Bedrock client. If `creds` are passed (already resolved via the AWS
// CLI in resolveAwsCredentials) they're used directly; otherwise fall back to
// fromIni for the configured profile, then the default provider chain.
function makeBedrockClient(cfg, creds) {
  const { BedrockRuntimeClient } = require('@aws-sdk/client-bedrock-runtime');
  const region  = cfg?.aws?.region || process.env.AWS_REGION || 'us-east-1';
  const profile = cfg?.aws?.profile;
  if (creds) return new BedrockRuntimeClient({ region, credentials: creds });
  if (profile) {
    const { fromIni } = require('@aws-sdk/credential-providers');
    return new BedrockRuntimeClient({ region, credentials: fromIni({ profile }) });
  }
  return new BedrockRuntimeClient({ region });
}

// Don't re-pop the browser more than once per cooldown window — guards against a
// misconfigured profile triggering an SSO login on every single request.
let _ssoCooldownUntil = 0;
const SSO_COOLDOWN_MS = 30 * 1000;

// Send a Bedrock command. `aws configure export-credentials` is the source of
// truth: it transparently refreshes role creds while the SSO *session* is valid,
// and only returns nothing once the session itself has expired. So we launch the
// browser SSO login ONLY when no creds come back — never on every call — and a
// cooldown stops repeated prompts. `makeCommand` is a thunk so it's rebuilt fresh
// on retry. EVERY Bedrock caller goes through this.
async function bedrockSend(cfg, makeCommand) {
  // Try every candidate profile — if ANY yields valid credentials, proceed
  // immediately: no refresh, no prompt. A broken profile (e.g. one whose
  // sso-session block is missing) is simply skipped, not "fixed" via login.
  let { creds, profile, errors } = await resolveAwsCredentials(cfg);

  if (!creds) {
    const blob = (errors || []).join(' | ');
    const looksExpired = /expired|sso session|sso.*login|UnauthorizedException|invalid grant/i.test(blob);
    console.warn('[bedrock] no valid credentials from any profile:', blob.slice(0, 300));
    if (looksExpired && Date.now() > _ssoCooldownUntil) {
      // Genuine expiry → one browser login, then re-resolve.
      _ssoCooldownUntil = Date.now() + SSO_COOLDOWN_MS;
      await awsSsoLogin(profile || undefined);
      ({ creds, profile } = await resolveAwsCredentials(cfg));
    }
    // Not expiry (mis-config etc.) → fall through; the SDK will throw a clear
    // error below which surfaces to the caller instead of looping logins.
  }

  // Pin the SDK fallback to the profile that was actually resolved.
  const sendCfg = { ...cfg, aws: { ...(cfg?.aws || {}), profile: profile || undefined } };
  const send = () => makeBedrockClient(sendCfg, creds).send(makeCommand());
  try {
    return await send();
  } catch (e) {
    // Credentials expired between resolve and send (rare) → one re-login + retry.
    if (isExpiredCredentialError(e) && Date.now() > _ssoCooldownUntil) {
      _ssoCooldownUntil = Date.now() + SSO_COOLDOWN_MS;
      console.warn('[bedrock] credentials expired mid-request — re-login + retry');
      await awsSsoLogin(profile || undefined);
      ({ creds, profile } = await resolveAwsCredentials(cfg));
      return await send();
    }
    throw e;
  }
}

function makeBedrockRuntime(sess) {
  const cfg = cfgForBedrock(sess);
  return { send: (makeCommand) => bedrockSend(cfg, makeCommand), cfg };
}

function aiClientFor(sess) {
  return createAiClient(sess, { bedrockRuntime: makeBedrockRuntime(sess) });
}

async function generateScriptFromReadme(repoName, language, readme, sess) {
  const ai = aiClientFor(sess);
  if (!ai.available()) return null;

  const system = `You are a DevOps engineer. Output a complete bash script ONLY if the README describes setup steps beyond a standard ${language} build (e.g. docker pull, brew install, custom env vars). Otherwise output the single word SKIP.`;
  const userText = `Repository: ${repoName}\nREADME:\n${String(readme).slice(0, 6000)}`;

  const result = await ai.complete({ messages: [{ role: 'user', content: userText }], system, maxTokens: 1500 });
  if (!result || result.trim() === 'SKIP') return null;
  return result;
}

/**
 * GET /api/scripts?session=SID&repo=REPO_NAME
 * Lists available setup scripts in the local scripts/<repo>/ folder
 */
app.get('/api/scripts', (req, res) => {
  const { session, repo } = req.query;
  if (!sessions[session]) return res.status(401).json({ error: 'Invalid session' });

  // `repo` arrived in a query string and was joined straight onto a path, so
  // `?repo=../../../../etc` listed that directory and returned its absolute
  // paths. Constrained to a plain repository name — the same rule
  // resolveRepoPath already applies — because adding a second search root
  // multiplies where a traversal could reach, not the reverse.
  // NOTE the `.` and `..` exclusion. The obvious character-class check
  // /^[A-Za-z0-9._-]+$/ ACCEPTS `..` — a dot is a legal filename character —
  // and path.join(root, '..') climbs straight out of the directory. A name must
  // also survive basename() unchanged, which rejects anything containing a
  // separator on either platform.
  if (repo !== undefined && !isPlainName(repo)) {
    return res.status(400).json({ error: 'Invalid repository name' });
  }

  const roots = scriptRoots();
  const isScript = f => ALL_EXTENSIONS.includes(path.extname(f).toLowerCase());

  // Per-repository directories across every root, then the generic scripts.
  // Deduplicated by FILENAME so a bundled script and a team one of the same
  // name appear once, matching what would actually run.
  const seen = new Set();
  const scripts = [];

  const collect = (dir, generic) => {
    const root = roots.find(r => isInsideRoot(r, dir));
    if (!root) return;

    let entries = [];
    try {
      entries = fs.readdirSync(dir);
    } catch (_) {
      return; // absent is the normal case for a fallback root
    }
    for (const f of entries.filter(isScript)) {
      if (seen.has(f)) continue;
      seen.add(f);
      scripts.push({ name: f, path: path.join(dir, f), generic, root: dir });
    }
  };

  if (repo) for (const root of roots) collect(path.join(root, repo), false);
  if (!scripts.length) for (const root of roots) collect(root, true);

  res.json({ scripts });
});

/**
 * POST /api/setup
 * Body: { session, repos: [{name, default_branch, clone_url, language}], options: {intellij, maven, parallel, openInIde} }
 * Kicks off setup jobs, streams progress via WebSocket
 */
app.post('/api/setup', (req, res) => {
  const { session, repos, options = {} } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repos || repos.length === 0) return res.status(400).json({ error: 'No repos specified' });
  if (repos.length > 10) return res.status(400).json({ error: 'Max 10 repos per run' });

  // Acknowledge immediately; work happens async via WS
  res.json({ ok: true, jobCount: repos.length });

  if (options.parallel) {
    repos.forEach(r => runSetup(session, sess, r, options));
  } else {
    (async () => {
      for (const r of repos) await runSetup(session, sess, r, options);
    })();
  }
});

/**
 * POST /api/suggest
 * Body: { session, repo, language, logs }
 * Returns a troubleshooting suggestion for a failed setup.
 *  - Uses whatever AI provider is configured in Settings; otherwise falls
 *    back to an offline heuristic analyzer.
 */
app.post('/api/suggest', async (req, res) => {
  const { session, repo, language, logs, phase } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const text = String(logs || '').slice(-6000);

  // Gather on-disk repo context so Claude can reason about the actual structure
  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  const repoCtx = gatherRepoContext(cloneDir, repo);

  const aiEnabled = aiClientFor(sess).available();
  const generic = () => heuristicSuggest({ repo, language, logs: text, repoCtx, phase });

  if (aiEnabled) {
    try {
      // User has AI configured → return the AI-generated suggestion.
      const suggestion = await bedrockSuggest({ repo, language, logs: text, repoCtx, phase }, sess);
      return res.json({ suggestion, source: 'bedrock', commands: extractCommands(suggestion) });
    } catch (e) {
      // Provider access failed (denied or no valid credentials)
      // → show the generic message instead of the AI suggestion.
      if (isAccessError(e)) {
        console.warn('No AI provider access for this user — using generic suggestion:', e.name || e.message);
        // reason: 'denied' = role lacks model access (don't suggest a refresh);
        //         'no-access' = credential problem (refresh may help).
        const g = generic();
        return res.json({ suggestion: g, source: 'generic', reason: accessFailReason(e), commands: extractCommands(g) });
      }
      // Other failures (throttling, network, bad response) → also fall back.
      console.warn('AI suggestion failed, using generic suggestion:', e.message);
    }
  }
  const g = generic();
  res.json({ suggestion: g, source: 'generic', commands: extractCommands(g) });
});

/**
 * POST /api/run-commands
 * Body: { session, repo, commands: [string] }
 * Runs the suggested fix commands in the repo's clone dir, streaming output to
 * the job terminal over WebSocket. Stops on the first failing command.
 * Note: this runs as the local user in their own clone dir — the same trust
 * level as the setup scripts the app already executes.
 */
app.post('/api/run-commands', (req, res) => {
  const { session, repo, commands, cmdIndex } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo) return res.status(400).json({ error: 'repo is required' });

  const safe = (Array.isArray(commands) ? commands : []).map(String).filter(isRunnableCommand).slice(0, 12);
  if (safe.length === 0) return res.status(400).json({ error: 'No runnable commands provided' });

  res.json({ ok: true, count: safe.length });

  const jobId = repo;
  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  const env = buildEnv(sess, cloneDir);

  (async () => {
    broadcast(session, { type: 'fix_start', jobId, cmdIndex });
    const capture = [];
    try {
      if (!fs.existsSync(cloneDir)) {
        throw new Error(`Clone directory not found: ${cloneDir}. Set up the repo first.`);
      }
      for (const cmd of safe) {
        // Register the running process so /api/cancel-fix can kill it
        await shCancellable(cmd, session, jobId, cloneDir, env, capture);
      }
      const followups = extractFollowups(capture.join('\n'), safe);
      broadcast(session, { type: 'fix_done', jobId, success: true, cmdIndex, followups });
    } catch (err) {
      log(session, jobId, 'err', `✗ ${err.message}`);
      const followups = extractFollowups(capture.join('\n'), safe);
      const cancelled = sess._fixCancelled?.[jobId];
      broadcast(session, { type: 'fix_done', jobId, success: false, error: err.message, cmdIndex, followups, cancelled });
      if (sess._fixCancelled) delete sess._fixCancelled[jobId];
    }
  })();
});

/**
 * POST /api/cancel-fix
 * Body: { session, repo }
 * Kills the currently running fix command for a repo.
 */
app.post('/api/cancel-fix', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const proc = sess._fixProc?.[repo];
  if (proc) {
    if (!sess._fixCancelled) sess._fixCancelled = {};
    sess._fixCancelled[repo] = true;
    try { process.kill(-proc.pid, 'SIGTERM'); } catch (_) { proc.kill('SIGTERM'); }
    delete sess._fixProc[repo];
    res.json({ ok: true });
  } else {
    res.json({ ok: false, message: 'No running command for this repo' });
  }
});

/**
 * POST /api/launch
 * Body: { session, repo }
 * Starts the repo's launch script (scripts/<repo>.launch.sh) as a long-running
 * server/service process, streaming its output to the job terminal. The process
 * keeps running until it exits on its own or /api/stop-launch kills it.
 */
app.post('/api/launch', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo) return res.status(400).json({ error: 'repo is required' });
  if (sess._launchProc?.[repo]) return res.status(409).json({ error: 'Already running' });

  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  if (!fs.existsSync(cloneDir)) {
    return res.status(400).json({ error: `Clone directory not found: ${cloneDir}. Set up the repo first.` });
  }

  const resolved = resolveLaunchScript(repo);
  let cmd;
  if (resolved) {
    // Built from the resolved script's OWN interpreter — bash for .sh,
    // PowerShell for .ps1, cmd for .bat — rather than assuming the shell.
    if (!resolved.available) return res.status(503).json({ error: resolved.hint });
    cmd = commandLineFor(resolved.resolved, [cloneDir]).line;
  } else {
    // Fallback when there's no committed launch script (button normally hides
    // in that case, but a direct API call still gets a best-effort launch).
    cmd = autoLaunchCommand(cloneDir);
    if (!cmd) return res.status(400).json({ error: `No launch script for ${repo} and no runnable artifact detected.` });
  }

  // Checked BEFORE responding. startLaunch runs after the response is sent, so
  // a failure there would surface as {ok:true} followed by silence — the exact
  // shape of failure this work exists to remove.
  const shell = detectBash();
  if (!shell.available) return res.status(503).json({ error: shell.hint });

  res.json({ ok: true });
  try {
    startLaunch(session, repo, cmd, cloneDir, buildEnv(sess, cloneDir));
  } catch (e) {
    // The response is already sent, so the job log is the only channel left.
    log(session, repo, 'error', e.message);
  }
});

/**
 * POST /api/stop-launch
 * Body: { session, repo }
 * Stops a running launch by killing its process group.
 */
app.post('/api/stop-launch', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  const proc = sess._launchProc?.[repo];
  if (!proc) return res.json({ ok: false, message: 'Not running' });
  try { process.kill(-proc.pid, 'SIGTERM'); } catch (_) { try { proc.kill('SIGTERM'); } catch (__) {} }
  res.json({ ok: true });
});

// Best-effort launch command when a repo has no dedicated launch script:
// Spring Boot apps → spring-boot:run; otherwise a built boot jar → java -jar.
function autoLaunchCommand(cloneDir) {
  const pom = path.join(cloneDir, 'pom.xml');
  if (fs.existsSync(pom)) {
    try {
      const txt = fs.readFileSync(pom, 'utf8');
      if (/spring-boot-maven-plugin|spring-boot-starter/.test(txt)) return 'mvn spring-boot:run';
    } catch (_) { /* ignore */ }
  }
  try {
    const target = path.join(cloneDir, 'target');
    if (fs.existsSync(target)) {
      const jar = fs.readdirSync(target).find(f => /\.jar$/.test(f) && !/sources|javadoc|original/.test(f));
      if (jar) return `java -jar "target/${jar}"`;
    }
  } catch (_) { /* ignore */ }
  return null;
}

// Spawn a long-running launch process in its own process group (so SIGTERM from
// /api/stop-launch reaches the whole tree — mvn + java forks, tomcat, etc.) and
// stream its stdout/stderr to the job terminal. Does NOT resolve on completion:
// a server is expected to keep running until stopped.
// Patterns in Tomcat/Spring stdout that indicate the *webapp* failed to start
// even though the Tomcat *process* keeps running. When matched we emit a
// launch_app_error so the UI can show Claude's suggestion without waiting for
// the process to exit (which may never happen for a server that stays up).
const LAUNCH_APP_FAIL_RE = /AccessDeniedException|ssm:GetParameters|Error creating bean|ContextRefreshException|APPLICATION FAILED TO START|Error starting ApplicationContext|SEVERE.*Servlet.*failed|ContextLoader.*Context initialization failed|BeanCreationException|NoSuchBeanDefinition|UnsatisfiedDependency/i;

function startLaunch(sessionId, repo, cmd, cloneDir, env) {
  const sess = sessions[sessionId];
  const jobId = repo;
  const fullCmd = `cd "${cloneDir}" && ${cmd}`;
  log(sessionId, jobId, 'cmd', '$ ' + cmd);

  const proc = spawnBash(['-c', fullCmd], { env, stdio: ['ignore', 'pipe', 'pipe'], detached: true });
  if (!sess._launchProc) sess._launchProc = {};
  sess._launchProc[repo] = proc;
  broadcast(sessionId, { type: 'launch_start', jobId, repo });

  const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');

  // Track whether we already fired a launch_app_error for this run so we don't
  // spam it on every matching log line.
  let appErrorFired = false;

  const makeLineHandler = (lvl) => {
    let buf = '';
    const onLine = (l) => {
      log(sessionId, jobId, lvl, l);
      // Detect webapp startup failure while Tomcat process itself stays alive.
      if (!appErrorFired && LAUNCH_APP_FAIL_RE.test(l)) {
        appErrorFired = true;
        // Flush buffered logs first so they arrive before the error event.
        broadcast(sessionId, { type: 'launch_app_error', jobId, repo });
      }
    };
    return {
      onData: (d) => {
        buf += d.toString();
        const parts = buf.split(/\r\n|\r|\n/);
        buf = parts.pop();
        parts.forEach(l => onLine(stripAnsi(l)));
      },
      flush: () => { if (buf.length) { onLine(stripAnsi(buf)); buf = ''; } },
    };
  };

  const out = makeLineHandler('out');
  const err = makeLineHandler('err');
  proc.stdout.on('data', out.onData);
  proc.stderr.on('data', err.onData);
  proc.on('error', (e) => {
    out.flush(); err.flush();
    if (sess._launchProc?.[repo] === proc) delete sess._launchProc[repo];
    log(sessionId, jobId, 'err', `✗ Launch failed: ${e.message}`);
    broadcast(sessionId, { type: 'launch_stopped', jobId, repo, code: 1 });
  });
  proc.on('exit', (code) => {
    out.flush(); err.flush();
    if (sess._launchProc?.[repo] === proc) delete sess._launchProc[repo];
    broadcast(sessionId, { type: 'launch_stopped', jobId, repo, code });
  });
}

// Like sh() but registers the spawned process in sess._fixProc[jobId] so it
// can be cancelled via /api/cancel-fix. The process is run in its own process
// group (detached) so SIGTERM propagates to child processes (e.g. mvn forks).
function shCancellable(cmd, sessionId, jobId, cloneDir, env, capture) {
  const sess = sessions[sessionId];
  return new Promise((resolve, reject) => {
    const fullCmd = `cd "${cloneDir}" && ${cmd}`;
    log(sessionId, jobId, 'cmd', '$ ' + fullCmd.replace(/https:\/\/[^@]+@/, 'https://***@'));

    const proc = spawnBash(['-c', fullCmd], {
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: true,   // own process group → SIGTERM kills the whole tree (mvn + java forks)
    });

    if (sess) {
      if (!sess._fixProc) sess._fixProc = {};
      sess._fixProc[jobId] = proc;
    }

    const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');
    const makeLineHandler = (onLine) => {
      let buf = '';
      return {
        onData: (d) => { buf += d.toString(); const p = buf.split('\n'); buf = p.pop(); p.forEach(l => onLine(stripAnsi(l))); },
        flush:  ()  => { if (buf.length) { onLine(stripAnsi(buf)); buf = ''; } },
      };
    };

    const out = makeLineHandler(l => { capture.push(l); log(sessionId, jobId, 'out', l); });
    const err = makeLineHandler(l => { capture.push(l); log(sessionId, jobId, 'err', l); });
    proc.stdout.on('data', out.onData);
    proc.stderr.on('data', err.onData);
    proc.on('close', code => {
      out.flush(); err.flush();
      if (sess?._fixProc?.[jobId] === proc) delete sess._fixProc[jobId];
      code === 0 ? resolve() : reject(new Error(`Exit code ${code}`));
    });
  });
}

// Treat as "no access" when Bedrock/Claude rejects on auth/permissions or when
// no usable AWS credentials are available. These users get the generic message;
// other (transient) errors fall back too but are logged differently above.
function isAccessError(e) {
  const name = String(e?.name || '');
  const msg = String(e?.message || '');
  const status = e?.$metadata?.httpStatusCode;
  return (
    status === 403 ||
    /AccessDenied|UnrecognizedClient|Unauthorized|ExpiredToken|InvalidSignature|Forbidden|CredentialsProviderError/i.test(name) ||
    /could not load credentials|security token.*invalid|not authorized|access denied|credentials/i.test(msg)
  );
}

// IAM PERMISSION denial (role lacks bedrock:InvokeModel on the configured model)
// — refreshing credentials can never fix this, so it must be reported as
// "denied", not "expired", or the UI sends the user token-chasing forever.
function isPermissionDenied(e) {
  const name = String(e?.name || '');
  const msg = String(e?.message || '');
  return /AccessDeniedException/i.test(name) || /is not authorized to perform/i.test(msg);
}

// Reason code the UI uses to pick its hint: 'denied' → "ask for model access";
// 'no-access' → "refresh credentials".
function accessFailReason(e) { return isPermissionDenied(e) ? 'denied' : 'no-access'; }

// Shell commands we'll offer to run from a suggestion. Only lines that START
// with one of these are treated as runnable — so prose, file edits (JSON/XML
// snippets) and bare identifiers are ignored, and a manual-only suggestion
// produces no commands (the UI then just shows the text, no Run button).
const RUNNABLE_HEADS = new Set([
  'npm', 'npx', 'yarn', 'pnpm', 'mvn', './mvnw', 'mvnw', 'gradle', './gradlew', 'gradlew',
  'brew', 'git', 'export', 'unset', 'source', 'cd', 'chmod', 'cp', 'mv', 'mkdir', 'ln',
  'java', 'javac', 'python', 'python3', 'pip', 'pip3', 'bundle', 'rails', 'node', 'docker',
  'make', 'curl', 'wget', 'sdk', 'asdf', 'nvm', 'open', 'idea', 'code', 'which',
  '/usr/libexec/java_home',
]);

function isRunnableCommand(line) {
  const c = String(line).trim().replace(/^[$#]\s+/, '');   // drop a leading shell prompt
  if (!c || c.length > 300) return false;
  if (!/\s/.test(c)) return false;                         // bare tool name (e.g. `mvn`) — a noun in prose, not a command to run
  if (/[{}<]/.test(c) || /^["']/.test(c)) return false;    // JSON/markup, not a command
  if (/^[A-Z0-9_]+=/.test(c)) return false;                // bare env assignment (set in Settings)
  const parts = c.split(/\s+/);
  const head = parts[0] === 'sudo' ? (parts[1] || '') : parts[0];
  return RUNNABLE_HEADS.has(head);
}

// Extract runnable commands from a suggestion's markdown (fenced blocks first,
// then inline `code`), de-duped and capped.
function extractCommands(md) {
  const text = String(md || '');
  const out = [];
  const add = (line) => {
    const c = String(line).trim().replace(/^[$#]\s+/, '');
    if (isRunnableCommand(c) && !out.includes(c)) out.push(c);
  };
  // Fenced ```code``` blocks — one command per line.
  (text.match(/```[\s\S]*?```/g) || []).forEach(block => {
    block.replace(/```[a-zA-Z]*\n?/, '').replace(/```\s*$/, '').split('\n').forEach(add);
  });
  // Inline `code` outside fenced blocks.
  text.replace(/```[\s\S]*?```/g, '').replace(/`([^`\n]+)`/g, (_, c) => { add(c); return ''; });
  return out.slice(0, 12);
}

// Pull runnable commands a tool printed in its OWN output — e.g. brew's
// "To link this version, run:\n  brew link pnpm". Looks for commands quoted in
// backticks/quotes and for lines that follow a "…run:/try:/use:" hint. Excludes
// commands we already ran. Used to offer a follow-up Run button after a command.
function extractFollowups(text, exclude = []) {
  const lines = String(text || '').split('\n');
  const excl = new Set(exclude.map(c => String(c).trim()));
  const out = [];
  const add = (raw) => {
    const c = String(raw).trim().replace(/^[$#>]\s+/, '');
    if (!isRunnableCommand(c) || excl.has(c) || out.includes(c)) return;
    out.push(c);
  };
  const INLINE_HINT = /\b(?:run|try|execute|use)\b\s*:?\s+(.+)$/i;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    // commands quoted in backticks or quotes anywhere on the line
    (line.match(/[`'"]([^`'"]+)[`'"]/g) || []).forEach(q => add(q.slice(1, -1)));
    // A short label line ending in ':' (e.g. "To force the link…:", "…run:")
    // introduces indented command line(s) below it — the common CLI convention.
    if (/:\s*$/.test(trimmed) && trimmed.length <= 140) {
      for (let j = i + 1; j < lines.length && j <= i + 4; j++) {
        if (!lines[j].trim()) break;          // stop at a blank line
        if (!/^\s/.test(lines[j])) break;     // stop once no longer indented
        add(lines[j]);
      }
    }
    // "run/try/execute/use: <cmd>" on the same line
    const m = trimmed.match(INLINE_HINT);
    if (m) add(m[1]);
  }
  return out.slice(0, 6);
}

function suggestSystemPrompt(phase) {
  const what = phase === 'launch'
    ? "an already-built app/server just FAILED TO LAUNCH (start) — e.g. a Tomcat web app or a Spring Boot service " +
      "wouldn't boot. Common causes: missing/expired AWS credentials, a port already in use, a missing or stale " +
      "built artifact (.war/.jar), bad local config, or a startup exception in the logs."
    : "a repo setup just failed (git clone, Maven/npm build, or local configuration).";
  return (
    'You are a senior developer assistant inside "i-Ready OASIS", an internal Curriculum Associates tool that ' +
    'clones repos from GitHub Enterprise, runs setup scripts, and launches apps on macOS. ' + what + ' ' +
    'You will be given the failure logs PLUS the actual on-disk structure of the cloned repo (directory tree, ' +
    'pom.xml modules, README excerpt). Use this real context to give a precise, actionable fix — do not guess at ' +
    'paths or modules that are not present. Respond in markdown: one short diagnosis line, then 2-4 bullet steps ' +
    'with exact commands in backticks. Under 200 words. Do not invent product features.'
  );
}

// Scan the cloned repo and return a compact context string for Claude.
// Reads: top-level directory tree, Maven module list from parent pom.xml,
// per-module pom.xml <artifactId>, README.md excerpt, and package.json name/scripts.
function gatherRepoContext(cloneDir, repoName) {
  if (!cloneDir || !fs.existsSync(cloneDir)) return null;

  const lines = [`=== Repo: ${repoName} (cloned at ${cloneDir}) ===`];

  // ── Directory tree (depth 2) ─────────────────────────────────────────────
  try {
    const entries = fs.readdirSync(cloneDir).filter(e => !e.startsWith('.')).slice(0, 40);
    lines.push('\nTop-level entries:');
    entries.forEach(e => {
      const full = path.join(cloneDir, e);
      const isDir = fs.statSync(full).isDirectory();
      if (isDir) {
        const sub = fs.readdirSync(full).filter(s => !s.startsWith('.')).slice(0, 15);
        lines.push(`  ${e}/`);
        sub.forEach(s => lines.push(`    ${s}${fs.statSync(path.join(full, s)).isDirectory() ? '/' : ''}`));
      } else {
        lines.push(`  ${e}`);
      }
    });
  } catch (_) {}

  // ── Parent pom.xml — modules + artifactId ───────────────────────────────
  const parentPom = path.join(cloneDir, 'pom.xml');
  if (fs.existsSync(parentPom)) {
    try {
      const xml = fs.readFileSync(parentPom, 'utf8').slice(0, 20000);
      const modules = [...xml.matchAll(/<module>(.*?)<\/module>/g)].map(m => m[1].trim());
      const artifactId = (xml.match(/<artifactId>(.*?)<\/artifactId>/) || [])[1] || '';
      lines.push(`\nParent pom.xml — artifactId: ${artifactId}`);
      if (modules.length) lines.push(`Modules: ${modules.join(', ')}`);

      // For each module, note its artifactId, directory presence, and key plugin config
      modules.forEach(mod => {
        const modDir = path.join(cloneDir, mod);
        const exists = fs.existsSync(modDir);
        const modPom = path.join(modDir, 'pom.xml');
        let modId = '', pluginNotes = '';
        if (exists && fs.existsSync(modPom)) {
          const mx = fs.readFileSync(modPom, 'utf8').slice(0, 8000);
          modId = (mx.match(/<artifactId>(.*?)<\/artifactId>/) || [])[1] || '';

          // Extract openapi-generator inputSpec so Claude knows exactly what file it needs
          const inputSpec = (mx.match(/<inputSpec>(.*?)<\/inputSpec>/s) || [])[1]?.trim();
          if (inputSpec) {
            // Check if the spec path resolves on disk
            const specPath = inputSpec.startsWith('http') ? inputSpec
              : path.resolve(modDir, inputSpec.replace(/\$\{project\.basedir\}/g, modDir)
                                                .replace(/\$\{basedir\}/g, modDir));
            const specExists = inputSpec.startsWith('http') ? '(remote URL)' :
              (fs.existsSync(specPath) ? 'EXISTS on disk' : 'MISSING on disk');
            pluginNotes += ` | openapi inputSpec: "${inputSpec}" → ${specExists}`;
          }

          // Extract other generator plugins that may need files
          const generators = [...mx.matchAll(/<configurationFile>(.*?)<\/configurationFile>/gs)].map(m => m[1].trim());
          if (generators.length) pluginNotes += ` | configFiles: ${generators.join(', ')}`;
        }
        lines.push(`  module "${mod}" → dir ${exists ? 'EXISTS' : 'MISSING'}${modId ? ` (artifactId: ${modId})` : ''}${pluginNotes}`);
      });
    } catch (_) {}
  }

  // ── package.json ─────────────────────────────────────────────────────────
  const pkgJson = path.join(cloneDir, 'package.json');
  if (fs.existsSync(pkgJson)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgJson, 'utf8'));
      lines.push(`\npackage.json — name: ${pkg.name || '?'}, scripts: ${Object.keys(pkg.scripts || {}).join(', ')}`);
    } catch (_) {}
  }

  // ── README excerpt (first 1500 chars) ────────────────────────────────────
  const readmes = ['README.md', 'README.MD', 'readme.md'].map(r => path.join(cloneDir, r));
  const readmePath = readmes.find(r => fs.existsSync(r));
  if (readmePath) {
    try {
      const excerpt = fs.readFileSync(readmePath, 'utf8').slice(0, 1500);
      lines.push(`\nREADME excerpt:\n${excerpt}`);
    } catch (_) {}
  }

  return lines.join('\n');
}

// Pull the most relevant error lines out of a build log (for specific feedback).
function extractErrors(t) {
  const lines = t.split('\n');
  const hits = [];
  const seen = new Set();
  const re = /(\[ERROR\]|ERROR:|error:|FAILED|fatal:|Caused by:|Exception|BUILD FAILURE|cannot find symbol|command not found)/i;
  for (const raw of lines) {
    const line = raw.replace(/^\s*\d+:\d+:\d+\s*/, '').trim();   // strip leading timestamps
    if (!line || !re.test(line)) continue;
    if (/^\[ERROR\]\s*$/.test(line) || /-{5,}/.test(line)) continue;
    const key = line.slice(0, 120);
    if (seen.has(key)) continue;
    seen.add(key);
    hits.push(line.length > 160 ? line.slice(0, 159) + '…' : line);
    if (hits.length >= 6) break;
  }
  return hits;
}

// Offline rule-based analyzer — no external calls, works fully internal/offline.
function heuristicSuggest({ repo, language, logs, repoCtx, phase }) {
  const t = logs || '';

  // ── Launch-specific failures (server/app wouldn't start) ───────────────────
  if (phase === 'launch') {
    if (/Unable to load (AWS )?credentials|ExpiredToken|sso.*expired|InvalidSignature|AccessDenied|sso login/i.test(t)) {
      return `**Diagnosis:** The app couldn't start because AWS credentials are missing or expired.\n\n` +
        `- Sign in with your profile:\n\`\`\`\naws sso login --profile ${'${AWS_PROFILE:-default}'}\n\`\`\`\n` +
        `- Pick the right profile in **Settings → AWS**, then click **▶ Launch** again.`;
    }
    if (/Address already in use|bind.*8080|port 8080|EADDRINUSE/i.test(t)) {
      return `**Diagnosis:** The port is already in use — another server (or a previous launch) is still running.\n\n` +
        `- Find and stop it:\n\`\`\`\nlsof -ti tcp:8080 | xargs kill\n\`\`\`\n` +
        `- Then click **▶ Launch** again.`;
    }
    if (/No built \.war found|No launch script|no runnable artifact|Bundled Tomcat not found/i.test(t)) {
      return `**Diagnosis:** The built artifact (or Tomcat) needed to launch wasn't found.\n\n` +
        `- Run setup/build first so the \`.war\`/\`.jar\` exists, then launch.\n` +
        `- If you only pulled latest, rebuild with \`mvn clean install -DskipTests\`.`;
    }
    return `**Diagnosis:** The app failed to launch.${(() => { const e = extractErrors(t); return e.length ? `\n\n**Key errors from the log:**\n\`\`\`\n${e.join('\n')}\n\`\`\`` : ''; })()}\n\n` +
      `- Check the stack trace above for the first exception.\n` +
      `- Verify AWS credentials (**Settings → AWS**) and that the build succeeded.`;
  }

  // ── Maven module / directory mismatch (uses real on-disk context) ──────────
  if (repoCtx) {
    // Find modules declared in pom.xml but whose directories are MISSING on disk
    const missing = [...repoCtx.matchAll(/module "([^"]+)" → dir MISSING/g)].map(m => m[1]);
    if (missing.length) {
      // Check if the log error mentions any of those missing module paths
      const mentioned = missing.filter(m => t.includes(m));
      const target = mentioned.length ? mentioned : missing;

      // Look for an existing directory that matches the module name (different path)
      const existingDirs = [...repoCtx.matchAll(/module "([^"]+)" → dir EXISTS/g)].map(m => m[1]);
      const suggestions = target.map(mod => {
        // Try to find a matching module by artifactId in the context
        const altMatch = repoCtx.match(new RegExp(`module "([^"]+)" → dir EXISTS.*?artifactId: ${mod.replace(/[-/]/g, '[-/]')}`, 's'));
        const alt = altMatch ? altMatch[1] : existingDirs.find(d => d.includes(mod.split('-').pop()) || mod.includes(d.split('/').pop()));
        return alt
          ? `\`${mod}\` → directory missing, but found at \`${alt}\` — check the \`<module>\` path in \`pom.xml\``
          : `\`${mod}\` → directory is missing from the repo`;
      });

      return `**Diagnosis:** Maven module path mismatch — declared in \`pom.xml\` but directory not found.\n\n` +
        suggestions.map(s => `- ${s}`).join('\n') + '\n\n' +
        `- Open the parent \`pom.xml\` and correct the \`<module>\` path to match the actual directory.\n` +
        `- Or skip the missing module temporarily:\n\`\`\`\nmvn clean install -pl \'!${target[0]}\'\n\`\`\``;
    }
  }

  // ── Mac password not provided ──────────────────────────────────────────────
  if (/(Could not obtain administrator access|sudo.*password|Administrator access is required|dl_prime_sudo)/i.test(t)) {
    return `**Diagnosis:** Setup needs your Mac login password to run \`sudo\` commands.\n\n` +
      `- Open **Settings** (top-right) → scroll to **Mac Password** → enter your login password and click **Verify**.\n` +
      `- Check **Save password on this device** so you won't be prompted again.\n` +
      `- Then click **↻ Retry**.`;
  }
  const cmdMatch = t.match(/(?:^|\s)([\w.-]+): command not found/) ||
                   t.match(/command not found: ([\w.-]+)/) ||
                   t.match(/([\w.-]+): No such file or directory[\s\S]*?exec/);
  const errBlock = () => {
    const e = extractErrors(t);
    return e.length ? `\n\n**Key errors from the log:**\n\`\`\`\n${e.join('\n')}\n\`\`\`` : '';
  };

  // ── Maven / Java build failures ──────────────────────────────────────────
  if (/COMPILATION ERROR|cannot find symbol|\[ERROR\].*\.java:\[\d+/i.test(t)) {
    return `**Diagnosis:** Java compilation failed.${errBlock()}\n\n` +
      `- Fix the compile errors shown above (missing import/symbol, syntax).\n` +
      `- Make sure the right **JDK** is active (set **Java Home** in Settings if needed).`;
  }
  if (/(There are test failures|Failed tests:|Tests run:.*Failures: [1-9]|BUILD FAILURE[\s\S]*surefire)/i.test(t)) {
    return `**Diagnosis:** The Maven build failed on **tests**.${errBlock()}\n\n` +
      `- To set up without running tests, add \`-DskipTests\` to **Maven Args** in Settings, then Retry.\n` +
      `- Or fix the failing tests listed above.`;
  }
  if (/(OutOfMemoryError|Java heap space|GC overhead limit)/i.test(t)) {
    return `**Diagnosis:** Maven ran out of memory.\n\n` +
      `- Increase the heap: set \`MAVEN_OPTS=-Xmx2g\` (add it under Extra Env Vars in Settings), then Retry.`;
  }
  if (/(invalid target release|release version .* not supported|Source option .* no longer supported|Unsupported class file major version|No compiler is provided|tools\.jar)/i.test(t)) {
    return `**Diagnosis:** JDK version mismatch (or a JRE is being used instead of a JDK).${errBlock()}\n\n` +
      `- Point **Java Home** in Settings at the JDK version the project needs.\n` +
      `- Find installed JDKs with \`/usr/libexec/java_home -V\`.`;
  }

  if (cmdMatch || /Exit code 127/.test(t)) {
    const cmd = cmdMatch ? cmdMatch[1] : 'the required tool';
    return `**Diagnosis:** \`${cmd}\` isn't on the app's PATH.\n\n` +
      `- OASIS (launched from the dock) may not see tools installed in custom/Homebrew/SDKMAN dirs.\n` +
      `- Confirm it's installed: run \`which ${cmd}\` in Terminal.\n` +
      `- If installed, the app's PATH resolution should pick it up — restart OASIS.\n` +
      `- If missing, install it (e.g. \`brew install ${cmd}\`) or set its location in **Settings**.`;
  }
  if (/JAVA_HOME/.test(t) && /(not set|invalid|No such)/i.test(t)) {
    return `**Diagnosis:** \`JAVA_HOME\` is unset or wrong.\n\n` +
      `- Set **Java Home** in OASIS **Settings** to your JDK path.\n` +
      `- Find it with \`/usr/libexec/java_home\`.`;
  }
  if (/(Non-resolvable|Could not resolve dependencies|Failed to (read|collect).*dependencies|Cannot access .* in offline mode|Could not transfer artifact)/i.test(t)) {
    return `**Diagnosis:** Maven couldn't resolve dependencies.\n\n` +
      `- Check you're on **VPN** and can reach the internal Nexus/artifact repo.\n` +
      `- Verify your \`~/.m2/settings.xml\` has the right mirror/credentials.\n` +
      `- Retry — transient registry/network errors are common.`;
  }
  if (/(Authentication failed|could not read Username|Permission denied \(publickey\)|Invalid username or password|fatal: Authentication|403 Forbidden)/i.test(t)) {
    return `**Diagnosis:** Git authentication to GitHub Enterprise failed.\n\n` +
      `- Your **PAT** may be expired or missing scope — regenerate one with \`repo\` (or Contents: Read) access.\n` +
      `- Update it in **Settings**, then **Retry**.`;
  }
  if (/(repository .* not found|fatal: repository|Could not read from remote repository)/i.test(t)) {
    return `**Diagnosis:** The repository couldn't be reached.\n\n` +
      `- Confirm the repo name and that your PAT can access it.\n` +
      `- Check VPN / GitHub Enterprise connectivity.`;
  }
  if (/(EADDRINUSE|address already in use)/i.test(t)) {
    return `**Diagnosis:** A required port is already in use.\n\n` +
      `- Another process/instance is bound to it — stop it, or change the port in the project config.`;
  }
  if (/ERESOLVE|unable to resolve dependency tree|peer dep/i.test(t)) {
    return `**Diagnosis:** npm dependency conflict (peer deps).\n\n` +
      `- Try installing with \`npm install --legacy-peer-deps\`.\n` +
      `- Or align the conflicting package versions.`;
  }
  if (/(getaddrinfo ENOTFOUND|Could not resolve host|ETIMEDOUT|Connection refused|Network is unreachable)/i.test(t)) {
    return `**Diagnosis:** Network/connectivity problem.\n\n` +
      `- Check your **VPN** and that internal hosts (GitHub Enterprise, Nexus) are reachable.\n` +
      `- Retry once connected.`;
  }
  if (/(Unsupported class file major version|compiled by a more recent version of the Java)/i.test(t)) {
    return `**Diagnosis:** JDK version mismatch.\n\n` +
      `- The project needs a different Java version. Point **Java Home** in Settings at the required JDK.`;
  }
  // Fallback
  const lang = language ? ` (${language})` : '';
  return `**Couldn't pinpoint the cause automatically${lang}.**\n\n` +
    `- Expand the **Logs** and look for the first \`ERROR\`/\`command not found\`/\`fatal\` line.\n` +
    `- Verify required tools are installed and on PATH, and that you're on VPN.\n` +
    `- Fix the issue, then click **Retry**.`;
}

// AI-powered analyzer, using whatever provider is configured in Settings.
// Only called when a provider/model is configured.
async function bedrockSuggest({ repo, language, logs, repoCtx, phase }, sess) {
  const ai = aiClientFor(sess);
  if (!ai.available()) throw new Error('AI not configured');

  const system = `You are a senior engineer diagnosing a ${language} build failure in repository ${repo}.
Return only a short paragraph (2-4 sentences) describing the root cause and the fix.`;
  const userText = `${repoCtx ? `Project: ${repoCtx}\n\n` : ''}Phase: ${phase}\n\nBuild output (tail):\n${logs}`;

  return ai.complete({ messages: [{ role: 'user', content: userText }], system, maxTokens: 1024 });
}

// A clone is "usable" only if it's a git work tree with at least one commit
// reachable from HEAD. An interrupted clone leaves a .git with no refs/commits,
// which is not usable and must be re-cloned rather than pulled into.
function isUsableGitRepo(dir) {
  try {
    if (!fs.existsSync(path.join(dir, '.git'))) return false;
    execSync('git rev-parse --verify HEAD', { cwd: dir, stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

// ── Core setup runner ─────────────────────────────────────────────────────
async function runSetup(sessionId, sess, repo, options) {
  const jobId = repo.name;

  // Tell the UI exactly how many steps this job will emit so the progress bar
  // moves smoothly instead of sitting at 18% (1/5) for the whole build.
  // Dedicated script repos: clone + script [+ ide] = 2 or 3 steps.
  // Auto-detected repos vary (maven=2, js=2-3, ruby=3, python=1), but those
  // never had the "stuck at 18%" problem — only dedicated-script repos do.
  const hasDedicatedScript = !!detectScript(repo.name);
  const stepCount = hasDedicatedScript
    ? (options.intellij ? 3 : 2)
    : 5;  // keep legacy value for auto-detect; accurate counts could be added later

  broadcast(sessionId, { type: 'job_start', jobId, repo: repo.name, stepCount });

  const cloneDir = path.join(expandHome(sess.cloneDir), repo.name);
  const authedUrl = sess.githubUrl.replace(/\/$/, '') +
    `/${sess.org}/${repo.name}.git`;
  const tokenUrl = authedUrl.replace('https://', `https://${sess.token}@`);

  try {
    // ── Step 1: Clone or pull ──────────────────────────────────────────
    const gitEnv = buildEnv(sess, cloneDir);
    const alreadyCloned = isUsableGitRepo(cloneDir);
    const cloneStepLabel = alreadyCloned ? 'Pulling latest changes' : 'Cloning repository';
    await runStep(sessionId, jobId, 'clone', cloneStepLabel, async () => {
      // Only `git pull` when there's a *usable* clone (at least one commit). A
      // previous clone that was interrupted (e.g. the app was killed) leaves a
      // bare ".git" on HEAD→master with no refs; fs.existsSync would be true but
      // a pull into it fails, so the repo would be stuck "empty" forever. Treat
      // any non-usable directory as a fresh clone: remove it and re-clone.
      if (alreadyCloned) {
        externalCalls.assertAllowed('GitHub');
        await sh(`git -C "${cloneDir}" pull "${tokenUrl}" ${repo.default_branch}`, sessionId, jobId, { env: gitEnv });
      } else {
        externalCalls.assertAllowed('GitHub');
        if (fs.existsSync(cloneDir)) {
          log(sessionId, jobId, 'warn', `Existing ${cloneDir} is not a complete clone (likely an interrupted run) — re-cloning.`);
          fs.rmSync(cloneDir, { recursive: true, force: true });
        }
        // Shallow, single-branch clone. iready-core is huge: one branch alone is
        // ~620k objects (~2 GB of history), and over the throttled corp tunnel
        // (~0.5 MB/s) a full clone takes ~an hour and frequently resets — which
        // is what made setup look "stuck". A repo can also have hundreds of
        // branches (iready-core has ~270), so --single-branch avoids dragging in
        // all of them. --depth 1 fetches only the latest revision, which is all
        // setup needs to build: the working tree is complete and the build's
        // buildnumber plugin (git rev-parse HEAD / branch name) works on a
        // shallow clone. Devs who later need history can `git fetch --unshallow`.
        externalCalls.assertAllowed('GitHub');
        const cloneCmd =
          `git clone --depth 1 --single-branch --branch ${repo.default_branch} "${tokenUrl}" "${cloneDir}"`;
        // The tunnel occasionally drops mid-clone. git removes the partial target
        // on failure, so a clean retry is safe; try a few times before giving up.
        let cloneErr;
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            await sh(cloneCmd, sessionId, jobId, { env: gitEnv });
            cloneErr = null;
            break;
          } catch (e) {
            cloneErr = e;
            if (attempt < 3) {
              log(sessionId, jobId, 'warn', `Clone attempt ${attempt} failed (${e.message}) — retrying…`);
              fs.rmSync(cloneDir, { recursive: true, force: true });
            }
          }
        }
        if (cloneErr) throw cloneErr;
      }
    });

    // ── Step 2: Detect & run setup script ─────────────────────────────
    //
    // resolveScript rather than detectScript: the resolved object carries which
    // interpreter runs this file and whether that interpreter exists, and both
    // are needed to build the command.
    const resolvedSetup = resolveScript(repo.name);
    if (resolvedSetup && !resolvedSetup.available) {
      // A script IS here, and nothing on this machine can run it. Said out loud
      // and the step skipped, rather than the setup quietly finishing without
      // having done the part that matters.
      log(sessionId, jobId, 'warn', `Skipping ${resolvedSetup.name}: ${resolvedSetup.hint}`);
    } else if (resolvedSetup) {
      await runStep(sessionId, jobId, 'script', `Running ${resolvedSetup.name}`, async () => {
        const env = buildEnv(sess, cloneDir);
        // Run with xtrace + a distinctive PS4 so we can surface each command the
        // script executes (mvn clean install, cp, etc.) in the UI.
        env.PS4 = TRACE_PS4;
        // -x tracing is a bash feature; a PowerShell script gets its output
        // without it rather than being handed a flag its interpreter rejects.
        const { line, trace } = commandLineFor(resolvedSetup.resolved, [cloneDir], { trace: true });
        await sh(line, sessionId, jobId, { env, trace });
      });
    } else {
      // Auto-detect from project type
      await runAutoSetup(sessionId, jobId, sess, repo, cloneDir);
    }

    // ── Step 3: Open in IDE ───────────────────────────────────────────
    if (options.intellij) {
      await runStep(sessionId, jobId, 'ide', 'Opening in IntelliJ IDEA', async () => {
        const cmd = ideaOpenCommand(sess.intellijPath, cloneDir);
        try {
          await sh(cmd, sessionId, jobId);
        } catch (e) {
          // Don't fail the whole setup just because the IDE couldn't launch
          log(sessionId, jobId, 'warn', `Could not open IntelliJ IDEA (${e.message}). ` +
            `Set the IntelliJ CLI path in Settings, or create the launcher via IDEA → Tools → Create Command-line Launcher.`);
        }
      });
    }

    broadcast(sessionId, { type: 'job_done', jobId, success: true });
  } catch (err) {
    // If the failure looks sudo-related, ask the frontend to re-collect the password.
    if (isSudoError(err.message)) {
      broadcast(sessionId, { type: 'sudo_required', jobId, reason: 'Password expired or incorrect — re-enter your Mac password to continue.' });
    }
    broadcast(sessionId, { type: 'job_done', jobId, success: false, error: err.message });
  }
}

function isSudoError(msg) {
  return /incorrect password|sudo.*failed|sorry.*try again|password.*incorrect|authentication failure/i.test(msg);
}

/**
 * Resolve which setup script a repo should run.
 * Resolution order (first match wins):
 *   1. scripts/<repo-name>.sh        — repo has its own script (dedicated)
 *   2. scripts/<repo-name>/setup.sh  — repo folder form (dedicated, legacy)
 *   3. scripts/setup.sh              — the default, used by everything else
 * Returns { path, name, dedicated } or null if nothing exists.
 */

// Shared repo enrichment: adds script-resolution fields to a raw GitHub repo object.
function enrichRepo(r) {
  const resolved = resolveScript(r.name);
  const launch   = resolveLaunchScript(r.name);
  return {
    id:             r.id,
    name:           r.name,
    full_name:      r.full_name,
    description:    r.description || '',
    language:       r.language || 'Unknown',
    updated_at:     r.updated_at,
    default_branch: r.default_branch,
    private:        r.private,
    topics:         r.topics || [],
    size:           r.size,
    clone_url:      r.clone_url,
    html_url:       r.html_url,
    _hasScript:     !!resolved?.dedicated,
    _script:        resolved?.name || null,
    _scriptDefault: resolved ? !resolved.dedicated : false,
    _hasLaunch:     !!launch,
    _launchLabel:   launch?.label || null,
  };
}

// A repo gets a Launch button only when it ships a dedicated launch script at
// scripts/<repo>.launch.sh. Libraries/shared modules (no entry point) simply
// don't have one, so no button is shown. The optional
// "# oasis-launch-label: …" header customises the button text.
// Where scripts are looked for, in order.
//
//   1. SCRIPTS_DIR      — what ships with the app (or OASIS_SCRIPTS_DIR)
//   2. <cloneDir>/oasis-scripts — a team's own directory, checked out beside
//                          their repositories
//
// Bundled first, so a shipped script is what runs unless it is missing. Worth
// knowing if you are adding one: under this order a bundled script always wins,
// so overriding one means renaming or removing it rather than shadowing it.
//
// The base directory is read the same way resolveRepoPath reads it — from any
// session that has one. This is a single-user desktop app, so "any session" and
// "the session" are the same thing, and the alternative is threading a session
// through every resolver that never needed one.
const FALLBACK_SCRIPTS_DIRNAME = 'oasis-scripts';

// A single path segment naming a repository, and nothing that can leave the
// directory it is joined to.
function isPlainName(name) {
  const value = String(name == null ? '' : name);
  if (!value || value === '.' || value === '..') return false;
  if (!/^[A-Za-z0-9._-]+$/.test(value)) return false;
  // path.win32.basename catches a backslash even when running on POSIX, so a
  // Windows-style traversal cannot slip through a Mac-hosted check.
  return path.basename(value) === value && path.win32.basename(value) === value;
}

// Defence in depth: whatever a name resolves to must still be inside the root
// it was joined to. The name check above should make this unreachable, and it
// is here precisely because "should be unreachable" is how traversals ship.
function isInsideRoot(root, candidate) {
  const rel = path.relative(path.resolve(root), path.resolve(candidate));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

// Where the scripts came from, and — when the fallback is a git checkout —
// which revision of them is in use.
//
// A team's oasis-scripts directory is usually a clone, so "my setup behaves
// differently from yours" is very often "you have not pulled". Reporting the
// revision turns that from a debugging session into a glance.
function scriptRootStatus() {
  return scriptRoots().map(dir => {
    const exists = fs.existsSync(dir);
    const status = { path: dir, exists, bundled: dir === SCRIPTS_DIR, revision: null, dirty: null };
    if (!exists || !fs.existsSync(path.join(dir, '.git'))) return status;

    try {
      const { execFileSync } = require('child_process');
      const run = args => execFileSync('git', args, { cwd: dir, encoding: 'utf8', timeout: 5000 }).trim();
      status.revision = run(['rev-parse', '--short', 'HEAD']);
      status.branch = run(['rev-parse', '--abbrev-ref', 'HEAD']);
      // Uncommitted local edits explain a difference no pull will fix.
      status.dirty = run(['status', '--porcelain']).length > 0;
    } catch (_) {
      // A checkout we cannot read is still a usable script directory.
    }
    return status;
  });
}

function scriptRoots() {
  const roots = [SCRIPTS_DIR];

  if (process.env.OASIS_SCRIPTS_FALLBACK_DIR) {
    roots.push(expandHome(process.env.OASIS_SCRIPTS_FALLBACK_DIR));
    return roots;
  }

  const sess = Object.values(sessions).find(s => s && s.cloneDir);
  const base = expandHome(sess?.cloneDir || '~/dev/projects');
  roots.push(path.join(base, FALLBACK_SCRIPTS_DIRNAME));
  return roots;
}

// The launch button's label, from a header comment in the script.
//
// The comment leader differs by language — `#` for shell and PowerShell, `REM`
// or `::` for cmd — so all of them are accepted rather than only the shell one.
function launchLabelFrom(scriptPath) {
  try {
    const head = fs.readFileSync(scriptPath, 'utf8').split('\n', 15);
    const m = head.find(l => /(?:#|REM|::|\/\/)\s*oasis-launch-label:/i.test(l));
    if (m) return m.replace(/.*oasis-launch-label:\s*/i, '').trim() || 'Launch';
  } catch (_) { /* ignore */ }
  return 'Launch';
}

// A repo gets a Launch button only when it ships scripts/<repo>.launch.<ext>
// for an extension this machine can actually run. Libraries with no entry
// point simply have none, so no button appears.
function resolveLaunchScript(repoName) {
  const found = findScriptIn(scriptRoots(), `${repoName}.launch`);
  if (!found) return null;
  return {
    path: found.path,
    name: path.basename(found.path),
    label: launchLabelFrom(found.path),
    // Carried through so the caller can offer the button in a disabled state
    // with the reason, rather than silently hiding a script that exists.
    available: found.available,
    hint: found.hint,
    resolved: found,
  };
}

function resolveScript(repoName) {
  // 1. Flat repo-specific script: <root>/<repo-name>.<ext>
  const flat = findScriptIn(scriptRoots(), repoName);
  if (flat) return { path: flat.path, name: path.basename(flat.path), dedicated: true, available: flat.available, hint: flat.hint, resolved: flat };

  // 2. Folder repo-specific script: <root>/<repo-name>/setup.<ext>
  const folder = findScriptIn(scriptRoots().map(r => path.join(r, repoName)), 'setup');
  if (folder) return { path: folder.path, name: `${repoName}/${path.basename(folder.path)}`, dedicated: true, available: folder.available, hint: folder.hint, resolved: folder };

  // 3. Default catch-all: <root>/setup.<ext>
  const generic = findScriptIn(scriptRoots(), 'setup');
  if (generic) return { path: generic.path, name: path.basename(generic.path), dedicated: false, available: generic.available, hint: generic.hint, resolved: generic };

  return null;
}

function detectScript(repoName) {
  return resolveScript(repoName)?.path || null;
}

async function runAutoSetup(sessionId, jobId, sess, repo, cloneDir) {
  const lang = (repo.language || '').toLowerCase();

  if (lang === 'java') {
    const mvnArgs = sess.mavenArgs || '-DskipTests';
    await runStep(sessionId, jobId, 'maven', 'Running Maven build', async () => {
      await sh(`cd "${cloneDir}" && mvn clean install ${mvnArgs}`, sessionId, jobId);
    });
  } else if (lang === 'javascript' || lang === 'typescript') {
    const pm = fs.existsSync(path.join(cloneDir, 'yarn.lock')) ? 'yarn' :
               fs.existsSync(path.join(cloneDir, 'pnpm-lock.yaml')) ? 'pnpm' : 'npm';
    await runStep(sessionId, jobId, 'install', `Installing dependencies (${pm})`, async () => {
      await sh(`cd "${cloneDir}" && ${pm} install`, sessionId, jobId);
    });
    if (fs.existsSync(path.join(cloneDir, '.env.example')) && !fs.existsSync(path.join(cloneDir, '.env'))) {
      await runStep(sessionId, jobId, 'env', 'Setting up .env', async () => {
        fs.copyFileSync(path.join(cloneDir, '.env.example'), path.join(cloneDir, '.env'));
        if (sess.extraEnv) fs.appendFileSync(path.join(cloneDir, '.env'), '\n' + sess.extraEnv);
        log(sessionId, jobId, 'ok', '.env configured');
      });
    }
  } else if (lang === 'ruby') {
    await runStep(sessionId, jobId, 'bundle', 'Bundle install', async () => {
      await sh(`cd "${cloneDir}" && bundle install`, sessionId, jobId);
    });
    await runStep(sessionId, jobId, 'db', 'Database setup', async () => {
      await sh(`cd "${cloneDir}" && bundle exec rails db:setup`, sessionId, jobId);
    });
  } else if (lang === 'python') {
    await runStep(sessionId, jobId, 'venv', 'Creating virtual environment', async () => {
      await sh(`python3 -m venv "${cloneDir}/venv"`, sessionId, jobId);
      await sh(`"${cloneDir}/venv/bin/pip" install -r "${cloneDir}/requirements.txt"`, sessionId, jobId);
    });
  } else {
    log(sessionId, jobId, 'warn', `No setup script found for language: ${repo.language || 'unknown'}. Skipping.`);
  }
}

async function runStep(sessionId, jobId, stepId, label, fn) {
  broadcast(sessionId, { type: 'step_start', jobId, stepId, label });
  log(sessionId, jobId, 'info', `▶ ${label}`);
  await fn();
  broadcast(sessionId, { type: 'step_done', jobId, stepId });
}

function log(sessionId, jobId, level, message) {
  enqueueLog(sessionId, { jobId, level, message, ts: Date.now() });
  // If the script signals it couldn't get a sudo password, prompt the UI immediately.
  // broadcast() flushes the pending log buffer first, so the line above is
  // delivered before this event.
  if (/Could not obtain administrator access|Administrator access is required/i.test(message)) {
    broadcast(sessionId, {
      type: 'sudo_required',
      jobId,
      reason: 'This setup needs your Mac login password to run administrator commands. Enter it in Settings → Mac Password, then Retry.',
    });
  }
}

/**
 * Build the command used to open a project in IntelliJ IDEA.
 *  - If the user configured an explicit CLI path, use it.
 *  - Otherwise prefer the `idea` launcher on PATH, then fall back to macOS `open`.
 */
function ideaOpenCommand(intellijPath, dir) {
  if (intellijPath) {
    // A configured value may be the `idea` CLI launcher OR an .app bundle path.
    return intellijPath.endsWith('.app')
      ? `open -a "${intellijPath}" "${dir}"`
      : `"${intellijPath}" "${dir}"`;
  }
  if (process.platform === 'darwin') {
    // Try the `idea` CLI (caller augments PATH with Toolbox/Homebrew dirs), then
    // each edition's app bundle by name, then the JetBrains bundle id as a last
    // resort. `2>/dev/null` keeps "command not found" noise out; the `||` chain
    // stops at the first launcher that exists.
    return [
      `idea "${dir}"`,
      `open -a "IntelliJ IDEA" "${dir}"`,
      `open -a "IntelliJ IDEA Ultimate" "${dir}"`,
      `open -a "IntelliJ IDEA CE" "${dir}"`,
      `open -b com.jetbrains.intellij "${dir}"`,
    ].map(c => `${c} 2>/dev/null`).join(' || ');
  }
  return `idea "${dir}"`;
}

function buildEnv(sess, cloneDir) {
  const env = {
    ...process.env,
    CLONE_DIR: cloneDir,
    GIT_TERMINAL_PROMPT: '0',
    GIT_ASKPASS: 'echo',
    // Tell dl_prime_sudo to never show a GUI dialog — the OASIS UI
    // collects the Mac password instead (via Settings or the password modal).
    OASIS_NO_DIALOG: '1',
  };
  // Pass the Mac login password so dl_prime_sudo uses it silently.
  if (sess.sudoPassword) env.OASIS_SUDO_PW = sess.sudoPassword;
  // FIFO for live password handoff if a script asks for sudo mid-run.
  if (sess._sudoFifo) env.OASIS_SUDO_FIFO = sess._sudoFifo;
  if (sess.intellijPath) env.INTELLIJ_PATH = sess.intellijPath;
  if (sess.mavenArgs)    env.MAVEN_ARGS    = sess.mavenArgs;
  // The user's chosen AWS profile drives credential resolution in the launch
  // scripts (scripts/lib/aws-creds.sh → AWS_PROFILE). Each developer picks their
  // own in Settings; we don't hardcode one.
  if (sess.awsProfile)   env.AWS_PROFILE   = sess.awsProfile;
  if (sess.extraEnv) {
    sess.extraEnv.split('\n').forEach(line => {
      const [k, ...v] = line.split('=');
      if (k && v.length) env[k.trim()] = v.join('=').trim();
    });
  }
  return env;
}

function sh(cmd, sessionId, jobId, opts = {}) {
  return new Promise((resolve, reject) => {
    log(sessionId, jobId, 'cmd', '$ ' + cmd.replace(/https:\/\/[^@]+@/, 'https://***@'));
    const proc = spawnBash(['-c', cmd], {
      env: opts.env || process.env,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    // Buffer partial lines: a chunk may end mid-line, so keep the remainder
    // until the next chunk completes it. Emit on either a newline *or* a
    // carriage return — git (clone/fetch/checkout) reports progress as
    // "Receiving objects: 42%\r" with no newline until the very end, so a
    // newline-only split would buffer the whole download and the UI would look
    // frozen. Treating \r as a delimiter streams that progress live.
    // Strip ANSI escape codes so Maven/npm colour output renders cleanly in the terminal.
    const stripAnsi = s => s.replace(/\x1B\[[0-9;]*[mGKHFABCDJST]/g, '').replace(/\r/g, '');

    const makeLineHandler = (onLine) => {
      let buf = '';
      const onData = (d) => {
        buf += d.toString();
        const parts = buf.split(/\r\n|\r|\n/);
        buf = parts.pop();           // last element is the incomplete line (or '')
        parts.forEach(l => onLine(stripAnsi(l)));
      };
      const flush = () => { if (buf.length) { onLine(stripAnsi(buf)); buf = ''; } };
      return { onData, flush };
    };

    // stderr handler. When tracing, bash xtrace lines (prefixed with our PS4
    // marker) are surfaced as the executed command + a live step label; all
    // other stderr is logged normally. (macOS bash 3.2 has no BASH_XTRACEFD,
    // so trace must be parsed out of stderr.)
    const onErrLine = (l) => {
      if (opts.capture) opts.capture.push(l);
      if (opts.trace && TRACE_RE.test(l)) {
        const cleaned = l.replace(TRACE_RE, '').trim();
        if (!cleaned) return;
        log(sessionId, jobId, 'cmd', cleaned);
        if (TRACE_TOP_RE.test(l)) {  // top-level command (single marker) → show in label
          broadcast(sessionId, { type: 'step_label', jobId, label: 'Running: ' + truncate(cleaned, 90) });
        }
      } else {
        log(sessionId, jobId, 'err', l);
      }
    };

    const out = makeLineHandler(l => { if (opts.capture) opts.capture.push(l); log(sessionId, jobId, 'out', l); });
    const err = makeLineHandler(onErrLine);
    proc.stdout.on('data', out.onData);
    proc.stderr.on('data', err.onData);

    // Finalize once, whether we get there via 'close' (stdio fully drained) or
    // the 'exit' fallback below.
    let finished = false;
    const finalize = (code) => {
      if (finished) return;
      finished = true;
      proc.stdout.removeListener('data', out.onData);
      proc.stderr.removeListener('data', err.onData);
      out.flush();                   // emit any trailing partial line
      err.flush();
      code === 0 ? resolve() : reject(new Error(`Exit code ${code}`));
    };

    proc.on('close', code => finalize(code));

    // Fallback: 'close' only fires once *all* stdio pipes are closed. A setup
    // script may launch a detached GUI/daemon (e.g. IntelliJ, Tomcat) that
    // inherits this child's stdout/stderr and holds the pipe open for its whole
    // lifetime — so 'close' would never fire and the job would hang at "done".
    // 'exit' fires as soon as the bash process itself terminates; give stdio a
    // brief moment to drain the already-written output, then finalize anyway.
    proc.on('exit', code => { setTimeout(() => finalize(code), 200); });
  });
}

function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

/**
 * Find the open PR whose head branch is `branch`, robust to GitHub Enterprise quirks.
 *
 * GitHub's `head=<owner>:<ref>` list filter compares the owner login
 * CASE-SENSITIVELY against the PR's canonical `head.label`. Repo paths
 * (`/repos/<owner>/<repo>`) and Jenkins job folders resolve case-insensitively,
 * so if the configured org casing differs from the canonical org login (e.g.
 * user typed `iready` but the org is `iReady`), the filtered query silently
 * returns zero PRs even though one exists. To stay correct regardless, we try
 * the fast filtered query first, then fall back to scanning open PRs and
 * matching `head.ref` case-insensitively (owner ignored).
 *
 * Returns the raw PR object or null.
 */
// Describe an axios/GitHub failure in actionable terms. The common enterprise
// case is a 404 on a repo endpoint with a VALID token — GitHub returns 404
// (not 403) for private repos a token can't see, which almost always means the
// PAT is missing the `repo` scope or hasn't been SSO-authorized for the org.
function ghErrInfo(e) {
  const s = e.response?.status;
  if (s === 404) return "repo not visible to this token — your GitHub PAT likely lacks the 'repo' scope (or isn't SSO-authorized for the org)";
  if (s === 401) return 'GitHub token is invalid or expired — re-enter your PAT in Settings';
  if (s === 403) return 'GitHub denied the request (rate limit or insufficient permissions) — check the token scope';
  const m = e.response?.data?.message || e.code || e.message || 'error';
  return s ? `HTTP ${s} — ${m}` : m;
}

async function findOpenPrForBranch({ apiBase, org, repo, branch, headers }) {
  if (!branch) return null;
  let lastErr = null;

  // Fast path — server-side head filter (works when org casing matches). A
  // failure here is non-fatal: fall through to the fallback scan, which may
  // still succeed (e.g. on an org-casing mismatch in the head= filter).
  const fastUrl = `${apiBase}/repos/${org}/${repo}/pulls?state=open&per_page=10&head=${encodeURIComponent(org + ':' + branch)}`;
  try {
    const r = await axios.get(fastUrl, { headers, timeout: 8000 });
    if (Array.isArray(r.data) && r.data.length) return r.data[0];
  } catch (e) {
    lastErr = e;
    console.error(`[pr] GET ${fastUrl} → ${ghErrInfo(e)}`);
  }

  // Fallback — list open PRs and match the head ref ignoring owner + case.
  const branchLc = branch.toLowerCase();
  for (let page = 1; page <= 3; page++) {
    const scanUrl = `${apiBase}/repos/${org}/${repo}/pulls?state=open&per_page=100&page=${page}&sort=updated&direction=desc`;
    let data;
    try {
      const r = await axios.get(scanUrl, { headers, timeout: 8000 });
      data = r.data;
      lastErr = null;   // a page came back — this isn't an access failure
    } catch (e) {
      lastErr = e;
      console.error(`[pr] GET ${scanUrl} → ${ghErrInfo(e)}`);
      break;
    }
    if (!Array.isArray(data) || !data.length) break;
    const hit = data.find(pr => ((pr.head && pr.head.ref) || '').toLowerCase() === branchLc);
    if (hit) return hit;
    if (data.length < 100) break; // last page
  }

  // No PR found. If every GitHub call errored (token scope / rate-limit /
  // network), surface it so the UI shows WHY rather than a bare "no PR".
  if (lastErr) { const err = new Error(ghErrInfo(lastErr)); err.isPrLookupError = true; throw err; }
  return null;
}

async function findMergedPrForBranch({ apiBase, org, repo, branch, headers }) {
  if (!branch) return null;
  const branchLc = branch.toLowerCase();
  try {
    const r = await axios.get(
      `${apiBase}/repos/${org}/${repo}/pulls?state=closed&per_page=20&head=${encodeURIComponent(org + ':' + branch)}&sort=updated&direction=desc`,
      { headers, timeout: 8000 });
    if (Array.isArray(r.data)) {
      const hit = r.data.find(pr => pr.merged_at && ((pr.head && pr.head.ref) || '').toLowerCase() === branchLc);
      if (hit) return hit;
    }
  } catch (_) {}
  // Fallback: scan recent closed PRs
  try {
    const r = await axios.get(
      `${apiBase}/repos/${org}/${repo}/pulls?state=closed&per_page=50&sort=updated&direction=desc`,
      { headers, timeout: 8000 });
    if (Array.isArray(r.data)) {
      return r.data.find(pr => pr.merged_at && ((pr.head && pr.head.ref) || '').toLowerCase() === branchLc) || null;
    }
  } catch (_) {}
  return null;
}

/**
 * GET /api/pull-status?session=SID&repos=name1,name2
 * For each cloned repo, git-fetches from origin and returns how many commits
 * it is behind the upstream. Repos not yet cloned are flagged as such.
 */
app.get('/api/pull-status', async (req, res) => {
  const { session, repos: reposParam, force } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  if (!sess._pullCache) sess._pullCache = {};

  const names   = String(reposParam || '').split(',').filter(Boolean);
  const results = {};
  const toFetch = [];

  for (const name of names) {
    const hit = sess._pullCache[name];
    if (hit && !force && (Date.now() - hit.ts) < CACHE_TTL_MS) {
      results[name] = hit.data;
    } else {
      toFetch.push(name);
    }
  }

  await Promise.all(toFetch.map(async (name) => {
    const cloneDir = path.join(expandHome(sess.cloneDir), name);
    if (!fs.existsSync(cloneDir)) {
      const data = { cloned: false };
      results[name] = data;
      sess._pullCache[name] = { data, ts: Date.now() };
      return;
    }
    try {
      // Repos are cloned via SSH — use the existing 'origin' remote so the
      // system SSH key works. Building an HTTPS token URL fails for SSH remotes.
      externalCalls.assertAllowed('GitHub');
      await execQuiet(`git -C "${cloneDir}" fetch --quiet origin`, { timeout: 30000 });
      const behind = await execQuiet(`git -C "${cloneDir}" rev-list HEAD..@{u} --count`, { timeout: 8000 });
      const data = { cloned: true, behind: parseInt(behind) || 0 };
      results[name] = data;
      sess._pullCache[name] = { data, ts: Date.now() };
    } catch (e) {
      // rev-list fails if no upstream is set — fall back to FETCH_HEAD
      try {
        const behind = await execQuiet(`git -C "${cloneDir}" rev-list HEAD..FETCH_HEAD --count`, { timeout: 8000 });
        const data = { cloned: true, behind: parseInt(behind) || 0 };
        results[name] = data;
        sess._pullCache[name] = { data, ts: Date.now() };
      } catch (e2) {
        const data = { cloned: true, behind: 0, fetchError: e.message?.slice(0, 100) };
        results[name] = data;
        sess._pullCache[name] = { data, ts: Date.now() };
      }
    }
  }));

  res.json(results);
});

// Recognize CI/service/bot commit authors so they can be excluded from the
// "top contributors" chips (a Slack link to a bot is useless). Matches common
// markers in the author name OR email; word boundaries avoid false hits on real
// names (e.g. "Abbott", "Talbot"). buildmaster is CA's CI account.
function isBotContributor(name, email) {
  const s = `${name || ''} ${email || ''}`.toLowerCase();
  return /\bbuildmaster\b|\[bot\]|\bbot\b|dependabot|github-actions|renovate|no-?reply|noreply|jenkins|service-?account|\bsvc\b|automation|\brobot\b/.test(s);
}

// ── Slack DM links for contributors ──────────────────────────────────────────
// Resolve a contributor's git email to their Slack user ID via users.lookupByEmail
// (needs `slack.token` in oasis.yml — a bot token with the users:read.email
// scope), then build a deep link that opens a 1:1 DM with them. Falls back to a
// people-search link when there's no token configured or the git email doesn't
// match a Slack account. email→id is cached (including a definitive "not found")
// so re-renders don't re-hit Slack; transient/rate-limit errors are NOT cached so
// they retry on the next render.
const _slackUserCache = {};                       // email -> { id: string|null, ts }
const SLACK_ID_TTL = 24 * 60 * 60 * 1000;         // 24h

// Slack workspace/team ID (e.g. "T0123ABCD") — needed to build a `slack://`
// deep link that opens the desktop app instead of the web client. Doesn't
// change for the life of the process, so it's resolved once and kept forever.
let _slackTeamId = null;
async function resolveSlackTeamId(token) {
  if (!token) return null;
  if (_slackTeamId) return _slackTeamId;
  try {
    const r = await axios.get('https://slack.com/api/auth.test',
      { headers: { Authorization: `Bearer ${token}` }, timeout: 8000 });
    if (r.data && r.data.ok && r.data.team_id) _slackTeamId = r.data.team_id;
  } catch (_) { /* network error → retry next call */ }
  return _slackTeamId;
}

function slackWorkspaceHost(s) {
  let ws = (s.workspace || 'cainc.enterprise.slack.com').replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  return /\.slack\.com$/i.test(ws) ? ws : ws.replace(/\.slack\.com.*$/i, '') + '.slack.com';
}
function slackSearchUrl(s, name) {
  return `https://${slackWorkspaceHost(s)}/messages/${encodeURIComponent(name)}`;
}
async function resolveSlackId(email, token) {
  if (!email || !token) return null;
  const key = email.toLowerCase();
  const hit = _slackUserCache[key];
  if (hit && (Date.now() - hit.ts) < SLACK_ID_TTL) return hit.id;
  try {
    const r = await axios.get('https://slack.com/api/users.lookupByEmail',
      { params: { email }, headers: { Authorization: `Bearer ${token}` }, timeout: 8000 });
    if (r.data && r.data.ok && r.data.user) {
      _slackUserCache[key] = { id: r.data.user.id, ts: Date.now() };
      return r.data.user.id;
    }
    if (r.data && r.data.error === 'users_not_found') {
      _slackUserCache[key] = { id: null, ts: Date.now() }; // definitive: no Slack account
      return null;
    }
    // ratelimited / invalid_auth / missing_scope → don't cache, fall back this time
  } catch (_) { /* network error → don't cache */ }
  return null;
}
async function contributorSlackUrl(s, c) {
  const token = s.token || '';
  const id = await resolveSlackId(c.email, token);
  // `slack://user?team=…&id=…` opens the member's DM in the Slack desktop app
  // (verified working on CA's Enterprise Grid) instead of the browser client.
  // Falls back to the `<workspace>/team/<USER_ID>` web link if the team ID
  // can't be resolved (no token, or the auth.test call failed).
  // When the email can't be resolved to a Slack ID (no token, or no matching
  // account) fall back to a search by EMAIL — never the display name — so the URL
  // still carries a unique identifier rather than an ambiguous name.
  if (id) {
    const teamId = await resolveSlackTeamId(token);
    if (teamId) return `slack://user?team=${encodeURIComponent(teamId)}&id=${encodeURIComponent(id)}`;
    return `https://${slackWorkspaceHost(s)}/team/${encodeURIComponent(id)}`;
  }
  // Fallback: search by the email's username (e.g. "kpearce"), not the full
  // address or the display name — a clean, unique handle without "@cainc.com".
  const handle = c.email ? c.email.split('@')[0] : c.name;
  return slackSearchUrl(s, handle);
}

/**
 * GET /api/repo-contributors?session=SID&repos=name1,name2
 * For each cloned repo, returns the top 3 contributors (by commit count) from
 * the local clone's full history via `git shortlog`. Response:
 *   { "repoA": [{ name, email, count }, ...up to 3], ... }
 * Repos not cloned locally map to an empty array. Cached per session.
 */
app.get('/api/repo-contributors', async (req, res) => {
  const { session, repos: reposParam } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  if (!sess._contribCache) sess._contribCache = {};
  const scfg    = loadConfig().slack || {};   // { token, teamId, workspace }
  const names   = String(reposParam || '').split(',').map(s => s.trim()).filter(Boolean);
  const results = {};
  const toScan  = [];

  for (const name of names) {
    const hit = sess._contribCache[name];
    if (hit && (Date.now() - hit.ts) < CACHE_TTL_MS) results[name] = hit.data;
    else toScan.push(name);
  }

  await Promise.all(toScan.map(async (name) => {
    const dir = path.join(expandHome(sess.cloneDir), name);
    let data = [];
    if (fs.existsSync(dir)) {
      try {
        // -s summary (count), -n sort by count desc, -e show email. A revision
        // (HEAD) is passed so shortlog reads history directly instead of stdin.
        const raw = await execQuiet(`git -C "${dir}" shortlog -sne -n HEAD`, { timeout: 12000 });
        data = raw.split('\n')
          .map(line => line.match(/^\s*(\d+)\s+(.*?)\s+<(.*?)>\s*$/))
          .filter(Boolean)
          .map(m => ({ count: parseInt(m[1]) || 0, name: m[2].trim(), email: m[3].trim() }))
          // Drop CI/service/bot accounts so the chips link to real teammates.
          // Match on name+email; \b keeps "bot"/"svc" from hitting names like
          // "Abbott". Filtering before slice means a dropped bot is replaced by
          // the next-highest human, not just left as a gap.
          .filter(c => !isBotContributor(c.name, c.email))
          .slice(0, 3);
        // Attach a Slack link per contributor: a direct DM when their email
        // resolves to a Slack user (token configured), else a search fallback.
        await Promise.all(data.map(async c => { c.slackUrl = await contributorSlackUrl(scfg, c); }));
      } catch (_) { data = []; }
    }
    results[name] = data;
    sess._contribCache[name] = { data, ts: Date.now() };
  }));

  res.json(results);
});

/**
 * POST /api/open-intellij
 * Body: { session, repo }
 * Opens the cloned project directory in IntelliJ IDEA (fire-and-forget).
 */

app.post('/api/open-intellij', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  if (!fs.existsSync(cloneDir)) {
    return res.status(400).json({ error: `Repo not yet cloned at: ${cloneDir}` });
  }

  // A GUI-launched Electron app inherits a minimal PATH (no /usr/local/bin,
  // Homebrew, or the JetBrains Toolbox scripts dir), so the bare `idea` launcher
  // isn't found and the open silently no-ops. Augment PATH with the usual spots.
  // path.delimiter, not ':' — Windows separates PATH entries with ';', so a
  // hardcoded colon produces one long nonsense entry rather than a list.
  // The POSIX-only directories are contributed only on POSIX; on Windows the
  // inherited PATH is all there is, which is the correct answer there.
  const home = os.homedir();
  const extra = process.platform === 'win32'
    ? []
    : [
        '/usr/local/bin', '/opt/homebrew/bin', '/usr/bin', '/bin',
        path.join(home, 'Library', 'Application Support', 'JetBrains', 'Toolbox', 'scripts'),
      ];
  const env = { ...process.env, PATH: [...extra, process.env.PATH || ''].filter(Boolean).join(path.delimiter) };

  const cmd = ideaOpenCommand(sess.intellijPath, cloneDir);
  // Await the result so a failed launch surfaces as an actionable error instead
  // of a misleading "Opening…" toast. GUI launchers (`open`, `idea`) return fast.
  exec(cmd, { env, timeout: 20000 }, (err, _stdout, stderr) => {
    if (res.headersSent) return;
    if (err) {
      console.warn('IntelliJ open error:', err.message, stderr || '');
      return res.status(500).json({
        error: 'Could not launch IntelliJ. Set the IDEA command-line launcher path in '
             + 'Settings (IDEA → Tools → Create Command-line Launcher).',
      });
    }
    res.json({ ok: true });
  });
});

app.post('/api/open-folder', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  if (!fs.existsSync(cloneDir)) {
    return res.status(400).json({ error: `Repo not found at: ${cloneDir}` });
  }

  exec(`open "${cloneDir}"`, (err) => { if (err) console.warn('Open folder error:', err.message); });
  res.json({ ok: true });
});

/**
 * GET /api/repo-badges?session=SID&repos=name1,name2&branches=branch1,branch2
 * For each repo: open PR info from GitHub + last Jenkins build status.
 * Best-effort — missing config or errors silently return nulls.
 */
app.get('/api/repo-badges', async (req, res) => {
  const { session, repos: reposParam, branches: branchesParam, force } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  if (!sess._badgeCache) sess._badgeCache = {};

  const names    = String(reposParam    || '').split(',').filter(Boolean);
  const branches = String(branchesParam || '').split(',').filter(Boolean);

  // Return cached results for recently-checked repos; only hit the network for stale ones.
  const results  = {};
  const toFetch  = [];
  const toFetchB = [];
  names.forEach((name, i) => {
    const hit = sess._badgeCache[name];
    if (hit && !force && (Date.now() - hit.ts) < CACHE_TTL_MS) {
      results[name] = hit.data;
    } else {
      toFetch.push(name);
      toFetchB.push(branches[i] || '');
    }
  });
  if (!toFetch.length) return res.json(results);

  const apiBase  = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
  const ghHeaders = {
    Authorization: `token ${sess.token}`,
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'iready-oasis/1.0',
  };

  await Promise.all(toFetch.map(async (name, i) => {
    const branch = toFetchB[i] || '';
    const out = { pr: null, jenkins: null };

    // ── Open PR for this branch ────────────────────────────────────────────
    try {
      const pr = branch
        ? await findOpenPrForBranch({ apiBase, org: sess.org, repo: name, branch, headers: ghHeaders })
        : null;
      if (pr) {
        out.pr = { number: pr.number, title: pr.title, url: pr.html_url, author: pr.user?.login };
      }
    } catch (_) {}

    // ── Jenkins last build status ──────────────────────────────────────────
    const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
    const jToken = sess.jenkinsToken || '';
    const jUser  = sess.jenkinsUser  || sess.githubLogin || '';

    if (!jToken) {
      out.jenkins = { error: 'no-token' };
    } else if (branch) {
      // Jenkins multibranch pipeline: slashes in branch names are single-encoded (%2F)
      const encodedBranch = encodeURIComponent(branch);
      const jApiUrl = `${jUrl}/job/iready/job/${encodeURIComponent(name)}/job/${encodedBranch}/lastBuild/api/json`;
      try {
        const jr = await axios.get(jApiUrl, {
          auth: { username: jUser, password: jToken },
          timeout: 8000,
        });
        const d = jr.data;
        out.jenkins = { result: d.result, url: d.url, building: d.building, number: d.number };
      } catch (e) {
        const status = e.response?.status;
        const errMsg = status === 404 ? `Job not found: ${name}/${branch}`
          : status === 401 || status === 403 ? 'Jenkins auth failed — check your API token'
          : e.message?.slice(0, 120);
        // 404 = no Jenkins job for this repo/branch — expected, not an error worth logging
        if (status !== 404) console.warn(`[jenkins] ${name}@${branch}: ${errMsg}`);
        out.jenkins = { error: errMsg, url: jApiUrl };
      }
    }

    results[name] = out;
    sess._badgeCache[name] = { data: out, ts: Date.now() };
  }));

  res.json(results);
});

/**
 * POST /api/pull
 * Body: { session, repos: [{name, default_branch}] }
 * Pulls latest code for each cloned repo; progress arrives via WebSocket.
 */
app.post('/api/pull', (req, res) => {
  const { session, repos } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const repoList = Array.isArray(repos) ? repos : [];
  if (!repoList.length) return res.status(400).json({ error: 'No repos specified' });

  res.json({ ok: true, count: repoList.length });

  (async () => {
    for (const repo of repoList) {
      const name = repo.name || String(repo);
      const cloneDir = path.join(expandHome(sess.cloneDir), name);
      let branch = repo.default_branch;
      if (!branch && fs.existsSync(cloneDir)) {
        const head = (await execQuiet(
          `git -C "${cloneDir}" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null`,
          { timeout: 5000 }
        ).catch(() => '')).replace(/^origin\//, '').trim();
        if (head) {
          branch = head;
        } else {
          for (const cand of ['develop', 'main', 'master']) {
            const ok = await execQuiet(
              `git -C "${cloneDir}" rev-parse --verify -q "refs/remotes/origin/${cand}" 2>/dev/null`,
              { timeout: 4000 }
            ).catch(() => '');
            if (ok.trim()) { branch = cand; break; }
          }
        }
        branch = branch || 'develop';
      }
      branch = branch || 'develop';

      broadcast(session, { type: 'pull_start', repo: name });
      if (!fs.existsSync(cloneDir)) {
        broadcast(session, { type: 'pull_done', repo: name, success: false, error: 'Not cloned locally' });
        continue;
      }
      try {
        const tokenUrl = `${sess.githubUrl.replace(/\/$/, '')}/${sess.org}/${name}.git`
          .replace('https://', `https://${sess.token}@`);

        // If there are local changes that would block the merge, stash them first
        // then restore after the pull (non-destructive).
        const status = await execQuiet(`git -C "${cloneDir}" status --porcelain`, { timeout: 5000 }).catch(() => '');
        const hasChanges = status.trim().length > 0;

        if (hasChanges) {
          await execQuiet(`git -C "${cloneDir}" stash --include-untracked`, { timeout: 15000 });
          try {
            externalCalls.assertAllowed('GitHub');
            await execQuiet(`git -C "${cloneDir}" pull "${tokenUrl}" ${branch}`, { timeout: 60000 });
          } finally {
            await execQuiet(`git -C "${cloneDir}" stash pop`, { timeout: 10000 }).catch(() => {});
          }
          if (sess._pullCache) delete sess._pullCache[name];   // local HEAD moved — force a fresh status check
          broadcast(session, { type: 'pull_done', repo: name, success: true, note: 'Local changes were stashed and restored.' });
        } else {
          externalCalls.assertAllowed('GitHub');
          await execQuiet(`git -C "${cloneDir}" pull "${tokenUrl}" ${branch}`, { timeout: 60000 });
          if (sess._pullCache) delete sess._pullCache[name];   // local HEAD moved — force a fresh status check
          broadcast(session, { type: 'pull_done', repo: name, success: true });
        }
      } catch (e) {
        broadcast(session, { type: 'pull_done', repo: name, success: false, error: e.message });
      }
    }
  })();
});

/**
 * GET /api/pick-directory
 * Opens a native Electron directory-picker dialog. Only works inside the
 * desktop app; returns { canceled: true } when run as a plain web server.
 */
app.get('/api/pick-directory', async (req, res) => {
  let dialog;
  try { dialog = require('electron').dialog; } catch (e) {}
  if (!dialog) return res.json({ canceled: true });
  try {
    const result = await dialog.showOpenDialog({
      properties: ['openDirectory', 'createDirectory'],
      title: 'Select clone base directory',
      buttonLabel: 'Select',
    });
    res.json(result);
  } catch (e) {
    res.json({ canceled: true, error: e.message });
  }
});

/**
 * GET /api/detect-tools
 * Auto-detects IntelliJ IDEA CLI and Java Home on the local machine.
 */
app.get('/api/detect-tools', async (req, res) => {
  const homeDir = os.homedir();
  const isWindows = process.platform === 'win32';
  const tools = {};

  // Whether the shell every script depends on is present, and where it was
  // found. Reported alongside the tools so the UI can grey out what cannot run
  // and say why, rather than offering a button that quietly does nothing.
  tools.shell = shellStatus();
  // Which directories scripts are read from, in order, and the revision of the
  // team's checkout if it is one.
  tools.scriptRoots = scriptRootStatus();

  // Java Home. /usr/libexec/java_home is a macOS utility and does not exist
  // anywhere else, so the other platforms answer the same question differently
  // rather than running a command that is guaranteed to fail.
  try {
    if (process.env.JAVA_HOME && fs.existsSync(process.env.JAVA_HOME)) {
      tools.javaHome = process.env.JAVA_HOME;
    } else if (isWindows) {
      const found = await execQuiet('where java', { timeout: 6000 }).catch(() => '');
      // `where` returns …\bin\java.exe; JAVA_HOME is two levels up.
      const first = String(found || '').split(/\r?\n/).find(Boolean);
      tools.javaHome = first ? path.dirname(path.dirname(first.trim())) : null;
    } else {
      tools.javaHome = (await execQuiet('/usr/libexec/java_home 2>/dev/null', { timeout: 6000 })) || null;
    }
  } catch (e) { tools.javaHome = null; }

  // IntelliJ IDEA CLI — the most common locations, per platform.
  const ideaCandidates = isWindows
    ? [
        // JetBrains Toolbox on Windows puts its shims under LOCALAPPDATA.
        process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'JetBrains', 'Toolbox', 'scripts', 'idea.cmd'),
        process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'JetBrains', 'IntelliJ IDEA', 'bin', 'idea64.exe'),
        process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'JetBrains', 'IntelliJ IDEA Community Edition', 'bin', 'idea64.exe'),
      ].filter(Boolean)
    : [
        path.join(homeDir, 'Library', 'Application Support', 'JetBrains', 'Toolbox', 'scripts', 'idea'),
        '/usr/local/bin/idea',
        '/Applications/IntelliJ IDEA.app/Contents/MacOS/idea',
        '/Applications/IntelliJ IDEA CE.app/Contents/MacOS/idea',
        '/Applications/IntelliJ IDEA Ultimate.app/Contents/MacOS/idea',
      ];
  tools.intellijPath = ideaCandidates.find(p => fs.existsSync(p)) || null;

  // Then whatever is on PATH. `which` is POSIX; `where` is its Windows
  // equivalent and prints one match per line.
  if (!tools.intellijPath) {
    try {
      const found = await execQuiet(isWindows ? 'where idea' : 'which idea 2>/dev/null', { timeout: 4000 });
      const first = String(found || '').split(/\r?\n/).map(l => l.trim()).find(Boolean);
      if (first && fs.existsSync(first)) tools.intellijPath = first;
    } catch (e) {}
  }

  res.json(tools);
});

/**
 * GET /api/existing-repos?session=SID
 * Lists all directories inside the configured clone base that contain a .git
 * folder — i.e. repos that have already been set up locally.
 */
app.get('/api/existing-repos', async (req, res) => {
  const { session } = req.query;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const base = expandHome(sess.cloneDir || '~/dev/projects');
  if (!fs.existsSync(base)) return res.json({ repos: [] });

  try {
    const entries = fs.readdirSync(base);
    const gitDirs = entries.filter(d => {
      return isProjectDir(base, d);
    });
    // Process in batches of 12 to avoid exhausting OS file-descriptor limits
    // when spawning concurrent git processes (each git call opens stdin/stdout pipes).
    const BATCH = 12;
    const repos = [];
    for (let i = 0; i < gitDirs.length; i += BATCH) {
      const batch = gitDirs.slice(i, i + BATCH);
      const results = await Promise.all(batch.map(async d => {
        const fullPath = path.join(base, d);
        let branch = 'unknown', lastCommit = null;
        try { branch     = await execQuiet(`git -C "${fullPath}" rev-parse --abbrev-ref HEAD`, { timeout: 8000 }); } catch (_) {}
        try { lastCommit = await execQuiet(`git -C "${fullPath}" log -1 --format=%ci`, { timeout: 8000 }); } catch (_) {}
        const launch = resolveLaunchScript(d);
        return { name: d, path: fullPath, branch, lastCommit, _hasLaunch: !!launch, _launchLabel: launch?.label || null };
      }));
      repos.push(...results);
    }
    res.json({ repos });
  } catch (e) {
    res.json({ repos: [], error: e.message });
  }
});

/**
 * GET /api/dependency-graph?session=SID
 * Scans cloned repos for pom.xml / package.json and returns a dependency graph.
 * Response: { nodes: [{name, language, version}], edges: [{from, to}] }  ("from depends on to")
 *
 * Accuracy strategy for Maven repos:
 *  1. Extract each repo's own groupId + artifactId.
 *  2. Detect the org groupId prefix (longest common prefix of all repo groupIds, e.g. "com.cainc").
 *  3. When scanning <dependency> blocks, skip any dep whose groupId does NOT start with the
 *     org prefix — this eliminates Spring, AWS, etc. entirely.
 *  4. Match the remaining (internal) dep's artifactId EXACTLY against known repos — no fuzzy
 *     substring matching which was the root cause of false positives.
 */
app.get('/api/dependency-graph',  _depGraphHandler);
app.post('/api/dependency-graph', _depGraphHandler);
async function _depGraphHandler(req, res) {
  const session     = req.query.session || req.body?.session;
  const refresh     = req.query.refresh || req.body?.refresh;
  const passedRepos = req.body?.repos;   // [{name, language}] passed from frontend allRepos
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!refresh && sess._depGraph) return res.json(sess._depGraph);

  const base = expandHome(sess.cloneDir);
  if (!fs.existsSync(base)) return res.json({ nodes: [], edges: [] });

  try {
    const entries  = fs.readdirSync(base);
    const repoNames = [];
    const repoMeta  = {}; // name -> { language, groupId, artifactId, pkgName }

    // ── Pass 1: collect repo metadata ────────────────────────────────────────
    for (const d of entries) {
      const fp = path.join(base, d);
      try {
        if (!fs.statSync(fp).isDirectory()) continue;
        if (!fs.existsSync(path.join(fp, '.git'))) continue;
        repoNames.push(d);
        let language = null, groupId = null, artifactId = null, pkgName = null, version = null;

        if (fs.existsSync(path.join(fp, 'pom.xml'))) {
          language = 'Java';
          try {
            const pom = fs.readFileSync(path.join(fp, 'pom.xml'), 'utf8');
            // Strip <parent> so we don't accidentally pick up the parent's groupId/artifactId
            const stripped = pom.replace(/<parent>[\s\S]*?<\/parent>/g, '');
            groupId    = stripped.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim()    || null;
            artifactId = stripped.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || null;
            // Fall back to parent groupId if own groupId is absent (inherited)
            if (!groupId) {
              groupId = pom.match(/<parent>[\s\S]*?<groupId>([^<]+)<\/groupId>[\s\S]*?<\/parent>/)?.[1]?.trim() || null;
            }
            // This repo's own current version (own <version>, or inherited from
            // <parent> if absent) — shown on its node in the tree-view graph and
            // used as the fallback version for any dependency that resolves to
            // this repo with no version pinned anywhere else (see repoDMVersions).
            version = extractOwnVersion(stripped)
              || pom.match(/<parent>[\s\S]*?<version>([^<]+)<\/version>[\s\S]*?<\/parent>/)?.[1]?.trim()
              || null;
          } catch (_) {}
        } else if (fs.existsSync(path.join(fp, 'package.json'))) {
          language = 'JavaScript';
          try {
            const pkg = JSON.parse(fs.readFileSync(path.join(fp, 'package.json'), 'utf8'));
            pkgName = pkg.name || null;
            version = pkg.version || null;
          } catch (_) {}
        } else if (fs.existsSync(path.join(fp, 'build.gradle')) ||
                   fs.existsSync(path.join(fp, 'build.gradle.kts'))) {
          language = 'Kotlin';
        }
        repoMeta[d] = { language, groupId, artifactId, pkgName, version };
      } catch (_) {}
    }

    // ── Detect org groupId prefix ─────────────────────────────────────────────
    // Use majority-vote on the first 2 dot-segments so a single outlier repo
    // (e.g. "tests.selenium") doesn't break detection of the main org prefix.
    function detectOrgPrefix(ids) {
      const tally = {};
      for (const gid of ids) {
        const segs = gid.split('.');
        if (segs.length >= 2) {
          const p = segs.slice(0, 2).join('.');
          tally[p] = (tally[p] || 0) + 1;
        }
      }
      const sorted = Object.entries(tally).sort((a, b) => b[1] - a[1]);
      return (sorted[0] && sorted[0][1] >= 2) ? sorted[0][0] : null;
    }
    const repoGroupIds = Object.values(repoMeta).map(m => m.groupId).filter(Boolean);
    const orgPrefix    = detectOrgPrefix(repoGroupIds);   // e.g. "com.cainc"

    // ── Fetch ALL org repos from GitHub so lookup covers non-cloned repos too ──
    const apiBase   = sess.githubUrl.replace(/\/$/, '') + '/api/v3';
    const ghHeaders = {
      Authorization: `token ${sess.token}`,
      Accept: 'application/vnd.github.v3+json',
      'User-Agent': 'iready-oasis/1.0',
    };
    let allOrgRepos = [];
    try {
      let page = 1;
      while (true) {
        const r = await axios.get(`${apiBase}/orgs/${sess.org}/repos`, {
          headers: ghHeaders, params: { page, per_page: 100, type: 'all' }, timeout: 10000,
        });
        allOrgRepos = allOrgRepos.concat(r.data);
        if (!r.headers['link']?.includes('rel="next"')) break;
        page++;
      }
    } catch (_) {}

    // Seed repoMeta and repoNames for every org repo (not just cloned ones).
    // Prefer the list passed by the frontend (already loaded) to avoid a second
    // paginated fetch — fall back to what the GitHub API returned.
    const clonedSet = new Set(repoNames);
    const orgRepoSource = (passedRepos && passedRepos.length) ? passedRepos : allOrgRepos;
    for (const r of orgRepoSource) {
      if (!repoMeta[r.name]) {
        repoNames.push(r.name);
        repoMeta[r.name] = { language: r.language || null, artifactId: null, pkgName: null, groupId: null };
      }
    }

    // ── Build lookup from ALL known repo names + ALL submodule artifactIds ──────
    // For cloned repos, scan every pom.xml in the tree and map its artifactId to
    // the top-level repo directory name. This is what lets us resolve e.g.
    // "com.cainc.queuing:queuing-service-client" → "queuing-service" repo.
    const lookup = {};
    for (const [name, meta] of Object.entries(repoMeta)) {
      if (meta.artifactId) lookup[meta.artifactId.toLowerCase()] = name;
      if (meta.pkgName)    lookup[meta.pkgName.toLowerCase()]    = name;
      lookup[name.toLowerCase()] = name;
    }
    // Extra pass: scan all pom.xml files in every cloned repo and register every
    // <artifactId> found (stripped of the <parent> block) → parent repo name.
    for (const repoName of clonedSet) {
      const fp = path.join(base, repoName);
      for (const pomPath of findAllPoms(fp)) {
        try {
          const raw = fs.readFileSync(pomPath, 'utf8');
          // Skip the parent element so we don't accidentally capture the parent's artifactId
          const stripped = raw.replace(/<parent>[\s\S]*?<\/parent>/g, '');
          const aid = stripped.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim();
          if (aid && !lookup[aid.toLowerCase()]) {
            lookup[aid.toLowerCase()] = repoName;
          }
        } catch (_) {}
      }
    }

    const edges  = [];
    const edgeSet = new Set();
    const addEdge = (from, to) => {
      const k = `${from}→${to}`;
      if (!edgeSet.has(k)) { edgeSet.add(k); edges.push({ from, to }); }
    };

    // Collect all pom.xml paths within a repo directory, excluding build output and
    // hidden directories. Multi-module Maven projects (e.g. iready-core) have their
    // real <dependencies> in submodule pom.xml files, not the root aggregator.
    function findAllPoms(repoDir) {
      const SKIP = new Set(['target', 'node_modules', '.git', '.mvn', 'vendor', 'dist', 'build']);
      const results = [];
      function walk(dir, depth) {
        if (depth > 4) return;
        try {
          const pomPath = path.join(dir, 'pom.xml');
          if (fs.existsSync(pomPath)) results.push(pomPath);
          for (const entry of fs.readdirSync(dir)) {
            if (SKIP.has(entry) || entry.startsWith('.')) continue;
            const child = path.join(dir, entry);
            try { if (fs.statSync(child).isDirectory()) walk(child, depth + 1); } catch (_) {}
          }
        } catch (_) {}
      }
      walk(repoDir, 0);
      return results;
    }

    // Extracts <properties><key>value</key>...</properties> as a plain object —
    // used to resolve "${some.version}" placeholders in <version> tags below.
    function extractPomProperties(pomXml) {
      const props = {};
      const block = pomXml.match(/<properties>([\s\S]*?)<\/properties>/);
      if (!block) return props;
      const re = /<([\w.-]+)>([^<]*)<\/\1>/g;
      let m;
      while ((m = re.exec(block[1]))) props[m[1]] = m[2].trim();
      return props;
    }

    // Extracts a pom's OWN top-level <version> — restricted to the "project
    // identity" region (before <dependencies>/<dependencyManagement>/
    // <properties>/<build>/<profiles>/<modules>). A bare, unscoped regex match
    // anywhere in the document can otherwise land on a completely unrelated
    // <version> tag nested deeper in the file — e.g. inside a <dependency>'s
    // own version, or a <properties> value — which is exactly what happened
    // before this: modules with no own <version> (relying on <parent>
    // inheritance, the common case) were picking up whatever <version> tag
    // happened to appear first elsewhere in the file (often a placeholder like
    // "${project.version}" or "${org.mapstruct.version}" from a dependency).
    function extractOwnVersion(strippedXml) {
      const cut = strippedXml.search(/<(dependencies|dependencyManagement|properties|build|profiles|modules)>/);
      const identity = cut === -1 ? strippedXml : strippedXml.slice(0, cut);
      return identity.match(/<version>([^<]+)<\/version>/)?.[1]?.trim() || null;
    }

    // Resolves a raw <version> value that may be a Maven property placeholder
    // (e.g. "${student-reward-service.version}") to its actual value, using a
    // repo's merged <properties> (root + every submodule) and its own project
    // version for the "${project.version}"/"${project.parent.version}"/
    // "${revision}" self-reference cases. Recurses (depth-bounded) because a
    // property's own value is sometimes ANOTHER placeholder one level down
    // (e.g. <content.model.shared.version>${project.version}</...> — resolving
    // only the outer "${content.model.shared.version}" leaves the inner one
    // showing up raw). Falls back to the raw placeholder text when it can't be
    // resolved locally at all (e.g. it's inherited from an external parent POM
    // not present on disk) — showing the unresolved placeholder is still
    // better than a wrong guess.
    function resolvePomVersion(raw, props, ownVersion, depth = 0) {
      if (!raw || depth > 5) return raw;
      const m = raw.match(/^\$\{([^}]+)\}$/);
      if (!m) return raw;
      const key = m[1];
      if (key === 'project.version' || key === 'project.parent.version' || key === 'revision') return ownVersion || raw;
      const next = props[key];
      if (!next) return raw;
      return resolvePomVersion(next, props, ownVersion, depth + 1);
    }

    // Returns true when a dep should be included.
    // Accepts: literal groupIds under the detected org prefix, inherited "${...}"
    // expressions (common in submodule pom.xml files), and empty groupIds — as
    // long as the artifactId is a known org repo.
    const isCainDep = (gid, aid) => {
      if (!aid) return false;
      const g = gid.toLowerCase();
      if (orgPrefix && g.startsWith(orgPrefix.toLowerCase())) return true; // literal org-prefixed groupId
      if (!g || g.startsWith('${')) return !!lookup[aid.toLowerCase()]; // property/blank → trust lookup
      return false;
    };

    // ── Pass 2: extract dependencies ──────────────────────────────────────────
    for (const d of repoNames) {
      const fp = path.join(base, d);

      // Maven: scan ALL pom.xml files in the repo (root + every submodule).
      // Each pom.xml is scanned independently; deps in any submodule count as a
      // dep of the top-level repo (the directory that was cloned).
      const pomFiles = findAllPoms(fp);
      if (d === 'iready-core') console.log(`[dep-debug] iready-core: found ${pomFiles.length} pom.xml files:`, pomFiles.map(p => p.replace(base + '/', '')));
      for (const pomPath of pomFiles) {
        try {
          const pom = fs.readFileSync(pomPath, 'utf8');
          const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
          const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
          for (const sec of sections) {
            const depBlocks = sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [];
            for (const dep of depBlocks) {
              const depGid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim()    || '';
              const depAid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
              if (!isCainDep(depGid, depAid)) continue;
              const target = lookup[depAid.toLowerCase()];
              if (d === 'iready-core') console.log(`[dep-debug] iready-core: ${depGid}:${depAid} → target=${target}`);
              if (target && target !== d) addEdge(d, target);
            }
          }
        } catch (_) {}
      }

      // Node.js: exact package name match against other repos' pkgName or dir name
      const pkgPath = path.join(fp, 'package.json');
      if (fs.existsSync(pkgPath)) {
        try {
          const pkg     = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
          const allDeps = Object.assign({}, pkg.dependencies, pkg.devDependencies, pkg.peerDependencies);
          for (const depName of Object.keys(allDeps)) {
            const bare   = depName.replace(/^@[^/]+\//, ''); // strip @scope/
            const target = lookup[depName.toLowerCase()] || lookup[bare.toLowerCase()];
            if (target && target !== d) addEdge(d, target);
          }
        } catch (_) {}
      }
    }

    // ── Dependency map: repo → ["groupId:artifactId", ...] for all com.cain* deps ─
    const depMap = {};
    for (const d of repoNames) {
      const fp   = path.join(base, d);
      const deps = new Set();
      for (const pomPath of findAllPoms(fp)) {
        try {
          const pom = fs.readFileSync(pomPath, 'utf8');
          const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
          const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
          for (const sec of sections) {
            const depBlocks = sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [];
            for (const dep of depBlocks) {
              const gid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
              const aid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
              if (!isCainDep(gid, aid)) continue;
              deps.add(`${gid}:${aid}`);
            }
          }
        } catch (_) {}
      }
      if (deps.size) depMap[d] = [...deps].sort();
    }

    // ── Submodule breakdown for multi-module cloned repos ─────────────────────
    // For each cloned repo, list its submodules (nested pom.xml files) and
    // resolve every submodule's com.cain* deps to either an external repo
    // (via lookup) or a sibling module in the same repo (internal). Repos with
    // only a root pom (single-module) produce no entry, so the frontend only
    // shows a breakdown for genuine multi-module projects (e.g. iready-core).
    const submodules = {};
    for (const repoName of clonedSet) {
      const repoDir = path.join(base, repoName);
      const rootPom = path.join(repoDir, 'pom.xml');
      const allPoms = findAllPoms(repoDir);

      // Map every module's own artifactId (lowercased) → display info, so we can
      // detect intra-repo (internal) dependencies between sibling modules.
      const ownModules = {};   // aidLower -> { artifactId, path }
      const pomInfo    = [];   // { pomPath, artifactId, relPath, isRoot }
      // Merged <properties> across every pom in this repo, plus the root pom's
      // own <version> — best-effort inputs for resolving "${x.version}"
      // placeholders in dependency <version> tags below.
      const repoProps  = {};
      let rootVersion  = null;
      // Raw (unresolved) <dependencyManagement> versions merged across every
      // pom in this repo — a submodule's own <dependency> entry frequently
      // omits <version> entirely because it's managed centrally here (a BOM/
      // parent-POM pattern), so without this a real, resolvable version was
      // being reported as "no version" just because it wasn't inline.
      const repoDMRaw  = {}; // "groupId:artifactId" (lowercased) -> raw version text
      for (const pomPath of allPoms) {
        try {
          const raw      = fs.readFileSync(pomPath, 'utf8');
          const stripped = raw.replace(/<parent>[\s\S]*?<\/parent>/g, '');
          const aid      = stripped.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || null;
          const relPath  = path.relative(repoDir, path.dirname(pomPath)) || '.';
          const isRoot   = pomPath === rootPom;
          if (aid) ownModules[aid.toLowerCase()] = { artifactId: aid, path: relPath };
          Object.assign(repoProps, extractPomProperties(raw));
          if (isRoot) {
            rootVersion = extractOwnVersion(stripped)
              || raw.match(/<parent>[\s\S]*?<version>([^<]+)<\/version>[\s\S]*?<\/parent>/)?.[1]?.trim()
              || null;
          }
          const dmBlock = raw.match(/<dependencyManagement>([\s\S]*?)<\/dependencyManagement>/);
          if (dmBlock) {
            for (const dep of (dmBlock[1].match(/<dependency>[\s\S]*?<\/dependency>/g) || [])) {
              const dGid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
              const dAid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
              const dVer = dep.match(/<version>([^<]+)<\/version>/)?.[1]?.trim() || null;
              if (dAid && dVer) repoDMRaw[`${dGid.toLowerCase()}:${dAid.toLowerCase()}`] = dVer;
            }
          }
          pomInfo.push({ pomPath, artifactId: aid, relPath, isRoot });
        } catch (_) {}
      }
      // Resolve DM versions' own "${...}" placeholders now that repoProps/
      // rootVersion are fully merged across every pom.
      const repoDMVersions = {};
      for (const [k, v] of Object.entries(repoDMRaw)) repoDMVersions[k] = resolvePomVersion(v, repoProps, rootVersion);

      // Only one pom (the root) → not a multi-module repo, skip.
      if (pomInfo.length <= 1) continue;

      const mods = [];
      for (const info of pomInfo) {
        if (info.isRoot) continue;   // the root pom maps to the repo node itself
        let pom;
        try { pom = fs.readFileSync(info.pomPath, 'utf8'); } catch (_) { continue; }
        // A submodule only has its own <version> when it explicitly overrides
        // the parent's (rare) — otherwise it inherits the parent/root version,
        // same as every sibling module in the reactor.
        const modStripped = pom.replace(/<parent>[\s\S]*?<\/parent>/g, '');
        // The submodule's own <version> can itself be a "${...}" placeholder
        // (e.g. CI-friendly-versions' <version>${revision}</version>) — resolve
        // it the same way a dependency's version gets resolved, and if it's
        // STILL unresolved after that, fall back to this repo's own version
        // (the same one shown on its node in the repo-view tree graph) rather
        // than displaying raw placeholder text.
        let moduleVersion = resolvePomVersion(extractOwnVersion(modStripped), repoProps, rootVersion) || rootVersion || null;
        if (moduleVersion && moduleVersion.includes('${')) moduleVersion = rootVersion || null;
        const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
        const sections    = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
        const selfAid = (info.artifactId || '').toLowerCase();
        // Capture EVERY com.cain* dep — never drop one just because it doesn't map
        // to a cloned repo. Key by group:artifact:version (not just group:artifact)
        // so two modules pinning different versions of the same dependency show up
        // as distinct entries instead of one silently overwriting the other — that
        // silent collapse is exactly what hid version conflicts before this.
        const byKey = new Map();
        for (const sec of sections) {
          for (const dep of (sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [])) {
            const gid     = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
            const aid     = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
            const scope   = dep.match(/<scope>([^<]+)<\/scope>/)?.[1]?.trim() || null;
            if (!isCainDep(gid, aid)) continue;
            const al       = aid.toLowerCase();
            const internal = !!(ownModules[al] && al !== selfAid);
            const repo     = internal ? null : (lookup[al] && lookup[al] !== repoName ? lookup[al] : null);
            // Version is just as often a "${x.version}" property placeholder as a
            // literal number — resolve it against this repo's merged <properties>
            // so the UI shows the real version, not the placeholder text. When
            // it's flat-out absent (inline AND via <dependencyManagement>/a BOM),
            // and this dep resolves to another known repo, fall back to that
            // target repo's own current version — a module-based (multi-module)
            // repo's modules all share one version, so depending on e.g. its
            // "-parent" artifact with no version pinned really just means "use
            // whatever version that repo is at now" (confirmed via `mvn
            // dependency:tree`, which resolves it to the repo's own reactor version).
            const rawVersion = dep.match(/<version>([^<]+)<\/version>/)?.[1]?.trim() || null;
            let version = resolvePomVersion(rawVersion, repoProps, rootVersion)
              || repoDMVersions[`${gid.toLowerCase()}:${al}`]
              || (repo ? repoMeta[repo]?.version : null)
              || null;
            // resolvePomVersion() returns the RAW placeholder text (truthy, so
            // the || chain above never falls through) when a property genuinely
            // can't be resolved locally (e.g. inherited from an external parent
            // POM not present on disk) — last resort: use this repo's own
            // version, the same one shown on its node in the repo-view tree
            // graph, rather than displaying "${...}" to the user.
            if (version && version.includes('${')) version = rootVersion || null;
            const key      = `${gid.toLowerCase()}:${al}:${version || ''}`;
            const existing = byKey.get(key);
            // Keep the entry with the "strongest" scope (compile/null beats test).
            if (!existing || (existing.scope && !scope)) {
              byKey.set(key, { group: gid, artifact: aid, version, repo, internal, scope });
            }
          }
        }
        const deps = [...byKey.values()].sort((a, b) => {
          if (a.internal !== b.internal) return a.internal ? -1 : 1;   // internal first
          if (a.artifact !== b.artifact) return a.artifact.localeCompare(b.artifact);
          return (a.version || '').localeCompare(b.version || '');     // group same-artifact versions together
        });
        if (deps.length) {
          mods.push({ module: info.artifactId || info.relPath, path: info.relPath, version: moduleVersion, deps });
        }
      }
      if (mods.length) {
        mods.sort((a, b) => a.module.localeCompare(b.module));
        submodules[repoName] = mods;
      }
    }

    // ── Fetch pom.xml for non-cloned repos from GitHub API ────────────────────
    const nonCloned = allOrgRepos.filter(r => !clonedSet.has(r.name));

    // Fetch pom.xml for non-cloned repos concurrently (10 at a time)
    // Semaphore: allows up to MAX_CONCURRENT GitHub API calls at any time
    const MAX_CONCURRENT = 50;
    let _active = 0;
    const _queue = [];
    const throttle = (fn) => new Promise((resolve, reject) => {
      const run = async () => {
        _active++;
        try { resolve(await fn()); } catch (e) { reject(e); } finally {
          _active--;
          if (_queue.length) _queue.shift()();
        }
      };
      _active < MAX_CONCURRENT ? run() : _queue.push(run);
    });
    // Helper: decode a GitHub contents API response to pom.xml text
    const decodePom = (data) => {
      const c = data?.content;
      return c ? Buffer.from(c.replace(/\n/g, ''), 'base64').toString('utf8') : null;
    };

    // Helper: extract com.cain* deps from a pom.xml string
    const extractCainDeps = (pom) => {
      const deps = new Set();
      const withoutMgmt = pom.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
      const sections = withoutMgmt.match(/<dependencies>[\s\S]*?<\/dependencies>/g) || [];
      for (const sec of sections) {
        for (const dep of (sec.match(/<dependency>[\s\S]*?<\/dependency>/g) || [])) {
          const gid = dep.match(/<groupId>([^<]+)<\/groupId>/)?.[1]?.trim() || '';
          const aid = dep.match(/<artifactId>([^<]+)<\/artifactId>/)?.[1]?.trim() || '';
          if (isCainDep(gid, aid)) deps.add(`${gid}:${aid}`);
        }
      }
      return deps;
    };

    // Helper: fetch a file from GitHub contents API (throttled)
    const ghFetch = async (repoName, filePath) => throttle(async () => {
      try {
        const r = await axios.get(
          `${apiBase}/repos/${sess.org}/${repoName}/contents/${filePath}`,
          { headers: ghHeaders, timeout: 8000 }
        );
        return r.data;
      } catch (_) { return null; }
    });

    // Process ALL non-cloned repos in parallel — throttle controls the concurrency.
    // Only fetch root pom.xml (no submodule recursion) for non-cloned repos to keep
    // API calls at O(N) instead of O(N×M). Cloned repos already scan all submodules
    // via findAllPoms() above, so nothing is lost for locally checked-out code.
    await Promise.all(nonCloned.map(async repo => {
        try {
          const rootData = await ghFetch(repo.name, 'pom.xml');
          const rootPom  = rootData ? decodePom(rootData) : null;
          if (!rootPom) return;

          const allDeps = new Set();
          for (const d of extractCainDeps(rootPom)) allDeps.add(d);

          if (allDeps.size) {
            depMap[repo.name] = [...new Set([...(depMap[repo.name] || []), ...allDeps])].sort();
            if (!repoNames.includes(repo.name)) {
              repoNames.push(repo.name);
              repoMeta[repo.name] = { language: repo.language || null };
            }
            for (const dep of allDeps) {
              const aid    = dep.split(':')[1] || '';
              const target = lookup[aid.toLowerCase()];
              if (target && target !== repo.name) addEdge(repo.name, target);
            }
          }
        } catch (_) {}
    }));

    console.log(`[depmap] ${Object.keys(depMap).length} repos with com.cain* deps | ${edges.length} edges | ${nonCloned.length} fetched from GitHub`);

    const nodes = repoNames.map(name => ({
      name, language: repoMeta[name]?.language || null, cloned: clonedSet.has(name),
      version: repoMeta[name]?.version || null,
    }));
    const result = { nodes, edges, orgPrefix: orgPrefix || null, depMap, submodules };
    sess._depGraph = result;   // cache for this session
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

/**
 * POST /api/delete-repo
 * Body: { session, repo }
 * Deletes the local clone directory for the given repo (irreversible).
 * Safety check: the resolved path must be a direct child of the configured cloneDir.
 */
app.post('/api/delete-repo', (req, res) => {
  const { session, repo } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo || /[/\\]/.test(repo)) return res.status(400).json({ error: 'Invalid repo name' });

  const base     = expandHome(sess.cloneDir);
  const cloneDir = path.join(base, repo);

  // Must be a direct child — no traversal
  if (path.dirname(cloneDir) !== base) return res.status(400).json({ error: 'Invalid path' });
  if (!fs.existsSync(cloneDir)) return res.json({ ok: true });

  try {
    fs.rmSync(cloneDir, { recursive: true, force: true });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/refresh-credentials
 * Refreshes AWS SSO credentials so Bedrock becomes available.
 * Spawns the refresh script with the user's full login environment so that
 * `aws`, `python3` etc. are on PATH. `aws sso login` opens the system
 * browser automatically — no terminal required.
 */
app.post('/api/refresh-credentials', async (req, res) => {
  const { session } = req.body;
  if (!sessions[session]) return res.status(401).json({ error: 'Invalid session' });

  const shell = detectBash();
  if (!shell.available) return res.status(503).json({ error: shell.hint });

  const scriptPath = path.join(SCRIPTS_DIR, 'refresh-aws-creds.sh');
  if (!fs.existsSync(scriptPath)) {
    return res.status(404).json({ error: 'Credential refresh script not found.' });
  }

  // Resolve the user's interactive login environment so tools installed via
  // Homebrew, nvm, SDKMAN etc. are on PATH — the same as opening Terminal.
  const loginEnv = await getLoginEnv();

  return new Promise(resolve => {
    const proc = spawnBash([scriptPath], {
      env: loginEnv,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let out = '';
    proc.stdout.on('data', d => { out += d; });
    proc.stderr.on('data', d => { out += d; });

    // 3-minute timeout — SSO browser login can take a while
    const timer = setTimeout(() => { proc.kill(); }, 180000);

    proc.on('close', code => {
      clearTimeout(timer);
      const snippet = out.slice(-600);
      if (code === 0) {
        res.json({ ok: true, output: snippet });
      } else if (code === 3) {
        // Exit 3 = SSO expired but non-interactive flag prevented login
        // This shouldn't happen since we removed OASIS_NONINTERACTIVE,
        // but handle it gracefully.
        res.json({ ok: false, ssoRequired: true, output: snippet });
      } else {
        res.status(500).json({ ok: false, error: snippet || `Exit code ${code}` });
      }
      resolve();
    });
  });
});

// ── Project chat ──────────────────────────────────────────────────────────

const CHAT_SYSTEM_PROMPT = (repo) =>
  `You are a developer assistant helping explain the "${repo}" project from the i-Ready (Curriculum Associates) ` +
  `GitHub Enterprise organization. Answer questions about architecture, how the code works, development flow, ` +
  `setup steps, and any technical questions. When recent build/setup console output is provided below and the user ` +
  `asks why a build or setup failed, diagnose the root cause from that output: quote the key error line, explain ` +
  `what it means, and give concrete fix steps (commands or config changes). Be concise and practical. ` +
  `Use the project context below when available. If something is not covered by the context, say you are not sure ` +
  `rather than guessing.`;

function getProjectContext(sess, repo) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repo);
  if (!fs.existsSync(cloneDir)) return null;

  let ctx = '';

  for (const f of ['README.md', 'readme.md', 'README.txt', 'README']) {
    const p = path.join(cloneDir, f);
    if (fs.existsSync(p)) {
      ctx += `\n\n--- README ---\n${fs.readFileSync(p, 'utf8').slice(0, 4000)}`;
      break;
    }
  }

  const pkg = path.join(cloneDir, 'package.json');
  if (fs.existsSync(pkg)) {
    try {
      const j = JSON.parse(fs.readFileSync(pkg, 'utf8'));
      ctx += `\n\n--- package.json ---\nname: ${j.name || ''}\ndescription: ${j.description || ''}\n` +
             `scripts: ${JSON.stringify(j.scripts || {}, null, 2)}`;
    } catch (e) {}
  }

  const pom = path.join(cloneDir, 'pom.xml');
  if (fs.existsSync(pom)) ctx += `\n\n--- pom.xml (partial) ---\n${fs.readFileSync(pom, 'utf8').slice(0, 1500)}`;

  try {
    const ignore = new Set(['node_modules', 'target', 'build', 'dist', '.git', '.idea']);
    const entries = fs.readdirSync(cloneDir).filter(e => !e.startsWith('.') && !ignore.has(e));
    ctx += `\n\n--- Top-level structure ---\n${entries.join(', ')}`;
    for (const dir of entries.slice(0, 5)) {
      const dp = path.join(cloneDir, dir);
      try {
        if (fs.statSync(dp).isDirectory()) {
          const sub = fs.readdirSync(dp).filter(e => !e.startsWith('.')).slice(0, 10);
          ctx += `\n${dir}/: ${sub.join(', ')}`;
        }
      } catch (e) {}
    }
  } catch (e) {}

  return ctx || null;
}

function heuristicChatReply(repo, messages, reason) {
  const q = ((messages || []).slice(-1)[0]?.content || '').toLowerCase();
  const deniedNote = reason === 'denied'
    ? `_AI-powered answers are unavailable — your AWS role lacks Bedrock access. Ask the platform team for \`bedrock:InvokeModel\` access._`
    : `_AI-powered answers are unavailable right now — click **Refresh AWS Credentials** to enable them._`;
  if (/how.*work|architecture|flow|explain|overview|structure/i.test(q)) {
    return `**${repo}** — offline overview\n\n` +
      `- Check **README.md** in the cloned repo for the architecture overview\n` +
      `- Look at the top-level **src/** folder structure for package layout\n` +
      `- Setup logs (expand the job card) show the exact Maven/npm steps run\n\n` +
      deniedNote;
  }
  if (/setup|install|run|start|build/i.test(q)) {
    return `**Setup steps for ${repo}:**\n` +
      `1. Select it in the repo list and click **Setup Workspace**\n` +
      `2. The setup script handles Maven/npm install automatically\n` +
      `3. Check **README.md** in the repo for any extra manual steps\n\n` +
      deniedNote;
  }
  if (reason === 'denied') {
    return `AI-powered answers for **${repo}** are unavailable.\n\n` +
      `Your AWS role doesn't have access to the configured Bedrock model. Ask the platform team for \`bedrock:InvokeModel\` access.`;
  }
  return `AI-powered answers for **${repo}** are temporarily unavailable.\n\n` +
    `Your AWS Bedrock credentials may have expired. Click **Refresh AWS Credentials** below to renew them automatically, then ask again.`;
}

/**
 * POST /api/chat
 * Body: { session, repo, messages: [{role, content}] }
 * Multi-turn chat about a project. Uses Claude on Bedrock when configured,
 * falls back to heuristic replies otherwise.
 */
app.post('/api/chat', async (req, res) => {
  const { session, repo, messages, logs } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });
  if (!repo || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'repo and messages are required' });
  }

  const context = getProjectContext(sess, repo);
  const logText = String(logs || '').slice(-6000).trim();

  // If the user is asking about a Jenkins/CI build, pull the actual Jenkins
  // console log for this repo's last build so Claude can diagnose the failure.
  const lastUserMsg = String([...messages].reverse().find(m => m.role === 'user')?.content || '');
  const asksJenkins = /jenkins|\bci\b|pipeline|\bbuild\b/i.test(lastUserMsg);
  let jenkinsText = '';
  if (asksJenkins) {
    try {
      const jc = await fetchJenkinsConsole(sess, repo);
      if (jc) {
        const head = `Branch: ${jc.branch} · Build #${jc.number ?? '?'} · ` +
          `Result: ${jc.building ? 'BUILDING' : (jc.result || 'unknown')}` +
          (jc.url ? ` · ${jc.url}` : '');
        jenkinsText = jc.console
          ? `${head}\n\n${jc.console}`
          : `${head}\n(No console output available.)`;
      }
    } catch (_) {}
  }

  const systemText = CHAT_SYSTEM_PROMPT(repo) +
    (context
      ? `\n\nProject context:${context}`
      : '\n\n(Note: this project has not been cloned locally yet — limited context available.)') +
    (logText
      ? `\n\n--- Recent local build/setup console output (newest last) ---\n${logText}`
      : '') +
    (jenkinsText
      ? `\n\n--- Jenkins build console for this repo (newest last) ---\n${jenkinsText}`
      : '');

  const convMessages = messages
    .map(m => ({ role: m.role, content: [{ text: String(m.content || '').slice(0, 4000) }] }))
    .slice(-20);

  const ai = aiClientFor(sess);
  if (ai.available()) {
    try {
      const flatMessages = convMessages.map(m => ({
        role: m.role,
        content: (m.content || []).map(b => b.text || '').join(''),
      }));
      const reply = await ai.complete({ messages: flatMessages, system: systemText, maxTokens: 2048 });
      if (!reply) throw new Error('Empty response');
      return res.json({ reply, source: sess.aiProvider || 'ai' });
    } catch (e) {
      if (e instanceof AiAuthError || isAccessError(e)) {
        const r = accessFailReason(e);
        return res.json({ reply: heuristicChatReply(repo, messages, r), source: 'generic', reason: r });
      }
      // Any other AI error: fall through to heuristic
    }
  }

  res.json({ reply: heuristicChatReply(repo, messages), source: 'generic' });
});

installDocker(app, { sessions, execQuiet, spawn, spawnBash, broadcast, enqueueLog });

// ─────────────────────────────────────────────────────────────────────────────
// Scheduled Jobs
// ─────────────────────────────────────────────────────────────────────────────

const SCHEDULED_JOBS_PATH = path.join(os.homedir(), '.oasis-scheduled-jobs.json');

function loadScheduledJobs() {
  try {
    if (fs.existsSync(SCHEDULED_JOBS_PATH)) return JSON.parse(fs.readFileSync(SCHEDULED_JOBS_PATH, 'utf8'));
  } catch (_) {}
  return {};
}

function saveScheduledJobs(data) {
  try { fs.writeFileSync(SCHEDULED_JOBS_PATH, JSON.stringify(data, null, 2)); } catch (_) {}
}

function shouldRunJob(job, now) {
  if (!job.enabled || job.schedule === 'manual') return false;
  const last = job.lastRun ? new Date(job.lastRun) : null;

  if (job.schedule === 'hourly') {
    return !last || (now - last) >= 3600000;
  }

  const [hh, mm] = (job.scheduleTime || '09:00').split(':').map(Number);
  const DAY_MAP = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };

  // Today's scheduled moment (local time).
  const target = new Date(now);
  target.setHours(hh, mm, 0, 0);

  // Fire once we're AT or PAST today's target and haven't already run since it.
  // (The old code required an exact `getMinutes() === mm` match, so any setInterval
  //  drift — or the machine sleeping through the target minute — skipped the job
  //  entirely. This catch-up comparison is robust to a missed minute: the next tick
  //  after the target time still runs it.)
  const dueNow = now >= target && (!last || last < target);

  if (job.schedule === 'daily') {
    if (!dueNow) return false;
    const days = job.scheduleDays || [];
    const todayKey = Object.keys(DAY_MAP)[now.getDay()];
    if (days.length > 0 && !days.includes(todayKey)) return false;
    return true;
  }

  if (job.schedule === 'weekly') {
    if (now.getDay() !== DAY_MAP[job.scheduleDay || 'mon']) return false;
    return dueNow;
  }

  return false;
}

function notifyDesktop(sessionId, repoName, results) {
  broadcast(sessionId, { type: 'scheduled_job_done', repo: repoName, results });

  const anyFail  = results.some(r => !r.ok && !r.funny);
  const funnyRow = results.find(r => r.funny);
  const taskRows = results.filter(r => !r.funny);
  const title    = anyFail ? `⚠️ OASIS — ${repoName}` : `✅ OASIS — ${repoName}`;
  const lines    = taskRows.map(r => `${r.ok ? '✓' : '✗'} ${r.task}: ${r.message.replace(/```[\s\S]*?```/g, '').replace(/\n+/g, ' ').slice(0, 100)}`);
  if (funnyRow) lines.push(`🎉 ${funnyRow.message}`);
  nativeNotify(title, lines.join('\n') || 'Scheduled job complete');
}

async function schedTaskPull(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  if (!fs.existsSync(cloneDir)) return { ok: false, message: 'Repo not cloned locally' };

  // Use the repo's own origin URL (respects whatever path/format was used at clone time)
  // and inject the token. Fallback to constructing from session fields if origin isn't set.
  let originUrl = '';
  try { originUrl = (await execQuiet(`git -C "${cloneDir}" remote get-url origin`)).trim(); } catch (_) {}
  if (!originUrl) {
    const ghHost = sess.githubUrl.replace(/\/$/, '').replace(/^https?:\/\//, '');
    originUrl = `https://${ghHost}/${sess.org}/${repoName}.git`;
  }
  // Strip any existing credentials from the URL, then inject the token.
  const tokenUrl = originUrl.replace(/^(https?:\/\/)([^@]+@)?/, `$1${sess.token}@`);

  try {
    const before = await execQuiet(`git -C "${cloneDir}" rev-list HEAD --count`).catch(() => '0');

    // Disable credential helpers so the token embedded in the URL is used directly.
    // Capture stderr merged into stdout so git error messages reach the user.
    externalCalls.assertAllowed('GitHub');
    await new Promise((resolve, reject) => {
      exec(
        `git -C "${cloneDir}" -c credential.helper="" pull "${tokenUrl}" 2>&1`,
        { timeout: 60000 },
        (err, stdout) => {
          if (err) {
            // Strip the token from the error before surfacing it
            const msg = (stdout || err.message || String(err))
              .replace(new RegExp(sess.token, 'g'), '***')
              .replace(/https?:\/\/[^@\s]+@/g, 'https://***@')
              .trim().slice(0, 300);
            reject(new Error(msg));
          } else resolve(stdout);
        }
      );
    });

    const after = await execQuiet(`git -C "${cloneDir}" rev-list HEAD --count`).catch(() => '0');
    const pulled = Math.max(0, parseInt(after) - parseInt(before));
    return { ok: true, message: pulled > 0 ? `Pulled ${pulled} new commit(s)` : 'Already up to date' };
  } catch (e) {
    return { ok: false, message: e.message || String(e) };
  }
}

// Commits merged via GitHub's default squash-merge carry the PR title in the
// subject as "<title> (#123)" — this is the only place a PR title is
// recoverable from `git log` without an extra API call per commit.
const SCHED_PR_TITLE_RE = /^(.*)\s\(#(\d+)\)$/;
// Loose JIRA-style ticket key (e.g. OASIS-123) — scanned out of the subject line.
const SCHED_TICKET_RE = /\b([A-Z][A-Z0-9]{1,9}-\d+)\b/;

// Checks the tracked remote branch for commits landed in the last 24h and
// surfaces each one's PR title + ticket id. Returns null (not an ok:true
// "nothing found" result) when there's nothing new, so callers can stay
// completely silent instead of notifying about an empty check.
async function schedTaskCheckCommits(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  if (!fs.existsSync(cloneDir)) return { ok: false, message: 'Repo not cloned locally' };

  const SEP = '\x1f', END = '\x1e';
  const logArgs = `--since="24 hours ago" --format="%H${SEP}%an${SEP}%s${END}"`;

  try {
    externalCalls.assertAllowed('GitHub');
    await execQuiet(`git -C "${cloneDir}" fetch --quiet origin`, { timeout: 30000 });

    let raw;
    try {
      raw = await execQuiet(`git -C "${cloneDir}" log @{u} ${logArgs}`, { timeout: 10000 });
    } catch (_) {
      // no upstream tracking branch — fall back to what was just fetched
      raw = await execQuiet(`git -C "${cloneDir}" log FETCH_HEAD ${logArgs}`, { timeout: 10000 });
    }

    const commits = raw.split(END).map(e => e.trim()).filter(Boolean).map(entry => {
      const [hash, author, subject = ''] = entry.split(SEP);
      const prMatch = SCHED_PR_TITLE_RE.exec(subject);
      const ticketMatch = SCHED_TICKET_RE.exec(subject);
      return {
        hash: (hash || '').slice(0, 7),
        author,
        title: prMatch ? prMatch[1] : subject,
        prNumber: prMatch ? prMatch[2] : null,
        ticket: ticketMatch ? ticketMatch[1] : null,
      };
    });

    if (!commits.length) return null;

    const lines = commits.map(c =>
      `${c.prNumber ? `#${c.prNumber} — ` : ''}${c.title}${c.ticket ? ` [${c.ticket}]` : ''}`
    );
    return {
      ok: true,
      status: 'new-commits',
      message: `${commits.length} commit${commits.length === 1 ? '' : 's'} in the last 24h:\n${lines.join('\n')}`,
    };
  } catch (e) {
    return { ok: false, message: e.message || String(e) };
  }
}

async function schedTaskBuildCheck(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  let branch = 'main';
  try { branch = await execQuiet(`git -C "${cloneDir}" rev-parse --abbrev-ref HEAD`, { timeout: 5000 }); } catch (_) {}

  const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser || sess.githubLogin || '';

  if (!jToken) return { ok: true, message: 'Jenkins not configured — skipping build check', status: 'skipped' };

  try {
    const jApiUrl = `${jUrl}/job/iready/job/${encodeURIComponent(repoName)}/job/${encodeURIComponent(branch)}/lastBuild/api/json`;
    const jr = await axios.get(jApiUrl, { auth: { username: jUser, password: jToken }, timeout: 8000 });
    const d = jr.data;
    if (d.building) return { ok: true, message: `Build #${d.number} is currently running`, status: 'running' };
    if (d.result === 'SUCCESS')  return { ok: true,  message: `Build #${d.number} passed ✓`, status: 'success' };
    if (d.result === 'FAILURE')  return { ok: false, message: `Build #${d.number} FAILED — check Jenkins`, status: 'failure', url: d.url };
    if (d.result === 'UNSTABLE') return { ok: false, message: `Build #${d.number} is unstable`, status: 'unstable', url: d.url };
    return { ok: true, message: `Last build: ${d.result || 'unknown'}`, status: 'unknown' };
  } catch (e) {
    if (e.response?.status === 404) return { ok: true, message: `No Jenkins build found for ${repoName}/${branch}`, status: 'not-found' };
    return { ok: true, message: `Jenkins unreachable: ${e.message?.slice(0, 80)}`, status: 'error' };
  }
}

// Fetch the Jenkins console log for a repo's last build (multibranch pipeline:
// /job/iready/job/<repo>/job/<branch>/lastBuild). Resolves the branch from the
// local clone. Returns { result, number, url, console } or null when there's no
// build / no token. Console text is tail-trimmed for prompt budget.
async function fetchJenkinsConsole(sess, repoName) {
  const jUrl   = sess.jenkinsUrl.replace(/\/$/, '');
  const jToken = sess.jenkinsToken || '';
  const jUser  = sess.jenkinsUser || sess.githubLogin || '';
  if (!jToken) return null;

  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  let branch = 'main';
  try { branch = (await execQuiet(`git -C "${cloneDir}" rev-parse --abbrev-ref HEAD`, { timeout: 5000 })).trim() || 'main'; } catch (_) {}

  const auth = { username: jUser, password: jToken };
  const jobBase = `${jUrl}/job/iready/job/${encodeURIComponent(repoName)}/job/${encodeURIComponent(branch)}/lastBuild`;
  try {
    const meta = await axios.get(`${jobBase}/api/json`, { auth, timeout: 8000 });
    const d = meta.data || {};
    let consoleText = '';
    try {
      const c = await axios.get(`${jobBase}/consoleText`, { auth, timeout: 12000, responseType: 'text' });
      consoleText = String(c.data || '');
    } catch (_) {}
    return {
      branch,
      result: d.result, number: d.number, building: d.building, url: d.url,
      console: consoleText.length > 7000 ? consoleText.slice(-7000) : consoleText,
    };
  } catch (e) {
    if (e.response?.status === 404) return null; // no job/build for this repo+branch
    console.warn(`[jenkins-console] ${repoName}@${branch}: ${e.message?.slice(0, 100)}`);
    return null;
  }
}

async function schedTaskCodeReview(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  if (!fs.existsSync(cloneDir)) return { ok: false, message: 'Repo not cloned' };

  const ai = aiClientFor(sess);
  if (!ai.available()) return { ok: true, message: 'AI not configured — set a provider in Settings', status: 'skipped' };

  let diff = '';
  try {
    diff = await execQuiet(`git -C "${cloneDir}" diff HEAD~5..HEAD --unified=3 2>/dev/null`, { timeout: 15000 });
    if (!diff.trim()) diff = await execQuiet(`git -C "${cloneDir}" show --stat HEAD 2>/dev/null`, { timeout: 10000 });
  } catch (_) {
    diff = await execQuiet(`git -C "${cloneDir}" show --stat HEAD 2>/dev/null`, { timeout: 10000 }).catch(() => '');
  }
  if (!diff.trim()) return { ok: true, message: 'No recent changes to review', status: 'clean' };

  const review = await ai.complete({
    system: 'You are a senior software engineer reviewing code changes. Analyze the git diff and give a concise code review. Focus on: potential bugs, security issues, performance, and code quality. Under 300 words. Format as markdown bullet points.',
    messages: [{ role: 'user', content: `Repo: ${repoName}\n\nRecent changes:\n${diff.slice(0, 6000)}` }],
    maxTokens: 512,
  });
  return { ok: true, message: review || 'No issues found', status: 'done' };
}

async function schedTaskSecurityScan(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  if (!fs.existsSync(cloneDir)) return { ok: false, message: 'Repo not cloned' };

  const hasPackageJson = fs.existsSync(path.join(cloneDir, 'package.json'));
  const hasPom         = fs.existsSync(path.join(cloneDir, 'pom.xml'));
  const hasRequirements = fs.existsSync(path.join(cloneDir, 'requirements.txt'));

  if (hasPackageJson) {
    const loginEnv = await getLoginEnv();
    const auditOut = await new Promise(resolve => {
      exec(`npm audit --json 2>/dev/null`, { cwd: cloneDir, timeout: 90000, env: loginEnv, maxBuffer: 5 * 1024 * 1024 },
        (_err, stdout) => resolve(stdout || '{}'));
    });
    try {
      const audit = JSON.parse(auditOut);
      const v = audit.metadata?.vulnerabilities || {};
      const critical = v.critical || 0, high = v.high || 0, moderate = v.moderate || 0;
      const total = v.total || (critical + high + moderate + (v.low || 0));
      if (total === 0) return { ok: true, message: 'No vulnerabilities found ✓', status: 'clean' };
      const msg = `${total} vulnerabilities: ${critical} critical, ${high} high, ${moderate} moderate`;
      return { ok: critical + high === 0, message: msg, status: critical + high > 0 ? 'vulnerable' : 'moderate' };
    } catch (_) {
      return { ok: true, message: 'npm audit completed — check output for details', status: 'done' };
    }
  }

  if (hasPom) {
    return { ok: true, message: 'Java: run `mvn org.owasp:dependency-check-maven:check` locally for a full CVE scan', status: 'manual' };
  }

  if (hasRequirements) {
    try {
      const out = await execQuiet(`pip-audit -r "${path.join(cloneDir, 'requirements.txt')}" 2>&1`, { timeout: 60000 });
      const found = /(\d+)\s+vulnerabilit/i.exec(out);
      if (found && parseInt(found[1]) > 0) return { ok: false, message: `${found[1]} Python vulnerabilities found — run pip-audit locally for details`, status: 'vulnerable' };
      return { ok: true, message: 'No Python vulnerabilities found ✓', status: 'clean' };
    } catch (_) {
      return { ok: true, message: 'Python: install pip-audit for automated dependency scanning', status: 'manual' };
    }
  }

  return { ok: true, message: 'Security scan not available for this project type', status: 'unsupported' };
}

async function schedTaskCodeImprovements(sess, repoName) {
  const cloneDir = path.join(expandHome(sess.cloneDir), repoName);
  if (!fs.existsSync(cloneDir)) return { ok: false, message: 'Repo not cloned' };

  const ai = aiClientFor(sess);
  if (!ai.available()) return { ok: true, message: 'AI not configured — set a provider in Settings', status: 'skipped' };

  let recentFilesOut = '';
  try { recentFilesOut = await execQuiet(`git -C "${cloneDir}" log --since="7 days ago" --name-only --format="" 2>/dev/null`, { timeout: 10000 }); } catch (_) {}

  const files = [...new Set(
    recentFilesOut.split('\n')
      .filter(f => f.trim() && /\.(java|js|ts|jsx|tsx|py|go|kt|scala)$/.test(f))
  )].slice(0, 3);

  if (!files.length) return { ok: true, message: 'No recently modified source files found in the last 7 days', status: 'clean' };

  const snippets = [];
  for (const f of files) {
    try {
      const content = fs.readFileSync(path.join(cloneDir, f), 'utf8').split('\n').slice(0, 150).join('\n');
      snippets.push(`### ${f}\n\`\`\`\n${content}\n\`\`\``);
    } catch (_) {}
  }
  if (!snippets.length) return { ok: true, message: 'Could not read recently modified files', status: 'skipped' };

  const suggestions = await ai.complete({
    system: 'You are a senior software engineer reviewing code quality. Suggest 3-5 concrete improvements for the provided code: readability, performance, error handling, or maintainability. Be specific — reference function names or line numbers. Under 250 words. Format as markdown bullet points.',
    messages: [{ role: 'user', content: `Repo: ${repoName}\nRecently modified files:\n\n${snippets.join('\n\n')}` }],
    maxTokens: 512,
  });
  return { ok: true, message: suggestions || 'No improvements suggested', status: 'done' };
}

async function runScheduledJob(repoName, jobConfig, sess) {
  const tasks = jobConfig.tasks || {};
  const results = [];

  if (tasks.pull) {
    try { results.push({ task: 'Pull', ...(await schedTaskPull(sess, repoName)) }); }
    catch (e) { results.push({ task: 'Pull', ok: false, message: e.message }); }
  }
  if (tasks.checkCommits) {
    try {
      const r = await schedTaskCheckCommits(sess, repoName);
      if (r) results.push({ task: 'Check Commits', ...r }); // null = nothing in the last 24h, stay silent
    } catch (e) { results.push({ task: 'Check Commits', ok: false, message: e.message }); }
  }
  if (tasks.buildCheck) {
    try { results.push({ task: 'Build Check', ...(await schedTaskBuildCheck(sess, repoName)) }); }
    catch (e) { results.push({ task: 'Build Check', ok: false, message: e.message }); }
  }
  if (tasks.codeReview) {
    try { results.push({ task: 'Code Review', ...(await schedTaskCodeReview(sess, repoName)) }); }
    catch (e) { results.push({ task: 'Code Review', ok: false, message: e.message }); }
  }
  if (tasks.securityScan) {
    try { results.push({ task: 'Security Scan', ...(await schedTaskSecurityScan(sess, repoName)) }); }
    catch (e) { results.push({ task: 'Security Scan', ok: false, message: e.message }); }
  }
  if (tasks.codeImprovements) {
    try { results.push({ task: 'Code Improvements', ...(await schedTaskCodeImprovements(sess, repoName)) }); }
    catch (e) { results.push({ task: 'Code Improvements', ok: false, message: e.message }); }
  }

  // If everything passed, ask the configured AI provider for a funny celebratory comment
  if (results.length > 0 && results.every(r => r.ok)) {
    try {
      const funnyMsg = await schedFunnyComment(sess, repoName, results);
      if (funnyMsg) results.push({ task: '🎉 Claude Says', ok: true, message: funnyMsg, funny: true });
    } catch (e) { console.warn(`[scheduler] funny comment skipped for ${repoName}:`, e.message); }
  }

  return results;
}

async function schedFunnyComment(sess, repoName, results) {
  const ai = aiClientFor(sess);
  if (!ai.available()) return null;

  const summary = results.map(r => `${r.task}: ${r.message.slice(0, 80)}`).join(', ');
  const msg = await ai.complete({
    system: 'You are a witty developer assistant. Write ONE short funny comment (max 2 sentences) celebrating that all automated health checks passed for a repo. Be clever, use dev humor, emojis welcome. No markdown, no quotes, just the comment.',
    messages: [{ role: 'user', content: `Repo: ${repoName}\nAll checks passed: ${summary}` }],
    maxTokens: 80,
  });
  return msg || null;
}


function initScheduler() {
  setInterval(async () => {
    const jobs = loadScheduledJobs();
    if (!Object.keys(jobs).length) return;

    const sessionEntry = Object.entries(sessions).find(([, s]) => s.githubUrl && s.token);
    if (!sessionEntry) return;
    const [activeSessionId, activeSess] = sessionEntry;

    const now = new Date();
    for (const [repoName, job] of Object.entries(jobs)) {
      if (!shouldRunJob(job, now)) continue;

      jobs[repoName].lastRun = now.toISOString();
      jobs[repoName].lastStatus = 'running';
      saveScheduledJobs(jobs);

      try {
        const results = await runScheduledJob(repoName, job, activeSess);
        const anyFail = results.some(r => !r.ok);
        jobs[repoName].lastStatus = anyFail ? 'partial' : 'success';
        jobs[repoName].lastReport = results.map(r => `${r.task}: ${r.message}`).join(' | ');
        saveScheduledJobs(jobs);
        if (results.length) notifyDesktop(activeSessionId, repoName, results);
      } catch (e) {
        jobs[repoName].lastStatus = 'failed';
        jobs[repoName].lastReport = e.message;
        saveScheduledJobs(jobs);
        notifyDesktop(activeSessionId, repoName, [{ task: 'Scheduler', ok: false, message: e.message }]);
      }
    }
  }, 30000);
}

/** GET /api/schedule?session=SID — list all scheduled jobs */
app.get('/api/schedule', (req, res) => {
  if (!sessions[req.query.session]) return res.status(401).json({ error: 'Invalid session' });
  res.json(loadScheduledJobs());
});

/** GET /api/schedule/:repo?session=SID — get schedule for one repo */
app.get('/api/schedule/:repo', (req, res) => {
  if (!sessions[req.query.session]) return res.status(401).json({ error: 'Invalid session' });
  const jobs = loadScheduledJobs();
  res.json(jobs[req.params.repo] || null);
});

/** POST /api/schedule/:repo — save schedule config */
app.post('/api/schedule/:repo', (req, res) => {
  const { session, schedule, scheduleTime, scheduleDays, scheduleDay, tasks, slack } = req.body;
  if (!sessions[session]) return res.status(401).json({ error: 'Invalid session' });

  const jobs = loadScheduledJobs();
  const existing = jobs[req.params.repo] || {};
  jobs[req.params.repo] = {
    enabled: true,
    schedule: schedule || 'manual',
    scheduleTime: scheduleTime || '09:00',
    scheduleDays: scheduleDays || [],
    scheduleDay: scheduleDay || 'mon',
    tasks: tasks || {},
    slack: slack || {},
    lastRun: existing.lastRun || null,
    lastStatus: existing.lastStatus || null,
    lastReport: existing.lastReport || null,
  };
  saveScheduledJobs(jobs);
  res.json({ ok: true });
});

/** DELETE /api/schedule/:repo?session=SID — remove schedule */
app.delete('/api/schedule/:repo', (req, res) => {
  if (!sessions[req.query.session]) return res.status(401).json({ error: 'Invalid session' });
  const jobs = loadScheduledJobs();
  delete jobs[req.params.repo];
  saveScheduledJobs(jobs);
  res.json({ ok: true });
});

/** POST /api/schedule/:repo/run — manual trigger */
app.post('/api/schedule/:repo/run', async (req, res) => {
  const { session } = req.body;
  const sess = sessions[session];
  if (!sess) return res.status(401).json({ error: 'Invalid session' });

  const jobs = loadScheduledJobs();
  const job = jobs[req.params.repo];
  if (!job) return res.status(404).json({ error: 'No schedule configured for this repo' });

  res.json({ ok: true, message: 'Job started' });

  jobs[req.params.repo].lastRun = new Date().toISOString();
  jobs[req.params.repo].lastStatus = 'running';
  saveScheduledJobs(jobs);

  try {
    const results = await runScheduledJob(req.params.repo, job, sess);
    const anyFail = results.some(r => !r.ok);
    jobs[req.params.repo].lastStatus = anyFail ? 'partial' : 'success';
    jobs[req.params.repo].lastReport = results.map(r => `${r.task}: ${r.message}`).join('\n\n');
    saveScheduledJobs(jobs);
    if (results.length) notifyDesktop(session, req.params.repo, results);
  } catch (e) {
    jobs[req.params.repo].lastStatus = 'failed';
    jobs[req.params.repo].lastReport = e.message;
    saveScheduledJobs(jobs);
    notifyDesktop(session, req.params.repo, [{ task: 'Scheduler', ok: false, message: e.message }]);
  }
});

initScheduler();
installBranches(app, { sessions, expandHome, execQuiet, isProjectDir, externalCalls });

installJira(app, { sessions, expandHome, execQuiet, isProjectDir, findOpenPrForBranch, findMergedPrForBranch, PREFS_PATH, externalCalls });
// Appraisal Prep: a private, per-user pack built from the session's own JIRA and
// GitHub data. Deliberately NOT given PREFS_PATH: nothing it saves goes in the
// prefs file (which /api/prefs serves without a session).
installAppraisal(app, {
  sessions, aiClientFor, searchAll: jiraSearchAll,
  jiraHttp: axios.create({ httpsAgent: JIRA_HTTPS_AGENT }), githubHttp: axios,
});
installPerfDiagnostics(app, { sessions, PREFS_PATH });

// ── Serve index for all unmatched routes (MUST be the last route) ──────────
// Pre-inject the saved theme onto <html data-theme> so the correct palette is
// applied before first paint — avoids a flash when the user prefers light mode.
// (localStorage can't be relied on in Electron because the port changes each launch.)
app.get('*', (_req, res) => {
  try {
    const prefs = fs.existsSync(PREFS_PATH) ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {}) : {};
    if (prefs.theme !== 'light') return res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
    const html = fs.readFileSync(path.join(PUBLIC_DIR, 'index.html'), 'utf8')
      .replace('<html lang="en">', '<html lang="en" data-theme="light">');
    res.setHeader('Content-Type', 'text/html; charset=utf-8').send(html);
  } catch (_) {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
  }
});

// Loopback by default.
//
// server.listen(port) with no host binds 0.0.0.0 — every interface — so an
// OASIS instance was reachable by anyone on the same network who knew the port.
// That was low-stakes when the app only listed repositories. It is not now:
// ~/.oasis-security/store.json records where credentials appear across the
// codebase, /api/security/findings serves it, and none of the API is
// authenticated. On an office or café network that is a map of the company's
// secrets, available to whoever asks.
//
// Set OASIS_BIND=0.0.0.0 to expose it deliberately (a container, or a shared
// machine). Anything other than loopback logs a warning, because doing it by
// accident is the failure this guards against.
const BIND_HOST = process.env.OASIS_BIND || '127.0.0.1';

// Listen on the given port (0 = OS-assigned free port) and resolve with the
// actual URL. Used both by the CLI (`npm start`) and the Electron main process.
function start(port = PORT, host = BIND_HOST) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      const actualPort = server.address().port;
      console.log(`\n  ⚡ i-Ready OASIS running at http://localhost:${actualPort}\n`);
      if (host !== '127.0.0.1' && host !== 'localhost') {
        console.warn(
          `  ⚠ Listening on ${host} — reachable from the network. The security API is\n` +
          '    unauthenticated and serves finding locations. Use 127.0.0.1 unless this is\n' +
          '    a deliberately isolated environment.\n'
        );
      }
      // Wellness defaults to ON. Only stay off if the user explicitly disabled
      // it in a previous session (prefs.wellnessEnabled === false).
      try {
        const prefs = fs.existsSync(PREFS_PATH)
          ? (JSON.parse(fs.readFileSync(PREFS_PATH, 'utf8')) || {}) : {};
        if (prefs.wellnessEnabled !== false) {
          _ws.enabled = true;
          wellnessStartTimer();
          console.log('[wellness] enabled' + (prefs.wellnessEnabled === true ? ' (resumed from saved preference)' : ' (default on)'));
        }
      } catch (e) { console.warn('[wellness] prefs restore failed:', e.message); }
      resolve({ server, port: actualPort, url: `http://localhost:${actualPort}` });
    });
  });
}

// Stops the background timers that would keep the process alive or run after quit (the rules update timer).
function stop() {
  try { stopSecurity(security); } catch (_) { /* quitting anyway */ }
}

// Run directly via `node server/index.js`; when required (Electron) just export.
if (require.main === module) {
  for (const sig of ['SIGINT', 'SIGTERM']) process.once(sig, () => { stop(); process.exit(0); });
  start();
}

module.exports = { app, server, start, stop };
