'use strict';
const fs = require('fs');

function readPrefs(prefsPath) {
  try {
    return fs.existsSync(prefsPath) ? (JSON.parse(fs.readFileSync(prefsPath, 'utf8')) || {}) : {};
  } catch (_) {
    return {};
  }
}

function writePrefs(prefsPath, prefs) {
  fs.writeFileSync(prefsPath, JSON.stringify(prefs, null, 2), 'utf8');
}

function listEnvironments(prefsPath) {
  const prefs = readPrefs(prefsPath);
  return (prefs.perfDiagnostics && prefs.perfDiagnostics.environments) || [];
}

const SECRET_KEYS = ['ddApiKey', 'ddAppKey', 'appdClientId', 'appdClientSecret'];

function stripSecrets(environment) {
  const clean = { ...environment };
  if (clean.datadog) {
    clean.datadog = { ...clean.datadog };
    SECRET_KEYS.forEach(k => delete clean.datadog[k]);
  }
  if (clean.appdynamics) {
    clean.appdynamics = { ...clean.appdynamics };
    SECRET_KEYS.forEach(k => delete clean.appdynamics[k]);
  }
  return clean;
}

function saveEnvironment(prefsPath, environment) {
  const prefs = readPrefs(prefsPath);
  if (!prefs.perfDiagnostics) prefs.perfDiagnostics = { environments: [] };
  if (!Array.isArray(prefs.perfDiagnostics.environments)) prefs.perfDiagnostics.environments = [];
  const list = prefs.perfDiagnostics.environments;
  const clean = stripSecrets(environment);
  const i = list.findIndex(e => e.id === clean.id);
  if (i >= 0) list[i] = clean; else list.push(clean);
  writePrefs(prefsPath, prefs);
  return clean;
}

function deleteEnvironment(prefsPath, id) {
  const prefs = readPrefs(prefsPath);
  if (!prefs.perfDiagnostics) return;
  prefs.perfDiagnostics.environments = (prefs.perfDiagnostics.environments || []).filter(e => e.id !== id);
  writePrefs(prefsPath, prefs);
}

module.exports = { listEnvironments, saveEnvironment, deleteEnvironment, stripSecrets, SECRET_KEYS };
