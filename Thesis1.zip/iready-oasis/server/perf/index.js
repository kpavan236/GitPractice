'use strict';
const { randomBytes } = require('crypto');
const defaultStore = require('./store');
const defaultDatadog = require('./datadog');
const defaultAppdynamics = require('./appdynamics');
const defaultDiagnose = require('./diagnose');

function newEnvId() {
  return 'env_' + Date.now().toString(36) + '_' + randomBytes(4).toString('hex');
}

// The same four secret names store.js strips before writing to disk — kept in
// one place so the two never drift apart.
const { SECRET_KEYS } = defaultStore;

// Merge an incoming `secrets` patch into what the session already holds.
// An explicit `null` (or empty string) means "the user cleared this field" and
// DELETES the key, rather than leaving the previous value behind forever —
// omitting a key still means "unchanged", which is what a restore posts.
function mergeSecrets(previous, patch) {
  const merged = { ...(previous || {}) };
  for (const key of SECRET_KEYS) {
    if (!patch || !(key in patch)) continue;
    const value = patch[key];
    if (value === null || value === undefined || value === '') delete merged[key];
    else merged[key] = value;
  }
  return merged;
}

// Both of a platform's secrets are required before it counts as configured:
// one key alone cannot authenticate either API, and reporting it as configured
// made the tab offer data it could never fetch.
function platformStatus(env, secrets) {
  return {
    datadogConfigured: !!(env.datadog && secrets.ddApiKey && secrets.ddAppKey),
    appdynamicsConfigured: !!(env.appdynamics && secrets.appdClientId && secrets.appdClientSecret),
  };
}

function authError(e) {
  const status = e?.response?.status;
  return status === 401 || status === 403 ? 'authentication failed' : (e?.message || 'connection failed');
}

function installPerfDiagnostics(app, { sessions, PREFS_PATH, deps } = {}) {
  const store = deps?.store || defaultStore;
  const datadog = deps?.datadog || defaultDatadog;
  const appdynamics = deps?.appdynamics || defaultAppdynamics;
  const runDiagnose = deps?.runDiagnose || defaultDiagnose.runDiagnose;
  const suggestFix = deps?.suggestFix || defaultDiagnose.suggestFix;

  function sessSecrets(sess, envId) {
    return (sess.perfEnvSecrets || {})[envId] || {};
  }

  function resolvedConfig(sess, env) {
    const secrets = sessSecrets(sess, env.id);
    const status = platformStatus(env, secrets);
    const out = {};
    if (status.datadogConfigured) {
      out.datadog = { ...env.datadog, baseUrl: datadog.siteToBaseUrl(env.datadog.site), ddApiKey: secrets.ddApiKey, ddAppKey: secrets.ddAppKey };
    }
    if (status.appdynamicsConfigured) {
      out.appdynamics = { ...env.appdynamics, clientId: secrets.appdClientId, clientSecret: secrets.appdClientSecret };
    }
    return out;
  }

  app.get('/api/perf/environments', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const environments = store.listEnvironments(PREFS_PATH).map(env => ({
      ...env,
      ...platformStatus(env, sessSecrets(sess, env.id)),
    }));
    res.json({ environments });
  });

  app.post('/api/perf/environments', async (req, res) => {
    const { session, environment, secrets, restore } = req.body || {};
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!environment || !environment.name) return res.status(400).json({ error: 'environment.name is required' });

    const env = { ...environment, id: environment.id || newEnvId() };
    const warnings = [];

    if (!restore) {
      // Each platform is validated on its own and a failure is a WARNING, not a
      // rejection: a rotated Datadog key must not throw away a save that also
      // carries working AppDynamics credentials and an edited environment name
      // (design spec: "surfaced as a warning rather than a hard error").
      const checks = [];
      if (env.datadog && secrets?.ddApiKey && secrets?.ddAppKey) {
        checks.push(['datadog', 'Datadog', () => datadog.validate({
          ...env.datadog, baseUrl: datadog.siteToBaseUrl(env.datadog.site),
          ddApiKey: secrets.ddApiKey, ddAppKey: secrets.ddAppKey,
        })]);
      }
      if (env.appdynamics && secrets?.appdClientId && secrets?.appdClientSecret) {
        checks.push(['appdynamics', 'AppDynamics', () => appdynamics.validate({
          ...env.appdynamics, clientId: secrets.appdClientId, clientSecret: secrets.appdClientSecret,
        })]);
      }
      const settled = await Promise.allSettled(checks.map(([, , run]) => run()));
      settled.forEach((result, i) => {
        if (result.status === 'rejected') {
          const [platform, label] = checks[i];
          warnings.push({ platform, message: `${label}: ${authError(result.reason)}` });
        }
      });
      // Persisted regardless of validation outcome — see above.
      store.saveEnvironment(PREFS_PATH, env);
    }

    if (!sess.perfEnvSecrets) sess.perfEnvSecrets = {};
    sess.perfEnvSecrets[env.id] = mergeSecrets(sess.perfEnvSecrets[env.id], secrets);

    res.json({ ok: true, environment: store.stripSecrets(env), warnings });
  });

  app.delete('/api/perf/environments/:id', (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    store.deleteEnvironment(PREFS_PATH, req.params.id);
    if (sess.perfEnvSecrets) delete sess.perfEnvSecrets[req.params.id];
    res.json({ ok: true });
  });

  app.post('/api/perf/test', async (req, res) => {
    const { session, platform, config } = req.body || {};
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    try {
      if (platform === 'datadog') await datadog.validate({ ...config, baseUrl: datadog.siteToBaseUrl(config.site) });
      else if (platform === 'appdynamics') await appdynamics.validate(config);
      else return res.status(400).json({ error: `Unknown platform "${platform}"` });
      res.json({ ok: true });
    } catch (e) {
      const status = e.response?.status;
      res.status(400).json({ ok: false, error: status === 401 || status === 403 ? 'Authentication failed' : (e.message || 'Connection failed') });
    }
  });

  app.get('/api/perf/services', async (req, res) => {
    const sess = sessions[req.query.session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const env = store.listEnvironments(PREFS_PATH).find(e => e.id === req.query.environmentId);
    if (!env) return res.status(404).json({ error: 'Environment not found' });
    const cfg = resolvedConfig(sess, env);
    const names = new Set();
    await Promise.all([
      cfg.datadog ? datadog.fetchServices(cfg.datadog).then(s => s.forEach(n => names.add(n))).catch(() => {}) : null,
      cfg.appdynamics ? appdynamics.fetchServices(cfg.appdynamics).then(s => s.forEach(n => names.add(n))).catch(() => {}) : null,
    ]);
    res.json({ services: [...names].sort() });
  });

  app.post('/api/perf/diagnose', async (req, res) => {
    const { session, environmentId, service, timeRange } = req.body || {};
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    const env = store.listEnvironments(PREFS_PATH).find(e => e.id === environmentId);
    if (!env) return res.status(404).json({ error: 'Environment not found' });
    const cfg = resolvedConfig(sess, env);
    if (!cfg.datadog && !cfg.appdynamics) {
      return res.status(400).json({ error: 'No platform is configured (with credentials) for this environment' });
    }
    try {
      // Passed straight through: `{warnings, load: {seriesBySource,
      // highLoadBuckets, from, to}, queries}` — the frontend needs from/to to
      // pin one shared x-axis across all four load charts.
      const result = await runDiagnose({ environment: cfg, service, timeRange, now: Date.now() });
      res.json(result);
    } catch (e) {
      res.status(400).json({ error: e.message || 'Diagnose failed' });
    }
  });

  app.post('/api/perf/suggest-fix', async (req, res) => {
    const { session, query } = req.body || {};
    const sess = sessions[session];
    if (!sess) return res.status(401).json({ error: 'Invalid session' });
    if (!query || !query.queryText) return res.status(400).json({ error: 'query is required' });
    try {
      const suggestion = await suggestFix(sess, query);
      res.json({ suggestion });
    } catch (e) {
      const userError = e.code === 'AI_NOT_CONFIGURED' || e.code === 'QUERY_TEXT_UNAVAILABLE';
      res.status(userError ? 400 : 502).json({ error: e.message || 'Fix suggestion failed' });
    }
  });
}

module.exports = { installPerfDiagnostics, mergeSecrets, platformStatus };
