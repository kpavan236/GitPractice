'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { listEnvironments, saveEnvironment, deleteEnvironment, stripSecrets } = require('./store');

function tmpPrefsPath() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-perf-')), 'prefs.json');
}

test('listEnvironments returns [] when the prefs file does not exist', () => {
  assert.deepEqual(listEnvironments(tmpPrefsPath()), []);
});

test('saveEnvironment + listEnvironments round-trip', () => {
  const p = tmpPrefsPath();
  saveEnvironment(p, { id: 'env_1', name: 'Production', datadog: { site: 'datadoghq.com', envTag: 'prod' } });
  const envs = listEnvironments(p);
  assert.equal(envs.length, 1);
  assert.equal(envs[0].name, 'Production');
  assert.equal(envs[0].datadog.envTag, 'prod');
});

test('saveEnvironment strips secret fields before persisting to disk', () => {
  const p = tmpPrefsPath();
  saveEnvironment(p, {
    id: 'env_1', name: 'Prod',
    datadog: { site: 'datadoghq.com', envTag: 'prod', ddApiKey: 'secret-key', ddAppKey: 'secret-app' },
  });
  const raw = fs.readFileSync(p, 'utf8');
  assert.equal(raw.includes('secret-key'), false);
  assert.equal(raw.includes('secret-app'), false);
});

test('saveEnvironment updates an existing environment by id instead of duplicating it', () => {
  const p = tmpPrefsPath();
  saveEnvironment(p, { id: 'env_1', name: 'Prod' });
  saveEnvironment(p, { id: 'env_1', name: 'Production' });
  const envs = listEnvironments(p);
  assert.equal(envs.length, 1);
  assert.equal(envs[0].name, 'Production');
});

test('deleteEnvironment removes only the matching id', () => {
  const p = tmpPrefsPath();
  saveEnvironment(p, { id: 'env_1', name: 'Prod' });
  saveEnvironment(p, { id: 'env_2', name: 'Staging' });
  deleteEnvironment(p, 'env_1');
  const envs = listEnvironments(p);
  assert.equal(envs.length, 1);
  assert.equal(envs[0].id, 'env_2');
});

test('stripSecrets removes known secret keys from both platform configs', () => {
  const clean = stripSecrets({
    id: 'env_1',
    datadog: { site: 'datadoghq.com', ddApiKey: 'a', ddAppKey: 'b' },
    appdynamics: { controllerUrl: 'https://x', appdClientId: 'c', appdClientSecret: 'd' },
  });
  assert.equal(clean.datadog.ddApiKey, undefined);
  assert.equal(clean.datadog.site, 'datadoghq.com');
  assert.equal(clean.appdynamics.appdClientSecret, undefined);
});

test('stripSecrets is a no-op when there are no secret fields present', () => {
  const clean = stripSecrets({ id: 'env_1', name: 'Prod' });
  assert.deepEqual(clean, { id: 'env_1', name: 'Prod' });
});
