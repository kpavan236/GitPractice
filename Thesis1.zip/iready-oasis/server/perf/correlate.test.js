'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  resolveTimeRange, bucketWidthMs, bucketize, highLoadThreshold,
  findHighLoadBuckets, isLoadCorrelated, correlate, correlateBySource,
} = require('./correlate');

test('resolveTimeRange converts a known range to from/to around `now`', () => {
  const now = 1000000;
  const { from, to } = resolveTimeRange('1h', now);
  assert.equal(to, now);
  assert.equal(from, now - 60 * 60 * 1000);
});

test('resolveTimeRange throws on an unknown range', () => {
  assert.throws(() => resolveTimeRange('3w', 1000));
});

test('bucketWidthMs is clamped to a 60s floor for short windows', () => {
  assert.equal(bucketWidthMs(0, 30 * 1000), 60000);
});

test('bucketWidthMs grows for longer windows', () => {
  const wide = bucketWidthMs(0, 24 * 60 * 60 * 1000);
  assert.ok(wide > 60000);
});

test('bucketize averages points within each bucket', () => {
  const points = [{ t: 0, v: 10 }, { t: 500, v: 20 }, { t: 1000, v: 30 }];
  const buckets = bucketize(points, 0, 2000, 1000);
  assert.equal(buckets.length, 2);
  assert.equal(buckets[0].avg, 15);
  assert.equal(buckets[1].avg, 30);
});

test('bucketize returns null avg for a bucket with no points', () => {
  const buckets = bucketize([], 0, 1000, 1000);
  assert.equal(buckets[0].avg, null);
});

test('highLoadThreshold is Infinity when every bucket is empty', () => {
  assert.equal(highLoadThreshold([{ avg: null }, { avg: null }]), Infinity);
});

test('highLoadThreshold is mean + 1 stddev of the non-null averages', () => {
  const buckets = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(v => ({ avg: v }));
  // mean 5.5, stddev ~2.87 -> threshold ~8.37
  const threshold = highLoadThreshold(buckets);
  assert.ok(threshold > 8 && threshold < 8.5, `expected ~8.37, got ${threshold}`);
});

test('findHighLoadBuckets flags only the bucket where a metric spikes above its own mean+stddev', () => {
  const from = 0, to = 4000, width = 1000;
  const cpu = [{ t: 0, v: 10 }, { t: 1000, v: 10 }, { t: 2000, v: 10 }, { t: 3000, v: 90 }];
  const highLoad = findHighLoadBuckets({ cpu, memory: [], throughput: [], connections: [] }, from, to, width);
  assert.equal(highLoad.length, 1);
  assert.equal(highLoad[0].from, 3000);
});

test('findHighLoadBuckets returns [] when every metric series is empty', () => {
  const highLoad = findHighLoadBuckets({ cpu: [], memory: [], throughput: [], connections: [] }, 0, 1000, 1000);
  assert.deepEqual(highLoad, []);
});

test('findHighLoadBuckets returns [] when a metric has no variance at all', () => {
  const cpu = [{ t: 0, v: 50 }, { t: 1000, v: 50 }, { t: 2000, v: 50 }];
  const highLoad = findHighLoadBuckets({ cpu, memory: [], throughput: [], connections: [] }, 0, 3000, 1000);
  assert.deepEqual(highLoad, []);
});

test('isLoadCorrelated checks occurrence timestamps against high-load buckets when available', () => {
  const highLoadBuckets = [{ from: 1000, to: 2000 }];
  assert.equal(isLoadCorrelated({ occurrences: [1500] }, highLoadBuckets), true);
  assert.equal(isLoadCorrelated({ occurrences: [500] }, highLoadBuckets), false);
});

test('isLoadCorrelated falls back to "any high-load bucket in window" for aggregate-only queries', () => {
  assert.equal(isLoadCorrelated({}, [{ from: 0, to: 100 }]), true);
  assert.equal(isLoadCorrelated({}, []), false);
});

test('correlate tags each query with loadCorrelated based on bucket overlap', () => {
  const from = 0, to = 5 * 60 * 1000; // 5 minutes -> 5 buckets of 60s at the width floor
  const load = {
    cpu: [
      { t: 10000, v: 10 }, { t: 70000, v: 10 }, { t: 130000, v: 10 }, { t: 190000, v: 10 },
      { t: 250000, v: 90 }, // bucket 4 (240000-300000) spikes
    ],
    memory: [], throughput: [], connections: [],
  };
  const queries = [
    { queryText: 'q1', occurrences: [255000] }, // inside the spiking bucket
    { queryText: 'q2', occurrences: [15000] },  // inside a calm bucket
  ];
  const { highLoadBuckets, queries: tagged } = correlate(load, queries, { from, to });
  assert.ok(highLoadBuckets.some(b => 250000 >= b.from && 250000 < b.to));
  assert.equal(tagged.find(q => q.queryText === 'q1').loadCorrelated, true);
  assert.equal(tagged.find(q => q.queryText === 'q2').loadCorrelated, false);
});
test('correlateBySource unions each source\'s own high-load buckets', () => {
  const from = 0, to = 5 * 60 * 1000; // 5 buckets of 60s at the width floor
  const seriesBySource = {
    // Datadog spikes in bucket 4 (240000-300000)
    datadog: {
      cpu: [{ t: 10000, v: 10 }, { t: 70000, v: 10 }, { t: 130000, v: 10 }, { t: 190000, v: 10 }, { t: 250000, v: 90 }],
      memory: [], throughput: [], connections: [],
    },
    // AppDynamics spikes in bucket 0 (0-60000)
    appdynamics: {
      cpu: [{ t: 10000, v: 90 }, { t: 70000, v: 10 }, { t: 130000, v: 10 }, { t: 190000, v: 10 }, { t: 250000, v: 10 }],
      memory: [], throughput: [], connections: [],
    },
  };
  const { highLoadBuckets } = correlateBySource(seriesBySource, [], { from, to });
  assert.deepEqual(highLoadBuckets.map(b => b.from), [0, 240000]);
});

test('correlateBySource does not let a large-magnitude source swamp a small one', () => {
  const from = 0, to = 5 * 60 * 1000;
  // Datadog reports memory in bytes; AppDynamics reports it as a percentage.
  // AppD's spike (10% -> 90%) is invisible next to Datadog's byte counts, so
  // pooling the raw values would lose it entirely.
  const seriesBySource = {
    // Bytes, spiking in bucket 0.
    datadog: {
      cpu: [], throughput: [], connections: [],
      memory: [{ t: 10000, v: 9e9 }, { t: 70000, v: 8e9 }, { t: 130000, v: 8e9 }, { t: 190000, v: 8e9 }, { t: 250000, v: 8e9 }],
    },
    // Percent, spiking in bucket 4.
    appdynamics: {
      cpu: [], throughput: [], connections: [],
      memory: [{ t: 10000, v: 10 }, { t: 70000, v: 10 }, { t: 130000, v: 10 }, { t: 190000, v: 10 }, { t: 250000, v: 90 }],
    },
  };
  const perSource = correlateBySource(seriesBySource, [], { from, to });
  assert.deepEqual(perSource.highLoadBuckets.map(b => b.from), [0, 240000]);

  // The old pooled behaviour, for contrast: the byte series sets a threshold in
  // the billions, so AppDynamics' 10% -> 90% spike never clears it and bucket 4
  // is silently dropped.
  const pooled = { cpu: [], throughput: [], connections: [],
    memory: [...seriesBySource.datadog.memory, ...seriesBySource.appdynamics.memory] };
  assert.deepEqual(correlate(pooled, [], { from, to }).highLoadBuckets.map(b => b.from), [0]);
});

test('correlateBySource returns no high-load buckets when every source is empty', () => {
  const empty = { cpu: [], memory: [], throughput: [], connections: [] };
  const { highLoadBuckets, queries } = correlateBySource(
    { datadog: empty, appdynamics: empty }, [{ queryText: 'q' }], { from: 0, to: 60000 }
  );
  assert.deepEqual(highLoadBuckets, []);
  assert.equal(queries[0].loadCorrelated, false);
});
