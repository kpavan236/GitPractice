'use strict';
const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const {
  getOAuthToken, validate, fetchTierMetrics, fetchSlowSql, fetchServices,
  metricPathsFor, aggregateSeries, _tokenCache,
} = require('./appdynamics');

function withServer(handler, run) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(handler);
    server.listen(0, async () => {
      const port = server.address().port;
      try { await run(`http://localhost:${port}`); resolve(); }
      catch (e) { reject(e); }
      finally { server.close(); }
    });
  });
}

beforeEach(() => { _tokenCache.clear(); });

test('getOAuthToken posts client-credentials and returns the token', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ access_token: 'tok-123', expires_in: 300 }));
  }, async (controllerUrl) => {
    const token = await getOAuthToken({ controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret' });
    assert.equal(token, 'tok-123');
  });
});

test('getOAuthToken caches the token until expiry', async () => {
  let calls = 0;
  await withServer((req, res) => {
    calls++;
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ access_token: 'tok-123', expires_in: 300 }));
  }, async (controllerUrl) => {
    const cfg = { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret' };
    await getOAuthToken(cfg);
    await getOAuthToken(cfg);
    assert.equal(calls, 1);
  });
});

test('validate() rejects on a 401 from the applications endpoint', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
    } else {
      res.writeHead(401); res.end('{}');
    }
  }, async (controllerUrl) => {
    await assert.rejects(() => validate({ controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret' }));
  });
});

test('fetchTierMetrics normalizes metric-data rows for all four default metrics', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify([{ metricValues: [{ startTimeInMillis: 1000, value: 30 }] }]));
    }
  }, async (controllerUrl) => {
    const result = await fetchTierMetrics(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 1000 }
    );
    assert.equal(result.cpu.length, 1);
    assert.equal(result.memory.length, 1);
    assert.equal(result.throughput.length, 1);
    assert.equal(result.connections.length, 1);
    assert.equal(result.cpu[0].v, 30);
  });
});

test('fetchSlowSql normalizes databaseCalls rows', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify([{ sqlText: 'SELECT * FROM orders', databaseName: 'orders_db', averageResponseTime: 320, callsPerMinute: 40 }]));
    }
  }, async (controllerUrl) => {
    const rows = await fetchSlowSql(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 1000 }
    );
    assert.equal(rows.length, 1);
    assert.equal(rows[0].queryText, 'SELECT * FROM orders');
    assert.equal(rows[0].avgDurationMs, 320);
  });
});

// Previously this degraded silently to [], which rendered as "No slow queries
// found" for an AppDynamics-only environment whose Database Visibility call was
// actually broken. It now rejects so the diagnose layer can warn about it.
test('fetchSlowSql rejects on failure so the caller can surface a warning', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
    } else {
      res.writeHead(404); res.end('not found');
    }
  }, async (controllerUrl) => {
    await assert.rejects(() => fetchSlowSql(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 1000 }
    ));
  });
});

test('fetchTierMetrics averages a wildcard path across every node it returns', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    // A wildcard metric path returns one entry PER NODE — three nodes here.
    res.end(JSON.stringify([
      { metricPath: 'node-a', metricValues: [{ startTimeInMillis: 1000, value: 30 }, { startTimeInMillis: 2000, value: 60 }] },
      { metricPath: 'node-b', metricValues: [{ startTimeInMillis: 1000, value: 60 }, { startTimeInMillis: 2000, value: 90 }] },
      { metricPath: 'node-c', metricValues: [{ startTimeInMillis: 1000, value: 90 }] },
    ]));
  }, async (controllerUrl) => {
    const result = await fetchTierMetrics(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 3000 }
    );
    // cpu is a percentage -> averaged across the nodes present at each timestamp
    assert.deepEqual(result.cpu, [{ t: 1000, v: 60 }, { t: 2000, v: 75 }]);
    // connections is a counter -> summed across nodes
    assert.deepEqual(result.connections, [{ t: 1000, v: 180 }, { t: 2000, v: 150 }]);
  });
});

test('fetchTierMetrics keeps the metric paths that resolve when one path 404s', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
      return;
    }
    if (decodeURIComponent(req.url).includes('Memory')) { res.writeHead(404); res.end('no such metric'); return; }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify([{ metricValues: [{ startTimeInMillis: 1000, value: 30 }] }]));
  }, async (controllerUrl) => {
    const result = await fetchTierMetrics(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 1000 }
    );
    assert.equal(result.cpu.length, 1);
    assert.deepEqual(result.memory, []);
    assert.equal(result.throughput.length, 1);
  });
});

test('fetchTierMetrics rejects when every metric path fails', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
      return;
    }
    res.writeHead(401); res.end('{}');
  }, async (controllerUrl) => {
    await assert.rejects(() => fetchTierMetrics(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { from: 0, to: 1000 }
    ));
  });
});

test('fetchTierMetrics scopes its metric paths to the selected tier', async () => {
  const seen = [];
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
      return;
    }
    seen.push(new URL(req.url, 'http://x').searchParams.get('metric-path'));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify([{ metricValues: [{ startTimeInMillis: 1000, value: 30 }] }]));
  }, async (controllerUrl) => {
    await fetchTierMetrics(
      { controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' },
      { service: 'checkout-tier', from: 0, to: 1000 }
    );
    assert.ok(seen.some(p => p === 'Application Infrastructure Performance|checkout-tier|Individual Nodes|*|Hardware Resources|CPU|%Busy'), seen.join('\n'));
    assert.ok(seen.some(p => p === 'Overall Application Performance|checkout-tier|Calls per Minute'), seen.join('\n'));
  });
});

test('metricPathsFor falls back to application-wide paths with no tier selected', () => {
  const wide = metricPathsFor(undefined);
  assert.equal(wide.throughput, 'Overall Application Performance|Calls per Minute');
  assert.match(wide.cpu, /Application Infrastructure Performance\|\*\|/);
  // Backends are not nested under a tier, so this one path never gets scoped.
  assert.equal(metricPathsFor('checkout-tier').connections, wide.connections);
});

test('metricPathsFor uses a caller override verbatim, tier or not', () => {
  const paths = metricPathsFor('checkout-tier', { cpu: 'Custom|CPU|Path' });
  assert.equal(paths.cpu, 'Custom|CPU|Path');
  assert.match(paths.memory, /\|checkout-tier\|/);
});

test('aggregateSeries combines timestamps across node series', () => {
  const nodes = [[{ t: 1, v: 10 }, { t: 2, v: 20 }], [{ t: 1, v: 30 }]];
  assert.deepEqual(aggregateSeries(nodes, 'avg'), [{ t: 1, v: 20 }, { t: 2, v: 20 }]);
  assert.deepEqual(aggregateSeries(nodes, 'sum'), [{ t: 1, v: 40 }, { t: 2, v: 20 }]);
  assert.deepEqual(aggregateSeries([], 'avg'), []);
});

test('fetchServices returns tier names', async () => {
  await withServer((req, res) => {
    if (req.url.includes('oauth')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ access_token: 't', expires_in: 300 }));
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify([{ name: 'checkout-service' }, { name: 'orders-service' }]));
    }
  }, async (controllerUrl) => {
    const names = await fetchServices({ controllerUrl, accountName: 'acct', clientId: 'cid', clientSecret: 'secret', applicationName: 'MyApp' });
    assert.deepEqual(names, ['checkout-service', 'orders-service']);
  });
});
