'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { installPerfDiagnostics, mergeSecrets, platformStatus } = require('./index');

// A stand-in for Express that records the handlers `installPerfDiagnostics`
// registers, so each route can be invoked directly with mock req/res objects —
// no HTTP server, matching this codebase's dependency-injection style for
// route modules (see installJira's injected collaborators).
function mountRoutes({ sessions, environments = [], platforms = {}, diagnose = {}, suggestFixImpl } = {}) {
  const calls = { saved: [], deleted: [], validated: [], diagnosed: [], suggested: [] };
  const routes = new Map();
  const app = {
    get: (path, handler) => routes.set('GET ' + path, handler),
    post: (path, handler) => routes.set('POST ' + path, handler),
    delete: (path, handler) => routes.set('DELETE ' + path, handler),
  };

  const store = {
    listEnvironments: () => environments,
    saveEnvironment: (_p, env) => { calls.saved.push(env); return env; },
    deleteEnvironment: (_p, id) => { calls.deleted.push(id); },
    stripSecrets: (env) => {
      const clean = { ...env };
      for (const key of ['datadog', 'appdynamics']) {
        if (!clean[key]) continue;
        clean[key] = { ...clean[key] };
        for (const s of ['ddApiKey', 'ddAppKey', 'appdClientId', 'appdClientSecret']) delete clean[key][s];
      }
      return clean;
    },
  };

  const datadog = {
    siteToBaseUrl: (site) => `https://api.${site}`,
    validate: async (cfg) => {
      calls.validated.push('datadog');
      if (platforms.datadogFails) { const e = new Error('bad key'); e.response = { status: 403 }; throw e; }
      return cfg;
    },
    fetchServices: async () => platforms.datadogServices || [],
  };
  const appdynamics = {
    validate: async (cfg) => {
      calls.validated.push('appdynamics');
      if (platforms.appdFails) throw new Error('controller unreachable');
      return cfg;
    },
    fetchServices: async () => platforms.appdServices || [],
  };

  installPerfDiagnostics(app, {
    sessions,
    PREFS_PATH: '/nonexistent/prefs.json',
    deps: {
      store, datadog, appdynamics,
      runDiagnose: async (args) => { calls.diagnosed.push(args); return diagnose.result || { warnings: [], load: {}, queries: [] }; },
      suggestFix: suggestFixImpl || (async (_sess, q) => { calls.suggested.push(q); return 'do the thing'; }),
    },
  });

  async function invoke(route, { body, query, params } = {}) {
    const handler = routes.get(route);
    assert.ok(handler, `route not registered: ${route}`);
    const res = { statusCode: 200, body: null,
      status(code) { this.statusCode = code; return this; },
      json(payload) { this.body = payload; return this; } };
    await handler({ body, query: query || {}, params: params || {} }, res);
    return res;
  }

  return { invoke, calls };
}

function session() {
  return { 'sid-1': { id: 'sid-1' } };
}

// ── restore path (a) ────────────────────────────────────────────────────────

test('a restore save neither writes to disk nor validates credentials', async () => {
  const sessions = session();
  const { invoke, calls } = mountRoutes({ sessions });
  const res = await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1', restore: true,
      environment: { id: 'env_1', name: 'Production', datadog: { site: 'datadoghq.com', envTag: 'prod' } },
      secrets: { ddApiKey: 'k', ddAppKey: 'a' },
    },
  });
  assert.equal(res.statusCode, 200);
  assert.deepEqual(calls.saved, []);      // no prefs write
  assert.deepEqual(calls.validated, []);  // no external call on startup rehydrate
  // The secrets still land in the session, which is the whole point of restore.
  assert.deepEqual(sessions['sid-1'].perfEnvSecrets.env_1, { ddApiKey: 'k', ddAppKey: 'a' });
});

// ── response never leaks secrets (b) ───────────────────────────────────────

test('a normal save returns only stripped, non-secret environment data', async () => {
  const { invoke } = mountRoutes({ sessions: session() });
  const res = await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1',
      environment: {
        id: 'env_1', name: 'Production',
        datadog: { site: 'datadoghq.com', envTag: 'prod' },
        appdynamics: { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' },
      },
      secrets: { ddApiKey: 'super-secret-key', ddAppKey: 'super-secret-app', appdClientId: 'cid', appdClientSecret: 'csecret' },
    },
  });
  const serialized = JSON.stringify(res.body);
  for (const secret of ['super-secret-key', 'super-secret-app', 'csecret']) {
    assert.equal(serialized.includes(secret), false, `response leaked ${secret}`);
  }
  assert.equal(res.body.environment.name, 'Production');
});

// ── resolvedConfig gating (c) ──────────────────────────────────────────────

test('a platform holding only one of its two secrets is not used for diagnose', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = { env_1: { ddApiKey: 'k' } }; // no ddAppKey
  const environments = [{ id: 'env_1', name: 'Prod', datadog: { site: 'datadoghq.com', envTag: 'prod' } }];
  const { invoke, calls } = mountRoutes({ sessions, environments });
  const res = await invoke('POST /api/perf/diagnose', { body: { session: 'sid-1', environmentId: 'env_1', timeRange: '1h' } });
  assert.equal(res.statusCode, 400);
  assert.match(res.body.error, /No platform is configured/);
  assert.deepEqual(calls.diagnosed, []);
});

test('a platform holding both secrets is passed through to runDiagnose', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = { env_1: { ddApiKey: 'k', ddAppKey: 'a', appdClientId: 'cid' } };
  const environments = [{
    id: 'env_1', name: 'Prod',
    datadog: { site: 'datadoghq.eu', envTag: 'prod' },
    appdynamics: { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' },
  }];
  const { invoke, calls } = mountRoutes({ sessions, environments });
  const res = await invoke('POST /api/perf/diagnose', {
    body: { session: 'sid-1', environmentId: 'env_1', service: 'checkout', timeRange: '4h' },
  });
  assert.equal(res.statusCode, 200);
  assert.equal(calls.diagnosed.length, 1);
  const passed = calls.diagnosed[0];
  assert.equal(passed.environment.datadog.baseUrl, 'https://api.datadoghq.eu');
  assert.equal(passed.environment.datadog.ddAppKey, 'a');
  // AppDynamics only has a client id, not the secret — so it is left out.
  assert.equal(passed.environment.appdynamics, undefined);
  assert.equal(passed.service, 'checkout');
  assert.equal(passed.timeRange, '4h');
});

// ── *Configured gating (d) — regression test ───────────────────────────────

test('datadogConfigured/appdynamicsConfigured require BOTH of a platform\'s secrets', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = {
    env_both: { ddApiKey: 'k', ddAppKey: 'a', appdClientId: 'cid', appdClientSecret: 'cs' },
    env_half: { ddApiKey: 'k', appdClientSecret: 'cs' },
  };
  const dd = { site: 'datadoghq.com', envTag: 'prod' };
  const appd = { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' };
  const environments = [
    { id: 'env_both', name: 'Both', datadog: dd, appdynamics: appd },
    { id: 'env_half', name: 'Half', datadog: dd, appdynamics: appd },
    { id: 'env_none', name: 'None', datadog: dd, appdynamics: appd },
  ];
  const { invoke } = mountRoutes({ sessions, environments });
  const res = await invoke('GET /api/perf/environments', { query: { session: 'sid-1' } });
  const byId = Object.fromEntries(res.body.environments.map(e => [e.id, e]));
  assert.deepEqual([byId.env_both.datadogConfigured, byId.env_both.appdynamicsConfigured], [true, true]);
  assert.deepEqual([byId.env_half.datadogConfigured, byId.env_half.appdynamicsConfigured], [false, false]);
  assert.deepEqual([byId.env_none.datadogConfigured, byId.env_none.appdynamicsConfigured], [false, false]);
});

test('platformStatus reports false for a platform that is not configured at all', () => {
  const status = platformStatus({ datadog: { site: 's' } }, { ddApiKey: 'k', ddAppKey: 'a', appdClientId: 'c', appdClientSecret: 's' });
  assert.equal(status.datadogConfigured, true);
  assert.equal(status.appdynamicsConfigured, false); // env has no appdynamics block
});

// ── I8: one platform's validation failure must not lose the whole save ─────

test('a failing platform is saved anyway and reported as a warning', async () => {
  const { invoke, calls } = mountRoutes({ sessions: session(), platforms: { datadogFails: true } });
  const res = await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1',
      environment: {
        id: 'env_1', name: 'Renamed Production',
        datadog: { site: 'datadoghq.com', envTag: 'prod' },
        appdynamics: { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' },
      },
      secrets: { ddApiKey: 'rotated', ddAppKey: 'rotated', appdClientId: 'cid', appdClientSecret: 'cs' },
    },
  });
  assert.equal(res.statusCode, 200);
  assert.equal(res.body.ok, true);
  assert.equal(calls.saved.length, 1);
  assert.equal(calls.saved[0].name, 'Renamed Production');
  // Both platforms were checked; only Datadog failed.
  assert.deepEqual(calls.validated.sort(), ['appdynamics', 'datadog']);
  assert.deepEqual(res.body.warnings, [{ platform: 'datadog', message: 'Datadog: authentication failed' }]);
});

test('both platforms failing still saves, with a warning each', async () => {
  const { invoke, calls } = mountRoutes({ sessions: session(), platforms: { datadogFails: true, appdFails: true } });
  const res = await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1',
      environment: {
        id: 'env_1', name: 'Prod',
        datadog: { site: 'datadoghq.com', envTag: 'prod' },
        appdynamics: { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' },
      },
      secrets: { ddApiKey: 'k', ddAppKey: 'a', appdClientId: 'cid', appdClientSecret: 'cs' },
    },
  });
  assert.equal(res.statusCode, 200);
  assert.equal(calls.saved.length, 1);
  assert.equal(res.body.warnings.length, 2);
  assert.match(res.body.warnings.find(w => w.platform === 'appdynamics').message, /controller unreachable/);
});

test('a clean save reports no warnings', async () => {
  const { invoke } = mountRoutes({ sessions: session() });
  const res = await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1',
      environment: { id: 'env_1', name: 'Prod', datadog: { site: 'datadoghq.com', envTag: 'prod' } },
      secrets: { ddApiKey: 'k', ddAppKey: 'a' },
    },
  });
  assert.deepEqual(res.body.warnings, []);
});

// ── I7: clearing a secret field actually removes it ────────────────────────

test('an explicit null secret deletes the stored value instead of orphaning it', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = { env_1: { ddApiKey: 'old-key', ddAppKey: 'old-app' } };
  const { invoke } = mountRoutes({ sessions });
  await invoke('POST /api/perf/environments', {
    body: {
      session: 'sid-1', restore: true,
      environment: { id: 'env_1', name: 'Prod', datadog: { site: 'datadoghq.com', envTag: 'prod' } },
      secrets: { ddApiKey: null, ddAppKey: 'new-app' },
    },
  });
  assert.deepEqual(sessions['sid-1'].perfEnvSecrets.env_1, { ddAppKey: 'new-app' });
});

test('mergeSecrets deletes on null or empty string, keeps omitted keys, and ignores unknown ones', () => {
  const previous = { ddApiKey: 'a', ddAppKey: 'b', appdClientId: 'c', appdClientSecret: 'd' };
  assert.deepEqual(mergeSecrets(previous, { ddApiKey: null }), { ddAppKey: 'b', appdClientId: 'c', appdClientSecret: 'd' });
  assert.deepEqual(mergeSecrets(previous, { ddAppKey: '' }), { ddApiKey: 'a', appdClientId: 'c', appdClientSecret: 'd' });
  assert.deepEqual(mergeSecrets(previous, {}), previous);
  assert.deepEqual(mergeSecrets(previous, undefined), previous);
  assert.deepEqual(mergeSecrets(previous, { somethingElse: 'x' }), previous);
  assert.deepEqual(mergeSecrets(undefined, { ddApiKey: 'fresh' }), { ddApiKey: 'fresh' });
});

// ── session / not-found guards ─────────────────────────────────────────────

test('every route rejects an unknown session with 401', async () => {
  const { invoke } = mountRoutes({ sessions: {} });
  const calls = [
    ['GET /api/perf/environments', { query: { session: 'nope' } }],
    ['POST /api/perf/environments', { body: { session: 'nope', environment: { name: 'x' } } }],
    ['DELETE /api/perf/environments/:id', { query: { session: 'nope' }, params: { id: 'env_1' } }],
    ['POST /api/perf/test', { body: { session: 'nope', platform: 'datadog', config: {} } }],
    ['GET /api/perf/services', { query: { session: 'nope' } }],
    ['POST /api/perf/diagnose', { body: { session: 'nope' } }],
    ['POST /api/perf/suggest-fix', { body: { session: 'nope', query: { queryText: 'q' } } }],
  ];
  for (const [route, args] of calls) {
    const res = await invoke(route, args);
    assert.equal(res.statusCode, 401, route);
  }
});

test('diagnose and services 404 on an unknown environment id', async () => {
  const { invoke } = mountRoutes({ sessions: session() });
  const d = await invoke('POST /api/perf/diagnose', { body: { session: 'sid-1', environmentId: 'missing' } });
  assert.equal(d.statusCode, 404);
  const s = await invoke('GET /api/perf/services', { query: { session: 'sid-1', environmentId: 'missing' } });
  assert.equal(s.statusCode, 404);
});

test('services merges Datadog service names and AppDynamics tier names', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = { env_1: { ddApiKey: 'k', ddAppKey: 'a', appdClientId: 'c', appdClientSecret: 's' } };
  const environments = [{
    id: 'env_1', name: 'Prod',
    datadog: { site: 'datadoghq.com', envTag: 'prod' },
    appdynamics: { controllerUrl: 'https://x', accountName: 'acct', applicationName: 'MyApp' },
  }];
  const { invoke } = mountRoutes({
    sessions, environments,
    platforms: { datadogServices: ['orders', 'checkout'], appdServices: ['checkout-tier', 'checkout'] },
  });
  const res = await invoke('GET /api/perf/services', { query: { session: 'sid-1', environmentId: 'env_1' } });
  assert.deepEqual(res.body.services, ['checkout', 'checkout-tier', 'orders']);
});

test('a name-less environment is rejected before anything is persisted', async () => {
  const { invoke, calls } = mountRoutes({ sessions: session() });
  const res = await invoke('POST /api/perf/environments', { body: { session: 'sid-1', environment: { id: 'env_1' } } });
  assert.equal(res.statusCode, 400);
  assert.deepEqual(calls.saved, []);
});

test('delete removes the environment from disk and its secrets from the session', async () => {
  const sessions = session();
  sessions['sid-1'].perfEnvSecrets = { env_1: { ddApiKey: 'k' }, env_2: { ddApiKey: 'k2' } };
  const { invoke, calls } = mountRoutes({ sessions });
  const res = await invoke('DELETE /api/perf/environments/:id', { query: { session: 'sid-1' }, params: { id: 'env_1' } });
  assert.equal(res.body.ok, true);
  assert.deepEqual(calls.deleted, ['env_1']);
  assert.deepEqual(Object.keys(sessions['sid-1'].perfEnvSecrets), ['env_2']);
});

function codedFailure(code, message) {
  return async () => { const e = new Error(message); e.code = code; throw e; };
}

test('suggest-fix maps a hash-only query row to a 400, not a 502', async () => {
  const { invoke } = mountRoutes({
    sessions: session(),
    suggestFixImpl: codedFailure('QUERY_TEXT_UNAVAILABLE', 'Query text unavailable for this row'),
  });
  const res = await invoke('POST /api/perf/suggest-fix', {
    body: { session: 'sid-1', query: { queryText: 'abc123', queryTextIsHash: true } },
  });
  assert.equal(res.statusCode, 400);
  assert.match(res.body.error, /Query text unavailable/);
});

test('suggest-fix maps an unconfigured-AI error to 400 and a transient failure to 502', async () => {
  const notConfigured = mountRoutes({ sessions: session(), suggestFixImpl: codedFailure('AI_NOT_CONFIGURED', 'Configure an AI provider') });
  const a = await notConfigured.invoke('POST /api/perf/suggest-fix', { body: { session: 'sid-1', query: { queryText: 'q' } } });
  assert.equal(a.statusCode, 400);

  const transient = mountRoutes({ sessions: session(), suggestFixImpl: async () => { throw new Error('rate limited'); } });
  const b = await transient.invoke('POST /api/perf/suggest-fix', { body: { session: 'sid-1', query: { queryText: 'q' } } });
  assert.equal(b.statusCode, 502);
});
