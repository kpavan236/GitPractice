'use strict';
const { resolveTimeRange, correlateBySource } = require('./correlate');
const defaultDatadog = require('./datadog');
const defaultAppdynamics = require('./appdynamics');
const { createAiClient } = require('../ai/client');

// Fresh arrays every call — a shared `{...CONST}` would alias the same four
// arrays into every degraded source's payload.
function emptyLoad() {
  return { cpu: [], memory: [], throughput: [], connections: [] };
}

function failureMessage(what, e) {
  const status = e?.response?.status;
  return status === 401 || status === 403
    ? `${what}: authentication failed — check Settings`
    : `${what}: request failed: ${e?.message || 'unknown error'}`;
}

// Turn one settled promise into either its value or a `{source, message}`
// warning pushed onto `warnings`, falling back to `fallback`. Each external
// call degrades on its own (spec §C.2) — a Datadog account without a DBM
// entitlement still gets its load charts and APM rows, with a DBM-only
// warning, instead of a blank tab.
function settledOr(settled, { source, what, fallback, warnings }) {
  if (settled.status === 'fulfilled') return settled.value;
  warnings.push({ source, message: failureMessage(what, settled.reason) });
  return fallback;
}

async function fetchDatadogSource(cfg, { service, from, to }, datadog) {
  const warnings = [];
  const [loadR, slowR, dbmR] = await Promise.allSettled([
    datadog.fetchLoadMetrics(cfg, { service, from, to }),
    datadog.fetchSlowResources(cfg, { service, from, to }),
    datadog.fetchDbmQueries(cfg, { from, to }),
  ]);

  const load = settledOr(loadR, { source: 'datadog', what: 'Datadog load metrics', fallback: emptyLoad(), warnings });
  const slow = settledOr(slowR, { source: 'datadog', what: 'Datadog APM slow resources', fallback: [], warnings });
  const dbm = settledOr(dbmR, { source: 'datadog', what: 'Datadog Database Monitoring', fallback: [], warnings });

  const queries = [
    ...slow.map(r => ({
      source: 'datadog-apm', queryText: r.resourceName, database: null,
      avgDurationMs: r.avgDurationMs, execCount: r.execCount,
    })),
    ...dbm.map(r => ({
      source: 'datadog-dbm', queryText: r.queryText, database: r.database,
      avgDurationMs: r.avgDurationMs, execCount: r.execCount,
      // DBM identifies a statement by signature hash, not literal SQL — carried
      // through so the UI can say so and the AI never sees a hash (see I5).
      queryTextIsHash: r.queryTextIsHash === true,
    })),
  ];
  return { load, queries, warnings };
}

async function fetchAppdynamicsSource(cfg, { service, from, to }, appdynamics) {
  const warnings = [];
  const [loadR, sqlR] = await Promise.allSettled([
    appdynamics.fetchTierMetrics(cfg, { service, from, to }),
    appdynamics.fetchSlowSql(cfg, { service, from, to }),
  ]);

  const load = settledOr(loadR, { source: 'appdynamics', what: 'AppDynamics load metrics', fallback: emptyLoad(), warnings });
  const slowSql = settledOr(sqlR, { source: 'appdynamics', what: 'AppDynamics slow SQL (Database Visibility)', fallback: [], warnings });

  const queries = slowSql.map(r => ({
    source: 'appd-db', queryText: r.queryText, database: r.database,
    avgDurationMs: r.avgDurationMs, execCount: r.execCount,
  }));
  return { load, queries, warnings };
}

// `execCount` does NOT mean the same thing in every source, so a single
// `avg × count` sort key would rank the merged table dishonestly:
//   datadog-apm  a real span count over the window        -> 'count'
//   appd-db      callsPerMinute, i.e. a rate              -> 'rate-per-minute'
//   datadog-dbm  the timeseries response carries no
//                execution count at all                   -> null
// The frontend uses this to label the Execs column rather than printing a rate
// and a count as if they were the same quantity.
const EXEC_COUNT_KIND = {
  'datadog-apm': 'count',
  'datadog-dbm': null,
  'appd-db': 'rate-per-minute',
};

// Total milliseconds of work in the window, as far as each source can honestly
// report it. A rate is multiplied out over the window; a source with no count
// at all is ranked on average duration alone rather than on a fabricated count.
function impactScore(query, windowMinutes) {
  const avg = query.avgDurationMs || 0;
  const count = query.execCount || 0;
  if (query.execCountKind === 'count') return avg * count;
  if (query.execCountKind === 'rate-per-minute') return avg * count * windowMinutes;
  return avg;
}

async function runDiagnose({ environment, service, timeRange, now, clients } = {}) {
  const datadog = clients?.datadog || defaultDatadog;
  const appdynamics = clients?.appdynamics || defaultAppdynamics;
  const { from, to } = resolveTimeRange(timeRange, now);

  const warnings = [];
  const seriesBySource = {};
  let queries = [];

  const sources = [];
  if (environment.datadog) {
    sources.push(['datadog', () => fetchDatadogSource(environment.datadog, { service, from, to }, datadog)]);
  }
  if (environment.appdynamics) {
    sources.push(['appdynamics', () => fetchAppdynamicsSource(environment.appdynamics, { service, from, to }, appdynamics)]);
  }

  // One platform blowing up entirely (not just one of its calls) is still only
  // a warning — the other platform's data flows through untouched.
  const settled = await Promise.allSettled(sources.map(([, run]) => run()));
  settled.forEach((result, i) => {
    const [name] = sources[i];
    if (result.status !== 'fulfilled') {
      warnings.push({ source: name, message: failureMessage(name === 'datadog' ? 'Datadog' : 'AppDynamics', result.reason) });
      return;
    }
    seriesBySource[name] = result.value.load;
    queries = queries.concat(result.value.queries);
    warnings.push(...result.value.warnings);
  });

  // Correlate per source rather than pooling raw values — the two platforms
  // report these metrics in different units (see correlateBySource).
  const { highLoadBuckets, queries: verdictQueries } = correlateBySource(seriesBySource, queries, { from, to });

  const windowMinutes = Math.max(1, (to - from) / 60000);
  const withTotals = verdictQueries.map(q => {
    const execCountKind = EXEC_COUNT_KIND[q.source] ?? null;
    const withKind = { ...q, execCountKind };
    const score = impactScore(withKind, windowMinutes);
    return {
      ...withKind,
      impactScore: score,
      // Null rather than a made-up number when the source gives no exec count.
      totalTimeMs: execCountKind ? score : null,
    };
  });
  withTotals.sort((a, b) => b.impactScore - a.impactScore);

  // `from`/`to` travel with the load payload so every chart in the grid can pin
  // the same x-axis and the shaded high-load bands line up across all four.
  return { warnings, load: { seriesBySource, highLoadBuckets, from, to }, queries: withTotals };
}

function buildFixPrompt(query) {
  return `A monitoring system flagged this database query as slow:

Query: ${query.queryText}
Database: ${query.database || 'unknown'}
Average duration: ${query.avgDurationMs.toFixed(1)}ms
Executions in window: ${describeExecCount(query)}
${query.loadCorrelated
    ? 'This slowness correlates with a period of elevated system load (CPU/memory/throughput/connections).'
    : 'This slowness does NOT correlate with elevated system load — it happens even when load is normal.'}

Suggest a concrete fix: an index, a query rewrite, or a caching/pagination change as appropriate.
If the query text is a resource/endpoint name rather than literal SQL (some monitoring sources report
only the endpoint), reason about likely causes at that level instead.
Keep the answer to a few sentences plus, if applicable, a short SQL code block.`;
}

function describeExecCount(query) {
  if (query.execCountKind === 'rate-per-minute') return `${query.execCount} calls/minute`;
  if (query.execCountKind === 'count' || typeof query.execCount === 'number') return String(query.execCount);
  return 'not reported by this monitoring source';
}

async function suggestFix(sess, query) {
  // Datadog DBM reports a query *signature hash*, not the statement text.
  // Sending that to a model produces a confident-sounding answer about a string
  // that carries no SQL at all, so refuse here as well as in the UI.
  if (query.queryTextIsHash) {
    const err = new Error('Query text unavailable for this row — Datadog DBM reports only a signature hash, so there is no SQL to analyse');
    err.code = 'QUERY_TEXT_UNAVAILABLE';
    throw err;
  }
  const ai = createAiClient(sess);
  if (!ai.available()) {
    const err = new Error('Configure an AI provider in Settings to get fix suggestions');
    err.code = 'AI_NOT_CONFIGURED';
    throw err;
  }
  return ai.complete({
    messages: [{ role: 'user', content: buildFixPrompt(query) }],
    system: 'You are a senior database engineer. Be specific and concise.',
    maxTokens: 800,
  });
}

module.exports = { runDiagnose, buildFixPrompt, suggestFix, impactScore, EXEC_COUNT_KIND };
