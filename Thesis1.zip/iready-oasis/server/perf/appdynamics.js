'use strict';
const axios = require('axios');

const _tokenCache = new Map(); // `${controllerUrl}|${clientId}` -> { token, expiresAt }

async function getOAuthToken(cfg) {
  const key = `${cfg.controllerUrl}|${cfg.clientId}`;
  const cached = _tokenCache.get(key);
  if (cached && cached.expiresAt > Date.now() + 5000) return cached.token;

  const params = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: `${cfg.clientId}@${cfg.accountName}`,
    client_secret: cfg.clientSecret,
  });
  const r = await axios.post(
    `${cfg.controllerUrl.replace(/\/$/, '')}/controller/api/oauth/access_token`,
    params.toString(),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15000 }
  );
  const token = r.data.access_token;
  const expiresAt = Date.now() + (r.data.expires_in || 300) * 1000;
  _tokenCache.set(key, { token, expiresAt });
  return token;
}

async function validate(cfg) {
  const token = await getOAuthToken(cfg);
  await axios.get(
    `${cfg.controllerUrl.replace(/\/$/, '')}/controller/rest/applications`,
    { headers: { Authorization: `Bearer ${token}` }, params: { output: 'json' }, timeout: 15000 }
  );
}

// Best-effort default metric paths — real path names are account/integration
// specific. Override any of these via cfg.metricOverrides for non-standard setups.
// Application-wide (no tier filter): the tier segment is a wildcard, or absent
// where AppDynamics offers an application-level rollup instead.
const DEFAULT_METRIC_PATHS = {
  cpu: 'Application Infrastructure Performance|*|Individual Nodes|*|Hardware Resources|CPU|%Busy',
  memory: 'Application Infrastructure Performance|*|Individual Nodes|*|Hardware Resources|Memory|Used %',
  throughput: 'Overall Application Performance|Calls per Minute',
  connections: 'Backends|*|*|Number of Connections',
};

// The same four metrics scoped to a single tier. `{tier}` is substituted with
// the tier name the user picked in the service/application filter, so an AppD
// tier selection actually narrows the data instead of being ignored.
// `connections` is deliberately unchanged: AppDynamics' Backends metric tree is
// not nested under a tier, so there is no tier segment to scope by — DB
// connections stay application-wide even with a tier filter applied.
const TIER_METRIC_PATHS = {
  cpu: 'Application Infrastructure Performance|{tier}|Individual Nodes|*|Hardware Resources|CPU|%Busy',
  memory: 'Application Infrastructure Performance|{tier}|Individual Nodes|*|Hardware Resources|Memory|Used %',
  throughput: 'Overall Application Performance|{tier}|Calls per Minute',
  connections: 'Backends|*|*|Number of Connections',
};

// How to collapse several returned series into one. Wildcard metric paths
// return one series PER MATCHING NODE, so a multi-node tier yields several
// arrays: percentages average across nodes, counters sum across them.
const METRIC_AGGREGATION = { cpu: 'avg', memory: 'avg', throughput: 'sum', connections: 'sum' };

function metricPathsFor(service, overrides = {}) {
  const base = service ? TIER_METRIC_PATHS : DEFAULT_METRIC_PATHS;
  const paths = {};
  for (const key of Object.keys(DEFAULT_METRIC_PATHS)) {
    // A user-supplied override is used verbatim — they know their own tree.
    paths[key] = overrides[key] || base[key].replace('{tier}', service || '');
  }
  return paths;
}

// Collapse `[[{t,v}...], [{t,v}...]]` (one array per node) into a single series,
// combining values that share a timestamp. Reading only `[0]` — as this used to —
// silently reported one arbitrary node as if it were the whole tier.
function aggregateSeries(seriesList, mode) {
  const byTime = new Map(); // t -> {sum, n}
  for (const series of seriesList) {
    for (const p of series) {
      const slot = byTime.get(p.t) || { sum: 0, n: 0 };
      slot.sum += p.v;
      slot.n += 1;
      byTime.set(p.t, slot);
    }
  }
  return [...byTime.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([t, { sum, n }]) => ({ t, v: mode === 'sum' ? sum : sum / n }));
}

async function fetchMetricData(cfg, token, metricPath, { from, to }, mode = 'avg') {
  const r = await axios.get(
    `${cfg.controllerUrl.replace(/\/$/, '')}/controller/rest/applications/${encodeURIComponent(cfg.applicationName)}/metric-data`,
    {
      headers: { Authorization: `Bearer ${token}` },
      params: {
        'metric-path': metricPath,
        'time-range-type': 'BETWEEN_TIMES',
        'start-time': from, 'end-time': to,
        rollup: false, output: 'json',
      },
      timeout: 20000,
    }
  );
  const seriesList = (Array.isArray(r.data) ? r.data : [])
    .map(entry => (entry?.metricValues || [])
      .map(v => ({ t: v.startTimeInMillis, v: v.value }))
      .filter(p => typeof p.v === 'number' && typeof p.t === 'number'));
  return aggregateSeries(seriesList, mode);
}

// Each metric path is fetched independently: one path that does not exist in
// this account's metric tree leaves that single chart empty instead of taking
// the other three down with it. Only a total failure (every path rejected,
// e.g. bad credentials or an unreachable controller) propagates, so the
// diagnose endpoint can surface it as an AppDynamics warning.
async function fetchTierMetrics(cfg, { service, from, to }) {
  const token = await getOAuthToken(cfg);
  const paths = metricPathsFor(service, cfg.metricOverrides || {});
  const keys = Object.keys(DEFAULT_METRIC_PATHS);
  const settled = await Promise.allSettled(
    keys.map(k => fetchMetricData(cfg, token, paths[k], { from, to }, METRIC_AGGREGATION[k]))
  );
  if (settled.every(s => s.status === 'rejected')) throw settled[0].reason;
  const result = {};
  keys.forEach((k, i) => { result[k] = settled[i].status === 'fulfilled' ? settled[i].value : []; });
  return result;
}

// Database Visibility's per-SQL detail (query text, explain plans) lives behind
// AppDynamics' internal `restui` API used by the Controller UI, not the officially
// versioned public API, so a failure here is entirely plausible (older
// Controller, DB Visibility not licensed, endpoint shape changed).
//
// This used to swallow every error and return `[]`, which made an
// AppDynamics-only environment show "No slow queries found" with no hint that
// anything had gone wrong. It now rejects and lets the diagnose orchestration
// turn that into a visible `{source: 'appdynamics', message}` warning
// (design spec §B: the degradation must be surfaced, not hidden).
//
// `applicationName` is sent as `applicationName` rather than as `applicationId`
// — the previous code passed a name in an id-shaped parameter. AppDynamics'
// numeric application id is not something this module has; when the endpoint
// rejects the name, the caller now hears about it.
//
// Note: this endpoint has no documented tier filter, so `service` does not
// narrow it — the returned rows are application-wide.
async function fetchSlowSql(cfg, { from, to }) {
  const token = await getOAuthToken(cfg);
  const r = await axios.get(
    `${cfg.controllerUrl.replace(/\/$/, '')}/controller/restui/databaseVisibility/topDatabaseCalls`,
    {
      headers: { Authorization: `Bearer ${token}` },
      params: { applicationName: cfg.applicationName, timeRangeStart: from, timeRangeEnd: to },
      timeout: 20000,
    }
  );
  const rows = Array.isArray(r.data) ? r.data : (r.data?.databaseCalls || []);
  return rows.map(row => ({
    queryText: row.sqlText || row.name || 'unknown query',
    database: row.databaseName || null,
    avgDurationMs: row.averageResponseTime || row.avgResponseTime || 0,
    // A rate, not a count — AppDynamics reports calls per minute. The diagnose
    // layer tags this as 'rate-per-minute' so it is never ranked or displayed
    // as though it were an execution count (see EXEC_COUNT_KIND).
    execCount: row.callsPerMinute || row.count || 0,
  }));
}

async function fetchServices(cfg) {
  const token = await getOAuthToken(cfg);
  const r = await axios.get(
    `${cfg.controllerUrl.replace(/\/$/, '')}/controller/rest/applications/${encodeURIComponent(cfg.applicationName)}/tiers`,
    { headers: { Authorization: `Bearer ${token}` }, params: { output: 'json' }, timeout: 15000 }
  );
  return (r.data || []).map(t => t.name);
}

module.exports = {
  getOAuthToken, validate, fetchTierMetrics, fetchSlowSql, fetchServices,
  DEFAULT_METRIC_PATHS, TIER_METRIC_PATHS, METRIC_AGGREGATION,
  metricPathsFor, aggregateSeries, _tokenCache,
};
