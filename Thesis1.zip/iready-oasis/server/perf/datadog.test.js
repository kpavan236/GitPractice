'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const { siteToBaseUrl, validate, fetchLoadMetrics, fetchSlowResources, fetchDbmQueries, fetchServices } = require('./datadog');

function withServer(handler, run) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(handler);
    server.listen(0, async () => {
      const port = server.address().port;
      try { await run(`http://localhost:${port}`); resolve(); }
      catch (e) { reject(e); }
      finally { server.close(); }
    });
  });
}

test('siteToBaseUrl builds the api host from a site', () => {
  assert.equal(siteToBaseUrl('datadoghq.eu'), 'https://api.datadoghq.eu');
});

test('validate() resolves on a 200 response', async () => {
  await withServer((req, res) => { res.writeHead(200); res.end('{}'); }, async (baseUrl) => {
    await validate({ baseUrl, ddApiKey: 'k', ddAppKey: 'a' });
  });
});

test('validate() rejects on a 403 response', async () => {
  await withServer((req, res) => { res.writeHead(403); res.end('{}'); }, async (baseUrl) => {
    await assert.rejects(() => validate({ baseUrl, ddApiKey: 'bad', ddAppKey: 'bad' }));
  });
});

test('fetchLoadMetrics returns points per metric and skips throughput without a service', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ series: [{ pointlist: [[1000, 42.5], [2000, 50]] }] }));
  }, async (baseUrl) => {
    const result = await fetchLoadMetrics({ baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' }, { from: 0, to: 3000 });
    assert.equal(result.cpu.length, 2);
    assert.equal(result.cpu[0].v, 42.5);
    assert.deepEqual(result.throughput, []);
  });
});

test('fetchLoadMetrics includes throughput when a service is given', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ series: [{ pointlist: [[1000, 10]] }] }));
  }, async (baseUrl) => {
    const result = await fetchLoadMetrics(
      { baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' },
      { service: 'checkout', from: 0, to: 3000 }
    );
    assert.equal(result.throughput.length, 1);
  });
});

test('fetchLoadMetrics rejects when the API returns 401', async () => {
  await withServer((req, res) => { res.writeHead(401); res.end('{}'); }, async (baseUrl) => {
    await assert.rejects(() =>
      fetchLoadMetrics({ baseUrl, ddApiKey: 'bad', ddAppKey: 'bad', envTag: 'prod' }, { from: 0, to: 1000 })
    );
  });
});

test('fetchSlowResources normalizes aggregate buckets into rows (durations ns -> ms)', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      data: { buckets: [{ by: { resource_name: 'GET /orders' },
        computes: { 'avg_@duration': 250000000, 'pc95_@duration': 400000000, count: 120 } }] },
    }));
  }, async (baseUrl) => {
    const rows = await fetchSlowResources(
      { baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' },
      { service: 'orders', from: 0, to: 1000 }
    );
    assert.equal(rows.length, 1);
    assert.equal(rows[0].resourceName, 'GET /orders');
    assert.equal(rows[0].avgDurationMs, 250);
    assert.equal(rows[0].execCount, 120);
  });
});

test('fetchDbmQueries normalizes timeseries rows grouped by query signature', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      data: { attributes: { series: [
        { group_tags: ['query_signature:abc123', 'db:orders_db'], values: [[45], [55]] },
      ] } },
    }));
  }, async (baseUrl) => {
    const rows = await fetchDbmQueries({ baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' }, { from: 0, to: 1000 });
    assert.equal(rows.length, 1);
    assert.equal(rows[0].queryText, 'abc123');
    assert.equal(rows[0].database, 'orders_db');
    assert.equal(rows[0].avgDurationMs, 50);
    // `values.length` counts timeseries data points, not executions — DBM gives
    // no exec count, so none is reported rather than one being invented.
    assert.equal(rows[0].execCount, null);
    assert.equal(rows[0].dataPointCount, 2);
  });
});

test('fetchDbmQueries flags the query signature as a hash, not literal SQL', async () => {
  await withServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      data: { attributes: { series: [
        { group_tags: ['query_signature:abc123', 'db:orders_db'], values: [[45]] },
        { group_tags: ['db:other_db'], values: [[10]] },
      ] } },
    }));
  }, async (baseUrl) => {
    const rows = await fetchDbmQueries({ baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' }, { from: 0, to: 1000 });
    assert.equal(rows[0].queryTextIsHash, true);
    // No signature tag at all means there is no hash to disclaim.
    assert.equal(rows[1].queryText, 'unknown query');
    assert.equal(rows[1].queryTextIsHash, false);
  });
});

test('fetchLoadMetrics keeps the metrics that succeed when one metric query fails', async () => {
  await withServer((req, res) => {
    // Only the memory query (system.mem.used) fails; cpu/connections succeed.
    if (decodeURIComponent(req.url).includes('system.mem.used')) { res.writeHead(500); res.end('boom'); return; }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ series: [{ pointlist: [[1000, 42.5]] }] }));
  }, async (baseUrl) => {
    const result = await fetchLoadMetrics({ baseUrl, ddApiKey: 'k', ddAppKey: 'a', envTag: 'prod' }, { from: 0, to: 3000 });
    assert.equal(result.cpu.length, 1);
    assert.deepEqual(result.memory, []);
    assert.equal(result.connections.length, 1);
  });
});

test('fetchServices returns [] on failure rather than throwing', async () => {
  await withServer((req, res) => { res.writeHead(500); res.end('boom'); }, async (baseUrl) => {
    const names = await fetchServices({ baseUrl, ddApiKey: 'k', ddAppKey: 'a' });
    assert.deepEqual(names, []);
  });
});
