'use strict';

const TIME_RANGE_MS = {
  '15m': 15 * 60 * 1000,
  '1h': 60 * 60 * 1000,
  '4h': 4 * 60 * 60 * 1000,
  '24h': 24 * 60 * 60 * 1000,
  '7d': 7 * 24 * 60 * 60 * 1000,
};

function resolveTimeRange(timeRange, now) {
  const ms = TIME_RANGE_MS[timeRange];
  if (!ms) throw new Error(`Unknown time range "${timeRange}"`);
  return { from: now - ms, to: now };
}

// Targets ~45 buckets across the window, floored at 60s so a 15m window still
// gets meaningful granularity instead of near-instant, noisy buckets.
function bucketWidthMs(from, to) {
  const span = to - from;
  const targetBuckets = 45;
  return Math.max(60000, Math.round(span / targetBuckets));
}

function bucketize(points, from, to, width) {
  const bucketCount = Math.ceil((to - from) / width);
  const buckets = new Array(bucketCount).fill(null).map(() => []);
  for (const p of points) {
    if (p.t < from || p.t > to) continue;
    const idx = Math.min(bucketCount - 1, Math.floor((p.t - from) / width));
    buckets[idx].push(p.v);
  }
  return buckets.map((vals, i) => ({
    from: from + i * width,
    to: from + (i + 1) * width,
    avg: vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null,
  }));
}

// mean + 1 stddev of this window's own bucket averages — a standard
// outlier-detection method. Relative to the window's own distribution rather
// than a hardcoded absolute number, so it adapts per service without manual
// tuning. See the "one documented deviation" note in this plan's Global
// Constraints for why this replaced a literal top-quartile pick.
function highLoadThreshold(buckets) {
  const values = buckets.map(b => b.avg).filter(v => v !== null);
  if (!values.length) return Infinity;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length;
  return mean + Math.sqrt(variance);
}

function findHighLoadBuckets(loadSeriesByMetric, from, to, width) {
  const bucketCount = Math.ceil((to - from) / width);
  const highLoad = new Array(bucketCount).fill(false);

  for (const points of Object.values(loadSeriesByMetric)) {
    const buckets = bucketize(points || [], from, to, width);
    const threshold = highLoadThreshold(buckets);
    if (threshold === Infinity) continue;
    buckets.forEach((b, i) => {
      if (b.avg !== null && b.avg > threshold) highLoad[i] = true;
    });
  }

  const result = [];
  highLoad.forEach((isHigh, i) => {
    if (isHigh) result.push({ from: from + i * width, to: from + (i + 1) * width });
  });
  return result;
}

// Query occurrences without per-occurrence timestamps (aggregate-only sources)
// are treated as overlapping the whole window — tagged load-correlated only
// when the window contains ANY high-load bucket at all. This is a documented
// limitation (design spec, section C) rather than a precise per-occurrence check.
function isLoadCorrelated(query, highLoadBuckets) {
  if (Array.isArray(query.occurrences) && query.occurrences.length) {
    return query.occurrences.some(t => highLoadBuckets.some(b => t >= b.from && t < b.to));
  }
  return highLoadBuckets.length > 0;
}

function correlate(loadSeriesByMetric, queryRows, { from, to }) {
  return correlateBySource({ _: loadSeriesByMetric }, queryRows, { from, to });
}

// Correlate across several monitoring sources WITHOUT pooling their raw values.
//
// Different platforms report the same conceptual metric in different units —
// Datadog's default `memory` is bytes (system.mem.used) while AppDynamics'
// default is a percentage; Datadog throughput is requests/sec while
// AppDynamics' is calls/minute. Concatenating those into one array before
// computing mean+1stddev lets the larger-magnitude platform dominate the
// threshold, so the other platform's genuine spikes never clear it (and its
// calm periods can be flagged). Instead each source gets its own threshold
// against its own distribution, and a bucket is "high load" if ANY configured
// source's own correlation flags it. That preserves "did load spike here?"
// while never comparing bytes against percent.
function correlateBySource(seriesBySource, queryRows, { from, to }) {
  const width = bucketWidthMs(from, to);
  const seen = new Map(); // `${from}` -> {from, to}
  for (const series of Object.values(seriesBySource || {})) {
    for (const bucket of findHighLoadBuckets(series || {}, from, to, width)) {
      seen.set(bucket.from, bucket);
    }
  }
  const highLoadBuckets = [...seen.values()].sort((a, b) => a.from - b.from);
  const queries = queryRows.map(q => ({ ...q, loadCorrelated: isLoadCorrelated(q, highLoadBuckets) }));
  return { highLoadBuckets, queries };
}

module.exports = {
  TIME_RANGE_MS, resolveTimeRange, bucketWidthMs, bucketize,
  highLoadThreshold, findHighLoadBuckets, isLoadCorrelated, correlate, correlateBySource,
};
