'use strict';
const axios = require('axios');

const ENDPOINTS = {
  validate: '/api/v1/validate',
  metricsQuery: '/api/v1/query',
  // Verify these two against Datadog's current API docs before relying on them
  // in production — the Spans Aggregate and DBM query-metrics APIs have shifted
  // paths/shapes across Datadog API versions (see design spec, "Open risks").
  spansAggregate: '/api/v2/spans/events/aggregate',
  dbmQueryMetrics: '/api/v2/query/timeseries',
  serviceDefinitions: '/api/v2/services/definitions',
};

function siteToBaseUrl(site) {
  return `https://api.${site}`;
}

function ddHeaders(cfg) {
  return { 'DD-API-KEY': cfg.ddApiKey, 'DD-APPLICATION-KEY': cfg.ddAppKey };
}

async function validate(cfg) {
  await axios.get(`${cfg.baseUrl}${ENDPOINTS.validate}`, { headers: ddHeaders(cfg), timeout: 15000 });
}

async function fetchLoadMetrics(cfg, { service, from, to }) {
  const overrides = cfg.metricOverrides || {};
  const scope = `env:${cfg.envTag}` + (service ? `,service:${service}` : '');
  const queries = {
    cpu: overrides.cpu || `avg:system.cpu.user{${scope}}`,
    memory: overrides.memory || `avg:system.mem.used{${scope}}`,
    throughput: overrides.throughput || (service ? `sum:trace.${service}.request.hits{env:${cfg.envTag}}.as_count()` : null),
    connections: overrides.connections || `avg:postgresql.connections{${scope}}`,
  };
  const entries = Object.entries(queries).filter(([, query]) => query);
  // Each metric query stands on its own: a metric name that does not exist in
  // this account (very common — the right name depends on which integration is
  // installed) leaves that one chart empty rather than losing all four. Only a
  // total failure propagates, so the caller can warn about Datadog as a whole.
  const settled = await Promise.allSettled(entries.map(([key, query]) =>
    axios.get(`${cfg.baseUrl}${ENDPOINTS.metricsQuery}`, {
      params: { from: Math.floor(from / 1000), to: Math.floor(to / 1000), query },
      headers: ddHeaders(cfg),
      timeout: 20000,
    }).then(r => [key, r.data.series?.[0]?.pointlist || []])
  ));
  if (settled.length && settled.every(s => s.status === 'rejected')) throw settled[0].reason;
  const result = { cpu: [], memory: [], throughput: [], connections: [] };
  for (const s of settled) {
    if (s.status !== 'fulfilled') continue;
    const [key, pointlist] = s.value;
    result[key] = pointlist.map(([t, v]) => ({ t, v })).filter(p => typeof p.v === 'number');
  }
  return result;
}

async function fetchSlowResources(cfg, { service, from, to }) {
  const filterQuery = `env:${cfg.envTag}` + (service ? ` service:${service}` : '');
  const r = await axios.post(`${cfg.baseUrl}${ENDPOINTS.spansAggregate}`, {
    filter: { from: new Date(from).toISOString(), to: new Date(to).toISOString(), query: filterQuery },
    compute: [
      { aggregation: 'avg', metric: '@duration' },
      { aggregation: 'pc95', metric: '@duration' },
      { aggregation: 'count' },
    ],
    group_by: [{ facet: 'resource_name', limit: 25, sort: { aggregation: 'avg', metric: '@duration', order: 'desc' } }],
  }, { headers: { ...ddHeaders(cfg), 'Content-Type': 'application/json' }, timeout: 20000 });

  const buckets = r.data.data?.buckets || [];
  return buckets.map(b => ({
    resourceName: b.by?.resource_name || 'unknown',
    avgDurationMs: (b.computes?.['avg_@duration'] || 0) / 1e6,
    p95DurationMs: (b.computes?.['pc95_@duration'] || 0) / 1e6,
    execCount: b.computes?.count || 0,
  }));
}

async function fetchDbmQueries(cfg, { from, to }) {
  const metric = (cfg.metricOverrides || {}).dbmQueryMetric || 'dbm.postgres.queries.time_avg';
  const r = await axios.post(`${cfg.baseUrl}${ENDPOINTS.dbmQueryMetrics}`, {
    data: {
      type: 'timeseries_request',
      attributes: { from, to, query: `avg:${metric}{env:${cfg.envTag}} by {query_signature,db}` },
    },
  }, { headers: { ...ddHeaders(cfg), 'Content-Type': 'application/json' }, timeout: 20000 });

  const series = r.data.data?.attributes?.series || [];
  return series.map(s => {
    const values = (s.values || []).flat().filter(v => typeof v === 'number');
    const avg = values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
    const tags = s.group_tags || [];
    const signature = tags.find(t => t.startsWith('query_signature:'))?.split(':')[1];
    return {
      // DBM's timeseries response identifies a statement only by its signature
      // hash (e.g. "abc123"); the literal SQL lives behind a separate samples
      // endpoint that is out of scope here. Flagged so callers never present
      // the hash as if it were a query, and never hand it to an AI model.
      queryText: signature || 'unknown query',
      queryTextIsHash: !!signature,
      database: tags.find(t => t.startsWith('db:'))?.split(':')[1] || null,
      avgDurationMs: avg,
      // NOT an execution count: `values.length` is the number of timeseries
      // data points returned, which says nothing about how often the statement
      // ran. There is no real exec count in this response, so report none
      // rather than fabricating one (the number of points is kept separately
      // for anyone who wants to know how well-sampled the average is).
      execCount: null,
      dataPointCount: values.length,
    };
  });
}

async function fetchServices(cfg) {
  try {
    const r = await axios.get(`${cfg.baseUrl}${ENDPOINTS.serviceDefinitions}`, { headers: ddHeaders(cfg), timeout: 15000 });
    return (r.data.data || [])
      .map(d => d.attributes?.schema?.info?.dd_service || d.attributes?.['dd-service'])
      .filter(Boolean);
  } catch (_) {
    return [];
  }
}

module.exports = { siteToBaseUrl, ENDPOINTS, validate, fetchLoadMetrics, fetchSlowResources, fetchDbmQueries, fetchServices };
