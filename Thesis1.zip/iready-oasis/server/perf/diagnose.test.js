'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { runDiagnose, buildFixPrompt, suggestFix } = require('./diagnose');

function fakeClients({ datadogLoad, datadogSlow = [], datadogDbm = [], appdLoad, appdSlowSql = [] } = {}) {
  return {
    datadog: {
      fetchLoadMetrics: async () => datadogLoad || { cpu: [], memory: [], throughput: [], connections: [] },
      fetchSlowResources: async () => datadogSlow,
      fetchDbmQueries: async () => datadogDbm,
    },
    appdynamics: {
      fetchTierMetrics: async () => appdLoad || { cpu: [], memory: [], throughput: [], connections: [] },
      fetchSlowSql: async () => appdSlowSql,
    },
  };
}

function rejects(message, status) {
  return async () => {
    const e = new Error(message);
    if (status) e.response = { status };
    throw e;
  };
}

test('runDiagnose merges queries from both platforms and sorts by impact', async () => {
  const clients = fakeClients({
    datadogSlow: [{ resourceName: 'GET /orders', avgDurationMs: 50, execCount: 10 }],
    appdSlowSql: [{ queryText: 'SELECT * FROM big_table', database: 'orders_db', avgDurationMs: 500, execCount: 5 }],
  });
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' }, appdynamics: { applicationName: 'MyApp' } },
    timeRange: '1h', now: 1000000, clients,
  });
  assert.equal(result.warnings.length, 0);
  assert.equal(result.queries.length, 2);
  // AppDynamics' execCount is calls/minute, so its impact over a 60-minute
  // window is 500ms x 5/min x 60min; Datadog APM's is a real count: 50 x 10.
  assert.equal(result.queries[0].queryText, 'SELECT * FROM big_table');
  assert.equal(result.queries[0].source, 'appd-db');
  assert.equal(result.queries[0].execCountKind, 'rate-per-minute');
  assert.equal(result.queries[0].impactScore, 500 * 5 * 60);
  assert.equal(result.queries[0].totalTimeMs, 500 * 5 * 60);
  assert.equal(result.queries[1].source, 'datadog-apm');
  assert.equal(result.queries[1].execCountKind, 'count');
  assert.equal(result.queries[1].totalTimeMs, 500);
});

test('runDiagnose ranks a DBM row on average duration alone (it has no exec count)', async () => {
  const clients = fakeClients({
    datadogDbm: [{ queryText: 'abc123', queryTextIsHash: true, database: 'orders_db', avgDurationMs: 900, execCount: null }],
    datadogSlow: [{ resourceName: 'GET /orders', avgDurationMs: 50, execCount: 10 }],
  });
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' } }, timeRange: '1h', now: 1000000, clients,
  });
  const dbm = result.queries.find(q => q.source === 'datadog-dbm');
  assert.equal(dbm.execCountKind, null);
  assert.equal(dbm.impactScore, 900);          // avg alone, not avg x point count
  assert.equal(dbm.totalTimeMs, null);         // no honest total to report
  assert.equal(dbm.queryTextIsHash, true);
});

test('runDiagnose records a warning and continues when one platform fails', async () => {
  const clients = fakeClients({ datadogSlow: [{ resourceName: 'GET /x', avgDurationMs: 10, execCount: 1 }] });
  clients.appdynamics.fetchTierMetrics = rejects('boom', 401);
  clients.appdynamics.fetchSlowSql = rejects('boom', 401);
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' }, appdynamics: { applicationName: 'MyApp' } },
    timeRange: '1h', now: 1000000, clients,
  });
  assert.equal(result.warnings.length, 2);
  assert.ok(result.warnings.every(w => w.source === 'appdynamics'));
  assert.match(result.warnings[0].message, /AppDynamics load metrics: authentication failed/);
  assert.equal(result.queries.length, 1); // Datadog's data still comes through
});

test('runDiagnose keeps a platform\'s load metrics when only its query call fails', async () => {
  const load = { cpu: [{ t: 1000, v: 40 }], memory: [], throughput: [], connections: [] };
  const clients = fakeClients({ datadogLoad: load, datadogSlow: [{ resourceName: 'GET /x', avgDurationMs: 10, execCount: 1 }] });
  // A Datadog account without a DBM entitlement: DBM 403s, everything else works.
  clients.datadog.fetchDbmQueries = rejects('forbidden', 403);
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' } }, timeRange: '1h', now: 1000000, clients,
  });
  assert.equal(result.warnings.length, 1);
  assert.match(result.warnings[0].message, /Datadog Database Monitoring: authentication failed/);
  // Charts still have data, and the APM rows survived.
  assert.deepEqual(result.load.seriesBySource.datadog.cpu, load.cpu);
  assert.equal(result.queries.length, 1);
  assert.equal(result.queries[0].source, 'datadog-apm');
});

test('runDiagnose keeps a platform\'s query rows when only its load call fails', async () => {
  const clients = fakeClients({ appdSlowSql: [{ queryText: 'SELECT 1', avgDurationMs: 10, execCount: 1 }] });
  clients.appdynamics.fetchTierMetrics = rejects('metric tree unavailable');
  const result = await runDiagnose({
    environment: { appdynamics: { applicationName: 'MyApp' } }, timeRange: '1h', now: 1000000, clients,
  });
  assert.equal(result.warnings.length, 1);
  assert.match(result.warnings[0].message, /AppDynamics load metrics: request failed/);
  assert.equal(result.queries.length, 1);
  assert.deepEqual(result.load.seriesBySource.appdynamics, { cpu: [], memory: [], throughput: [], connections: [] });
});

test('runDiagnose surfaces an AppDynamics slow-SQL failure instead of showing an empty table silently', async () => {
  const clients = fakeClients();
  clients.appdynamics.fetchSlowSql = rejects('Request failed with status code 404');
  const result = await runDiagnose({
    environment: { appdynamics: { applicationName: 'MyApp' } }, timeRange: '1h', now: 1000000, clients,
  });
  assert.equal(result.queries.length, 0);
  assert.equal(result.warnings.length, 1);
  assert.match(result.warnings[0].message, /AppDynamics slow SQL \(Database Visibility\): request failed/);
});

test('runDiagnose only calls the platforms present in environment config', async () => {
  let appdCalled = false;
  const clients = fakeClients();
  clients.appdynamics.fetchTierMetrics = async () => { appdCalled = true; return { cpu: [], memory: [], throughput: [], connections: [] }; };
  await runDiagnose({ environment: { datadog: { envTag: 'prod' } }, timeRange: '1h', now: 1000000, clients });
  assert.equal(appdCalled, false);
});

test('runDiagnose passes the selected service through to both platforms', async () => {
  const seen = {};
  const clients = fakeClients();
  clients.datadog.fetchLoadMetrics = async (_cfg, opts) => { seen.ddLoad = opts.service; return { cpu: [], memory: [], throughput: [], connections: [] }; };
  clients.datadog.fetchSlowResources = async (_cfg, opts) => { seen.ddSlow = opts.service; return []; };
  clients.appdynamics.fetchTierMetrics = async (_cfg, opts) => { seen.appdLoad = opts.service; return { cpu: [], memory: [], throughput: [], connections: [] }; };
  clients.appdynamics.fetchSlowSql = async (_cfg, opts) => { seen.appdSql = opts.service; return []; };
  await runDiagnose({
    environment: { datadog: { envTag: 'prod' }, appdynamics: { applicationName: 'MyApp' } },
    service: 'checkout', timeRange: '1h', now: 1000000, clients,
  });
  assert.deepEqual(seen, { ddLoad: 'checkout', ddSlow: 'checkout', appdLoad: 'checkout', appdSql: 'checkout' });
});

test('runDiagnose returns the resolved window bounds so every chart shares one axis', async () => {
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' } }, timeRange: '1h', now: 1000000, clients: fakeClients(),
  });
  assert.equal(result.load.to, 1000000);
  assert.equal(result.load.from, 1000000 - 60 * 60 * 1000);
});

test('runDiagnose keeps each source\'s series separate and correlates them per source', async () => {
  const from = 1000000 - 5 * 60 * 1000;
  // Datadog reports memory in bytes, AppDynamics as a percentage. Pooling them
  // would let the byte magnitudes set the threshold for both.
  const clients = fakeClients({
    datadogLoad: {
      cpu: [], throughput: [], connections: [],
      memory: [0, 1, 2, 3, 4].map(i => ({ t: from + i * 60000 + 10000, v: i === 0 ? 9e9 : 8e9 })),
    },
    appdLoad: {
      cpu: [], throughput: [], connections: [],
      memory: [0, 1, 2, 3, 4].map(i => ({ t: from + i * 60000 + 10000, v: i === 4 ? 90 : 10 })),
    },
  });
  const result = await runDiagnose({
    environment: { datadog: { envTag: 'prod' }, appdynamics: { applicationName: 'MyApp' } },
    timeRange: '15m', now: 1000000, clients,
  });
  assert.deepEqual(Object.keys(result.load.seriesBySource), ['datadog', 'appdynamics']);
  // Both sources' own spikes are represented — the byte magnitudes never set
  // the threshold for the percentage series or vice versa.
  assert.equal(result.load.highLoadBuckets.length, 2);
});

test('buildFixPrompt mentions the load-correlation state', () => {
  const withLoad = buildFixPrompt({ queryText: 'SELECT 1', database: 'db', avgDurationMs: 100, execCount: 3, loadCorrelated: true });
  assert.match(withLoad, /correlates with a period of elevated/);
  const withoutLoad = buildFixPrompt({ queryText: 'SELECT 1', database: 'db', avgDurationMs: 100, execCount: 3, loadCorrelated: false });
  assert.match(withoutLoad, /does NOT correlate/);
});

test('buildFixPrompt labels a rate as a rate and says so when no count exists', () => {
  const rate = buildFixPrompt({ queryText: 'SELECT 1', avgDurationMs: 100, execCount: 40, execCountKind: 'rate-per-minute', loadCorrelated: false });
  assert.match(rate, /40 calls\/minute/);
  const none = buildFixPrompt({ queryText: 'SELECT 1', avgDurationMs: 100, execCount: null, execCountKind: null, loadCorrelated: false });
  assert.match(none, /not reported by this monitoring source/);
});

test('suggestFix refuses a row whose "query text" is only a signature hash', async () => {
  await assert.rejects(
    () => suggestFix({ aiEnabled: true }, { queryText: 'abc123', queryTextIsHash: true, avgDurationMs: 1, execCount: 1, loadCorrelated: false }),
    (e) => e.code === 'QUERY_TEXT_UNAVAILABLE'
  );
});

test('suggestFix throws a coded error when AI is not configured', async () => {
  const sess = { aiEnabled: false };
  await assert.rejects(
    () => suggestFix(sess, { queryText: 'q', avgDurationMs: 1, execCount: 1, loadCorrelated: false }),
    (e) => e.code === 'AI_NOT_CONFIGURED'
  );
});
