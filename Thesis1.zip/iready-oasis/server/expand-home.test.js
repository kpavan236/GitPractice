'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const { expandHome } = require('./expand-home');

const HOME = os.homedir();

// This runs in ~30 places — every clone, every scan target, every script
// lookup. The version it replaced fell through to `/tmp` on Windows because
// HOME is unset there, so the app silently used the wrong directory rather than
// failing. These tests are mostly about the ways it must NOT be clever.

test('expands a leading tilde', () => {
  assert.equal(expandHome('~'), HOME);
  assert.equal(expandHome('~/dev/projects/iready'), path.join(HOME, 'dev/projects/iready'));
});

test('uses os.homedir(), which is defined on Windows too', () => {
  // The whole point. process.env.HOME is normally unset on Windows — the
  // variable is USERPROFILE — and os.homedir() reads whichever applies.
  assert.equal(expandHome('~').startsWith(HOME), true);
  assert.ok(HOME.length > 1, 'os.homedir() must return something real');
});

test('normalises the separator for the platform', () => {
  // A caller writing '~/dev' should get a backslash path on Windows without
  // having to know that.
  assert.equal(expandHome('~/dev/x'), path.join(HOME, 'dev', 'x'));
  assert.equal(expandHome('~/dev/x').includes(path.sep), true);
});

test('accepts a Windows-style separator after the tilde', () => {
  assert.equal(expandHome('~\\dev\\x'), path.join(HOME, '\\dev\\x'));
});

test('leaves an absolute path alone', () => {
  assert.equal(expandHome('/var/data'), '/var/data');
  assert.equal(expandHome('C:\\Users\\someone\\dev'), 'C:\\Users\\someone\\dev');
});

test('leaves a relative path alone', () => {
  assert.equal(expandHome('dev/projects'), 'dev/projects');
  assert.equal(expandHome('./scripts'), './scripts');
});

test('only a LEADING tilde is expanded', () => {
  // `.replace('~', home)` — what this replaced — rewrote a tilde anywhere in
  // the string. `~` is a legal filename character, and a backup file called
  // `notes~` or a path containing one would have been silently corrupted into
  // an absolute path pointing somewhere else entirely.
  assert.equal(expandHome('/var/backup~/data'), '/var/backup~/data');
  assert.equal(expandHome('notes~'), 'notes~');
  assert.equal(expandHome('/tmp/a~b'), '/tmp/a~b');
});

test('does not expand ~user — that is a shell feature we do not implement', () => {
  // Expanding it as if it were our own home would point at the wrong person's
  // directory, which is worse than leaving it unresolved and visible.
  assert.equal(expandHome('~otheruser/dev'), '~otheruser/dev');
});

test('handles nothing at all without throwing', () => {
  assert.equal(expandHome(''), '');
  assert.equal(expandHome(null), '');
  assert.equal(expandHome(undefined), '');
});

test('is idempotent — expanding twice changes nothing', () => {
  // It is called on values that may already have been expanded upstream.
  const once = expandHome('~/dev');
  assert.equal(expandHome(once), once);
});
