'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createExternalCalls, ExternalCallsDisabledError, parseFlag, hostOf } = require('./external-calls');

function make({ prefs, env = {}, hosts = ['github.example.test', 'jenkins.example.test'] } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'extcalls-'));
  const prefsPath = path.join(dir, 'prefs.json');
  if (prefs !== undefined) fs.writeFileSync(prefsPath, typeof prefs === 'string' ? prefs : JSON.stringify(prefs));
  return { ec: createExternalCalls({ prefsPath, env, getHosts: () => hosts }), prefsPath };
}

test('with nothing configured the calls are OFF', () => {
  assert.deepEqual(make().ec.state(), { enabled: false, source: 'default' });
});

test('the environment sets the starting value', () => {
  assert.deepEqual(make({ env: { OASIS_EXTERNAL_CALLS: 'on' } }).ec.state(), { enabled: true, source: 'environment' });
  assert.deepEqual(make({ env: { OASIS_EXTERNAL_CALLS: 'off' } }).ec.state(), { enabled: false, source: 'environment' });
});

test('the saved Settings choice beats the environment, and either way round', () => {
  assert.deepEqual(make({ prefs: { externalCallsEnabled: false }, env: { OASIS_EXTERNAL_CALLS: 'on' } }).ec.state(), { enabled: false, source: 'settings' });
  assert.deepEqual(make({ prefs: { externalCallsEnabled: true }, env: { OASIS_EXTERNAL_CALLS: 'off' } }).ec.state(), { enabled: true, source: 'settings' });
});

test('anything unrecognised fails SAFE (off), never open', () => {
  for (const bad of ['maybe', '', 'ON ', '2', undefined]) {
    assert.equal(parseFlag(bad), undefined, `"${bad}" must not count as a setting`);
  }
  assert.equal(make({ env: { OASIS_EXTERNAL_CALLS: 'maybe' } }).ec.isEnabled(), false);
  assert.equal(make({ prefs: '{ not json' }).ec.isEnabled(), false, 'a damaged prefs file means off');
  assert.equal(make({ prefs: { externalCallsEnabled: 'yes' } }).ec.isEnabled(), false, 'only a real boolean in the file counts');
});

test('flag words are understood in any case', () => {
  for (const on of ['on', 'ON', '1', 'true', 'Yes']) assert.equal(parseFlag(on), true, on);
  for (const off of ['off', 'OFF', '0', 'false', 'No']) assert.equal(parseFlag(off), false, off);
});

test('switching it saves to the prefs file, keeps everything else in it, and takes effect at once', () => {
  const { ec, prefsPath } = make({ prefs: { theme: 'dark', jiraUrl: 'https://jira.example.test' } });
  assert.equal(ec.isEnabled(), false);
  ec.setEnabled(true);
  assert.equal(ec.isEnabled(), true);
  assert.deepEqual(JSON.parse(fs.readFileSync(prefsPath, 'utf8')), { theme: 'dark', jiraUrl: 'https://jira.example.test', externalCallsEnabled: true });
  ec.setEnabled(false);
  assert.equal(ec.isEnabled(), false);
});

test('setEnabled refuses anything that is not a real true or false', () => {
  const { ec } = make();
  for (const bad of ['true', 1, null, undefined, {}]) assert.throws(() => ec.setEnabled(bad), /true or false/);
});

test('assertAllowed throws a recognisable error when off, and is silent when on', () => {
  const { ec } = make();
  assert.throws(() => ec.assertAllowed('GitHub'), err => err instanceof ExternalCallsDisabledError && err.code === 'EXTERNAL_CALLS_DISABLED' && err.status === 503 && /switched off/.test(err.message));
  ec.setEnabled(true);
  assert.doesNotThrow(() => ec.assertAllowed('GitHub'));
});

test('host matching ignores case, ports, paths and credentials in the address', () => {
  assert.equal(hostOf('https://GitHub.Example.test:8443/api/v3/user'), 'github.example.test');
  assert.equal(hostOf('https://user:secret@jenkins.example.test/job'), 'jenkins.example.test');
  assert.equal(hostOf('not a url'), null);
  assert.equal(hostOf(undefined), null);
});

// A stand-in for axios: records the interceptor so the tests can drive it.
function fakeAxios() {
  const fn = { handlers: [] };
  return { interceptors: { request: { use(f) { fn.handlers.push(f); } } }, run: config => fn.handlers.reduce((p, h) => p.then(h), Promise.resolve(config)), fn };
}

test('the HTTP gate blocks calls to the GitHub and Jenkins hosts when off, and lets other hosts through', async () => {
  const { ec } = make();
  const ax = fakeAxios();
  ec.installAxiosGate(ax);
  await assert.rejects(ax.run({ url: 'https://github.example.test/api/v3/user' }), err => err.code === 'EXTERNAL_CALLS_DISABLED');
  await assert.rejects(ax.run({ baseURL: 'https://jenkins.example.test', url: '/me/api/json' }), err => err.code === 'EXTERNAL_CALLS_DISABLED');
  const other = { url: 'https://slack.com/api/auth.test' };
  assert.equal(await ax.run(other), other, 'JIRA, Slack and everything else are not affected');
});

test('the HTTP gate lets a login call through even when off, and everything when on', async () => {
  const { ec } = make();
  const ax = fakeAxios();
  ec.installAxiosGate(ax);
  const login = { url: 'https://github.example.test/api/v3/user', oasisLogin: true };
  assert.equal(await ax.run(login), login);
  ec.setEnabled(true);
  const normal = { url: 'https://github.example.test/api/v3/orgs/acme/repos' };
  assert.equal(await ax.run(normal), normal);
});

test('the HTTP gate looks up the hosts afresh each time, so a new session is covered at once', async () => {
  const hosts = [];
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'extcalls-'));
  const ec = createExternalCalls({ prefsPath: path.join(dir, 'p.json'), env: {}, getHosts: () => hosts });
  const ax = fakeAxios();
  ec.installAxiosGate(ax);
  const cfg = { url: 'https://github.late.test/x' };
  assert.equal(await ax.run(cfg), cfg, 'not a known host yet');
  hosts.push('github.late.test');
  await assert.rejects(ax.run(cfg), err => err.code === 'EXTERNAL_CALLS_DISABLED');
});

function run(mw, reqPath, baseUrl = '') {
  const out = { nexted: false, status: null, body: null };
  mw({ path: reqPath, baseUrl }, { status(s) { out.status = s; return this; }, json(b) { out.body = b; return this; } }, () => { out.nexted = true; });
  return out;
}

test('the route gate answers 503 with a clear message for listed routes when off, and passes the rest', () => {
  const { ec } = make();
  const mw = ec.routeGate([/^\/api\/repos(\/|$)/, /^\/api\/pull$/]);
  const blocked = run(mw, '/api/repos/count');
  assert.equal(blocked.nexted, false);
  assert.equal(blocked.status, 503);
  assert.equal(blocked.body.code, 'EXTERNAL_CALLS_DISABLED');
  assert.match(blocked.body.message, /switched off/);
  assert.equal(run(mw, '/api/prefs').nexted, true);
  assert.equal(run(mw, '/api/reposXYZ').nexted, true, 'a prefix needs a boundary');
  ec.setEnabled(true);
  assert.equal(run(mw, '/api/repos').nexted, true);
});

test('the route gate still matches when it is mounted under /api (Express then hides the prefix)', () => {
  const { ec } = make();
  const mw = ec.routeGate([/^\/api\/repos(\/|$)/]);
  assert.equal(run(mw, '/repos', '/api').status, 503, 'mounted at /api, the path arrives as /repos');
  assert.equal(run(mw, '/prefs', '/api').nexted, true);
});

function answer(ec, body) {
  const out = { status: null, body: null };
  const refused = ec.refuseAutomatic({ body }, { status(s) { out.status = s; return this; }, json(b) { out.body = b; return this; } }, 'JIRA background');
  return { refused, ...out };
}

test('while off, a timer\'s request (marked auto) is refused with a clear message, and a person\'s click is not', () => {
  const { ec } = make();
  const auto = answer(ec, { session: 's', auto: true });
  assert.equal(auto.refused, true);
  assert.equal(auto.status, 503);
  assert.equal(auto.body.code, 'EXTERNAL_CALLS_DISABLED');
  assert.match(auto.body.message, /JIRA background calls are switched off/);
  assert.equal(answer(ec, { session: 's' }).refused, false, 'the Sync button sends no auto marker');
  assert.equal(answer(ec, { session: 's', auto: false }).refused, false);
});

test('while on, nothing is refused; and only a real true counts as automatic', () => {
  const { ec } = make();
  ec.setEnabled(true);
  assert.equal(answer(ec, { auto: true }).refused, false);
  ec.setEnabled(false);
  for (const odd of ['true', 1, 'yes', null, {}]) assert.equal(answer(ec, { auto: odd }).refused, false, `${JSON.stringify(odd)} is not the marker`);
  assert.equal(answer(ec, undefined).refused, false, 'no body at all');
});
