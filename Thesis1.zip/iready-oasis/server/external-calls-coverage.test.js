'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// The HTTP gate stops every request made through the shared HTTP client. Git
// commands that contact GitHub do not go through it, so each one needs an explicit
// externalCalls.assertAllowed(...) right before it. This test finds them all and
// fails when one is unguarded, so a command added later cannot quietly bypass the
// switch.

const FILES = ['index.js', 'branches.js', 'jira.js'].map(f => path.join(__dirname, f));
// A command that starts with git and contacts the remote: ls-remote, fetch, pull, clone.
const NETWORK_GIT = /[`'"]git\s.*\b(ls-remote|fetch|pull|clone)\b/;
const GUARD = /externalCalls\.assertAllowed\(/;

function findUnguarded(file) {
  const lines = fs.readFileSync(file, 'utf8').split('\n');
  const found = [];
  lines.forEach((line, i) => {
    const code = line.trim();
    if (code.startsWith('//') || code.startsWith('*')) return;
    if (!NETWORK_GIT.test(line)) return;
    const window = lines.slice(Math.max(0, i - 3), i + 1).join('\n');
    if (!GUARD.test(window)) found.push(`${path.basename(file)}:${i + 1}: ${code.slice(0, 90)}`);
  });
  return found;
}

test('every git command that contacts GitHub is guarded by the external-calls switch', () => {
  const unguarded = FILES.flatMap(findUnguarded);
  assert.deepEqual(unguarded, [], `unguarded network git commands:\n${unguarded.join('\n')}`);
});

test('the scan really does see the commands it is meant to guard (so it cannot pass by finding nothing)', () => {
  const total = FILES.reduce((n, f) => n + fs.readFileSync(f, 'utf8').split('\n').filter(l => NETWORK_GIT.test(l) && !l.trim().startsWith('//') && !l.trim().startsWith('*')).length, 0);
  assert.ok(total >= 8, `expected at least 8 network git commands, found ${total}`);
});

test('the pattern recognises a command and ignores prose', () => {
  assert.ok(NETWORK_GIT.test('await execQuiet(`git -C "${d}" fetch --quiet origin`)'));
  assert.ok(NETWORK_GIT.test('`git clone --depth 1 "${u}" "${d}"`'));
  assert.ok(!NETWORK_GIT.test('Output SKIP if the README only shows standard git clone, or has no section'));
  assert.ok(!NETWORK_GIT.test('await execQuiet(`git -C "${d}" checkout "${b}"`)'));
});

test('the background and scheduled jobs ask the switch before they start', () => {
  const branches = fs.readFileSync(path.join(__dirname, 'branches.js'), 'utf8');
  const warm = branches.slice(branches.indexOf('const warm = async'), branches.indexOf('setTimeout(warm'));
  assert.match(warm, /externalCalls\.isEnabled\(\)/, 'the branch refresher must stop when the switch is off');
  const vw = fs.readFileSync(path.join(__dirname, 'version-watch', 'index.js'), 'utf8');
  const auto = vw.slice(vw.indexOf('function maybeAutoScanVersionWatch'), vw.indexOf('setInterval(maybeAutoScanVersionWatch'));
  assert.match(auto, /externalCalls\.isEnabled\(\)/, 'the automatic Version Watch scan must stop when the switch is off');
});

test('the JIRA timer checks the switch on every tick and marks its requests as automatic', () => {
  const client = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'modules', 'jira.js'), 'utf8');
  const timer = client.slice(client.indexOf('function startJiraAutoSync'), client.indexOf('function stopJiraAutoSync'));
  assert.match(timer, /externalCallsOn\(\)/, 'the timer must skip a tick while the switch is off');
  assert.match(timer, /syncJira\(true, true\)/, 'the timer must mark its sync as automatic');
  const sync = client.slice(client.indexOf('async function syncJira'), client.indexOf('async function loadJiraHistory'));
  assert.equal((sync.match(/auto: auto/g) || []).length, 2, 'both the first request and the retry must carry the marker');
});

test('the server refuses automatic JIRA syncs while the switch is off', () => {
  const route = fs.readFileSync(path.join(__dirname, 'jira.js'), 'utf8');
  const sync = route.slice(route.indexOf("app.post('/api/jira/sync'"), route.indexOf("app.get('/api/jira/ticket-work'"));
  assert.match(sync, /externalCalls\.refuseAutomatic\(req, res/, 'the sync route must check the switch for automatic requests');
  const refuse = sync.indexOf('refuseAutomatic');
  assert.ok(refuse > -1 && refuse < sync.indexOf('sessions[session]') + 400, 'and before it does any work');
});
