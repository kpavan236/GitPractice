'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync, spawn } = require('child_process');

// Finding a usable Bash, and saying so plainly when there is not one.
//
// Every script this app runs — repository setup, launch, AWS credential
// refresh, Docker streaming — goes through `spawn('bash', …)`. On Windows that
// call fails with ENOENT, which surfaced as a job that produced no output and
// no explanation. A feature that cannot work should say why, not go quiet.
//
// THE USEFUL PART IS THE SEARCH, NOT THE ERROR. OASIS already requires git to
// clone anything, and on Windows git overwhelmingly means Git for Windows,
// which ships bash at a predictable location. So on most Windows machines bash
// is already present and merely absent from PATH — looking in those places
// turns "this feature is broken" into "this feature works" without asking the
// user to install anything.

// Cached: this shells out, and the answer cannot change while the app runs.
let _bash;

// Where Git for Windows puts bash. Checked in order; the first that exists wins.
//
// path.win32 explicitly, and `env` injected, for one reason: this builds
// WINDOWS paths, and it must build them correctly no matter which platform is
// asking. Plain `path.join` would produce forward slashes when called from a
// Mac — which is exactly the situation every test run is in, so the function
// would be untestable on the machine it is written on.
function windowsCandidates(env = process.env) {
  const roots = [
    env.ProgramFiles,
    env['ProgramFiles(x86)'],
    env.LOCALAPPDATA && path.win32.join(env.LOCALAPPDATA, 'Programs'),
  ].filter(Boolean);

  const relative = [
    path.win32.join('Git', 'bin', 'bash.exe'),
    // usr/bin is the MSYS2 layout Git for Windows uses internally; some
    // installs expose only this one.
    path.win32.join('Git', 'usr', 'bin', 'bash.exe'),
  ];

  const out = [];
  for (const root of roots) for (const rel of relative) out.push(path.win32.join(root, rel));
  // A last resort for an install that ignored the standard roots, and the only
  // candidate when the environment variables are missing entirely.
  out.push('C:\\Program Files\\Git\\bin\\bash.exe');
  return out;
}

function runs(command) {
  try {
    execFileSync(command, ['--version'], { stdio: 'ignore', timeout: 5000 });
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Locates a usable bash.
 *
 * @returns {{ available, path, source, hint }}
 *   `path` is what to spawn. `hint` is what to tell a human, and is only set
 *   when there is nothing to run — an unexplained missing feature is the thing
 *   this module exists to prevent.
 */
// The overrides exist so the FAILURE path can be tested. Without them the only
// way to exercise "there is no bash" is to run on a machine that has none,
// which no CI worker does — so the branch that matters most would ship
// unverified.
function detectBash({ refresh = false, platform = process.platform, env = process.env, probe = runs, exists = fs.existsSync } = {}) {
  const cacheable = platform === process.platform && env === process.env && probe === runs;
  if (_bash && !refresh && cacheable) return _bash;

  const remember = value => {
    if (cacheable) _bash = value;
    return value;
  };

  // On PATH is the normal case everywhere, including a Windows machine whose
  // user added Git's bin directory themselves.
  if (probe('bash')) {
    return remember({ available: true, path: 'bash', source: 'PATH', hint: null });
  }

  if (platform === 'win32') {
    for (const candidate of windowsCandidates(env)) {
      if (exists(candidate) && probe(candidate)) {
        return remember({ available: true, path: candidate, source: 'Git for Windows', hint: null });
      }
    }
    return remember({
      available: false,
      path: null,
      source: null,
      // Names the specific fix rather than the general problem. OASIS needs git
      // regardless, so this is not an extra dependency — it is the one the user
      // already needs, installed in the usual way.
      hint: 'Setup and launch scripts need Bash. Install Git for Windows '
        + '(https://git-scm.com/download/win) — it provides both git and bash — '
        + 'then restart OASIS.',
    });
  }

  return remember({
    available: false,
    path: null,
    source: null,
    hint: 'Bash was not found on PATH. Install it through your package manager, then restart OASIS.',
  });
}

/**
 * Spawns bash, or throws an error a human can act on.
 *
 * Every caller previously spawned the literal string 'bash'. Routing them
 * through here means the Git-for-Windows fallback applies everywhere, and the
 * failure message is written once instead of being absent five times.
 */
function spawnBash(args, options = {}) {
  const bash = detectBash();
  if (!bash.available) throw new Error(bash.hint);
  return spawn(bash.path, args, options);
}

// For the tools/capability endpoint, so the UI can disable what cannot work and
// say why instead of offering a button that does nothing.
function shellStatus() {
  const bash = detectBash();
  return {
    bash: {
      available: bash.available,
      path: bash.path,
      source: bash.source,
      hint: bash.hint,
    },
    platform: process.platform,
    // Named so a reader knows which features go quiet without a shell.
    requires: ['repository setup', 'launch', 'AWS credential refresh', 'Docker commands'],
  };
}

function _resetForTests() {
  _bash = undefined;
}

module.exports = { detectBash, spawnBash, shellStatus, windowsCandidates, _resetForTests };
