'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseHcl, resourcesFrom, parseValue } = require('./iac/hcl');

// The parser only has to read what a policy inspects. These tests pin the
// constructs real Terraform uses and, more importantly, the two places where
// being wrong would hide a finding rather than merely miss one.

test('parses a resource block into type, name and attributes', () => {
  const resources = resourcesFrom(`
resource "aws_s3_bucket" "logs" {
  bucket = "my-logs"
  acl    = "private"
}
`, 'main.tf');

  assert.equal(resources.length, 1);
  assert.equal(resources[0].type, 'aws_s3_bucket');
  assert.equal(resources[0].name, 'logs');
  assert.equal(resources[0].body.acl, 'private');
  assert.equal(resources[0].line, 2);
});

test('repeated blocks of the same name become a list', () => {
  // The one that matters most. A security group can carry several ingress
  // blocks; collapsing them to the last would hide every rule but one — and the
  // hidden one is exactly the rule an attacker uses.
  const [sg] = resourcesFrom(`
resource "aws_security_group" "web" {
  ingress {
    from_port   = 443
    cidr_blocks = ["10.0.0.0/8"]
  }
  ingress {
    from_port   = 22
    cidr_blocks = ["0.0.0.0/0"]
  }
}
`, 'sg.tf');

  assert.ok(Array.isArray(sg.body.ingress), 'two ingress blocks must not collapse into one');
  assert.equal(sg.body.ingress.length, 2);
  assert.deepEqual(sg.body.ingress[1].cidr_blocks, ['0.0.0.0/0']);
});

test('nested blocks become nested objects', () => {
  const [bucket] = resourcesFrom(`
resource "aws_s3_bucket" "b" {
  versioning {
    enabled = true
  }
}
`, 'main.tf');
  assert.equal(bucket.body.versioning.enabled, true);
});

test('parses literal scalars, lists and booleans', () => {
  assert.equal(parseValue('"hello"'), 'hello');
  assert.equal(parseValue('true'), true);
  assert.equal(parseValue('42'), 42);
  assert.equal(parseValue('3.5'), 3.5);
  assert.deepEqual(parseValue('["a", "b"]'), ['a', 'b']);
  assert.deepEqual(parseValue('[]'), []);
});

test('an unresolved expression stays raw rather than being guessed', () => {
  // Resolving `var.x` means implementing Terraform. An unresolved value fails
  // to match a literal, so the policy reports the resource and a human looks —
  // a false positive, which is the safe direction. A WRONGLY resolved value
  // would pass silently.
  const [db] = resourcesFrom(`
resource "aws_db_instance" "d" {
  storage_encrypted = var.encrypt_everything
  name              = "\${local.prefix}-db"
}
`, 'rds.tf');
  assert.equal(db.body.storage_encrypted, 'var.encrypt_everything');
  assert.equal(db.body.name, '"${local.prefix}-db"');
});

test('comments are stripped, but not inside strings', () => {
  const [b] = resourcesFrom(`
resource "aws_s3_bucket" "b" {
  # acl = "public-read"
  acl = "private"  # keep it private
  note = "value with # inside"
}
`, 'main.tf');
  assert.equal(b.body.acl, 'private');
  // A commented-out attribute must not be read as set.
  assert.equal(b.body.note, 'value with # inside');
});

test('multi-line lists and maps are gathered', () => {
  const [sg] = resourcesFrom(`
resource "aws_security_group" "x" {
  cidr_blocks = [
    "10.0.0.0/8",
    "192.168.0.0/16",
  ]
  tags = {
    Environment = "prod"
    Owner       = "platform"
  }
}
`, 'sg.tf');
  assert.deepEqual(sg.body.cidr_blocks, ['10.0.0.0/8', '192.168.0.0/16']);
  assert.equal(sg.body.tags.Environment, 'prod');
});

test('heredocs are read as their text', () => {
  const [p] = resourcesFrom(`
resource "aws_iam_policy" "p" {
  policy = <<POLICY
{
  "Effect": "Allow"
}
POLICY
}
`, 'iam.tf');
  assert.match(p.body.policy, /"Effect": "Allow"/);
});

test('only resource and data blocks become policy resources', () => {
  // Evaluating a bucket policy against a provider or variable block is noise.
  const resources = resourcesFrom(`
terraform {
  required_version = ">= 1.0"
}
variable "region" {
  default = "us-east-1"
}
provider "aws" {
  region = var.region
}
resource "aws_s3_bucket" "b" {
  acl = "private"
}
data "aws_ami" "ubuntu" {
  most_recent = true
}
`, 'main.tf');

  assert.deepEqual(resources.map(r => r.type).sort(), ['aws_ami', 'aws_s3_bucket']);
});

test('malformed input yields no resources instead of throwing', () => {
  // One unparseable file must never fail a repository scan.
  assert.doesNotThrow(() => parseHcl('resource "broken" {{{{'));
  assert.doesNotThrow(() => parseHcl(''));
  assert.doesNotThrow(() => parseHcl(null));
  assert.deepEqual(resourcesFrom('', 'x.tf'), []);
});
