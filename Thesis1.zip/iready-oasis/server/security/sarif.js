'use strict';

// SARIF 2.1.0 export.
//
// SARIF is the OASIS standard for static analysis results, and it is what
// everything downstream speaks: GitHub code scanning, GitLab, Azure DevOps, and
// the VS Code SARIF viewer all ingest it. Without this, findings can only be
// read inside OASIS; with it, the same scan can annotate a pull request, fail a
// CI job, or open inline in an editor.
//
// Two details are what make a SARIF file actually useful rather than merely
// valid:
//
//   partialFingerprints — how a consumer tracks a finding across commits. Ours
//   already survive code moving, so exporting them means GitHub will not close
//   and reopen every alert when a file is reformatted.
//
//   security-severity — a numeric property GitHub reads to assign its own
//   severity. Without it every alert lands as "warning" regardless of what we
//   determined, and the risk work is thrown away at the boundary.

const SCHEMA = 'https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json';
const VERSION = '2.1.0';

// SARIF has four levels; our five severities map onto them. INFO becomes
// "note", and nothing maps to "none" — a finding we chose to report is never
// nothing.
const LEVELS = {
  CRITICAL: 'error',
  HIGH: 'error',
  MEDIUM: 'warning',
  LOW: 'note',
  INFO: 'note',
};

// GitHub buckets security-severity as: 9.0+ critical, 7.0+ high, 4.0+ medium,
// below that low. These are the midpoints of those bands, so our severity
// survives the round trip instead of being flattened.
const SECURITY_SEVERITY = {
  CRITICAL: '9.5',
  HIGH: '7.5',
  MEDIUM: '5.0',
  LOW: '2.0',
  INFO: '1.0',
};

// One SARIF rule per (ruleId), collected from the findings themselves — the
// scanners do not publish a rule catalogue, and a rules array that disagreed
// with the results would be worse than one derived from them.
function collectRules(findings) {
  const byId = new Map();

  for (const finding of findings) {
    for (const detection of finding.detections) {
      const id = detection.ruleId || `${finding.type}/${finding.category}`;
      if (byId.has(id)) continue;

      const tags = ['security', finding.type.toLowerCase()];
      if (finding.cwe) tags.push(`external/cwe/${finding.cwe.toLowerCase()}`);
      if (finding.metadata && finding.metadata.owasp) {
        // GitHub renders external/cwe and OWASP tags as filterable labels.
        tags.push(`external/owasp/${finding.metadata.owasp.split(':')[0].toLowerCase()}`);
      }
      if (finding.metadata && finding.metadata.transitive) tags.push('transitive-dependency');
      if (finding.metadata && finding.metadata.knownExploited) tags.push('known-exploited');

      byId.set(id, {
        id,
        name: finding.category,
        shortDescription: { text: finding.title },
        fullDescription: { text: finding.description || finding.title },
        help: {
          text: finding.remediation || finding.description || finding.title,
          markdown: finding.remediation ? `**Remediation:** ${finding.remediation}` : undefined,
        },
        defaultConfiguration: { level: LEVELS[finding.severity] || 'warning' },
        properties: {
          tags,
          'security-severity': SECURITY_SEVERITY[finding.severity] || '5.0',
          precision: (finding.metadata && finding.metadata.confidence
            ? String(finding.metadata.confidence).toLowerCase()
            : 'medium'),
        },
      });
    }
  }

  return [...byId.values()];
}

function locationFor(finding) {
  // A finding with no file — an SCA advisory against a package rather than a
  // line of code — still needs a location, or consumers drop it. The lockfile
  // or manifest is the honest answer.
  const uri = finding.file || (finding.metadata && finding.metadata.lockfile) || '.';
  const location = { physicalLocation: { artifactLocation: { uri, uriBaseId: '%SRCROOT%' } } };

  if (finding.startLine) {
    location.physicalLocation.region = {
      startLine: finding.startLine,
      endLine: finding.endLine || finding.startLine,
    };
  }
  return location;
}

// A suppressed finding is exported as suppressed rather than omitted, so a
// consumer sees the same set of findings we do and the triage decision travels
// with them.
function suppressionsFor(finding) {
  if (finding.status !== 'SUPPRESSED' && finding.status !== 'FALSE_POSITIVE') return undefined;
  return [
    {
      kind: 'external',
      status: 'accepted',
      justification:
        (finding.suppression && finding.suppression.reason) ||
        (finding.status === 'FALSE_POSITIVE' ? 'Marked as a false positive' : 'Risk accepted'),
    },
  ];
}

function resultFor(finding, ruleIndex, ruleId) {
  const risk = finding.risk || {};

  return {
    ruleId,
    ruleIndex,
    level: LEVELS[finding.severity] || 'warning',
    message: {
      text: [
        finding.description || finding.title,
        finding.evidence ? `Evidence: ${finding.evidence}` : null,
        risk.score !== undefined ? `Risk ${risk.score}/100 (${risk.priority}).` : null,
      ]
        .filter(Boolean)
        .join(' '),
    },
    locations: [locationFor(finding)],
    // The stable identity. Exporting it is what stops a consumer treating a
    // reformatted file as a new set of alerts.
    partialFingerprints: { oasisFingerprint: finding.fingerprint },
    suppressions: suppressionsFor(finding),
    properties: {
      severity: finding.severity,
      riskScore: risk.score,
      riskPriority: risk.priority,
      riskConfidence: risk.confidence,
      // Every scanner that reported it. A finding corroborated by two engines
      // is worth more than one, and that is invisible without this.
      detectedBy: finding.detections.map(d => d.source),
      repository: finding.repository,
      status: finding.status,
      cve: finding.cve || undefined,
      cwe: finding.cwe || undefined,
      cvssVector: finding.metadata ? finding.metadata.cvssVector : undefined,
      owasp: finding.metadata ? finding.metadata.owasp : undefined,
      transitive: finding.metadata ? finding.metadata.transitive : undefined,
      knownExploited: finding.metadata ? finding.metadata.knownExploited : undefined,
      epss: finding.metadata ? finding.metadata.epss : undefined,
    },
  };
}

/**
 * @param {Array}  findings
 * @param {object} opts  { toolVersion, repository, invocation }
 */
function toSarif(findings, { toolVersion = null, repository = null, startedAt = null, endedAt = null } = {}) {
  const list = findings || [];
  const rules = collectRules(list);
  const indexById = new Map(rules.map((r, i) => [r.id, i]));

  const results = list.map(finding => {
    const ruleId = (finding.detections[0] && finding.detections[0].ruleId) || `${finding.type}/${finding.category}`;
    return resultFor(finding, indexById.get(ruleId) ?? 0, ruleId);
  });

  return {
    $schema: SCHEMA,
    version: VERSION,
    runs: [
      {
        tool: {
          driver: {
            name: 'i-Ready OASIS Security',
            version: toolVersion || 'unknown',
            informationUri: 'https://github.cainc.com/iready/iready-oasis',
            rules,
          },
        },
        // Named so a consumer resolves relative paths against the checkout.
        originalUriBaseIds: { '%SRCROOT%': { description: { text: repository || 'repository root' } } },
        invocations: [
          {
            executionSuccessful: true,
            startTimeUtc: startedAt ? new Date(startedAt).toISOString() : undefined,
            endTimeUtc: endedAt ? new Date(endedAt).toISOString() : undefined,
          },
        ],
        results,
        properties: { repository: repository || undefined },
      },
    ],
  };
}

module.exports = { toSarif, collectRules, LEVELS, SECURITY_SEVERITY, SCHEMA, VERSION };