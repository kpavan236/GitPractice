'use strict';
const cheerio = require('cheerio');

// Maven transitive dependency resolution.
//
// Every other ecosystem writes a lockfile listing what the resolver installed.
// Maven does not — the resolved tree exists only inside `mvn dependency:tree`,
// which is exactly the installed tooling this product cannot assume. So the
// resolution happens here: POMs are fetched from a repository and walked the
// way Maven walks them.
//
// This matters more than any other gap for a Java codebase. A Spring Boot
// application declares a handful of starters and resolves to several hundred
// jars; reading pom.xml alone sees the handful. Log4Shell arrived through
// spring-boot-starter-log4j2, not a direct log4j-core declaration.
//
// Maven's rules that are implemented here, because omitting them produces wrong
// versions rather than merely fewer results:
//
//   parent POMs          properties and dependencyManagement are inherited
//   dependencyManagement supplies the version when a dependency omits one
//   BOM imports          <scope>import</scope> pulls in another POM's
//                        dependencyManagement — this is how every Spring Boot
//                        project pins its versions, so skipping it leaves most
//                        dependencies with no resolvable version at all
//   property expansion   ${project.version}, ${spring.version}, inherited
//   scopes               compile and runtime are transitive; test and provided
//                        are not, which is Maven's rule and stops a test-only
//                        library being reported as shipped
//   exclusions           an excluded child is not walked
//   nearest wins         the version closest to the root of the tree is used
//
// Not implemented, and reported rather than hidden: version ranges (rare in
// practice), profile activation, and mirrors/authentication beyond a single
// configurable base URL.

const DEFAULT_REPOSITORY = 'https://repo1.maven.org/maven2';

// Depth and breadth caps. A large Spring project resolves several hundred
// artifacts; these exist so a pathological graph cannot run forever, and both
// are reported when hit.
const MAX_DEPTH = 8;
// Raisable, because "incomplete" is a worse answer than "slow" for anyone who
// actually has a graph this size, and 1500 is a guess about other people's
// projects rather than a property of the analysis.
const MAX_ARTIFACTS = Number(process.env.OASIS_MAVEN_MAX_ARTIFACTS) || 1500;

// Scopes whose dependencies are themselves shipped. Maven does not propagate
// test or provided through the graph, and neither do we.
const TRANSITIVE_SCOPES = new Set(['compile', 'runtime']);

function text($, el, tag) {
  const found = $(el).children(tag).first();
  return found.length ? found.text().trim() : null;
}

/**
 * Parses one POM into the pieces resolution needs.
 * Structure only — no fetching, so this is pure and directly testable.
 */
function parsePom(xml) {
  const $ = cheerio.load(xml, { xmlMode: true });
  const project = $('project').first();

  const parentEl = project.children('parent').first();
  const parent = parentEl.length
    ? {
        groupId: text($, parentEl, 'groupId'),
        artifactId: text($, parentEl, 'artifactId'),
        version: text($, parentEl, 'version'),
      }
    : null;

  const properties = {};
  project
    .children('properties')
    .children()
    .each((_, el) => {
      properties[el.tagName] = $(el).text().trim();
    });

  const readDeps = container =>
    container
      .children('dependency')
      .toArray()
      .map(el => ({
        groupId: text($, el, 'groupId'),
        artifactId: text($, el, 'artifactId'),
        version: text($, el, 'version'),
        scope: text($, el, 'scope') || null,
        optional: text($, el, 'optional') === 'true',
        type: text($, el, 'type') || 'jar',
        exclusions: $(el)
          .children('exclusions')
          .children('exclusion')
          .toArray()
          .map(ex => `${text($, ex, 'groupId')}:${text($, ex, 'artifactId')}`),
      }))
      .filter(d => d.groupId && d.artifactId);

  // <licenses> is in every well-formed POM and we were downloading it anyway.
  const licenses = project
    .children('licenses')
    .children('license')
    .toArray()
    .map(el => text($, el, 'name') || text($, el, 'url'))
    .filter(Boolean);

  return {
    licenses,
    groupId: text($, project, 'groupId') || (parent && parent.groupId),
    artifactId: text($, project, 'artifactId'),
    // A module inheriting its version from the parent is the norm in a
    // multi-module build.
    version: text($, project, 'version') || (parent && parent.version),
    packaging: text($, project, 'packaging') || 'jar',
    parent,
    properties,
    dependencies: readDeps(project.children('dependencies').first()),
    dependencyManagement: readDeps(
      project.children('dependencyManagement').first().children('dependencies').first()
    ),
    modules: project
      .children('modules')
      .children('module')
      .toArray()
      .map(el => $(el).text().trim()),
  };
}

// Expands ${...} against the property table, the project's own coordinates, and
// the inherited chain. Bounded iteration because properties can reference each
// other and a cycle must not hang the scan.
function expand(value, properties, depth = 0) {
  if (typeof value !== 'string' || !value.includes('${') || depth > 5) return value;
  const next = value.replace(/\$\{([^}]+)\}/g, (whole, key) => {
    const resolved = properties[key];
    return resolved === undefined ? whole : resolved;
  });
  return next === value ? value : expand(next, properties, depth + 1);
}

function coordKey(groupId, artifactId) {
  return `${groupId}:${artifactId}`;
}

/**
 * Resolves the full dependency graph for one project POM.
 *
 * @param {string}   rootXml   the project's pom.xml
 * @param {function} fetchPom  (groupId, artifactId, version) -> xml | null
 * @param {object}   opts      { maxDepth, maxArtifacts, includeTestScope }
 */
async function resolve(rootXml, fetchPom, opts = {}) {
  const maxDepth = opts.maxDepth ?? MAX_DEPTH;
  const maxArtifacts = opts.maxArtifacts ?? MAX_ARTIFACTS;
  const includeTest = opts.includeTestScope === true;

  const resolved = new Map(); // group:artifact -> { version, direct, depth, path }
  const unresolved = [];      // dependencies whose version could not be determined
  const fetchFailures = [];
  let truncated = false;

  // Walks the parent chain, merging properties and dependencyManagement from
  // the top down so a child's own entries win.
  async function withInheritance(pom, seen = new Set()) {
    let properties = { ...pom.properties };
    let management = [...pom.dependencyManagement];

    // A child module almost never repeats its parent's <licenses>; Maven treats
    // them as inherited. The NEAREST declaration in the chain governs, and it is
    // taken while walking rather than from wherever the walk ended up.
    //
    // Reading only the far end of the chain is what made Netty — and every other
    // artifact whose licence lives one level up — report as unlicensed:
    // netty-codec-http declares nothing, netty-parent declares Apache-2.0, and
    // netty-parent's own parent (org.sonatype.oss:oss-parent) declares nothing.
    // The empty grandparent was the one being read.
    let licenses = pom.licenses;

    let current = pom;
    let depth = 0;
    while (current.parent && depth < maxDepth) {
      const key = `${current.parent.groupId}:${current.parent.artifactId}:${current.parent.version}`;
      if (seen.has(key)) break; // malformed POM with a parent cycle
      seen.add(key);

      const xml = await fetchPom(current.parent.groupId, current.parent.artifactId, current.parent.version);
      if (!xml) {
        fetchFailures.push(key);
        break;
      }
      const parentPom = parsePom(xml);
      // Parent values are defaults: the child's own entries take precedence.
      properties = { ...parentPom.properties, ...properties };
      management = [...parentPom.dependencyManagement, ...management];
      if (!licenses.length) licenses = parentPom.licenses;
      current = parentPom;
      depth += 1;
    }

    // Maven's built-in properties, which real POMs use constantly.
    properties['project.version'] = properties['project.version'] || pom.version;
    properties['project.groupId'] = properties['project.groupId'] || pom.groupId;
    properties['pom.version'] = properties['pom.version'] || pom.version;

    return { properties, management, licenses };
  }

  // dependencyManagement entries with <scope>import</scope> pull in another
  // POM's management section. This is how Spring Boot pins versions, so without
  // it most dependencies in a Spring project have no version to resolve.
  async function expandImports(management, properties, depth = 0) {
    if (depth > 3) return management;
    const out = [];

    for (const entry of management) {
      if (entry.scope !== 'import') {
        out.push(entry);
        continue;
      }
      const version = expand(entry.version, properties);
      const xml = await fetchPom(entry.groupId, entry.artifactId, version);
      if (!xml) {
        fetchFailures.push(`${entry.groupId}:${entry.artifactId}:${version} (BOM)`);
        continue;
      }
      const bom = parsePom(xml);
      const inherited = await withInheritance(bom);
      const bomProps = { ...inherited.properties, ...properties };
      // Imported entries rank below the importing POM's own, which is why they
      // are appended rather than prepended.
      out.push(...(await expandImports(inherited.management, bomProps, depth + 1)));
    }

    return out;
  }

  function managedVersion(management, groupId, artifactId, properties) {
    const hit = management.find(m => m.groupId === groupId && m.artifactId === artifactId);
    return hit ? expand(hit.version, properties) : null;
  }

  const rootPom = parsePom(rootXml);
  const rootInherited = await withInheritance(rootPom);
  const rootManagement = await expandImports(rootInherited.management, rootInherited.properties);

  // Breadth-first, so the shallowest occurrence of an artifact is seen first —
  // which is precisely Maven's "nearest wins" rule.
  let frontier = rootPom.dependencies.map(d => ({
    dep: d,
    depth: 0,
    properties: rootInherited.properties,
    management: rootManagement,
    excluded: new Set(),
    path: [],
  }));

  while (frontier.length) {
    if (resolved.size >= maxArtifacts) {
      truncated = true;
      break;
    }
    const next = [];

    for (const item of frontier) {
      // Checked per artifact, not only between levels. One level of a wide
      // graph can contain hundreds of dependencies, so a level-only check
      // sails past the cap by an entire tier.
      if (resolved.size >= maxArtifacts) {
        truncated = true;
        break;
      }
      const { dep, depth, properties, management, excluded, path } = item;

      const groupId = expand(dep.groupId, properties);
      const artifactId = expand(dep.artifactId, properties);
      const key = coordKey(groupId, artifactId);

      if (excluded.has(key)) continue;
      // Nearest wins: an artifact already resolved at a shallower depth keeps
      // the version it was given.
      if (resolved.has(key)) continue;

      const scope = dep.scope || 'compile';
      if (!includeTest && (scope === 'test' || scope === 'provided') && depth > 0) continue;
      if (dep.optional && depth > 0) continue;

      const version = expand(dep.version, properties) || managedVersion(management, groupId, artifactId, properties);

      if (!version || version.includes('${') || /[\[\](),]/.test(version)) {
        // No version, an unexpanded property, or a range. Recorded rather than
        // guessed: querying OSV with a wrong version returns a confident,
        // wrong answer.
        unresolved.push({ groupId, artifactId, declared: dep.version || null, reason: version ? 'unresolvable version' : 'no version' });
        continue;
      }

      resolved.set(key, {
        ecosystem: 'Maven',
        name: key,
        version,
        direct: depth === 0,
        scope,
        depth,
        path: path.join(' > ') || null,
        // Filled in below from the artifact's own POM, which is fetched anyway
        // to walk its dependencies.
        licenses: [],
        // Whether that POM was actually retrieved. null means it was never
        // asked for — the walk stopped at this artifact, so nothing was learned
        // either way. False means the repository did not have it, which is a
        // different fact from "the POM declares no licence" and has a different
        // remedy: an artifact from a private Nexus is unreadable here, not
        // unlicensed.
        pomAvailable: null,
      });

      if (depth >= maxDepth) continue;
      // Only compile and runtime propagate, per Maven.
      if (depth > 0 && !TRANSITIVE_SCOPES.has(scope)) continue;

      const xml = await fetchPom(groupId, artifactId, version);
      if (!xml) {
        fetchFailures.push(`${key}:${version}`);
        resolved.get(key).pomAvailable = false;
        continue;
      }
      resolved.get(key).pomAvailable = true;

      const childPom = parsePom(xml);
      const childInherited = await withInheritance(childPom);
      // The POM we just fetched to find children also carries the licence.
      resolved.get(key).licenses = childInherited.licenses || childPom.licenses || [];
      const childManagement = await expandImports(childInherited.management, childInherited.properties);
      const childExcluded = new Set([...excluded, ...dep.exclusions]);

      for (const child of childPom.dependencies) {
        const childScope = child.scope || 'compile';
        if (childScope === 'test' || childScope === 'provided' || child.optional) continue;
        next.push({
          dep: child,
          depth: depth + 1,
          properties: { ...childInherited.properties },
          // The importing project's management still wins over the child's.
          management: [...management, ...childManagement],
          excluded: childExcluded,
          path: [...path, key],
        });
      }
    }

    frontier = next;
  }

  return {
    dependencies: [...resolved.values()],
    unresolved,
    fetchFailures,
    truncated,
    // Carried so a truncation can name its own limit. "Hit a limit" without
    // saying which one leaves a reader with nothing to act on.
    limit: maxArtifacts,
    resolvedCount: resolved.size,
    root: { groupId: rootPom.groupId, artifactId: rootPom.artifactId, version: rootPom.version },
    modules: rootPom.modules,
  };
}

module.exports = {
  parsePom,
  resolve,
  expand,
  DEFAULT_REPOSITORY,
  MAX_DEPTH,
  MAX_ARTIFACTS,
  TRANSITIVE_SCOPES,
};
