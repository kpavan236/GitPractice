'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createOrchestrator } = require('./orchestrator');
const { scanner: patternScanner } = require('./scanners/pattern-sast');
const { createOverrides } = require('./overrides');
const { supportFromFlags } = require('./engine-loader/run');
const { installedLoader, offlineLoader, FAKE_CORE, tmpDir } = require('./test-support/loader');

const OPEN = { OASIS_ALLOW_OPEN_NETWORK_ENGINE: '1' };
const REAL_FLAG = supportFromFlags(process.allowedNodeEnvironmentFlags).flag;
const GO_RULES = [
  { id: 'go-insecure-skip-verify', language: 'go', severity: 'HIGH', query: 'q' },
  { id: 'go-other', language: 'go', severity: 'LOW', query: 'q' },
];
const release = (n = 1) => ({ release: n, core: FAKE_CORE, languages: {
  go: { extensions: ['.go'], rules: GO_RULES, grammar: 'WASM-GO' },
  python: { extensions: ['.py'], rules: [{ id: 'py-eval', language: 'python', severity: 'HIGH', query: 'q' }], grammar: 'WASM-PY' },
} });

const repo = (t, files) => {
  const d = tmpDir(t, 'oasis-eng-repo-');
  for (const f of files) fs.writeFileSync(path.join(d, f), 'package main\n');
  return d;
};
async function finish(o, id) {
  for (let i = 0; i < 400; i += 1) {
    const s = o.getScan(id);
    if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(s.status)) return s;
    await new Promise((r) => setTimeout(r, 25));
  }
  throw new Error('scan did not finish');
}
const orch = (t, over) => {
  const o = createOrchestrator({ scanners: [patternScanner], dir: tmpDir(t, 'oasis-eng-store-'), userRulesDir: null, userGrammarsDir: null, env: OPEN, ...over });
  t.after(() => o.shutdown());
  return o;
};

test('a scan runs the installed rules for the repository\'s languages only, and the findings are readable locally with no rule server configured', async (t) => {
  delete process.env.OASIS_RULE_SERVER_URL;
  const loader = await installedLoader(t, release());
  const o = orch(t, { loader });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go', 'util.go']) }] });
  const done = await finish(o, scan.id);
  assert.equal(done.status, 'COMPLETED', done.error || JSON.stringify(done.perRepository));
  const findings = await o.listFindings({ repository: 'org/go' });
  assert.deepEqual(findings.flatMap((f) => f.detections.map((d) => d.ruleId)).sort(), ['go-insecure-skip-verify', 'go-other']);
  assert.equal(findings[0].metadata.ruleSetVersion, 'release-1');
  assert.deepEqual(done.ruleSets.map((r) => [r.repository, r.version, r.source]), [['org/go', 'release-1', 'rules-service']]);
  // the language packs' grammars reached the engine's src/ast/grammars
  assert.deepEqual(findings[0].metadata.wasm.sort(), ['tree-sitter-go.wasm', 'tree-sitter-python.wasm']);
});

test('a per-project override disables a rule and re-grades another', async (t) => {
  const loader = await installedLoader(t, release());
  const overrides = createOverrides({ file: path.join(tmpDir(t), 'o.json') });
  overrides.set('org/go', { disabled: ['go-insecure-skip-verify'], severity: { 'go-other': 'CRITICAL' } });
  const o = orch(t, { loader, overrides });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] });
  assert.equal((await finish(o, scan.id)).status, 'COMPLETED');
  const findings = await o.listFindings({ repository: 'org/go' });
  assert.deepEqual(findings.map((f) => [f.detections[0].ruleId, f.severity]), [['go-other', 'CRITICAL']]);
});

test('with nothing installed and the service unreachable, startScan is refused with NO_RULES before any scan exists', async (t) => {
  const o = orch(t, { loader: offlineLoader(t) });
  await assert.rejects(o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] }),
    (e) => e.code === 'NO_RULES' && /No rules installed and the rules service is unreachable/.test(e.message));
});

test('first scan with nothing installed asks the service once and uses what it gets', async (t) => {
  const real = await installedLoader(t, release());
  let calls = 0;
  const lazy = { ...real, current: () => (calls ? real.current() : null), update: async () => { calls += 1; return { status: 'updated', release: 1 }; },
    rulesFor: (l) => real.rulesFor(l), corePath: () => real.corePath() };
  const o = orch(t, { loader: lazy });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] });
  assert.equal((await finish(o, scan.id)).status, 'COMPLETED');
  assert.equal(calls, 1);
});

test('where the Node cannot deny network and the opt-in is absent, the scan fails naming the env var and the Node', async (t) => {
  const loader = await installedLoader(t, release());
  const o = orch(t, { loader, env: {}, engineOptions: { permissionSupport: { flag: REAL_FLAG, netDenial: false } } });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] });
  const done = await finish(o, scan.id);
  assert.equal(done.status, 'FAILED');
  assert.match(done.error, /OASIS_ALLOW_OPEN_NETWORK_ENGINE=1/);
  assert.match(done.error, /Node/);
  assert.deepEqual(await o.listFindings({ repository: 'org/go' }), []);
});

test('a release with no core pack fails the scan with the NoRulesError message, not as failed scanners', async (t) => {
  const real = await installedLoader(t, release());
  const noCore = { ...real, current: () => { const c = real.current(); const { core, ...packDirs } = c.packDirs; return { ...c, packDirs }; }, corePath: () => null };
  const o = orch(t, { loader: noCore });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] });
  const done = await finish(o, scan.id);
  assert.equal(done.status, 'FAILED');
  assert.match(done.error, /No rules installed and the rules service is unreachable/);
});

test('a release change mid-scan does not mix versions: the rule set and the engine copy come from one resolved release', async (t) => {
  const real = await installedLoader(t, release(1));
  let n = 100;
  // every call to current() answers a different release number, as if an update landed between the calls
  const moving = { ...real, current: () => ({ ...real.current(), release: (n += 1) }) };
  const dir = tmpDir(t, 'oasis-eng-store-');
  const o = orch(t, { loader: moving, dir });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']) }] });
  const done = await finish(o, scan.id);
  assert.equal(done.status, 'COMPLETED', done.error || '');
  const used = done.ruleSets[0].version;
  assert.deepEqual(fs.readdirSync(path.join(dir, 'engine-work')), [used]);
});

test('OASIS_ENGINE=bundled keeps the old worker path even when a loader is configured', async (t) => {
  const loader = await installedLoader(t, release());
  const { testRuleSet } = require('./test-support/rules');
  const o = orch(t, { loader, env: { OASIS_ENGINE: 'bundled' } });
  const scan = await o.startScan({ targets: [{ repository: 'org/go', repoPath: repo(t, ['main.go']), ruleSet: testRuleSet() }] });
  const done = await finish(o, scan.id);
  assert.equal(done.status, 'COMPLETED', done.error || '');
  assert.deepEqual(done.ruleSets, []);
  const findings = await o.listFindings({ repository: 'org/go' });
  assert.ok(!findings.some((f) => f.metadata && f.metadata.ruleSetVersion), 'the installed engine must not have run');
  });
