'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createOrchestrator } = require('./orchestrator');
const store = require('./store');

// Clearing is destructive and irreversible, so these tests are mostly about
// what must SURVIVE it. Deleting findings is cheap — a rescan brings them back.
// Deleting the triage on them, or the trend, is not.

function finding(over = {}) {
  return {
    id: over.id || 'F-1',
    fingerprint: over.id || 'fp1',
    type: 'SAST',
    category: 'X',
    severity: 'HIGH',
    status: 'OPEN',
    repository: 'api',
    file: 'A.java',
    startLine: 1,
    detections: [{ source: 'AST_SAST', ruleId: 'r', detectedAt: 1 }],
    metadata: {},
    ...over,
  };
}

function seeded(data = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-clear-'));
  fs.mkdirSync(path.join(dir, 'sbom'), { recursive: true });
  fs.writeFileSync(
    path.join(dir, 'store.json'),
    JSON.stringify({
      version: 1,
      findings: [],
      scans: [],
      assets: {},
      sboms: [],
      history: [],
      baseline: null,
      ...data,
    })
  );
  return dir;
}

function orch(dir) {
  return createOrchestrator({ scanners: [], dir, log: () => {} });
}

const SEED = {
  findings: [
    finding({ id: 'a', repository: 'api' }),
    finding({ id: 'b', repository: 'api', status: 'SUPPRESSED', suppression: { reason: 'accepted risk' } }),
    finding({ id: 'c', repository: 'api', status: 'FALSE_POSITIVE', suppression: { reason: 'not reachable' } }),
    finding({ id: 'd', repository: 'web' }),
  ],
  scans: [
    { id: 'S1', repositories: ['api'], status: 'COMPLETED' },
    { id: 'S2', repositories: ['api', 'web'], status: 'COMPLETED' },
  ],
  sboms: [{ repository: 'api', path: 'x' }, { repository: 'web', path: 'y' }],
  history: [{ at: 1, total: 4 }, { at: 2, total: 4 }],
  assets: { api: { criticality: 'CRITICAL', internetFacing: true } },
  baseline: { createdAt: 1, fingerprints: ['a'] },
};

test('the preview says what would go, without touching anything', async () => {
  const dir = seeded(SEED);
  const preview = await orch(dir).clearPreview({});

  assert.equal(preview.findings, 4);
  assert.equal(preview.suppressed, 2);
  assert.equal(preview.scans, 2);
  assert.equal(store.load(dir).findings.length, 4, 'preview must not delete anything');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the preview scopes to one repository', async () => {
  const dir = seeded(SEED);
  const preview = await orch(dir).clearPreview({ repository: 'web' });
  assert.equal(preview.findings, 1);
  assert.equal(preview.suppressed, 0);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── What must survive ──────────────────────────────────────────────────────

test('triage decisions are kept by DEFAULT', async () => {
  // The one that matters. Suppressions are human judgements with reasons; a
  // clear that discards them means the next scan resurrects issues somebody
  // already decided about, and they have to decide again.
  const dir = seeded(SEED);
  await orch(dir).clearFindings({});

  const left = store.load(dir).findings;
  assert.deepEqual(left.map(f => f.id).sort(), ['b', 'c']);
  assert.equal(left.every(f => f.suppression), true, 'the reason must survive too');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('repository settings are never cleared — they are configuration', async () => {
  // Criticality drives risk scoring. Silently resetting it would change every
  // future score with no visible cause.
  const dir = seeded(SEED);
  await orch(dir).clearFindings({});
  assert.deepEqual(store.load(dir).assets.api, { criticality: 'CRITICAL', internetFacing: true });

  await orch(dir).resetSecurity();
  assert.deepEqual(store.load(dir).assets.api, { criticality: 'CRITICAL', internetFacing: true },
    'not even a full reset touches configuration');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing findings keeps the trend history', async () => {
  // You cannot rescan last month. Only the explicit reset takes this.
  const dir = seeded(SEED);
  await orch(dir).clearFindings({});
  assert.equal(store.load(dir).history.length, 2);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── What goes ──────────────────────────────────────────────────────────────

test('opting out removes triage decisions too', async () => {
  const dir = seeded(SEED);
  const removed = await orch(dir).clearFindings({ keepSuppressed: false });

  assert.deepEqual(store.load(dir).findings, []);
  assert.equal(removed.keptSuppressed, 0);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing one repository leaves the others alone', async () => {
  const dir = seeded(SEED);
  await orch(dir).clearFindings({ repository: 'web' });

  const left = store.load(dir).findings.map(f => f.id).sort();
  assert.deepEqual(left, ['a', 'b', 'c'], 'api is untouched');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a scan covering several repositories survives a single-repository clear', async () => {
  // It is still an accurate record of the others. Only a scan that covered
  // ONLY the cleared repository describes nothing afterwards.
  const dir = seeded(SEED);
  await orch(dir).clearFindings({ repository: 'api' });

  assert.deepEqual(store.load(dir).scans.map(s => s.id), ['S2']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a full reset empties everything a scan can rebuild, and the trend', async () => {
  const dir = seeded(SEED);
  await orch(dir).resetSecurity();

  const data = store.load(dir);
  assert.deepEqual(data.findings, []);
  assert.deepEqual(data.scans, []);
  assert.deepEqual(data.sboms, []);
  assert.deepEqual(data.history, []);
  assert.equal(data.baseline, null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the SBOM file on disk is deleted, not just its index entry', async () => {
  // Otherwise a cleared repository leaves megabytes of orphaned JSON that
  // nothing will ever read or clean up.
  const dir = seeded(SEED);
  store.saveSbom({ bomFormat: 'CycloneDX' }, 'api', dir);
  assert.ok(fs.existsSync(store.sbomPath(dir, 'api')));

  await orch(dir).clearFindings({ repository: 'api' });
  assert.equal(fs.existsSync(store.sbomPath(dir, 'api')), false);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the result reports what was actually removed', async () => {
  const dir = seeded(SEED);
  const removed = await orch(dir).clearFindings({});
  // Four findings, two of them kept — so two were deleted.
  assert.equal(removed.findings, 2);
  assert.equal(removed.keptSuppressed, 2);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing an empty store is safe', async () => {
  const dir = seeded({});
  await orch(dir).clearFindings({});
  await orch(dir).resetSecurity();
  assert.deepEqual(store.load(dir).findings, []);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing a repository that does not exist changes nothing', async () => {
  const dir = seeded(SEED);
  await orch(dir).clearFindings({ repository: 'never-scanned' });
  assert.equal(store.load(dir).findings.length, 4);
  fs.rmSync(dir, { recursive: true, force: true });
});
