'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { fromSarif, typeForTool, severityFor, fileFor, cweFrom } = require('./sarif-ingest');
const { toSarif } = require('./sarif');

const REPO = path.join('/', 'tmp', 'repo');

function sarif({ tool = 'Trivy', rules = [], results = [], properties = undefined } = {}) {
  return {
    version: '2.1.0',
    runs: [{ tool: { driver: { name: tool, version: '1.0.0', rules } }, results, properties }],
  };
}

test('imports a result into a finding', () => {
  const document = sarif({
    tool: 'Checkov',
    rules: [
      {
        id: 'CKV_AWS_20',
        name: 'S3BucketPublicRead',
        shortDescription: { text: 'S3 bucket is public' },
        fullDescription: { text: 'The bucket allows public read access.' },
        help: { text: 'Set acl to private.' },
        properties: { tags: ['external/cwe/cwe-732'], 'security-severity': '7.5' },
      },
    ],
    results: [
      {
        ruleId: 'CKV_AWS_20',
        level: 'error',
        message: { text: 'Ensure the S3 bucket is not public' },
        locations: [{ physicalLocation: { artifactLocation: { uri: 'infra/s3.tf' }, region: { startLine: 12 } } }],
      },
    ],
  });

  const [finding] = fromSarif(document, { repository: 'repo', repoPath: REPO });
  assert.equal(finding.type, 'IAC');
  assert.equal(finding.severity, 'HIGH');
  assert.equal(finding.cwe, 'CWE-732');
  assert.equal(finding.file, 'infra/s3.tf');
  assert.equal(finding.startLine, 12);
  assert.equal(finding.detections[0].source, 'CHECKOV');
  assert.equal(finding.detections[0].ruleId, 'CKV_AWS_20');
  assert.equal(finding.remediation, 'Set acl to private.');
});

test('infers the finding type from the producing tool', () => {
  assert.equal(typeForTool('Trivy Vulnerability Scanner'), 'CONTAINER');
  assert.equal(typeForTool('checkov'), 'IAC');
  assert.equal(typeForTool('OWASP ZAP'), 'DAST');
  assert.equal(typeForTool('Prowler'), 'CLOUD');
  assert.equal(typeForTool('SonarQube'), 'QUALITY');
  // An unknown tool is SAST rather than dropped: a finding filed under the
  // wrong heading is recoverable, a finding thrown away is not.
  assert.equal(typeForTool('SomeInternalTool'), 'SAST');
});

test('a run can declare its own type for an unrecognised tool', () => {
  const document = sarif({
    tool: 'AcmeScanner',
    properties: { oasisType: 'CONTAINER' },
    results: [{ ruleId: 'A1', message: { text: 'x' } }],
  });
  assert.equal(fromSarif(document, { repository: 'repo' })[0].type, 'CONTAINER');
});

test('security-severity beats the SARIF level', () => {
  // SARIF collapses CRITICAL and HIGH into `error`. Reading the numeric
  // property is what stops every imported scanner's worst findings flattening
  // into one band.
  assert.equal(severityFor({}, { level: 'error', properties: { 'security-severity': '9.6' } }), 'CRITICAL');
  assert.equal(severityFor({}, { level: 'error' }), 'HIGH');
  assert.equal(severityFor({}, { level: 'note' }), 'LOW');
  assert.equal(severityFor({ defaultConfiguration: { level: 'warning' } }, {}), 'MEDIUM');
});

test('resolves a rule referenced by index', () => {
  const document = sarif({
    rules: [{ id: 'R0', shortDescription: { text: 'First' } }, { id: 'R1', shortDescription: { text: 'Second' } }],
    results: [{ ruleIndex: 1, message: { text: 'hit' }, level: 'warning' }],
  });
  assert.equal(fromSarif(document, { repository: 'repo' })[0].title, 'Second');
});

test('normalises paths without ever using them to open a file', () => {
  assert.equal(fileFor({ locations: [{ physicalLocation: { artifactLocation: { uri: 'file:///tmp/repo/a.js' } } }] }, REPO), 'a.js');
  assert.equal(fileFor({ locations: [{ physicalLocation: { artifactLocation: { uri: './src/a.js' } } }] }, REPO), 'src/a.js');
  assert.equal(fileFor({ locations: [{ physicalLocation: { artifactLocation: { uri: 'src%2Fa.js' } } }] }, REPO), 'src/a.js');
  // Outside the repository: left absolute rather than rendered as a run of
  // `../`, which would read as if the finding were somewhere it is not.
  assert.equal(fileFor({ locations: [{ physicalLocation: { artifactLocation: { uri: '/etc/passwd' } } }] }, REPO), '/etc/passwd');
  assert.equal(fileFor({ locations: [] }, REPO), null);
});

test('extracts CWE and CVE from wherever the tool put them', () => {
  assert.equal(cweFrom({ properties: { tags: ['external/cwe/cwe-89'] } }, {}), 'CWE-89');
  assert.equal(cweFrom({ properties: { cwe: 'CWE-79: XSS' } }, {}), 'CWE-79');
  assert.equal(cweFrom({}, {}), null);

  const document = sarif({
    tool: 'Trivy',
    results: [{ ruleId: 'CVE-2021-44228', message: { text: 'log4j' }, level: 'error' }],
  });
  assert.equal(fromSarif(document, { repository: 'repo' })[0].cve, 'CVE-2021-44228');
});

test('records upstream suppression without acting on it', () => {
  // Suppression here is a decision with an owner and a reason. Importing one
  // silently would let another tool close findings in this app.
  const document = sarif({
    results: [{ ruleId: 'R', message: { text: 'x' }, suppressions: [{ kind: 'inSource' }] }],
  });
  const [finding] = fromSarif(document, { repository: 'repo' });
  assert.equal(finding.metadata.suppressedUpstream, true);
  assert.equal(finding.status, 'OPEN');
});

test('refuses to crash on anything that is not SARIF', () => {
  assert.deepEqual(fromSarif(null, { repository: 'repo' }), []);
  assert.deepEqual(fromSarif({}, { repository: 'repo' }), []);
  assert.deepEqual(fromSarif({ runs: 'nope' }, { repository: 'repo' }), []);
  assert.deepEqual(fromSarif({ runs: [null, { results: null }] }, { repository: 'repo' }), []);
  assert.deepEqual(fromSarif({ runs: [{ results: [null] }] }, { repository: 'repo' }), []);
});

test('a finding survives an export/import round trip', () => {
  // sarif.js and sarif-ingest.js are two halves of one boundary. If they drift,
  // findings this app exports stop being findings it can read back.
  const original = {
    type: 'SAST',
    category: 'SQL_INJECTION',
    severity: 'CRITICAL',
    title: 'SQL query built from external input',
    description: 'A SQL statement is executed with attacker-controlled input.',
    repository: 'repo',
    file: 'src/Dao.java',
    startLine: 42,
    endLine: 42,
    cwe: 'CWE-89',
    cve: null,
    status: 'OPEN',
    fingerprint: 'abc123',
    detections: [{ source: 'AST_SAST', ruleId: 'java-sql-injection', detectedAt: 1 }],
    remediation: 'Use a parameterised query.',
    evidence: null,
    risk: { score: 90, priority: 'P1', confidence: 'HIGH' },
    metadata: { confidence: 'HIGH' },
  };

  const [restored] = fromSarif(toSarif([original], { repository: 'repo' }), { repository: 'repo' });
  assert.equal(restored.severity, 'CRITICAL');
  assert.equal(restored.cwe, 'CWE-89');
  assert.equal(restored.file, 'src/Dao.java');
  assert.equal(restored.startLine, 42);
  assert.equal(restored.detections[0].ruleId, 'java-sql-injection');
  assert.equal(restored.metadata.upstreamFingerprint, 'abc123');
});
