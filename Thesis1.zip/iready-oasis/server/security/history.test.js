'use strict';
// The trend series: counts over time, so the dashboard can answer "is this
// getting better" and not only "how bad is it now".
const test = require('node:test');
const assert = require('node:assert/strict');
const { recordHistory, MAX_HISTORY_POINTS } = require('./store');

const point = (at, total) => ({ at, total, counts: { CRITICAL: total }, byType: {}, repositories: 1 });

test('history appends in order', () => {
  const h = recordHistory(recordHistory([], point(1, 5)), point(2, 3));
  assert.deepEqual(h.map(p => p.total), [5, 3]);
});

test('history is capped at the oldest end', () => {
  let h = [];
  for (let i = 0; i < MAX_HISTORY_POINTS + 20; i++) h = recordHistory(h, point(i, i));
  assert.equal(h.length, MAX_HISTORY_POINTS);
  assert.equal(h[h.length - 1].total, MAX_HISTORY_POINTS + 19);
});

test('an undefined history starts a new series', () => {
  assert.equal(recordHistory(undefined, point(1, 1)).length, 1);
});
