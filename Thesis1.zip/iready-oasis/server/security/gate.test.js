'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { evaluateGate, loadGate, saveGate, DEFAULT_GATE, GATE_FILENAME } = require('./gate');
const storeModule = require('./store');

// A gate blocks builds, so the property that matters is not "does it pass the
// happy case" but "does it ever say PASSED when it should not". Most of these
// tests are about that direction.

function finding(over = {}) {
  return {
    type: 'SAST',
    severity: 'HIGH',
    status: 'OPEN',
    isNewCode: false,
    risk: { score: 40 },
    ...over,
  };
}

const CLEAN_COVERAGE = [
  { type: 'SAST', analysed: true },
  { type: 'SECRET', analysed: true },
];

test('a clean scan passes', () => {
  const result = evaluateGate({ findings: [], coverage: CLEAN_COVERAGE });
  assert.equal(result.status, 'PASSED');
  assert.equal(result.blocking, false);
});

test('a new critical fails the build', () => {
  const result = evaluateGate({
    findings: [finding({ severity: 'CRITICAL', isNewCode: true })],
    coverage: CLEAN_COVERAGE,
  });
  assert.equal(result.status, 'FAILED');
  assert.equal(result.blocking, true);
  assert.match(result.reason, /critical_issues/);
});

test('an OLD critical does not fail the default gate', () => {
  // The whole Clean as You Code argument. A repository with a backlog must be
  // able to go green on a change that adds nothing, or the gate gets switched
  // off within a week and stops protecting anything.
  const result = evaluateGate({
    findings: [finding({ severity: 'CRITICAL', isNewCode: false })],
    coverage: CLEAN_COVERAGE,
  });
  assert.equal(result.status, 'PASSED');
});

test('a single new secret fails, because there is no acceptable number', () => {
  const result = evaluateGate({
    findings: [finding({ type: 'SECRET', severity: 'HIGH', isNewCode: true })],
    coverage: CLEAN_COVERAGE,
  });
  assert.equal(result.blocking, true);
  assert.match(result.reason, /secrets/);
});

test('a suppressed finding does not fail the gate', () => {
  // Triage has to mean something. If a suppressed finding still blocks, the
  // suppression feature is decorative.
  const result = evaluateGate({
    findings: [finding({ severity: 'CRITICAL', isNewCode: true, status: 'SUPPRESSED' })],
    coverage: CLEAN_COVERAGE,
  });
  assert.equal(result.status, 'PASSED');
});

// ── Failing closed ─────────────────────────────────────────────────────────

test('a NEW_CODE condition without a diff is NOT reported as passed', () => {
  // The failure that would matter most in practice: CI clones shallow by
  // default, so if "no diff" meant "nothing new", the gate would silently
  // disable itself in exactly the environment it exists for.
  const result = evaluateGate({
    findings: [finding({ severity: 'CRITICAL', isNewCode: false })],
    coverage: CLEAN_COVERAGE,
    newCodeAvailable: false,
  });
  assert.equal(result.status, 'FAILED');
  assert.equal(result.blocking, true);
  assert.ok(result.conditions.some(c => c.status === 'NOT_EVALUATED'));
  assert.match(result.reason, /no diff available/);
});

test('an unreadable gate file blocks rather than falling back', () => {
  // Someone edited the gate and got it wrong. Quietly running different
  // thresholds than the ones in the file is how a build passes for reasons
  // nobody can reconstruct afterwards.
  const result = evaluateGate({ findings: [], gateError: 'unreadable: bad indentation' });
  assert.equal(result.status, 'NOT_EVALUATED');
  assert.equal(result.blocking, true);
});

test('a coverage gap warns without blocking', () => {
  // A scan that never checked SAST and found nothing is not a pass — but it is
  // also not a reason to fail every build in a repository with no containers.
  const result = evaluateGate({
    findings: [],
    coverage: [{ type: 'SAST', analysed: true }, { type: 'DAST', analysed: false }],
  });
  assert.equal(result.status, 'WARN');
  assert.equal(result.blocking, false, 'a warning that fails the build is an error wearing another word');
});

// ── Conditions and metrics ─────────────────────────────────────────────────

test('every condition is reported with its actual value', () => {
  // A red build that cannot say which threshold it crossed is a red build
  // people override.
  const result = evaluateGate({ findings: [], coverage: CLEAN_COVERAGE });
  assert.equal(result.conditions.length, DEFAULT_GATE.conditions.length);
  for (const c of result.conditions) {
    assert.equal(typeof c.actual, 'number');
    assert.ok(c.explanation.length > 10);
  }
});

test('an OVERALL condition counts the backlog too', () => {
  const gate = { name: 'strict', conditions: [{ metric: 'critical_issues', scope: 'OVERALL', operator: 'GT', threshold: 0 }] };
  const findings = [finding({ severity: 'CRITICAL', isNewCode: false })];
  assert.equal(evaluateGate({ findings, gate }).status, 'FAILED');
});

test('a severity-scoped condition counts only that severity', () => {
  const gate = {
    name: 'x',
    conditions: [{ metric: 'vulnerabilities', scope: 'OVERALL', operator: 'GT', threshold: 0, severity: 'CRITICAL' }],
  };
  assert.equal(evaluateGate({ findings: [finding({ severity: 'HIGH' })], gate }).status, 'PASSED');
  assert.equal(evaluateGate({ findings: [finding({ severity: 'CRITICAL' })], gate }).status, 'FAILED');
});

test('risk_score takes the worst, not the sum', () => {
  // A sum lets fifty trivial findings outweigh one exploited CVE.
  const gate = { name: 'x', conditions: [{ metric: 'risk_score', scope: 'OVERALL', operator: 'GT', threshold: 80 }] };
  const many = Array.from({ length: 50 }, () => finding({ risk: { score: 10 } }));
  assert.equal(evaluateGate({ findings: many, gate }).status, 'PASSED');
  assert.equal(evaluateGate({ findings: [finding({ risk: { score: 95 } })], gate }).status, 'FAILED');
});

test('high_severity_cves counts SCA findings only', () => {
  const gate = { name: 'x', conditions: [{ metric: 'high_severity_cves', scope: 'OVERALL', operator: 'GT', threshold: 0 }] };
  assert.equal(evaluateGate({ findings: [finding({ type: 'SAST', severity: 'CRITICAL' })], gate }).status, 'PASSED');
  assert.equal(evaluateGate({ findings: [finding({ type: 'SCA', severity: 'HIGH' })], gate }).status, 'FAILED');
});

// ── Loading a gate from a repository ───────────────────────────────────────

function repoWith(contents) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-gate-'));
  if (contents !== null) fs.writeFileSync(path.join(dir, GATE_FILENAME), contents);
  return dir;
}

test('a repository with no gate file gets the default', () => {
  const dir = repoWith(null);
  const { gate, source, error } = loadGate(dir);
  assert.equal(error, null);
  assert.equal(source, 'default');
  assert.equal(gate.name, 'default');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a repository gate overrides the default', () => {
  const dir = repoWith(`
name: strict
conditions:
  - metric: blocker_issues
    scope: OVERALL
    operator: GT
    threshold: 5
`);
  const { gate, error } = loadGate(dir);
  assert.equal(error, null);
  assert.equal(gate.name, 'strict');
  assert.equal(gate.conditions.length, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a gate naming an unknown metric is rejected, not ignored', () => {
  const dir = repoWith('conditions:\n  - metric: vibes\n    operator: GT\n    threshold: 1\n');
  const { gate, error } = loadGate(dir);
  assert.equal(gate, null);
  assert.match(error, /unknown metric/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a gate with a non-numeric threshold is rejected', () => {
  const dir = repoWith('conditions:\n  - metric: secrets\n    operator: GT\n    threshold: "none"\n');
  assert.match(loadGate(dir).error, /threshold must be a number/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('an empty gate file is rejected rather than passing everything', () => {
  const dir = repoWith('name: empty\nconditions: []\n');
  const { gate, error } = loadGate(dir);
  assert.equal(gate, null);
  assert.match(error, /no conditions/);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Store-backed gate loading ───────────────────────────────────────────────

test('loadGate prefers store config over YAML file', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const storeGate = { name: 'store-gate', conditions: [{ metric: 'secrets', operator: 'GT', threshold: 0, scope: 'NEW_CODE' }] };
  await storeModule.saveGateConfig('org/repo', storeGate, dir);
  // Also write a YAML file that should be ignored
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  fs.writeFileSync(path.join(repoPath, '.oasis-security-gate.yml'), 'conditions:\n  - metric: secrets\n    operator: GT\n    threshold: 99\n    scope: NEW_CODE\n');
  const { gate, source } = loadGate(repoPath, { repository: 'org/repo', dir });
  assert.equal(source, 'settings');
  assert.equal(gate.conditions[0].threshold, 0);
});

test('loadGate falls back to YAML when no store entry', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  fs.writeFileSync(path.join(repoPath, '.oasis-security-gate.yml'), 'conditions:\n  - metric: secrets\n    operator: GT\n    threshold: 5\n    scope: NEW_CODE\n');
  const { gate, source } = loadGate(repoPath, { repository: 'org/repo', dir });
  assert.equal(source, '.oasis-security-gate.yml');
  assert.equal(gate.conditions[0].threshold, 5);
});

test('saveGate + loadGate round-trip through store', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  const g = { name: 'test', conditions: [{ metric: 'vulnerabilities', operator: 'GT', threshold: 0, scope: 'NEW_CODE' }] };
  await saveGate('org/repo', g, { dir });
  const { gate, source } = loadGate(repoPath, { repository: 'org/repo', dir });
  assert.equal(source, 'settings');
  assert.equal(gate.name, 'test');
});
