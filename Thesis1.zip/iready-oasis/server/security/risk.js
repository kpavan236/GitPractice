'use strict';

// The risk engine.
//
// CVSS is not the score. CVSS describes a vulnerability in the abstract; it
// knows nothing about whether this repository is in production, whether the
// flagged code is reachable, or whether the package is even used. A CVSS 9.8 in
// a dev-only tool and a CVSS 6.5 on an internet-facing service holding personal
// data are not the same problem, and a queue sorted by CVSS puts them in the
// wrong order.
//
// Two rules govern everything below.
//
// EVERY POINT IS ATTRIBUTABLE. The result carries the factor list that produced
// it, each with its own contribution, so a developer asked to drop what they
// are doing can see why. A number nobody can interrogate gets ignored the first
// time it is wrong.
//
// UNKNOWN IS NOT ZERO-RISK, AND IT IS NOT RISK EITHER. Reachability analysis
// does not exist here yet, so reachability is UNKNOWN for every finding. An
// unknown factor contributes no points and says so. It must never be dressed up
// as "not reachable", which would be a claim we cannot support.

// Maximum points per factor. Configurable: pass `weights` to override any of
// them. They are deliberately not normalised — the total defines the scale.
const DEFAULT_WEIGHTS = {
  severity: 30,
  exploit: 20,
  reachability: 15,
  exposure: 10,
  environment: 10,
  assetCriticality: 10,
  dataSensitivity: 5,
};

const SEVERITY_POINTS = { CRITICAL: 1, HIGH: 0.75, MEDIUM: 0.45, LOW: 0.2, INFO: 0.05 };

const CRITICALITY_POINTS = { CRITICAL: 1, HIGH: 0.7, MEDIUM: 0.4, LOW: 0.15 };

const ENVIRONMENT_POINTS = { production: 1, staging: 0.4, development: 0.1 };

const REACHABILITY_POINTS = {
  REACHABLE: 1,
  LIKELY_REACHABLE: 0.7,
  NOT_REACHABLE: 0,
  UNKNOWN: null, // null means "no evidence either way" — scores nothing
};

function factor(key, label, value, known, ratio, weight) {
  return {
    key,
    label,
    value,
    known,
    points: known ? Math.round(ratio * weight * 10) / 10 : 0,
    max: weight,
  };
}

// A live credential is the one case where the finding is not a *potential*
// problem: the secret is in the repository history and must be rotated whatever
// else is true. Severity alone under-rates that, so verified secrets get the
// exploit points outright.
function exploitFactor(finding, weight) {
  const md = finding.metadata || {};

  // A CISA KEV listing is confirmed in-the-wild exploitation, which is the
  // strongest signal available and takes the full weight. Ransomware use is
  // called out in the label because it changes how a team schedules the work,
  // even though it cannot raise the score any further.
  if (md.knownExploited === true) {
    const ransomware = md.kev && md.kev.ransomware;
    return factor(
      'exploit',
      'Known exploited',
      ransomware ? 'CISA KEV — used in ransomware' : 'CISA KEV',
      true,
      1,
      weight
    );
  }

  if (typeof md.epss === 'number') {
    // EPSS is the probability of exploitation in the next 30 days, and it is
    // heavily skewed: the median CVE scores under 0.001, and 0.1 already puts a
    // vulnerability in roughly the top 2%. Feeding the raw probability in would
    // make almost every real signal round to nothing, so it is square-rooted —
    // 0.01 → 0.10, 0.1 → 0.32, 0.5 → 0.71. The percentile is shown alongside so
    // the number can be read in context rather than taken on trust.
    const ratio = Math.min(1, Math.sqrt(md.epss));
    const pct = typeof md.epssPercentile === 'number'
      ? ` (${Math.round(md.epssPercentile * 100)}th pct)`
      : '';
    return factor('exploit', 'Exploit prediction', `EPSS ${md.epss.toFixed(3)}${pct}`, true, ratio, weight);
  }
  if (finding.type === 'SECRET') {
    const verified = md.verified === true;
    return factor(
      'exploit',
      'Credential exposed',
      verified ? 'Verified live' : 'Unverified',
      true,
      verified ? 1 : 0.6,
      weight
    );
  }
  return factor('exploit', 'Known exploited', 'Unknown', false, 0, weight);
}

function reachabilityFactor(finding, weight) {
  const value = (finding.metadata && finding.metadata.reachability) || 'UNKNOWN';
  const ratio = REACHABILITY_POINTS[value];
  if (ratio === null || ratio === undefined) {
    return factor('reachability', 'Reachability', 'Unknown — not analysed', false, 0, weight);
  }
  return factor('reachability', 'Reachability', value, true, ratio, weight);
}

/**
 * @param {object} finding   a normalised finding
 * @param {object} asset     what the user told us about this repository:
 *                           { criticality, environment, internetFacing, sensitiveData }
 * @param {object} weights   optional overrides for DEFAULT_WEIGHTS
 */
function scoreFinding(finding, asset = {}, weights = {}) {
  const w = { ...DEFAULT_WEIGHTS, ...weights };
  const md = finding.metadata || {};

  const factors = [
    factor(
      'severity',
      'Severity',
      md.cvss ? `${finding.severity} (CVSS ${md.cvss})` : finding.severity,
      true,
      SEVERITY_POINTS[finding.severity] ?? 0.45,
      w.severity
    ),
    exploitFactor(finding, w.exploit),
    reachabilityFactor(finding, w.reachability),
    asset.internetFacing === undefined
      ? factor('exposure', 'Internet exposed', 'Unknown', false, 0, w.exposure)
      : factor('exposure', 'Internet exposed', asset.internetFacing ? 'Yes' : 'No', true, asset.internetFacing ? 1 : 0, w.exposure),
    asset.environment
      ? factor('environment', 'Environment', asset.environment, true, ENVIRONMENT_POINTS[asset.environment] ?? 0.4, w.environment)
      : factor('environment', 'Environment', 'Unknown', false, 0, w.environment),
    asset.criticality
      ? factor('assetCriticality', 'Asset criticality', asset.criticality, true, CRITICALITY_POINTS[asset.criticality] ?? 0.4, w.assetCriticality)
      : factor('assetCriticality', 'Asset criticality', 'Unset', false, 0, w.assetCriticality),
    asset.sensitiveData === undefined
      ? factor('dataSensitivity', 'Sensitive data', 'Unknown', false, 0, w.dataSensitivity)
      : factor('dataSensitivity', 'Sensitive data', asset.sensitiveData ? 'Yes' : 'No', true, asset.sensitiveData ? 1 : 0, w.dataSensitivity),
  ];

  const score = Math.round(factors.reduce((sum, f) => sum + f.points, 0));
  const knownWeight = factors.filter(f => f.known).reduce((sum, f) => sum + f.max, 0);
  const totalWeight = factors.reduce((sum, f) => sum + f.max, 0);

  return {
    score,
    priority: priorityFor(score),
    factors,
    // How much of the model actually had data behind it. A 40/100 built from a
    // third of the factors is a different statement from a 40 built from all of
    // them, and the UI says so rather than presenting both as equally settled.
    confidence: Math.round((knownWeight / totalWeight) * 100),
    unknownFactors: factors.filter(f => !f.known).map(f => f.key),
  };
}

function priorityFor(score) {
  if (score >= 85) return 'P0';
  if (score >= 70) return 'P1';
  if (score >= 50) return 'P2';
  if (score >= 30) return 'P3';
  return 'P4';
}

// A one-line explanation, for the places a full factor table will not fit.
function explain(risk) {
  const contributing = risk.factors
    .filter(f => f.points > 0)
    .sort((a, b) => b.points - a.points)
    .map(f => `${f.label} ${f.value} (+${f.points})`);
  const unknown = risk.factors.filter(f => !f.known).length;
  const tail = unknown ? `; ${unknown} factor${unknown === 1 ? '' : 's'} unknown` : '';
  return `${risk.score}/100 — ${contributing.join(', ')}${tail}`;
}

module.exports = {
  DEFAULT_WEIGHTS,
  scoreFinding,
  priorityFor,
  explain,
};