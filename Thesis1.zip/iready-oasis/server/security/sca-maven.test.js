'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { scanner, createPomFetcher, indexWorkspacePoms } = require('./scanners/sca-maven');

// A multi-module Maven repository scans ITSELF as well as its dependencies, and
// the difference matters for licences.
//
// `activity-component-service` declares Apache-2.0 in its root POM and builds
// five modules that inherit it. Its own modules depend on each other, so
// resolution meets `com.cainc.activitycomponent:activity-component-service-shared`
// as an ordinary dependency — and looked for it in Maven Central, where a
// company's unpublished module has never existed. The fetch failed, the licence
// came back empty, and the repository was reported as carrying an unknown
// licence obligation to itself.
//
// That is the shape of the bug behind "I added the licence and it still shows
// licence issues": the licence WAS there, in the POM one directory up, and
// nothing in the scan ever read it.

function repo(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-maven-'));
  for (const [name, content] of Object.entries(files)) {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  return dir;
}

// No advisories, and no network: this file is about licences, and an OSV lookup
// per dependency would make it a test of the internet.
const noVulnerabilities = { post: async () => ({ data: { vulns: [] } }) };

const ROOT_POM = `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <groupId>com.cainc.activitycomponent</groupId>
  <artifactId>activity-component-service-parent</artifactId>
  <version>5.9.0</version>
  <packaging>pom</packaging>
  <licenses>
    <license>
      <name>Apache License, Version 2.0</name>
      <url>https://www.apache.org/licenses/LICENSE-2.0</url>
    </license>
  </licenses>
  <modules><module>shared</module><module>core</module></modules>
</project>`;

const SHARED_POM = `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <parent>
    <groupId>com.cainc.activitycomponent</groupId>
    <artifactId>activity-component-service-parent</artifactId>
    <version>5.9.0</version>
  </parent>
  <artifactId>activity-component-service-shared</artifactId>
</project>`;

const CORE_POM = `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <parent>
    <groupId>com.cainc.activitycomponent</groupId>
    <artifactId>activity-component-service-parent</artifactId>
    <version>5.9.0</version>
  </parent>
  <artifactId>activity-component-service-core</artifactId>
  <dependencies>
    <dependency>
      <groupId>com.cainc.activitycomponent</groupId>
      <artifactId>activity-component-service-shared</artifactId>
      <version>5.9.0</version>
    </dependency>
  </dependencies>
</project>`;

test('the repository\'s own POMs are indexed by Maven coordinate', () => {
  const dir = repo({ 'pom.xml': ROOT_POM, 'shared/pom.xml': SHARED_POM });
  const index = indexWorkspacePoms([path.join(dir, 'pom.xml'), path.join(dir, 'shared', 'pom.xml')]);

  assert.ok(index.has('com.cainc.activitycomponent:activity-component-service-parent:5.9.0'));
  // groupId and version both inherited from the parent, which is the norm in a
  // multi-module build and the case an index keyed on declared text would miss.
  assert.ok(index.has('com.cainc.activitycomponent:activity-component-service-shared:5.9.0'));

  fs.rmSync(dir, { recursive: true, force: true });
});

test('a workspace POM is served without asking the repository', async () => {
  const dir = repo({ 'pom.xml': '<project><groupId>com.example</groupId><artifactId>local</artifactId><version>1.0</version></project>' });
  const fetchPom = createPomFetcher({
    dir: fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-pomcache-')),
    // Unreachable on purpose: anything that leaves this machine is a failure.
    env: { OASIS_MAVEN_REPO: 'http://127.0.0.1:1' },
    workspace: new Map([['com.example:local:1.0', path.join(dir, 'pom.xml')]]),
  });

  assert.match(await fetchPom('com.example', 'local', '1.0'), /local/);
  assert.equal(fetchPom.stats.workspace, 1);
  assert.equal(fetchPom.stats.missed, 0);
});

test('a module of the scanned repository takes the licence its own root POM declares', async () => {
  const dir = repo({ 'pom.xml': ROOT_POM, 'shared/pom.xml': SHARED_POM, 'core/pom.xml': CORE_POM });
  const cache = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-pomcache-'));

  const result = await scanner.scan({
    repoPath: dir,
    repository: 'activity-component-service',
    dir: cache,
    env: { OASIS_MAVEN_REPO: 'http://127.0.0.1:1' },
    httpClient: noVulnerabilities,
  });

  const licences = result.findings.filter(f => f.type === 'LICENSE');
  assert.deepEqual(
    licences.map(f => f.title),
    [],
    `Apache-2.0 is declared in the root POM, so nothing here needs review — got ${JSON.stringify(licences.map(f => f.title))}`
  );

  const shared = result.dependencies.find(d => d.name.endsWith('activity-component-service-shared'));
  assert.ok(shared, 'the sibling module should resolve as a dependency');
  assert.deepEqual(shared.licenses, ['Apache License, Version 2.0']);
  assert.equal(result.stats.pomsFromWorkspace > 0, true);

  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(cache, { recursive: true, force: true });
});

test('a dependency whose POM is unreachable says so, rather than reporting no licence', async () => {
  // An artifact that lives in a private Nexus is not unlicensed — it is
  // unreadable from here. Reporting "no licence declared" sends the reader to
  // add a licence that already exists; naming the unreachable repository sends
  // them to configure OASIS_MAVEN_REPO, which is the thing that actually fixes
  // it.
  const dir = repo({
    'pom.xml': `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <groupId>com.cainc</groupId><artifactId>app</artifactId><version>1.0</version>
  <dependencies>
    <dependency>
      <groupId>com.cainc.commons</groupId>
      <artifactId>http-session-validation</artifactId>
      <version>2.4.0</version>
    </dependency>
  </dependencies>
</project>`,
  });
  const cache = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-pomcache-'));

  const result = await scanner.scan({
    repoPath: dir,
    repository: 'app',
    dir: cache,
    env: { OASIS_MAVEN_REPO: 'http://127.0.0.1:1' },
    httpClient: noVulnerabilities,
  });

  const finding = result.findings.find(f => f.type === 'LICENSE');
  assert.ok(finding, 'an unassessed licence is still a finding');
  assert.match(finding.description, /could not be retrieved/i);
  assert.match(finding.remediation, /OASIS_MAVEN_REPO/);
  assert.equal(finding.metadata.pomAvailable, false);

  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(cache, { recursive: true, force: true });
});