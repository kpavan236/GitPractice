'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { createOrchestrator } = require('./orchestrator');
const { scanner: patternScanner } = require('./scanners/pattern-sast');
const { testRuleSet } = require('./test-support/rules');

// A user's custom rule pack (~/.oasis/security/rules/*.json) has to reach the
// worker pool a real scan runs on, not just the main thread. This is the
// end-to-end proof: a real orchestrator, running a real scan through real
// worker threads, actually applies a rule nobody but this test's temp
// directory knows about.

function tmpdir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

async function waitForScan(orchestrator, id) {
  for (let i = 0; i < 200; i++) {
    const scan = orchestrator.getScan(id);
    if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(scan.status)) return scan;
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  throw new Error('scan did not finish in time');
}

test('a user rule pack is applied to a real scan through the worker pool', async (t) => {
  const userRulesDir = tmpdir('oasis-orch-user-rules-');
  t.after(() => fs.rmSync(userRulesDir, { recursive: true, force: true }));
  const repoPath = tmpdir('oasis-orch-repo-');
  t.after(() => fs.rmSync(repoPath, { recursive: true, force: true }));
  const storeDir = tmpdir('oasis-orch-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));

  fs.writeFileSync(
    path.join(userRulesDir, 'pack.json'),
    JSON.stringify({
      rules: [
        {
          id: 'orch-user-marker',
          language: 'text',
          severity: 'LOW',
          pattern: 'ORCH_CUSTOM_MARKER',
          files: ['**/*.txt'],
          title: 'Custom marker',
          fixture: { detect: 'ORCH_CUSTOM_MARKER', clean: 'nothing here' },
        },
      ],
    })
  );
  fs.writeFileSync(path.join(repoPath, 'notes.txt'), 'ORCH_CUSTOM_MARKER present\n');

  const orchestrator = createOrchestrator({
    scanners: [patternScanner],
    dir: storeDir,
    userRulesDir,
    userGrammarsDir: null,
  });
  t.after(() => orchestrator.shutdown());

  const scan = await orchestrator.startScan({ targets: [{ repository: 'test/repo', repoPath, ruleSet: testRuleSet() }] });
  const finished = await waitForScan(orchestrator, scan.id);
  assert.equal(finished.status, 'COMPLETED', finished.error || '');

  const findings = await orchestrator.listFindings({ repository: 'test/repo' });
  const ids = findings.flatMap(f => f.detections.map(d => d.ruleId));
  assert.ok(ids.includes('orch-user-marker'), `expected orch-user-marker, got ${JSON.stringify(ids)}`);
});

// ── Quick Scan ───────────────────────────────────────────────────────────────

function git(dir, args) {
  execFileSync('git', args, {
    cwd: dir,
    stdio: 'pipe',
    env: {
      ...process.env,
      GIT_AUTHOR_NAME: 'Test', GIT_AUTHOR_EMAIL: 't@example.invalid',
      GIT_COMMITTER_NAME: 'Test', GIT_COMMITTER_EMAIL: 't@example.invalid',
    },
  });
}

// A scanner with no prepare/scanFile — same shape as SCA, SBOM, git-history —
// standing in for "a whole-repo scanner Quick Scan must never run".
function fakeWholeRepoScanner(id, calls) {
  return {
    id, type: 'SCA', name: id, requires: null, produces: ['SCA'],
    async isAvailable() { return { available: true, version: '1' }; },
    async scan() { calls.count += 1; return { findings: [] }; },
  };
}

test('quick scan never runs a scanner that cannot be scoped to changed files', async (t) => {
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true, force: true }));
  const storeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-store-'));
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));

  git(repoPath, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(repoPath, 'a.js'), 'const a = 1;\n');
  git(repoPath, ['add', '.']);
  git(repoPath, ['commit', '-qm', 'first']);
  fs.writeFileSync(path.join(repoPath, 'a.js'), 'const a = 1;\nconst b = 2;\n');
  git(repoPath, ['add', '.']);
  git(repoPath, ['commit', '-qm', 'second']);

  const calls = { count: 0 };
  const orchestrator = createOrchestrator({
    scanners: [patternScanner, fakeWholeRepoScanner('FAKE_SCA', calls)],
    dir: storeDir,
  });
  t.after(() => orchestrator.shutdown());

  const scan = await orchestrator.startScan({
    targets: [{ repository: 'quick/repo', repoPath, ruleSet: testRuleSet() }],
    mode: 'quick',
    baseRef: 'HEAD~1',
  });
  const finished = await waitForScan(orchestrator, scan.id);
  assert.equal(finished.status, 'COMPLETED', finished.error || '');

  const ids = finished.perRepository[0].scanners.map(s => s.id);
  assert.ok(ids.includes('PATTERN_SAST'), `expected PATTERN_SAST to run, got ${JSON.stringify(ids)}`);
  assert.ok(!ids.includes('FAKE_SCA'), `FAKE_SCA must not run in quick mode, got ${JSON.stringify(ids)}`);
  assert.equal(calls.count, 0);
});

test('quick scan restricts scanning to files changed since the base ref', async (t) => {
  const userRulesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-rules-'));
  t.after(() => fs.rmSync(userRulesDir, { recursive: true, force: true }));
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-repo2-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true, force: true }));
  const storeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-store2-'));
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));

  fs.writeFileSync(
    path.join(userRulesDir, 'pack.json'),
    JSON.stringify({
      rules: [{
        id: 'quick-marker', language: 'text', severity: 'LOW', pattern: 'QUICK_MARKER',
        files: ['**/*.txt'], title: 'Quick marker',
        fixture: { detect: 'QUICK_MARKER', clean: 'nothing here' },
      }],
    })
  );

  git(repoPath, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(repoPath, 'old.txt'), 'QUICK_MARKER present in old file\n');
  git(repoPath, ['add', '.']);
  git(repoPath, ['commit', '-qm', 'first']);

  // Second commit only touches new.txt — old.txt carries the same marker but
  // did not change, so quick scan must not see it.
  fs.writeFileSync(path.join(repoPath, 'new.txt'), 'QUICK_MARKER present in new file\n');
  git(repoPath, ['add', '.']);
  git(repoPath, ['commit', '-qm', 'second']);

  const orchestrator = createOrchestrator({
    scanners: [patternScanner],
    dir: storeDir,
    userRulesDir,
    userGrammarsDir: null,
  });
  t.after(() => orchestrator.shutdown());

  const scan = await orchestrator.startScan({
    targets: [{ repository: 'quick/repo2', repoPath, ruleSet: testRuleSet() }],
    mode: 'quick',
    baseRef: 'HEAD~1',
  });
  const finished = await waitForScan(orchestrator, scan.id);
  assert.equal(finished.status, 'COMPLETED', finished.error || '');

  const findings = await orchestrator.listFindings({ repository: 'quick/repo2' });
  const files = findings.map(f => f.file);
  assert.ok(files.includes('new.txt'), `expected new.txt, got ${JSON.stringify(files)}`);
  assert.ok(!files.includes('old.txt'), `old.txt was not changed — must not be scanned, got ${JSON.stringify(files)}`);
});

test('quick scan fails closed when there is no base to diff against', async (t) => {
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-repo3-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true, force: true }));
  const storeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-quick-store3-'));
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));

  // A single commit: HEAD~1 does not exist, so the diff cannot be taken —
  // the exact "cannot tell" case diff.js's own tests cover for markNewCode.
  git(repoPath, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(repoPath, 'a.js'), 'const a = 1;\n');
  git(repoPath, ['add', '.']);
  git(repoPath, ['commit', '-qm', 'only']);

  const orchestrator = createOrchestrator({ scanners: [patternScanner], dir: storeDir });
  t.after(() => orchestrator.shutdown());

  const scan = await orchestrator.startScan({
    targets: [{ repository: 'quick/repo3', repoPath, ruleSet: testRuleSet() }],
    mode: 'quick',
    baseRef: 'HEAD~1',
  });
  const finished = await waitForScan(orchestrator, scan.id);
  // With every scanner skipped (there is only one, and it could not run),
  // nothing was analysed — the orchestrator's own existing rule for that
  // (line ~710) marks the whole scan FAILED, same as it would for any other
  // reason a scan checked nothing. The specific "why" lives on the scanner
  // entry, which is what a real Quick Scan UI would surface.
  assert.equal(finished.status, 'FAILED');

  const entry = finished.perRepository[0].scanners.find(s => s.id === 'PATTERN_SAST');
  assert.equal(entry.status, 'SKIPPED');
  assert.match(entry.error, /Quick scan/);
});

test('editing a user rule busts the scan cache so the fixed severity is reported', async (t) => {
  const userRulesDir = tmpdir('oasis-orch-cache-rules-');
  t.after(() => fs.rmSync(userRulesDir, { recursive: true, force: true }));
  const repoPath = tmpdir('oasis-orch-cache-repo-');
  t.after(() => fs.rmSync(repoPath, { recursive: true, force: true }));
  const storeDir = tmpdir('oasis-orch-cache-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));

  const packFile = path.join(userRulesDir, 'pack.json');
  const packWithSeverity = severity => JSON.stringify({
    rules: [
      {
        id: 'orch-cache-marker',
        language: 'text',
        severity,
        pattern: 'ORCH_CACHE_MARKER',
        files: ['**/*.txt'],
        title: 'Custom marker',
        fixture: { detect: 'ORCH_CACHE_MARKER', clean: 'nothing here' },
      },
    ],
  });
  fs.writeFileSync(packFile, packWithSeverity('LOW'));
  fs.writeFileSync(path.join(repoPath, 'notes.txt'), 'ORCH_CACHE_MARKER present\n');

  const orchestrator = createOrchestrator({
    scanners: [patternScanner],
    dir: storeDir,
    userRulesDir,
    userGrammarsDir: null,
  });
  t.after(() => orchestrator.shutdown());

  const findingFor = async () =>
    (await orchestrator.listFindings({ repository: 'cache/repo' }))
      .find(f => f.detections.some(d => d.ruleId === 'orch-cache-marker'));

  const first = await orchestrator.startScan({ targets: [{ repository: 'cache/repo', repoPath, ruleSet: testRuleSet() }] });
  await waitForScan(orchestrator, first.id);
  assert.equal((await findingFor()).severity, 'LOW');

  // The file on disk never changes — only the rule that judges it. A cache
  // keyed on file content plus the SIGNED bundle version alone would still hit
  // here and keep serving the old severity.
  fs.writeFileSync(packFile, packWithSeverity('HIGH'));

  const second = await orchestrator.startScan({ targets: [{ repository: 'cache/repo', repoPath, ruleSet: testRuleSet() }] });
  await waitForScan(orchestrator, second.id);
  assert.equal((await findingFor()).severity, 'HIGH');
});