'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { scanner, toFindings, categoryFrom, isSecurityRule, parseErrorCount, bundledVersion } = require('./scanners/eslint');

const REPO = path.join('/', 'tmp', 'repo');

function payload(messages, filePath = path.join(REPO, 'src', 'app.js')) {
  return [{ filePath, messages }];
}

test('maps an ESLint error to a QUALITY finding', () => {
  const findings = toFindings(
    payload([{ ruleId: 'no-unused-vars', severity: 2, message: "'x' is assigned but never used.", line: 3 }]),
    'repo',
    REPO
  );
  assert.equal(findings.length, 1);
  assert.equal(findings[0].type, 'QUALITY');
  assert.equal(findings[0].severity, 'MEDIUM');
  assert.equal(findings[0].file, 'src/app.js');
  assert.equal(findings[0].startLine, 3);
});

test('a warning ranks below an error', () => {
  const [warning] = toFindings(payload([{ ruleId: 'eqeqeq', severity: 1, message: 'Use ===', line: 1 }]), 'repo', REPO);
  assert.equal(warning.severity, 'LOW');
});

test('quality findings never outrank a vulnerability', () => {
  // The whole reason QUALITY is a separate type. If lint could reach HIGH, a
  // formatting complaint would sit alongside SQL injection in the same list.
  const findings = toFindings(
    payload([
      { ruleId: 'no-unused-vars', severity: 2, message: 'unused', line: 1 },
      { ruleId: 'semi', severity: 2, message: 'missing semicolon', line: 2 },
    ]),
    'repo',
    REPO
  );
  assert.ok(findings.every(f => ['MEDIUM', 'LOW'].includes(f.severity)));
});

test('promotes security-relevant rules to SAST with a CWE', () => {
  const [finding] = toFindings(payload([{ ruleId: 'no-eval', severity: 2, message: 'eval can be harmful', line: 9 }]), 'repo', REPO);
  assert.equal(finding.type, 'SAST');
  assert.equal(finding.severity, 'HIGH');
  assert.equal(finding.cwe, 'CWE-95');
});

test('promotes plugin security rules by prefix', () => {
  // Enumerating every eslint-plugin-security rule would rot on their next
  // release; the prefix is the stable part.
  assert.equal(isSecurityRule('security/detect-non-literal-fs-filename'), true);
  assert.equal(isSecurityRule('no-unsanitized/method'), true);
  assert.equal(isSecurityRule('no-unused-vars'), false);

  const [finding] = toFindings(
    payload([{ ruleId: 'security/detect-child-process', severity: 1, message: 'child_process', line: 4 }]),
    'repo',
    REPO
  );
  assert.equal(finding.type, 'SAST');
});

test('a parse error is counted, not reported as a finding', () => {
  // A repository linted with the wrong ESLint version produces hundreds of
  // these. Reported as findings they would read as defects in the source and
  // bury everything real.
  const messages = [
    { fatal: true, severity: 2, message: 'Parsing error: Unexpected token', line: 1, ruleId: null },
    { ruleId: 'no-undef', severity: 2, message: "'y' is not defined", line: 2 },
  ];
  const findings = toFindings(payload(messages), 'repo', REPO);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].detections[0].ruleId, 'no-undef');
  assert.equal(parseErrorCount(payload(messages)), 1);
});

test('drops the plugin prefix when building a category', () => {
  assert.equal(categoryFrom('@typescript-eslint/no-explicit-any'), 'NO_EXPLICIT_ANY');
  assert.equal(categoryFrom('no-unused-vars'), 'NO_UNUSED_VARS');
});

test('records whether ESLint can fix the finding itself', () => {
  const [finding] = toFindings(
    payload([{ ruleId: 'semi', severity: 2, message: 'Missing semicolon', line: 1, fix: { range: [1, 2], text: ';' } }]),
    'repo',
    REPO
  );
  assert.equal(finding.metadata.fixable, true);
  assert.match(finding.remediation, /eslint --fix/);
});

test('survives an empty or malformed payload', () => {
  assert.deepEqual(toFindings([], 'repo', REPO), []);
  assert.deepEqual(toFindings(null, 'repo', REPO), []);
  assert.deepEqual(toFindings([{ filePath: 'a.js' }], 'repo', REPO), []);
});

// ── scan(), against a stub binary ───────────────────────────────────────────
//
// ESLint is optional and usually absent from a machine running these tests, so
// a stub stands in for it. What is being tested is this adapter's handling of
// what ESLint does — a non-zero exit on findings, and a config-less repository
// — not ESLint itself.

function stubRepo(script) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-eslint-'));
  const bin = path.join(root, 'node_modules', '.bin');
  fs.mkdirSync(bin, { recursive: true });
  const file = path.join(bin, 'eslint');
  fs.writeFileSync(file, script, { mode: 0o755 });
  return root;
}

test('prefers the repository-local ESLint and tolerates its non-zero exit', async () => {
  // ESLint exits 1 when it finds anything. Treating that as failure would
  // discard exactly the runs that matter.
  const repoPath = stubRepo(
    '#!/bin/sh\n' +
      'if [ "$1" = "--version" ]; then echo "v9.14.0"; exit 0; fi\n' +
      'echo \'[{"filePath":"a.js","messages":[{"ruleId":"no-eval","severity":2,"message":"eval","line":4}]}]\'\n' +
      'exit 1\n'
  );

  const state = await scanner.isAvailable({ repoPath });
  assert.equal(state.available, true);

  const result = await scanner.scan({ repoPath, repository: 'repo' });
  assert.equal(result.stats.binary, 'repository-local');
  assert.equal(result.findings.length, 1);
  assert.equal(result.findings[0].type, 'SAST');

  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('a repository with no ESLint config is skipped, not failed', async () => {
  // Most repositories are not ESLint projects. That is a fact about the
  // repository, not a broken scanner, and it must not turn a scan red or
  // credit QUALITY as covered.
  const repoPath = stubRepo(
    '#!/bin/sh\n' +
      'if [ "$1" = "--version" ]; then echo "v9.14.0"; exit 0; fi\n' +
      'echo "Oops! ESLint couldn\'t find an eslint.config.js file." >&2\n' +
      'exit 2\n'
  );

  const result = await scanner.scan({ repoPath, repository: 'repo' });
  assert.equal(result.stats.skipped, true);
  assert.match(result.stats.reason, /eslint\.config\.js/);
  assert.deepEqual(result.findings, []);

  fs.rmSync(repoPath, { recursive: true, force: true });
});

// ── the bundled fallback ─────────────────────────────────────────────────────
//
// Unlike the stubbed tests above, this exercises the REAL bundled ESLint
// (a `dependencies` entry of this app itself, not the target repository's) —
// no stub binary, no mocked child process. A repository directory with no
// node_modules/.bin/eslint of its own falls through to it.

function realRepo(files) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-eslint-bundled-'));
  for (const [name, contents] of Object.entries(files)) {
    fs.writeFileSync(path.join(root, name), contents);
  }
  return root;
}

test('bundledVersion() reports the real bundled ESLint', () => {
  assert.equal(typeof bundledVersion(), 'string');
  assert.match(bundledVersion(), /^\d+\.\d+\.\d+/);
});

test('isAvailable() reports available even with no repository chosen yet', async () => {
  // Bundled ESLint needs no repository to exist — unlike the old binary-only
  // check, which could only answer for a global install.
  const state = await scanner.isAvailable({});
  assert.equal(state.available, true);
  assert.equal(state.hint, null);
});

test('falls back to the bundled ESLint and finds a real lint violation via a legacy .eslintrc', async () => {
  // A legacy (non-flat) config, because the bundled version is pinned to
  // ESLint 8 specifically so this format still works without a repository
  // needing to have migrated to eslint.config.js.
  const repoPath = realRepo({
    '.eslintrc.json': JSON.stringify({
      root: true,
      env: { es2021: true, node: true },
      parserOptions: { ecmaVersion: 2021 },
      rules: { 'no-unused-vars': 'error' },
    }),
    'app.js': 'const unused = 1;\n',
  });

  const result = await scanner.scan({ repoPath, repository: 'repo' });
  assert.equal(result.stats.binary, 'bundled');
  assert.equal(result.findings.length, 1);
  assert.equal(result.findings[0].detections[0].ruleId, 'no-unused-vars');
  assert.equal(result.findings[0].type, 'QUALITY');

  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('the bundled fallback skips a repository with no ESLint config, not failing the scan', async () => {
  const repoPath = realRepo({ 'app.js': 'const x = 1;\n' });

  const result = await scanner.scan({ repoPath, repository: 'repo' });
  assert.equal(result.stats.skipped, true);
  assert.deepEqual(result.findings, []);

  fs.rmSync(repoPath, { recursive: true, force: true });
});

// ── Quick Scan's file-list restriction ──────────────────────────────────────

test('an empty file list (quick scan, nothing changed) skips ESLint entirely', async () => {
  // Must not fall back to '.' — that would silently turn "quick scan, nothing
  // changed" into a full-repo lint. No repoPath needed: this returns before
  // ever touching the filesystem or spawning a binary.
  const result = await scanner.scan({ repoPath: '/does/not/exist', repository: 'repo', files: [] });
  assert.deepEqual(result.findings, []);
  assert.equal(result.stats.skipped, true);
});

test('the repository-local binary is invoked with the file list, not "."', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-eslint-quick-'));
  const argsFile = path.join(root, 'args.txt');
  const bin = path.join(root, 'node_modules', '.bin');
  fs.mkdirSync(bin, { recursive: true });
  fs.writeFileSync(
    path.join(bin, 'eslint'),
    '#!/bin/sh\n' +
      'if [ "$1" = "--version" ]; then echo "v9.14.0"; exit 0; fi\n' +
      `echo "$@" > "${argsFile}"\n` +
      "echo '[]'\n",
    { mode: 0o755 }
  );

  await scanner.scan({ repoPath: root, repository: 'repo', files: ['src/a.js', 'src/b.js'] });
  const args = fs.readFileSync(argsFile, 'utf8');
  assert.match(args, /src\/a\.js/);
  assert.match(args, /src\/b\.js/);
  assert.doesNotMatch(args.trim(), /(^|\s)\.\s*$/);

  fs.rmSync(root, { recursive: true, force: true });
});

test('the bundled fallback only lints the given files, not the whole repository', async () => {
  const repoPath = realRepo({
    '.eslintrc.json': JSON.stringify({
      root: true,
      env: { es2021: true, node: true },
      parserOptions: { ecmaVersion: 2021 },
      rules: { 'no-unused-vars': 'error' },
    }),
    'bad.js': 'const unused = 1;\n',
    'clean.js': 'const used = 1;\nconsole.log(used);\n',
  });

  const result = await scanner.scan({ repoPath, repository: 'repo', files: ['clean.js'] });
  assert.deepEqual(result.findings, []);

  fs.rmSync(repoPath, { recursive: true, force: true });
});
