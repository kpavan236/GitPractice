'use strict';
const path = require('path');
const { createFinding, severityFromCvss } = require('./finding');
const { toPosix } = require('./paths');

// SARIF 2.1.0 ingestion — the other half of sarif.js.
//
// This is the highest-leverage module in the security tab, and it is worth
// being explicit about why: it turns every scanner that exists into a data
// source without writing an adapter for any of them. Container scanning
// (Trivy), IaC (Checkov, tfsec), DAST (ZAP), cloud posture (Prowler), API
// testing, and every commercial SAST product all emit SARIF. Each one this app
// reimplemented would be a scanner to maintain, a tool to keep pace with, and a
// rule set to curate; each one ingested is a file to parse.
//
// It is also what makes the capability register honest. Those capabilities were
// marked EXTERNAL — "ingest rather than reimplement" — with nothing to do the
// ingesting, which meant the decision was recorded and not implemented.
//
// Nothing here trusts the document. A SARIF file is produced by another tool
// and may be malformed, enormous, or hostile — a `uri` of ../../etc/passwd is a
// display string here and never a path that gets opened, and every field is
// treated as absent until proven otherwise.

// SARIF's four levels onto our five. `none` is INFO rather than dropped: a tool
// that chose to report something did not think it was nothing.
const LEVELS = { error: 'HIGH', warning: 'MEDIUM', note: 'LOW', none: 'INFO' };

// Tool name → what kind of finding it produces.
//
// The tool is the only reliable signal. A SARIF result has no type field, and
// inferring from the rule id would mean pattern-matching every vendor's naming
// scheme. Matched on a lowercased substring so "Trivy Vulnerability Scanner",
// "trivy", and "aquasecurity/trivy" all land in the same place.
const TOOL_TYPES = [
  [['trivy', 'grype', 'clair', 'docker scout', 'snyk container'], 'CONTAINER'],
  [['checkov', 'tfsec', 'terrascan', 'kics', 'cfn-nag', 'cfn_nag', 'kubelinter', 'kube-linter', 'datree'], 'IAC'],
  [['zap', 'nuclei', 'arachni', 'wapiti', 'burp'], 'DAST'],
  [['prowler', 'scoutsuite', 'steampipe', 'cloudsploit', 'kubescape'], 'CLOUD'],
  [['schemathesis', 'restler', '42crunch', 'apisec'], 'API'],
  [['sonar', 'eslint', 'pmd', 'checkstyle', 'tslint', 'stylelint'], 'QUALITY'],
  [['gitleaks', 'trufflehog', 'detect-secrets', 'ggshield'], 'SECRET'],
  [['dependency-check', 'osv', 'dependabot', 'renovate', 'retire'], 'SCA'],
  [['semgrep', 'codeql', 'bandit', 'gosec', 'brakeman', 'spotbugs', 'find-sec-bugs', 'sast'], 'SAST'],
];

const DEFAULT_TYPE = 'SAST';

function typeForTool(toolName) {
  const name = String(toolName || '').toLowerCase();
  for (const [needles, type] of TOOL_TYPES) {
    if (needles.some(n => name.includes(n))) return type;
  }
  return DEFAULT_TYPE;
}

// A stable, readable source id — SEMGREP, TRIVY, OWASP_ZAP. Used as the
// detection source, so two tools reporting the same finding stay
// distinguishable after deduplication merges them.
function sourceIdFor(toolName) {
  const clean = String(toolName || 'SARIF').toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_|_$/g, '');
  return clean || 'SARIF';
}

// CWE arrives as a tag (`external/cwe/cwe-89`), as a taxa reference, or inside
// free text. All three are read rather than only the tidy one, because which
// one a tool uses is not something this app gets to decide.
function cweFrom(rule = {}, result = {}) {
  const haystack = [
    ...(((rule.properties || {}).tags) || []),
    ...(((result.properties || {}).tags) || []),
    (rule.properties || {}).cwe,
    (result.properties || {}).cwe,
    rule.id,
    result.ruleId,
  ]
    .filter(Boolean)
    .map(String)
    .join(' ');

  const match = /CWE[-_ ]?(\d+)/i.exec(haystack);
  return match ? `CWE-${match[1]}` : null;
}

function cveFrom(rule = {}, result = {}) {
  // result.ruleId is first because it is where the tools that matter put it:
  // Trivy, Grype, and Dependabot all use the CVE itself as the rule id.
  const haystack = [
    result.ruleId,
    rule.id,
    (rule.properties || {}).cve,
    (result.properties || {}).cve,
    (result.message || {}).text,
  ]
    .filter(Boolean)
    .map(String)
    .join(' ');
  const match = /CVE-\d{4}-\d{4,7}/i.exec(haystack);
  return match ? match[0].toUpperCase() : null;
}

/**
 * Severity for one result.
 *
 * `security-severity` is preferred over `level` wherever a tool sets it: it is
 * a CVSS-scale number, so it distinguishes a CRITICAL from a HIGH, while SARIF
 * levels collapse both into `error`. Losing that distinction on ingest would
 * flatten every imported scanner's worst findings into one band.
 */
function severityFor(rule = {}, result = {}) {
  const numeric =
    (result.properties || {})['security-severity'] ?? (rule.properties || {})['security-severity'];
  const fromScore = severityFromCvss(numeric);
  if (fromScore) return fromScore;

  const level = result.level || (rule.defaultConfiguration || {}).level;
  return LEVELS[level] || 'MEDIUM';
}

/**
 * A displayable, repository-relative path for a result.
 *
 * Never used to open anything. SARIF URIs come from another tool and can be
 * absolute, percent-encoded, `file://`-schemed, or deliberately hostile; this
 * normalises them for display and deduplication, and a traversal attempt ends
 * up as a harmless-looking string in a finding rather than a file read.
 */
function fileFor(result, repoPath) {
  const location = (result.locations || [])[0] || {};
  const physical = location.physicalLocation || {};
  const raw = (physical.artifactLocation || {}).uri;
  if (!raw) return null;

  let uri = String(raw);
  try {
    uri = decodeURIComponent(uri);
  } catch (_) {
    // A malformed escape sequence; the raw string is still usable as a label.
  }
  uri = uri.replace(/^file:\/\//i, '');

  if (repoPath && path.isAbsolute(uri)) {
    const relative = path.relative(repoPath, uri);
    // Only rewrite when it actually lands inside the repository. A path that
    // does not is left absolute rather than turned into a run of `../`, which
    // would read as if the finding were somewhere it is not.
    if (relative && !relative.startsWith('..')) uri = relative;
  }

  return toPosix(uri).replace(/^\.\//, '');
}

function regionOf(result) {
  const physical = ((result.locations || [])[0] || {}).physicalLocation || {};
  const region = physical.region || {};
  const startLine = Number.isFinite(region.startLine) ? region.startLine : null;
  return { startLine, endLine: Number.isFinite(region.endLine) ? region.endLine : startLine };
}

// A rule catalogue for one run, keyed by id AND by index — SARIF results
// reference a rule either way, and a tool is free to use whichever.
function rulesOf(run) {
  const driver = ((run.tool || {}).driver) || {};
  const extensions = ((run.tool || {}).extensions) || [];
  const all = [...(driver.rules || []), ...extensions.flatMap(e => e.rules || [])];

  const byId = new Map();
  all.forEach((rule, index) => {
    if (rule && rule.id) byId.set(String(rule.id), rule);
    byId.set(`#${index}`, rule || {});
  });
  return byId;
}

function ruleFor(rules, result) {
  if (result.ruleId && rules.has(String(result.ruleId))) return rules.get(String(result.ruleId));
  if (Number.isInteger(result.ruleIndex) && rules.has(`#${result.ruleIndex}`)) return rules.get(`#${result.ruleIndex}`);
  return {};
}

function textOf(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  return String(value.text || value.markdown || '');
}

/**
 * Converts a parsed SARIF document into findings.
 *
 * @param {object} document   parsed SARIF 2.1.0
 * @param {object} options    { repository, repoPath, type, origin }
 *   type   forces the finding type, for a tool this app does not recognise
 *   origin a label for where the file came from, kept in metadata so a reader
 *          can tell an imported finding from a locally produced one
 */
function fromSarif(document, { repository, repoPath = null, type = null, origin = null } = {}) {
  if (!document || !Array.isArray(document.runs)) return [];

  const findings = [];

  for (const run of document.runs) {
    if (!run || !Array.isArray(run.results)) continue;

    const driver = ((run.tool || {}).driver) || {};
    const toolName = driver.name || 'SARIF';
    const source = sourceIdFor(toolName);
    // An explicit override wins, then the run's own declaration, then the tool
    // name. The middle one lets a CI job label output from a tool this app has
    // never heard of without a code change.
    const runType = type || (run.properties || {}).oasisType || typeForTool(toolName);
    const rules = rulesOf(run);

    for (const result of run.results) {
      if (!result) continue;

      const rule = ruleFor(rules, result);
      const { startLine, endLine } = regionOf(result);
      const message = textOf(result.message) || textOf(rule.shortDescription) || String(result.ruleId || 'Finding');
      const file = fileFor(result, repoPath);

      findings.push(
        createFinding({
          type: runType,
          category: String(rule.name || result.ruleId || 'IMPORTED')
            .toUpperCase()
            .replace(/[^A-Z0-9]+/g, '_')
            .slice(0, 60),
          severity: severityFor(rule, result),
          title: (textOf(rule.shortDescription) || message).split('\n')[0].slice(0, 140),
          description: textOf(rule.fullDescription) || message,
          repository,
          file,
          startLine,
          endLine,
          cwe: cweFrom(rule, result),
          cve: cveFrom(rule, result),
          source,
          ruleId: result.ruleId || rule.id || null,
          remediation: textOf(rule.help) || null,
          evidence: file ? `${file}${startLine ? `:${startLine}` : ''} — ${result.ruleId || rule.id || toolName}` : null,
          metadata: {
            snippet: textOf((((result.locations || [])[0] || {}).physicalLocation || {}).contextRegion?.snippet) || null,
            confidence: (rule.properties || {}).precision || 'MEDIUM',
            engine: 'sarif',
            tool: toolName,
            toolVersion: driver.version || driver.semanticVersion || null,
            origin,
            // The producing tool's own identity for this result. Kept so a
            // re-import after a code move can be traced back, even though our
            // fingerprint is what actually deduplicates.
            upstreamFingerprint:
              (result.partialFingerprints && Object.values(result.partialFingerprints)[0]) || null,
            // Triage already applied upstream. Recorded rather than acted on:
            // suppression in this app is a decision with an owner and a reason,
            // and importing one silently would let another tool close findings
            // here.
            suppressedUpstream: Array.isArray(result.suppressions) && result.suppressions.length > 0,
          },
        })
      );
    }
  }

  return findings;
}

module.exports = { fromSarif, typeForTool, sourceIdFor, severityFor, fileFor, cweFrom, cveFrom, LEVELS, TOOL_TYPES, DEFAULT_TYPE };