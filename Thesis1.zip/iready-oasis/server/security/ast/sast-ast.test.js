'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scanSource, textWithoutStrings, identifiersIn, adjustSeverity } = require('../scanners/sast-ast');
const { testRuleSet } = require('../test-support/rules');
const engine = require('./engine');

const BUNDLE = testRuleSet();
// Rules carry the bundle version the way the scanner attaches it, so a finding
// can say which rule set produced it.
const RULES = BUNDLE.rules.map(r => ({ ...r, _bundleVersion: BUNDLE.version }));
const scan = (src, file) => scanSource(src, file, 'repo', RULES);

// The corpus. Each pair is a vulnerable shape and the corrected version that
// must stay silent — a rule that cannot tell them apart trains people to ignore
// the scanner.

test('taint follows a variable to the sink', async () => {
  const found = await scan(`class R {
  void f(HttpServletRequest request) throws Exception {
    String n = request.getParameter("n");
    String sql = "SELECT * FROM t WHERE n=" + n;
    stmt.executeQuery(sql);
  } }`, 'R.java');
  assert.equal(found.length, 1);
  assert.equal(found[0].metadata.taintedVia, 'variable');
  assert.equal(found[0].metadata.engine, 'tree-sitter');
});

test('a correctly parameterised query is not flagged', async () => {
  // The regression the AST engine exists to make impossible: the tainted
  // variable is `n` and so is the column name inside the SQL string. A string
  // literal is one leaf node, so there is no identifier there to match.
  assert.deepEqual(await scan(`class R {
  void f(HttpServletRequest request) throws Exception {
    String n = request.getParameter("n");
    PreparedStatement ps = conn.prepareStatement("SELECT * FROM t WHERE n = ?");
    ps.setString(1, n);
  } }`, 'R.java'), []);
});

test('a constant query is not flagged', async () => {
  assert.deepEqual(await scan('class R { void f(){ stmt.executeQuery("SELECT COUNT(*) FROM t"); } }', 'R.java'), []);
});

test('a sink named in a comment or a string is not a finding', async () => {
  assert.deepEqual(await scan(`class R { void f(){
    // stmt.executeQuery(userInput)
    String s = "stmt.executeQuery(userInput)";
  } }`, 'R.java'), []);
});

test('direct taint in the arguments is caught', async () => {
  const found = await scan(`class R { void f(HttpServletRequest request) throws Exception {
    stmt.executeQuery("SELECT " + request.getParameter("q")); } }`, 'R.java');
  assert.equal(found[0].metadata.taintedVia, 'direct');
});

test('command injection is caught', async () => {
  const found = await scan(`class R { void f(HttpServletRequest request) throws Exception {
    Runtime.getRuntime().exec("ping " + request.getParameter("h")); } }`, 'R.java');
  assert.equal(found[0].category, 'COMMAND_INJECTION');
  assert.equal(found[0].severity, 'CRITICAL');
});

test('JavaScript DOM XSS is caught, directly and through a variable', async () => {
  assert.equal((await scan('function h(req){ el.innerHTML = req.query.msg; }', 'v.js')).length, 1);
  assert.equal((await scan('function h(req){ const m = req.query.msg; el.innerHTML = m; }', 'v.js')).length, 1);
});

test('textContent is not innerHTML', async () => {
  assert.deepEqual(await scan('function h(req){ el.textContent = req.query.msg; }', 'v.js'), []);
});

test('an inline ignore suppresses an AST finding', async () => {
  assert.deepEqual(await scan(`class R { void f(HttpServletRequest request) throws Exception {
    stmt.executeQuery("SELECT " + request.getParameter("q")); // oasis:ignore java-sql-injection -- reviewed
  } }`, 'R.java'), []);
});

test('findings carry the rule metadata the bundle declared', async () => {
  const f = (await scan(`class R { void f(HttpServletRequest request) throws Exception {
    stmt.executeQuery("SELECT " + request.getParameter("q")); } }`, 'R.java'))[0];
  assert.equal(f.cwe, 'CWE-89');
  assert.match(f.metadata.cvssVector, /^CVSS:3\.1/);
  assert.equal(f.metadata.owasp, 'A03:2021-Injection');
  assert.ok(f.metadata.ruleBundleVersion);
});

// ── The primitives ─────────────────────────────────────────────────────────

test('string literals are removed but dotted expressions survive', async () => {
  // Source patterns are dotted (`req.`), so they must match text; string
  // literals must not be in that text.
  const tree = await engine.parse('const x = f(req.query.id, "WHERE n = ?");', 'javascript');
  const stripped = textWithoutStrings(tree.rootNode);
  assert.match(stripped, /req\.query\.id/);
  assert.equal(stripped.includes('WHERE'), false);
  tree.delete();
});

test('identifiers are collected structurally, never from inside a string', async () => {
  const tree = await engine.parse('class A { void f(){ g("n", n); } }', 'java');
  const ids = identifiersIn(tree.rootNode);
  assert.ok(ids.includes('n'));
  // `n` appears once as an identifier and once inside a string; only the
  // identifier is counted.
  assert.equal(ids.filter(i => i === 'n').length, 1);
  tree.delete();
});

test('a low-confidence rule reports one band lower', () => {
  assert.equal(adjustSeverity('HIGH', 'LOW'), 'MEDIUM');
  assert.equal(adjustSeverity('HIGH', 'HIGH'), 'HIGH');
});

test('a file type with no grammar produces nothing', async () => {
  assert.deepEqual(await scan('anything at all', 'README.md'), []);
});

test('a bundled AST rule tags its finding metadata.ruleSource as bundled', async () => {
  const rule = { id: 'custom-marker', language: 'java', query: '(method_invocation name: (identifier) @m)', severity: 'LOW', title: 'marker call' };
  const found = await scanSource('class R { void f(){ g(); } }', 'R.java', 'repo', [rule]);
  assert.equal(found[0].metadata.ruleSource, 'bundled');
});

test("a user-pack AST rule's finding is tagged metadata.ruleSource: 'user'", async () => {
  const rule = { id: 'custom-marker', language: 'java', query: '(method_invocation name: (identifier) @m)', severity: 'LOW', title: 'marker call', source: 'user' };
  const found = await scanSource('class R { void f(){ g(); } }', 'R.java', 'repo', [rule]);
  assert.equal(found[0].metadata.ruleSource, 'user');
});
