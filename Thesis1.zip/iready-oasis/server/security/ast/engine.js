'use strict';
// Moved to oasis-analyzer; this path stays so no other import had to change.
module.exports = require('oasis-analyzer/src/ast/engine');
