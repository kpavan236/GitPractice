'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const engine = require('./engine');

// These tests are the ones that catch a broken grammar bundle. If a dependency
// bump changes the tree-sitter ABI, the grammars stop loading and every AST
// rule silently finds nothing — so "the grammar loads" is asserted directly
// rather than inferred from rule results.

test('the vendored grammars are present in the repository', () => {
  // They ship with the app: @vscode/tree-sitter-wasm is a devDependency and
  // electron-builder does not package those.
  for (const name of ['java', 'javascript', 'typescript', 'python']) {
    assert.ok(
      fs.existsSync(`${engine.GRAMMAR_DIR}/tree-sitter-${name}.wasm`),
      `missing vendored grammar: ${name}`
    );
  }
});

test('every vendored grammar actually loads', async () => {
  // An ABI mismatch between grammar and runtime fails here with a clear
  // message, instead of turning into "the scanner found nothing".
  for (const name of engine.availableLanguages()) {
    assert.ok(await engine.loadLanguage(name), `grammar failed to load: ${name}`);
  }
});

test('extensions map to grammars', () => {
  assert.equal(engine.languageFor('.java'), 'java');
  assert.equal(engine.languageFor('.tsx'), 'typescript');
  assert.equal(engine.languageFor('.PY'), 'python');
  assert.equal(engine.languageFor('.md'), null);
});

test('Java parses into a real tree', async () => {
  const tree = await engine.parse('class A { void f() { g(); } }', 'java');
  assert.equal(tree.rootNode.type, 'program');
  assert.ok(tree.rootNode.childCount > 0);
  tree.delete();
});

test('a query returns structural matches, not text matches', async () => {
  // The whole reason for the engine: this matches a method invocation node,
  // so the same text inside a string or a comment cannot match.
  const source = `class A {
  void f() {
    stmt.executeQuery("SELECT 1");
    // executeQuery in a comment
    String s = "executeQuery in a string";
  }
}`;
  const tree = await engine.parse(source, 'java');
  const matches = await engine.runQuery(tree, 'java', '(method_invocation name: (identifier) @m)');

  assert.equal(matches.length, 1);
  assert.equal(matches[0].captures.m.text, 'executeQuery');
  tree.delete();
});

test('line numbers are one-based', async () => {
  // tree-sitter counts rows from zero; everything else in this codebase counts
  // lines from one, and an off-by-one here points every finding at the wrong
  // line.
  const tree = await engine.parse('class A {\n  void f() {\n    g();\n  }\n}', 'java');
  const matches = await engine.runQuery(tree, 'java', '(method_invocation) @call');
  assert.equal(matches[0].startLine, 3);
  tree.delete();
});

test('a match exposes its named captures together', async () => {
  // Rules need the sink and its argument in one match; separate capture lists
  // would have to be re-correlated by the caller.
  const tree = await engine.parse('class A { void f() { stmt.executeQuery(sql); } }', 'java');
  const matches = await engine.runQuery(
    tree, 'java',
    '(method_invocation name: (identifier) @name arguments: (argument_list (identifier) @arg))'
  );
  assert.equal(matches[0].captures.name.text, 'executeQuery');
  assert.equal(matches[0].captures.arg.text, 'sql');
  tree.delete();
});

test('JavaScript template interpolation is visible as structure', async () => {
  // What the regex engine could only approximate by not blanking `${...}`.
  const tree = await engine.parse('const r = db.query(`SELECT ${id}`);', 'javascript');
  const matches = await engine.runQuery(tree, 'javascript', '(template_substitution) @sub');
  assert.equal(matches.length, 1);
  assert.equal(matches[0].captures.sub.text, '${id}');
  tree.delete();
});

test('Python parses and queries', async () => {
  const tree = await engine.parse('import os\nos.system("ls " + x)\n', 'python');
  const matches = await engine.runQuery(tree, 'python', '(call function: (attribute) @f)');
  assert.equal(matches[0].captures.f.text, 'os.system');
  tree.delete();
});

test('an unsupported language yields null rather than throwing', async () => {
  assert.equal(await engine.parse('anything', 'cobol'), null);
});

test('a malformed query disables itself instead of failing the scan', async () => {
  // A bad rule should take itself out, not stop everything else running.
  assert.equal(await engine.compileQuery('java', '(this is not valid'), null);
  const tree = await engine.parse('class A {}', 'java');
  assert.deepEqual(await engine.runQuery(tree, 'java', '(nonsense'), []);
  tree.delete();
});

test('syntactically broken source still parses to a usable tree', async () => {
  // Real repositories contain files that do not compile. tree-sitter recovers,
  // and we must not treat that as a reason to skip the file.
  const tree = await engine.parse('class A { void f( { stmt.executeQuery(x); }', 'java');
  assert.ok(tree);
  const matches = await engine.runQuery(tree, 'java', '(method_invocation name: (identifier) @m)');
  assert.ok(matches.length >= 1);
  tree.delete();
});

test('compiled queries are cached', async () => {
  // Rules run against every file in a repository; recompiling per file is the
  // difference between a viable rule set and an unusable one.
  const q1 = await engine.compileQuery('java', '(method_invocation) @a');
  const q2 = await engine.compileQuery('java', '(method_invocation) @a');
  assert.equal(q1, q2);
});

const { loadPlugins, listLoadedPlugins, _reset } = require('./engine');

test('loadPlugins registers extensions and grammar path from manifest', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-grammars-'));
  t.after(() => { fs.rmSync(dir, { recursive: true }); _reset(); });

  const pluginDir = path.join(dir, 'ruby');
  fs.mkdirSync(pluginDir);
  // Create a fake (zero-byte) grammar file — we only test extension registration, not parsing
  fs.writeFileSync(path.join(pluginDir, 'grammar.wasm'), '');
  fs.writeFileSync(path.join(pluginDir, 'manifest.json'), JSON.stringify({
    language: 'ruby',
    displayName: 'Ruby',
    extensions: ['.rb', '.rake'],
    version: '1.0.0',
  }));

  const loaded = loadPlugins(dir);
  assert.equal(loaded.length, 1);
  assert.equal(loaded[0].language, 'ruby');
  assert.deepEqual(loaded[0].extensions, ['.rb', '.rake']);
  assert.equal(loaded[0].valid, true);

  // languageFor should now return 'ruby' for .rb
  const { languageFor } = require('./engine');
  assert.equal(languageFor('.rb'), 'ruby');
});

test('loadPlugins skips directory with missing grammar.wasm', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-grammars-'));
  t.after(() => { fs.rmSync(dir, { recursive: true }); _reset(); });

  const pluginDir = path.join(dir, 'kotlin');
  fs.mkdirSync(pluginDir);
  fs.writeFileSync(path.join(pluginDir, 'manifest.json'), JSON.stringify({
    language: 'kotlin', displayName: 'Kotlin', extensions: ['.kt'], version: '1.0.0',
  }));

  const loaded = loadPlugins(dir);
  assert.equal(loaded.length, 1);
  assert.equal(loaded[0].valid, false);
  assert.ok(loaded[0].error);
});

test('loadPlugins returns empty array when dir does not exist', () => {
  const loaded = loadPlugins('/nonexistent/path/xyz');
  assert.deepEqual(loaded, []);
});

test('loadPlugins records rulesFile when the plugin ships default rules', (t) => {
  // A grammar plugin can bundle rules for the language it adds — otherwise a
  // new language means a working parser with nothing that ever uses it.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-grammars-'));
  t.after(() => { fs.rmSync(dir, { recursive: true }); _reset(); });

  const pluginDir = path.join(dir, 'ruby');
  fs.mkdirSync(pluginDir);
  fs.writeFileSync(path.join(pluginDir, 'grammar.wasm'), '');
  fs.writeFileSync(path.join(pluginDir, 'manifest.json'), JSON.stringify({
    language: 'ruby', displayName: 'Ruby', extensions: ['.rb'], version: '1.0.0',
  }));
  fs.writeFileSync(path.join(pluginDir, 'rules.json'), JSON.stringify({ rules: [] }));

  const loaded = loadPlugins(dir);
  assert.equal(loaded[0].rulesFile, path.join(pluginDir, 'rules.json'));
});

test('loadPlugins leaves rulesFile null when the plugin ships no rules', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-grammars-'));
  t.after(() => { fs.rmSync(dir, { recursive: true }); _reset(); });

  const pluginDir = path.join(dir, 'ruby');
  fs.mkdirSync(pluginDir);
  fs.writeFileSync(path.join(pluginDir, 'grammar.wasm'), '');
  fs.writeFileSync(path.join(pluginDir, 'manifest.json'), JSON.stringify({
    language: 'ruby', displayName: 'Ruby', extensions: ['.rb'], version: '1.0.0',
  }));

  const loaded = loadPlugins(dir);
  assert.equal(loaded[0].rulesFile, null);
});
