'use strict';
const os = require('os');
const { Worker } = require('worker_threads');

// A small worker pool, so scanning stops holding the server hostage.
//
// Scanning ran on the same event loop as Express, with synchronous reads and
// synchronous regex and parser work. For the several seconds a repository
// takes, the server could not answer anything — so the progress bar the user
// was watching to see how the scan was going was frozen BY the scan. Across
// 250 repositories the app is unusable for the whole run, and nothing else the
// machine has is being used either: one core busy, the rest idle.
//
// worker_threads ships with Node, so this costs no dependency — which this app
// cannot take anyway.
//
// The pool is deliberately dull. Fixed size, one queue, workers reused. Each
// worker loads the rule bundle and the tree-sitter grammars when it starts, so
// spawning one per repository would cost more than the parallelism returns.

// Leave room for the main thread and for the machine to stay usable. Scanning
// is a background chore in a desktop app; taking every core to finish a minute
// sooner is not a trade the person using the laptop agreed to.
function defaultSize() {
  const cores = os.cpus().length || 2;
  return Math.max(1, Math.min(4, cores - 2));
}

/**
 * @param {number} size        threads to keep
 * @param {string} workerPath  module each thread runs
 * @param {object} workerData  constant data every worker receives at startup
 */
function createPool({ size = defaultSize(), workerPath, workerData = null } = {}) {
  const idle = [];
  const all = new Set();
  const queue = [];
  // Tasks handed to a worker and not yet answered, so a thread that dies can
  // reject its caller instead of leaving them waiting forever.
  const inFlight = new Map();
  let nextId = 1;
  let destroyed = false;

  function spawn() {
    const worker = new Worker(workerPath, { workerData });
    // Idle threads must not keep the process alive. The Express server runs
    // inside the Electron main process, so a pool left referenced after a scan
    // is an app that will not quit — the user closes the window and the dock
    // icon stays. Referenced again the moment a task is handed over, so work in
    // flight always finishes.
    worker.unref();
    all.add(worker);

    worker.on('message', msg => {
      const task = inFlight.get(msg.id);
      if (!task) return;

      // A progress report is not an answer: the task is still running, keeps its
      // worker, and stays in flight. Without this distinction the first report
      // would resolve the caller with a partial result and free a thread that is
      // still busy.
      if (msg.progress !== undefined) {
        if (task.onProgress) {
          try {
            task.onProgress(msg.progress);
          } catch (_) {
            // A consumer that throws while drawing a progress bar must not fail
            // the scan it is reporting on.
          }
        }
        return;
      }

      inFlight.delete(msg.id);
      worker.busy = false;
      worker.unref();                    // idle again
      if (msg.ok) task.resolve(msg.result);
      else task.reject(new Error(msg.error || 'worker task failed'));
      release(worker);
    });

    // A scanner that exhausts memory takes its thread with it. Without this the
    // caller waits forever and the scan sits at RUNNING until the app is
    // restarted.
    const die = err => {
      all.delete(worker);
      for (const [id, task] of inFlight) {
        if (task.worker !== worker) continue;
        inFlight.delete(id);
        task.reject(new Error(`worker stopped before finishing: ${err || 'exited'}`));
      }
      const i = idle.indexOf(worker);
      if (i !== -1) idle.splice(i, 1);
      // Replaced, so one bad repository does not shrink the pool for the rest
      // of a 250-repository run.
      if (!destroyed && queue.length) pump();
    };

    worker.on('error', e => die(e.message));
    worker.on('exit', code => { if (code !== 0) die(`exit code ${code}`); else all.delete(worker); });

    return worker;
  }

  function release(worker) {
    if (destroyed) return;
    idle.push(worker);
    pump();
  }

  function pump() {
    while (queue.length) {
      let worker = idle.pop();
      if (!worker) {
        if (all.size >= size) return;      // saturated: the rest waits its turn
        worker = spawn();
      }
      const task = queue.shift();
      task.worker = worker;
      worker.busy = true;
      // Held while the task runs, so a scan in progress keeps the process
      // alive and always gets to finish.
      worker.ref();
      inFlight.set(task.id, task);
      worker.postMessage({ id: task.id, payload: task.payload });
    }
  }

  return {
    /**
     * Runs one task on a worker, resolving with whatever it posts back.
     *
     * Rejects if the task throws OR if its thread dies — never hangs, because
     * a hung scan is indistinguishable from a slow one and people wait for it.
     *
     * @param {function} opts.onProgress  called with whatever the task posts as
     *                                    `{ id, progress }` while it runs
     */
    run(payload, { onProgress = null } = {}) {
      if (destroyed) return Promise.reject(new Error('pool has been destroyed'));
      return new Promise((resolve, reject) => {
        queue.push({ id: nextId++, payload, resolve, reject, onProgress });
        pump();
      });
    },

    size() {
      return all.size;
    },

    /**
     * Stops every thread.
     *
     * Electron will not quit while worker threads are alive, so an app that
     * skips this leaves the user with a dock icon that refuses to go away.
     */
    async destroy() {
      destroyed = true;
      queue.length = 0;
      for (const [, task] of inFlight) task.reject(new Error('pool has been destroyed'));
      inFlight.clear();
      await Promise.all([...all].map(w => w.terminate().catch(() => {})));
      all.clear();
      idle.length = 0;
    },
  };
}

module.exports = { createPool, defaultSize };
