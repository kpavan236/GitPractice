'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');

// Exploit intelligence: EPSS and the CISA KEV catalog.
//
// These answer a question OSV cannot. OSV says a vulnerability exists and how
// bad it would be if exploited; neither tells you whether anyone is actually
// exploiting it. Without them the risk engine's `exploit` factor reads
// "Unknown" for every SCA finding — 20 of 100 points permanently unavailable,
// and the reason risk confidence caps out around 85%.
//
//   EPSS  FIRST's Exploit Prediction Scoring System. A daily-refreshed
//         probability, 0–1, that a CVE will be exploited in the next 30 days.
//         Most CVEs score under 0.01; the tail is what matters.
//   KEV   CISA's Known Exploited Vulnerabilities catalog. Not a prediction —
//         a list of CVEs with confirmed in-the-wild exploitation. A KEV hit is
//         the strongest signal available and outranks any CVSS score.
//
// Both are public, free, and need no key. Both are cached on disk, because a
// scan of a large repository can reference hundreds of CVEs and neither service
// should be hit once per finding.

const KEV_URL = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json';
const EPSS_URL = 'https://api.first.org/data/v1/epss';

// KEV changes a few times a week; EPSS is recomputed daily. A day-old cache is
// materially as good as a fresh fetch, and it keeps the tool usable offline.
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;

// EPSS accepts a comma-separated list. Kept well under the URL length limit.
const EPSS_BATCH = 100;

function getJson(url, { timeoutMs = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'i-Ready-OASIS' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(getJson(res.headers.location, { timeoutMs }));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} from ${new URL(url).host}`));
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', c => (body += c));
      res.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          reject(new Error(`Unreadable response from ${new URL(url).host}`));
        }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`Timed out contacting ${new URL(url).host}`)));
    req.on('error', reject);
  });
}

function cacheFile(dir, name) {
  return path.join(dir, 'intel', `${name}.json`);
}

function readCache(dir, name, now) {
  try {
    const cached = JSON.parse(fs.readFileSync(cacheFile(dir, name), 'utf8'));
    if (!cached || typeof cached.fetchedAt !== 'number') return null;
    return { ...cached, stale: now - cached.fetchedAt > CACHE_TTL_MS };
  } catch (_) {
    return null;
  }
}

function writeCache(dir, name, payload) {
  try {
    fs.mkdirSync(path.join(dir, 'intel'), { recursive: true });
    fs.writeFileSync(cacheFile(dir, name), JSON.stringify(payload), { mode: 0o600 });
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * The KEV catalog as a Map of CVE → { dateAdded, dueDate, ransomware, name }.
 *
 * A stale cache is served rather than discarded when the fetch fails. Being a
 * day behind on KEV is a far better outcome than losing the exploit signal for
 * the whole scan because a laptop was offline.
 */
async function loadKev({ dir, now = Date.now, fetchJson = getJson } = {}) {
  const cached = readCache(dir, 'kev', now());
  if (cached && !cached.stale) {
    return { entries: new Map(Object.entries(cached.entries)), fetchedAt: cached.fetchedAt, fromCache: true };
  }

  try {
    const payload = await fetchJson(KEV_URL);
    const entries = {};
    for (const v of payload.vulnerabilities || []) {
      if (!v.cveID) continue;
      entries[v.cveID] = {
        dateAdded: v.dateAdded || null,
        dueDate: v.dueDate || null,
        // CISA flags whether a vulnerability is known to be used in ransomware
        // campaigns. That is the single most actionable field in the catalog.
        ransomware: v.knownRansomwareCampaignUse === 'Known',
        name: v.vulnerabilityName || null,
      };
    }
    const fetchedAt = now();
    writeCache(dir, 'kev', { fetchedAt, entries, count: Object.keys(entries).length });
    return { entries: new Map(Object.entries(entries)), fetchedAt, fromCache: false };
  } catch (err) {
    if (cached) {
      return {
        entries: new Map(Object.entries(cached.entries)),
        fetchedAt: cached.fetchedAt,
        fromCache: true,
        stale: true,
        error: err.message,
      };
    }
    // No data at all. Returning an empty map is safe: findings score the
    // exploit factor as unknown, which is honest, rather than as absent-from-
    // KEV, which would be a claim we cannot make.
    return { entries: new Map(), fetchedAt: null, error: err.message, unavailable: true };
  }
}

/**
 * EPSS scores for specific CVEs, as a Map of CVE → { score, percentile }.
 *
 * Fetched per CVE set rather than as a bulk download: the full EPSS dataset is
 * ~250k rows, and a repository references a few dozen.
 */
async function loadEpss(cveIds, { dir, now = Date.now, fetchJson = getJson } = {}) {
  const wanted = [...new Set((cveIds || []).filter(id => /^CVE-\d{4}-\d+$/.test(id)))];
  if (!wanted.length) return { scores: new Map(), fetchedAt: now() };

  const cached = readCache(dir, 'epss', now()) || { fetchedAt: 0, entries: {} };
  const fresh = !cached.stale;
  const scores = new Map();
  const missing = [];

  for (const id of wanted) {
    // hasOwnProperty, not truthiness: a cached `null` means "we asked today and
    // EPSS has no score for this CVE". Treating that as a cache miss would
    // re-request every unmodelled CVE on every scan.
    if (fresh && Object.prototype.hasOwnProperty.call(cached.entries, id)) {
      const value = cached.entries[id];
      if (value) scores.set(id, value);
    } else {
      missing.push(id);
    }
  }
  if (!missing.length) return { scores, fetchedAt: cached.fetchedAt, fromCache: true };

  const entries = fresh ? { ...cached.entries } : {};
  let error = null;

  for (let i = 0; i < missing.length; i += EPSS_BATCH) {
    const batch = missing.slice(i, i + EPSS_BATCH);
    try {
      const payload = await fetchJson(`${EPSS_URL}?cve=${batch.join(',')}`);
      for (const row of payload.data || []) {
        const value = { score: Number(row.epss), percentile: Number(row.percentile) };
        if (Number.isFinite(value.score)) {
          entries[row.cve] = value;
          scores.set(row.cve, value);
        }
      }
      // A CVE absent from the response has no EPSS score — usually too new to
      // have been modelled. Recorded as null so we do not ask again today, and
      // read downstream as unknown rather than as zero risk.
      for (const id of batch) if (!scores.has(id)) entries[id] = null;
    } catch (err) {
      error = err.message;
      break;
    }
  }

  const fetchedAt = now();
  writeCache(dir, 'epss', { fetchedAt, entries });
  return { scores, fetchedAt, error };
}

/**
 * Attaches exploit intelligence to findings, in place.
 *
 * Only SCA findings carry a CVE, so only they are enriched. A finding whose CVE
 * is in neither source keeps `knownExploited: undefined` and scores the exploit
 * factor as unknown — which is the correct statement. "Not in KEV" is not
 * evidence of safety; KEV is a list of what is confirmed exploited, not a list
 * of everything that is not.
 */
function enrich(findings, { kev, epss }) {
  let kevHits = 0;
  let epssScored = 0;

  for (const finding of findings) {
    if (!finding.cve) continue;
    const md = finding.metadata || (finding.metadata = {});

    const kevEntry = kev && kev.entries.get(finding.cve);
    if (kevEntry) {
      md.knownExploited = true;
      md.kev = kevEntry;
      kevHits += 1;
      // Confirmed in-the-wild exploitation is not a MEDIUM, whatever the
      // advisory's own label says.
      if (finding.severity === 'MEDIUM' || finding.severity === 'LOW') finding.severity = 'HIGH';
    }

    const epssEntry = epss && epss.scores.get(finding.cve);
    if (epssEntry) {
      md.epss = epssEntry.score;
      md.epssPercentile = epssEntry.percentile;
      epssScored += 1;
    }
  }

  return { kevHits, epssScored };
}

module.exports = {
  loadKev,
  loadEpss,
  enrich,
  KEV_URL,
  EPSS_URL,
  CACHE_TTL_MS,
  EPSS_BATCH,
  _getJson: getJson,
};