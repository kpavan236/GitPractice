'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ACTIVE_STATUSES } = require('./finding');

// Persistence for findings, scan history, asset settings, and SBOMs.
//
// A directory rather than the single dotfile the rest of OASIS uses, because
// SBOM documents run to megabytes and have no business being re-parsed every
// time someone opens the dashboard. The index stays small and loads fast; the
// documents sit beside it and are read only when asked for.

const DEFAULT_DIR = path.join(os.homedir(), '.oasis-security');

const EMPTY = {
  version: 1,
  findings: [],
  scans: [],
  assets: {},
  sboms: [],
  // Time series. Counts only — a few hundred bytes per entry — because the
  // question is "is this getting better", and storing whole findings per day
  // would grow without bound to answer it.
  history: [],
  baseline: null,
  gates: {},    // { [repository]: { name, conditions } }
  ignores: {},  // { [repository]: string }  (raw .oasis-security-ignore text)
};

// Scan history is for "what changed and when", not an audit archive.
const MAX_SCAN_HISTORY = 50;

// Roughly a year of daily scans. Long enough for a trend, short enough that the
// index stays small.
const MAX_HISTORY_POINTS = 400;

function storePath(dir = DEFAULT_DIR) {
  return path.join(dir, 'store.json');
}

function sbomPath(dir, repository) {
  // Repository names can contain slashes (org/repo). Flattened so the filename
  // stays inside the sbom directory rather than creating a path traversal.
  const safe = String(repository).replace(/[^A-Za-z0-9._-]/g, '_');
  return path.join(dir, 'sbom', `${safe}.json`);
}

function load(dir = DEFAULT_DIR) {
  try {
    const file = storePath(dir);
    // Ensure mutable top-level objects (gates, ignores, assets) are always fresh
    // copies rather than references into EMPTY. A shallow spread shares object
    // identity, so a mutate() callback that does data.gates[k] = v would
    // inadvertently write into EMPTY.gates and contaminate every future load()
    // call that falls through to the EMPTY fallback.
    if (!fs.existsSync(file)) return { ...EMPTY, gates: {}, ignores: {}, assets: {} };
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { ...EMPTY, gates: {}, ignores: {}, assets: {} };
    return { ...EMPTY, gates: {}, ignores: {}, assets: {}, ...parsed };
  } catch (_) {
    // Corrupt store: start clean rather than refusing to open the tab. The
    // findings are all reproducible by rescanning.
    return { ...EMPTY, gates: {}, ignores: {}, assets: {} };
  }
}

function save(data, dir = DEFAULT_DIR) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const file = storePath(dir);
    const tmp = `${file}.tmp`;
    // Write-then-rename, so a crash mid-write leaves the previous good index
    // rather than a half-written one.
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
    return true;
  } catch (_) {
    return false;
  }
}

function saveSbom(document, repository, dir = DEFAULT_DIR) {
  try {
    fs.mkdirSync(path.join(dir, 'sbom'), { recursive: true });
    fs.writeFileSync(sbomPath(dir, repository), JSON.stringify(document), { mode: 0o600 });
    return sbomPath(dir, repository);
  } catch (_) {
    return null;
  }
}

// Removes a repository's SBOM document. The index entry is dropped separately,
// by whoever is mutating the store — this only deletes the file beside it, so a
// cleared repository does not leave a megabyte of orphaned JSON on disk.
function deleteSbom(repository, dir = DEFAULT_DIR) {
  try {
    fs.unlinkSync(sbomPath(dir, repository));
    return true;
  } catch (_) {
    return false;
  }
}

function loadSbom(repository, dir = DEFAULT_DIR) {
  try {
    return JSON.parse(fs.readFileSync(sbomPath(dir, repository), 'utf8'));
  } catch (_) {
    return null;
  }
}

/**
 * Folds a scan's findings into what is already stored.
 *
 * The hard part is not adding new findings; it is deciding what happened to the
 * ones that did not come back.
 *
 * @param {Array}  stored        existing findings
 * @param {Array}  incoming      deduped findings from this scan
 * @param {object} opts
 * @param {string} opts.repository    the repository that was scanned
 * @param {Array}  opts.coveredTypes  finding types a scanner actually completed
 *                                    for. Anything outside this list is left
 *                                    alone.
 * @param {number} opts.now
 */
function mergeFindings(stored, incoming, { repository, coveredTypes, now }) {
  const incomingByFp = new Map(incoming.map(f => [f.fingerprint, f]));
  const result = [];
  const seen = new Set();

  for (const existing of stored) {
    const match = incomingByFp.get(existing.fingerprint);

    if (match) {
      seen.add(existing.fingerprint);
      // A triage decision outlives a rescan. Someone who marked a finding a
      // false positive should not have to do it again every scan; only the
      // facts are refreshed.
      const keepStatus =
        existing.status === 'SUPPRESSED' || existing.status === 'FALSE_POSITIVE'
          ? existing.status
          : existing.status === 'RESOLVED'
            ? 'REOPENED' // it came back
            : existing.status;

      result.push({
        ...existing,
        ...match,
        id: existing.id,
        status: keepStatus,
        firstSeenAt: existing.firstSeenAt || now,
        lastSeenAt: now,
        // Triage metadata belongs to the finding, not to any one scan.
        suppression: existing.suppression || null,
        notes: existing.notes || null,
      });
      continue;
    }

    // Not reported this time. Only conclude something if this scan could
    // actually have found it — same repository, and a scanner for its type ran
    // successfully. Without that check, a scan where Semgrep was missing would
    // silently mark every SAST finding resolved.
    const couldHaveFound =
      existing.repository === repository && coveredTypes.includes(existing.type);

    if (couldHaveFound && ACTIVE_STATUSES.includes(existing.status)) {
      result.push({
        ...existing,
        status: 'RESOLVED',
        resolvedAt: now,
        // Named precisely. The finding is gone from the code; no build was run,
        // no test suite, no verification beyond "the scanner stopped reporting
        // it". Calling that VERIFIED would be a claim we have not earned.
        resolvedBy: 'NOT_DETECTED',
      });
    } else {
      result.push(existing);
    }
  }

  for (const finding of incoming) {
    if (seen.has(finding.fingerprint)) continue;
    result.push({ ...finding, firstSeenAt: now, lastSeenAt: now });
  }

  return result;
}

/**
 * Appends a snapshot of the current totals.
 *
 * One point per scan rather than per day: two scans in an hour are two data
 * points, which is what someone watching a fix land wants to see. A daily
 * rollup can be derived from this; the reverse cannot.
 */
function recordHistory(history, { at, counts, total, byType, repositories }) {
  const point = { at, counts, total, byType, repositories };
  return [...(history || []), point].slice(-MAX_HISTORY_POINTS);
}

function recordScan(scans, scan) {
  return [scan, ...scans.filter(s => s.id !== scan.id)].slice(0, MAX_SCAN_HISTORY);
}

// ── Serialised mutation ────────────────────────────────────────────────────
//
// Every write is load → modify → save, and a scan holds that sequence open for
// minutes: it loads the store before running the scanners and saves after. Any
// mutation in between — suppressing a finding, setting asset criticality — is
// applied to a copy the scan is about to overwrite, and the user's decision
// vanishes with no error and no trace.
//
// mutate() serialises the whole read-modify-write, so a mutation either lands
// before the scan reloads or after it has saved, never in the gap. Callers must
// route every write through here; a bare save() reintroduces the race.
//
// Scope is this process. Two OASIS instances against one home directory could
// still interleave — see the note on lockfiles below.
const _queues = new Map();

function mutate(dir, fn) {
  const previous = _queues.get(dir) || Promise.resolve();
  const next = previous
    .catch(() => {}) // one failed mutation must not wedge the queue
    .then(async () => {
      const data = load(dir);
      const result = await fn(data);
      save(data, dir);
      return result;
    });

  _queues.set(dir, next);
  // Keep the map from growing across directories that are no longer in use.
  next.finally(() => {
    if (_queues.get(dir) === next) _queues.delete(dir);
  });
  return next;
}

// Whether any mutation is currently queued, for diagnostics.
function isBusy(dir) {
  return _queues.has(dir);
}

function loadGateConfig(repository, dir) {
  return (load(dir).gates || {})[repository] ?? null;
}

function saveGateConfig(repository, gate, dir) {
  return mutate(dir, data => {
    if (!data.gates) data.gates = {};
    data.gates[repository] = gate;
  });
}

function clearGateConfig(repository, dir) {
  return mutate(dir, data => {
    if (data.gates) delete data.gates[repository];
  });
}

function loadIgnoreConfig(repository, dir) {
  return (load(dir).ignores || {})[repository] ?? null;
}

function saveIgnoreConfig(repository, text, dir) {
  return mutate(dir, data => {
    if (!data.ignores) data.ignores = {};
    data.ignores[repository] = text;
  });
}

function clearIgnoreConfig(repository, dir) {
  return mutate(dir, data => {
    if (data.ignores) delete data.ignores[repository];
  });
}

module.exports = {
  DEFAULT_DIR,
  EMPTY,
  MAX_SCAN_HISTORY,
  load,
  save,
  saveSbom,
  loadSbom,
  deleteSbom,
  storePath,
  sbomPath,
  mergeFindings,
  recordScan,
  recordHistory,
  MAX_HISTORY_POINTS,
  mutate,
  isBusy,
  loadGateConfig,
  saveGateConfig,
  clearGateConfig,
  loadIgnoreConfig,
  saveIgnoreConfig,
  clearIgnoreConfig,
};