'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { scanner, parseDiff, createDiffParser } = require('./scanners/secrets-history');

// The scanner that finds credentials committed and later deleted — the ones the
// working-tree scanner cannot see, and the reason history scanning exists.
//
// It was failing on every real repository:
//
//   GIT_HISTORY  FAILED  "git log failed: stdout maxBuffer length exceeded"
//
// It buffered the complete diff of every commit across every ref into one
// string. The dashboard then showed SECRET as covered by the working-tree
// scanner alone, so a repository whose history holds a live key read as clean.
// These tests cover the fix and, more importantly, the shape of the failure:
// partial results must survive, and must be labelled partial.

// Synthetic, and deliberately NOT AWS's documented `AKIAIOSFODNN7EXAMPLE`:
// the scanner rejects that one as a placeholder, correctly, so a test built on
// it passes whether or not detection works at all.
const AWS_KEY = 'AKIA2E0A8F3B244C9986';

function diffFor(lines) {
  return ['\x00commit abc123\x00Dev <dev@example.invalid>\x002026-01-01T00:00:00Z',
          'diff --git a/config.yml b/config.yml',
          '+++ b/config.yml',
          ...lines].join('\n');
}

// ── Parsing ────────────────────────────────────────────────────────────────

test('finds a credential on an added line', () => {
  const findings = parseDiff(diffFor([`+aws_key: ${AWS_KEY}`]), 'repo');
  assert.equal(findings.length, 1);
  assert.match(findings[0].title, /in git history/);
  assert.equal(findings[0].file, 'config.yml');
  assert.equal(findings[0].metadata.commit, 'abc123');
});

test('a removed line is not a new leak', () => {
  // The commit that ADDED it is already reported. Counting the deletion too
  // would double every rotation and make cleaning up look like a regression.
  assert.equal(parseDiff(diffFor([`-aws_key: ${AWS_KEY}`]), 'repo').length, 0);
});

test('the same credential in many commits is one finding', () => {
  const findings = parseDiff(diffFor([
    `+aws_key: ${AWS_KEY}`,
    '+unrelated: true',
    `+aws_key: ${AWS_KEY}`,
  ]), 'repo');
  assert.equal(findings.length, 1, 'one credential, one row');
});

test('the plaintext credential is never persisted', () => {
  // It is needed during the scan for validity checking and must not reach the
  // store, the logs, or the report.
  const [finding] = parseDiff(diffFor([`+aws_key: ${AWS_KEY}`]), 'repo');
  assert.equal(JSON.stringify(finding).includes(AWS_KEY), false, 'the secret must not serialise');
  assert.equal(finding._plaintext, AWS_KEY, 'but it is available in-process');
});

// ── Streaming ──────────────────────────────────────────────────────────────
//
// A fake streamer stands in for `git log -p`, so the volume and the failure
// modes are controllable from a test rather than dependent on whatever history
// happens to be on the machine.

function fakeStreamer(lines, result = {}) {
  return async (command, args, opts) => {
    for (const line of lines) opts.onLine(line);
    return { ok: true, timedOut: false, code: 0, error: null, stderr: '',
             bytes: lines.join('\n').length, lines: lines.length, linesTruncated: 0, ...result };
  };
}

const repoWithGitDir = () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-hist-'));
  fs.mkdirSync(path.join(dir, '.git'));
  return dir;
};

test('output far larger than any buffer is scanned, not refused', () => {
  // The regression. 200k lines is well past what the old 40MB cap allowed once
  // it is real diff text, and nothing here accumulates.
  const dir = repoWithGitDir();
  const lines = [`\x00commit c1\x00Dev <d@e.invalid>\x002026-01-01T00:00:00Z`, '+++ b/deep.yml'];
  for (let i = 0; i < 200_000; i++) lines.push(`+filler_${i}: value`);
  lines.push(`+aws_key: ${AWS_KEY}`);          // the needle, at the very end

  return scanner.scan({ repoPath: dir, repository: 'repo', streamer: fakeStreamer(lines) })
    .then(result => {
      assert.equal(result.findings.length, 1, 'the credential after 200k lines is still found');
      assert.equal(result.stats.truncated, false);
      fs.rmSync(dir, { recursive: true, force: true });
    });
});

test('a timeout keeps what it found and says the scan was partial', async () => {
  // The old code threw, discarding every credential it had already read. A
  // partial history scan that found a live key is worth far more than an
  // exception — provided nothing reads it as a clean result.
  const dir = repoWithGitDir();
  const lines = [`\x00commit c1\x00Dev <d@e.invalid>\x002026-01-01T00:00:00Z`, '+++ b/a.yml', `+aws_key: ${AWS_KEY}`];

  const result = await scanner.scan({
    repoPath: dir, repository: 'repo',
    streamer: fakeStreamer(lines, { timedOut: true, ok: false }),
  });

  assert.equal(result.findings.length, 1, 'findings survive the timeout');
  assert.equal(result.stats.truncated, true, 'and the scan is not reported as complete');
  assert.match(result.stats.truncatedReason, /timed out/i);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a genuine git failure is still an error', () => {
  // Distinct from a timeout: nothing was read, so there is nothing to keep, and
  // silently returning zero findings would read as a clean history.
  const dir = repoWithGitDir();
  const streamer = async () => ({ ok: false, timedOut: false, code: 128, error: null,
                                  stderr: 'fatal: not a git repository', bytes: 0, lines: 0, linesTruncated: 0 });

  return assert.rejects(
    () => scanner.scan({ repoPath: dir, repository: 'repo', streamer }),
    /not a git repository/,
    'the reason git gave must reach the user'
  ).finally(() => fs.rmSync(dir, { recursive: true, force: true }));
});

test('oversized lines are reported, not silently dropped', async () => {
  // A minified bundle in history is one line megabytes long. It gets truncated
  // to keep memory flat, which means a credential at the end of it is missed —
  // so the count has to surface rather than vanish.
  const dir = repoWithGitDir();
  const result = await scanner.scan({
    repoPath: dir, repository: 'repo',
    streamer: fakeStreamer(['+++ b/bundle.min.js', '+var a=1'], { linesTruncated: 3 }),
  });

  assert.equal(result.stats.linesTruncated, 3);
  assert.match(result.stats.truncatedReason || '', /line/i);
  assert.equal(result.stats.truncated, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a directory that is not a repository is skipped, not failed', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-nogit-'));
  const result = await scanner.scan({ repoPath: dir, repository: 'repo' });
  assert.equal(result.stats.skipped, true);
  assert.equal(result.findings.length, 0);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Against a real repository ──────────────────────────────────────────────

function git(dir, args) {
  execFileSync('git', args, {
    cwd: dir,
    stdio: 'pipe',
    env: {
      ...process.env,
      GIT_AUTHOR_NAME: 'Test', GIT_AUTHOR_EMAIL: 't@example.invalid',
      GIT_COMMITTER_NAME: 'Test', GIT_COMMITTER_EMAIL: 't@example.invalid',
    },
  });
}

test('finds a credential that was committed and later deleted', async () => {
  // The whole purpose of the scanner, end to end through real git: the working
  // tree is spotless and the repository is not.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-realhist-'));
  git(dir, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(dir, 'config.yml'), `aws_access_key_id: ${AWS_KEY}\n`);
  git(dir, ['add', '.']);
  git(dir, ['commit', '-qm', 'oops']);

  fs.writeFileSync(path.join(dir, 'config.yml'), 'aws_access_key_id: ${AWS_KEY_FROM_ENV}\n');
  git(dir, ['add', '.']);
  git(dir, ['commit', '-qm', 'remove the key']);

  const result = await scanner.scan({ repoPath: dir, repository: 'repo' });

  assert.equal(result.findings.length, 1, 'the deleted credential is still in the history');
  assert.equal(result.findings[0].file, 'config.yml');
  assert.ok(result.stats.commitsScanned >= 2, `scanned ${result.stats.commitsScanned} commits`);
  assert.equal(result.findings[0].metadata.masked.includes(AWS_KEY), false, 'the preview is masked');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the parser is incremental — no full diff is ever held', () => {
  // The property the fix depends on. Fed a line at a time, it must produce the
  // same findings as the whole-string API; if it needed the full text it could
  // not stream.
  const lines = diffFor([`+aws_key: ${AWS_KEY}`]).split('\n');
  const p = createDiffParser('repo');
  for (const line of lines) p.pushLine(line);

  assert.equal(p.findings.length, 1);
  assert.equal(p.commitCount, 1);
});
