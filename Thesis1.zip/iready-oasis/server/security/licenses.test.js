'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { normaliseLicense, categoryOf, evaluate, chooseGoverning, inventory, DEFAULT_POLICY } = require('./licenses');

// ── Normalisation ──────────────────────────────────────────────────────────
//
// The same licence is written four different ways across four POMs. Grouping
// those as one licence is most of the job.

test('the many spellings of Apache 2 collapse to one identifier', () => {
  for (const text of [
    'Apache License, Version 2.0',
    'The Apache Software License, Version 2.0',
    'Apache 2',
    'Apache-2.0',
    'apache license v2',
  ]) {
    assert.equal(normaliseLicense(text), 'Apache-2.0', `failed on: ${text}`);
  }
});

test('MIT and BSD variants are recognised', () => {
  assert.equal(normaliseLicense('MIT License'), 'MIT');
  assert.equal(normaliseLicense('The MIT License (MIT)'), 'MIT');
  assert.equal(normaliseLicense('BSD 3-Clause License'), 'BSD-3-Clause');
  assert.equal(normaliseLicense('Simplified BSD'), 'BSD-2-Clause');
  assert.equal(normaliseLicense('ISC'), 'ISC');
});

test('AGPL is never mistaken for GPL', () => {
  // The single most consequential distinction in the table: AGPL triggers on
  // network use, which a hosted product does by definition.
  assert.equal(normaliseLicense('GNU Affero General Public License v3'), 'AGPL-3.0');
  assert.equal(normaliseLicense('AGPL-3.0'), 'AGPL-3.0');
  assert.equal(categoryOf(normaliseLicense('AGPL-3.0')), 'network-copyleft');
  assert.equal(categoryOf(normaliseLicense('GPL-3.0')), 'strong-copyleft');
});

test('the GPL classpath exception is not plain GPL', () => {
  // Ubiquitous in the Java ecosystem, and a materially weaker obligation.
  // Collapsing it into GPL would flag half a Spring dependency tree as a
  // strong-copyleft problem.
  for (const text of ['GPL2 w/ CPE', 'GNU General Public License, version 2 with the GNU Classpath Exception']) {
    assert.equal(normaliseLicense(text), 'GPL-2.0-with-classpath-exception', `failed on: ${text}`);
    assert.equal(categoryOf(normaliseLicense(text)), 'weak-copyleft');
  }
});

test('Eclipse, Mozilla and CDDL are weak copyleft', () => {
  for (const text of ['Eclipse Public License - v 1.0', 'Mozilla Public License 2.0', 'CDDL 1.1']) {
    assert.equal(categoryOf(normaliseLicense(text)), 'weak-copyleft', `failed on: ${text}`);
  }
});

test('the Eclipse DISTRIBUTION licence is not the Eclipse PUBLIC licence', () => {
  // EDL 1.0 is BSD-3-Clause word for word — permissive, nothing to review. It
  // arrives in any Spring tree through jakarta.xml.bind-api, and reading it as
  // an unidentified licence raised a MEDIUM "unknown licence" finding on a
  // dependency that states its terms plainly.
  for (const text of ['Eclipse Distribution License - v 1.0', 'Eclipse Distribution License v. 1.0', 'EDL 1.0']) {
    assert.equal(normaliseLicense(text), 'BSD-3-Clause', `failed on: ${text}`);
    assert.equal(categoryOf(normaliseLicense(text)), 'permissive', `failed on: ${text}`);
  }
});

test('the Eclipse and Mozilla version numbers survive the words between', () => {
  // "Eclipse Public License v. 2.0" spells eleven characters between "Public"
  // and the version, which a narrower gap missed — so EPL-2.0 was reported as
  // EPL-1.0. Same obligation, wrong licence on the record and in the inventory.
  assert.equal(normaliseLicense('Eclipse Public License v. 2.0'), 'EPL-2.0');
  assert.equal(normaliseLicense('Eclipse Public License, Version 2.0'), 'EPL-2.0');
  assert.equal(normaliseLicense('Eclipse Public License - v 1.0'), 'EPL-1.0');
  assert.equal(normaliseLicense('Mozilla Public License, Version 2.0'), 'MPL-2.0');
});

test('an SPDX expression takes its first term', () => {
  // "MIT OR Apache-2.0" means the consumer may pick either.
  assert.equal(normaliseLicense('MIT OR Apache-2.0'), 'MIT');
  assert.equal(normaliseLicense('(MIT OR CC0-1.0)'), 'MIT');
});

test('unhelpful placeholders read as unknown, not as a licence', () => {
  for (const text of ['UNKNOWN', 'See LICENSE', 'N/A', 'none', '', null, undefined]) {
    assert.equal(normaliseLicense(text), null, `failed on: ${text}`);
  }
});

// ── Policy ─────────────────────────────────────────────────────────────────

test('permissive licences are allowed without a finding', () => {
  for (const text of ['MIT', 'Apache-2.0', 'BSD-3-Clause', 'ISC']) {
    const result = evaluate(text);
    assert.equal(result.action, 'allow', `${text} should be allowed`);
    assert.equal(result.severity, null);
  }
});

test('AGPL is the highest concern for a distributed product', () => {
  const result = evaluate('AGPL-3.0');
  assert.equal(result.severity, 'CRITICAL');
  assert.equal(result.action, 'review');
  assert.match(result.reason, /network/i);
});

test('an unidentifiable licence is not treated as benign', () => {
  // A dependency nobody has assessed is not a dependency that is fine.
  const result = evaluate('Some Bespoke Terms v4');
  assert.equal(result.category, 'unknown');
  assert.equal(result.severity, 'MEDIUM');
  assert.equal(result.action, 'review');
});

test('the policy is configurable', () => {
  const relaxed = { ...DEFAULT_POLICY, 'strong-copyleft': { severity: 'LOW', action: 'note', reason: 'internal only' } };
  assert.equal(evaluate('GPL-3.0').severity, 'HIGH');
  assert.equal(evaluate('GPL-3.0', relaxed).severity, 'LOW');
});

// ── Multiple licences ──────────────────────────────────────────────────────

test('a dual-licensed component is judged by its least restrictive option', () => {
  // Maven's convention: the consumer may choose. Reporting "GPL" for a
  // component also offered under Apache would be wrong.
  const governing = chooseGoverning(['GPL-2.0', 'Apache License, Version 2.0']);
  assert.equal(governing.spdx, 'Apache-2.0');
  assert.equal(governing.action, 'allow');
});

test('a component licensed only under AGPL is still flagged', () => {
  assert.equal(chooseGoverning(['GNU Affero General Public License']).severity, 'CRITICAL');
});

test('no declared licence resolves to unknown', () => {
  assert.equal(chooseGoverning([]).category, 'unknown');
  assert.equal(chooseGoverning(null).category, 'unknown');
});

// ── Inventory ──────────────────────────────────────────────────────────────

test('the inventory groups packages by licence, worst first', () => {
  const deps = [
    { name: 'a', version: '1', licenses: ['MIT'] },
    { name: 'b', version: '1', licenses: ['Apache-2.0'] },
    { name: 'c', version: '1', licenses: ['MIT'] },
    { name: 'd', version: '1', licenses: ['AGPL-3.0'] },
    { name: 'e', version: '1', licenses: [] },
  ];
  const result = inventory(deps);

  // The one that needs a decision is at the top, not buried under 300 MITs.
  assert.equal(result[0].license, 'UNKNOWN');
  assert.ok(result.slice(0, 2).some(r => r.license === 'AGPL-3.0'));
  assert.equal(result.find(r => r.license === 'MIT').count, 2);
  assert.deepEqual(result.find(r => r.license === 'MIT').packages, ['a@1', 'c@1']);
});

test('the package list per licence is capped but the count is not', () => {
  const deps = Array.from({ length: 120 }, (_, i) => ({ name: `p${i}`, version: '1', licenses: ['MIT'] }));
  const mit = inventory(deps)[0];
  assert.equal(mit.count, 120);
  assert.equal(mit.packages.length, 50);
});

test('an empty dependency list produces an empty inventory', () => {
  assert.deepEqual(inventory([]), []);
});
