'use strict';
const fs = require('fs');
const path = require('path');
const { createOrchestrator } = require('./orchestrator');
const { createSecurityRouter } = require('./routes');
const { scanner: builtinSecrets } = require('./scanners/secrets-builtin');
const { scanner: historySecrets } = require('./scanners/secrets-history');
const { scanner: astSast } = require('./scanners/sast-ast');
const { scanner: patternSast } = require('./scanners/pattern-sast');
const { scanner: iacPolicy } = require('./scanners/iac-policy');
const { scanner: sarifImport } = require('./scanners/sarif-import');
const { scanner: gitleaks } = require('./scanners/gitleaks');
const { scanner: semgrep } = require('./scanners/semgrep');
const { scanner: eslint } = require('./scanners/eslint');
const { scanner: syft } = require('./scanners/syft');
const { createScaScanner } = require('./scanners/sca');
const { scanner: lockfileSca } = require('./scanners/sca-lockfile');
const { scanner: mavenSca } = require('./scanners/sca-maven');
const { createSbomScanner } = require('./scanners/sbom-builtin');
const os = require('os');
const { createRuleSyncFromEnv, DEFAULT_URL: DEFAULT_RULES_URL } = require('./rule-sync');
const { createEngineLoader } = require('./engine-loader');
const { createRulesUpdater } = require('./rules-updates');
const { createOverrides } = require('./overrides');
const { createRulesView } = require('./rules-view');
const { DEFAULT_DIR } = require('./store');
const { USER_RULES_DIR, USER_GRAMMARS_DIR } = require('./paths');
const { setUserRulesDir } = require('./local-rules');
const { loadPlugins } = require('./ast/engine');

// 'stable' unless a tester asks for the beta channel. The value is trimmed and lowercased ("Beta " works); anything
// else still reaches update(), which refuses it with BAD_CHANNEL and the allowed values (it is logged, not a crash).
function resolveChannel(value) {
  const channel = value === undefined || value === null ? '' : String(value).trim().toLowerCase();
  return channel || undefined;
}

// The installed-rules engine parts: the loader, its updater (not started) and the overrides.
function createInstalledEngine({ env = process.env, dir = path.join(os.homedir(), '.oasis-security', 'rules'), log = console.log, ...options } = {}) {
  const loader = createEngineLoader({ dir, baseUrl: env.OASIS_RULE_SERVER_URL || DEFAULT_RULES_URL, channel: resolveChannel(env.OASIS_RULES_CHANNEL), log, ...options });
  return { loader, updater: createRulesUpdater({ loader, log }), overrides: createOverrides() };
}

// One call wires the security tab into the Express app, keeping
// server/index.js to two lines.
//
// Scanner order matters only for readability in the UI; the orchestrator runs
// them sequentially and deduplication makes the outcome order-independent.

function installSecurity(app, { loadVersionWatchRows, resolveRepoPath, listRepositories, appVersion = null, log = console.log } = {}) {
  // Every capability is covered by a scanner that ships with the app and runs
  // on plain Node, so a fresh install on Windows, macOS, or Linux has full
  // coverage with nothing to download.
  //
  // The external adapters stay in the list because a developer who already has
  // Semgrep gets a second opinion for free, and two scanners agreeing on one
  // finding is what the correlation engine is for. They are strictly additive:
  // when absent they report unavailable and the scan is unaffected.
  setUserRulesDir(USER_RULES_DIR);
  loadPlugins(USER_GRAMMARS_DIR);

  const scanners = [
    builtinSecrets,                                              // bundled
    historySecrets,                                              // bundled (uses git)
    astSast,                                                     // bundled (tree-sitter + signed rule bundle)
    patternSast,                                                 // bundled (line rules: IaC, config)
    iacPolicy,                                                   // bundled (structured Terraform/K8s policies)
    lockfileSca,                                                 // bundled (lockfile tree)
    mavenSca,                                                    // bundled (resolved Maven tree)
    createScaScanner({ loadRows: loadVersionWatchRows }),        // bundled (declared)
    createSbomScanner({ loadRows: loadVersionWatchRows, appVersion }), // bundled
    // Last of the bundled scanners: it contributes findings other tools
    // produced, and reading them after our own keeps the dedup direction
    // stable — an imported finding merges into ours rather than the reverse.
    sarifImport,                                                 // bundled (ingests other tools' SARIF)
    gitleaks,                                                    // optional
    semgrep,                                                     // optional
    eslint,                                                      // optional
    syft,                                                        // optional
  ];

  // Rules come from the signed releases of the rules service (OASIS_RULE_SERVER_URL), downloaded once into
  // ~/.oasis-security/rules and refreshed on launch and every six hours; scans run on the installed copy, so they
  // work offline after the first download. There is no built-in copy: with nothing installed and the service
  // unreachable a scan is refused with a clear message. Findings stay in this machine's own store.
  // Ruling 26: the installed-rules path is OPT-IN (OASIS_ENGINE=installed) until a real core pack is published and the
  // two public keys are pinned (PINNED_KEYS is empty, so it cannot install anything yet). Without it, scans keep the
  // previous behaviour (rule server per scan, bundled worker pool, rule-server findings). Task 16 makes it the default.
  let orchestrator;
  let updater = null;
  if (process.env.OASIS_ENGINE !== 'installed') {
    const ruleSync = createRuleSyncFromEnv(process.env, { dir: DEFAULT_DIR, log });
    orchestrator = createOrchestrator({ scanners, log, ruleSync });
  } else {
    const installed = createInstalledEngine({ env: process.env, log });
    updater = installed.updater;
    const { overrides } = installed;
    orchestrator = createOrchestrator({ scanners, log, loader: updater.loader, overrides });
    orchestrator.rulesUpdater = updater;
    orchestrator.rulesView = createRulesView({ loader: updater.loader, updater, overrides });
    updater.start();                    // not awaited: startup must not wait for the network; failures are logged
  }

  // Anything a previous run could not deliver (the rule server was down) goes out
  // now, without blocking startup.
  orchestrator.flushPending().then(
    r => { if (r.delivered || r.remaining || r.rejected) log(`security: outbox - delivered ${r.delivered}, waiting ${r.remaining}, rejected ${r.rejected}`); },
    e => log(`security: could not flush the outbox: ${e.message}`)
  );
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath, listRepositories, appVersion }));
  return orchestrator;
}

// App shutdown: stop what installSecurity started (today the rules update timer).
function stopSecurity(orchestrator) {
  if (orchestrator && orchestrator.rulesUpdater) orchestrator.rulesUpdater.stop();
}

module.exports = { installSecurity, stopSecurity, createOrchestrator, createInstalledEngine, resolveChannel };