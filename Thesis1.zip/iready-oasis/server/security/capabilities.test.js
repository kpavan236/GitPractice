'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { CAPABILITIES, STATUS, byCategory, summary, find } = require('./capabilities');

const HERE = __dirname;

// These are the tests that make the register worth keeping. A capability list
// nobody verifies becomes the optimistic README that everyone stops believing
// after three months; these assertions are what stop that happening.

test('every capability has a unique id', () => {
  const ids = CAPABILITIES.map(c => c.id);
  assert.equal(new Set(ids).size, ids.length, 'duplicate capability id');
});

test('every capability has a known status', () => {
  const valid = new Set(Object.values(STATUS));
  for (const c of CAPABILITIES) {
    assert.ok(valid.has(c.status), `${c.id} has status "${c.status}"`);
  }
});

test('a capability claiming to be implemented names a module that exists', () => {
  // The core assertion. Marking something implemented without pointing at real
  // code is how a register starts lying.
  for (const c of CAPABILITIES) {
    if (c.status !== STATUS.IMPLEMENTED && c.status !== STATUS.PARTIAL) continue;
    assert.ok(c.module, `${c.id} is ${c.status} but names no module`);
    assert.ok(fs.existsSync(path.join(HERE, c.module)), `${c.id} names a missing module: ${c.module}`);
  }
});

test('a module named by the register actually exports something', () => {
  for (const c of CAPABILITIES) {
    if (!c.module) continue;
    const exported = require(path.join(HERE, c.module));
    assert.ok(exported && Object.keys(exported).length, `${c.module} exports nothing`);
  }
});

test('an unbuilt capability does not claim a module', () => {
  // The inverse mistake: leaving a module path behind after downgrading a row,
  // which reads as though the code exists.
  for (const c of CAPABILITIES) {
    if (c.status === STATUS.PLANNED || c.status === STATUS.DECLINED) {
      assert.equal(c.module, undefined, `${c.id} is ${c.status} but names ${c.module}`);
    }
  }
});

test('a declined capability records why', () => {
  // "We are not doing this" is a decision, and a decision without a reason gets
  // re-litigated every few months.
  for (const c of CAPABILITIES.filter(c => c.status === STATUS.DECLINED)) {
    assert.ok(c.why && c.why.length > 20, `${c.id} is declined with no real reason`);
  }
});

test('a partial capability records what it does not cover', () => {
  // The distinction the whole product rests on: partial coverage stated is
  // useful, partial coverage implied to be complete is a lie.
  for (const c of CAPABILITIES.filter(c => c.status === STATUS.PARTIAL)) {
    assert.ok(c.limits && c.limits.length > 10, `${c.id} is partial but does not say what is missing`);
  }
});

test('a capability delegated to an external tool says which and why', () => {
  for (const c of CAPABILITIES.filter(c => c.status === STATUS.EXTERNAL)) {
    assert.ok(c.why && c.why.length > 20, `${c.id} is external with no rationale`);
  }
});

test('every capability belongs to a numbered category', () => {
  for (const c of CAPABILITIES) {
    assert.ok(Number.isInteger(c.category) && c.category >= 1 && c.category <= 24, `${c.id} category ${c.category}`);
  }
});

test('grouping and lookup work', () => {
  const groups = byCategory();
  assert.ok(groups.length > 1);
  assert.deepEqual(groups.map(g => g.category), [...groups.map(g => g.category)].sort((a, b) => a - b));
  assert.equal(find('sast').name, 'SAST');
  assert.equal(find('nope'), null);
});

test('the summary adds up', () => {
  const s = summary();
  const counted = Object.entries(s).filter(([k]) => k !== 'total').reduce((n, [, v]) => n + v, 0);
  assert.equal(counted, s.total);
});

test('the register reflects what is actually built', () => {
  // Spot checks against reality, so a refactor that removes a feature fails
  // here rather than leaving the register overstating the product.
  assert.equal(find('sarif-export').status, STATUS.IMPLEMENTED);
  assert.equal(find('sarif-import').status, STATUS.IMPLEMENTED);
  assert.equal(find('auth-rbac').status, STATUS.DECLINED);
  assert.equal(find('reachability').status, STATUS.PLANNED);
  // IaC detection is ours; the rest of §5-9 is delegated to tools that already
  // do it and reaches us through SARIF ingestion.
  assert.equal(find('iac-scanning').status, STATUS.PARTIAL);
  // A gate that blocks a build, and the git-diff scoping it depends on.
  assert.equal(find('policies').status, STATUS.IMPLEMENTED);
  assert.equal(find('container-scanning').status, STATUS.EXTERNAL);
});
