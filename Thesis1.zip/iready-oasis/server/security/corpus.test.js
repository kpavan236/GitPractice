'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { forEachFile, runCorpusScanners } = require('./corpus');

// One pass over the repository, shared by every content scanner.
//
// Four scanners each walked the tree themselves and each read every file, so a
// scan walked the same directories four times and read the same bytes four
// times. The walk was already shared code — it was just being RUN four times.
//
// The properties that matter here are all about not paying twice, and about
// paying nothing at all for files nobody asked for.

function repo(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-corpus-'));
  for (const [name, content] of Object.entries(files)) {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  return dir;
}

test('visits every scannable file once', async () => {
  const dir = repo({ 'a.js': 'const a = 1;', 'src/b.py': 'x = 2', 'README.md': '# hi' });
  const seen = [];
  await forEachFile(dir, {}, f => seen.push(f.relPath));

  assert.deepEqual(seen.sort(), ['README.md', 'a.js', 'src/b.py']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('paths are POSIX-relative, on every platform', async () => {
  // A Windows separator here would fingerprint the same finding differently
  // from the same scan run on a Mac, splitting one issue into two.
  const dir = repo({ 'src/deep/nested.js': 'x' });
  const seen = [];
  await forEachFile(dir, {}, f => seen.push(f.relPath));

  assert.deepEqual(seen, ['src/deep/nested.js']);
  assert.equal(seen[0].includes('\\'), false);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('reads a file once no matter how many consumers ask for it', async () => {
  // The entire point. Four scanners asking for the same file must cost one read.
  const dir = repo({ 'a.js': 'const secret = 1;' });
  let reads = 0;
  const realRead = fs.readFileSync;
  fs.readFileSync = (...args) => { reads++; return realRead(...args); };

  try {
    await forEachFile(dir, {}, f => {
      f.text; f.text; f.text; f.text;         // four consumers
    });
  } finally {
    fs.readFileSync = realRead;
  }

  assert.equal(reads, 1, `read ${reads} times, expected 1`);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a file nobody reads is never read', async () => {
  // pattern-sast skips files no rule glob matches, and called that "the whole
  // cost of this scanner". Sharing the walk must not take that back by eagerly
  // reading everything when only that scanner is running.
  const dir = repo({ 'a.js': 'x', 'b.js': 'y' });
  let reads = 0;
  const realRead = fs.readFileSync;
  fs.readFileSync = (...args) => { reads++; return realRead(...args); };

  try {
    await forEachFile(dir, {}, f => { if (f.relPath === 'a.js') f.text; });
  } finally {
    fs.readFileSync = realRead;
  }

  assert.equal(reads, 1, 'only the file that was asked for');
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Quick Scan's `files` restriction ────────────────────────────────────────

test('an explicit file list visits only those files, not the whole tree', async () => {
  const dir = repo({ 'a.js': 'x', 'b.js': 'y', 'src/c.js': 'z' });
  const seen = [];
  await forEachFile(dir, { files: ['a.js', 'src/c.js'] }, f => seen.push(f.relPath));

  assert.deepEqual(seen.sort(), ['a.js', 'src/c.js']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('an empty file list visits nothing — never falls back to the full walk', async () => {
  // Quick scan on a branch with no changes must scan zero files, not silently
  // do a full scan because an empty list looked like "no restriction".
  const dir = repo({ 'a.js': 'x' });
  const seen = [];
  await forEachFile(dir, { files: [] }, f => seen.push(f.relPath));

  assert.deepEqual(seen, []);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a file list entry that no longer exists is skipped, not an error', async () => {
  // The diff was taken before the walk; a file can be renamed or deleted
  // between the two without this being a bug in either.
  const dir = repo({ 'a.js': 'x' });
  const seen = [];
  await forEachFile(dir, { files: ['a.js', 'gone.js'] }, f => seen.push(f.relPath));

  assert.deepEqual(seen, ['a.js']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a file list entry inside a skipped directory is still skipped', async () => {
  const dir = repo({ 'node_modules/dep/index.js': 'x', 'a.js': 'y' });
  const seen = [];
  await forEachFile(dir, { files: ['node_modules/dep/index.js', 'a.js'] }, f => seen.push(f.relPath));

  assert.deepEqual(seen, ['a.js']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the content hash is stable and computed once', async () => {
  // This is what the incremental cache keys on, so it has to be the content and
  // nothing else — not the path, not the mtime.
  const dir = repo({ 'a.js': 'same', 'b.js': 'same', 'c.js': 'different' });
  const hashes = {};
  await forEachFile(dir, {}, f => { hashes[f.relPath] = f.sha256; });

  assert.equal(hashes['a.js'], hashes['b.js'], 'identical content, identical hash');
  assert.notEqual(hashes['a.js'], hashes['c.js']);
  assert.match(hashes['a.js'], /^[0-9a-f]{64}$/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('size is available without reading the file', async () => {
  // So a scanner can apply its own cap — 1MB for the AST parser, 2MB for
  // secrets — before anything is read.
  const dir = repo({ 'big.js': 'x'.repeat(5000) });
  let reads = 0;
  const realRead = fs.readFileSync;
  fs.readFileSync = (...args) => { reads++; return realRead(...args); };

  try {
    await forEachFile(dir, {}, f => { assert.equal(f.size, 5000); });
  } finally {
    fs.readFileSync = realRead;
  }
  assert.equal(reads, 0, 'checking a size must not cost a read');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('skips the directories and binaries the scanners already skipped', async () => {
  const dir = repo({
    'app.js': 'x',
    'node_modules/dep/index.js': 'x',
    '.git/config': 'x',
    'target/out.class': 'x',
    'logo.png': 'x',
    'yarn.lock': 'x',
  });
  const seen = [];
  await forEachFile(dir, {}, f => seen.push(f.relPath));

  assert.deepEqual(seen, ['app.js'], `also visited: ${seen.filter(s => s !== 'app.js')}`);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('binary content is flagged rather than silently dropped', async () => {
  // secrets-builtin skips binaries; pattern-sast never did. The corpus reports
  // the fact and lets each scanner keep its own behaviour, because changing one
  // scanner's coverage while speeding up another is not a refactor.
  const dir = repo({ 'data.txt': 'text\0with a null byte' });
  let flagged = null;
  await forEachFile(dir, {}, f => { flagged = f.binary; });

  assert.equal(flagged, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('an unreadable file is skipped, not fatal', async () => {
  const dir = repo({ 'ok.js': 'x' });
  const seen = [];
  // A path that vanishes between the walk and the read — a build running
  // alongside the scan does this constantly.
  await forEachFile(dir, {}, f => {
    fs.rmSync(path.join(dir, 'ok.js'));
    assert.equal(f.text, null, 'a vanished file reads as null, not a throw');
    seen.push(f.relPath);
  });
  assert.deepEqual(seen, ['ok.js']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the file budget is reported when it stops the walk', async () => {
  const dir = repo(Object.fromEntries(Array.from({ length: 10 }, (_, i) => [`f${i}.js`, 'x'])));
  const seen = [];
  const stats = await forEachFile(dir, { maxFiles: 4 }, f => seen.push(f.relPath));

  assert.equal(seen.length, 4);
  assert.equal(stats.truncated, true);
  assert.match(stats.truncatedReason, /OASIS_SCAN_MAX_FILES/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('counts the work it actually did', async () => {
  const dir = repo({ 'a.js': 'x', 'b.js': 'y', 'c.js': 'z' });
  const stats = await forEachFile(dir, {}, f => { if (f.relPath !== 'c.js') f.text; });

  assert.equal(stats.filesVisited, 3);
  assert.equal(stats.filesRead, 2, 'one file was never asked for');
  assert.ok(stats.bytesRead > 0);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Progress ───────────────────────────────────────────────────────────────
//
// A scan of a large repository runs for minutes with nothing on screen but a
// repository name, which is indistinguishable from a scan that has hung. What a
// reader needs is the file being looked at and how far through the tree it is —
// and the second one requires knowing the denominator, so the walk counts first
// and reports against a real total rather than an animated guess.

test('progress reports the file being scanned and how many are done', async () => {
  const dir = repo({ 'a.js': 'x', 'b.js': 'y', 'src/c.py': 'z' });
  const seen = [];
  await forEachFile(dir, { onProgress: p => seen.push(p) }, () => {});

  assert.equal(seen.length, 3, 'one report per file');
  assert.deepEqual(seen.map(p => p.filesScanned), [1, 2, 3]);
  // Every report carries the total, so a bar can be drawn from the first one.
  assert.deepEqual([...new Set(seen.map(p => p.filesTotal))], [3]);
  assert.ok(seen.every(p => typeof p.file === 'string' && p.file.length));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('counting the files costs no reads', async () => {
  // The denominator is worth one extra pass over the directory entries. It is
  // not worth reading the repository twice.
  const dir = repo({ 'a.js': 'x'.repeat(100), 'b.js': 'y' });
  let reads = 0;
  const realRead = fs.readFileSync;
  fs.readFileSync = (...args) => { reads++; return realRead(...args); };

  try {
    await forEachFile(dir, { onProgress: () => {} }, () => {});
  } finally {
    fs.readFileSync = realRead;
  }

  assert.equal(reads, 0, 'nothing was asked for, so nothing should have been read');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the total respects the file budget rather than promising more', async () => {
  const dir = repo(Object.fromEntries(Array.from({ length: 10 }, (_, i) => [`f${i}.js`, 'x'])));
  const seen = [];
  await forEachFile(dir, { maxFiles: 4, onProgress: p => seen.push(p) }, () => {});

  assert.equal(seen.length, 4);
  assert.equal(seen[seen.length - 1].filesTotal, 4, 'a bar must not stall at 40% because the cap cut the walk short');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a walk with no progress consumer counts nothing', async () => {
  // The pre-count exists for the progress bar. A scanner running standalone —
  // and every test above — must not pay for a bar nobody is watching.
  const dir = repo({ 'a.js': 'x' });
  let walks = 0;
  const realReaddir = fs.readdirSync;
  fs.readdirSync = (...args) => { walks++; return realReaddir(...args); };

  try {
    await forEachFile(dir, {}, () => {});
  } finally {
    fs.readdirSync = realReaddir;
  }

  assert.equal(walks, 1, 'one pass over the tree, not two');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('every scanner in a shared pass sees one progress stream', async () => {
  const dir = repo({ 'a.js': 'x', 'b.js': 'y' });
  const seen = [];
  const noop = {
    id: 'A', prepare: () => ({}), scanFile: () => [], finish: () => ({}),
  };
  await runCorpusScanners([noop, { ...noop, id: 'B' }], {
    repoPath: dir, repository: 'r', dir, onProgress: p => seen.push(p.filesScanned),
  });

  assert.deepEqual(seen, [1, 2], 'two scanners share one walk, so one report per file');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a missing repository is an error, not an empty clean scan', async () => {
  // Zero findings from a path that does not exist is the most dangerous
  // possible result: it looks exactly like a clean repository.
  await assert.rejects(() => forEachFile('/nonexistent/repo/path', {}, () => {}), /does not exist/);
});
