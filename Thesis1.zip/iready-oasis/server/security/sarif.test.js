'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { toSarif, LEVELS, SECURITY_SEVERITY, VERSION } = require('./sarif');
const { createFinding } = require('./finding');
const { scoreFinding } = require('./risk');

function finding(overrides = {}) {
  const { metadata = {}, risk, status, fingerprint, ...rest } = overrides;
  const f = createFinding({
    type: 'SAST',
    category: 'SQL_INJECTION',
    severity: 'HIGH',
    title: 'SQL query built by string concatenation',
    description: 'User input reaches a database query.',
    repository: 'iready-core',
    file: 'src/Repo.java',
    startLine: 42,
    cwe: 'CWE-89',
    source: 'BUILTIN_SAST',
    ruleId: 'java-sql-injection',
    remediation: 'Use a parameterised query.',
    metadata,
    ...rest,
  });
  f.fingerprint = fingerprint || 'fp-1';
  f.risk = risk || scoreFinding(f, { criticality: 'HIGH', environment: 'production' });
  if (status) f.status = status;
  return f;
}

const run = doc => doc.runs[0];

// ── Shape ──────────────────────────────────────────────────────────────────

test('the document declares SARIF 2.1.0 with a schema', () => {
  const doc = toSarif([finding()]);
  assert.equal(doc.version, VERSION);
  assert.match(doc.$schema, /sarif-schema-2\.1\.0\.json$/);
  assert.equal(doc.runs.length, 1);
});

test('the tool driver names itself and its version', () => {
  const driver = run(toSarif([finding()], { toolVersion: '1.1.4' })).tool.driver;
  assert.equal(driver.version, '1.1.4');
  assert.match(driver.name, /OASIS/);
});

test('each distinct rule appears once and results index into it', () => {
  const doc = toSarif([finding({ fingerprint: 'a' }), finding({ fingerprint: 'b' })]);
  assert.equal(run(doc).tool.driver.rules.length, 1);
  assert.equal(run(doc).results.length, 2);
  for (const result of run(doc).results) {
    assert.equal(run(doc).tool.driver.rules[result.ruleIndex].id, result.ruleId);
  }
});

test('the location carries file and line', () => {
  const loc = run(toSarif([finding()])).results[0].locations[0].physicalLocation;
  assert.equal(loc.artifactLocation.uri, 'src/Repo.java');
  assert.equal(loc.region.startLine, 42);
});

test('a finding with no file still gets a location', () => {
  // An SCA advisory has no source line. Consumers drop results with no
  // location, so the lockfile stands in for one.
  const sca = finding({
    type: 'SCA', category: 'VULNERABLE_DEPENDENCY', file: null, startLine: null,
    source: 'LOCKFILE_SCA', ruleId: 'CVE-2021-44228',
    metadata: { lockfile: 'package-lock.json', transitive: true },
  });
  const loc = run(toSarif([sca])).results[0].locations[0].physicalLocation;
  assert.equal(loc.artifactLocation.uri, 'package-lock.json');
});

// ── The two details that make it useful ────────────────────────────────────

test('severity survives as security-severity, not just a level', () => {
  // Without this GitHub files every alert as "warning" and the whole risk model
  // is thrown away at the boundary.
  const rules = run(toSarif([finding({ severity: 'CRITICAL' })])).tool.driver.rules;
  assert.equal(rules[0].properties['security-severity'], SECURITY_SEVERITY.CRITICAL);
  assert.equal(rules[0].defaultConfiguration.level, 'error');
});

test('our stable fingerprint is exported as a partialFingerprint', () => {
  // This is what stops a consumer closing and reopening every alert when a file
  // is reformatted.
  const result = run(toSarif([finding({ fingerprint: 'abc123' })])).results[0];
  assert.equal(result.partialFingerprints.oasisFingerprint, 'abc123');
});

test('severity maps onto the four SARIF levels', () => {
  assert.equal(LEVELS.CRITICAL, 'error');
  assert.equal(LEVELS.HIGH, 'error');
  assert.equal(LEVELS.MEDIUM, 'warning');
  assert.equal(LEVELS.LOW, 'note');
  assert.equal(LEVELS.INFO, 'note');
});

// ── Triage travels with the findings ───────────────────────────────────────

test('a suppressed finding is exported as suppressed, not dropped', () => {
  const f = finding({ status: 'SUPPRESSED' });
  f.suppression = { reason: 'accepted for Q3', owner: 'sec-team' };
  const result = run(toSarif([f])).results[0];

  assert.equal(result.suppressions.length, 1);
  assert.equal(result.suppressions[0].justification, 'accepted for Q3');
});

test('a false positive carries a justification even with no reason recorded', () => {
  const result = run(toSarif([finding({ status: 'FALSE_POSITIVE' })])).results[0];
  assert.match(result.suppressions[0].justification, /false positive/i);
});

test('an open finding has no suppressions key', () => {
  assert.equal(run(toSarif([finding()])).results[0].suppressions, undefined);
});

// ── Properties a consumer can act on ───────────────────────────────────────

test('risk score and priority travel in properties', () => {
  const props = run(toSarif([finding()])).results[0].properties;
  assert.equal(typeof props.riskScore, 'number');
  assert.match(props.riskPriority, /^P[0-4]$/);
});

test('every detecting scanner is listed', () => {
  // A finding corroborated by two engines is worth more than one, and that is
  // invisible unless it is exported.
  const f = finding();
  f.detections.push({ source: 'SEMGREP', ruleId: 'java.sqli', detectedAt: null });
  assert.deepEqual(run(toSarif([f])).results[0].properties.detectedBy, ['BUILTIN_SAST', 'SEMGREP']);
});

test('CWE becomes a GitHub-recognised tag', () => {
  const rule = run(toSarif([finding()])).tool.driver.rules[0];
  assert.ok(rule.properties.tags.includes('external/cwe/cwe-89'));
});

test('a transitive dependency is tagged as one', () => {
  const sca = finding({
    type: 'SCA', source: 'LOCKFILE_SCA', ruleId: 'CVE-2021-44228',
    metadata: { transitive: true, lockfile: 'package-lock.json' },
  });
  assert.ok(run(toSarif([sca])).tool.driver.rules[0].properties.tags.includes('transitive-dependency'));
});

test('a known-exploited vulnerability is tagged', () => {
  const kev = finding({ metadata: { knownExploited: true }, ruleId: 'CVE-2021-44228' });
  assert.ok(run(toSarif([kev])).tool.driver.rules[0].properties.tags.includes('known-exploited'));
});

test('rule precision reflects the engine confidence', () => {
  const low = finding({ metadata: { confidence: 'LOW' }, ruleId: 'java-ssrf' });
  assert.equal(run(toSarif([low])).tool.driver.rules[0].properties.precision, 'low');
});

// ── Degenerate input ───────────────────────────────────────────────────────

test('an empty finding list produces a valid empty run', () => {
  const doc = toSarif([]);
  assert.equal(run(doc).results.length, 0);
  assert.deepEqual(run(doc).tool.driver.rules, []);
});

test('null findings do not throw', () => {
  assert.equal(run(toSarif(null)).results.length, 0);
});

test('a finding with no ruleId still gets a stable rule id', () => {
  const f = finding({ ruleId: null });
  const result = run(toSarif([f])).results[0];
  assert.equal(result.ruleId, 'SAST/SQL_INJECTION');
});

test('the whole document serialises to JSON', () => {
  // undefined values are legal in JS objects and illegal in JSON; a consumer
  // gets the serialised form, so that is what must be checked.
  const doc = toSarif([finding(), finding({ status: 'SUPPRESSED', fingerprint: 'x' })]);
  const round = JSON.parse(JSON.stringify(doc));
  assert.equal(round.runs[0].results.length, 2);
});