'use strict';

// Licence identification, classification, and policy.
//
// The data was already being downloaded and thrown away: every Maven POM the
// resolver fetches carries a <licenses> block, and npm lockfiles often record a
// `license` field per package. Reading it costs nothing extra.
//
// What makes this non-trivial is that licence text is free-form. The same
// licence appears as "Apache License, Version 2.0", "The Apache Software
// License, Version 2.0", "Apache 2", and "Apache-2.0" across four POMs written
// by four people. Grouping those as one licence — and telling them apart from
// AGPL — is the whole job. Everything below normalises to an SPDX identifier
// first and reasons about that.
//
// A note on what this is not: licence obligations depend on how software is
// distributed, whether it is linked statically or dynamically, and whether it
// is offered as a service. That is a legal question. This flags what needs
// review and by whom; it does not give an answer.

// Free-text → SPDX. Ordered: the first pattern that matches wins, so more
// specific variants must precede their general forms (AGPL before GPL,
// GPL-with-classpath-exception before GPL).
const PATTERNS = [
  // Network copyleft — the one that matters most for a hosted product.
  [/\baffero\b|\bagpl\b/i, 'AGPL-3.0'],

  // Classpath exception makes GPL usable for a library; it is a materially
  // different obligation from plain GPL and must not collapse into it.
  [/gpl.{0,20}(classpath|cpe)\b|classpath.{0,20}exception/i, 'GPL-2.0-with-classpath-exception'],

  [/\blgpl\b|lesser general public/i, 'LGPL-3.0'],
  [/\bgpl\b|gnu general public/i, 'GPL-3.0'],

  [/apache/i, 'Apache-2.0'],
  [/\bmit\b/i, 'MIT'],
  [/bsd.{0,10}3|3.{0,10}clause bsd|new bsd|modified bsd/i, 'BSD-3-Clause'],
  [/bsd.{0,10}2|2.{0,10}clause bsd|simplified bsd|freebsd/i, 'BSD-2-Clause'],
  [/\bbsd\b/i, 'BSD-3-Clause'],
  [/\bisc\b/i, 'ISC'],

  // The Eclipse DISTRIBUTION Licence, which is BSD-3-Clause word for word and
  // has nothing in common with the Eclipse PUBLIC Licence beyond the first word.
  // It must be tested before the EPL patterns, and it arrives in any Spring
  // dependency tree through jakarta.xml.bind-api.
  [/eclipse distribution licen[cs]e|\bedl\b.{0,10}1/i, 'BSD-3-Clause'],

  // The gap before the version is wide enough for the words real POMs put
  // there — "License v. 2.0", "License, Version 2.0". At ten characters
  // "Eclipse Public License v. 2.0" fell through to the 1.0 pattern below and
  // was recorded as the wrong licence.
  [/eclipse public.{0,20}2\b|\bepl.{0,5}2/i, 'EPL-2.0'],
  [/eclipse public|\bepl\b/i, 'EPL-1.0'],
  [/mozilla public.{0,20}2\b|\bmpl.{0,5}2/i, 'MPL-2.0'],
  [/mozilla public|\bmpl\b/i, 'MPL-2.0'],
  [/\bcddl\b|common development and distribution/i, 'CDDL-1.1'],

  [/creative commons zero|\bcc0\b/i, 'CC0-1.0'],
  [/\bunlicense\b|public domain/i, 'Unlicense'],
  [/\bzlib\b/i, 'Zlib'],
  [/\bwtfpl\b/i, 'WTFPL'],
  [/bouncy castle/i, 'MIT'],
  [/\bproprietary\b|all rights reserved|commercial licen[cs]e/i, 'PROPRIETARY'],
];

// SPDX id → what obligations it carries. Categories, not verdicts.
const CATEGORIES = {
  'MIT': 'permissive',
  'Apache-2.0': 'permissive',
  'BSD-2-Clause': 'permissive',
  'BSD-3-Clause': 'permissive',
  'ISC': 'permissive',
  'Zlib': 'permissive',
  'CC0-1.0': 'public-domain',
  'Unlicense': 'public-domain',
  'WTFPL': 'public-domain',
  'LGPL-3.0': 'weak-copyleft',
  'MPL-2.0': 'weak-copyleft',
  'EPL-1.0': 'weak-copyleft',
  'EPL-2.0': 'weak-copyleft',
  'CDDL-1.1': 'weak-copyleft',
  'GPL-2.0-with-classpath-exception': 'weak-copyleft',
  'GPL-3.0': 'strong-copyleft',
  'AGPL-3.0': 'network-copyleft',
  'PROPRIETARY': 'proprietary',
};

// The default policy for a commercially distributed product, which is what
// OASIS is being built into. Severities reflect how much review each category
// needs — not a legal conclusion.
//
// AGPL is highest because its trigger is *offering the software over a
// network*, which a SaaS product does by definition; the usual "we only link
// to it" reasoning does not apply.
//
// Unknown is deliberately not benign. A dependency whose licence we could not
// read is one nobody has assessed, and treating that as fine is how an
// unreviewed obligation ships.
const DEFAULT_POLICY = {
  'network-copyleft': { severity: 'CRITICAL', action: 'review', reason: 'Offering this software over a network can require publishing your source.' },
  'strong-copyleft': { severity: 'HIGH', action: 'review', reason: 'Distributing a work built on this can require releasing it under the same licence.' },
  'proprietary': { severity: 'HIGH', action: 'review', reason: 'A commercial or all-rights-reserved licence needs a purchased entitlement.' },
  'weak-copyleft': { severity: 'LOW', action: 'note', reason: 'Modifications to the component itself must usually be published; linking is generally fine.' },
  'unknown': { severity: 'MEDIUM', action: 'review', reason: 'No licence could be determined, so the obligations are unassessed.' },
  'permissive': { severity: null, action: 'allow', reason: null },
  'public-domain': { severity: null, action: 'allow', reason: null },
};

/**
 * Free-text licence → SPDX identifier, or null when unrecognised.
 * Already-valid SPDX ids pass straight through.
 */
function normaliseLicense(text) {
  if (!text) return null;
  const raw = String(text).trim();
  if (!raw || /^(unknown|none|n\/?a|see licen[cs]e|other)$/i.test(raw)) return null;

  // SPDX expressions like "MIT OR Apache-2.0" — take the first term. Picking
  // one of several permitted licences is the licensee's choice, and the first
  // is conventionally the preferred one.
  const firstTerm = raw.split(/\s+(?:OR|AND)\s+/i)[0].replace(/[()]/g, '').trim();
  if (CATEGORIES[firstTerm]) return firstTerm;

  for (const [pattern, id] of PATTERNS) {
    if (pattern.test(firstTerm)) return id;
  }
  return null;
}

function categoryOf(spdxId) {
  if (!spdxId) return 'unknown';
  return CATEGORIES[spdxId] || 'unknown';
}

/**
 * Evaluates one licence against a policy.
 * Returns { spdx, category, action, severity, reason }.
 */
function evaluate(licenseText, policy = DEFAULT_POLICY) {
  const spdx = normaliseLicense(licenseText);
  const category = categoryOf(spdx);
  const rule = policy[category] || policy.unknown;

  return {
    spdx,
    category,
    action: rule.action,
    severity: rule.severity,
    reason: rule.reason,
    declared: licenseText || null,
  };
}

// A dependency may declare several licences. Maven's convention is that the
// consumer may choose any one of them, so the LEAST restrictive governs — a
// component offered under "GPL-2.0 or Apache-2.0" can be used under Apache-2.0,
// and flagging it as GPL would be wrong.
const RESTRICTION_ORDER = [
  'public-domain', 'permissive', 'weak-copyleft', 'strong-copyleft', 'network-copyleft', 'proprietary', 'unknown',
];

function chooseGoverning(licenseTexts, policy = DEFAULT_POLICY) {
  const evaluated = (licenseTexts || []).filter(Boolean).map(t => evaluate(t, policy));
  if (!evaluated.length) return evaluate(null, policy);

  return evaluated.reduce((best, current) =>
    RESTRICTION_ORDER.indexOf(current.category) < RESTRICTION_ORDER.indexOf(best.category) ? current : best
  );
}

/**
 * Groups dependencies by licence, for the inventory a procurement or audit
 * request actually asks for.
 *
 * @param {Array} dependencies  [{ name, version, licenses: [] }]
 */
function inventory(dependencies, policy = DEFAULT_POLICY) {
  const byLicense = new Map();

  for (const dep of dependencies || []) {
    const governing = chooseGoverning(dep.licenses, policy);
    const key = governing.spdx || 'UNKNOWN';
    const entry = byLicense.get(key) || {
      license: key,
      category: governing.category,
      action: governing.action,
      severity: governing.severity,
      count: 0,
      packages: [],
    };
    entry.count += 1;
    // Capped: an inventory listing 900 permissive packages is a wall of text,
    // and the count is what the reader needs.
    if (entry.packages.length < 50) entry.packages.push(`${dep.name}@${dep.version}`);
    byLicense.set(key, entry);
  }

  return [...byLicense.values()].sort(
    (a, b) => RESTRICTION_ORDER.indexOf(b.category) - RESTRICTION_ORDER.indexOf(a.category) || b.count - a.count
  );
}

module.exports = {
  normaliseLicense,
  categoryOf,
  evaluate,
  chooseGoverning,
  inventory,
  DEFAULT_POLICY,
  CATEGORIES,
  RESTRICTION_ORDER,
};
