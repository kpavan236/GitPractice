'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { verifySecret, verifyFindings, isEnabled, canVerify } = require('./secret-verify');
const { createFinding } = require('./finding');

const ON = { OASIS_SECRET_VERIFY: '1' };

function secretFinding(ruleId = 'github-pat', fingerprint = 'fp-1') {
  const f = createFinding({
    type: 'SECRET',
    category: 'GITHUB_PAT',
    severity: 'CRITICAL',
    title: 'GitHub personal access token',
    description: 'A token appears in source.',
    repository: 'repo-a',
    file: 'config.properties',
    source: 'BUILTIN_SECRETS',
    ruleId,
    metadata: { secretHash: 'abc', masked: 'ghp_****' },
  });
  f.fingerprint = fingerprint;
  return f;
}

const responder = (status, body = '') => async () => ({ status, body });

// ── Opt-in ─────────────────────────────────────────────────────────────────

test('verification is off unless explicitly enabled', () => {
  // It transmits a live credential. That has to be a decision someone made,
  // not a default they discover afterwards.
  assert.equal(isEnabled({}), false);
  assert.equal(isEnabled({ OASIS_SECRET_VERIFY: '0' }), false);
  assert.equal(isEnabled(ON), true);
});

test('with verification off, nothing is sent anywhere', async () => {
  let called = false;
  const result = await verifyFindings([secretFinding()], new Map([['fp-1', 'ghp_x']]), {
    env: {},
    fetch: async () => { called = true; return { status: 200 }; },
  });
  assert.equal(called, false);
  assert.equal(result.attempted, 0);
  assert.match(result.skipped, /disabled/);
});

// ── Interpreting the provider ──────────────────────────────────────────────

test('a 200 from GitHub means the token is live', async () => {
  const r = await verifySecret('github-pat', 'ghp_x', { fetch: responder(200, '{"login":"x"}') });
  assert.deepEqual([r.verified, r.state], [true, 'live']);
});

test('a 401 means the token was revoked', async () => {
  const r = await verifySecret('github-pat', 'ghp_x', { fetch: responder(401) });
  assert.deepEqual([r.verified, r.state], [true, 'revoked']);
});

test("Slack's 200-with-ok-false is read as revoked, not live", async () => {
  // Slack answers 200 for a dead token; going by status alone would call every
  // expired Slack token an active incident.
  const live = await verifySecret('slack-token', 'xoxb-x', { fetch: responder(200, '{"ok":true}') });
  const dead = await verifySecret('slack-token', 'xoxb-x', { fetch: responder(200, '{"ok":false,"error":"invalid_auth"}') });
  assert.equal(live.state, 'live');
  assert.equal(dead.state, 'revoked');
});

test('a Google key that is accepted but misused reads as live', async () => {
  const live = await verifySecret('google-api-key', 'AIza-x', { fetch: responder(400, 'bad request') });
  const dead = await verifySecret('google-api-key', 'AIza-x', { fetch: responder(403, '{"reason":"API_KEY_INVALID"}') });
  assert.equal(live.state, 'live');
  assert.equal(dead.state, 'revoked');
});

test('a rate limit or outage is unknown, never revoked', async () => {
  // A false "revoked" retires a live key in someone's head. Silence must stay
  // silence.
  for (const status of [429, 500, 503, 0]) {
    const r = await verifySecret('github-pat', 'ghp_x', { fetch: responder(status) });
    assert.equal(r.state, 'unknown', `status ${status} must be unknown`);
    assert.equal(r.verified, false);
  }
});

test('a rule with no probe is unknown rather than assumed safe', async () => {
  assert.equal(canVerify('private-key'), false);
  const r = await verifySecret('private-key', '-----BEGIN', { fetch: responder(200) });
  assert.equal(r.state, 'unknown');
});

// ── Effect on findings ─────────────────────────────────────────────────────

test('a live credential becomes CRITICAL and says so', async () => {
  const f = secretFinding();
  const result = await verifyFindings([f], new Map([['fp-1', 'ghp_x']]), { env: ON, fetch: responder(200, '{"login":"x"}') });

  assert.equal(result.live, 1);
  assert.equal(f.severity, 'CRITICAL');
  assert.match(f.title, /VERIFIED LIVE/);
  assert.equal(f.metadata.verified, true);
  assert.equal(f.metadata.verificationProvider, 'GitHub');
});

test('a revoked credential drops to LOW instead of cluttering the queue', async () => {
  // Still worth removing; not an incident. Leaving it CRITICAL is how a real
  // leak gets lost among historical ones.
  const f = secretFinding();
  const result = await verifyFindings([f], new Map([['fp-1', 'ghp_x']]), { env: ON, fetch: responder(401) });

  assert.equal(result.revoked, 1);
  assert.equal(f.severity, 'LOW');
  assert.equal(f.metadata.verified, false);
  assert.equal(f.metadata.verificationState, 'revoked');
  assert.match(f.description, /no longer valid/);
});

test('an unverifiable credential keeps its original severity', async () => {
  const f = secretFinding();
  const before = f.severity;
  await verifyFindings([f], new Map([['fp-1', 'ghp_x']]), { env: ON, fetch: responder(500) });
  assert.equal(f.severity, before);
  assert.equal(f.metadata.verificationState, 'unknown');
});

test('a finding whose secret we no longer hold is skipped', async () => {
  // The plaintext is deliberately never stored, so verification is only
  // possible during the scan that found it.
  const result = await verifyFindings([secretFinding()], new Map(), { env: ON, fetch: responder(200) });
  assert.equal(result.attempted, 0);
});

test('non-secret findings are ignored', async () => {
  const sca = createFinding({
    type: 'SCA', category: 'VULNERABLE_DEPENDENCY', severity: 'HIGH', title: 'CVE-1',
    repository: 'r', source: 'LOCKFILE_SCA', ruleId: 'CVE-1',
  });
  sca.fingerprint = 'fp-1';
  const result = await verifyFindings([sca], new Map([['fp-1', 'x']]), { env: ON, fetch: responder(200) });
  assert.equal(result.attempted, 0);
});

test('the plaintext never lands on the finding during verification', async () => {
  const f = secretFinding();
  await verifyFindings([f], new Map([['fp-1', 'ghp_SUPERSECRETVALUE']]), { env: ON, fetch: responder(200, '{}') });
  assert.equal(JSON.stringify(f).includes('ghp_SUPERSECRETVALUE'), false);
});