'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { runCorpusScanners } = require('./corpus');
const { createCache } = require('./scan-cache');
const { withTestRules } = require('./test-support/rules');
const secrets = withTestRules(require('./scanners/secrets-builtin').scanner);
const patternSast = withTestRules(require('./scanners/pattern-sast').scanner);
const iacPolicy = withTestRules(require('./scanners/iac-policy').scanner);
const astSast = withTestRules(require('./scanners/sast-ast').scanner);

// The safety net for sharing the walk.
//
// Four scanners used to each walk the tree and each read every file. They now
// share one pass, and the ONLY acceptable difference is how long it takes:
// same files, same findings, same stats. A speed-up that quietly changes what
// a security scanner reports is not a speed-up, it is a regression nobody
// notices until the finding that mattered is the one that went missing.

const SCANNERS = [secrets, patternSast, iacPolicy, astSast];

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-equiv-'));
  const write = (name, content) => {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  };

  // Something for each engine to find, plus a good deal of ordinary source for
  // them all to walk past — the ratio a real repository has.
  write('config/app.yml', 'aws_access_key_id: AKIA2E0A8F3B244C9986\nregion: us-east-1\n');
  write('Dockerfile', 'FROM node:20\nADD https://example.invalid/tool.tar.gz /tmp/\nUSER root\n');
  write('infra/main.tf', `
resource "aws_s3_bucket" "data" {
  bucket = "my-data"
  acl    = "public-read"
}
resource "aws_security_group" "open" {
  ingress {
    cidr_blocks = ["0.0.0.0/0"]
    from_port   = 22
    to_port     = 22
  }
}
`);
  write('src/main/java/Handler.java', `
public class Handler {
  public void run(HttpServletRequest request) throws Exception {
    String name = request.getParameter("name");
    String sql = "SELECT * FROM users WHERE name = '" + name + "'";
    stmt.executeQuery(sql);
  }
}
`);
  for (let i = 0; i < 40; i++) {
    write(`src/util/helper${i}.js`, `export function helper${i}(a, b) {\n  return a + b;\n}\n`);
  }
  return dir;
}

const key = f => `${f.source}|${f.fingerprint}`;

test('the shared pass finds exactly what separate passes found', async () => {
  const dir = fixture();

  const separate = [];
  for (const scanner of SCANNERS) {
    const result = await scanner.scan({ repoPath: dir, repository: 'equiv' });
    separate.push(...result.findings);
  }

  const { results } = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv' });
  const combined = [...results.values()].flatMap(r => r.findings);

  assert.ok(separate.length > 0, 'the fixture must actually trigger something, or this proves nothing');
  assert.deepEqual(
    combined.map(key).sort(),
    separate.map(key).sort(),
    'the shared pass must report the same findings, from the same scanners'
  );
  fs.rmSync(dir, { recursive: true, force: true });
});

test('each scanner reports the same stats either way', async () => {
  // filesAnalysed is how the coverage panel says what was checked. If sharing
  // the walk changed it, the dashboard would be describing a scan that did not
  // happen.
  const dir = fixture();

  const { results } = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv' });

  for (const scanner of SCANNERS) {
    const alone = await scanner.scan({ repoPath: dir, repository: 'equiv' });
    const shared = results.get(scanner.id);
    assert.deepEqual(shared.stats, alone.stats, `${scanner.id} stats differ between the two paths`);
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the shared pass reads each file once instead of once per scanner', async () => {
  // The actual claim being made. Without this the refactor is just churn.
  const dir = fixture();

  const count = async fn => {
    let reads = 0;
    const real = fs.readFileSync;
    fs.readFileSync = (...args) => {
      // Rule bundles and grammars are read too; only repository files count.
      if (typeof args[0] === 'string' && args[0].startsWith(dir)) reads++;
      return real(...args);
    };
    try { await fn(); } finally { fs.readFileSync = real; }
    return reads;
  };

  const separateReads = await count(async () => {
    for (const scanner of SCANNERS) await scanner.scan({ repoPath: dir, repository: 'equiv' });
  });
  const sharedReads = await count(() =>
    runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv' }));

  assert.ok(sharedReads < separateReads,
    `shared pass read ${sharedReads}, separate passes read ${separateReads} — expected fewer`);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── The cached path must be indistinguishable from the cold one ────────────

test('a warm cache reports exactly what a cold scan reported', async () => {
  // The single most important test of the cache. A scan that is fast and
  // slightly wrong is far worse than a slow one: the findings it drops are
  // invisible, and nobody re-runs a scan that said everything was fine.
  const dir = fixture();
  const store = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-'));

  const cold = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv' });
  const cache = createCache({ dir: store, repository: 'equiv', bundleVersion: 'test-1' });
  await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv', cache });   // populate

  const warmCache = createCache({ dir: store, repository: 'equiv', bundleVersion: 'test-1' });
  const warm = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv', cache: warmCache });

  assert.ok(warmCache.stats.hits > 0, 'the second run must actually be using the cache');
  assert.deepEqual(
    [...warm.results.values()].flatMap(r => r.findings).map(key).sort(),
    [...cold.results.values()].flatMap(r => r.findings).map(key).sort(),
    'a cached scan must find exactly what a cold scan found'
  );

  for (const scanner of SCANNERS) {
    assert.deepEqual(
      warm.results.get(scanner.id).stats,
      cold.results.get(scanner.id).stats,
      `${scanner.id} reports different coverage when served from cache`
    );
  }
  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(store, { recursive: true, force: true });
});

test('an edited file is re-scanned even when its neighbours are cached', async () => {
  // The cache must not make a scan blind to the change that matters.
  const dir = fixture();
  const store = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-'));

  const cache = createCache({ dir: store, repository: 'equiv', bundleVersion: 'test-1' });
  const before = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv', cache });
  const beforeCount = [...before.results.values()].flatMap(r => r.findings).length;

  // A credential appears in a file that was clean and cached a moment ago.
  fs.writeFileSync(path.join(dir, 'src/util/helper7.js'),
    'const token = "AKIA2E0A8F3B244C9986";\nexport default token;\n');

  const warm = createCache({ dir: store, repository: 'equiv', bundleVersion: 'test-1' });
  const after = await runCorpusScanners(SCANNERS, { repoPath: dir, repository: 'equiv', cache: warm });
  const found = [...after.results.values()].flatMap(r => r.findings);

  assert.ok(warm.stats.hits > 0, 'the untouched files still came from cache');
  assert.ok(found.length > beforeCount, 'the edited file was re-scanned and the new credential found');
  assert.ok(found.some(f => f.file === 'src/util/helper7.js'), 'and it is attributed to the edited file');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(store, { recursive: true, force: true });
});

test('one scanner throwing does not cost the others their findings', async () => {
  // They share a pass now, so an escaping exception would take three scanners'
  // work with it. The sequential orchestrator failed one scanner at a time and
  // this must not be a step back from that.
  const dir = fixture();
  const exploding = {
    id: 'EXPLODING', type: 'SAST', name: 'Breaks on purpose',
    prepare: () => ({}),
    scanFile: () => { throw new Error('rule engine blew up'); },
    finish: () => ({}),
  };

  const { results } = await runCorpusScanners([...SCANNERS, exploding], { repoPath: dir, repository: 'equiv' });

  assert.match(results.get('EXPLODING').error, /blew up/);
  const survivors = SCANNERS.filter(s => !results.get(s.id).error);
  assert.equal(survivors.length, SCANNERS.length, 'every other scanner still completed');
  assert.ok([...results.values()].flatMap(r => r.findings).length > 0, 'and their findings survived');
  fs.rmSync(dir, { recursive: true, force: true });
});
