'use strict';
const fs = require('fs');
const path = require('path');
const { isInside } = require('./paths');

// Reads the lines of source around a finding, so the detail view can show where
// the problem actually is instead of a path and a number.
//
// TWO THINGS MAKE THIS MORE DANGEROUS THAN IT LOOKS, and both are handled here
// rather than left to the caller.
//
// 1. It reads a file path that arrived over HTTP. `file` comes from a finding,
//    and a finding can come from an imported SARIF document written by another
//    tool — so it is attacker-influenced in exactly the way a path traversal
//    needs. Every read is confined to the repository with isInside().
//
// 2. A SECRET finding's line CONTAINS THE CREDENTIAL. Returning it verbatim
//    would turn this into a credential-disclosure endpoint, undoing the care
//    taken everywhere else to never store or transmit the value. Secret lines
//    are redacted, and the redaction FAILS CLOSED: if the value cannot be
//    located precisely, the whole line is withheld rather than guessed at.

const CONTEXT_LINES = 8;
const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_LINE_LENGTH = 400;

/**
 * Rebuilds the search pattern for a secret from its masked preview.
 *
 * The plaintext is deliberately never stored, so the only handle on it is the
 * mask the scanner produced — `AKIA************LKEY`: a known prefix, a known
 * length, a known suffix. That is enough to find the token in the line and
 * replace it, and specific enough not to redact something else by accident.
 */
function maskedPattern(masked) {
  const match = /^(\S*?)(\*+)(\S*)$/.exec(String(masked || ''));
  if (!match) return null;

  const [, prefix, stars, suffix] = match;
  if (!prefix && !suffix) return null;

  const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // The stars stand for a known number of characters, so the length is part of
  // the match rather than a loose wildcard.
  return new RegExp(`${escape(prefix)}\\S{${stars.length}}${escape(suffix)}`);
}

/**
 * Removes a credential from a line.
 *
 * Returns null when it cannot be done confidently — the caller withholds the
 * line entirely in that case. Showing a line that MIGHT still contain a live
 * credential is the failure this function exists to prevent, so "not sure" and
 * "safe" must not collapse into the same answer.
 */
function redactSecret(line, masked) {
  const pattern = maskedPattern(masked);
  if (!pattern) return null;
  if (!pattern.test(line)) return null;
  return line.replace(pattern, masked);
}

/**
 * A window of source around a finding.
 *
 * @returns {{ lines, startLine, endLine, redacted, error }}
 *   `lines` is [{ number, text, isFinding }]. `error` set means nothing is
 *   returned — a missing file is an ordinary outcome (the repository moved, the
 *   code was deleted) and is reported rather than thrown.
 */
function readSource(finding, repoPath, { context = CONTEXT_LINES } = {}) {
  if (!finding || !finding.file) return { error: 'this finding is not attached to a file' };
  if (!repoPath) return { error: 'the repository is not cloned locally' };

  const target = path.resolve(repoPath, finding.file);
  // The traversal guard. A SARIF document from another tool can name any path
  // it likes; this is what stops ../../../.ssh/id_rsa being served.
  if (!isInside(repoPath, target)) return { error: 'that path is outside the repository' };

  let stat;
  try {
    stat = fs.statSync(target);
  } catch (_) {
    return { error: 'the file no longer exists in the working tree' };
  }
  if (!stat.isFile()) return { error: 'not a file' };
  if (stat.size > MAX_FILE_BYTES) return { error: 'the file is too large to display' };

  let text;
  try {
    text = fs.readFileSync(target, 'utf8');
  } catch (_) {
    return { error: 'the file could not be read' };
  }
  if (text.includes('\0')) return { error: 'the file is binary' };

  const all = text.split('\n');
  const focus = finding.startLine || 1;
  const from = Math.max(1, focus - context);
  const to = Math.min(all.length, (finding.endLine || focus) + context);

  const isSecret = finding.type === 'SECRET';
  const masked = (finding.metadata && finding.metadata.masked) || null;
  let redacted = false;

  const lines = [];
  for (let n = from; n <= to; n++) {
    let content = all[n - 1] ?? '';
    const isFinding = n >= focus && n <= (finding.endLine || focus);

    if (isSecret && isFinding) {
      const safe = redactSecret(content, masked);
      if (safe === null) {
        // Fail closed. The credential is somewhere on this line and could not
        // be located, so the line does not leave the machine.
        content = '‹ line withheld — it contains a credential ›';
      } else {
        content = safe;
      }
      redacted = true;
    }

    // Long lines are truncated for display; a minified bundle would otherwise
    // send a megabyte to render one finding.
    if (content.length > MAX_LINE_LENGTH) content = `${content.slice(0, MAX_LINE_LENGTH)}…`;

    lines.push({ number: n, text: content, isFinding });
  }

  return {
    lines,
    startLine: from,
    endLine: to,
    focusLine: focus,
    totalLines: all.length,
    // Stated so the UI can say why a line looks odd, rather than leaving a
    // reader to wonder whether the scanner mangled their code.
    redacted,
    error: null,
  };
}

module.exports = { readSource, redactSecret, maskedPattern, CONTEXT_LINES };
