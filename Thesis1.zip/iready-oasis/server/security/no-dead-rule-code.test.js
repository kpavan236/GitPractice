'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

// Rules live on the rule server. These are the pieces of the old arrangement
// (signed bundle, rule fetcher, build and ingest tooling, the bundled rule files)
// that must not come back, and nothing may still depend on them.

const ROOT = path.join(__dirname, '..', '..');
const GONE = [
  'rules',                               // rule JSON sources: oasis-rule-server/seed/rules
  'server/security/rules',               // the baked signed bundle
  'server/security/rule-bundle.js',
  'server/security/rule-bundle.test.js',
  'server/security/rule-fetch.js',
  'server/security/rule-fetch.test.js',
  'server/security/rule-licensing.test.js',
  'server/security/ast/rule-corpus.test.js',
  'tools/build-rules.js',
  'tools/ingest-rules.js',
  'tools/ingest',
];

test('the old rule machinery is gone', () => {
  for (const p of GONE) assert.ok(!fs.existsSync(path.join(ROOT, p)), `${p} should have moved to oasis-rule-server`);
});

function* sourceFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', '.superpowers', 'release', 'docs'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* sourceFiles(full);
    else if (/\.(js|sh|json)$/.test(entry.name) && !/package-lock\.json$/.test(entry.name)) yield full;
  }
}

test('nothing requires or invokes a removed module', () => {
  const forbidden = [
    /require\(['"][^'"]*rule-bundle(\.js)?['"]\)/,
    /require\(['"][^'"]*rule-fetch(\.js)?['"]\)/,
    /require\(['"][^'"]*build-rules(\.js)?['"]\)/,
    /require\(['"][^'"]*ingest-rules(\.js)?['"]\)/,
    /ruleUpdater/,
    /rules\/rules\.json/,
    /npm run build:rules/,
    /tools\/build-rules/,
    /tools\/ingest-rules/,
  ];
  const self = path.join(__dirname, 'no-dead-rule-code.test.js');
  const offenders = [];
  for (const file of sourceFiles(ROOT)) {
    if (file === self) continue;
    const text = fs.readFileSync(file, 'utf8');
    for (const re of forbidden) if (re.test(text)) offenders.push(`${path.relative(ROOT, file)} matches ${re}`);
  }
  assert.deepEqual(offenders, []);
});

test('package.json has no rule build or ingest scripts', () => {
  const { scripts } = require('../../package.json');
  assert.equal(scripts['build:rules'], undefined);
  assert.equal(scripts['ingest:rules'], undefined);
  for (const [name, command] of Object.entries(scripts)) assert.ok(!/build:rules/.test(command), `script ${name} still calls build:rules`);
});

test('test-only rules (copies of third-party rule sets) never ship in an installer', () => {
  const { build } = require('../../package.json');
  assert.ok(build.files.includes('!server/**/test-support/**'),
    'the fixture holds Gitleaks/Checkov-derived rules; their licences are not distributed with the app');
});
