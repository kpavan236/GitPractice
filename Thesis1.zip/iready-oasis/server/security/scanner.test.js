'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { streamTool } = require('./scanner');

// `runTool` buffers a tool's entire output into a string, which is fine for a
// version check and wrong for `git log -p`. The history secret scanner did it
// anyway and failed on every real repository:
//
//   GIT_HISTORY  FAILED  "git log failed: stdout maxBuffer length exceeded"
//
// Raising the cap only moves the wall — a monorepo's full diff is larger than
// any number worth holding in memory, and the process pays for it in RSS even
// when it succeeds. `streamTool` hands output over a line at a time and keeps
// memory flat, so these tests are about the properties that makes true.

// Emits `lines` lines of `width` characters through the real stdout pipe, so
// chunk boundaries land wherever the OS puts them rather than somewhere
// convenient.
function emitter(lines, width = 100) {
  return ['-e', `
    const line = 'x'.repeat(${width}) + '\\n';
    for (let i = 0; i < ${lines}; i++) process.stdout.write(line);
  `];
}

test('processes far more output than any buffer cap would allow', async () => {
  // ~50 MB, past the 40 MB cap the old code set and 50× execFile's own default.
  // The point is not that the number is big enough; it is that nothing here
  // grows with the output at all.
  const LINES = 500_000;
  let seen = 0;
  const result = await streamTool('node', emitter(LINES), { onLine: () => { seen++; } });

  assert.equal(result.error, null, 'streaming must not fail where buffering did');
  assert.equal(seen, LINES, 'every line reaches the consumer');
  assert.ok(result.bytes > 50_000_000, `expected >50MB, got ${result.bytes}`);
});

test('a line split across two chunks arrives whole', async () => {
  // The bug this prevents is silent: half a credential on each side of a chunk
  // boundary matches no pattern, so the finding simply never appears.
  const seen = [];
  await streamTool('node', emitter(2000, 3000), { onLine: l => seen.push(l) });

  assert.equal(seen.length, 2000);
  assert.ok(seen.every(l => l.length === 3000), 'no line was cut at a chunk boundary');
});

test('output with no trailing newline still delivers its last line', async () => {
  const seen = [];
  await streamTool('node', ['-e', 'process.stdout.write("no-newline-at-end")'], { onLine: l => seen.push(l) });
  assert.deepEqual(seen, ['no-newline-at-end']);
});

test('a single enormous line is truncated rather than held in memory', async () => {
  // Streaming alone does not bound memory: one committed minified bundle with
  // no newline in it would accumulate in the carry buffer and reproduce the
  // original crash with extra steps.
  const seen = [];
  const result = await streamTool(
    'node',
    ['-e', 'process.stdout.write("y".repeat(5_000_000) + "\\nshort\\n")'],
    { onLine: l => seen.push(l), maxLineLength: 1000 }
  );

  assert.ok(seen[0].length <= 1000, 'the long line is capped');
  assert.equal(result.linesTruncated, 1, 'and the caller is told it happened');
  // The line after it must still parse correctly — the carry buffer has to
  // resynchronise at the next newline, not stay poisoned.
  assert.equal(seen[1], 'short');
});

test('a non-zero exit is reported without discarding what was read', async () => {
  // git log can fail partway through. The credentials it already printed are
  // still credentials.
  const seen = [];
  const result = await streamTool(
    'node',
    ['-e', 'process.stdout.write("found-this\\n"); process.exit(3)'],
    { onLine: l => seen.push(l) }
  );

  assert.equal(result.code, 3);
  assert.deepEqual(seen, ['found-this'], 'lines read before the failure survive');
});

test('a missing binary is an error, not a hang', async () => {
  const result = await streamTool('oasis-no-such-binary-xyz', [], { onLine: () => {} });
  assert.ok(result.error, 'spawn failure is reported');
  assert.equal(result.timedOut, false);
});

test('a timeout keeps the lines it already read', async () => {
  // The old code threw on timeout and dropped everything. A partial history
  // scan that found a live AWS key is worth incomparably more than an
  // exception, so long as it is labelled partial.
  const seen = [];
  const result = await streamTool(
    'node',
    ['-e', 'process.stdout.write("early\\n"); setInterval(() => {}, 1000);'],
    { onLine: l => seen.push(l), timeoutMs: 400 }
  );

  assert.equal(result.timedOut, true);
  assert.deepEqual(seen, ['early']);
});

test('stderr is captured but capped', async () => {
  // Diagnostics are useful; a tool that writes a gigabyte of warnings must not
  // reintroduce the very problem this function exists to solve.
  const result = await streamTool(
    'node',
    ['-e', 'process.stderr.write("e".repeat(200_000))'],
    { onLine: () => {}, maxStderrBytes: 4096 }
  );
  assert.ok(result.stderr.length <= 4096);
});

test('a subprocess gets a home directory on every platform', () => {
  // Scanners get a stripped environment so an app holding GitHub and Jenkins
  // tokens does not hand them to a subprocess reading someone else's
  // repository. Passing only HOME left git on Windows with no home at all,
  // because Windows sets USERPROFILE instead — and git needs one to read its
  // configuration.
  const { toolEnv } = require('./scanner');
  const env = toolEnv();

  assert.ok(env.HOME, 'HOME is set for POSIX');
  assert.ok(env.USERPROFILE, 'USERPROFILE is set for Windows');
  assert.equal(env.LANG, 'C', 'output must not depend on the developer\'s locale');
  // The point of stripping it: no inherited credentials.
  assert.equal(env.GITHUB_TOKEN, undefined);
  assert.equal(Object.keys(env).some(k => /TOKEN|SECRET|PASSWORD|KEY/i.test(k)), false);
});
