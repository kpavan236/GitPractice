'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createRulesUpdater, SIX_HOURS_MS } = require('./rules-updates');

const deferred = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };

test('update() is serialised: a second call while one is in flight returns the first call\'s promise', async () => {
  const d = deferred();
  let calls = 0;
  const u = createRulesUpdater({ loader: { update: () => { calls += 1; return d.promise; } }, log: () => {} });
  const a = u.update();
  const b = u.update();
  assert.equal(calls, 1);
  assert.strictEqual(a, b);
  d.resolve({ status: 'updated', release: 2 });
  await a;
  await u.update();
  assert.equal(calls, 2, 'a finished update does not block the next one');
});

test('the wrapped loader keeps every other method and routes update through the serialiser', async () => {
  let calls = 0;
  const base = { current: () => ({ release: 1 }), update: async () => { calls += 1; return { status: 'current', release: 1 }; } };
  const u = createRulesUpdater({ loader: base, log: () => {} });
  assert.equal(u.loader.current().release, 1);
  await Promise.all([u.loader.update(), u.loader.update()]);
  assert.equal(calls, 1);
});

test('start() updates now and then every six hours on an unref\'d timer; stop() clears it', async () => {
  const logs = [];
  let calls = 0;
  let timer = null;
  const fakeSet = (fn, ms) => { timer = { fn, ms, unref() { this.unrefd = true; return this; }, cleared: false }; return timer; };
  const fakeClear = (h) => { h.cleared = true; };
  const u = createRulesUpdater({ loader: { update: async () => { calls += 1; return { status: 'current', release: 1 }; } }, log: (m) => logs.push(m), setIntervalImpl: fakeSet, clearIntervalImpl: fakeClear });
  await u.start();
  assert.equal(calls, 1);
  assert.equal(timer.ms, SIX_HOURS_MS);
  assert.equal(SIX_HOURS_MS, 6 * 60 * 60 * 1000);
  assert.equal(timer.unrefd, true);
  await timer.fn();
  assert.equal(calls, 2);
  u.stop();
  assert.equal(timer.cleared, true);
});

test('a failing update (integrity failure, no pinned keys) is logged with its code and never thrown from the timer', async () => {
  const logs = [];
  const u = createRulesUpdater({ loader: { update: async () => { throw Object.assign(new Error('no keys'), { code: 'NO_PINNED_KEYS' }); } }, log: (m) => logs.push(m), setIntervalImpl: () => ({ unref() {} }), clearIntervalImpl() {} });
  await u.start();
  assert.ok(logs.some((m) => /NO_PINNED_KEYS/.test(m)));
  u.stop();
});

test('status() remembers the last result and the last error, and clears the error on success', async () => {
  let next = { status: 'offline', release: 1, error: 'NETWORK' };
  const u = createRulesUpdater({ loader: { update: async () => { if (next instanceof Error) throw next; return next; } }, log: () => {} });
  assert.deepEqual(u.status(), { lastResult: null, lastError: null, lastAt: null });
  await u.update();
  assert.equal(u.status().lastResult.status, 'offline');
  next = Object.assign(new Error('no keys'), { code: 'NO_PINNED_KEYS' });
  await assert.rejects(u.update());
  assert.deepEqual(u.status().lastError, { code: 'NO_PINNED_KEYS', message: 'no keys' });
  next = { status: 'current', release: 1 };
  await u.update();
  assert.equal(u.status().lastError, null);
  assert.equal(typeof u.status().lastAt, 'string');
});
