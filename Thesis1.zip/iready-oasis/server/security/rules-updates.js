'use strict';
// Keeps the installed rules fresh: one update in flight at a time (the loader requires that), once on launch and
// then every six hours. A failure never escapes the timer; it is logged with its code so a missing signing key
// (NO_PINNED_KEYS) or a rejected release is visible in the log rather than silent.
const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

function createRulesUpdater({ loader, log = () => {}, intervalMs = SIX_HOURS_MS, setIntervalImpl = setInterval, clearIntervalImpl = clearInterval }) {
  let inFlight = null;
  let timer = null;
  let last = { lastResult: null, lastError: null, lastAt: null };

  // What the last attempt said, for the read-only rules view: an offline answer, an UPGRADE_REQUIRED, or a coded failure.
  function update() {
    if (inFlight) return inFlight;
    let started;
    try { started = Promise.resolve(loader.update()); } catch (e) { started = Promise.reject(e); }
    inFlight = started.then(
      (r) => { last = { lastResult: r || null, lastError: null, lastAt: new Date().toISOString() }; return r; },
      (e) => { last = { lastResult: null, lastError: { code: (e && e.code) || 'ERROR', message: (e && e.message) || String(e) }, lastAt: new Date().toISOString() }; throw e; },
    ).finally(() => { inFlight = null; });
    return inFlight;
  }
  const status = () => ({ ...last });

  async function runOnce() {
    try {
      const r = await update();
      if (r && r.status === 'updated') log(`security: rules updated to release-${r.release}`);
      else if (r && r.error) log(`security: rules update: ${r.status} (${r.error})`);
    } catch (e) {
      log(`security: rules update failed (${e.code || 'ERROR'}): ${e.message}`);
    }
  }

  async function start() {
    if (!timer) {
      timer = setIntervalImpl(runOnce, intervalMs);
      if (timer && typeof timer.unref === 'function') timer.unref();
    }
    await runOnce();
  }

  function stop() {
    if (timer) { clearIntervalImpl(timer); timer = null; }
  }

  return { update, start, stop, status, loader: { ...loader, update } };
}

module.exports = { createRulesUpdater, SIX_HOURS_MS };
