'use strict';
const { RuleServerError } = require('./client');
const { buildRuleSet } = require('./ruleset');

// Fetches a project's rules before a scan. Cached rules are used ONLY when the
// server cannot be reached, and are always labelled so nobody mistakes them
// for current configuration. A profile the scanner cannot run is never
// papered over with a cache: that is a configuration error to fix.
function createRuleSync({ client, cache, baseUrl = null, now = Date.now, required = false, log = () => {} }) {
  let last = null;

  async function refresh(projectKey) {
    try {
      const fetchedAt = new Date(now()).toISOString();
      const ruleSet = buildRuleSet(await client.fetchProfile(projectKey), { source: 'rule-server', fetchedAt });
      if (!ruleSet.projectKnown) {
        ruleSet.warning = `Project "${projectKey}" is not registered on the rule server; using the "${ruleSet.profile.name}" profile`;
        log(`security: ${ruleSet.warning}`);
      }
      // Best effort: a full disk must not fail a scan that has its rules in hand.
      try { cache.write(projectKey, ruleSet); } catch (e) { log(`security: could not cache rules for ${projectKey}: ${e.message}`); }
      last = { projectKey, source: ruleSet.source, version: ruleSet.version, fetchedAt, error: null };
      return ruleSet;
    } catch (e) {
      if (e.code !== 'UNREACHABLE') {
        last = { projectKey, source: null, version: null, fetchedAt: null, error: e.message };
        throw e;
      }
      const cached = cache.read(projectKey);
      if (cached) {
        const warning = `Rule server unreachable; using cached rules from ${cached.fetchedAt}`;
        log(`security: ${warning} (${projectKey})`);
        last = { projectKey, source: 'rule-server-cache', version: cached.version, fetchedAt: cached.fetchedAt, error: e.message };
        return { ...cached, source: 'rule-server-cache', stale: true, warning };
      }
      last = { projectKey, source: null, version: null, fetchedAt: null, error: e.message };
      if (required) {
        throw new RuleServerError('UNREACHABLE',
          `Rule server unreachable and no cached rules for ${projectKey}: ${e.message}. Start oasis-rule-server (${baseUrl || 'OASIS_RULE_SERVER_URL'}) and retry.`);
      }
      log(`security: ${e.message}; no cached rules for ${projectKey}, using built-in rules`);
      return null;
    }
  }

  // What the server needs to merge a finished repository scan, record the run and
  // evaluate the gate. Pure, so the findings store can queue it before sending.
  function buildAnalysisPayload({ repository, scan, repo, findings, ruleSet, scannerVersion = null, analyzerVersion = null }) {
    return {
      analysisId: `${scan.id}:${repository}`,
      scanId: scan.id,
      projectKey: repository,
      profile: ruleSet && ruleSet.profile ? { id: ruleSet.profile.id, version: ruleSet.profile.version } : null,
      ruleSetVersion: ruleSet ? ruleSet.version : null,
      scannerVersion,
      analyzerVersion,
      usedCache: !!(ruleSet && ruleSet.stale),
      mode: scan.mode || null,
      startedAt: scan.startedAt ? new Date(scan.startedAt).toISOString() : null,
      completedAt: scan.finishedAt ? new Date(scan.finishedAt).toISOString() : null,
      coverage: (repo.coverage || []).map(c => ({ type: c.type, analysed: !!c.analysed })),
      newCodeAvailable: !(repo.newCode && repo.newCode.available === false),
      findings,
    };
  }

  // Uploads a finished repository scan so the server can own the findings, run
  // history and quality gate. Never throws: the outcome is data for the scan
  // record, not a reason to fail a scan that already succeeded.
  async function publishAnalysis(input) {
    if (!input.ruleSet) return { skipped: true };
    try {
      const out = await client.postAnalysis(buildAnalysisPayload(input));
      return { ok: true, analysisId: out.analysisId, serverGate: out.gate, gateSource: out.gateSource || null };
    } catch (e) {
      log(`security: could not upload ${input.repository} to the rule server: ${e.message}`);
      return { ok: false, unreachable: e.code === 'UNREACHABLE', error: e.message };
    }
  }

  // Rule definitions by id, for the detail view. Successes are remembered for the
  // life of the process (a rule's example does not change under a running app);
  // a failure returns null and is retried next time.
  const ruleCache = new Map();
  async function getRule(id) {
    if (ruleCache.has(id)) return ruleCache.get(id);
    try {
      const rule = (await client.getRule(id)).body || null;
      if (rule) ruleCache.set(id, rule);
      return rule;
    } catch (_) {
      return null;
    }
  }

  return { client, refresh, buildAnalysisPayload, publishAnalysis, getRule, status: () => ({ configured: true, baseUrl, required, last }) };
}

module.exports = { createRuleSync };
