'use strict';

// What the analyzer can execute. Sent with every profile request so the server,
// not the scanner, decides whether the profile is runnable and says which rule
// is the problem.
const { ENGINES: SCANNER_ENGINES } = require('oasis-analyzer');

class RuleServerError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.code = code;
    Object.assign(this, extra);
  }
}

const qs = params => {
  const parts = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return parts.length ? `?${parts.join('&')}` : '';
};

function createRuleServerClient({ baseUrl, token = null, fetchImpl = globalThis.fetch, timeoutMs = 5000 }) {
  const root = baseUrl.replace(/\/$/, '');
  // Listing findings can be a large answer; give those reads longer than the quick
  // profile lookup, so a big install is not mistaken for an unreachable server.
  const readTimeout = Math.max(timeoutMs, 30000);

  // One request, one failure vocabulary. A server that cannot be reached, or
  // answers 5xx, is UNREACHABLE; a refusal (bad id, duplicate, bad token) is HTTP
  // with the status. Callers that need more (the 422 for an unrunnable profile)
  // pass `onStatus`.
  async function call(method, path, { body, timeout = timeoutMs, onStatus } = {}) {
    let res;
    try {
      res = await fetchImpl(`${root}/api/v1${path}`, {
        method,
        headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...(token ? { 'x-oasis-token': token } : {}) },
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
        signal: AbortSignal.timeout(timeout),
      });
    } catch (e) {
      throw new RuleServerError('UNREACHABLE', `rule server unreachable: ${e.message}`);
    }
    const payload = await res.json().catch(() => ({}));
    if (onStatus) onStatus(res.status, payload);
    if (res.status >= 500) throw new RuleServerError('UNREACHABLE', `rule server error ${res.status}`);
    if (!res.ok) throw new RuleServerError('HTTP', payload.message || `rule server returned ${res.status}`, { status: res.status });
    return payload;
  }

  async function fetchProfile(projectKey) {
    const body = await call('GET', `/projects/${encodeURIComponent(projectKey)}/profile?engines=${encodeURIComponent(SCANNER_ENGINES)}`, {
      onStatus: (status, payload) => {
        if (status === 422) throw new RuleServerError('UNSUPPORTED_RULES', payload.message || 'profile has rules this scanner cannot run', { rules: payload.rules || [] });
      },
    });
    // A 200 that is not a profile (a proxy's HTML page, a truncated body) means
    // the server is not usable right now, the same as not answering at all.
    if (!body.profile || !Array.isArray(body.rules)) {
      throw new RuleServerError('UNREACHABLE', 'rule server returned an unexpected response');
    }
    return body;
  }

  return {
    fetchProfile,
    // Uploads one analysis. The scan's findings can be large, so this waits longer.
    postAnalysis: payload => call('POST', '/analyses', { body: payload, timeout: Math.max(timeoutMs, 30000) }),
    // One rule as the server stores it (`.body` is the definition); used for the
    // worked example in a finding's detail view.
    getRule: id => call('GET', `/rules/${encodeURIComponent(id)}`),

    // Findings, triage and trends (the rule server is their system of record).
    listFindings: filter => call('GET', `/findings${qs(filter || {})}`, { timeout: readTimeout }),
    repositories: () => call('GET', '/findings/repositories', { timeout: readTimeout }),
    getFinding: id => call('GET', `/findings/${encodeURIComponent(id)}`),
    updateFinding: (id, patch) => call('POST', `/findings/${encodeURIComponent(id)}/status`, { body: patch }),
    setRisk: updates => call('POST', '/findings/risk', { body: { updates } }),
    history: points => call('GET', `/history${qs({ points })}`, { timeout: readTimeout }),
    getBaseline: () => call('GET', '/baseline'),
    setBaseline: () => call('POST', '/baseline'),
    clearBaseline: () => call('DELETE', '/baseline'),
    clearPreview: repository => call('GET', `/maintenance/preview${qs({ repository })}`),
    clearFindings: (repository, keepSuppressed) => call('DELETE', `/findings${qs({ repository, keepSuppressed })}`),
    reset: () => call('POST', '/maintenance/reset'),
    // Rule administration: the rules, profiles and project assignments screens.
    listRules: filter => call('GET', `/rules${qs({ fields: 'summary', ...(filter || {}) })}`, { timeout: readTimeout }),
    createRule: (rule, activateIn) => call('POST', '/rules', { body: activateIn ? { ...rule, activateIn } : rule }),
    updateRule: (id, patch) => call('PUT', `/rules/${encodeURIComponent(id)}`, { body: patch }),
    deprecateRule: id => call('DELETE', `/rules/${encodeURIComponent(id)}`),
    listProfiles: () => call('GET', '/profiles'),
    getProfile: id => call('GET', `/profiles/${encodeURIComponent(id)}`),
    createProfile: profile => call('POST', '/profiles', { body: profile }),
    deleteProfile: id => call('DELETE', `/profiles/${encodeURIComponent(id)}`),
    profileRules: (id, filter) => call('GET', `/profiles/${encodeURIComponent(id)}/rules${qs(filter || {})}`, { timeout: readTimeout }),
    setProfileRule: (id, ruleId, patch) => call('PUT', `/profiles/${encodeURIComponent(id)}/rules/${encodeURIComponent(ruleId)}`, { body: patch }),
    clearProfileRule: (id, ruleId) => call('DELETE', `/profiles/${encodeURIComponent(id)}/rules/${encodeURIComponent(ruleId)}`),
    listProjects: () => call('GET', '/projects'),
    assignProject: (key, body) => call('PUT', `/projects/${encodeURIComponent(key)}`, { body }),

    importBulk: (payload, { mode } = {}) => call('POST', `/import${qs({ mode })}`, { body: payload, timeout: 600000 }),
  };
}

module.exports = { createRuleServerClient, RuleServerError, SCANNER_ENGINES };
