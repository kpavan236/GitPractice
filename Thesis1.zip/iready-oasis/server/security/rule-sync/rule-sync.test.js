'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createRuleServerClient, RuleServerError, SCANNER_ENGINES } = require('./client');
const { buildRuleSet } = require('./ruleset');
const { createRuleSetCache } = require('./cache');
const { createRuleSync } = require('./sync');
const { createRuleSyncFromEnv } = require('./index');

const profileBody = {
  profile: { id: 'default', name: 'Default', version: 3 },
  rules: [
    { ruleId: 'A', severity: 'CRITICAL', params: { max: 2 }, engine: 'pattern', schemaVersion: 1, definition: { id: 'A', severity: 'LOW', pattern: 'x', files: ['**'] } },
    { ruleId: 'B', severity: 'HIGH', params: {}, engine: 'ast', schemaVersion: 1, definition: { id: 'B', severity: 'HIGH', query: '(a)' } },
  ],
};
const reply = (status, body) => async () => ({ status, ok: status < 400, json: async () => body });
const clientWith = fetchImpl => createRuleServerClient({ baseUrl: 'http://rs', fetchImpl });
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'rsync-'));

test('client asks for the project profile declaring scanner engines', async () => {
  let url;
  const c = clientWith(async u => { url = u; return { status: 200, ok: true, json: async () => profileBody }; });
  assert.deepEqual((await c.fetchProfile('student-api')).profile.id, 'default');
  assert.equal(url, 'http://rs/api/v1/projects/student-api/profile?engines=' + encodeURIComponent(SCANNER_ENGINES));
});

test('client maps failures to typed errors', async () => {
  await assert.rejects(clientWith(async () => { throw new Error('ECONNREFUSED'); }).fetchProfile('p'), e => e.code === 'UNREACHABLE');
  await assert.rejects(clientWith(reply(503, {})).fetchProfile('p'), e => e.code === 'UNREACHABLE');
  await assert.rejects(clientWith(reply(404, { message: 'nope' })).fetchProfile('p'), e => e.code === 'HTTP');
  const rules = [{ ruleId: 'X', engine: 'ast', schemaVersion: 2 }];
  await assert.rejects(clientWith(reply(422, { error: 'UNSUPPORTED_RULES', message: 'Rule X ...', rules })).fetchProfile('p'),
    e => e instanceof RuleServerError && e.code === 'UNSUPPORTED_RULES' && e.rules.length === 1 && /Rule X/.test(e.message));
});

test('buildRuleSet applies profile severity and params to the rule definition', () => {
  const rs = buildRuleSet(profileBody, { source: 'rule-server', fetchedAt: '2026-10-01T00:00:00.000Z' });
  assert.equal(rs.version, 'default@3');
  assert.deepEqual(rs.rules[0], { id: 'A', severity: 'CRITICAL', pattern: 'x', files: ['**'], params: { max: 2 } });
  assert.deepEqual(rs.rules[1], { id: 'B', severity: 'HIGH', query: '(a)' });
  assert.equal(rs.profile.name, 'Default');
});

test('cache round-trips and rejects a corrupt file', () => {
  const cache = createRuleSetCache(tmp());
  assert.equal(cache.read('p'), null);
  const rs = buildRuleSet(profileBody, { source: 'rule-server', fetchedAt: 'T' });
  cache.write('p/odd key', rs);
  assert.deepEqual(cache.read('p/odd key').rules, rs.rules);
  fs.writeFileSync(path.join(cache.dir, fs.readdirSync(cache.dir)[0]), '{nope');
  assert.equal(cache.read('p/odd key'), null);
});

test('sync: live fetch is cached and labelled rule-server', async () => {
  const sync = createRuleSync({ client: clientWith(reply(200, profileBody)), cache: createRuleSetCache(tmp()), now: () => 1 });
  const rs = await sync.refresh('p');
  assert.equal(rs.source, 'rule-server');
  assert.equal(rs.stale, undefined);
});

test('sync: server down uses the labelled cache, else null, else throws when required', async () => {
  const cache = createRuleSetCache(tmp());
  const live = createRuleSync({ client: clientWith(reply(200, profileBody)), cache });
  await live.refresh('p');
  const down = clientWith(async () => { throw new Error('refused'); });
  const stale = await createRuleSync({ client: down, cache }).refresh('p');
  assert.equal(stale.source, 'rule-server-cache');
  assert.equal(stale.stale, true);
  assert.match(stale.warning, /unreachable.*cached rules/i);
  assert.equal(await createRuleSync({ client: down, cache }).refresh('never-seen'), null);
  await assert.rejects(createRuleSync({ client: down, cache, required: true }).refresh('never-seen'), e => e.code === 'UNREACHABLE');
});

test('sync: unsupported rules always throw, even with a cache present', async () => {
  const cache = createRuleSetCache(tmp());
  await createRuleSync({ client: clientWith(reply(200, profileBody)), cache }).refresh('p');
  const bad = clientWith(reply(422, { error: 'UNSUPPORTED_RULES', message: 'Rule B ...', rules: [{ ruleId: 'B' }] }));
  await assert.rejects(createRuleSync({ client: bad, cache }).refresh('p'), e => e.code === 'UNSUPPORTED_RULES');
});

test('sync.status reports the last outcome', async () => {
  const sync = createRuleSync({ client: clientWith(reply(200, profileBody)), cache: createRuleSetCache(tmp()), baseUrl: 'http://rs' });
  await sync.refresh('p');
  assert.equal(sync.status().configured, true);
  assert.equal(sync.status().last.source, 'rule-server');
});

test('createRuleSyncFromEnv always returns a sync: default local URL, required, overridable', () => {
  const d = createRuleSyncFromEnv({}, { dir: tmp() });
  assert.equal(d.status().baseUrl, 'http://127.0.0.1:5090');
  assert.equal(d.status().required, true);
  assert.equal(createRuleSyncFromEnv({ OASIS_RULE_SERVER_URL: 'http://rules.internal:9' }, { dir: tmp() }).status().baseUrl, 'http://rules.internal:9');
});

test('client.getRule reads one rule; sync.getRule caches successes and returns null on failure', async () => {
  let calls = 0;
  const client = { getRule: async id => { calls += 1; if (id === 'bad') throw new RuleServerError('UNREACHABLE', 'down'); return { id, body: { id, example: { vulnerable: 'v' } } }; } };
  const sync = createRuleSync({ client, cache: createRuleSetCache(tmp()) });
  assert.equal((await sync.getRule('r1')).example.vulnerable, 'v');
  await sync.getRule('r1');
  assert.equal(calls, 1, 'second lookup comes from memory');
  assert.equal(await sync.getRule('bad'), null);
  await sync.getRule('bad');
  assert.equal(calls, 3, 'failures are not cached');

  let seen;
  const c = createRuleServerClient({ baseUrl: 'http://rs', fetchImpl: async u => { seen = u; return { status: 200, ok: true, json: async () => ({ id: 'a/b', body: { id: 'a/b' } }) }; } });
  assert.equal((await c.getRule('a/b')).body.id, 'a/b');
  assert.equal(seen, 'http://rs/api/v1/rules/a%2Fb');
  await assert.rejects(clientWith(reply(404, { message: 'nope' })).getRule('zz'), e => e.code === 'HTTP' && e.status === 404);
});

test('client treats a 200 with an unusable body as unreachable', async () => {
  const htmlPage = async () => ({ status: 200, ok: true, json: async () => { throw new SyntaxError('Unexpected token <'); } });
  await assert.rejects(clientWith(htmlPage).fetchProfile('p'), e => e.code === 'UNREACHABLE');
  await assert.rejects(clientWith(reply(200, { profile: { id: 'd' } })).fetchProfile('p'), e => e.code === 'UNREACHABLE');
});

test('sync: a cache write failure never fails the scan', async () => {
  const cache = { read: () => null, write: () => { throw new Error('EACCES'); } };
  const rs = await createRuleSync({ client: clientWith(reply(200, profileBody)), cache }).refresh('p');
  assert.equal(rs.source, 'rule-server');
});

test('sync: an unregistered project is flagged instead of silently using Default', async () => {
  const body = { ...profileBody, projectKnown: false };
  const rs = await createRuleSync({ client: clientWith(reply(200, body)), cache: createRuleSetCache(tmp()) }).refresh('org/repo');
  assert.equal(rs.projectKnown, false);
  assert.match(rs.warning, /org\/repo.*not registered.*"Default"/);
  const known = await createRuleSync({ client: clientWith(reply(200, { ...profileBody, projectKnown: true })), cache: createRuleSetCache(tmp()) }).refresh('p');
  assert.equal(known.warning, undefined);
});

const analysisInput = (extra = {}) => ({
  repository: 'org/a',
  scan: { id: 'SCAN-1', startedAt: '2026-10-01T00:00:00Z', finishedAt: '2026-10-01T00:00:05Z', mode: 'full' },
  repo: { coverage: [{ type: 'SAST', analysed: true }], newCode: { available: true } },
  findings: [{ fingerprint: 'fp1', type: 'SAST', severity: 'HIGH', status: 'OPEN' }],
  ruleSet: { version: 'default@3', stale: false, profile: { id: 'default', name: 'Default', version: 3 } },
  scannerVersion: '2.0.1', analyzerVersion: '0.1.0',
  ...extra,
});

test('client.postAnalysis posts JSON and maps failures', async () => {
  let seen;
  const ok = createRuleServerClient({ baseUrl: 'http://rs', token: 't', fetchImpl: async (u, o) => { seen = { u, o }; return { status: 201, ok: true, json: async () => ({ analysisId: 'a', gate: { status: 'PASSED' } }) }; } });
  assert.equal((await ok.postAnalysis({ x: 1 })).gate.status, 'PASSED');
  assert.equal(seen.u, 'http://rs/api/v1/analyses');
  assert.equal(seen.o.method, 'POST');
  assert.equal(seen.o.headers['x-oasis-token'], 't');
  assert.deepEqual(JSON.parse(seen.o.body), { x: 1 });
  await assert.rejects(clientWith(reply(409, { message: 'dup' })).postAnalysis({}), e => e.code === 'HTTP' && e.status === 409);
  await assert.rejects(clientWith(reply(502, {})).postAnalysis({}), e => e.code === 'UNREACHABLE');
  await assert.rejects(clientWith(async () => { throw new Error('refused'); }).postAnalysis({}), e => e.code === 'UNREACHABLE');
});

test('publishAnalysis builds the payload from the scan and never leaks plaintext', async () => {
  let sent;
  const client = { fetchProfile: async () => profileBody, postAnalysis: async p => { sent = p; return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; } };
  const sync = createRuleSync({ client, cache: createRuleSetCache(tmp()) });
  const secret = { fingerprint: 'fp2', type: 'SECRET', severity: 'HIGH', status: 'OPEN' };
  Object.defineProperty(secret, '_plaintext', { value: 'ghp_SECRET', enumerable: false });
  const out = await sync.publishAnalysis(analysisInput({ findings: [secret] }));
  assert.equal(out.ok, true);
  assert.equal(out.serverGate.status, 'PASSED');
  assert.equal(sent.analysisId, 'SCAN-1:org/a');
  assert.equal(sent.projectKey, 'org/a');
  assert.deepEqual(sent.profile, { id: 'default', version: 3 });
  assert.equal(sent.ruleSetVersion, 'default@3');
  assert.equal(sent.newCodeAvailable, true);
  assert.deepEqual(sent.coverage, [{ type: 'SAST', analysed: true }]);
  assert.equal(sent.analyzerVersion, '0.1.0');
  assert.ok(!JSON.stringify(sent).includes('ghp_SECRET'));
});

test('publishAnalysis is skipped without a synced rule set and never throws on failure', async () => {
  const sync = createRuleSync({ client: { postAnalysis: async () => { throw new RuleServerError('UNREACHABLE', 'down'); } }, cache: createRuleSetCache(tmp()) });
  assert.deepEqual(await sync.publishAnalysis(analysisInput({ ruleSet: null })), { skipped: true });
  const out = await sync.publishAnalysis(analysisInput());
  assert.equal(out.ok, false);
  assert.match(out.error, /down/);
});

test('publishAnalysis reports the server gate source and flags unreachable failures', async () => {
  const up = createRuleSync({ client: { postAnalysis: async () => ({ analysisId: 'a', gate: { status: 'PASSED' }, gateSource: 'default' }) }, cache: createRuleSetCache(tmp()) });
  assert.equal((await up.publishAnalysis(analysisInput())).gateSource, 'default');
  const down = createRuleSync({ client: { postAnalysis: async () => { throw new RuleServerError('UNREACHABLE', 'down'); } }, cache: createRuleSetCache(tmp()) });
  assert.equal((await down.publishAnalysis(analysisInput())).unreachable, true);
  const refused = createRuleSync({ client: { postAnalysis: async () => { throw new RuleServerError('HTTP', 'dup', { status: 409 }); } }, cache: createRuleSetCache(tmp()) });
  assert.equal((await refused.publishAnalysis(analysisInput())).unreachable, false);
});

test('the default rule server URL is a port fetch is willing to connect to', async () => {
  // fetch (like browsers) refuses a list of "bad ports" (5090 is one: SIP). A default
  // on one of them fails as an unreachable server even when the server is running,
  // and no test with a random port can see it.
  const { DEFAULT_URL } = require('./index');
  const outcome = await fetch(`${DEFAULT_URL}/api/v1/health`, { signal: AbortSignal.timeout(2000) }).then(() => 'reachable', e => e);
  if (outcome !== 'reachable') {
    assert.doesNotMatch(String(outcome.cause && outcome.cause.message), /bad port/i, `${DEFAULT_URL} is a port fetch refuses`);
  }
});

test('when the rule server is required and unreachable the error says how to start it', async () => {
  const down = clientWith(async () => { throw new Error('fetch failed'); });
  await assert.rejects(createRuleSync({ client: down, cache: createRuleSetCache(tmp()), required: true, baseUrl: 'http://127.0.0.1:5090' }).refresh('demo'),
    e => e.code === 'UNREACHABLE' && /demo/.test(e.message) && /start oasis-rule-server/i.test(e.message) && /127\.0\.0\.1:5090/.test(e.message));
});

test('buildAnalysisPayload is the pure half of publishAnalysis and carries the scan id for the per-scan trend point', async () => {
  const client = { postAnalysis: async () => ({}) };
  const sync = createRuleSync({ client, cache: createRuleSetCache(tmp()) });
  assert.equal(sync.client, client);
  const payload = sync.buildAnalysisPayload(analysisInput());
  assert.equal(payload.analysisId, 'SCAN-1:org/a');
  assert.equal(payload.scanId, 'SCAN-1');
  assert.equal(payload.projectKey, 'org/a');
  assert.deepEqual(payload.profile, { id: 'default', version: 3 });
  assert.deepEqual(payload.findings, analysisInput().findings);
});
