'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createRuleServerClient } = require('./client');

const make = (reply = { status: 200, body: { ok: true } }) => {
  const seen = [];
  const client = createRuleServerClient({
    baseUrl: 'http://rs', token: 'tok',
    fetchImpl: async (url, init = {}) => { seen.push({ url, method: init.method || 'GET', body: init.body ? JSON.parse(init.body) : undefined, token: init.headers && init.headers['x-oasis-token'] }); return { status: reply.status, ok: reply.status < 400, json: async () => reply.body }; },
  });
  return { client, seen };
};

const CALLS = [
  ['listFindings', [{ repository: 'org/a', status: 'new', search: 'a b' }], 'GET', '/api/v1/findings?repository=org%2Fa&status=new&search=a%20b', undefined],
  ['listFindings', [{}], 'GET', '/api/v1/findings', undefined],
  ['getFinding', ['F-1'], 'GET', '/api/v1/findings/F-1', undefined],
  ['updateFinding', ['F-1', { status: 'SUPPRESSED', reason: 'r' }], 'POST', '/api/v1/findings/F-1/status', { status: 'SUPPRESSED', reason: 'r' }],
  ['getBaseline', [], 'GET', '/api/v1/baseline', undefined],
  ['setBaseline', [], 'POST', '/api/v1/baseline', undefined],
  ['clearBaseline', [], 'DELETE', '/api/v1/baseline', undefined],
  ['history', [30], 'GET', '/api/v1/history?points=30', undefined],
  ['clearPreview', ['org/a'], 'GET', '/api/v1/maintenance/preview?repository=org%2Fa', undefined],
  ['clearPreview', [null], 'GET', '/api/v1/maintenance/preview', undefined],
  ['clearFindings', ['org/a', true], 'DELETE', '/api/v1/findings?repository=org%2Fa&keepSuppressed=true', undefined],
  ['clearFindings', [null, false], 'DELETE', '/api/v1/findings?keepSuppressed=false', undefined],
  ['reset', [], 'POST', '/api/v1/maintenance/reset', undefined],
  ['setRisk', [[{ id: 'F-1', risk: { score: 3 } }]], 'POST', '/api/v1/findings/risk', { updates: [{ id: 'F-1', risk: { score: 3 } }] }],
  ['importBulk', [{ findings: [], history: [] }], 'POST', '/api/v1/import', { findings: [], history: [] }],
  ['importBulk', [{ findings: [], history: [] }, { mode: 'merge' }], 'POST', '/api/v1/import?mode=merge', { findings: [], history: [] }],
  ['repositories', [], 'GET', '/api/v1/findings/repositories', undefined],
  // rule administration
  ['listRules', [{ search: 'sql inj', language: 'java' }], 'GET', '/api/v1/rules?fields=summary&search=sql%20inj&language=java', undefined],
  ['listRules', [{}], 'GET', '/api/v1/rules?fields=summary', undefined],
  ['createRule', [{ id: 'U1' }, ['default']], 'POST', '/api/v1/rules', { id: 'U1', activateIn: ['default'] }],
  ['createRule', [{ id: 'U1' }], 'POST', '/api/v1/rules', { id: 'U1' }],
  ['updateRule', ['U1', { severity: 'LOW' }], 'PUT', '/api/v1/rules/U1', { severity: 'LOW' }],
  ['deprecateRule', ['U1'], 'DELETE', '/api/v1/rules/U1', undefined],
  ['listProfiles', [], 'GET', '/api/v1/profiles', undefined],
  ['getProfile', ['strict'], 'GET', '/api/v1/profiles/strict', undefined],
  ['createProfile', [{ id: 'strict', name: 'Strict', parentId: 'default' }], 'POST', '/api/v1/profiles', { id: 'strict', name: 'Strict', parentId: 'default' }],
  ['deleteProfile', ['strict'], 'DELETE', '/api/v1/profiles/strict', undefined],
  ['profileRules', ['strict', { state: 'disabled', search: 'a b' }], 'GET', '/api/v1/profiles/strict/rules?state=disabled&search=a%20b', undefined],
  ['setProfileRule', ['strict', 'R/1', { enabled: false }], 'PUT', '/api/v1/profiles/strict/rules/R%2F1', { enabled: false }],
  ['clearProfileRule', ['strict', 'R1'], 'DELETE', '/api/v1/profiles/strict/rules/R1', undefined],
  ['listProjects', [], 'GET', '/api/v1/projects', undefined],
  ['assignProject', ['org/a', { name: 'A', profileId: 'strict' }], 'PUT', '/api/v1/projects/org%2Fa', { name: 'A', profileId: 'strict' }],
];

for (const [name, args, method, path, body] of CALLS) {
  test(`client.${name}(${JSON.stringify(args).slice(0, 40)}) -> ${method} ${path}`, async () => {
    const { client, seen } = make();
    assert.deepEqual(await client[name](...args), { ok: true });
    assert.deepEqual(seen, [{ url: 'http://rs' + path, method, body, token: 'tok' }]);
  });
}

test('the new calls map failures like the old ones', async () => {
  await assert.rejects(make({ status: 503, body: {} }).client.listFindings({}), e => e.code === 'UNREACHABLE');
  await assert.rejects(make({ status: 404, body: { message: 'nope' } }).client.getFinding('x'), e => e.code === 'HTTP' && e.status === 404);
  const down = createRuleServerClient({ baseUrl: 'http://rs', fetchImpl: async () => { throw new Error('refused'); } });
  await assert.rejects(down.history(5), e => e.code === 'UNREACHABLE');
});
