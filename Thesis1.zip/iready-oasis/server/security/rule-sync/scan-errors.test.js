'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const express = require('express');
const { createSecurityRouter } = require('../routes');

async function post(startScan) {
  const orchestrator = { startScan, listFindings: () => [] };
  const app = express();
  app.use(express.json());
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => ['x'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/api/security/scans`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ repository: 'x' }),
    });
    return { status: res.status, body: await res.json() };
  } finally {
    server.close();
  }
}
const coded = (code, message, extra = {}) => async () => { throw Object.assign(new Error(message), { code }, extra); };

test('POST /scans: a profile the scanner cannot run is a 422 that lists the rules', async () => {
  const r = await post(coded('UNSUPPORTED_RULES', 'Rule X is active ...', { rules: [{ ruleId: 'X' }] }));
  assert.equal(r.status, 422);
  assert.equal(r.body.code, 'UNSUPPORTED_RULES');
  assert.deepEqual(r.body.rules, [{ ruleId: 'X' }]);
  assert.match(r.body.error, /Rule X/);
});

test('POST /scans: no rules at all is a 503 with the instruction to start the rule server', async () => {
  const r = await post(coded('NO_RULES', 'No rules available: the rule server is unreachable and nothing is cached.'));
  assert.equal(r.status, 503);
  assert.equal(r.body.code, 'NO_RULES');
  assert.match(r.body.error, /rule server is unreachable/);
});

test('POST /scans: required-but-unreachable rule server is a 503, a rejected token a 502, anything else 500', async () => {
  assert.equal((await post(coded('UNREACHABLE', 'down'))).status, 503);
  assert.equal((await post(coded('HTTP', 'bad token', { status: 401 }))).status, 502);
  assert.equal((await post(async () => { throw new Error('boom'); })).status, 500);
});

test('GET /findings/:id/source takes the rule example from the rule server, so server-only rules have one', async () => {
  const fs = require('fs');
  const path = require('path');
  const repo = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-ex-'));
  fs.writeFileSync(path.join(repo, 'a.txt'), 'line one\nBAD\nline three\n');
  const finding = { id: 'F1', repository: 'x', file: 'a.txt', startLine: 2, endLine: 2, detections: [{ ruleId: 'server-only-rule' }] };
  const asked = [];
  const orchestrator = {
    getFinding: async id => (id === finding.id ? finding : null),
    ruleSync: { getRule: async id => { asked.push(id); return { id, language: 'text', example: { file: 'a.txt', vulnerable: 'BAD', fixed: 'GOOD' }, provenance: null }; } },
  };
  const app = express();
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => repo, listRepositories: () => ['x'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const body = await (await fetch(`http://127.0.0.1:${server.address().port}/api/security/findings/F1/source`)).json();
    assert.deepEqual(asked, ['server-only-rule']);
    assert.equal(body.example.vulnerable, 'BAD');
    assert.equal(body.example.fixed, 'GOOD');
    assert.equal(body.example.language, 'text');
  } finally {
    server.close();
    fs.rmSync(repo, { recursive: true, force: true });
  }
});

// ── Reading findings when the store (the rule server) cannot be reached ────────

async function get(orchestrator, route) {
  const app = express();
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => ['x'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/api/security${route}`);
    return { status: res.status, body: await res.json() };
  } finally {
    server.close();
  }
}
const unreachable = () => Object.assign(new Error('rule server unreachable: refused'), { code: 'UNREACHABLE' });

test('every route that reads findings answers 503 with the reason when the store is down, never an empty result', async () => {
  const failing = async () => { throw unreachable(); };
  const orchestrator = {
    listFindings: failing, getFinding: failing, scannedRepositories: failing, dashboard: failing, trends: failing, licenseInventory: failing, clearPreview: failing,
    gateStatus: () => null,
  };
  for (const route of ['/findings', '/findings/F1', '/findings/F1/source', '/dashboard', '/trends', '/licenses', '/clear/preview', '/sarif', '/repositories']) {
    const r = await get(orchestrator, route);
    assert.equal(r.status, 503, route);
    assert.match(r.body.error, /rule server unreachable/, route);
    assert.equal(r.body.code, 'UNREACHABLE', route);
  }
});

test('an unknown finding is still a 404, distinct from an unreachable store', async () => {
  const orchestrator = { getFinding: async () => null, listFindings: async () => [] };
  assert.equal((await get(orchestrator, '/findings/nope')).status, 404);
});

test('the queue is exposed on /rules and set-aside scans can be retried over HTTP', async () => {
  const orchestrator = {
    ruleSync: { status: () => ({ configured: true, baseUrl: 'http://x' }) },
    outboxStatus: () => ({ queued: 2, rejected: 1, blocked: null }),
    retryRejected: async () => ({ requeued: 1, delivered: 1, remaining: 0, rejected: 0, blocked: null }),
  };
  const status = await get(orchestrator, '/rules');
  assert.deepEqual(status.body.outbox, { queued: 2, rejected: 1, blocked: null });
  assert.equal(status.body.configured, true);

  const app = express();
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => [], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/api/security/rules/outbox/retry`, { method: 'POST' });
    assert.deepEqual(await res.json(), { requeued: 1, delivered: 1, remaining: 0, rejected: 0, blocked: null });
  } finally {
    server.close();
  }
});
