'use strict';
const { createRuleServerClient } = require('./client');
const { createRuleSetCache } = require('./cache');
const { createRuleSync } = require('./sync');

// The rule server is where rules live; there is no built-in copy. It defaults to
// the local service next to oasis, and a scan with no server and nothing cached
// fails with a clear message (NO_RULES) instead of running no rules.
const DEFAULT_URL = 'http://127.0.0.1:5090';

function createRuleSyncFromEnv(env, { dir, log } = {}) {
  const baseUrl = env.OASIS_RULE_SERVER_URL || DEFAULT_URL;
  return createRuleSync({
    client: createRuleServerClient({ baseUrl, token: env.OASIS_RULE_SERVER_TOKEN || null }),
    cache: createRuleSetCache(dir),
    baseUrl,
    required: true,
    log,
  });
}

module.exports = { createRuleSyncFromEnv, createRuleSync, DEFAULT_URL };
