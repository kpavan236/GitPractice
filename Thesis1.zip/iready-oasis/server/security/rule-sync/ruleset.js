'use strict';

// The server's answer, reshaped into what buildRuleSet({ ruleSet }) expects. The
// profile's severity and params are applied to a copy of the rule definition;
// the definition itself is what oasis shipped, byte for byte.
function buildRuleSet(response, { source, fetchedAt }) {
  const { profile, rules } = response;
  return {
    rules: rules.map(r => {
      const rule = { ...r.definition, severity: r.severity };
      if (r.params && Object.keys(r.params).length) rule.params = r.params;
      return rule;
    }),
    version: `${profile.id}@${profile.version}`,
    source,
    createdAt: fetchedAt,
    fetchedAt,
    profile: { id: profile.id, name: profile.name, version: profile.version },
    projectKnown: response.projectKnown !== false,
  };
}

module.exports = { buildRuleSet };
