'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createOrchestrator } = require('../orchestrator');
const { scanner: patternScanner } = require('../scanners/pattern-sast');

const tmpdir = prefix => fs.mkdtempSync(path.join(os.tmpdir(), prefix));

async function waitForScan(orchestrator, id) {
  for (let i = 0; i < 400; i++) {
    const scan = orchestrator.getScan(id);
    if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(scan.status)) return scan;
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  throw new Error('scan did not finish in time');
}

const markerSet = (marker, extra = {}) => ({
  version: `default@${marker}`,
  source: 'rule-server',
  fetchedAt: '2026-10-01T00:00:00.000Z',
  rules: [{ id: `rs-${marker}`, language: 'text', severity: 'LOW', pattern: marker, files: ['**/*.txt'], title: marker, category: 'TEST' }],
  ...extra,
});

function repoWithBoth(t) {
  const p = tmpdir('oasis-ws-repo-');
  t.after(() => fs.rmSync(p, { recursive: true, force: true }));
  fs.writeFileSync(path.join(p, 'n.txt'), 'MARKER_A and MARKER_B\n');
  return p;
}

test('each repository is scanned with its own fetched profile, and the scan record says so', async (t) => {
  const storeDir = tmpdir('oasis-ws-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));
  const sets = {
    'org/a': markerSet('MARKER_A'),
    'org/b': markerSet('MARKER_B', { source: 'rule-server-cache', stale: true, warning: 'Rule server unreachable; using cached rules from T' }),
  };
  const ruleSync = { refresh: async key => sets[key], status: () => ({ configured: true }) };
  const orchestrator = createOrchestrator({ scanners: [patternScanner], dir: storeDir, userRulesDir: null, userGrammarsDir: null, ruleSync });
  t.after(() => orchestrator.shutdown());

  const scan = await orchestrator.startScan({
    targets: [{ repository: 'org/a', repoPath: repoWithBoth(t) }, { repository: 'org/b', repoPath: repoWithBoth(t) }],
  });
  const finished = await waitForScan(orchestrator, scan.id);
  assert.equal(finished.status, 'COMPLETED', finished.error || '');

  const ids = async repo => (await orchestrator.listFindings({ repository: repo })).flatMap(f => f.detections.map(d => d.ruleId)).sort();
  assert.deepEqual(await ids('org/a'), ['rs-MARKER_A']);
  assert.deepEqual(await ids('org/b'), ['rs-MARKER_B']);

  assert.equal(finished.ruleSets.length, 2);
  const b = finished.ruleSets.find(r => r.repository === 'org/b');
  assert.equal(b.stale, true);
  assert.match(b.warning, /cached rules/);
  assert.equal(orchestrator.ruleSync, ruleSync);
});

test('unsupported rules fail startScan before any scan is created', async (t) => {
  const storeDir = tmpdir('oasis-ws-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));
  const err = Object.assign(new Error('Rule X is active in profile "Default" but the installed scanner does not support it'), { code: 'UNSUPPORTED_RULES' });
  const orchestrator = createOrchestrator({
    scanners: [patternScanner], dir: storeDir, userRulesDir: null, userGrammarsDir: null,
    ruleSync: { refresh: async () => { throw err; }, status: () => ({}) },
  });
  t.after(() => orchestrator.shutdown());
  await assert.rejects(orchestrator.startScan({ targets: [{ repository: 'org/d', repoPath: storeDir }] }), /Rule X is active/);
});

test('rules are fetched concurrently (bounded), and ruleSets keep target order', async (t) => {
  const storeDir = tmpdir('oasis-ws-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));
  let inFlight = 0; let peak = 0;
  const ruleSync = {
    refresh: async key => {
      inFlight += 1; peak = Math.max(peak, inFlight);
      await new Promise(r => setTimeout(r, 40));
      inFlight -= 1;
      return markerSet(key.replace('org/', 'M_'), key === 'org/r3' ? { projectKnown: false, warning: 'not registered' } : {});
    },
    status: () => ({}),
  };
  const orchestrator = createOrchestrator({ scanners: [patternScanner], dir: storeDir, userRulesDir: null, userGrammarsDir: null, ruleSync });
  t.after(() => orchestrator.shutdown());
  const targets = Array.from({ length: 12 }, (_, i) => ({ repository: `org/r${i}`, repoPath: repoWithBoth(t) }));
  const scan = await orchestrator.startScan({ targets });
  assert.ok(peak > 1, `fetches ran one at a time (peak ${peak})`);
  assert.ok(peak <= 8, `fetch concurrency is unbounded (peak ${peak})`);
  assert.deepEqual(scan.ruleSets.map(r => r.repository), targets.map(x => x.repository));
  assert.equal(scan.ruleSets[3].warning, 'not registered');
  assert.equal(scan.ruleSets[3].projectKnown, false);
  await waitForScan(orchestrator, scan.id);
});

test('with no rules from the server and none cached, startScan fails with NO_RULES before creating anything', async (t) => {
  const storeDir = tmpdir('oasis-ws-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));
  const orchestrator = createOrchestrator({
    scanners: [patternScanner], dir: storeDir, userRulesDir: null, userGrammarsDir: null,
    ruleSync: { refresh: async () => null, status: () => ({}) },
  });
  t.after(() => orchestrator.shutdown());
  await assert.rejects(orchestrator.startScan({ targets: [{ repository: 'org/n', repoPath: storeDir }] }),
    e => e.code === 'NO_RULES' && /rules service is unreachable/.test(e.message));
});

test('without a rule server, rules supplied on the target are used (and local packs still merge)', async (t) => {
  const storeDir = tmpdir('oasis-ws-store-');
  t.after(() => fs.rmSync(storeDir, { recursive: true, force: true }));
  const userRulesDir = tmpdir('oasis-ws-user-');
  t.after(() => fs.rmSync(userRulesDir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(userRulesDir, 'p.json'), JSON.stringify({ rules: [
    { id: 'local-marker', language: 'text', severity: 'LOW', pattern: 'MARKER_B', files: ['**/*.txt'], title: 'b', category: 'TEST', fixture: { detect: 'MARKER_B', clean: 'z' } },
  ] }));
  const orchestrator = createOrchestrator({ scanners: [patternScanner], dir: storeDir, userRulesDir, userGrammarsDir: null });
  t.after(() => orchestrator.shutdown());
  const scan = await orchestrator.startScan({ targets: [{ repository: 'org/s', repoPath: repoWithBoth(t), ruleSet: markerSet('MARKER_A') }] });
  await waitForScan(orchestrator, scan.id);
  const ids = (await orchestrator.listFindings({ repository: 'org/s' })).flatMap(f => f.detections.map(d => d.ruleId)).sort();
  assert.deepEqual(ids, ['local-marker', 'rs-MARKER_A']);
});
