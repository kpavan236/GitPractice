'use strict';
const fs = require('fs');
const path = require('path');

function createRuleSetCache(baseDir) {
  const dir = path.join(baseDir, 'rule-server');
  const file = key => path.join(dir, `${encodeURIComponent(key).replace(/%/g, '_')}.json`);

  function read(key) {
    try {
      const rs = JSON.parse(fs.readFileSync(file(key), 'utf8'));
      return Array.isArray(rs.rules) && typeof rs.version === 'string' ? rs : null;
    } catch (_) {
      return null;
    }
  }

  function write(key, ruleSet) {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = `${file(key)}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(ruleSet));
    fs.renameSync(tmp, file(key));
  }

  return { read, write, dir };
}

module.exports = { createRuleSetCache };
