'use strict';
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { isActive, SEVERITY_RANK } = require('./finding');
const storeModule = require('./store');

// The quality gate: one binary answer a CI job can act on.
//
// Everything else in this tab informs a human. This exists to block a build,
// which is a different contract — it has to be deterministic, it has to explain
// itself, and it has to FAIL CLOSED. A gate that answers PASSED because it
// could not work something out is worse than no gate, because the green tick
// gets trusted.
//
// The default gate is deliberately scoped to NEW CODE. A gate on the total
// count of a repository with seven hundred open findings fails on day one,
// never goes green, and is switched off inside a week; a gate on what this
// change introduced is one a team can actually hold while the backlog is worked
// down separately. That is the whole Clean as You Code argument, and it is the
// difference between a gate that survives and one that gets an exemption.

const GATE_FILENAME = '.oasis-security-gate.yml';

// Checked into the repository ON PURPOSE, like the ignore file: a threshold
// change is then a reviewable diff in a pull request rather than a setting
// somebody moved in a UI at 6pm.
const DEFAULT_GATE = {
  name: 'default',
  conditions: [
    // Nothing new and critical, and no new secret. Both are absolutes: there is
    // no acceptable number of freshly committed credentials.
    { metric: 'critical_issues', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    { metric: 'secrets', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    { metric: 'high_severity_cves', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    // Coverage is a gate condition, not a footnote. A scan that did not check
    // SAST at all and found nothing is not a pass, and without this the gate
    // would happily go green on it.
    { metric: 'coverage_gaps', scope: 'OVERALL', operator: 'GT', threshold: 0, level: 'WARN' },
  ],
};

const OPERATORS = {
  GT: (actual, threshold) => actual > threshold,
  GTE: (actual, threshold) => actual >= threshold,
  LT: (actual, threshold) => actual < threshold,
  LTE: (actual, threshold) => actual <= threshold,
  EQ: (actual, threshold) => actual === threshold,
};

const OPERATOR_WORDS = { GT: '>', GTE: '>=', LT: '<', LTE: '<=', EQ: '=' };

// Each metric is a function of the findings in scope. Kept as a table so the
// set of things a gate can assert on is enumerable and testable, rather than
// scattered through a switch nobody can audit.
const METRICS = {
  vulnerabilities: findings => findings.filter(f => ['SAST', 'SCA', 'IAC', 'CONTAINER', 'DAST'].includes(f.type)).length,
  secrets: findings => findings.filter(f => f.type === 'SECRET').length,
  iac_misconfigurations: findings => findings.filter(f => f.type === 'IAC').length,
  license_violations: findings => findings.filter(f => f.type === 'LICENSE').length,

  critical_issues: findings => findings.filter(f => f.severity === 'CRITICAL').length,
  blocker_issues: findings => findings.filter(f => ['CRITICAL', 'HIGH'].includes(f.severity)).length,

  high_severity_cves: findings =>
    findings.filter(f => f.type === 'SCA' && ['CRITICAL', 'HIGH'].includes(f.severity)).length,

  // The worst risk score present, not a sum: a gate should react to the single
  // most dangerous thing, and a total would let fifty trivial findings
  // outweigh one exploited CVE.
  risk_score: findings => findings.reduce((worst, f) => Math.max(worst, (f.risk && f.risk.score) || 0), 0),
};

// Not derived from findings — derived from what the scan CHECKED. Separate for
// that reason: every other metric counts things that were found, and this one
// counts things that were not looked at.
function coverageGaps(coverage) {
  return (coverage || []).filter(c => !c.analysed).length;
}

/**
 * Reads a repository's gate, falling back to the default.
 *
 * A malformed file is a FAILURE, not a silent fallback to the default. Someone
 * edited the gate and got it wrong; quietly running different thresholds than
 * the ones in the file is how a build passes for reasons nobody can reconstruct.
 */
function loadGate(repoPath, { repository, store = storeModule, dir } = {}) {
  // 1. Store config (if repository and dir are provided)
  if (repository && dir) {
    const storeGate = store.loadGateConfig(repository, dir);
    if (storeGate !== null) {
      if (!Array.isArray(storeGate.conditions) || !storeGate.conditions.length) {
        return { gate: null, source: 'settings', error: 'no conditions defined' };
      }
      for (const condition of storeGate.conditions) {
        if (!METRICS[condition.metric] && condition.metric !== 'coverage_gaps') {
          return { gate: null, source: 'settings', error: `unknown metric "${condition.metric}"` };
        }
        if (!OPERATORS[condition.operator]) {
          return { gate: null, source: 'settings', error: `unknown operator "${condition.operator}"` };
        }
        if (typeof condition.threshold !== 'number') {
          return { gate: null, source: 'settings', error: `${condition.metric}: threshold must be a number` };
        }
      }
      return { gate: { name: storeGate.name || 'settings', conditions: storeGate.conditions }, source: 'settings', error: null };
    }
  }

  // 2. YAML file (existing logic unchanged)
  const file = path.join(repoPath || '.', GATE_FILENAME);
  if (!fs.existsSync(file)) return { gate: DEFAULT_GATE, source: 'default', error: null };

  let parsed;
  try {
    parsed = yaml.load(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return { gate: null, source: GATE_FILENAME, error: `unreadable: ${e.message.split('\n')[0]}` };
  }

  if (!parsed || !Array.isArray(parsed.conditions) || !parsed.conditions.length) {
    return { gate: null, source: GATE_FILENAME, error: 'no conditions defined' };
  }

  for (const condition of parsed.conditions) {
    if (!METRICS[condition.metric] && condition.metric !== 'coverage_gaps') {
      return { gate: null, source: GATE_FILENAME, error: `unknown metric "${condition.metric}"` };
    }
    if (!OPERATORS[condition.operator]) {
      return { gate: null, source: GATE_FILENAME, error: `unknown operator "${condition.operator}"` };
    }
    if (typeof condition.threshold !== 'number') {
      return { gate: null, source: GATE_FILENAME, error: `${condition.metric}: threshold must be a number` };
    }
  }

  return { gate: { name: parsed.name || 'custom', conditions: parsed.conditions }, source: GATE_FILENAME, error: null };
}

function scopeFindings(findings, scope) {
  const active = (findings || []).filter(isActive);
  return scope === 'NEW_CODE' ? active.filter(f => f.isNewCode) : active;
}

/**
 * Evaluates a gate.
 *
 * @param {object} input
 *   findings      the scan's findings, already marked by diff.markNewCode
 *   coverage      the scan's per-capability coverage
 *   gate          a gate definition, or omitted for the default
 *   newCodeAvailable  whether the diff could be taken at all
 *
 * @returns {{ status, conditions, ... }} status is PASSED | FAILED | WARN | NOT_EVALUATED
 */
function evaluateGate({ findings = [], coverage = [], gate = DEFAULT_GATE, newCodeAvailable = true, gateError = null } = {}) {
  // A gate that could not be read does not pass. This is the fail-closed rule
  // the whole module exists to honour.
  if (gateError || !gate) {
    return {
      status: 'NOT_EVALUATED',
      gate: null,
      conditions: [],
      reason: gateError || 'no gate definition',
      blocking: true,
    };
  }

  const results = [];

  for (const condition of gate.conditions) {
    const scope = condition.scope || 'NEW_CODE';
    const level = condition.level === 'WARN' ? 'WARN' : 'ERROR';

    // A NEW_CODE condition with no diff cannot be evaluated. Reporting it as
    // passed would mean every shallow clone in CI silently disables the gate —
    // which is precisely the configuration a build runs in by default.
    if (scope === 'NEW_CODE' && !newCodeAvailable) {
      results.push({
        ...condition,
        scope,
        level,
        actual: null,
        passed: false,
        status: 'NOT_EVALUATED',
        explanation: 'no diff available, so new code could not be identified',
      });
      continue;
    }

    const scoped = scopeFindings(findings, scope);
    const actual = condition.metric === 'coverage_gaps'
      ? coverageGaps(coverage)
      : METRICS[condition.metric](
          condition.severity ? scoped.filter(f => f.severity === condition.severity) : scoped
        );

    // A condition states what makes the gate FAIL — "critical_issues GT 0"
    // means fail when there is more than none — so the condition passing is the
    // operator NOT matching. Stated here because the inverse reads naturally
    // and is wrong.
    const breached = OPERATORS[condition.operator](actual, condition.threshold);

    results.push({
      ...condition,
      scope,
      level,
      actual,
      passed: !breached,
      status: breached ? level : 'PASSED',
      explanation: `${condition.metric}${condition.severity ? ` (${condition.severity})` : ''} `
        + `in ${scope === 'NEW_CODE' ? 'new code' : 'overall code'} is ${actual}, `
        + `${breached ? 'which breaches' : 'within'} ${OPERATOR_WORDS[condition.operator]} ${condition.threshold}`,
    });
  }

  const failed = results.filter(r => r.status === 'ERROR' || r.status === 'NOT_EVALUATED');
  const warned = results.filter(r => r.status === 'WARN');

  return {
    status: failed.length ? 'FAILED' : warned.length ? 'WARN' : 'PASSED',
    gate: gate.name,
    conditions: results,
    // The one field a CI job needs. WARN does not block: a warning that fails
    // the build is an error wearing a different word, and teams stop
    // distinguishing them.
    blocking: failed.length > 0,
    failedCount: failed.length,
    warnCount: warned.length,
    reason: failed.length
      ? failed.map(r => r.explanation).join('; ')
      : null,
  };
}

function saveGate(repository, gate, { store = storeModule, dir } = {}) {
  return store.saveGateConfig(repository, gate, dir);
}

function clearGate(repository, { store = storeModule, dir } = {}) {
  return store.clearGateConfig(repository, dir);
}

module.exports = {
  evaluateGate,
  loadGate,
  saveGate,
  clearGate,
  coverageGaps,
  scopeFindings,
  METRICS,
  OPERATORS,
  DEFAULT_GATE,
  GATE_FILENAME,
};
