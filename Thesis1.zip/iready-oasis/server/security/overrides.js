'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { SEVERITY_RANK } = require('./finding');

// Per-project rule overrides: which rules a project switches off and which severities it changes.
// Kept on this machine only (~/.oasis-security/overrides.json); the rules service never sees them.
// Unknown rule ids are stored and ignored by apply(): a rule can leave a release and come back.
const DEFAULT_FILE = path.join(os.homedir(), '.oasis-security', 'overrides.json');

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const validSeverity = (v) => typeof v === 'string' && Object.hasOwn(SEVERITY_RANK, v);
const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function createOverrides({ file = DEFAULT_FILE } = {}) {
  // Reads the whole file. Missing is empty. Damaged JSON is moved aside (so a later write cannot wipe other
  // projects' data) when `forWrite`; any other read error (permissions, I/O) is thrown to a writer, because
  // writing on top of a file we could not read would destroy it.
  function load(forWrite = false) {
    let text;
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      if (e && e.code === 'ENOENT') return {};
      if (forWrite) throw e;
      return {};     // a scan must not fail because of a preferences file it cannot read
    }
    try {
      const data = JSON.parse(text);
      if (isObj(data)) return data;
      throw new Error('not an object');
    } catch (_) {
      if (forWrite) fs.renameSync(file, `${file}.bak.${Date.now()}`);
      return {};
    }
  }
  function normalise(entry) {
    const e = isObj(entry) ? entry : {};
    return {
      disabled: Array.isArray(e.disabled) ? e.disabled.filter((x) => typeof x === 'string') : [],
      severity: isObj(e.severity) ? Object.fromEntries(Object.entries(e.severity).filter(([, v]) => validSeverity(v))) : {},
    };
  }

  function get(projectKey) {
    const all = load();
    const e = normalise(typeof projectKey === 'string' && Object.hasOwn(all, projectKey) ? all[projectKey] : null);
    return { disabled: [...e.disabled], severity: { ...e.severity } };
  }

  function set(projectKey, patch = {}) {
    if (typeof projectKey !== 'string' || !projectKey) throw new Error('projectKey is required');
    if (FORBIDDEN_KEYS.has(projectKey)) throw new Error(`projectKey "${projectKey}" is not allowed`);
    if (patch.disabled !== undefined && (!Array.isArray(patch.disabled) || !patch.disabled.every((x) => typeof x === 'string'))) {
      throw new Error('disabled must be an array of rule ids');
    }
    if (patch.severity !== undefined) {
      if (!isObj(patch.severity)) throw new Error('severity must be an object of rule id to severity');
      for (const [id, v] of Object.entries(patch.severity)) {
        if (!validSeverity(v)) throw new Error(`severity of ${id} must be one of ${Object.keys(SEVERITY_RANK).join(', ')}`);
      }
    }
    const all = load(true);
    const current = normalise(Object.hasOwn(all, projectKey) ? all[projectKey] : null);
    all[projectKey] = {
      disabled: patch.disabled !== undefined ? [...new Set(patch.disabled)] : current.disabled,
      severity: patch.severity !== undefined ? { ...patch.severity } : current.severity,
    };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.tmp`;
    try {
      fs.writeFileSync(tmp, JSON.stringify(all, null, 2));
      fs.renameSync(tmp, file);
    } catch (e) {
      try { fs.rmSync(tmp, { force: true }); } catch (_) { /* nothing more to do */ }
      throw e;
    }
    return get(projectKey);
  }

  function apply(rules, projectKey) {
    const o = get(projectKey);
    if (!o.disabled.length && !Object.keys(o.severity).length) return rules;
    const off = new Set(o.disabled);
    return rules.filter((r) => !off.has(r.id)).map((r) => (Object.prototype.hasOwnProperty.call(o.severity, r.id) ? { ...r, severity: o.severity[r.id] } : r));
  }

  return { get, set, apply };
}

module.exports = { createOverrides, DEFAULT_FILE };
