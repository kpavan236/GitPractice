'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { execFileSync } = require('child_process');
const { createMirror, indexPath, INDEX_VERSION } = require('./advisories/mirror');
const { listEntries, eachEntry } = require('./advisories/zip');
const { buildIndex, compact } = require('../../tools/build-advisories');
const { fetchOsvVulnerabilities } = require('../version-watch/registries/osv');

// ── The zip reader ─────────────────────────────────────────────────────────
//
// Tested against archives made by the system `zip`, not hand-built fixtures:
// the failure modes here are all about real-world header layout, and a fixture
// written to match my own parser would agree with it about everything,
// including the parts that are wrong.

function tempZip(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-zip-'));
  for (const [name, content] of Object.entries(files)) {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  const archive = path.join(dir, 'out.zip');
  execFileSync('zip', ['-q', '-r', archive, '.', '-x', 'out.zip'], { cwd: dir });
  return { dir, buffer: fs.readFileSync(archive) };
}

test('reads entries through the central directory', () => {
  const { dir, buffer } = tempZip({ 'a.json': '{"id":"A"}', 'nested/b.json': '{"id":"B"}' });
  // `zip` may or may not prefix entries with "./" depending on the platform,
  // and the reader must not care either way.
  const names = listEntries(buffer)
    .map(e => e.name.replace(/^\.\//, ''))
    .filter(n => !n.endsWith('/'))
    .sort();
  assert.deepEqual(names, ['a.json', 'nested/b.json']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('inflates deflated entries', () => {
  // Highly repetitive content so `zip` definitely chooses deflate rather than
  // storing it — otherwise the interesting path is never exercised.
  const content = JSON.stringify({ id: 'A', details: 'x'.repeat(5000) });
  const { dir, buffer } = tempZip({ 'big.json': content });

  const seen = {};
  eachEntry(buffer, (name, data) => { seen[name.replace(/^\.\//, '')] = data.toString('utf8'); });
  assert.equal(seen['big.json'], content);

  const entry = listEntries(buffer).find(e => e.name.endsWith('big.json'));
  assert.equal(entry.method, 8, 'expected this entry to be deflated');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('skips directory entries', () => {
  const { dir, buffer } = tempZip({ 'nested/b.json': '{}' });
  const names = [];
  eachEntry(buffer, name => names.push(name));
  assert.ok(names.every(n => !n.endsWith('/')));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('refuses what it does not understand instead of returning garbage', () => {
  assert.throws(() => listEntries(Buffer.from('not a zip at all')), /not a zip archive/);
});

// ── Index building ─────────────────────────────────────────────────────────

const ADVISORY = {
  id: 'GHSA-test-0001',
  aliases: ['CVE-2024-0001'],
  summary: 'A test advisory',
  details: 'x'.repeat(20000),
  references: Array.from({ length: 40 }, (_, i) => ({ type: 'WEB', url: `https://example.invalid/${i}` })),
  database_specific: { severity: 'HIGH', cwe_ids: ['CWE-79'] },
  affected: [{
    package: { ecosystem: 'Hex', name: 'demo_pkg' },
    ranges: [{ type: 'ECOSYSTEM', events: [{ introduced: '1.0.0' }, { fixed: '1.5.0' }] }],
  }],
};

test('the index keeps the ranges and drops the bulk', () => {
  // The whole reason a mirror is viable: npm's export is 219 MB, and it is the
  // prose and references that make it so. If this ever starts keeping the full
  // record the index quietly grows back and the only symptom is a slow disk.
  const small = compact(ADVISORY);
  assert.equal(small.details, undefined);
  assert.equal(small.references, undefined);
  assert.ok(small.affected[0].ranges, 'the ranges ARE the data');
  assert.ok(JSON.stringify(small).length < JSON.stringify(ADVISORY).length / 10);
});

test('builds an index from an archive of advisories', () => {
  const { dir, buffer } = tempZip({ 'GHSA-test-0001.json': JSON.stringify(ADVISORY) });
  const index = buildIndex(buffer, 'Hex');

  assert.equal(index.indexVersion, INDEX_VERSION);
  assert.deepEqual(index.packages.demo_pkg, ['GHSA-test-0001']);
  assert.ok(index.advisories['GHSA-test-0001']);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('withdrawn advisories are left out', () => {
  // A retracted advisory reported as live is a false positive wearing an
  // authoritative id.
  const { dir, buffer } = tempZip({
    'a.json': JSON.stringify({ ...ADVISORY, withdrawn: '2024-02-01T00:00:00Z' }),
  });
  assert.deepEqual(Object.keys(buildIndex(buffer, 'Hex').advisories), []);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('one unreadable record does not cost the others', () => {
  const { dir, buffer } = tempZip({
    'good.json': JSON.stringify(ADVISORY),
    'bad.json': '{ not json',
  });
  const index = buildIndex(buffer, 'Hex');
  assert.equal(Object.keys(index.advisories).length, 1);
  assert.equal(index.skipped, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Lookup ─────────────────────────────────────────────────────────────────

function mirrorWith(index) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-mirror-'));
  fs.writeFileSync(indexPath('hex', dir), zlib.gzipSync(JSON.stringify(index)));
  return { dir, mirror: createMirror({ dir }) };
}

test('finds an affected version and clears a fixed one', () => {
  const { dir, buffer } = tempZip({ 'a.json': JSON.stringify(ADVISORY) });
  const { dir: mdir, mirror } = mirrorWith(buildIndex(buffer, 'Hex'));

  assert.equal(mirror.lookup('hex', 'demo_pkg', '1.2.0').length, 1);
  assert.equal(mirror.lookup('hex', 'demo_pkg', '1.5.0').length, 0);
  assert.equal(mirror.lookup('hex', 'demo_pkg', '1.2.0')[0].id, 'GHSA-test-0001');

  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(mdir, { recursive: true, force: true });
});

test('an UNMIRRORED ecosystem returns null, not an empty array', () => {
  // The distinction the whole design rests on. "No known vulnerabilities" and
  // "we have no data" must never be the same answer, or every package in an
  // unmirrored ecosystem silently reads as clean.
  const { dir, mirror } = mirrorWith({ indexVersion: INDEX_VERSION, packages: {}, advisories: {} });
  assert.equal(mirror.lookup('npm', 'lodash', '4.17.20'), null);
  assert.deepEqual(mirror.lookup('hex', 'anything', '1.0.0'), []);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('an index from an older build is refused rather than half-read', () => {
  const { dir, mirror } = mirrorWith({ indexVersion: 999, packages: { x: ['A'] }, advisories: {} });
  assert.equal(mirror.lookup('hex', 'x', '1.0.0'), null, 'must fall through to the network');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a corrupt index reads as absent so the scan falls back', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-mirror-'));
  fs.writeFileSync(indexPath('hex', dir), Buffer.from('not gzip'));
  assert.equal(createMirror({ dir }).lookup('hex', 'x', '1.0.0'), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('status reports what is mirrored and how old it is', () => {
  const { dir, buffer } = tempZip({ 'a.json': JSON.stringify(ADVISORY) });
  const { dir: mdir, mirror } = mirrorWith(buildIndex(buffer, 'Hex'));

  const status = mirror.status();
  assert.equal(status.available, true);
  assert.equal(status.ecosystems[0].ecosystem, 'hex');
  assert.equal(status.ecosystems[0].advisories, 1);
  // A mirror that stopped updating months ago is a quiet failure.
  assert.equal(typeof status.ecosystems[0].ageDays, 'number');

  fs.rmSync(dir, { recursive: true, force: true });
  fs.rmSync(mdir, { recursive: true, force: true });
});

// ── The lookup path ────────────────────────────────────────────────────────

test('the mirror short-circuits the network when it has the ecosystem', async () => {
  const mirror = {
    lookup: () => [{ id: 'GHSA-x', aliases: ['CVE-2024-1234'], severity: 'HIGH', summary: 's', url: 'u' }],
  };
  const httpClient = { post: () => { throw new Error('the network must not be called'); } };

  const result = await fetchOsvVulnerabilities('Hex', 'demo_pkg', '1.2.0', httpClient, { mirror });
  assert.equal(result.source, 'mirror');
  assert.equal(result.cves[0].id, 'CVE-2024-1234', 'the CVE alias is preferred over the GHSA id');
});

test('an unmirrored ecosystem falls through to the API', async () => {
  const mirror = { lookup: () => null };
  let called = false;
  const httpClient = {
    post: async () => { called = true; return { data: { vulns: [] } }; },
  };

  const result = await fetchOsvVulnerabilities('npm', 'lodash', '4.17.20', httpClient, { mirror });
  assert.equal(called, true);
  assert.equal(result.source, 'api');
});

test('offline mode says why it found nothing instead of reporting clean', async () => {
  // Without this, an unmirrored ecosystem on an air-gapped network times out
  // per dependency and then reports nothing — slowly, and looking exactly like
  // a clean result.
  const result = await fetchOsvVulnerabilities('npm', 'lodash', '4.17.20', null, {
    mirror: { lookup: () => null },
    env: { OASIS_ADVISORY_OFFLINE: '1' },
  });
  assert.deepEqual(result.cves, []);
  assert.match(result.error, /not in the offline advisory mirror/);
  assert.equal(result.source, 'offline');
});
