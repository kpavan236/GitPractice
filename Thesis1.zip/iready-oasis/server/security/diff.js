'use strict';
const { runTool } = require('./scanner');
const { toPosix } = require('./paths');

// "New code" — findings introduced by the change under review.
//
// This is the primitive Clean as You Code rests on, and the reason it matters
// is arithmetic: a repository with seven hundred open findings will never be
// cleared, so a gate on the total is a gate that fails forever and gets turned
// off within a week. A gate on what THIS change introduced is one a team can
// actually hold, and it stops the number growing while the backlog is worked
// down separately.
//
// The baseline in ignore.js answers a related but different question — "what
// was already here when we started" — and it is a snapshot taken by hand. This
// is derived from git on every scan, needs no ceremony, and knows which LINES
// changed rather than only which findings existed. Both are kept: the baseline
// survives a shallow clone or a missing base ref, which is exactly when this
// cannot answer at all.

const DEFAULT_BASE = 'HEAD~1';

// A hunk header: @@ -old,count +new,count @@
const HUNK = /^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@/;

/**
 * Added and modified line numbers per file, for a diff between two refs.
 *
 * `-U0` so the ranges are the changed lines themselves rather than three lines
 * of surrounding context. Context lines are not new code, and counting them
 * would attribute a pre-existing finding to whoever edited the line above it.
 *
 * Returns a Map of posix path → Set of line numbers, or null when the diff
 * could not be taken. NULL IS A REAL ANSWER and is deliberately not an empty
 * Map: "nothing changed" and "we could not tell what changed" must not be the
 * same value, because the first means a gate should pass and the second means
 * it has no basis to.
 */
async function changedLines(repoPath, { base = DEFAULT_BASE, head = 'HEAD', timeoutMs = 60000 } = {}) {
  const result = await runTool(
    'git',
    [
      'diff', '--unified=0', '--no-color', '--no-ext-diff',
      // Renames are followed so a moved file's untouched lines are not all
      // reported as new.
      '--find-renames',
      '--diff-filter=ACMR',
      `${base}...${head}`,
    ],
    { cwd: repoPath, timeoutMs }
  );

  // A shallow clone, an unknown ref, or a repository with one commit. All of
  // them mean "cannot tell", which the caller must handle differently from
  // "nothing changed".
  if (result.error || result.timedOut || result.code !== 0) return null;

  return parseDiff(result.stdout);
}

/**
 * Parses `git diff -U0` output into changed line numbers per file.
 *
 * Exported and pure, because the interesting failures here are parsing ones and
 * they are far cheaper to test against a fixture than against a repository.
 */
function parseDiff(text) {
  const byFile = new Map();
  let current = null;

  for (const line of String(text || '').split('\n')) {
    // `+++ b/path` names the file the following hunks belong to. /dev/null
    // means a deletion, which introduces no code.
    if (line.startsWith('+++ ')) {
      const target = line.slice(4).trim();
      current = target === '/dev/null' ? null : toPosix(target.replace(/^b\//, ''));
      if (current && !byFile.has(current)) byFile.set(current, new Set());
      continue;
    }

    if (!current) continue;

    const hunk = HUNK.exec(line);
    if (!hunk) continue;

    const start = parseInt(hunk[1], 10);
    // `@@ -1 +5 @@` with no count means exactly one line.
    const count = hunk[2] === undefined ? 1 : parseInt(hunk[2], 10);
    // A count of zero is a pure deletion: the hunk removes lines and adds none,
    // so there is nothing new to attribute.
    for (let i = 0; i < count; i++) byFile.get(current).add(start + i);
  }

  return byFile;
}

/**
 * Whether one finding sits in changed code.
 *
 * Two cases, and the second is the one that needs stating:
 *
 *   A finding WITH a line is new when that line changed. Straightforward.
 *
 *   A finding with NO line — an SCA advisory against a package, an IaC policy
 *   violation about a resource — is new when its file changed at all. A
 *   vulnerable dependency appears because someone edited the lockfile, and
 *   refusing to attribute it because the advisory has no line number would let
 *   every new CVE through a gate untouched.
 */
function isInChangedCode(finding, changed) {
  if (!changed) return false;

  const file = toPosix(finding.file || (finding.metadata && finding.metadata.lockfile) || '');
  if (!file) return false;

  const lines = changed.get(file);
  if (!lines) return false;
  if (!finding.startLine) return lines.size > 0;

  const from = finding.startLine;
  const to = finding.endLine || finding.startLine;
  for (let line = from; line <= to; line++) {
    if (lines.has(line)) return true;
  }
  return false;
}

/**
 * Marks findings that the change introduced.
 *
 * Returns `{ findings, base, head, available, reason }`. When the diff could
 * not be taken, `available` is false and NOTHING is marked new — a gate reading
 * this must fail closed on that rather than reporting a clean new-code result
 * it has no evidence for.
 */
async function markNewCode(findings, repoPath, { base = DEFAULT_BASE, head = 'HEAD', timeoutMs } = {}) {
  const changed = await changedLines(repoPath, { base, head, timeoutMs });

  if (!changed) {
    return {
      findings: (findings || []).map(f => ({ ...f, isNewCode: false })),
      base,
      head,
      available: false,
      reason: `could not diff ${base}...${head} — a shallow clone or an unknown ref`,
    };
  }

  return {
    findings: (findings || []).map(f => ({ ...f, isNewCode: isInChangedCode(f, changed) })),
    base,
    head,
    available: true,
    reason: null,
    changedFiles: changed.size,
    changedLines: [...changed.values()].reduce((n, s) => n + s.size, 0),
  };
}

module.exports = { markNewCode, changedLines, parseDiff, isInChangedCode, DEFAULT_BASE };
