'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { affecting, rangeAffects, affectedEntryMatches, severityOf } = require('./advisories/ranges');

// "Does this advisory affect this version" is the question the whole SCA path
// rests on. A false negative means a live CVE in a shipped dependency is never
// reported, so most of these tests are about that direction.

const range = (...events) => ({ type: 'SEMVER', events });

test('a version inside an introduced/fixed window is affected', () => {
  const r = range({ introduced: '1.0.0' }, { fixed: '1.5.0' });
  assert.equal(rangeAffects(r, '1.2.0'), true);
});

test('the fixed version itself is NOT affected', () => {
  // Off by one here means telling everyone who already upgraded that they are
  // still vulnerable — the fastest way to lose trust in the scanner.
  const r = range({ introduced: '1.0.0' }, { fixed: '1.5.0' });
  assert.equal(rangeAffects(r, '1.5.0'), false);
  assert.equal(rangeAffects(r, '1.5.1'), false);
});

test('a version below the introduced point is not affected', () => {
  assert.equal(rangeAffects(range({ introduced: '2.0.0' }, { fixed: '2.1.0' }), '1.9.0'), false);
});

test('last_affected includes the named version', () => {
  // The mirror image of `fixed`: last_affected IS vulnerable, fixed is NOT.
  const r = range({ introduced: '1.0.0' }, { last_affected: '1.5.0' });
  assert.equal(rangeAffects(r, '1.5.0'), true);
  assert.equal(rangeAffects(r, '1.5.1'), false);
});

test('introduced "0" means from the beginning', () => {
  const r = range({ introduced: '0' }, { fixed: '4.17.21' });
  assert.equal(rangeAffects(r, '0.0.1'), true);
  assert.equal(rangeAffects(r, '4.17.20'), true);
  assert.equal(rangeAffects(r, '4.17.21'), false);
});

test('an unfixed advisory affects everything from its introduction on', () => {
  const r = range({ introduced: '2.0.0' });
  assert.equal(rangeAffects(r, '2.0.0'), true);
  assert.equal(rangeAffects(r, '99.0.0'), true);
  assert.equal(rangeAffects(r, '1.0.0'), false);
});

test('events are processed in VERSION order, not array order', () => {
  // A regression: fixed in 1.5, broken again in 2.0, fixed again in 2.5. Walking
  // the array as given — when the database lists them out of order — closes the
  // wrong window and clears a version that is genuinely vulnerable.
  const r = range(
    { fixed: '2.5.0' },
    { introduced: '1.0.0' },
    { fixed: '1.5.0' },
    { introduced: '2.0.0' }
  );
  assert.equal(rangeAffects(r, '1.2.0'), true, 'first window');
  assert.equal(rangeAffects(r, '1.7.0'), false, 'between the windows');
  assert.equal(rangeAffects(r, '2.1.0'), true, 'second window');
  assert.equal(rangeAffects(r, '2.5.0'), false, 'fixed again');
});

test('a GIT range is skipped rather than compared to a version', () => {
  // Commit hashes cannot be ordered against "1.2.3". Guessing produces
  // confident nonsense.
  const git = { type: 'GIT', events: [{ introduced: 'a1b2c3d' }, { fixed: 'e4f5g6h' }] };
  assert.equal(rangeAffects(git, '1.2.3'), false);
});

// ── Whole advisory entries ─────────────────────────────────────────────────

test('an explicit versions list matches exactly', () => {
  const entry = { package: { name: 'lodash' }, versions: ['4.17.20', '4.17.19'] };
  assert.equal(affectedEntryMatches(entry, 'lodash', '4.17.20'), true);
});

test('a versions list that misses the version falls through to the ranges', () => {
  // OSV entries often carry BOTH, and the list is frequently incomplete for
  // ecosystems with many releases. Treating a miss as proof of safety is how a
  // real vulnerability goes unreported.
  const entry = {
    package: { name: 'lodash' },
    versions: ['4.17.19'],
    ranges: [range({ introduced: '0' }, { fixed: '4.17.21' })],
  };
  assert.equal(affectedEntryMatches(entry, 'lodash', '4.17.20'), true);
});

test('a different package is never matched', () => {
  const entry = { package: { name: 'lodash' }, ranges: [range({ introduced: '0' })] };
  assert.equal(affectedEntryMatches(entry, 'underscore', '1.0.0'), false);
});

test('package names match case-insensitively', () => {
  // Maven and NuGet coordinates vary in case between manifests and advisories.
  const entry = { package: { name: 'Newtonsoft.Json' }, ranges: [range({ introduced: '0' })] };
  assert.equal(affectedEntryMatches(entry, 'newtonsoft.json', '12.0.0'), true);
});

test('a leading v is tolerated on either side', () => {
  const entry = { package: { name: 'x' }, versions: ['v1.2.3'] };
  assert.equal(affectedEntryMatches(entry, 'x', '1.2.3'), true);
  assert.equal(affectedEntryMatches(entry, 'x', 'v1.2.3'), true);
});

test('filters a list of advisories down to the ones that apply', () => {
  const advisories = [
    { id: 'A', affected: [{ package: { name: 'lodash' }, ranges: [range({ introduced: '0' }, { fixed: '4.17.21' })] }] },
    { id: 'B', affected: [{ package: { name: 'lodash' }, ranges: [range({ introduced: '5.0.0' })] }] },
    { id: 'C', affected: [{ package: { name: 'express' }, ranges: [range({ introduced: '0' })] }] },
  ];
  assert.deepEqual(affecting(advisories, { name: 'lodash', version: '4.17.20' }).map(a => a.id), ['A']);
});

test('malformed input is not affected, and does not throw', () => {
  assert.equal(rangeAffects(null, '1.0.0'), false);
  assert.equal(rangeAffects({ events: null }, '1.0.0'), false);
  assert.equal(affectedEntryMatches({}, 'x', '1.0.0'), false);
  assert.equal(affectedEntryMatches({ package: { name: 'x' } }, 'x', ''), false);
  assert.deepEqual(affecting(null, { name: 'x', version: '1' }), []);
});

// ── Severity ───────────────────────────────────────────────────────────────

test('reads severity from wherever the publisher put it', () => {
  assert.equal(severityOf({ database_specific: { severity: 'HIGH' } }), 'HIGH');
  // GitHub says MODERATE where the rest of the product says MEDIUM.
  assert.equal(severityOf({ database_specific: { severity: 'MODERATE' } }), 'MEDIUM');
  assert.deepEqual(
    severityOf({ severity: [{ type: 'CVSS_V3', score: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H' }] }),
    { vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H' }
  );
});

test('an advisory with no stated severity is MEDIUM, not dropped', () => {
  assert.equal(severityOf({}), 'MEDIUM');
});
