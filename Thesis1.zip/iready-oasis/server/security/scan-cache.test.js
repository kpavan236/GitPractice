'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createCache, cacheKey } = require('./scan-cache');

// Re-scanning a repository nobody touched costs exactly as much as the first
// scan: every file is read, every regex is run, every syntax tree is rebuilt.
// On one real repository that is ~4s of pure CPU to rediscover findings that
// cannot have changed, and it is the reason scanning 250 repositories is an
// hour rather than a coffee.
//
// Caching findings per file is only safe because the content scanners are pure
// functions of (content, path, rules) — no cross-file state, no ordering. These
// tests are mostly about the things that make a cached result WRONG, because a
// stale security finding is worse than a slow one.

const dirFor = () => fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-cache-'));
const file = (relPath, sha256) => ({ relPath, sha256 });
const FINDING = { id: 'f1', file: 'a.js', title: 'Hardcoded password', fingerprint: 'abc' };

test('a file with the same content hits', () => {
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  assert.deepEqual(cache.get('SECRETS', file('a.js', 'sha-1')), [FINDING]);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('edited content misses', () => {
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  assert.equal(cache.get('SECRETS', file('a.js', 'sha-2')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the same content at a different path misses', () => {
  // Findings carry their file path, in the evidence and in the fingerprint.
  // Reusing them across paths would report the finding against the wrong file.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  assert.equal(cache.get('SECRETS', file('copy/a.js', 'sha-1')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('one scanner\'s result is never served to another', () => {
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  assert.equal(cache.get('AST_SAST', file('a.js', 'sha-1')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('new rules invalidate everything', () => {
  // THE DANGEROUS ONE. A rule bundle ships a new rule, the files have not
  // changed, and a cache keyed only on content would report the old findings —
  // so the new rule silently never fires on any existing code. The rule would
  // look installed and find nothing.
  const dir = dirFor();
  createCache({ dir, repository: 'repo', bundleVersion: '1' })
    .set('SECRETS', file('a.js', 'sha-1'), [FINDING]);

  const withNewRules = createCache({ dir, repository: 'repo', bundleVersion: '2' });
  assert.equal(withNewRules.get('SECRETS', file('a.js', 'sha-1')), null,
    'a new rule bundle must re-scan everything');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a new app version invalidates everything', () => {
  // The scanners' own logic changes between releases too. Keying on the rule
  // bundle alone would keep serving findings produced by the previous engine.
  const dir = dirFor();
  createCache({ dir, repository: 'repo', bundleVersion: '1', appVersion: '1.0.0' })
    .set('SECRETS', file('a.js', 'sha-1'), [FINDING]);

  const upgraded = createCache({ dir, repository: 'repo', bundleVersion: '1', appVersion: '1.1.0' });
  assert.equal(upgraded.get('SECRETS', file('a.js', 'sha-1')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('an empty result is cached, and is not confused with a miss', () => {
  // Most files contain nothing, so "this file is clean" is the overwhelming
  // majority of the cache and where nearly all the saving comes from. Treating
  // it as a miss would cache only the rare file and save nothing.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('clean.js', 'sha-1'), []);
  assert.deepEqual(cache.get('SECRETS', file('clean.js', 'sha-1')), [], 'a clean file is a hit');
  assert.equal(cache.get('SECRETS', file('unknown.js', 'sha-9')), null, 'an unknown file is a miss');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a finding carrying a live secret is never cached', () => {
  // Secret findings carry the plaintext on a non-enumerable field so the
  // verifier can check whether the credential is live. That field cannot
  // survive JSON, so a cached secret finding would come back unverifiable and
  // quietly downgrade every future scan of that file.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  const secret = { ...FINDING, type: 'SECRET' };
  Object.defineProperty(secret, '_plaintext', { value: 'AKIA2E0A8F3B244C9986', enumerable: false });

  cache.set('SECRETS', file('a.js', 'sha-1'), [secret]);
  assert.equal(cache.get('SECRETS', file('a.js', 'sha-1')), null, 'must re-scan rather than serve it');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('survives a restart', () => {
  const dir = dirFor();
  const first = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  first.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  first.save(['a.js']);

  const second = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  assert.deepEqual(second.get('SECRETS', file('a.js', 'sha-1')), [FINDING]);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('deleted files are pruned so the cache cannot grow forever', () => {
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  cache.set('SECRETS', file('kept.js', 'sha-1'), [FINDING]);
  cache.set('SECRETS', file('gone.js', 'sha-2'), [FINDING]);
  cache.save(['kept.js']);                   // gone.js was not seen this scan

  const reopened = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  assert.deepEqual(reopened.get('SECRETS', file('kept.js', 'sha-1')), [FINDING]);
  assert.equal(reopened.get('SECRETS', file('gone.js', 'sha-2')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('repositories do not share a cache', () => {
  const dir = dirFor();
  createCache({ dir, repository: 'repo-a', bundleVersion: '1' })
    .set('SECRETS', file('a.js', 'sha-1'), [FINDING]);

  const other = createCache({ dir, repository: 'repo-b', bundleVersion: '1' });
  assert.equal(other.get('SECRETS', file('a.js', 'sha-1')), null,
    'findings carry their repository name');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a corrupt cache file is ignored, not fatal', () => {
  // The cache is an optimisation. Anything wrong with it must cost speed, never
  // a scan.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  cache.save(['a.js']);

  fs.writeFileSync(cache.path, '{ this is not json');
  const reopened = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  assert.equal(reopened.get('SECRETS', file('a.js', 'sha-1')), null);
  assert.doesNotThrow(() => reopened.save(['a.js']));
  fs.rmSync(dir, { recursive: true, force: true });
});

test('it can be turned off entirely', () => {
  // For anyone who does not trust it, and to prove a bug is not the cache.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1', enabled: false });

  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  assert.equal(cache.get('SECRETS', file('a.js', 'sha-1')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('reports its own hit rate', () => {
  // So the coverage panel can say how much of a scan was actually re-examined.
  // A cache that silently serves everything is indistinguishable from a scanner
  // that stopped working.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });

  cache.set('SECRETS', file('a.js', 'sha-1'), []);
  cache.get('SECRETS', file('a.js', 'sha-1'));       // hit
  cache.get('SECRETS', file('b.js', 'sha-2'));       // miss

  assert.equal(cache.stats.hits, 1);
  assert.equal(cache.stats.misses, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the key is stable across processes', () => {
  // It is written to disk, so a key derived from anything process-local would
  // miss on every run and the cache would never do anything.
  const a = cacheKey({ appVersion: '1', bundleVersion: '2', scannerId: 'S', relPath: 'a.js', sha256: 'x' });
  const b = cacheKey({ appVersion: '1', bundleVersion: '2', scannerId: 'S', relPath: 'a.js', sha256: 'x' });
  assert.equal(a, b);
  assert.notEqual(a, cacheKey({ appVersion: '1', bundleVersion: '2', scannerId: 'S', relPath: 'a.js', sha256: 'y' }));
});

// ── Clearing ───────────────────────────────────────────────────────────────

const { clearCache } = require('./scan-cache');

test('clearing results drops the cache with them', () => {
  // Without this, "clear results" followed by a rescan hands back the very
  // findings that were just cleared, in a fraction of a second. To anyone
  // watching, the clear button did nothing.
  const dir = dirFor();
  const cache = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  cache.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
  cache.save(['a.js']);

  clearCache({ dir, repository: 'repo' });

  const after = createCache({ dir, repository: 'repo', bundleVersion: '1' });
  assert.equal(after.get('SECRETS', file('a.js', 'sha-1')), null, 'the file must be re-scanned');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing one repository leaves the others alone', () => {
  const dir = dirFor();
  for (const repo of ['keep', 'drop']) {
    const c = createCache({ dir, repository: repo, bundleVersion: '1' });
    c.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
    c.save(['a.js']);
  }

  clearCache({ dir, repository: 'drop' });

  assert.deepEqual(createCache({ dir, repository: 'keep', bundleVersion: '1' }).get('SECRETS', file('a.js', 'sha-1')), [FINDING]);
  assert.equal(createCache({ dir, repository: 'drop', bundleVersion: '1' }).get('SECRETS', file('a.js', 'sha-1')), null);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a full reset drops every repository', () => {
  const dir = dirFor();
  for (const repo of ['a', 'b']) {
    const c = createCache({ dir, repository: repo, bundleVersion: '1' });
    c.set('SECRETS', file('a.js', 'sha-1'), [FINDING]);
    c.save(['a.js']);
  }

  clearCache({ dir });

  for (const repo of ['a', 'b']) {
    assert.equal(createCache({ dir, repository: repo, bundleVersion: '1' }).get('SECRETS', file('a.js', 'sha-1')), null);
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clearing a cache that was never written is not an error', () => {
  assert.doesNotThrow(() => clearCache({ dir: '/nonexistent/oasis', repository: 'x' }));
  assert.doesNotThrow(() => clearCache({ dir: '/nonexistent/oasis' }));
});
