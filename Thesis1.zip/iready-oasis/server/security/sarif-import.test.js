'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { scanner, listSarifFiles, sarifDirs, isSarifName, SARIF_DIR } = require('./scanners/sarif-import');

function tempRepo(files = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-sarif-'));
  const dir = path.join(root, SARIF_DIR);
  fs.mkdirSync(dir, { recursive: true });
  for (const [name, content] of Object.entries(files)) {
    fs.writeFileSync(path.join(dir, name), typeof content === 'string' ? content : JSON.stringify(content));
  }
  return root;
}

function sarifDocument(tool, ruleId) {
  return {
    version: '2.1.0',
    runs: [
      {
        tool: { driver: { name: tool, version: '1.0' } },
        results: [
          {
            ruleId,
            level: 'error',
            message: { text: `${tool} found something` },
            locations: [{ physicalLocation: { artifactLocation: { uri: 'app/main.tf' }, region: { startLine: 3 } } }],
          },
        ],
      },
    ],
  };
}

test('imports every SARIF file in the directory', async () => {
  const repoPath = tempRepo({
    'trivy.sarif': sarifDocument('Trivy', 'CVE-2023-1234'),
    'checkov.sarif.json': sarifDocument('Checkov', 'CKV_AWS_20'),
  });

  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.equal(result.findings.length, 2);
  assert.deepEqual(result.stats.tools.sort(), ['Checkov', 'Trivy']);
  assert.deepEqual(result.stats.rejected, []);
  // The type each tool's findings land under — the reason this scanner exists.
  assert.deepEqual(result.findings.map(f => f.type).sort(), ['CONTAINER', 'IAC']);

  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('claims coverage only for the tools that actually reported', async () => {
  // A Trivy report is container coverage and says nothing about DAST or cloud
  // posture. Claiming those would put "analysed" against a capability nobody
  // ran — a dashboard saying something was checked when it was not.
  const repoPath = tempRepo({ 'trivy.sarif': sarifDocument('Trivy', 'CVE-2023-1234') });
  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.deepEqual(result.stats.produced, ['CONTAINER']);
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('a report with no findings still counts as coverage', async () => {
  // A ZAP run that found nothing IS a DAST test. The case this must not be
  // confused with is nobody having run ZAP at all, which is the skip above.
  const repoPath = tempRepo({
    'zap.sarif': { version: '2.1.0', runs: [{ tool: { driver: { name: 'OWASP ZAP' } }, results: [] }] },
  });
  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.deepEqual(result.findings, []);
  assert.deepEqual(result.stats.produced, ['DAST']);
  assert.equal(result.stats.skipped, undefined);
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('files that all fail to parse are a skip, not a clean scan', async () => {
  const repoPath = tempRepo({ 'broken.sarif': '{"runs": [', 'alsobroken.sarif': '<html>' });
  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.equal(result.stats.skipped, true);
  assert.equal(result.stats.rejected.length, 2);
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('an empty directory is SKIPPED, not a clean scan', async () => {
  // The distinction the whole coverage model rests on: "no container findings"
  // and "nobody scanned the container" must not look the same.
  const repoPath = tempRepo();
  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.equal(result.stats.skipped, true);
  assert.match(result.stats.reason, /no SARIF files/);
  assert.deepEqual(result.findings, []);
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('a repository with no .oasis directory at all is skipped quietly', async () => {
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-bare-'));
  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.equal(result.stats.skipped, true);
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('one broken file never costs the others', async () => {
  // A half-written SARIF from a cancelled CI job is the common case, and it
  // must not discard the files that are fine.
  const repoPath = tempRepo({
    'good.sarif': sarifDocument('Trivy', 'CVE-2023-1234'),
    'truncated.sarif': '{"runs": [',
    'notsarif.sarif': { hello: 'world' },
  });

  const result = await scanner.scan({ repoPath, repository: 'repo', env: {} });
  assert.equal(result.findings.length, 1);
  assert.equal(result.stats.rejected.length, 2);
  // A rejected file means a tool ran in CI and its results are not in this
  // scan, so each one names itself and why.
  assert.ok(result.stats.rejected.every(r => r.file && r.reason));

  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('reads an external directory when one is configured', async () => {
  // The CI case: tools write SARIF to a workspace artifacts directory beside
  // the checkout rather than into the repository itself.
  const external = tempRepo({ 'zap.sarif': sarifDocument('OWASP ZAP', 'X1') });
  const repoPath = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-repo-'));

  const result = await scanner.scan({
    repoPath,
    repository: 'repo',
    env: { OASIS_SARIF_DIR: path.join(external, SARIF_DIR) },
  });
  assert.equal(result.findings.length, 1);
  assert.equal(result.findings[0].type, 'DAST');

  fs.rmSync(external, { recursive: true, force: true });
  fs.rmSync(repoPath, { recursive: true, force: true });
});

test('only reads files named as SARIF', () => {
  // Restricted rather than parsing every .json in the directory: a package.json
  // that happened to land there is not a scan result.
  assert.equal(isSarifName('trivy.sarif'), true);
  assert.equal(isSarifName('trivy.SARIF.json'), true);
  assert.equal(isSarifName('package.json'), false);
  assert.equal(isSarifName('notes.txt'), false);
});

test('lists nothing for directories that do not exist', () => {
  assert.deepEqual(listSarifFiles(['/nonexistent/path/nowhere']), []);
  assert.deepEqual(sarifDirs(null, {}), []);
});

test('is always available — there is nothing to install', async () => {
  const state = await scanner.isAvailable();
  assert.equal(state.available, true);
});
