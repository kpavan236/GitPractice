'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { readSource, redactSecret, maskedPattern } = require('./source');

function repo(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-src-'));
  for (const [name, content] of Object.entries(files)) {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  return dir;
}

const CODE = Array.from({ length: 40 }, (_, i) => `line ${i + 1}`).join('\n');

test('returns a window of lines around the finding', () => {
  const dir = repo({ 'src/App.java': CODE });
  const out = readSource({ file: 'src/App.java', startLine: 20 }, dir, { context: 3 });

  assert.equal(out.error, null);
  assert.deepEqual(out.lines.map(l => l.number), [17, 18, 19, 20, 21, 22, 23]);
  assert.equal(out.lines.find(l => l.isFinding).number, 20);
  assert.equal(out.focusLine, 20);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('marks every line of a multi-line finding', () => {
  const dir = repo({ 'a.js': CODE });
  const out = readSource({ file: 'a.js', startLine: 10, endLine: 12 }, dir, { context: 1 });
  assert.deepEqual(out.lines.filter(l => l.isFinding).map(l => l.number), [10, 11, 12]);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('clamps at the start and end of the file', () => {
  const dir = repo({ 'a.js': 'one\ntwo\nthree' });
  const top = readSource({ file: 'a.js', startLine: 1 }, dir, { context: 5 });
  assert.deepEqual(top.lines.map(l => l.number), [1, 2, 3]);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── The traversal guard ────────────────────────────────────────────────────

test('refuses a path outside the repository', () => {
  // `file` can come from a SARIF document written by another tool, so it is
  // attacker-influenced in exactly the way a traversal needs.
  const dir = repo({ 'a.js': 'x' });
  for (const file of ['../../../etc/passwd', '/etc/passwd', 'nested/../../outside.txt']) {
    const out = readSource({ file, startLine: 1 }, dir);
    assert.ok(out.error, `${file} should have been refused`);
    assert.equal(out.lines, undefined);
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a missing file is an ordinary answer, not a crash', () => {
  const dir = repo({ 'a.js': 'x' });
  assert.match(readSource({ file: 'gone.js', startLine: 1 }, dir).error, /no longer exists/);
  assert.match(readSource({ file: 'a.js', startLine: 1 }, null).error, /not cloned/);
  assert.match(readSource({ startLine: 1 }, dir).error, /not attached to a file/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('binary files are refused', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-src-'));
  fs.writeFileSync(path.join(dir, 'a.bin'), Buffer.from([0x00, 0x01, 0x02]));
  assert.match(readSource({ file: 'a.bin', startLine: 1 }, dir).error, /binary/);
  fs.rmSync(dir, { recursive: true, force: true });
});

// ── Credential redaction ───────────────────────────────────────────────────
//
// A SECRET finding's line contains the credential. Returning it verbatim would
// make this a credential-disclosure endpoint, undoing the care taken everywhere
// else never to store or transmit the value.

test('THE CREDENTIAL NEVER LEAVES THE MACHINE', () => {
  const secret = 'AKIAIOSFODNN7REALKEY';
  const dir = repo({ 'C.java': `class C {\n  String k = "${secret}";\n}` });

  const out = readSource(
    { file: 'C.java', startLine: 2, type: 'SECRET', metadata: { masked: 'AKIA************LKEY' } },
    dir,
    { context: 1 }
  );

  const serialised = JSON.stringify(out);
  assert.equal(serialised.includes(secret), false, 'the raw credential was served');
  assert.equal(out.redacted, true);
  // …while the line is still recognisable, which is the point of a mask.
  assert.match(out.lines.find(l => l.isFinding).text, /AKIA\*+LKEY/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('redaction FAILS CLOSED when the value cannot be located', () => {
  // The important direction. If the mask does not match the line — the file
  // changed since the scan, the mask is malformed — the line is withheld rather
  // than served on the assumption that it is probably fine.
  const dir = repo({ 'C.java': 'String k = "something-else-entirely";' });
  const out = readSource(
    { file: 'C.java', startLine: 1, type: 'SECRET', metadata: { masked: 'AKIA************LKEY' } },
    dir,
    { context: 0 }
  );
  assert.match(out.lines[0].text, /withheld/);
  assert.equal(out.redacted, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a secret finding with no mask withholds the line', () => {
  const dir = repo({ 'C.java': 'String k = "AKIAIOSFODNN7REALKEY";' });
  const out = readSource({ file: 'C.java', startLine: 1, type: 'SECRET', metadata: {} }, dir, { context: 0 });
  assert.match(out.lines[0].text, /withheld/);
  assert.equal(JSON.stringify(out).includes('AKIAIOSFODNN7REALKEY'), false);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('only the finding line is redacted, not its context', () => {
  // Redacting the whole window would make the code frame useless for the very
  // findings where seeing the surrounding code matters most.
  const dir = repo({ 'C.java': 'int before = 1;\nString k = "AKIAIOSFODNN7REALKEY";\nint after = 2;' });
  const out = readSource(
    { file: 'C.java', startLine: 2, type: 'SECRET', metadata: { masked: 'AKIA************LKEY' } },
    dir,
    { context: 1 }
  );
  assert.equal(out.lines[0].text, 'int before = 1;');
  assert.equal(out.lines[2].text, 'int after = 2;');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a non-secret finding is not redacted', () => {
  const dir = repo({ 'a.js': 'eval(userInput);' });
  const out = readSource({ file: 'a.js', startLine: 1, type: 'SAST' }, dir, { context: 0 });
  assert.equal(out.lines[0].text, 'eval(userInput);');
  assert.equal(out.redacted, false);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the mask pattern matches by prefix, length and suffix', () => {
  // Loose enough to find the token, specific enough not to redact something
  // else on the same line.
  const pattern = maskedPattern('AKIA************LKEY');
  assert.ok(pattern.test('AKIAIOSFODNN7REALKEY'));
  assert.equal(pattern.test('AKIASHORT'), false);
  assert.equal(maskedPattern('********'), null, 'a fully masked value gives nothing to search for');
  assert.equal(maskedPattern(''), null);
});

test('redactSecret says no rather than guessing', () => {
  assert.equal(redactSecret('nothing here', 'AKIA****LKEY'), null);
  assert.equal(redactSecret('anything', null), null);
});

test('very long lines are truncated', () => {
  const dir = repo({ 'min.js': `${'x'.repeat(5000)}` });
  const out = readSource({ file: 'min.js', startLine: 1 }, dir, { context: 0 });
  assert.ok(out.lines[0].text.length < 500);
  assert.match(out.lines[0].text, /…$/);
  fs.rmSync(dir, { recursive: true, force: true });
});
