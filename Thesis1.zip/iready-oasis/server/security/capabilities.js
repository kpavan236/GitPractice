'use strict';

// The capability register.
//
// One row per capability in the target feature set, each naming the module that
// implements it or the reason it does not exist. It answers three questions
// that otherwise get answered from memory, badly:
//
//   What does this product actually do?
//   Where does a new capability go?
//   What did we decide about the ones we skipped?
//
// This file is VERIFIED BY TESTS (capabilities.test.js). A row claiming
// `status: 'implemented'` must name a module that exists and exports something;
// a row marked `planned` must not name one. That is what stops it drifting into
// the usual optimistic README that nobody trusts after three months.
//
// Adding a capability is: implement it, flip the row, add its module path. The
// register is the checklist, and the test is the enforcement.

const STATUS = {
  IMPLEMENTED: 'implemented', // works, has tests
  PARTIAL: 'partial',         // works for some inputs; `limits` says which
  PLANNED: 'planned',         // intended, not started
  EXTERNAL: 'external',       // supplied by ingesting another tool's output
  DECLINED: 'declined',       // deliberately not doing it; `why` is required
};

// Categories mirror the numbering of the target feature set so a request like
// "where are we on §6" has a single answer.
const CAPABILITIES = [
  // ── 1. Source code analysis ──────────────────────────────────────────────
  { id: 'sast', category: 1, name: 'SAST', status: STATUS.PARTIAL, module: 'scanners/sast-ast.js',
    limits: '18 rules, 4 languages, intraprocedural taint; no cross-file analysis' },
  { id: 'taint-analysis', category: 1, name: 'Taint analysis', status: STATUS.PARTIAL, module: 'scanners/sast-ast.js',
    limits: 'intraprocedural, fixed-point within a file; no cross-method or cross-file flow' },
  { id: 'pattern-matching', category: 1, name: 'AST pattern matching', status: STATUS.IMPLEMENTED, module: 'ast/engine.js' },
  { id: 'custom-security-rules', category: 1, name: 'Custom security rules', status: STATUS.IMPLEMENTED, module: 'local-rules.js' },
  { id: 'cross-file-analysis', category: 1, name: 'Cross-file analysis', status: STATUS.PLANNED,
    why: 'needs a real parser and a call graph; tree-sitter is the prerequisite' },
  { id: 'dataflow-analysis', category: 1, name: 'Data-flow analysis', status: STATUS.PLANNED,
    why: 'same prerequisite as cross-file analysis' },
  { id: 'code-quality', category: 1, name: 'Code quality, smells, complexity, tech debt', status: STATUS.EXTERNAL,
    module: 'scanners/eslint.js',
    why: 'ESLint and SonarQube already do this well. We adapt ESLint and ingest the rest as SARIF rather than reimplement ~5,000 rules; QUALITY is a separate finding type so lint never outranks a vulnerability' },

  // ── 2. Vulnerability detection ───────────────────────────────────────────
  { id: 'cve-detection', category: 2, name: 'CVE detection', status: STATUS.IMPLEMENTED, module: 'scanners/sca-lockfile.js' },
  { id: 'offline-advisories', category: 2, name: 'Offline advisory mirror', status: STATUS.PARTIAL,
    module: 'advisories/mirror.js',
    limits: 'ecosystems are opt-in and must be built by an operator; an unmirrored ecosystem falls back to api.osv.dev unless OASIS_ADVISORY_OFFLINE=1' },
  { id: 'cwe-classification', category: 2, name: 'CWE classification', status: STATUS.IMPLEMENTED, module: 'finding.js' },
  { id: 'cvss', category: 2, name: 'CVSS scoring', status: STATUS.PARTIAL, module: 'finding.js',
    limits: 'vectors on SAST rules; SCA severity comes from the advisory, not a computed vector' },
  { id: 'epss', category: 2, name: 'EPSS scoring', status: STATUS.IMPLEMENTED, module: 'threat-intel.js' },
  { id: 'kev', category: 2, name: 'Known-exploited detection', status: STATUS.IMPLEMENTED, module: 'threat-intel.js' },
  { id: 'dedup', category: 2, name: 'Deduplication', status: STATUS.IMPLEMENTED, module: 'fingerprint.js' },
  { id: 'suppression', category: 2, name: 'Suppression and false positives', status: STATUS.IMPLEMENTED, module: 'ignore.js' },
  { id: 'vuln-history', category: 2, name: 'History and status tracking', status: STATUS.IMPLEMENTED, module: 'store.js' },
  { id: 'trend-analysis', category: 2, name: 'Trend analysis', status: STATUS.IMPLEMENTED, module: 'store.js' },
  { id: 'continuous-monitoring', category: 2, name: 'Continuous monitoring and alerts', status: STATUS.PLANNED,
    why: 'the scheduler and Slack config already exist in OASIS; this is wiring, not invention' },

  // ── 3. Dependency / SCA ──────────────────────────────────────────────────
  { id: 'sca', category: 3, name: 'Software composition analysis', status: STATUS.IMPLEMENTED, module: 'scanners/sca-lockfile.js' },
  { id: 'transitive-deps', category: 3, name: 'Transitive dependency detection', status: STATUS.PARTIAL, module: 'maven-resolver.js',
    limits: 'Maven resolved; 10 lockfile formats; Gradle uncovered without dependency locking' },
  { id: 'dependency-tree', category: 3, name: 'Dependency tree analysis', status: STATUS.IMPLEMENTED, module: 'maven-resolver.js' },
  { id: 'upgrade-recommendations', category: 3, name: 'Upgrade recommendations', status: STATUS.IMPLEMENTED, module: 'scanners/sca-maven.js' },
  { id: 'automated-upgrades', category: 3, name: 'Automated upgrades and PRs', status: STATUS.PLANNED,
    why: 'needs the GitHub App integration that does not exist yet' },
  { id: 'reachability', category: 3, name: 'Dependency reachability', status: STATUS.PLANNED,
    why: 'the market differentiator; needs a call graph over compiled classes' },
  { id: 'malicious-packages', category: 3, name: 'Malicious package and typosquat detection', status: STATUS.PLANNED },

  // ── 4. Secret scanning ───────────────────────────────────────────────────
  { id: 'secret-regex', category: 4, name: 'Pattern-based secret detection', status: STATUS.IMPLEMENTED, module: 'secret-patterns.js' },
  { id: 'secret-entropy', category: 4, name: 'Entropy-based detection', status: STATUS.IMPLEMENTED, module: 'secret-patterns.js' },
  { id: 'secret-history', category: 4, name: 'Git history scanning', status: STATUS.IMPLEMENTED, module: 'scanners/secrets-history.js' },
  { id: 'secret-verification', category: 4, name: 'Active credential verification', status: STATUS.PARTIAL, module: 'secret-verify.js',
    limits: '6 providers; opt-in because it transmits a live credential' },
  { id: 'secret-baseline', category: 4, name: 'Baseline and allowlisting', status: STATUS.IMPLEMENTED, module: 'ignore.js' },
  { id: 'push-protection', category: 4, name: 'Push protection', status: STATUS.PLANNED,
    why: 'needs a pre-commit hook or a GitHub App; detection already exists' },

  // ── 5-9. Container, IaC, cloud, DAST, API ────────────────────────────────
  { id: 'iac-scanning', category: 6, name: 'IaC scanning', status: STATUS.PARTIAL, module: 'scanners/iac-policy.js',
    limits: '44 Checkov graph checks evaluated against parsed Terraform and Kubernetes resources, plus 10 line rules for Dockerfile. Checkov connection checks need a resource graph we do not build, and HCL expressions (var.x, count, for_each) are not resolved' },
  { id: 'differential-analysis', category: 13, name: 'New code vs overall code', status: STATUS.IMPLEMENTED, module: 'diff.js' },
  { id: 'container-scanning', category: 5, name: 'Container scanning', status: STATUS.EXTERNAL, module: 'sarif-ingest.js',
    why: 'Trivy does this well and emits SARIF; ingested from .oasis/sarif/ rather than reimplemented' },
  { id: 'cloud-scanning', category: 7, name: 'Cloud posture', status: STATUS.EXTERNAL, module: 'sarif-ingest.js',
    why: 'needs cloud credentials and an inventory service. Prowler emits SARIF, which is ingested' },
  { id: 'dast', category: 8, name: 'Dynamic scanning', status: STATUS.EXTERNAL, module: 'sarif-ingest.js',
    why: 'needs a running target. ZAP emits SARIF, which is ingested' },
  { id: 'api-security', category: 9, name: 'API security testing', status: STATUS.EXTERNAL, module: 'sarif-ingest.js',
    why: 'same as DAST — needs a live endpoint. Schemathesis and 42Crunch emit SARIF, which is ingested' },

  // ── 10-12. SBOM, licences, supply chain ──────────────────────────────────
  { id: 'sbom-generate', category: 10, name: 'SBOM generation (CycloneDX)', status: STATUS.IMPLEMENTED, module: 'scanners/sbom-builtin.js' },
  { id: 'sbom-spdx', category: 10, name: 'SPDX support', status: STATUS.PLANNED },
  { id: 'sbom-ingest', category: 10, name: 'SBOM ingestion and comparison', status: STATUS.PLANNED },
  { id: 'license-detection', category: 11, name: 'Licence detection and classification', status: STATUS.IMPLEMENTED, module: 'licenses.js' },
  { id: 'license-policy', category: 11, name: 'Licence policy enforcement', status: STATUS.IMPLEMENTED, module: 'licenses.js' },
  { id: 'license-inventory', category: 11, name: 'Licence inventory and reports', status: STATUS.IMPLEMENTED, module: 'orchestrator.js' },
  { id: 'supply-chain', category: 12, name: 'Provenance and build integrity', status: STATUS.PLANNED },

  // ── 13-14. Configuration and remediation ─────────────────────────────────
  { id: 'exception-management', category: 13, name: 'Exceptions and suppression', status: STATUS.IMPLEMENTED, module: 'ignore.js' },
  { id: 'allow-deny', category: 13, name: 'Allow/deny lists', status: STATUS.IMPLEMENTED, module: 'ignore.js' },
  { id: 'policies', category: 13, name: 'Org and project policies, quality gates', status: STATUS.IMPLEMENTED,
    module: 'gate.js' },
  { id: 'remediation-guidance', category: 14, name: 'Remediation guidance', status: STATUS.IMPLEMENTED, module: 'finding.js' },
  { id: 'automated-fixes', category: 14, name: 'Automated fixes and PRs', status: STATUS.PLANNED },
  { id: 'remediation-verification', category: 14, name: 'Remediation verification', status: STATUS.PARTIAL, module: 'store.js',
    limits: 'resolution means "no longer detected" — no build, no tests' },

  // ── 16-19. Integration, reporting ────────────────────────────────────────
  { id: 'repo-scanning', category: 16, name: 'Repository scanning', status: STATUS.IMPLEMENTED, module: 'orchestrator.js' },
  { id: 'pr-integration', category: 16, name: 'PR comments, status checks, merge blocking', status: STATUS.PLANNED,
    why: 'needs the GitHub App' },
  { id: 'sarif-export', category: 17, name: 'SARIF output', status: STATUS.IMPLEMENTED, module: 'sarif.js' },
  { id: 'sarif-import', category: 17, name: 'SARIF ingestion', status: STATUS.IMPLEMENTED, module: 'sarif-ingest.js' },
  { id: 'cli', category: 17, name: 'CLI and pipeline gates', status: STATUS.PLANNED },
  { id: 'dashboard', category: 19, name: 'Security and risk dashboard', status: STATUS.IMPLEMENTED, module: 'orchestrator.js' },
  { id: 'trends-dashboard', category: 19, name: 'Trend reporting', status: STATUS.IMPLEMENTED, module: 'store.js' },

  // ── 20-24. Risk, compliance, access, notifications, audit ────────────────
  { id: 'risk-scoring', category: 20, name: 'Explainable risk scoring', status: STATUS.IMPLEMENTED, module: 'risk.js' },
  { id: 'asset-criticality', category: 20, name: 'Asset and business criticality', status: STATUS.IMPLEMENTED, module: 'risk.js' },
  { id: 'risk-acceptance', category: 20, name: 'Risk acceptance and exceptions', status: STATUS.IMPLEMENTED, module: 'ignore.js' },
  { id: 'owasp-mapping', category: 21, name: 'OWASP / CWE / CVE mapping', status: STATUS.IMPLEMENTED, module: 'finding.js' },
  { id: 'compliance-frameworks', category: 21, name: 'CIS, NIST, PCI, SOC 2, ISO, GDPR, HIPAA', status: STATUS.PLANNED,
    why: 'control mapping over existing findings; needs the framework tables, not new detection' },
  { id: 'auth-rbac', category: 22, name: 'SSO, RBAC, user management', status: STATUS.DECLINED,
    why: 'single-user desktop tool. Tenancy fields that are always one constant would be fiction — revisit only if OASIS becomes hosted' },
  { id: 'notifications', category: 23, name: 'Slack, email, JIRA, webhooks', status: STATUS.PLANNED,
    why: 'OASIS already has Slack config, a JIRA module and a scheduler; this is wiring' },
  { id: 'audit-log', category: 24, name: 'Audit logging', status: STATUS.PARTIAL, module: 'store.js',
    limits: 'suppression decisions and scan history are recorded; there is no immutable audit trail' },
];

function byCategory() {
  const groups = new Map();
  for (const c of CAPABILITIES) {
    if (!groups.has(c.category)) groups.set(c.category, []);
    groups.get(c.category).push(c);
  }
  return [...groups.entries()].sort((a, b) => a[0] - b[0]).map(([category, items]) => ({ category, items }));
}

function summary() {
  const counts = {};
  for (const c of CAPABILITIES) counts[c.status] = (counts[c.status] || 0) + 1;
  return { total: CAPABILITIES.length, ...counts };
}

function find(id) {
  return CAPABILITIES.find(c => c.id === id) || null;
}

module.exports = { CAPABILITIES, STATUS, byCategory, summary, find };
