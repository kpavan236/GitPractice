'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const express = require('express');
const { createRulesView } = require('./rules-view');
const { createOverrides } = require('./overrides');
const { createRulesUpdater } = require('./rules-updates');
const { createSecurityRouter } = require('./routes');

const RULES = {
  java: [{ id: 'java-sqli', title: 'SQL injection', language: 'java', pillar: 'security', severity: 'HIGH', engine: 'ast', body: 'secret-internals' }],
  python: [{ id: 'py-eval', language: 'python', pillar: 'reliability', severity: 'MEDIUM', engine: 'pattern' }],
};
function fakeLoader({ installed = true } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rv-'));
  const release = installed ? {
    release: 7, manifest: { release: 7, channel: 'stable', createdAt: '2026-10-01T00:00:00.000Z', packs: [
      { packId: 'core', kind: 'core', language: null }, { packId: 'lang-java', kind: 'language', language: 'java' }, { packId: 'lang-python', kind: 'language', language: 'python' }] },
    packDirs: { core: dir, 'lang-java': dir, 'lang-python': dir },
  } : null;
  return { current: () => release, rulesFor: (langs) => langs.flatMap((l) => RULES[l] || []), update: async () => ({ status: 'current', release: 7 }) };
}
function tmpOverrides() { return createOverrides({ file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'rv-o-')), 'o.json') }); }

test('installed(): lists each rule with language, pillar and severity, and nothing of the rule body', () => {
  const v = createRulesView({ loader: fakeLoader(), overrides: tmpOverrides() }).installed();
  assert.equal(v.mode, 'installed');
  assert.equal(v.release.number, 7);
  assert.equal(typeof v.release.installedAt, 'string');
  assert.equal(v.updateAvailable, false);
  assert.equal(v.updateError, null);
  assert.deepEqual(v.rules.map((r) => r.id), ['java-sqli', 'py-eval']);
  assert.deepEqual(v.rules[0], { id: 'java-sqli', title: 'SQL injection', language: 'java', pillar: 'security', severity: 'HIGH', engine: 'ast' });
  assert.equal(v.rules[1].title, 'py-eval', 'a rule without a title is shown by its id');
});

test('installed(): nothing installed gives release null, no rules, and the updater error in plain language', async () => {
  const updater = createRulesUpdater({ loader: { ...fakeLoader({ installed: false }), update: async () => { throw Object.assign(new Error('x'), { code: 'NO_PINNED_KEYS' }); } }, log: () => {} });
  await updater.update().catch(() => {});
  const v = createRulesView({ loader: fakeLoader({ installed: false }), updater, overrides: tmpOverrides() }).installed();
  assert.equal(v.release, null);
  assert.deepEqual(v.rules, []);
  assert.equal(v.updateError.code, 'NO_PINNED_KEYS');
  assert.match(v.updateError.message, /signing keys/i);
});

test('installed(): an offline check is reported, and UPGRADE_REQUIRED means an update is available', async () => {
  let result = { status: 'offline', release: 7, error: 'NETWORK' };
  const updater = createRulesUpdater({ loader: { ...fakeLoader(), update: async () => result }, log: () => {} });
  const view = createRulesView({ loader: fakeLoader(), updater, overrides: tmpOverrides() });
  await updater.update();
  assert.equal(view.installed().updateError.code, 'OFFLINE');
  assert.equal(view.installed().updateAvailable, false);
  result = { status: 'current', release: 7, error: 'UPGRADE_REQUIRED' };
  await updater.update();
  assert.equal(view.installed().updateAvailable, true);
  assert.equal(view.installed().updateError, null);
});

test('installed(project): includes that project\'s overrides', () => {
  const overrides = tmpOverrides();
  overrides.set('shop', { disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } });
  const v = createRulesView({ loader: fakeLoader(), overrides }).installed('shop');
  assert.deepEqual(v.overrides, { disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } });
});

test('setOverrides validates the project key, the arrays and the severities', () => {
  const view = createRulesView({ loader: fakeLoader(), overrides: tmpOverrides() });
  assert.deepEqual(view.setOverrides('shop', { disabled: ['a'], severity: { b: 'LOW' } }), { disabled: ['a'], severity: { b: 'LOW' } });
  for (const bad of [[null, {}], ['__proto__', {}], ['a/b', {}], ['', {}], ['shop', { disabled: 'x' }], ['shop', { severity: { a: 'SEVERE' } }], ['shop', { severity: [] }], ['shop', null], ['shop', { disabled: [1] }]]) {
    assert.throws(() => view.setOverrides(...bad), (e) => e.status === 400, JSON.stringify(bad));
  }
});

async function call(orchestrator, method, url, body, headers = {}) {
  const app = express();
  app.use(express.json());
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => ['x'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/api/security${url}`, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  } finally { server.close(); }
}

test('GET /rules/installed in legacy mode says so and PUT is refused', async () => {
  const g = await call({}, 'GET', '/rules/installed');
  assert.equal(g.status, 200);
  assert.equal(g.body.mode, 'legacy');
  assert.equal(g.body.release, null);
  assert.deepEqual(g.body.rules, []);
  assert.equal((await call({}, 'PUT', '/rules/overrides/shop', { disabled: [] })).status, 409);
});

test('GET /rules/installed and PUT /rules/overrides/:project in installed mode', async () => {
  const orchestrator = { rulesView: createRulesView({ loader: fakeLoader(), overrides: tmpOverrides() }) };
  const g = await call(orchestrator, 'GET', '/rules/installed?project=shop');
  assert.equal(g.body.mode, 'installed');
  assert.equal(g.body.rules.length, 2);
  const p = await call(orchestrator, 'PUT', '/rules/overrides/shop', { disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } });
  assert.equal(p.status, 200);
  assert.deepEqual(p.body, { disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } });
  assert.deepEqual((await call(orchestrator, 'GET', '/rules/installed?project=shop')).body.overrides, p.body);
  assert.equal((await call(orchestrator, 'PUT', '/rules/overrides/shop', { severity: { a: 'SEVERE' } })).status, 400);
  assert.equal((await call(orchestrator, 'PUT', '/rules/overrides/shop', { disabled: 'nope' })).status, 400);
  assert.equal((await call(orchestrator, 'PUT', '/rules/overrides/__proto__', { disabled: [] })).status, 400);
});

test('both routes refuse a foreign web page', async () => {
  const orchestrator = { rulesView: createRulesView({ loader: fakeLoader(), overrides: tmpOverrides() }) };
  assert.equal((await call(orchestrator, 'GET', '/rules/installed', undefined, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await call(orchestrator, 'PUT', '/rules/overrides/shop', { disabled: [] }, { origin: 'https://evil.example' })).status, 403);
});

test('installed(): devKeys lists the DEV-ONLY signing keys in use, [] for a loader without any; a dev key file error has plain text', async () => {
  const withDev = { ...fakeLoader(), devKeys: () => ['dev-1'] };
  assert.deepEqual(createRulesView({ loader: withDev, overrides: tmpOverrides() }).installed().devKeys, ['dev-1']);
  assert.deepEqual(createRulesView({ loader: fakeLoader(), overrides: tmpOverrides() }).installed().devKeys, []);
  const updater = createRulesUpdater({ loader: { ...fakeLoader({ installed: false }), update: async () => { throw Object.assign(new Error('x'), { code: 'DEV_KEY_PRIVATE' }); } }, log: () => {} });
  await updater.update().catch(() => {});
  const v = createRulesView({ loader: fakeLoader({ installed: false }), updater, overrides: tmpOverrides() }).installed();
  assert.equal(v.updateError.code, 'DEV_KEY_PRIVATE');
  assert.match(v.updateError.message, /PRIVATE key/);
});
