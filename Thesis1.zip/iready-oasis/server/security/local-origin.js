'use strict';

// Who may talk to the Security API.
//
// server/index.js answers every origin (`app.use(cors())`), so any web page the user
// visits can call http://127.0.0.1:<port> and, because of that CORS answer, READ what
// comes back. The Security API holds findings, source excerpts, and the controls for
// what gets scanned and how. It is for the app itself and for tools, so it refuses a
// request whose Origin is anything other than a local address. Tools (curl, CI, the
// CLI) send no Origin at all and are unaffected.

const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '[::1]']);

function isLocalOrigin(origin) {
  try {
    return LOCAL_HOSTS.has(new URL(origin).hostname);
  } catch (_) {
    return false;                       // 'null', garbage
  }
}

function localOriginGuard(req, res, next) {
  const origin = req.get('origin');
  if (origin !== undefined && !isLocalOrigin(origin)) {
    return res.status(403).json({ error: `refusing a request from origin ${origin}: the Security API answers only the app itself`, code: 'FORBIDDEN_ORIGIN' });
  }
  return next();
}

module.exports = { isLocalOrigin, localOriginGuard };
