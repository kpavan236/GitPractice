'use strict';
const { parentPort, threadId, workerData } = require('worker_threads');

// A stand-in for a scan worker, so pool.test.js can exercise the behaviours
// that matter — parallelism, failure, death — without needing a repository.

parentPort.on('message', ({ id, payload }) => {
  try {
    if (payload.crash) process.exit(1);
    if (payload.fail) throw new Error(payload.fail);
    // A long task reporting where it has got to, which is the only way the
    // dashboard can say anything about a scan happening on another thread.
    for (let i = 0; i < (payload.report || 0); i++) {
      parentPort.postMessage({ id, progress: { step: i } });
    }
    if (payload.blockMs) {
      const until = Date.now() + payload.blockMs;
      while (Date.now() < until) { /* deliberately blocking, like a real scan */ }
    }
    const result = payload.whoami ? { threadId }
      : payload.readWorkerData ? { workerData: workerData || null }
      : { echoed: payload.echo };
    parentPort.postMessage({ id, ok: true, result });
  } catch (e) {
    parentPort.postMessage({ id, ok: false, error: e.message });
  }
});
