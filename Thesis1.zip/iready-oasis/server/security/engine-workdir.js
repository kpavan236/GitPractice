'use strict';
// The core pack ships no grammars (the .wasm files live in the language packs), but the engine looks for them at
// src/ast/grammars inside its own directory. The verified store is never written to, so a run uses a copy: the
// core plus every installed language pack's grammar, per release.
//
// Safe for concurrent scans: a copy is built in a temp dir beside the target and renamed into place (so a release
// dir is never visible half-built), preparation of one target is shared between callers, and a release dir that a
// running scan holds is never deleted by another scan's cleanup.
const fs = require('fs');
const path = require('path');

const READY = '.ready';

const inflight = new Map();   // target dir -> Promise<void> of its preparation
const holds = new Map();      // target dir -> number of runs using it

const noRules = (message) => Object.assign(new Error(message), { code: 'NO_RULES_INSTALLED' });

function build(release, source, target, workDir) {
  fs.mkdirSync(workDir, { recursive: true });
  const tmp = `${target}.tmp-${process.pid}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  try {
    fs.cpSync(source, tmp, { recursive: true, dereference: false });
    const grammars = path.join(tmp, 'src', 'ast', 'grammars');
    fs.mkdirSync(grammars, { recursive: true });
    for (const p of release.manifest.packs) {
      if (p.kind !== 'language' || !release.packDirs[p.packId]) continue;
      const from = path.join(release.packDirs[p.packId], 'grammar');
      let names = [];
      try { names = fs.readdirSync(from).filter((n) => n.endsWith('.wasm')); } catch (_) { continue; }
      for (const n of names) fs.copyFileSync(path.join(from, n), path.join(grammars, n));
    }
    fs.writeFileSync(path.join(tmp, READY), String(release.release));
    // An existing target that is not ready is an interrupted preparation (a ready one never reaches here).
    fs.rmSync(target, { recursive: true, force: true });
    fs.renameSync(tmp, target);
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    // Another process may have finished the same release first: its ready copy is as good as ours.
    if (fs.existsSync(path.join(target, READY))) return;
    throw e;
  }
}

function cleanup(workDir, keep) {
  try {
    for (const name of fs.readdirSync(workDir)) {
      const dir = path.join(workDir, name);
      if (dir !== keep && /^release-\d+$/.test(name) && !holds.get(dir)) fs.rmSync(dir, { recursive: true, force: true });
    }
  } catch (_) { /* best effort */ }
}

// Prepares (or reuses) the engine copy for `release` (default: the loader's current one) and holds it until done()
// is called, so no other scan's cleanup can remove it while this run uses it.
async function acquireCore({ loader, workDir, release = loader.current() }) {
  if (!release) throw noRules('no rules release is installed; run update() first');
  const source = release.packDirs && release.packDirs.core;
  if (!source) throw noRules('the installed release has no core pack');
  const target = path.join(workDir, `release-${release.release}`);

  holds.set(target, (holds.get(target) || 0) + 1);
  let released = false;
  const done = () => {
    if (released) return;
    released = true;
    const left = (holds.get(target) || 1) - 1;
    if (left > 0) holds.set(target, left); else holds.delete(target);
  };
  try {
    if (!fs.existsSync(path.join(target, READY))) {
      let job = inflight.get(target);
      if (!job) {
        job = Promise.resolve().then(() => build(release, source, target, workDir)).finally(() => inflight.delete(target));
        inflight.set(target, job);
      }
      await job;
    }
    cleanup(workDir, target);
  } catch (e) { done(); throw e; }
  return { path: target, done };
}

// Convenience for callers that do not hold the copy across a run.
async function prepareCore(opts) {
  const lease = await acquireCore(opts);
  lease.done();
  return lease.path;
}

module.exports = { prepareCore, acquireCore };
