'use strict';
const fs = require('fs');
const path = require('path');
const { loadLocalRules } = require('./local-rules');
const { DEV_WARNING } = require('./engine-loader/dev-keys');

const NO_RULES_MESSAGE = 'No rules installed and the rules service is unreachable. Connect to the network once so the rules can be downloaded, then retry.';

class NoRulesError extends Error {
  constructor(message = NO_RULES_MESSAGE, options) {
    super(message, options);
    this.code = 'NO_RULES';
  }
}

// What to tell the user when the loader could not give us rules. The plan's message is always the headline;
// the loader's coded cause rides along on .cause, and a state the user can act on is appended.
function noRulesFrom(cause, loader) {
  const hint = cause && cause.code === 'NO_PINNED_KEYS'
    ? ' (this build has no signing keys pinned, so no release can be trusted: NO_PINNED_KEYS)'
    : cause && cause.code === 'BAD_PACK' ? ` (the installed rules are damaged: ${cause.message})`
      : cause && cause.code && cause.code !== 'NO_RULES_INSTALLED' ? ` (${cause.code}${/^DEV_KEY/.test(cause.code) ? `: ${cause.message}` : ''})` : '';
  // A development signing key is in use: say so wherever a user reads why there are no rules.
  const devKeys = loader && typeof loader.devKeys === 'function' ? loader.devKeys() : [];
  return new NoRulesError(NO_RULES_MESSAGE + hint + (devKeys.length ? ` [${DEV_WARNING(devKeys)}]` : ''), cause ? { cause } : undefined);
}

// Languages whose packs apply to every repository, by the ids the rule registry really uses (oasis-rule-server
// seed/languages.json): secrets and IaC are not tied to one source language, and `text` is the generic fallback.
// A pack.json may also say `always: true` (the builder does not write it today); that is honoured too.
const ALWAYS_LANGUAGES = ['text', 'secrets', 'iac'];

// Files with no (useful) extension, by basename: lowercased exact names, then prefixes.
const BASENAMES = new Map([
  ['dockerfile', 'dockerfile'], ['containerfile', 'dockerfile'],
  ['jenkinsfile', 'groovy'],
  ['.env', 'secrets'], ['.npmrc', 'secrets'], ['.netrc', 'secrets'], ['.pgpass', 'secrets'], ['id_rsa', 'secrets'], ['id_ed25519', 'secrets'],
]);
const BASENAME_PREFIXES = [['dockerfile.', 'dockerfile'], ['jenkinsfile.', 'groovy'], ['.env.', 'secrets']];

function languageForBasename(name) {
  const base = path.basename(name).toLowerCase();
  if (BASENAMES.has(base)) return BASENAMES.get(base);
  const hit = BASENAME_PREFIXES.find(([prefix]) => base.startsWith(prefix));
  return hit ? hit[1] : null;
}

function packMeta(release, packId) {
  try { return JSON.parse(fs.readFileSync(path.join(release.packDirs[packId], 'pack.json'), 'utf8')) || {}; } catch (_) { return {}; }
}

// extension -> the set of languages whose pack.json claims it (".yml" is YAML, Ansible, Kubernetes and more; ".cls" is
// Apex and Visual Basic 6), from the installed language packs
function installedExtensions(loader, pinned) {
  const release = pinned || loader.current();
  const map = new Map();
  const always = [];
  if (!release) return { map, always };
  for (const p of release.manifest.packs) {
    if (p.kind !== 'language' || !release.packDirs[p.packId]) continue;
    const meta = packMeta(release, p.packId);
    if (Array.isArray(meta.extensions)) {
      for (const e of meta.extensions) {
        if (typeof e !== 'string') continue;
        const key = e.toLowerCase();
        if (!map.has(key)) map.set(key, new Set());
        map.get(key).add(p.language);
      }
    }
    if (meta.always === true) always.push(p.language);
  }
  return { map, always };
}

// The languages present in a repository (or in the explicit file list of a quick scan), walked the way the
// analyzer walks (same skipped directories, binaries and size limit) so the two never disagree about what exists.
function detectLanguages({ repoPath, files = null, loader, release }) {
  const { map } = installedExtensions(loader, release);
  const engine = require('oasis-analyzer/src/ast/engine');
  const found = new Set();
  const see = (name) => {
    const ext = path.extname(name).toLowerCase();
    for (const lang of map.get(ext) || []) found.add(lang);
    const own = engine.languageFor(ext);
    if (own) found.add(own);
    const named = languageForBasename(name);
    if (named) found.add(named);
  };
  if (Array.isArray(files)) {
    for (const f of files) if (typeof f === 'string') see(f);
  } else {
    const { walk } = require('oasis-analyzer/src/corpus');
    for (const abs of walk(repoPath, repoPath, { files: 0, maxFiles: Infinity })) see(abs);
  }
  return [...found];
}

// Makes sure a release is installed, asking the rules service once if not. Never throws anything but NoRulesError:
// scanning with zero rules would read as a clean repository.
async function ensureRules(loader) {
  const have = loader.current();
  if (have) return have;
  let result = null;
  let cause = null;
  try { result = await loader.update(); } catch (e) { cause = e; }
  const now = loader.current();
  if (!now) {
    // Offline answers are the ordinary reason and need no extra words; UPGRADE_REQUIRED is the one worth naming.
    const upgrade = result && result.error === 'UPGRADE_REQUIRED' ? Object.assign(new Error('this version of the app is too old to read the newest rules'), { code: 'UPGRADE_REQUIRED' }) : null;
    throw noRulesFrom(cause || upgrade, loader);
  }
  return now;
}

// oasis-analyzer never chooses rules: it is handed a complete rule set. This is
// where the scanner chooses: the rule server's rules (or its labelled cache),
// followed by the rules that live on this machine. There is no built-in
// fallback: a scan that silently ran no rules would look exactly like a clean
// repository.
function buildRuleSet({ ruleSet, loader, release, languages, projectKey, overrides, userRulesDir, plugins } = {}) {
  if (loader) return buildInstalledRuleSet({ loader, release, languages, projectKey, overrides, userRulesDir, plugins });
  if (!ruleSet) throw new NoRulesError();
  const local = loadLocalRules({ userRulesDir, plugins });
  const rules = [...ruleSet.rules, ...local.rules];
  // An empty rule set is the quietest way to get a wrong answer: every engine
  // "completes" and the repository reads as clean. It happens when the rule
  // server was started on a database nobody seeded, or a profile disabled
  // everything, so it is refused with the way out.
  if (!rules.length) {
    const profile = ruleSet.profile ? `profile "${ruleSet.profile.name}" v${ruleSet.profile.version}` : `rule set ${ruleSet.version || '(unversioned)'}`;
    throw new NoRulesError(`The rule server has no active rules (${profile}), so a scan would report a clean repository. `
      + 'Seed it (node scripts/seed.js in oasis-rule-server) or enable rules in the profile.');
  }
  return {
    rules,
    version: ruleSet.version,
    cacheVersion: `${ruleSet.version || 'none'}:${local.hash}`,
    source: ruleSet.source,
    createdAt: ruleSet.createdAt || null,
    rejected: [],
  };
}

// Rules of the given languages from one release's own pack dirs (never from whatever the loader's current is).
function rulesFrom(release, wanted) {
  const out = [];
  for (const language of new Set(wanted)) {
    const p = release.manifest.packs.find((x) => x.kind === 'language' && x.language === language);
    if (!p || !release.packDirs[p.packId]) continue;
    const rules = JSON.parse(fs.readFileSync(path.join(release.packDirs[p.packId], 'rules.json'), 'utf8'));
    if (!Array.isArray(rules)) throw Object.assign(new Error(`rules.json of the ${language} pack is not an array`), { code: 'BAD_PACK' });
    out.push(...rules);
  }
  return out;
}

// The rule set from the installed release: only the language packs the repository needs, then the per-project
// overrides, then the rules on this machine. The version is the release number, so a new release is a new cache key.
function buildInstalledRuleSet({ loader, release: pinned, languages, projectKey, overrides, userRulesDir, plugins }) {
  let release;
  let installed;
  try {
    release = pinned || loader.current();
    if (!release) throw Object.assign(new Error('no rules release is installed'), { code: 'NO_RULES_INSTALLED' });
    const all = release.manifest.packs.filter((p) => p.kind === 'language').map((p) => p.language);
    const wanted = Array.isArray(languages) ? [...new Set([...languages, ...ALWAYS_LANGUAGES, ...installedExtensions(loader, release).always])] : all;
    installed = rulesFrom(release, wanted);
  } catch (e) {
    throw noRulesFrom(e, loader);
  }
  const local = loadLocalRules({ userRulesDir, plugins });
  let rules = [...installed, ...local.rules];
  if (overrides) rules = overrides.apply(rules, projectKey);
  if (!rules.length) {
    throw new NoRulesError(`The installed rules (release-${release.release}) have no rules for this repository's languages (${(languages || []).join(', ') || 'none detected'}), so a scan would report a clean repository. `
      + 'Check that the rules service has published packs for them, or add your own rule pack.');
  }
  return {
    rules,
    version: `release-${release.release}`,
    cacheVersion: `release-${release.release}:${local.hash}`,
    source: 'rules-service',
    createdAt: release.manifest.createdAt || null,
    rejected: [],
  };
}

// What the per-file scan cache is keyed on. The analyzer only knows its own
// version, which nothing forces anyone to bump; folding the oasis release in
// makes shipping a fixed engine invalidate findings cached by the old one.
function cacheVersionFor(ruleSet) {
  return `${(ruleSet && ruleSet.cacheVersion) || 'none'}|oasis@${require('../../package.json').version}`;
}

module.exports = { noRulesFrom, buildRuleSet, cacheVersionFor, NoRulesError, detectLanguages, ensureRules, installedExtensions };
