'use strict';
const { execFile, spawn } = require('child_process');
const os = require('os');

// The environment a scanner's subprocess gets: enough to run, nothing more.
//
// Scanners read other people's repositories, so they are not handed the whole
// environment of an app that holds GitHub and Jenkins tokens. HOME is included
// because git needs it to find its configuration — and on Windows HOME is
// usually unset, where the equivalents are USERPROFILE and HOMEDRIVE/HOMEPATH.
// Passing only HOME left git on Windows with no home at all.
function toolEnv() {
  const home = os.homedir();
  return {
    PATH: process.env.PATH,
    HOME: home,
    USERPROFILE: process.env.USERPROFILE || home,
    HOMEDRIVE: process.env.HOMEDRIVE,
    HOMEPATH: process.env.HOMEPATH,
    // Stable, parseable output regardless of the developer's locale.
    LANG: 'C',
  };
}

// The scanner contract. Everything above it — orchestration, dedup, risk,
// dashboard — depends on this and nothing else, so swapping Semgrep for CodeQL
// or adding Trivy is one new file in scanners/ and one line in the registry.
//
//   {
//     type:        one of finding.TYPES
//     id:          stable short id, used in the UI and in detection sources
//     name:        human label
//     requires:    external binary this needs, or null if built in
//     isAvailable() -> Promise<{available, version, hint}>
//     scan({ repoPath, repository, timeoutMs }) -> Promise<{findings, artifacts}>
//   }
//
// A scanner MUST NOT throw for an ordinary "nothing found" or "tool missing"
// outcome; those are results, not errors. It may throw if the repository path
// is unusable, which the orchestrator records as a failed scan for that
// scanner alone — one broken scanner never fails the whole run.

// Runs an external tool. Wrapped rather than used directly so that every
// scanner gets the same timeout, output cap, and non-throwing contract.
//
// A non-zero exit is NOT an error here: Semgrep exits 1 when it finds
// something, Gitleaks exits 1 when it finds a leak. Treating that as failure
// would discard exactly the runs that matter.
function runTool(command, args, { cwd, timeoutMs = 300000, maxBuffer = 64 * 1024 * 1024, env } = {}) {
  return new Promise(resolve => {
    execFile(
      command,
      args,
      {
        cwd,
        timeout: timeoutMs,
        maxBuffer,
        // Scanners read repository contents; they get no inherited secrets
        // beyond what they need to run.
        env: env || toolEnv(),
      },
      (err, stdout, stderr) => {
        const timedOut = err && err.killed;
        resolve({
          ok: !err || (!timedOut && typeof err.code === 'number'),
          timedOut: Boolean(timedOut),
          code: err && typeof err.code === 'number' ? err.code : 0,
          stdout: stdout || '',
          stderr: stderr || '',
          error: err && !timedOut && typeof err.code !== 'number' ? err.message : null,
        });
      }
    );
  });
}

/**
 * Runs a tool whose output is too large to hold, delivering it a line at a time.
 *
 * `runTool` buffers everything into a string. For `git --version` that is
 * correct; for `git log -p --all` it is a crash. The history secret scanner
 * used it and failed on every repository with real history:
 *
 *   GIT_HISTORY  FAILED  "git log failed: stdout maxBuffer length exceeded"
 *
 * Raising the cap only moves the wall — a monorepo's complete diff is bigger
 * than any figure worth resident in memory, and the process pays that cost in
 * RSS even on the runs that succeed. Here nothing accumulates: each chunk is
 * split into lines, handed to `onLine`, and dropped.
 *
 * Streaming ALONE does not bound memory. A committed minified bundle is one
 * line several megabytes long, and it would sit in the carry buffer until the
 * newline that never comes — the original crash with extra steps. So a line
 * past `maxLineLength` is truncated, counted, and the buffer resynchronises at
 * the next newline.
 *
 * Failure is a result, not an exception, matching `runTool`: a non-zero exit or
 * a timeout still returns, and whatever `onLine` already consumed still counts.
 * A partial history scan that found a live credential beats a thrown error.
 *
 * @param {function(string):void} opts.onLine  called per line, without its newline
 * @returns {Promise<{ok, timedOut, code, error, stderr, bytes, lines, linesTruncated}>}
 */
function streamTool(command, args, {
  cwd,
  timeoutMs = 300000,
  env,
  onLine,
  maxLineLength = 64 * 1024,
  maxStderrBytes = 64 * 1024,
} = {}) {
  return new Promise(resolve => {
    let child;
    try {
      child = spawn(command, args, {
        cwd,
        env: env || toolEnv(),
        stdio: ['ignore', 'pipe', 'pipe'],
      });
    } catch (e) {
      resolve({ ok: false, timedOut: false, code: null, error: e.message, stderr: '', bytes: 0, lines: 0, linesTruncated: 0 });
      return;
    }

    let carry = '';
    let carryTruncated = false;      // this line already hit the cap; discard to its end
    let bytes = 0;
    let lines = 0;
    let linesTruncated = 0;
    let stderr = '';
    let settled = false;
    let timedOut = false;
    let error = null;

    const timer = timeoutMs > 0 ? setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, timeoutMs) : null;

    const emit = line => { lines++; onLine(line); };

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      bytes += Buffer.byteLength(chunk);
      let start = 0;

      for (;;) {
        const nl = chunk.indexOf('\n', start);
        if (nl === -1) break;

        if (carryTruncated) {
          // Mid-discard: this newline ends the oversized line. Emit what was
          // kept of it and resynchronise.
          emit(carry);
          carry = '';
          carryTruncated = false;
        } else {
          const line = carry + chunk.slice(start, nl);
          carry = '';
          if (line.length > maxLineLength) {
            linesTruncated++;
            emit(line.slice(0, maxLineLength));
          } else {
            emit(line);
          }
        }
        start = nl + 1;
      }

      if (start < chunk.length) {
        if (carryTruncated) return;                 // still discarding
        carry += chunk.slice(start);
        if (carry.length > maxLineLength) {
          // Cap it now rather than letting the buffer grow to the next newline,
          // which may be megabytes away or absent entirely.
          carry = carry.slice(0, maxLineLength);
          carryTruncated = true;
          linesTruncated++;
        }
      }
    });

    child.stderr.setEncoding('utf8');
    child.stderr.on('data', chunk => {
      if (stderr.length < maxStderrBytes) stderr += chunk.slice(0, maxStderrBytes - stderr.length);
    });

    child.on('error', e => { error = e.message; });

    child.on('close', code => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      // Output with no trailing newline: the last line is still a line.
      if (carry) emit(carry);
      resolve({
        ok: !error && !timedOut && code === 0,
        timedOut,
        code: typeof code === 'number' ? code : null,
        error,
        stderr,
        bytes,
        lines,
        linesTruncated,
      });
    });
  });
}

// Whether a binary exists, and what version. Cached per process: this shells
// out, and the dashboard asks on every page load.
const _availability = new Map();

async function toolAvailability(command, versionArgs = ['--version'], hint = null) {
  if (_availability.has(command)) return _availability.get(command);

  const result = await runTool(command, versionArgs, { timeoutMs: 8000 });
  const available = !result.error && !result.timedOut;
  const value = {
    available,
    version: available ? (result.stdout || result.stderr).trim().split('\n')[0] : null,
    hint: available ? null : hint,
  };
  _availability.set(command, value);
  return value;
}

function _resetAvailabilityCache() {
  _availability.clear();
}

module.exports = { runTool, streamTool, toolAvailability, toolEnv, _resetAvailabilityCache };