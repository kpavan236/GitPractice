'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const os = require('os');

// Truncation must always name its own limit.
//
// A capped scan is the one case where "no findings" and "no findings *yet*"
// look identical, so the report has to say which limit stopped it and what
// raises that limit. Without a reason string the UI falls back to "incomplete,
// hit a limit", which tells a reader their result is untrustworthy and gives
// them nothing to do about it — the shape of warning people learn to skip.
//
// This is a source-level check rather than a behavioural one because reaching
// these branches needs a repository with 20,000 files or 500 commits. It is
// deliberately crude: it exists to make a missing reason fail here, next to the
// scanner being written, instead of silently in someone's scan report.

const DIR = path.join(__dirname, 'scanners');

function scannerSources() {
  return fs
    .readdirSync(DIR)
    .filter(f => f.endsWith('.js') && !f.endsWith('.test.js'))
    .map(f => ({ name: f, source: fs.readFileSync(path.join(DIR, f), 'utf8') }));
}

test('every scanner that reports truncation also reports why', () => {
  for (const { name, source } of scannerSources()) {
    // `truncated:` as a stats field, not the local variable it is built from.
    if (!/^\s*truncated:/m.test(source)) continue;

    assert.match(source, /truncatedReason/,
      `${name} reports stats.truncated without a truncatedReason. A truncated scan ` +
      `must name the limit that stopped it and the setting that raises it — ` +
      `otherwise the report says "incomplete" and stops there.`);
  }
});

test('every truncation limit can be raised without a rebuild', () => {
  // A cap is a guess about other people's repositories. Ours are not the
  // biggest ones this will ever run against, so each guess is an env var.
  const knobs = {
    'secrets-history.js': 'OASIS_HISTORY_MAX_COMMITS',
    'sca-lockfile.js': 'OASIS_SCA_MAX_PACKAGES',
    'sca-maven.js': 'OASIS_MAVEN_MAX_ARTIFACTS',
  };

  for (const [file, envVar] of Object.entries(knobs)) {
    const source = fs.readFileSync(path.join(DIR, file), 'utf8');
    assert.match(source, new RegExp(envVar),
      `${file} should let ${envVar} raise its limit, and should name it in the reason`);
  }

  // The file-count cap used to be duplicated in each content scanner and now
  // lives in the shared walk, which is the only place that counts files.
  // (corpus.js moved to oasis-analyzer; the shim at this path re-exports it.)
  assert.match(fs.readFileSync(require.resolve('oasis-analyzer/src/corpus'), 'utf8'), /OASIS_SCAN_MAX_FILES/);
});

test('the file cap actually caps, rather than merely being mentioned', async () => {
  // The test above reads source text, so it passes for a knob that is named in
  // a comment and wired to nothing. This one spends the walk.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-cap-'));
  for (let i = 0; i < 8; i++) fs.writeFileSync(path.join(dir, `f${i}.js`), 'x');

  const { forEachFile } = require('./corpus');
  let visited = 0;
  const stats = await forEachFile(dir, { maxFiles: 3 }, () => { visited++; });

  assert.equal(visited, 3);
  assert.equal(stats.truncated, true);
  assert.match(stats.truncatedReason, /OASIS_SCAN_MAX_FILES/,
    'the reason must name the knob that raises it');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the Maven cap reads its env var', () => {
  // The one knob that lives in the resolver rather than the scanner, so the
  // pattern above would not catch it moving.
  const source = fs.readFileSync(path.join(__dirname, 'maven-resolver.js'), 'utf8');
  assert.match(source, /OASIS_MAVEN_MAX_ARTIFACTS/);
});
