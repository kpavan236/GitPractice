'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const expected = require('./shims.expected.json');

// The engine modules moved to oasis-analyzer. Every old import path must keep
// exposing exactly the names it did before the move, so no other part of
// iready-oasis had to change.
for (const [mod, names] of Object.entries(expected)) {
  test(`${mod} still exports the same names`, () => {
    assert.deepEqual(Object.keys(require(`./${mod}`)).sort(), names);
  });
}

test('the engine modules are the analyzer\'s, not copies', () => {
  assert.equal(require('./finding'), require('oasis-analyzer/src/finding'));
  assert.equal(require('./ast/engine'), require('oasis-analyzer/src/ast/engine'));
  assert.equal(require('./corpus').runCorpusScanners, require('oasis-analyzer/src/corpus').runCorpusScanners);
});
