'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { satisfies, violations, readPath, OPERATORS, MISSING } = require('./iac/evaluate');
const { scanContent } = require('./scanners/iac-policy');

// The inversion is the thing to get right, so it is tested first and directly.
// A policy states what SHOULD be true; a finding is raised when it is NOT.
// Backwards, this engine would report every correctly configured resource and
// stay silent on the broken ones — wrong in the direction that gets people hurt.

const ENCRYPTED = {
  id: 'checkov-CKV_TEST_1',
  type: 'IAC',
  severity: 'HIGH',
  title: 'Storage must be encrypted',
  resourceTypes: ['aws_db_instance'],
  definition: {
    op: 'attribute',
    resourceTypes: ['aws_db_instance'],
    attribute: 'storage_encrypted',
    operator: 'is_true',
  },
};

function resource(type, body, name = 'r') {
  return { type, name, file: 'main.tf', line: 1, body };
}

test('a compliant resource produces no finding', () => {
  const compliant = [resource('aws_db_instance', { storage_encrypted: true })];
  assert.equal(satisfies(ENCRYPTED.definition, compliant[0]), true);
  assert.deepEqual(violations(ENCRYPTED, compliant), []);
});

test('a non-compliant resource produces exactly one', () => {
  const broken = [resource('aws_db_instance', { storage_encrypted: false })];
  assert.equal(satisfies(ENCRYPTED.definition, broken[0]), false);
  assert.equal(violations(ENCRYPTED, broken).length, 1);
});

test('a missing attribute is a violation, not a pass', () => {
  // The common real case: the attribute was never set. Treating absence as
  // compliant is how a policy engine reports nothing on a repository full of
  // unencrypted databases.
  const absent = [resource('aws_db_instance', {})];
  assert.equal(violations(ENCRYPTED, absent).length, 1);
});

test('a policy says nothing about resource types it does not name', () => {
  const other = [resource('aws_s3_bucket', { storage_encrypted: false })];
  assert.deepEqual(violations(ENCRYPTED, other), []);
});

// ── Path reading ───────────────────────────────────────────────────────────

test('reads nested and wildcard paths', () => {
  const body = { versioning: { enabled: true }, ingress: [{ port: 22 }, { port: 443 }] };
  assert.deepEqual(readPath(body, 'versioning.enabled'), [true]);
  assert.deepEqual(readPath(body, 'ingress.*.port'), [22, 443]);
});

test('a plain segment searches into a list', () => {
  // Terraform renders repeated blocks as a list, so `ingress.cidr_blocks` has
  // to work whether there is one ingress block or four.
  const body = { ingress: [{ cidr_blocks: ['10.0.0.0/8'] }, { cidr_blocks: ['0.0.0.0/0'] }] };
  assert.deepEqual(readPath(body, 'ingress.cidr_blocks'), [['10.0.0.0/8'], ['0.0.0.0/0']]);
});

test('an absent path reads as MISSING rather than undefined', () => {
  // `exists` and `is_false` must be able to tell "absent" from "set to false".
  assert.deepEqual(readPath({}, 'nope'), [MISSING]);
  assert.equal(OPERATORS.not_exists(MISSING), true);
  assert.equal(OPERATORS.is_false(MISSING), false);
  assert.equal(OPERATORS.is_false(false), true);
});

test('every element of a wildcard must satisfy the condition', () => {
  // One public subnet among ten is still a finding.
  const rule = {
    resourceTypes: ['aws_security_group'],
    definition: {
      op: 'attribute',
      resourceTypes: ['aws_security_group'],
      attribute: 'ingress.*.cidr_blocks',
      operator: 'not_contains',
      value: '0.0.0.0/0',
    },
  };
  const mixed = [resource('aws_security_group', {
    ingress: [{ cidr_blocks: ['10.0.0.0/8'] }, { cidr_blocks: ['0.0.0.0/0'] }],
  })];
  assert.equal(violations(rule, mixed).length, 1);
});

// ── Operators ──────────────────────────────────────────────────────────────

test('booleans compare loosely across string and native forms', () => {
  // Terraform and YAML both produce "true" where a policy says true; a strict
  // comparison would fail every boolean policy silently.
  assert.equal(OPERATORS.equals('true', true), true);
  assert.equal(OPERATORS.is_true('true'), true);
  assert.equal(OPERATORS.is_true(true), true);
});

test('numeric operators compare as numbers, not strings', () => {
  assert.equal(OPERATORS.greater_than('10', 9), true);
  assert.equal(OPERATORS.less_than(5, '10'), true);
  // "10" > "9" is false as strings; this is the classic silent bug.
  assert.equal(OPERATORS.greater_than_or_equal('10', '10'), true);
});

test('an unimplemented operator never reads as satisfied', () => {
  // Passing on an operator we do not implement would quietly clear every
  // resource the policy was written to catch.
  const rule = {
    resourceTypes: ['aws_s3_bucket'],
    definition: { op: 'attribute', resourceTypes: ['aws_s3_bucket'], attribute: 'acl', operator: 'nonsense' },
  };
  assert.equal(violations(rule, [resource('aws_s3_bucket', { acl: 'private' })]).length, 1);
});

// ── Boolean composition ────────────────────────────────────────────────────

test('and / or / not compose', () => {
  const body = { a: true, b: false };
  const r = resource('x', body);
  const attr = (attribute, operator) => ({ op: 'attribute', resourceTypes: ['x'], attribute, operator });

  assert.equal(satisfies({ op: 'and', children: [attr('a', 'is_true'), attr('b', 'is_false')] }, r), true);
  assert.equal(satisfies({ op: 'and', children: [attr('a', 'is_true'), attr('b', 'is_true')] }, r), false);
  assert.equal(satisfies({ op: 'or', children: [attr('a', 'is_false'), attr('b', 'is_false')] }, r), true);
  assert.equal(satisfies({ op: 'not', children: [attr('a', 'is_true')] }, r), false);
});

test('a filter nested in an and does not invert the result', () => {
  const r = resource('aws_elb', { versioning: true });
  const definition = {
    op: 'and',
    children: [
      { op: 'filter', attribute: 'resource_type', operator: 'within', value: ['aws_elb'] },
      { op: 'attribute', resourceTypes: ['aws_elb'], attribute: 'versioning', operator: 'is_true' },
    ],
  };
  assert.equal(satisfies(definition, r), true);
});

// ── End to end, through the scanner ────────────────────────────────────────

const OPEN_INGRESS = {
  id: 'checkov-CKV_TEST_SG',
  type: 'IAC',
  severity: 'HIGH',
  title: 'Security group must not be open to the internet',
  category: 'NETWORKING',
  resourceTypes: ['aws_security_group'],
  definition: {
    op: 'attribute',
    resourceTypes: ['aws_security_group'],
    attribute: 'ingress.cidr_blocks',
    operator: 'not_contains',
    value: '0.0.0.0/0',
  },
};

test('evaluates a policy against real Terraform', () => {
  const tf = `
resource "aws_security_group" "web" {
  ingress {
    from_port   = 443
    cidr_blocks = ["10.0.0.0/8"]
  }
}
resource "aws_security_group" "open" {
  ingress {
    from_port   = 22
    cidr_blocks = ["0.0.0.0/0"]
  }
}
`;
  const findings = scanContent(tf, 'main.tf', 'repo', [OPEN_INGRESS]);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].metadata.resourceName, 'open');
  assert.equal(findings[0].type, 'IAC');
  assert.equal(findings[0].metadata.engine, 'iac-policy');
});

test('a commented-out example does not fire, unlike a line pattern', () => {
  // The reason this engine exists. The pattern rule for the same thing leans on
  // requiresContext and still has to guess; a parser simply never sees the
  // commented attribute.
  const tf = `
resource "aws_security_group" "web" {
  # cidr_blocks = ["0.0.0.0/0"]   <- do not do this
  ingress {
    cidr_blocks = ["10.0.0.0/8"]
  }
}
`;
  assert.deepEqual(scanContent(tf, 'main.tf', 'repo', [OPEN_INGRESS]), []);
});

test('evaluates a policy against a Kubernetes manifest', () => {
  const privileged = {
    id: 'checkov-CKV_TEST_K8S',
    type: 'IAC',
    severity: 'HIGH',
    title: 'Containers must not be privileged',
    resourceTypes: ['Pod'],
    definition: {
      op: 'attribute',
      resourceTypes: ['Pod'],
      attribute: 'spec.containers.securityContext.privileged',
      operator: 'not_equals',
      value: true,
    },
  };

  const manifest = `
apiVersion: v1
kind: Pod
metadata:
  name: bad
spec:
  containers:
    - name: app
      securityContext:
        privileged: true
`;
  const findings = scanContent(manifest, 'pod.yaml', 'repo', [privileged]);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].metadata.resourceName, 'bad');
});

test('files with nothing to evaluate produce nothing', () => {
  assert.deepEqual(scanContent('just: config\n', 'values.yaml', 'repo', [OPEN_INGRESS]), []);
  assert.deepEqual(scanContent('', 'main.tf', 'repo', [OPEN_INGRESS]), []);
  assert.deepEqual(scanContent('x', 'README.md', 'repo', [OPEN_INGRESS]), []);
});

test('malformed YAML does not fail the scan', () => {
  assert.doesNotThrow(() => scanContent('a:\n  - [unclosed\n', 'bad.yaml', 'repo', [OPEN_INGRESS]));
});

test('a bundled policy tags its finding metadata.ruleSource as bundled', () => {
  const tf = `
resource "aws_security_group" "open" {
  ingress {
    cidr_blocks = ["0.0.0.0/0"]
  }
}
`;
  const findings = scanContent(tf, 'main.tf', 'repo', [OPEN_INGRESS]);
  assert.equal(findings[0].metadata.ruleSource, 'bundled');
});

test("a user-pack policy's finding is tagged metadata.ruleSource: 'user'", () => {
  const tf = `
resource "aws_security_group" "open" {
  ingress {
    cidr_blocks = ["0.0.0.0/0"]
  }
}
`;
  const findings = scanContent(tf, 'main.tf', 'repo', [{ ...OPEN_INGRESS, source: 'user' }]);
  assert.equal(findings[0].metadata.ruleSource, 'user');
});
