'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadKev, loadEpss, enrich, CACHE_TTL_MS } = require('./threat-intel');
const { createFinding } = require('./finding');

const NOW = 1700000000000;

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-intel-'));
}

const KEV_PAYLOAD = {
  vulnerabilities: [
    { cveID: 'CVE-2021-44228', dateAdded: '2021-12-10', dueDate: '2021-12-24', knownRansomwareCampaignUse: 'Known', vulnerabilityName: 'Log4Shell' },
    { cveID: 'CVE-2017-5638', dateAdded: '2021-11-03', knownRansomwareCampaignUse: 'Unknown', vulnerabilityName: 'Struts RCE' },
    { dateAdded: '2020-01-01' }, // no cveID — must be skipped, not crash
  ],
};

function epssPayload(rows) {
  return { data: rows.map(([cve, epss, percentile]) => ({ cve, epss: String(epss), percentile: String(percentile) })) };
}

function sca(cve, severity = 'MEDIUM') {
  return createFinding({
    type: 'SCA', category: 'VULNERABLE_DEPENDENCY', severity,
    title: cve, repository: 'repo-a', cve, source: 'VERSION_WATCH',
    metadata: { ecosystem: 'maven', packageName: 'log4j-core' },
  });
}

// ── KEV ────────────────────────────────────────────────────────────────────

test('the KEV catalog is fetched and indexed by CVE', async () => {
  const kev = await loadKev({ dir: tmpDir(), now: () => NOW, fetchJson: async () => KEV_PAYLOAD });
  assert.equal(kev.entries.size, 2);
  assert.equal(kev.entries.get('CVE-2021-44228').ransomware, true);
  assert.equal(kev.entries.get('CVE-2017-5638').ransomware, false);
});

test('a malformed KEV row is skipped rather than crashing the scan', async () => {
  const kev = await loadKev({ dir: tmpDir(), now: () => NOW, fetchJson: async () => KEV_PAYLOAD });
  assert.equal(kev.entries.has(undefined), false);
});

test('a fresh KEV cache is used instead of refetching', async () => {
  const dir = tmpDir();
  let calls = 0;
  const fetchJson = async () => { calls += 1; return KEV_PAYLOAD; };

  await loadKev({ dir, now: () => NOW, fetchJson });
  const second = await loadKev({ dir, now: () => NOW + 60000, fetchJson });

  assert.equal(calls, 1);
  assert.equal(second.fromCache, true);
  assert.equal(second.entries.size, 2);
});

test('an expired cache is refetched', async () => {
  const dir = tmpDir();
  let calls = 0;
  const fetchJson = async () => { calls += 1; return KEV_PAYLOAD; };

  await loadKev({ dir, now: () => NOW, fetchJson });
  await loadKev({ dir, now: () => NOW + CACHE_TTL_MS + 1, fetchJson });

  assert.equal(calls, 2);
});

test('a stale cache is served when the fetch fails', async () => {
  // Being a day behind on KEV beats losing the exploit signal for the whole
  // scan because a laptop was on a plane.
  const dir = tmpDir();
  await loadKev({ dir, now: () => NOW, fetchJson: async () => KEV_PAYLOAD });

  const offline = await loadKev({
    dir,
    now: () => NOW + CACHE_TTL_MS + 1,
    fetchJson: async () => { throw new Error('ENOTFOUND'); },
  });

  assert.equal(offline.entries.size, 2);
  assert.equal(offline.stale, true);
  assert.match(offline.error, /ENOTFOUND/);
});

test('with no cache and no network, KEV is unavailable rather than empty-but-authoritative', async () => {
  const kev = await loadKev({ dir: tmpDir(), now: () => NOW, fetchJson: async () => { throw new Error('offline'); } });
  assert.equal(kev.unavailable, true);
  assert.equal(kev.entries.size, 0);
});

// ── EPSS ───────────────────────────────────────────────────────────────────

test('EPSS scores are fetched for the CVEs actually referenced', async () => {
  let requested = null;
  const epss = await loadEpss(['CVE-2021-44228', 'CVE-2017-5638'], {
    dir: tmpDir(),
    now: () => NOW,
    fetchJson: async url => {
      requested = url;
      return epssPayload([['CVE-2021-44228', 0.97, 0.999], ['CVE-2017-5638', 0.94, 0.998]]);
    },
  });

  assert.equal(epss.scores.get('CVE-2021-44228').score, 0.97);
  assert.match(requested, /CVE-2021-44228,CVE-2017-5638/);
});

test('non-CVE identifiers are not sent to EPSS', async () => {
  // OSV ids like GHSA-xxxx have no EPSS score and would waste the request.
  let called = false;
  const epss = await loadEpss(['GHSA-jfh8-c2jp-5v3q', 'not-an-id'], {
    dir: tmpDir(), now: () => NOW,
    fetchJson: async () => { called = true; return epssPayload([]); },
  });
  assert.equal(called, false);
  assert.equal(epss.scores.size, 0);
});

test('duplicate CVEs are requested once', async () => {
  let urls = 0;
  await loadEpss(['CVE-2021-44228', 'CVE-2021-44228'], {
    dir: tmpDir(), now: () => NOW,
    fetchJson: async url => { urls += 1; assert.equal((url.match(/CVE-/g) || []).length, 1); return epssPayload([]); },
  });
  assert.equal(urls, 1);
});

test('cached EPSS scores are reused on the next scan', async () => {
  const dir = tmpDir();
  let calls = 0;
  const fetchJson = async () => { calls += 1; return epssPayload([['CVE-2021-44228', 0.97, 0.999]]); };

  await loadEpss(['CVE-2021-44228'], { dir, now: () => NOW, fetchJson });
  const second = await loadEpss(['CVE-2021-44228'], { dir, now: () => NOW + 1000, fetchJson });

  assert.equal(calls, 1);
  assert.equal(second.scores.get('CVE-2021-44228').score, 0.97);
});

test('a CVE with no EPSS score is remembered so it is not asked for again today', async () => {
  const dir = tmpDir();
  let calls = 0;
  const fetchJson = async () => { calls += 1; return epssPayload([]); };

  await loadEpss(['CVE-2099-0001'], { dir, now: () => NOW, fetchJson });
  await loadEpss(['CVE-2099-0001'], { dir, now: () => NOW + 1000, fetchJson });

  assert.equal(calls, 1);
});

test('an EPSS failure returns what was gathered rather than throwing', async () => {
  const result = await loadEpss(['CVE-2021-44228'], {
    dir: tmpDir(), now: () => NOW,
    fetchJson: async () => { throw new Error('503'); },
  });
  assert.equal(result.scores.size, 0);
  assert.match(result.error, /503/);
});

// ── Enrichment ─────────────────────────────────────────────────────────────

test('a KEV listing marks a finding known-exploited', async () => {
  const findings = [sca('CVE-2021-44228')];
  const kev = await loadKev({ dir: tmpDir(), now: () => NOW, fetchJson: async () => KEV_PAYLOAD });

  const applied = enrich(findings, { kev, epss: { scores: new Map() } });

  assert.equal(applied.kevHits, 1);
  assert.equal(findings[0].metadata.knownExploited, true);
  assert.equal(findings[0].metadata.kev.ransomware, true);
});

test('confirmed exploitation raises a MEDIUM advisory', () => {
  // A vulnerability being exploited in the wild is not a MEDIUM, whatever the
  // advisory's own label says.
  const findings = [sca('CVE-2021-44228', 'MEDIUM')];
  enrich(findings, { kev: { entries: new Map([['CVE-2021-44228', { ransomware: false }]]) }, epss: { scores: new Map() } });
  assert.equal(findings[0].severity, 'HIGH');
});

test('a CRITICAL is not downgraded by enrichment', () => {
  const findings = [sca('CVE-2021-44228', 'CRITICAL')];
  enrich(findings, { kev: { entries: new Map([['CVE-2021-44228', {}]]) }, epss: { scores: new Map() } });
  assert.equal(findings[0].severity, 'CRITICAL');
});

test('absence from KEV is not recorded as evidence of safety', () => {
  // KEV lists what is confirmed exploited. It is not a list of everything that
  // is not, so a miss must leave the factor unknown rather than set false.
  const findings = [sca('CVE-2099-0001')];
  enrich(findings, { kev: { entries: new Map() }, epss: { scores: new Map() } });
  assert.equal(findings[0].metadata.knownExploited, undefined);
});

test('EPSS scores are attached with their percentile', () => {
  const findings = [sca('CVE-2021-44228')];
  const applied = enrich(findings, {
    kev: { entries: new Map() },
    epss: { scores: new Map([['CVE-2021-44228', { score: 0.97, percentile: 0.999 }]]) },
  });
  assert.equal(applied.epssScored, 1);
  assert.equal(findings[0].metadata.epss, 0.97);
  assert.equal(findings[0].metadata.epssPercentile, 0.999);
});

test('findings without a CVE are left untouched', () => {
  const secret = createFinding({
    type: 'SECRET', category: 'AWS_KEY', severity: 'CRITICAL', title: 'k',
    repository: 'r', source: 'BUILTIN_SECRETS', metadata: { secretHash: 'x' },
  });
  enrich([secret], { kev: { entries: new Map([['CVE-2021-44228', {}]]) }, epss: { scores: new Map() } });
  assert.equal(secret.metadata.knownExploited, undefined);
});