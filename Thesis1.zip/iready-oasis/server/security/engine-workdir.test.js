'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { installedLoader, tmpDir } = require('./test-support/loader');
const { prepareCore, acquireCore } = require('./engine-workdir');

const langs = (release) => ({ release, languages: { go: { extensions: ['.go'], rules: [], grammar: 'WASM-GO' }, python: { extensions: ['.py'], rules: [], grammar: 'WASM-PY' } } });

test('the core is copied to a working dir with every language pack\'s grammar at src/ast/grammars; the verified store is untouched', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const core = await prepareCore({ loader, workDir: work });
  assert.ok(core.startsWith(work));
  assert.equal(fs.readFileSync(path.join(core, 'src/ast/grammars/tree-sitter-go.wasm'), 'utf8'), 'WASM-GO');
  assert.equal(fs.readFileSync(path.join(core, 'src/ast/grammars/tree-sitter-python.wasm'), 'utf8'), 'WASM-PY');
  assert.ok(fs.existsSync(path.join(core, 'index.js')));
  assert.ok(!fs.existsSync(path.join(loader.corePath(), 'src/ast/grammars')), 'must not write into the verified store');
});

test('the same release is prepared once; a new release gets its own dir and the old one is removed', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const one = await prepareCore({ loader, workDir: work });
  fs.writeFileSync(path.join(one, 'marker'), 'kept');
  assert.equal(await prepareCore({ loader, workDir: work }), one);
  assert.ok(fs.existsSync(path.join(one, 'marker')));
  loader.serve(langs(2));
  await loader.update();
  const two = await prepareCore({ loader, workDir: work });
  assert.notEqual(two, one);
  assert.ok(!fs.existsSync(one));
});

test('an interrupted preparation is redone rather than trusted', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const one = await prepareCore({ loader, workDir: work });
  fs.rmSync(path.join(one, '.ready'));
  fs.rmSync(path.join(one, 'src/ast/grammars/tree-sitter-go.wasm'));
  const again = await prepareCore({ loader, workDir: work });
  assert.ok(fs.existsSync(path.join(again, 'src/ast/grammars/tree-sitter-go.wasm')));
});

test('with no release installed it rejects with NO_RULES_INSTALLED', async (t) => {
  const { offlineLoader } = require('./test-support/loader');
  await assert.rejects(async () => prepareCore({ loader: offlineLoader(t), workDir: tmpDir(t) }), { code: 'NO_RULES_INSTALLED' });
});

test('two concurrent prepareCore calls both succeed with identical content', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const [a, b] = await Promise.all([prepareCore({ loader, workDir: work }), prepareCore({ loader, workDir: work })]);
  assert.equal(a, b);
  assert.equal(fs.readFileSync(path.join(a, 'src/ast/grammars/tree-sitter-go.wasm'), 'utf8'), 'WASM-GO');
  assert.ok(fs.existsSync(path.join(a, '.ready')));
  assert.deepEqual(fs.readdirSync(work).filter((n) => n.includes('tmp')), [], 'no temp dirs left behind');
});

test('a release dir is built beside and renamed into place: it is never visible without .ready', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const seen = [];
  const origRename = fs.renameSync;
  fs.renameSync = (from, to) => { seen.push([path.basename(from), fs.existsSync(path.join(from, '.ready'))]); return origRename(from, to); };
  t.after(() => { fs.renameSync = origRename; });
  await prepareCore({ loader, workDir: work });
  fs.renameSync = origRename;
  assert.equal(seen.length, 1);
  assert.notEqual(seen[0][0], 'release-1');
  assert.equal(seen[0][1], true);
});

test('cleanup while a run holds an older release keeps that run\'s dir; it goes once the run is done', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const work = tmpDir(t);
  const held = await acquireCore({ loader, workDir: work });
  loader.serve(langs(2));
  await loader.update();
  const two = await prepareCore({ loader, workDir: work });
  assert.ok(fs.existsSync(held.path), 'the running scan\'s release dir must survive');
  assert.notEqual(two, held.path);
  held.done();
  await prepareCore({ loader, workDir: work });
  assert.ok(!fs.existsSync(held.path));
});

test('an explicit release is prepared even if the loader has moved on', async (t) => {
  const loader = await installedLoader(t, langs(1));
  const pinned = loader.current();
  const work = tmpDir(t);
  loader.serve(langs(2));
  await loader.update();
  const dir = await prepareCore({ loader, workDir: work, release: pinned });
  assert.equal(path.basename(dir), 'release-1');
  assert.equal(fs.readFileSync(path.join(dir, 'src/ast/grammars/tree-sitter-go.wasm'), 'utf8'), 'WASM-GO');
});
