'use strict';
const fs = require('fs');
const path = require('path');
const { toPosix } = require('./paths');
const storeModule = require('./store');

// Suppression that lives with the code, and a baseline.
//
// A scanner's usefulness is decided by its noise, not its coverage. 27 findings
// from one over-eager rule and people stop opening the tab, at which point the
// other 10 might as well not exist. Three mechanisms, each for a different kind
// of "yes, we know":
//
//   .oasis-security-ignore   paths and rules that are permanently uninteresting
//                            (test fixtures, vendored code, a rule that does not
//                            apply to this codebase)
//   // oasis:ignore          one specific line, reviewed and accepted, with the
//                            justification sitting next to the code it excuses
//   baseline                 "everything as of today is known; tell me about
//                            what arrives next"
//
// The first two are checked into the repository, which is the point: the
// decision is reviewable in a pull request rather than buried in one person's
// local database.

const IGNORE_FILENAME = '.oasis-security-ignore';

// The glob matcher and inline `oasis:ignore` markers moved to oasis-analyzer, where
// the engines use them; they are re-exported below.
const { globToRegExp, parseInlineIgnores, inlineIgnoreFor } = require('oasis-analyzer/src/ignore');

/**
 * Parses an ignore file.
 *
 * Each non-empty, non-comment line is one of:
 *   <glob>                every finding under that path
 *   <RULE>                that rule, everywhere
 *   <RULE>: <glob>        that rule, under that path
 *
 * A rule is distinguished from a path by having no slash and no dot — rule ids
 * look like `java-sql-injection` or `GENERIC_SECRET_ASSIGNMENT`, paths look
 * like `src/**` or `*.min.js`.
 */
function parseIgnoreFile(text) {
  const rules = [];

  for (const rawLine of String(text || '').split('\n')) {
    const line = rawLine.replace(/\s+#.*$/, '').trim();
    if (!line || line.startsWith('#')) continue;

    const scoped = /^([A-Za-z0-9_.-]+)\s*:\s*(.+)$/.exec(line);
    if (scoped && !scoped[1].includes('/')) {
      rules.push({ rule: scoped[1], glob: scoped[2].trim(), match: globToRegExp(scoped[2].trim()) });
      continue;
    }

    const looksLikeRule = !line.includes('/') && !line.includes('*') && !line.includes('.');
    if (looksLikeRule) {
      rules.push({ rule: line, glob: null, match: null });
      continue;
    }

    rules.push({ rule: null, glob: line, match: globToRegExp(line) });
  }

  return rules;
}

function loadIgnoreFile(repoPath, { repository, store = storeModule, dir } = {}) {
  if (repository && dir) {
    const stored = store.loadIgnoreConfig(repository, dir);
    if (stored !== null) return parseIgnoreFile(stored);
  }
  try {
    return parseIgnoreFile(fs.readFileSync(path.join(repoPath, IGNORE_FILENAME), 'utf8'));
  } catch (_) {
    return [];
  }
}

function saveIgnoreRules(repository, text, { store = storeModule, dir } = {}) {
  return store.saveIgnoreConfig(repository, text, dir);
}

function clearIgnoreRules(repository, { store = storeModule, dir } = {}) {
  return store.clearIgnoreConfig(repository, dir);
}

// Whether a path is excluded outright — no scanner should even read it. Used
// before analysis, so ignoring a fixture directory costs nothing rather than
// producing findings we then throw away.
function isPathIgnored(rules, relativePath) {
  const file = toPosix(relativePath);
  return rules.some(r => r.rule === null && r.match && r.match.test(file));
}

// Whether a specific finding is excluded. Checked after analysis, because rule
// scoping needs to know which rule fired.
function ignoreReasonFor(rules, finding) {
  const file = toPosix(finding.file || '');
  const ruleIds = new Set(
    [
      ...finding.detections.map(d => d.ruleId).filter(Boolean),
      finding.category,
      finding.type,
    ].map(String)
  );

  for (const r of rules) {
    if (r.rule && !ruleIds.has(r.rule)) continue;
    if (r.match && !r.match.test(file)) continue;
    if (!r.rule && !r.match) continue;
    return r.rule && r.glob
      ? `${IGNORE_FILENAME}: ${r.rule} in ${r.glob}`
      : r.rule
        ? `${IGNORE_FILENAME}: rule ${r.rule}`
        : `${IGNORE_FILENAME}: path ${r.glob}`;
  }
  return null;
}


// ── Baseline ───────────────────────────────────────────────────────────────
//
// "Everything here today is known; tell me what arrives next." The mechanism CI
// gates are built on, and the only realistic path from a 27-finding backlog to
// a green build that still means something.

function createBaseline(findings, now) {
  return {
    createdAt: now,
    fingerprints: [...new Set(findings.map(f => f.fingerprint).filter(Boolean))],
  };
}

function isNewSinceBaseline(baseline, finding) {
  if (!baseline || !Array.isArray(baseline.fingerprints)) return true;
  return !baseline.fingerprints.includes(finding.fingerprint);
}

module.exports = {
  IGNORE_FILENAME,
  parseIgnoreFile,
  loadIgnoreFile,
  saveIgnoreRules,
  clearIgnoreRules,
  isPathIgnored,
  ignoreReasonFor,
  parseInlineIgnores,
  inlineIgnoreFor,
  createBaseline,
  isNewSinceBaseline,
  globToRegExp,
};