'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { fingerprintOf, dedupe, normaliseSnippet } = require('./fingerprint');
const { createFinding, SEVERITY_RANK } = require('./finding');

const opts = { severityRank: SEVERITY_RANK };

function secret({ source = 'BUILTIN_SECRETS', file = 'src/App.java', line = 10, hash = 'abc123', severity = 'CRITICAL' } = {}) {
  return createFinding({
    type: 'SECRET', category: 'AWS_KEY', severity, title: 'AWS key',
    repository: 'repo-a', file, startLine: line, source, ruleId: 'aws-access-key-id',
    metadata: { secretHash: hash },
  });
}

function sca({ pkg = 'log4j-core', cve = 'CVE-2021-44228', version = '2.14.1', source = 'VERSION_WATCH', severity = 'CRITICAL' } = {}) {
  return createFinding({
    type: 'SCA', category: 'VULNERABLE_DEPENDENCY', severity, title: `${cve} in ${pkg}`,
    repository: 'repo-a', cve, source, ruleId: cve,
    metadata: { ecosystem: 'maven', packageName: pkg, versionInUse: version },
  });
}

function sast({ file = 'src/Repo.java', line = 42, snippet = 'stmt.execute("SELECT " + name)', cwe = 'CWE-89', source = 'SEMGREP' } = {}) {
  return createFinding({
    type: 'SAST', category: 'SQLI', severity: 'HIGH', title: 'SQL injection',
    repository: 'repo-a', file, startLine: line, cwe, source, ruleId: 'java.sqli',
    metadata: { snippet },
  });
}

// ── Stability across editing ───────────────────────────────────────────────

test('a secret keeps its identity when the code around it moves', () => {
  // Adding an import at the top of a file shifts every line below it. A
  // line-based fingerprint would close this finding and open an identical one,
  // losing its age and any triage decision attached to it.
  assert.equal(fingerprintOf(secret({ line: 10 })), fingerprintOf(secret({ line: 250 })));
});

test('a different secret in the same file is a different finding', () => {
  assert.notEqual(fingerprintOf(secret({ hash: 'aaa' })), fingerprintOf(secret({ hash: 'bbb' })));
});

test('the same secret in a different file is a different finding', () => {
  assert.notEqual(fingerprintOf(secret({ file: 'A.java' })), fingerprintOf(secret({ file: 'B.java' })));
});

test('a SAST finding survives reformatting and a changed literal', () => {
  const a = sast({ snippet: 'stmt.execute("SELECT * FROM users WHERE n = " + name)' });
  const b = sast({ snippet: "stmt.execute(  'SELECT * FROM accounts WHERE n = '  +  name )", line: 99 });
  assert.equal(fingerprintOf(a), fingerprintOf(b));
});

test('a genuinely different statement is a different finding', () => {
  assert.notEqual(
    fingerprintOf(sast({ snippet: 'stmt.execute(query)' })),
    fingerprintOf(sast({ snippet: 'runtime.exec(command)' }))
  );
});

test('an SCA finding is identified by package and advisory, not version', () => {
  // Upgrading is what resolves it, so the version cannot be part of its
  // identity — otherwise every bump would look like a brand new vulnerability.
  assert.equal(fingerprintOf(sca({ version: '2.14.1' })), fingerprintOf(sca({ version: '2.15.0' })));
});

test('two advisories against the same package are separate findings', () => {
  assert.notEqual(fingerprintOf(sca({ cve: 'CVE-2021-44228' })), fingerprintOf(sca({ cve: 'CVE-2021-45046' })));
});

test('the same package in two repositories is two findings', () => {
  const a = sca();
  const b = sca();
  b.repository = 'repo-b';
  assert.notEqual(fingerprintOf(a), fingerprintOf(b));
});

test('normalising a snippet strips literals, numbers, and all whitespace', () => {
  assert.equal(normaliseSnippet('foo( "bar" ,  42 )'), 'foo(S,N)');
  assert.equal(normaliseSnippet("foo('bar',42)"), 'foo(S,N)');
});

// ── Correlation ────────────────────────────────────────────────────────────

test('two scanners finding the same secret produce one finding with two sources', () => {
  // This is the whole point of normalising: the dashboard shows the issue once,
  // with corroboration, instead of the same leak twice under different names.
  const merged = dedupe([secret({ source: 'BUILTIN_SECRETS' }), secret({ source: 'GITLEAKS' })], opts);

  assert.equal(merged.length, 1);
  assert.deepEqual(merged[0].detections.map(d => d.source).sort(), ['BUILTIN_SECRETS', 'GITLEAKS']);
});

test('merging keeps the worst severity, not the last one seen', () => {
  // Presenting the optimistic view because of scan order would be indefensible.
  const merged = dedupe([secret({ severity: 'MEDIUM' }), secret({ source: 'GITLEAKS', severity: 'CRITICAL' })], opts);
  assert.equal(merged[0].severity, 'CRITICAL');

  const reversed = dedupe([secret({ severity: 'CRITICAL' }), secret({ source: 'GITLEAKS', severity: 'MEDIUM' })], opts);
  assert.equal(reversed[0].severity, 'CRITICAL');
});

test('merging fills gaps from the corroborating report', () => {
  const withoutCwe = sast({ cwe: null });
  withoutCwe.metadata.snippet = 'x';
  const withCwe = sast({ cwe: 'CWE-89', source: 'CODEQL' });
  withCwe.metadata.snippet = 'x';

  const merged = dedupe([withoutCwe, withCwe], opts);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].cwe, 'CWE-89');
});

test('the same scanner reporting twice does not duplicate the detection source', () => {
  const merged = dedupe([secret(), secret()], opts);
  assert.equal(merged[0].detections.length, 1);
});

test('unrelated findings are left alone', () => {
  const merged = dedupe([secret(), sca(), sast()], opts);
  assert.equal(merged.length, 3);
});

test('every finding leaves deduplication with a fingerprint', () => {
  for (const f of dedupe([secret(), sca(), sast()], opts)) {
    assert.match(f.fingerprint, /^[0-9a-f]{40}$/);
  }
});
// ── Licence findings ───────────────────────────────────────────────────────

function license({ pkg = 'ch.qos.logback:logback-classic', spdx = 'EPL-1.0', category = 'LICENSE_WEAK_COPYLEFT', repo = 'repo-a' } = {}) {
  return createFinding({
    type: 'LICENSE', category, severity: 'LOW', title: `${spdx} — ${pkg}`,
    repository: repo, file: 'pom.xml', source: 'MAVEN_SCA', ruleId: 'license-weak-copyleft',
    metadata: { ecosystem: 'Maven', packageName: pkg, versionInUse: '1.2.11', license: spdx },
  });
}

test('two packages under the same licence are two findings', () => {
  // The regression this guards: without a LICENSE identity these fell back to
  // type+repo+file+category, so every weak-copyleft dependency in one pom.xml
  // collapsed into a single finding and two of three vanished.
  const merged = dedupe([
    license({ pkg: 'ch.qos.logback:logback-classic' }),
    license({ pkg: 'com.h2database:h2', spdx: 'MPL-2.0' }),
    license({ pkg: 'javax.annotation:javax.annotation-api', spdx: 'GPL-2.0-with-classpath-exception' }),
  ], opts);
  assert.equal(merged.length, 3);
});

test('the same package reported twice is one licence finding', () => {
  assert.equal(dedupe([license(), license()], opts).length, 1);
});

test('a licence finding survives a version bump', () => {
  // A dependency keeps its licence across upgrades; re-raising it on every bump
  // would reset triage that is still valid.
  const a = license();
  const b = license();
  b.metadata.versionInUse = '1.5.0';
  assert.equal(fingerprintOf(a), fingerprintOf(b));
});

test('a package that changes licence is a new finding', () => {
  assert.notEqual(fingerprintOf(license({ spdx: 'EPL-1.0' })), fingerprintOf(license({ spdx: 'AGPL-3.0' })));
});
