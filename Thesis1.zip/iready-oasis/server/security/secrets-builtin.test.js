'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const secretsEngine = require('./scanners/secrets-builtin');
const { withTestRules } = require('./test-support/rules');
const { scanContent, maskSecret, hashSecret } = secretsEngine;
const scanner = withTestRules(secretsEngine.scanner);
const { dedupe } = require('./fingerprint');
const { SEVERITY_RANK } = require('./finding');

const REPO = 'fixture-repo';

function scan(content, file = 'src/Config.java') {
  return scanContent(content, file, REPO);
}

function fixtureRepo(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-sec-'));
  for (const [name, content] of Object.entries(files)) {
    const full = path.join(dir, name);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content);
  }
  return dir;
}

// ── Detection ──────────────────────────────────────────────────────────────

test('an AWS access key id is found', () => {
  const found = scan('String key = "AKIAIOSFODNN7REALKEY";');
  assert.equal(found.length, 1);
  assert.equal(found[0].category, 'AWS_ACCESS_KEY_ID');
  assert.equal(found[0].severity, 'CRITICAL');
  assert.equal(found[0].cwe, 'CWE-798');
});

test('a temporary STS key is found as well as a long-lived one', () => {
  assert.equal(scan('token = "ASIAIOSFODNN7REALKEY"').length, 1);
});

test('a GitHub personal access token is found', () => {
  const found = scan(`token: ghp_${'a1B2c3D4e5'.repeat(3)}abcdef`);
  assert.equal(found.length, 1);
  assert.equal(found[0].severity, 'CRITICAL');
});

test('a private key header is found', () => {
  const found = scan('-----BEGIN RSA PRIVATE KEY-----\nMIIEow...\n');
  assert.equal(found.length, 1);
  assert.equal(found[0].category, 'PRIVATE_KEY');
});

test('a password inside a database URL is found', () => {
  const found = scan('spring.datasource.url=postgresql://svc:Hunter2Hunter2@db.internal:5432/app');
  assert.ok(found.some(f => f.category === 'POSTGRES_URL'));
});

test('a Slack bot token is found', () => {
  assert.equal(scan('SLACK_TOKEN=xoxb-2401234567-2409876543-AbCdEfGhIjKlMnOpQrSt').length, 1);
});

test('the line number is reported', () => {
  const found = scan('line one\nline two\nkey = "AKIAIOSFODNN7REALKEY"\n');
  assert.equal(found[0].startLine, 3);
});

// ── The property that matters most ─────────────────────────────────────────

test('the secret itself is never stored on the finding', () => {
  // A security tool that copies credentials into its own database is a second
  // copy of the leak. Only a hash and a mask may survive.
  const secret = 'AKIAIOSFODNN7REALKEY';
  const found = scan(`String key = "${secret}";`);
  const serialised = JSON.stringify(found[0]);
  assert.equal(serialised.includes(secret), false, 'the raw secret leaked into the finding');
  assert.equal(found[0].metadata.secretHash, hashSecret(secret));
  assert.ok(found[0].metadata.masked.startsWith('AKIA'));
  assert.ok(found[0].metadata.masked.includes('*'));
});

test('the masked preview keeps only the ends', () => {
  assert.equal(maskSecret('AKIAIOSFODNN7REALKEY'), 'AKIA************LKEY');
  assert.equal(maskSecret('short'), '*****');
});

test('the same secret hashes the same way for deduplication', () => {
  const a = scan('key = "AKIAIOSFODNN7REALKEY"', 'A.java')[0];
  const b = scan('\n\nkey = "AKIAIOSFODNN7REALKEY"', 'A.java')[0];
  // Same file, same secret, different line — one finding, so that moving code
  // does not reopen it.
  assert.equal(a.metadata.secretHash, b.metadata.secretHash);
});

// ── False positives ────────────────────────────────────────────────────────

test('placeholders are not reported', () => {
  // A scanner that cries wolf gets switched off, and then it catches nothing.
  const placeholders = [
    'password = "changeme"',
    'api_key = "YOUR_API_KEY_HERE"',
    'secret = "xxxxxxxxxxxx"',
    'password = "${DB_PASSWORD}"',
    'apiKey = "$MY_API_KEY"',
    'password = "example"',
    'token = "<your-token>"',
    'password = "test"',
  ];
  for (const line of placeholders) {
    assert.deepEqual(scan(line), [], `should not flag: ${line}`);
  }
});

test('a documented placeholder carrying a real provider prefix is not reported', () => {
  // The false positive this fixes: config/oasis.yml documents how to add a
  // Slack token with `# token: xoxb-your-bot-token`, and the scanner flagged
  // it. The marker sits AFTER the provider prefix, so the start-anchored
  // placeholder patterns never saw it.
  const placeholders = [
    'token = "xoxb-your-bot-token"',
    'token = "ghp_your_token_here"',
    'key = "sk-example-key"',
    'token = "my-api-token-goes-here"',
  ];
  for (const line of placeholders) {
    assert.deepEqual(scan(line), [], `should not flag: ${line}`);
  }
});

test('A CREDENTIAL INSIDE A COMMENT IS STILL REPORTED', () => {
  // Deliberately NOT suppressed. Commenting a line out does not remove the
  // secret from the file or from git history, so a scanner that skipped
  // comments would miss one of the most common ways a key actually leaks —
  // someone "disabling" it instead of rotating it.
  const commented = [
    '// String key = "AKIAIOSFODNN7REALKEY";  // old key, remove later',
    '# aws_access_key_id = AKIAIOSFODNN7REALKEY',
    '  * token: xoxb-2401234567-2409876543-AbCdEfGhIjKlMnOpQrSt',
  ];
  for (const line of commented) {
    assert.equal(scan(line).length > 0, true, `a commented credential must still be found: ${line}`);
  }
});

test('a real token is never dismissed as a placeholder', () => {
  // The direction that matters. A missed credential is unbounded damage; a
  // false positive is an annoyance.
  assert.equal(scan('SLACK_TOKEN=xoxb-2401234567-2409876543-AbCdEfGhIjKlMnOpQrSt').length, 1);
  assert.equal(scan('String key = "AKIAIOSFODNN7REALKEY";').length, 1);
});

test("AWS's own documentation key is not reported", () => {
  assert.deepEqual(scan('key = "AKIAIOSFODNN7EXAMPLE"'), []);
});

test('a low-entropy value assigned to a secret-shaped name is not reported', () => {
  assert.deepEqual(scan('password = "see the internal wiki"'), []);
});

test('a high-entropy value assigned to a secret-shaped name IS reported', () => {
  const found = scan('client_secret = "8Kj2Xp9QmRt4Vw7Nz3Bs6Yd1Hf5Gc0La"');
  assert.equal(found.length, 1);
  assert.equal(found[0].category, 'GENERIC_SECRET_ASSIGNMENT');
});

test('ordinary source produces nothing', () => {
  const clean = `
    package com.cainc.iready;
    public class StudentService {
      private final StudentRepository repo;
      public List<Student> search(String name) { return repo.findByName(name); }
    }`;
  assert.deepEqual(scan(clean), []);
});

// ── Walking a repository ───────────────────────────────────────────────────

test('a fixture repository is scanned end to end', async () => {
  const dir = fixtureRepo({
    'src/main/java/App.java': 'String k = "AKIAIOSFODNN7REALKEY";',
    'config/app.properties': 'db.url=postgresql://svc:S3cretP4ssw0rd@db:5432/x',
    'README.md': 'Set AWS_ACCESS_KEY_ID in your environment.',
  });
  const result = await scanner.scan({ repoPath: dir, repository: REPO });

  // The scanner emits RAW findings; the orchestrator dedupes them. Since the
  // bundle's Gitleaks rules now run alongside the built-in table, the same
  // credential is legitimately reported twice — once per rule set — and the two
  // collapse into one finding carrying both detections. Asserting the raw count
  // here would be asserting an implementation detail that changes every time a
  // rule set grows; asserting the deduped count is what a user sees.
  const merged = dedupe(result.findings, { severityRank: SEVERITY_RANK });
  assert.equal(merged.length, 2);
  assert.equal(result.stats.filesScanned, 3);
  assert.equal(result.stats.truncated, false);

  // Corroboration is the point of running both: two independent rule sets
  // agreeing on one secret is stronger evidence than either alone.
  const aws = merged.find(f => f.file.endsWith('App.java'));
  assert.ok(
    aws.detections.length >= 2,
    `expected the built-in and Gitleaks rules to corroborate, got ${JSON.stringify(aws.detections.map(d => d.ruleId))}`
  );

  fs.rmSync(dir, { recursive: true, force: true });
});

test('vendored and build directories are skipped', async () => {
  const dir = fixtureRepo({
    'node_modules/pkg/index.js': 'const k = "AKIAIOSFODNN7REALKEY";',
    'target/classes/App.class': 'const k = "AKIAIOSFODNN7REALKEY";',
    '.git/config': 'password = "AKIAIOSFODNN7REALKEY"',
    'src/App.java': '// clean',
  });
  const result = await scanner.scan({ repoPath: dir, repository: REPO });

  // Dependencies are not the customer's code, and .git is scanned by Gitleaks
  // which understands history properly.
  assert.deepEqual(result.findings, []);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('hitting the file cap is reported rather than passing as a clean scan', async () => {
  const files = {};
  for (let i = 0; i < 12; i++) files[`f${i}.txt`] = 'nothing here';
  const dir = fixtureRepo(files);

  const result = await scanner.scan({ repoPath: dir, repository: REPO, maxFiles: 5 });

  assert.equal(result.stats.truncated, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a binary file is skipped even with a text extension', async () => {
  const dir = fixtureRepo({ 'data.txt': `bin\0ary AKIAIOSFODNN7REALKEY` });
  const result = await scanner.scan({ repoPath: dir, repository: REPO });
  assert.deepEqual(result.findings, []);
  assert.equal(result.stats.filesSkipped, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a missing repository path is an error, not an empty result', async () => {
  // Silently returning "no findings" for a path that does not exist would read
  // as a clean repository.
  await assert.rejects(
    () => scanner.scan({ repoPath: '/no/such/repo', repository: REPO }),
    /does not exist/
  );
});

test('the built-in scanner is always available', async () => {
  assert.equal((await scanner.isAvailable()).available, true);
});

test('a built-in secret pattern tags its finding metadata.ruleSource as bundled', () => {
  const found = scan('String key = "AKIAIOSFODNN7REALKEY";');
  assert.equal(found[0].metadata.ruleSource, 'bundled');
});

test("a user-pack secret rule's finding is tagged metadata.ruleSource: 'user'", () => {
  // bundleRules arrives pre-compiled (see bundleSecretRules in
  // scanners/secrets-builtin.js) — this is that shape, carrying source:'user'
  // the way a rule loaded from ~/.oasis/security/rules/*.json would.
  const userRule = {
    id: 'custom-marker-secret',
    name: 'Custom marker secret',
    pattern: /TOTALLY_CUSTOM_SECRET_[A-Z0-9]+/g,
    severity: 'HIGH',
    entropyFloor: null,
    keywords: [],
    secretGroup: null,
    allowlist: null,
    source: 'user',
  };
  const found = scanContent('String key = "TOTALLY_CUSTOM_SECRET_ABC123";', 'src/Config.java', REPO, [userRule]);
  assert.equal(found[0].metadata.ruleSource, 'user');
});