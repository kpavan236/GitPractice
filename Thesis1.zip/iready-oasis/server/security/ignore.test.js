'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  parseIgnoreFile, isPathIgnored, ignoreReasonFor, parseInlineIgnores,
  inlineIgnoreFor, createBaseline, isNewSinceBaseline, globToRegExp,
} = require('./ignore');
const { scanSource } = require('./scanners/sast-ast');
const { testRuleSet } = require('./test-support/rules');

function finding(overrides = {}) {
  return {
    file: 'src/Repo.java',
    startLine: 42,
    category: 'SQL_INJECTION',
    type: 'SAST',
    fingerprint: 'fp-1',
    detections: [{ source: 'BUILTIN_SAST', ruleId: 'java-sql-injection' }],
    ...overrides,
  };
}

// ── Globs ──────────────────────────────────────────────────────────────────

test('globs match the way people expect', () => {
  assert.ok(globToRegExp('src/**').test('src/main/App.java'));
  assert.ok(globToRegExp('**/test/**').test('a/b/test/c/X.java'));
  assert.ok(globToRegExp('*.min.js').test('bundle.min.js'));
  assert.equal(globToRegExp('*.min.js').test('src/bundle.min.js'), false);
  assert.ok(globToRegExp('**/*.min.js').test('src/bundle.min.js'));
});

test('a glob cannot be escaped with regex metacharacters', () => {
  // `.` in a glob is a literal dot, not "any character".
  assert.equal(globToRegExp('a.js').test('axjs'), false);
});

// ── Ignore file ────────────────────────────────────────────────────────────

test('a bare path ignores everything under it', () => {
  const rules = parseIgnoreFile('src/test/**');
  assert.ok(isPathIgnored(rules, 'src/test/fixtures/Bad.java'));
  assert.equal(isPathIgnored(rules, 'src/main/App.java'), false);
});

test('a bare rule id ignores that rule everywhere', () => {
  const rules = parseIgnoreFile('java-sql-injection');
  assert.match(ignoreReasonFor(rules, finding()), /rule java-sql-injection/);
  assert.equal(ignoreReasonFor(rules, finding({ detections: [{ ruleId: 'js-eval' }] })), null);
});

test('a rule can be ignored in one path only', () => {
  const rules = parseIgnoreFile('java-sql-injection: src/legacy/**');
  assert.ok(ignoreReasonFor(rules, finding({ file: 'src/legacy/Old.java' })));
  // The same rule elsewhere still reports — that is the point of scoping.
  assert.equal(ignoreReasonFor(rules, finding({ file: 'src/main/New.java' })), null);
});

test('a category can be ignored, not just a rule id', () => {
  // Users think in categories ("stop telling me about generic secrets"), not
  // in the rule ids the engine happens to use.
  const rules = parseIgnoreFile('GENERIC_SECRET_ASSIGNMENT');
  assert.ok(ignoreReasonFor(rules, finding({ category: 'GENERIC_SECRET_ASSIGNMENT' })));
});

test('comments and blank lines are skipped', () => {
  const rules = parseIgnoreFile('# a comment\n\n  \nsrc/**   # trailing note\n');
  assert.equal(rules.length, 1);
  assert.equal(rules[0].glob, 'src/**');
});

test('an empty or missing ignore file ignores nothing', () => {
  assert.deepEqual(parseIgnoreFile(''), []);
  assert.equal(ignoreReasonFor([], finding()), null);
  assert.equal(isPathIgnored([], 'anything'), false);
});

test('the reason names the file, so a hidden finding is explainable', () => {
  // A finding that vanished with no traceable cause is worse than a noisy one.
  const reason = ignoreReasonFor(parseIgnoreFile('src/**'), finding());
  assert.match(reason, /\.oasis-security-ignore/);
});

// ── Inline markers ─────────────────────────────────────────────────────────

test('a marker on the same line suppresses that line', () => {
  const markers = parseInlineIgnores('dangerous();  // oasis:ignore\nother();');
  assert.ok(inlineIgnoreFor(markers, finding({ startLine: 1 })));
  assert.equal(inlineIgnoreFor(markers, finding({ startLine: 2 })), null);
});

test('a marker on its own line suppresses the line below', () => {
  const markers = parseInlineIgnores('// oasis:ignore\ndangerous();');
  assert.ok(inlineIgnoreFor(markers, finding({ startLine: 2 })));
});

test('a marker scoped to a rule does not suppress a different rule', () => {
  const markers = parseInlineIgnores('dangerous(); // oasis:ignore java-sql-injection');
  assert.ok(inlineIgnoreFor(markers, finding({ startLine: 1 })));
  assert.equal(
    inlineIgnoreFor(markers, finding({ startLine: 1, category: 'XSS', detections: [{ ruleId: 'js-dom-xss' }] })),
    null
  );
});

test('the justification travels with the suppression', () => {
  const markers = parseInlineIgnores('x(); // oasis:ignore java-sql-injection -- table name is a constant');
  assert.match(inlineIgnoreFor(markers, finding({ startLine: 1 })), /table name is a constant/);
});

test('markers work in Python and SQL comment syntax too', () => {
  assert.ok(inlineIgnoreFor(parseInlineIgnores('x() # oasis:ignore'), finding({ startLine: 1 })));
  assert.ok(inlineIgnoreFor(parseInlineIgnores('x() -- oasis:ignore'), finding({ startLine: 1 })));
});

test('an inline marker actually suppresses a real finding end to end', async () => {
  // Through the AST scanner, which is the engine that ships.
  const rules = testRuleSet().rules;
  const vulnerable = 'class A{void f(HttpServletRequest request)throws Exception{stmt.executeQuery("SELECT " + request.getParameter("q"));}}';
  assert.equal((await scanSource(vulnerable, 'A.java', 'r', rules)).length, 1);

  const ignored = 'class A{void f(HttpServletRequest request)throws Exception{\n  stmt.executeQuery("SELECT " + request.getParameter("q")); // oasis:ignore\n}}';
  assert.equal((await scanSource(ignored, 'A.java', 'r', rules)).length, 0);
});

// ── Baseline ───────────────────────────────────────────────────────────────

test('a baseline records what exists today', () => {
  const baseline = createBaseline([finding({ fingerprint: 'a' }), finding({ fingerprint: 'b' })], 1000);
  assert.deepEqual(baseline.fingerprints.sort(), ['a', 'b']);
  assert.equal(baseline.createdAt, 1000);
});

test('only findings absent from the baseline count as new', () => {
  // The mechanism a CI gate needs: a 27-finding backlog should not fail every
  // build, but the 28th should.
  const baseline = createBaseline([finding({ fingerprint: 'known' })], 1000);
  assert.equal(isNewSinceBaseline(baseline, finding({ fingerprint: 'known' })), false);
  assert.equal(isNewSinceBaseline(baseline, finding({ fingerprint: 'fresh' })), true);
});

test('with no baseline every finding is new', () => {
  assert.equal(isNewSinceBaseline(null, finding()), true);
  assert.equal(isNewSinceBaseline({}, finding()), true);
});

test('duplicate fingerprints are stored once', () => {
  assert.equal(createBaseline([finding({ fingerprint: 'x' }), finding({ fingerprint: 'x' })], 1).fingerprints.length, 1);
});

// ── Store preference (A3) ──────────────────────────────────────────────────

const { loadIgnoreFile, saveIgnoreRules } = require('./ignore');
const storeModule = require('./store');
const fs = require('fs');
const os = require('os');
const pathMod = require('path');

test('loadIgnoreFile prefers store config over ignore file', async (t) => {
  const dir = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'oasis-ign-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  await storeModule.saveIgnoreConfig('org/repo', 'src/generated/**', dir);
  const repoPath = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  fs.writeFileSync(pathMod.join(repoPath, '.oasis-security-ignore'), 'src/other/**');
  const rules = loadIgnoreFile(repoPath, { repository: 'org/repo', dir });
  assert.equal(rules.length, 1);
  assert.equal(rules[0].glob, 'src/generated/**');
});

test('loadIgnoreFile falls back to file when no store entry', (t) => {
  const dir = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'oasis-ign-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const repoPath = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  fs.writeFileSync(pathMod.join(repoPath, '.oasis-security-ignore'), 'src/other/**');
  const rules = loadIgnoreFile(repoPath, { repository: 'org/repo', dir });
  assert.equal(rules[0].glob, 'src/other/**');
});

test('saveIgnoreRules + loadIgnoreFile round-trip', async (t) => {
  const dir = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'oasis-ign-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const repoPath = fs.mkdtempSync(pathMod.join(os.tmpdir(), 'repo-'));
  t.after(() => fs.rmSync(repoPath, { recursive: true }));
  await saveIgnoreRules('org/repo', 'java-sql-injection\nsrc/test/**', { dir });
  const rules = loadIgnoreFile(repoPath, { repository: 'org/repo', dir });
  assert.equal(rules.length, 2);
});