'use strict';
const fs = require('node:fs');

// What the read-only Rules section shows: the installed release, its rules (id, title, language, pillar, severity,
// engine; never a rule's body), what the last update check said, and a project's overrides. Rule definitions are
// not edited on this machine; they come from the central rules service.
const PROJECT_KEY = /^[A-Za-z0-9][A-Za-z0-9._@+-]{0,199}$/;
const MAX_ID = 200;

const ERROR_TEXT = {
  NO_PINNED_KEYS: 'This build has no signing keys pinned, so rule releases cannot be trusted or downloaded yet.',
  OFFLINE: 'The rules service could not be reached. Scans keep using the installed release.',
  DEV_KEYS_UNREADABLE: 'The development signing key file (OASIS_DEV_RULES_PUBLIC_KEYS) could not be read, so no release was installed.',
  DEV_KEYS_BAD_FILE: 'The development signing key file (OASIS_DEV_RULES_PUBLIC_KEYS) is not a JSON object of key ids to public keys, so no release was installed.',
  DEV_KEY_INVALID: 'A key in the development signing key file (OASIS_DEV_RULES_PUBLIC_KEYS) is not a valid Ed25519 public key, so no release was installed.',
  DEV_KEY_PRIVATE: 'The development signing key file (OASIS_DEV_RULES_PUBLIC_KEYS) contains a PRIVATE key. Put only public keys in it. No release was installed.',
  DEV_KEY_ID_PINNED: 'A key id in the development signing key file (OASIS_DEV_RULES_PUBLIC_KEYS) is already pinned in this build and cannot be overridden.',
  BAD_SIGNATURE: 'The latest rules release failed its signature check and was not installed.',
  UNKNOWN_KEY: 'The latest rules release is signed with a key this build does not trust, so it was not installed.',
};

const badRequest = (message) => Object.assign(new Error(message), { status: 400 });

function createRulesView({ loader, updater = null, overrides }) {
  function installedAt(release) {
    try {
      const dir = Object.values(release.packDirs || {})[0];
      if (dir) return fs.statSync(dir).mtime.toISOString();
    } catch (_) { /* fall through */ }
    return release.manifest && release.manifest.createdAt ? release.manifest.createdAt : null;
  }

  function updateState() {
    const s = updater && updater.status ? updater.status() : { lastResult: null, lastError: null };
    if (s.lastError) {
      const code = s.lastError.code;
      return { updateAvailable: false, updateError: { code, message: ERROR_TEXT[code] || `The rules update failed (${code}): ${s.lastError.message}` } };
    }
    const r = s.lastResult;
    if (r && r.status === 'offline') return { updateAvailable: false, updateError: { code: 'OFFLINE', message: ERROR_TEXT.OFFLINE } };
    // A newer release exists but needs a newer app than this one: the user can act on that, so it is "available".
    if (r && r.error === 'UPGRADE_REQUIRED') return { updateAvailable: true, updateError: null };
    return { updateAvailable: false, updateError: null };
  }

  function installed(project) {
    const state = updateState();
    let release = null;
    let rules = [];
    try { release = loader.current(); } catch (e) {
      if (!state.updateError) state.updateError = { code: e.code || 'ERROR', message: `The installed rules could not be read (${e.code || 'ERROR'}).` };
    }
    if (release) {
      const languages = release.manifest.packs.filter((p) => p.kind === 'language').map((p) => p.language);
      rules = loader.rulesFor(languages).map((r) => ({
        id: r.id, title: r.title || r.id, language: r.language || null, pillar: r.pillar || null, severity: r.severity || null, engine: r.engine || null,
      })).sort((a, b) => (a.language || '').localeCompare(b.language || '') || a.id.localeCompare(b.id));
    }
    const view = {
      mode: 'installed',
      release: release ? { number: release.release, installedAt: installedAt(release), channel: release.manifest.channel || null, createdAt: release.manifest.createdAt || null } : null,
      ...state,
      // Ids of DEV-ONLY signing keys the release was trusted through ([] in a normal build): the page says "Development key".
      devKeys: typeof loader.devKeys === 'function' ? loader.devKeys() : [],
      rules,
    };
    if (typeof project === 'string' && PROJECT_KEY.test(project)) view.overrides = overrides.get(project);
    return view;
  }

  function setOverrides(project, body) {
    if (typeof project !== 'string' || !PROJECT_KEY.test(project)) throw badRequest('project must be a repository name');
    if (body === null || typeof body !== 'object' || Array.isArray(body)) throw badRequest('body must be an object');
    const { disabled, severity } = body;
    if (disabled !== undefined && (!Array.isArray(disabled) || !disabled.every((x) => typeof x === 'string' && x && x.length <= MAX_ID))) throw badRequest('disabled must be an array of rule ids');
    if (severity !== undefined && (severity === null || typeof severity !== 'object' || Array.isArray(severity) || Object.keys(severity).some((k) => !k || k.length > MAX_ID))) throw badRequest('severity must be an object of rule id to severity');
    try { return overrides.set(project, { disabled, severity }); } catch (e) {
      if (/must be|not allowed|required/.test(e.message)) throw badRequest(e.message);
      throw e;
    }
  }

  return { installed, setOverrides };
}

module.exports = { createRulesView };
