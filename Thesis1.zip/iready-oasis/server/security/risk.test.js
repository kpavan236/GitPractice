'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scoreFinding, priorityFor, explain, DEFAULT_WEIGHTS } = require('./risk');
const { createFinding } = require('./finding');

function finding(overrides = {}) {
  const { metadata = {}, ...rest } = overrides;
  return createFinding({
    type: 'SCA',
    category: 'VULNERABLE_DEPENDENCY',
    severity: 'CRITICAL',
    title: 'CVE-2021-44228',
    repository: 'repo-a',
    source: 'VERSION_WATCH',
    metadata,
    ...rest,
  });
}

const PROD = { criticality: 'CRITICAL', environment: 'production', internetFacing: true, sensitiveData: true };
const DEV = { criticality: 'LOW', environment: 'development', internetFacing: false, sensitiveData: false };

test('context outranks severity', () => {
  // The central claim of the risk engine: a HIGH on an internet-facing
  // production service matters more than a CRITICAL in a scratch tool. A queue
  // sorted by CVSS gets this backwards.
  const criticalInDev = scoreFinding(finding({ severity: 'CRITICAL' }), DEV);
  const highInProd = scoreFinding(finding({ severity: 'HIGH' }), PROD);
  assert.ok(highInProd.score > criticalInDev.score, `${highInProd.score} should exceed ${criticalInDev.score}`);
});

test('every point is attributable to a named factor', () => {
  const risk = scoreFinding(finding(), PROD);
  const summed = risk.factors.reduce((s, f) => s + f.points, 0);
  assert.equal(Math.round(summed), risk.score);
  assert.deepEqual(
    risk.factors.map(f => f.key).sort(),
    ['assetCriticality', 'dataSensitivity', 'environment', 'exploit', 'exposure', 'reachability', 'severity']
  );
});

test('an unknown factor scores nothing and says it is unknown', () => {
  // Reachability analysis does not exist yet. Dressing that up as
  // "not reachable" would be a claim we cannot support.
  const risk = scoreFinding(finding(), {});
  const reachability = risk.factors.find(f => f.key === 'reachability');
  assert.equal(reachability.known, false);
  assert.equal(reachability.points, 0);
  assert.match(reachability.value, /Unknown/);
});

test('confidence reflects how much of the model had data', () => {
  const blind = scoreFinding(finding(), {});
  const informed = scoreFinding(finding({ metadata: { reachability: 'REACHABLE', knownExploited: true } }), PROD);
  assert.ok(informed.confidence > blind.confidence);
  assert.equal(informed.confidence, 100);
});

test('proven reachability scores more than assumed reachability', () => {
  const reachable = scoreFinding(finding({ metadata: { reachability: 'REACHABLE' } }), PROD);
  const likely = scoreFinding(finding({ metadata: { reachability: 'LIKELY_REACHABLE' } }), PROD);
  const not = scoreFinding(finding({ metadata: { reachability: 'NOT_REACHABLE' } }), PROD);
  assert.ok(reachable.score > likely.score);
  assert.ok(likely.score > not.score);
});

test('proven unreachable is not the same as unknown', () => {
  // Both score zero points for reachability, but only one of them is a fact,
  // and confidence is what tells them apart.
  const unknown = scoreFinding(finding(), PROD);
  const notReachable = scoreFinding(finding({ metadata: { reachability: 'NOT_REACHABLE' } }), PROD);
  assert.equal(unknown.score, notReachable.score);
  assert.ok(notReachable.confidence > unknown.confidence);
});

test('EPSS is scaled for its skew rather than used raw', () => {
  // The median CVE scores under 0.001 and 0.1 is already roughly the top 2%, so
  // the raw probability would round almost every real signal to nothing. The
  // curve is sqrt: 0.01 → 0.10 of the weight, 0.9 → 0.95.
  const low = scoreFinding(finding({ metadata: { epss: 0.01 } }), PROD);
  const mid = scoreFinding(finding({ metadata: { epss: 0.1 } }), PROD);
  const high = scoreFinding(finding({ metadata: { epss: 0.9 } }), PROD);

  assert.ok(high.score > mid.score && mid.score > low.score);
  assert.equal(low.factors.find(f => f.key === 'exploit').points, 2); // 0.1 × 20
  assert.ok(high.factors.find(f => f.key === 'exploit').points > 18);
});

test('a KEV listing outranks even a high EPSS score', () => {
  const epss = scoreFinding(finding({ metadata: { epss: 0.9 } }), PROD);
  const kev = scoreFinding(finding({ metadata: { knownExploited: true } }), PROD);
  assert.ok(kev.score >= epss.score);
  assert.match(kev.factors.find(f => f.key === 'exploit').value, /CISA KEV/);
});

test('ransomware use is called out in the factor label', () => {
  const risk = scoreFinding(finding({ metadata: { knownExploited: true, kev: { ransomware: true } } }), PROD);
  assert.match(risk.factors.find(f => f.key === 'exploit').value, /ransomware/);
});

test('the EPSS percentile is shown alongside the probability', () => {
  const risk = scoreFinding(finding({ metadata: { epss: 0.42, epssPercentile: 0.97 } }), PROD);
  assert.match(risk.factors.find(f => f.key === 'exploit').value, /EPSS 0\.420 \(97th pct\)/);
});

test('a known-exploited vulnerability takes the full exploit weight', () => {
  const risk = scoreFinding(finding({ metadata: { knownExploited: true } }), PROD);
  assert.equal(risk.factors.find(f => f.key === 'exploit').points, DEFAULT_WEIGHTS.exploit);
});

test('an exposed credential scores as exploitable without needing a CVE', () => {
  // A committed secret is not a potential problem; it is in the history and
  // must be rotated whatever else is true.
  const risk = scoreFinding(
    createFinding({ type: 'SECRET', category: 'AWS_KEY', severity: 'CRITICAL', title: 'AWS key', repository: 'r', source: 'BUILTIN_SECRETS', metadata: { secretHash: 'x' } }),
    PROD
  );
  const exploit = risk.factors.find(f => f.key === 'exploit');
  assert.equal(exploit.known, true);
  assert.ok(exploit.points > 0);
});

test('a verified live credential outranks an unverified one', () => {
  const base = { type: 'SECRET', category: 'AWS_KEY', severity: 'CRITICAL', title: 'k', repository: 'r', source: 'BUILTIN_SECRETS' };
  const unverified = scoreFinding(createFinding({ ...base, metadata: { verified: false } }), PROD);
  const verified = scoreFinding(createFinding({ ...base, metadata: { verified: true } }), PROD);
  assert.ok(verified.score > unverified.score);
});

test('weights are configurable', () => {
  // The spec requires the formula to be tunable rather than baked in.
  const standard = scoreFinding(finding(), PROD);
  const exposureHeavy = scoreFinding(finding(), PROD, { exposure: 50 });
  assert.ok(exposureHeavy.score > standard.score);
});

test('priority bands follow the score', () => {
  assert.equal(priorityFor(95), 'P0');
  assert.equal(priorityFor(85), 'P0');
  assert.equal(priorityFor(70), 'P1');
  assert.equal(priorityFor(50), 'P2');
  assert.equal(priorityFor(30), 'P3');
  assert.equal(priorityFor(0), 'P4');
});

test('a fully contextualised critical finding lands in P0', () => {
  const risk = scoreFinding(
    finding({ severity: 'CRITICAL', metadata: { knownExploited: true, reachability: 'REACHABLE', cvss: 9.8 } }),
    PROD
  );
  assert.equal(risk.priority, 'P0');
  assert.ok(risk.score >= 85);
});

test('the same finding in a dev-only repository is not urgent', () => {
  const risk = scoreFinding(finding({ severity: 'CRITICAL', metadata: { reachability: 'NOT_REACHABLE' } }), DEV);
  assert.ok(['P3', 'P4'].includes(risk.priority), `expected low priority, got ${risk.priority}`);
});

test('the one-line explanation names the contributing factors', () => {
  const text = explain(scoreFinding(finding({ metadata: { knownExploited: true } }), PROD));
  assert.match(text, /\d+\/100/);
  assert.match(text, /Severity/);
  assert.match(text, /Known exploited/);
});

test('the explanation says how many factors were unknown', () => {
  assert.match(explain(scoreFinding(finding(), {})), /factors unknown/);
});