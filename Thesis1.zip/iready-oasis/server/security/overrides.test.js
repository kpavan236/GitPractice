'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createOverrides } = require('./overrides');

const tmp = (t) => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-overrides-'));
  t.after(() => fs.rmSync(d, { recursive: true, force: true }));
  return path.join(d, 'nested', 'overrides.json');
};
const rules = [
  { id: 'go-insecure-skip-verify', severity: 'HIGH', language: 'go' },
  { id: 'go-other', severity: 'LOW', language: 'go' },
];

test('a project with no overrides gets the empty shape and rules come back unchanged', (t) => {
  const o = createOverrides({ file: tmp(t) });
  assert.deepEqual(o.get('org/a'), { disabled: [], severity: {} });
  assert.deepEqual(o.apply(rules, 'org/a'), rules);
});

test('disabling a rule removes it; a severity override changes severity without touching the input', (t) => {
  const o = createOverrides({ file: tmp(t) });
  o.set('org/a', { disabled: ['go-insecure-skip-verify'], severity: { 'go-other': 'CRITICAL' } });
  const out = o.apply(rules, 'org/a');
  assert.deepEqual(out.map((r) => [r.id, r.severity]), [['go-other', 'CRITICAL']]);
  assert.equal(rules[1].severity, 'LOW');
  assert.deepEqual(o.apply(rules, 'org/b').map((r) => r.id), ['go-insecure-skip-verify', 'go-other']);
});

test('overrides persist to the file and survive a new instance', (t) => {
  const file = tmp(t);
  createOverrides({ file }).set('org/a', { disabled: ['x'] });
  assert.deepEqual(createOverrides({ file }).get('org/a'), { disabled: ['x'], severity: {} });
});

test('set merges per key: a patch with only severity leaves disabled alone', (t) => {
  const o = createOverrides({ file: tmp(t) });
  o.set('p', { disabled: ['a'] });
  o.set('p', { severity: { b: 'LOW' } });
  assert.deepEqual(o.get('p'), { disabled: ['a'], severity: { b: 'LOW' } });
  o.set('p', { disabled: [] });
  assert.deepEqual(o.get('p'), { disabled: [], severity: { b: 'LOW' } });
});

test('unknown rule ids are kept and ignored by apply', (t) => {
  const o = createOverrides({ file: tmp(t) });
  o.set('p', { disabled: ['no-such-rule'], severity: { 'also-missing': 'LOW' } });
  assert.deepEqual(o.get('p').disabled, ['no-such-rule']);
  assert.equal(o.apply(rules, 'p').length, 2);
});

test('an invalid severity is refused and nothing is written', (t) => {
  const file = tmp(t);
  const o = createOverrides({ file });
  assert.throws(() => o.set('p', { severity: { a: 'SEVERE' } }), /severity/i);
  assert.throws(() => o.set('p', { disabled: 'a' }), /disabled/i);
  assert.equal(fs.existsSync(file), false);
});

test('a damaged file reads as no overrides rather than failing a scan', (t) => {
  const file = tmp(t);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, '{not json');
  const o = createOverrides({ file });
  assert.deepEqual(o.get('p'), { disabled: [], severity: {} });
  o.set('p', { disabled: ['a'] });
  assert.deepEqual(createOverrides({ file }).get('p').disabled, ['a']);
});

test('the returned object is a copy: mutating it does not change the stored overrides', (t) => {
  const o = createOverrides({ file: tmp(t) });
  o.set('p', { disabled: ['a'] });
  o.get('p').disabled.push('b');
  assert.deepEqual(o.get('p').disabled, ['a']);
});

// ---- fix round 1: never wipe other projects' data ----
test('invalid JSON is moved aside to overrides.json.bak.<timestamp> before any write, so other projects\' data is recoverable', (t) => {
  const file = tmp(t);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, '{"other/proj": {"disabled": ["x"]}  oops');
  const o = createOverrides({ file });
  o.set('p', { disabled: ['a'] });
  const baks = fs.readdirSync(path.dirname(file)).filter((n) => n.startsWith('overrides.json.bak.'));
  assert.equal(baks.length, 1);
  assert.match(fs.readFileSync(path.join(path.dirname(file), baks[0]), 'utf8'), /other\/proj/);
  assert.deepEqual(createOverrides({ file }).get('p').disabled, ['a']);
});

test('a read error other than "missing" (EACCES) throws from set() and leaves the file alone; get() answers empty', (t) => {
  const file = tmp(t);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify({ keep: { disabled: ['x'], severity: {} } }));
  const origRead = fs.readFileSync;
  fs.readFileSync = (p, ...rest) => { if (p === file) throw Object.assign(new Error('EACCES: permission denied'), { code: 'EACCES' }); return origRead(p, ...rest); };
  t.after(() => { fs.readFileSync = origRead; });
  const o = createOverrides({ file });
  assert.deepEqual(o.get('keep'), { disabled: [], severity: {} });
  assert.throws(() => o.set('p', { disabled: ['a'] }), /EACCES/);
  fs.readFileSync = origRead;
  assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')), { keep: { disabled: ['x'], severity: {} } });
});

test('the temp file is removed if the write or rename fails', (t) => {
  const file = tmp(t);
  const o = createOverrides({ file });
  const origRename = fs.renameSync;
  fs.renameSync = () => { throw Object.assign(new Error('EXDEV'), { code: 'EXDEV' }); };
  t.after(() => { fs.renameSync = origRename; });
  assert.throws(() => o.set('p', { disabled: ['a'] }), /EXDEV/);
  fs.renameSync = origRename;
  assert.deepEqual(fs.readdirSync(path.dirname(file)), []);
});

test('severity names inherited from Object.prototype are refused, and so are prototype-polluting project keys', (t) => {
  const file = tmp(t);
  const o = createOverrides({ file });
  for (const bad of ['toString', 'constructor', '__proto__', 'hasOwnProperty']) {
    assert.throws(() => o.set('p', { severity: { a: bad } }), /severity/i, bad);
  }
  for (const key of ['__proto__', 'constructor', 'prototype']) {
    assert.throws(() => o.set(key, { disabled: ['a'] }), /projectKey/i, key);
  }
  assert.equal(fs.existsSync(file), false);
  assert.deepEqual(o.get('__proto__'), { disabled: [], severity: {} });
});

test('a stored severity that is an inherited name is dropped on read', (t) => {
  const file = tmp(t);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify({ p: { disabled: [], severity: { a: 'toString', b: 'LOW' } } }));
  assert.deepEqual(createOverrides({ file }).get('p').severity, { b: 'LOW' });
});
