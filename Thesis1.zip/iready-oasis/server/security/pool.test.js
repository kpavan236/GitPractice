'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { createPool } = require('./pool');

// Scanning runs in the same process and on the same event loop as the HTTP
// server, with synchronous reads and synchronous regex work. For the ~4 seconds
// a repository takes, the server cannot answer anything — so the progress bar
// the user is watching to see how the scan is going is frozen BY the scan.
//
// worker_threads is in Node already, so this costs no dependency. These tests
// are about the pool being a thing you can trust with a long job: it must not
// lose work, leak threads, or take the process down with a bad task.

const ECHO = path.join(__dirname, '__fixtures__', 'echo-worker.js');

test('runs a task in another thread and returns its result', async () => {
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    assert.deepEqual(await pool.run({ echo: 'hello' }), { echoed: 'hello' });
  } finally {
    await pool.destroy();
  }
});

test('the caller\'s thread stays responsive while a task runs', async () => {
  // The entire point. A blocking task must not stop the event loop that is
  // serving the dashboard.
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    let ticks = 0;
    const timer = setInterval(() => { ticks++; }, 10);
    await pool.run({ blockMs: 300 });
    clearInterval(timer);

    assert.ok(ticks > 5, `event loop ticked only ${ticks} times — it was blocked`);
  } finally {
    await pool.destroy();
  }
});

test('work actually overlaps across workers', async () => {
  const pool = createPool({ size: 4, workerPath: ECHO });
  try {
    const started = Date.now();
    await Promise.all([1, 2, 3, 4].map(() => pool.run({ blockMs: 250 })));
    const elapsed = Date.now() - started;

    // Four 250ms tasks on four threads: well under the 1000ms a sequential run
    // would take. Generous, because CI machines are not quiet.
    assert.ok(elapsed < 700, `took ${elapsed}ms — tasks did not run in parallel`);
  } finally {
    await pool.destroy();
  }
});

test('more tasks than workers all complete', async () => {
  // 250 repositories through 4 threads: the queue is the normal case, not the
  // exception.
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    const results = await Promise.all(
      Array.from({ length: 12 }, (_, i) => pool.run({ echo: `task-${i}` }))
    );
    assert.deepEqual(results.map(r => r.echoed).sort(),
      Array.from({ length: 12 }, (_, i) => `task-${i}`).sort());
  } finally {
    await pool.destroy();
  }
});

test('a task that throws rejects only that task', async () => {
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    await assert.rejects(() => pool.run({ fail: 'deliberate' }), /deliberate/);
    // The pool is still usable — one bad repository must not end a 250-repo run.
    assert.deepEqual(await pool.run({ echo: 'still here' }), { echoed: 'still here' });
  } finally {
    await pool.destroy();
  }
});

test('a worker that dies mid-task rejects rather than hanging forever', async () => {
  // A scanner that runs out of memory kills its thread. Without this the scan
  // would sit at "RUNNING" until someone restarted the app.
  const pool = createPool({ size: 1, workerPath: ECHO });
  try {
    await assert.rejects(() => pool.run({ crash: true }), /worker/i);
    // And the pool replaces it, so the run continues.
    assert.deepEqual(await pool.run({ echo: 'recovered' }), { echoed: 'recovered' });
  } finally {
    await pool.destroy();
  }
});

test('a task can report progress while it runs', async () => {
  // Without this the work that takes the longest is the work nothing can be said
  // about: it happens on another thread, and a pool that only speaks at the end
  // leaves the dashboard with a repository name and a frozen bar.
  const pool = createPool({ size: 1, workerPath: ECHO });
  try {
    const seen = [];
    const result = await pool.run({ echo: 'done', report: 3 }, { onProgress: p => seen.push(p.step) });

    assert.deepEqual(seen, [0, 1, 2]);
    assert.deepEqual(result, { echoed: 'done' }, 'progress must not be mistaken for the answer');
  } finally {
    await pool.destroy();
  }
});

test('progress from a task nobody is watching is harmless', async () => {
  const pool = createPool({ size: 1, workerPath: ECHO });
  try {
    assert.deepEqual(await pool.run({ echo: 'quiet', report: 2 }), { echoed: 'quiet' });
  } finally {
    await pool.destroy();
  }
});

test('destroy stops every thread', async () => {
  // An Electron app that leaves worker threads running does not quit, and the
  // user gets a dock icon that will not go away.
  const pool = createPool({ size: 3, workerPath: ECHO });
  await pool.run({ echo: 'x' });
  await pool.destroy();

  assert.equal(pool.size(), 0, 'no threads left running');
  await assert.rejects(() => pool.run({ echo: 'after' }), /destroyed/i);
});

test('threads are reused, not spawned per task', async () => {
  // Each worker loads the rule bundle and the tree-sitter grammars. Paying that
  // per repository would cost more than the parallelism saves.
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    const ids = [];
    for (let i = 0; i < 6; i++) ids.push((await pool.run({ whoami: true })).threadId);
    assert.ok(new Set(ids).size <= 2, `saw ${new Set(ids).size} threads for a pool of 2`);
  } finally {
    await pool.destroy();
  }
});

test('the pool never grows past its size', async () => {
  const pool = createPool({ size: 2, workerPath: ECHO });
  try {
    const inFlight = Array.from({ length: 8 }, () => pool.run({ blockMs: 50 }));
    assert.ok(pool.size() <= 2, `pool grew to ${pool.size()}`);
    await Promise.all(inFlight);
  } finally {
    await pool.destroy();
  }
});

// These two are run in a CHILD PROCESS on purpose. The property is "does Node
// exit", which cannot be asserted from inside the process being asked, and
// Worker exposes no hasRef() to inspect instead.

function runScript(body, timeoutMs = 8000) {
  const { execFileSync } = require('child_process');
  const started = Date.now();
  const out = execFileSync(process.execPath, ['-e', body], {
    cwd: __dirname, timeout: timeoutMs, encoding: 'utf8',
  });
  return { out: out.trim(), ms: Date.now() - started };
}

test('workerData passed to createPool is visible inside the worker', async () => {
  // Each worker's module scope is separate from the main thread's, so anything
  // a worker needs to know at startup — like where to look for user rule packs
  // — has to arrive as workerData rather than through a shared module variable.
  const pool = createPool({ size: 1, workerPath: ECHO, workerData: { userRulesDir: '/tmp/example-rules' } });
  try {
    const result = await pool.run({ readWorkerData: true });
    assert.deepEqual(result.workerData, { userRulesDir: '/tmp/example-rules' });
  } finally {
    await pool.destroy();
  }
});

test('idle threads do not keep the process alive', () => {
  // The Express server runs inside the Electron main process, so a pool that
  // stays referenced after a scan is an app that will not quit: the user closes
  // the window and the dock icon refuses to go away. This script never calls
  // destroy() — if idle threads held the loop open it would hang until the
  // timeout killed it.
  const { out } = runScript(`
    const { createPool } = require('./pool');
    const pool = createPool({ size: 2, workerPath: './__fixtures__/echo-worker.js' });
    pool.run({ echo: 'done' }).then(r => console.log(r.echoed));
  `);
  assert.equal(out, 'done', 'the task finished and the process then exited on its own');
});

test('a task in flight does keep the process alive', () => {
  // The other half. Unref'ing unconditionally would let the process exit
  // mid-scan and silently lose the run — the task below takes 400ms and
  // nothing else is holding the loop open.
  const { out, ms } = runScript(`
    const { createPool } = require('./pool');
    const pool = createPool({ size: 1, workerPath: './__fixtures__/echo-worker.js' });
    pool.run({ blockMs: 400 }).then(() => console.log('finished'));
  `);
  assert.equal(out, 'finished', 'the process exited before its task completed');
  assert.ok(ms >= 400, `returned in ${ms}ms — the task cannot have run`);
});
