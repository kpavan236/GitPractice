'use strict';
const path = require('path');
const { createLocalFindingsStore } = require('./local');
const { createRemoteFindingsStore } = require('./remote');
const { createOutbox } = require('./outbox');

// Where findings live: in the scanner's own store on this machine, by default. Only a caller that hands in a
// rule-server sync (the legacy OASIS_ENGINE=bundled wiring) gets the remote store, with the outbox protecting
// scans from outages; `remote: false` forces the local store even then. No environment variable is consulted:
// findings never leave the machine because a rules URL happens to be configured.
function createFindingsStore({ ruleSync, store, dir, log, remote = true }) {
  if (remote && ruleSync && ruleSync.client && typeof ruleSync.buildAnalysisPayload === 'function') {
    return createRemoteFindingsStore({
      client: ruleSync.client,
      outbox: createOutbox({ dir: path.join(dir, 'outbox') }),
      buildPayload: ruleSync.buildAnalysisPayload,
      log,
    });
  }
  return createLocalFindingsStore({ store, dir });
}

module.exports = { createFindingsStore, createLocalFindingsStore, createRemoteFindingsStore, createOutbox };
