'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const store = require('../store');
const { createLocalFindingsStore } = require('./local');

const make = t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-local-fs-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  return createLocalFindingsStore({ store, dir });
};
const f = (fp, repo, extra = {}) => ({ fingerprint: fp, id: `F-${fp}`, repository: repo, type: 'SAST', severity: 'HIGH', status: 'OPEN', ...extra });
const covered = { coveredTypes: ['SAST'] };

test('merge keeps findings between scans with the scanner\'s own rules, and finishScan records one trend point', async (t) => {
  const s = make(t);
  await s.merge('a', [f('1', 'a'), f('2', 'a')], { ...covered, now: 100 });
  await s.finishScan({ now: 100 });
  await s.merge('a', [f('1', 'a')], { ...covered, now: 200 });
  await s.finishScan({ now: 200 });
  const all = await s.all();
  assert.deepEqual(all.map(x => [x.fingerprint, x.status]).sort(), [['1', 'OPEN'], ['2', 'RESOLVED']]);
  const h = await s.history();
  assert.deepEqual(h.map(p => [p.at, p.total]), [[100, 2], [200, 1]]);
  assert.equal(s.mode, 'local');
});

test('update patches by id and returns the finding, or null for an unknown id', async (t) => {
  const s = make(t);
  await s.merge('a', [f('1', 'a')], { ...covered, now: 1 });
  const updated = await s.update('F-1', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  assert.equal(updated.status, 'SUPPRESSED');
  assert.equal(await s.update('nope', { status: 'OPEN' }), null);
  assert.equal((await s.get('F-1')).suppression.reason, 'r');
  assert.equal(await s.get('nope'), null);
});

test('baseline can be set from active findings and cleared', async (t) => {
  const s = make(t);
  await s.merge('a', [f('1', 'a'), f('2', 'a')], { ...covered, now: 1 });
  await s.update('F-2', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  assert.equal(await s.baseline(), null);
  const b = await s.setBaseline(5);
  assert.deepEqual(b.fingerprints, ['1']);
  assert.equal((await s.baseline()).createdAt, 5);
  await s.clearBaseline();
  assert.equal(await s.baseline(), null);
});

test('preview, clear (keeping triage) and reset', async (t) => {
  const s = make(t);
  await s.merge('a', [f('1', 'a'), f('2', 'a')], { ...covered, now: 1 });
  await s.merge('b', [f('3', 'b')], { ...covered, now: 1 });
  await s.update('F-2', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  await s.finishScan({ now: 1 });
  assert.deepEqual(await s.preview({ repository: null }), { repository: null, findings: 3, suppressed: 1, history: 1, repositories: 2 });
  assert.equal((await s.preview({ repository: 'a' })).findings, 2);
  const cleared = await s.clear({ repository: 'a', keepSuppressed: true });
  assert.deepEqual([cleared.findings, cleared.keptSuppressed], [1, 1]);
  assert.deepEqual((await s.all()).map(x => x.id).sort(), ['F-2', 'F-3']);
  await s.reset();
  assert.deepEqual([(await s.all()).length, (await s.history()).length, await s.baseline()], [0, 0, null]);
});

test('setRisk changes only risk', async (t) => {
  const s = make(t);
  await s.merge('a', [f('1', 'a')], { ...covered, now: 1 });
  await s.update('F-1', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  assert.equal(await s.setRisk([{ id: 'F-1', risk: { score: 42 } }, { id: 'nope', risk: { score: 1 } }]), 1);
  const x = await s.get('F-1');
  assert.deepEqual([x.risk.score, x.status], [42, 'SUPPRESSED']);
});

test('with OASIS_RULE_SERVER_URL set and no ruleSync, createFindingsStore is the local store', (t) => {
  const prev = process.env.OASIS_RULE_SERVER_URL;
  process.env.OASIS_RULE_SERVER_URL = 'https://rules.example.test';
  t.after(() => { if (prev === undefined) delete process.env.OASIS_RULE_SERVER_URL; else process.env.OASIS_RULE_SERVER_URL = prev; });
  const { createFindingsStore } = require('./index');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-local-fs-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const s = createFindingsStore({ store, dir, log: () => {} });
  assert.equal(s.mode, 'local');
  assert.ok(!fs.existsSync(path.join(dir, 'outbox')), 'no outbox means no remote store');
});
