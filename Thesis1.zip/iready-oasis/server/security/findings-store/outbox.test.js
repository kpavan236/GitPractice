'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createOutbox } = require('./outbox');

const tmp = t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-outbox-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  return dir;
};
const unreachable = () => Object.assign(new Error('down'), { code: 'UNREACHABLE' });
const refused = (status, message = 'no') => Object.assign(new Error(message), { code: 'HTTP', status });

test('put survives a restart and list returns payloads in the order they were queued', (t) => {
  const dir = tmp(t);
  const a = createOutbox({ dir });
  a.put('SCAN-1:org/a', { n: 1 });
  a.put('SCAN-1:org/b', { n: 2 });
  a.put('SCAN-2:org/a', { n: 3 });
  const b = createOutbox({ dir });
  assert.deepEqual(b.list().map(e => [e.id, e.payload.n]), [['SCAN-1:org/a', 1], ['SCAN-1:org/b', 2], ['SCAN-2:org/a', 3]]);
});

test('ids that differ only in punctuation do not collide on disk', (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('a/b', { n: 1 });
  o.put('a_b', { n: 2 });
  assert.equal(o.list().length, 2);
});

test('remove deletes the entry; putting the same id again replaces it', (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('x', { n: 1 });
  o.put('x', { n: 2 });
  assert.deepEqual(o.list().map(e => e.payload.n), [2]);
  o.remove('x');
  assert.deepEqual(o.list(), []);
});

test('flush delivers in order, removes what the server accepted or already had (409)', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('1', { n: 1 }); o.put('2', { n: 2 }); o.put('3', { n: 3 });
  const seen = [];
  const result = await o.flush(async p => { seen.push(p.n); if (p.n === 2) throw refused(409, 'already recorded'); });
  assert.deepEqual(seen, [1, 2, 3]);
  assert.deepEqual([result.delivered, result.remaining], [3, 0]);
  assert.deepEqual(o.list(), []);
});

test('flush stops at the first unreachable and keeps everything not yet delivered', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('1', { n: 1 }); o.put('2', { n: 2 }); o.put('3', { n: 3 });
  const result = await o.flush(async p => { if (p.n >= 2) throw unreachable(); });
  assert.deepEqual([result.delivered, result.remaining], [1, 2]);
  assert.deepEqual(o.list().map(e => e.id), ['2', '3']);
});

test('a corrupt file is quarantined and reported, and does not block the rest', async (t) => {
  const dir = tmp(t);
  const o = createOutbox({ dir });
  o.put('ok', { n: 1 });
  fs.writeFileSync(path.join(dir, 'zzz-garbage.json'), '{nope');
  const r = await o.flush(async () => {});
  assert.deepEqual([r.delivered, r.rejected], [1, 1]);
  assert.equal(fs.readdirSync(path.join(dir, 'rejected')).length, 1);
});

test('concurrent flushes do not deliver the same payload twice', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('1', { n: 1 });
  let posts = 0;
  const slow = async () => { posts += 1; await new Promise(r => setTimeout(r, 30)); };
  await Promise.all([o.flush(slow), o.flush(slow)]);
  assert.equal(posts, 1);
});

test('auth and overload answers (401, 403, 408, 413, 429) stop the flush and never count against a payload', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('a', { n: 1 }); o.put('b', { n: 2 }); o.put('c', { n: 3 });
  for (const status of [401, 403, 408, 413, 429]) {
    for (let i = 0; i < 5; i++) {
      const r = await o.flush(async () => { throw refused(status, 'nope'); });
      assert.deepEqual([r.delivered, r.remaining, r.rejected], [0, 3, 0], `status ${status}`);
      assert.deepEqual(r.blocked, { status, message: 'nope' });
    }
  }
  assert.deepEqual(o.list().map(e => e.id), ['a', 'b', 'c'], 'everything is still queued, in order');
  assert.equal(o.stats().rejected, 0);
  const ok = await o.flush(async () => {});
  assert.deepEqual([ok.delivered, ok.remaining, ok.blocked], [3, 0, null]);
});

test('a payload the server calls malformed (400, 404, 410, 422) is quarantined at once, with the reason', async (t) => {
  const dir = tmp(t);
  const o = createOutbox({ dir });
  o.put('bad', { n: 1 });
  o.put('good', { n: 2 });
  const r = await o.flush(async p => { if (p.n === 1) throw refused(422, 'bad payload'); });
  assert.deepEqual([r.delivered, r.remaining, r.rejected], [1, 0, 1]);
  assert.deepEqual(o.stats(), { queued: 0, rejected: 1 });
  const file = fs.readdirSync(path.join(dir, 'rejected'))[0];
  assert.match(fs.readFileSync(path.join(dir, 'rejected', file), 'utf8'), /bad payload/);
});

test('any other refusal is retried, and quarantined only after three separate flushes', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('odd', { n: 1 });
  for (let i = 1; i <= 2; i++) assert.equal((await o.flush(async () => { throw refused(418, 'teapot'); })).remaining, 1, `flush ${i}`);
  const third = await o.flush(async () => { throw refused(418, 'teapot'); });
  assert.deepEqual([third.remaining, third.rejected], [0, 1]);
});

test('a quarantined payload can be put back in the queue and delivered', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('bad', { n: 1 });
  await o.flush(async () => { throw refused(422, 'bad payload'); });
  assert.deepEqual(o.stats(), { queued: 0, rejected: 1 });
  assert.equal(o.requeueRejected(), 1);
  assert.deepEqual(o.stats(), { queued: 1, rejected: 0 });
  const r = await o.flush(async () => {});
  assert.equal(r.delivered, 1);
});

test('a payload queued while a flush is running is delivered by the flush that was started after it', async (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('1', { n: 1 });
  const posted = [];
  const slow = async p => { posted.push(p.n); await new Promise(r => setTimeout(r, 40)); };
  const first = o.flush(slow);
  await new Promise(r => setTimeout(r, 10));
  o.put('2', { n: 2 });           // arrives after the first flush has already listed the queue
  const second = o.flush(slow);
  await Promise.all([first, second]);
  assert.deepEqual(posted, [1, 2]);
  assert.deepEqual(o.list(), []);
});

test('purge removes queued payloads that match, and only those', (t) => {
  const o = createOutbox({ dir: tmp(t) });
  o.put('a', { projectKey: 'org/a' }); o.put('b', { projectKey: 'org/b' }); o.put('c', { projectKey: 'org/a' });
  assert.equal(o.purge(p => p.projectKey === 'org/a'), 2);
  assert.deepEqual(o.list().map(e => e.id), ['b']);
  assert.equal(o.purge(() => true), 1);
  assert.deepEqual(o.list(), []);
});
