'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const store = require('../store');
const { createOrchestrator } = require('../orchestrator');
const { scanner: patternScanner } = require('../scanners/pattern-sast');
const { scoreFinding } = require('../risk');

// The orchestrator keeps scans, repository assets and SBOMs; findings, history and
// the baseline belong to the findings store. These tests pin that split with a
// store that records what it is asked.

const tmpdir = prefix => fs.mkdtempSync(path.join(os.tmpdir(), prefix));
const markerSet = marker => ({
  version: 'default@1', source: 'rule-server', fetchedAt: '2026-10-01T00:00:00.000Z',
  rules: [{ id: `rs-${marker}`, language: 'text', severity: 'LOW', pattern: marker, files: ['**/*.txt'], title: marker, category: 'TEST' }],
});

function fakeStore(mergeResult = () => ({ ok: true, analysisId: 'x', serverGate: { status: 'PASSED' }, gateSource: 'default' })) {
  const calls = [];
  const mem = { findings: [], history: [], baseline: null };
  return {
    mode: 'remote', calls, mem,
    all: async () => { calls.push(['all']); return mem.findings; },
    get: async id => mem.findings.find(f => f.id === id) || null,
    history: async () => mem.history,
    baseline: async () => mem.baseline,
    merge: async (repository, findings, ctx) => {
      calls.push(['merge', repository, findings.length, ctx]);
      mem.findings = [...mem.findings.filter(f => f.repository !== repository), ...findings];
      return mergeResult(repository, ctx);
    },
    finishScan: async ctx => { calls.push(['finishScan', ctx]); },
    update: async (id, patch) => { calls.push(['update', id, patch]); const f = mem.findings.find(x => x.id === id); if (!f) return null; Object.assign(f, patch); return f; },
    setBaseline: async () => { calls.push(['setBaseline']); mem.baseline = { createdAt: 1, fingerprints: mem.findings.map(f => f.fingerprint) }; return mem.baseline; },
    clearBaseline: async () => { calls.push(['clearBaseline']); mem.baseline = null; },
    preview: async ({ repository }) => { calls.push(['preview', repository]); const s = repository ? mem.findings.filter(f => f.repository === repository) : mem.findings; return { repository: repository || null, findings: s.length, suppressed: 0, history: mem.history.length, repositories: 1 }; },
    clear: async opts => { calls.push(['clear', opts]); return { findings: 0, keptSuppressed: 0 }; },
    reset: async () => { calls.push(['reset']); mem.findings = []; mem.history = []; mem.baseline = null; return { reset: true }; },
    setRisk: async updates => { calls.push(['setRisk', updates]); for (const u of updates) { const f = mem.findings.find(x => x.id === u.id); if (f) f.risk = u.risk; } return updates.length; },
  };
}

async function waitForScan(orchestrator, id) {
  for (let i = 0; i < 400; i++) {
    const scan = orchestrator.getScan(id);
    if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(scan.status) && true) return scan;
    await new Promise(r => setTimeout(r, 25));
  }
  throw new Error('scan did not finish in time');
}

function setup(t, findingsStore) {
  const dir = tmpdir('oasis-fsi-');
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const orchestrator = createOrchestrator({ scanners: [patternScanner], dir, userRulesDir: null, userGrammarsDir: null, findingsStore });
  t.after(() => orchestrator.shutdown());
  const repo = name => {
    const p = tmpdir('oasis-fsi-repo-');
    t.after(() => fs.rmSync(p, { recursive: true, force: true }));
    fs.writeFileSync(path.join(p, 'n.txt'), 'MARKER_A\n');
    return { repository: name, repoPath: p, ruleSet: markerSet('MARKER_A') };
  };
  return { dir, orchestrator, repo };
}
const settle = () => new Promise(r => setTimeout(r, 150));

test('a scan is merged per repository through the store, history is closed once, and nothing lands in store.json', async (t) => {
  const fs_ = fakeStore();
  const { dir, orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a'), repo('org/b')] });
  await waitForScan(orchestrator, scan.id);
  await settle();

  const merges = fs_.calls.filter(c => c[0] === 'merge');
  assert.deepEqual(merges.map(c => c[1]).sort(), ['org/a', 'org/b']);
  const ctx = merges.find(c => c[1] === 'org/a')[3];
  assert.ok(Array.isArray(ctx.coveredTypes) && ctx.coveredTypes.length > 0, 'coverage decides what may be resolved');
  assert.equal(ctx.analysis.scan.id, scan.id);
  assert.equal(ctx.analysis.ruleSet.version, 'default@1');
  assert.ok(ctx.analysis.repo.gate, 'the repository result (gate, coverage) travels with the analysis');
  assert.ok(ctx.analysis.scannerVersion && ctx.analysis.analyzerVersion);
  assert.equal(fs_.calls.filter(c => c[0] === 'finishScan').length, 1);
  assert.ok(fs_.calls.findIndex(c => c[0] === 'finishScan') > fs_.calls.map(c => c[0]).lastIndexOf('merge'), 'history is closed after the merges');
  assert.deepEqual(store.load(dir).findings, [], 'findings are not kept locally');
  assert.equal(store.load(dir).scans.length, 1, 'scans still are');
  assert.ok(merges.every(c => c[2] === 1 && fs_.mem.findings.find(f => f.repository === c[1]).id), 'findings leave with ids');
});

test('each repository records the store\'s outcome, and compares gates only when both used the default', async (t) => {
  const outcomes = {
    'org/a': { ok: true, analysisId: 'a', serverGate: { status: 'PASSED' }, gateSource: 'default' },
    'org/b': { ok: true, analysisId: 'b', serverGate: { status: 'PASSED' }, gateSource: 'project' },
    'org/c': { ok: false, pending: true, unreachable: true, error: 'down' },
  };
  const { orchestrator, repo } = setup(t, fakeStore(r => outcomes[r]));
  const scan = await orchestrator.startScan({ targets: [repo('org/a'), repo('org/b'), repo('org/c')] });
  await waitForScan(orchestrator, scan.id);
  await settle();
  const by = Object.fromEntries(orchestrator.getScan(scan.id).perRepository.map(r => [r.repository, r]));
  assert.notEqual(by['org/a'].gate.status, 'PASSED', 'test premise: the local gate disagrees');
  assert.deepEqual(by['org/a'].ruleServer.gateMismatch, { local: by['org/a'].gate.status, server: 'PASSED' });
  assert.match(by['org/b'].ruleServer.gateComparison, /different gates/);
  assert.equal(by['org/b'].ruleServer.gateMismatch, undefined);
  assert.deepEqual([by['org/c'].ruleServer.ok, by['org/c'].ruleServer.pending], [false, true]);
});

test('after three unreachable uploads the rest are only queued, not attempted', async (t) => {
  const fs_ = fakeStore(() => ({ ok: false, pending: true, unreachable: true, error: 'down' }));
  const { orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: ['org/r0', 'org/r1', 'org/r2', 'org/r3', 'org/r4'].map(repo) });
  await waitForScan(orchestrator, scan.id);
  await settle();
  const merges = fs_.calls.filter(c => c[0] === 'merge').sort((a, b) => a[1].localeCompare(b[1]));
  assert.equal(merges.length, 5, 'every repository is still handed to the store, which queues it');
  assert.equal(merges.filter(c => c[3].deferUpload).length, 2);
  assert.ok(merges.filter(c => !c[3].deferUpload).length === 3);
});

test('reads come from the store, filtered and ordered as before', async (t) => {
  const fs_ = fakeStore();
  const { orchestrator } = setup(t, fs_);
  fs_.mem.findings = [
    { id: 'F1', fingerprint: 'a', repository: 'x', type: 'SAST', severity: 'LOW', status: 'OPEN', title: 'Plain', file: 'a.js', risk: { score: 5 } },
    { id: 'F2', fingerprint: 'b', repository: 'y', type: 'SECRET', severity: 'HIGH', status: 'OPEN', title: 'Token', file: 'b.js', risk: { score: 50 } },
    { id: 'F3', fingerprint: 'c', repository: 'x', type: 'SAST', severity: 'LOW', status: 'SUPPRESSED', title: 'Old', file: 'c.js' },
  ];
  fs_.mem.history = [{ at: 1, total: 1, counts: { CRITICAL: 0, HIGH: 0 }, byType: {}, repositories: 1 }, { at: 2, total: 2, counts: { CRITICAL: 0, HIGH: 1 }, byType: {}, repositories: 2 }];
  assert.deepEqual((await orchestrator.listFindings({})).map(f => f.id), ['F2', 'F1']);
  assert.deepEqual((await orchestrator.listFindings({ repository: 'x', status: 'all' })).map(f => f.id).sort(), ['F1', 'F3']);
  assert.deepEqual((await orchestrator.listFindings({ search: 'token' })).map(f => f.id), ['F2']);
  const dash = await orchestrator.dashboard();
  assert.deepEqual([dash.total, dash.suppressed, dash.byType.SECRET], [2, 1, 1]);
  assert.equal(dash.topRisks[0].id, 'F2');
  assert.equal((await orchestrator.trends({ points: 10 })).sinceLastScan.total, 1);
  assert.equal((await orchestrator.getFinding('F2')).title, 'Token');
  assert.equal(await orchestrator.getFinding('nope'), null);
});

test('triage, baseline, clear and reset go to the store; clear also tidies the scanner\'s own scans', async (t) => {
  const fs_ = fakeStore();
  const { dir, orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a')] });
  await waitForScan(orchestrator, scan.id);
  await settle();
  const id = fs_.mem.findings[0].id;

  assert.equal((await orchestrator.updateFinding(id, { status: 'SUPPRESSED', suppression: { reason: 'r' } })).status, 'SUPPRESSED');
  assert.equal(await orchestrator.updateFinding('nope', { status: 'OPEN' }), null);
  await orchestrator.setBaseline();
  assert.ok(fs_.mem.baseline);
  assert.equal((await orchestrator.dashboard()).baseline.count, 1);
  await orchestrator.clearBaseline();
  assert.equal(fs_.mem.baseline, null);

  const preview = await orchestrator.clearPreview({ repository: 'org/a' });
  assert.equal(preview.findings, 1);
  assert.equal(preview.scans, 1, 'the scanner adds its own scan count');
  await orchestrator.clearFindings({ repository: 'org/a' });
  assert.deepEqual(fs_.calls.find(c => c[0] === 'clear')[1], { repository: 'org/a', keepSuppressed: true });
  assert.equal(store.load(dir).scans.length, 0, 'the scan record for a cleared repository goes too');

  await orchestrator.resetSecurity();
  assert.ok(fs_.calls.some(c => c[0] === 'reset'));
});

test('changing a repository\'s asset context re-scores its findings through the store', async (t) => {
  const fs_ = fakeStore();
  const { dir, orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a'), repo('org/b')] });
  await waitForScan(orchestrator, scan.id);
  await settle();
  await orchestrator.setAsset('org/a', { criticality: 'high', exposure: 'internet' });
  const call = fs_.calls.find(c => c[0] === 'setRisk');
  const finding = fs_.mem.findings.find(f => f.repository === 'org/a');
  assert.deepEqual(call[1].map(u => u.id), [finding.id], 'only that repository\'s findings');
  assert.deepEqual(call[1][0].risk, scoreFinding(finding, { criticality: 'high', exposure: 'internet' }));
  assert.equal(store.load(dir).assets['org/a'].criticality, 'high');
});

test('a store that cannot be read fails the read instead of showing an empty list', async (t) => {
  const fs_ = fakeStore();
  fs_.all = async () => { throw Object.assign(new Error('rule server unreachable'), { code: 'UNREACHABLE' }); };
  const { orchestrator } = setup(t, fs_);
  await assert.rejects(orchestrator.listFindings({}), e => e.code === 'UNREACHABLE');
  await assert.rejects(orchestrator.dashboard(), e => e.code === 'UNREACHABLE');
});

test('flushPending delivers whatever the store has queued, and is a no-op for a store without a queue', async (t) => {
  const remote = fakeStore();
  remote.flush = async () => { remote.calls.push(['flush']); return { delivered: 2, remaining: 0, rejected: 0 }; };
  assert.deepEqual(await setup(t, remote).orchestrator.flushPending(), { delivered: 2, remaining: 0, rejected: 0 });
  assert.deepEqual(await setup(t, fakeStore()).orchestrator.flushPending(), { delivered: 0, remaining: 0, rejected: 0 });
});

// ── Review fixes ──────────────────────────────────────────────────────────────

test('a store that fails while merging one repository does not fail the scan or lose its record', async (t) => {
  const fs_ = fakeStore(repo => { if (repo === 'org/b') throw new Error('disk full'); return { ok: true, analysisId: 'x', serverGate: { status: 'PASSED' }, gateSource: 'default' }; });
  const { dir, orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a'), repo('org/b')] });
  await waitForScan(orchestrator, scan.id);
  await settle();
  const done = orchestrator.getScan(scan.id);
  assert.equal(done.status, 'COMPLETED');
  const by = Object.fromEntries(done.perRepository.map(r => [r.repository, r]));
  assert.equal(by['org/a'].ruleServer.ok, true);
  assert.deepEqual([by['org/b'].ruleServer.ok, by['org/b'].ruleServer.failed], [false, true]);
  assert.match(by['org/b'].ruleServer.error, /disk full/);
  assert.equal(store.load(dir).scans.length, 1, 'the scan record is still written');
});

test('a scan is not COMPLETED until its findings have been merged', async (t) => {
  let release;
  const gate = new Promise(r => { release = r; });
  const fs_ = fakeStore();
  const realMerge = fs_.merge;
  fs_.merge = async (...args) => { await gate; return realMerge(...args); };
  const { orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a')] });
  await new Promise(r => setTimeout(r, 400));
  assert.notEqual(orchestrator.getScan(scan.id).status, 'COMPLETED', 'findings are still being merged');
  release();
  await waitForScan(orchestrator, scan.id);
  assert.equal(orchestrator.getScan(scan.id).status, 'COMPLETED');
  assert.equal(fs_.mem.findings.length, 1);
});

test('starting a scan also tries to deliver anything still queued', async (t) => {
  const fs_ = fakeStore();
  fs_.flush = async () => { fs_.calls.push(['flush']); return { delivered: 0, remaining: 0, rejected: 0, blocked: null }; };
  const { orchestrator, repo } = setup(t, fs_);
  const scan = await orchestrator.startScan({ targets: [repo('org/a')] });
  await waitForScan(orchestrator, scan.id);
  assert.ok(fs_.calls.some(c => c[0] === 'flush'));
});

test('reads ask the store to filter, and the repository list does not download findings', async (t) => {
  const fs_ = fakeStore();
  const asked = [];
  fs_.list = async filter => { asked.push(filter); return [{ id: 'F1', repository: 'x', title: 'q one', status: 'OPEN', risk: { score: 1 } }, { id: 'F2', repository: 'x', title: 'q two', status: 'OPEN', risk: { score: 9 } }]; };
  fs_.repositories = async () => [{ repository: 'x', findings: 2, active: 2 }];
  fs_.all = async () => { throw new Error('should not download everything'); };
  const { orchestrator } = setup(t, fs_);
  assert.deepEqual((await orchestrator.listFindings({ repository: 'x', status: 'new', search: 'q' })).map(f => f.id), ['F2', 'F1']);
  assert.deepEqual(asked, [{ repository: 'x', type: null, severity: null, status: 'new', search: 'q' }]);
  assert.deepEqual(await orchestrator.scannedRepositories(), ['x']);
});

test('the queue is visible, and scans the server set aside can be retried', async (t) => {
  const fs_ = fakeStore();
  fs_.outboxStatus = () => ({ queued: 2, rejected: 1, blocked: { status: 401, message: 'UNAUTHORIZED' } });
  fs_.retryRejected = async () => ({ requeued: 1, delivered: 1, remaining: 0, rejected: 0, blocked: null });
  const { orchestrator } = setup(t, fs_);
  assert.deepEqual(orchestrator.outboxStatus(), { queued: 2, rejected: 1, blocked: { status: 401, message: 'UNAUTHORIZED' } });
  assert.equal((await orchestrator.retryRejected()).delivered, 1);
  assert.equal(setup(t, fakeStore()).orchestrator.outboxStatus(), null, 'a store without a queue has nothing to show');
});

test('with a real rule sync, every repository\'s scan is uploaded with its findings, rule set, coverage and scan id', async (t) => {
  const { createRuleSync } = require('../rule-sync/sync');
  const { createRuleSetCache } = require('../rule-sync/cache');
  const posted = [];
  const client = {
    fetchProfile: async () => { throw new Error('rules are supplied on the target here'); },
    postAnalysis: async p => { posted.push(p); return { analysisId: p.analysisId, gate: { status: 'PASSED' }, gateSource: 'default' }; },
    getRule: async () => null,
  };
  const dir = tmpdir('oasis-fsi-sync-');
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const sync = createRuleSync({ client, cache: createRuleSetCache(dir), baseUrl: 'http://rs' });
  // The real factory picks the remote store because the sync exposes a client.
  const { createFindingsStore } = require('./index');
  const findingsStore = createFindingsStore({ ruleSync: sync, store, dir, log: () => {} });
  assert.equal(findingsStore.mode, 'remote');

  const o = createOrchestrator({ scanners: [patternScanner], dir, userRulesDir: null, userGrammarsDir: null, findingsStore });
  t.after(() => o.shutdown());
  const p = tmpdir('oasis-fsi-repo-');
  t.after(() => fs.rmSync(p, { recursive: true, force: true }));
  fs.writeFileSync(path.join(p, 'n.txt'), 'MARKER_A\n');
  const ruleSet = { ...markerSet('MARKER_A'), profile: { id: 'default', name: 'Default', version: 7 } };
  const scan = await o.startScan({ targets: [{ repository: 'org/a', repoPath: p, ruleSet }] });
  for (let i = 0; i < 400; i++) {
    const x = o.getScan(scan.id);
    if (x.status === 'COMPLETED' && x.perRepository.length && x.perRepository.every(r => r.ruleServer)) break;
    await new Promise(r => setTimeout(r, 25));
  }

  assert.equal(posted.length, 1);
  const payload = posted[0];
  assert.equal(payload.analysisId, `${scan.id}:org/a`);
  assert.equal(payload.scanId, scan.id);
  assert.deepEqual(payload.profile, { id: 'default', version: 7 });
  assert.equal(payload.ruleSetVersion, 'default@1');
  assert.ok(payload.coverage.some(c => c.analysed), 'coverage decides what the server may resolve');
  assert.equal(payload.findings.length, 1);
  assert.ok(payload.findings[0].id && payload.findings[0].fingerprint && payload.findings[0].risk, 'findings leave with ids and risk');
  assert.ok(payload.scannerVersion && payload.analyzerVersion);
  assert.equal(o.getScan(scan.id).perRepository[0].ruleServer.ok, true);
});
