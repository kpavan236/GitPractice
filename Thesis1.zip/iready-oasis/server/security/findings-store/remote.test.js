'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createOutbox } = require('./outbox');
const { createRemoteFindingsStore } = require('./remote');

const tmp = t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-remote-fs-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  return dir;
};
const down = () => Object.assign(new Error('rule server unreachable: refused'), { code: 'UNREACHABLE' });
const http = (status, message) => Object.assign(new Error(message), { code: 'HTTP', status });
const buildPayload = ({ repository, scan, findings }) => ({ analysisId: `${scan.id}:${repository}`, projectKey: repository, findings });

function make(t, clientOverrides = {}) {
  const posted = [];
  const client = {
    postAnalysis: async p => { posted.push(p.analysisId); return { analysisId: p.analysisId, gate: { status: 'PASSED' }, gateSource: 'default' }; },
    listFindings: async filter => [{ id: 'F-1', filter }],
    getFinding: async id => ({ id }),
    updateFinding: async (id, body) => ({ id, ...body }),
    history: async points => ({ points: [{ at: 1, total: 2 }], asked: points }),
    getBaseline: async () => null,
    ...clientOverrides,
  };
  const outbox = createOutbox({ dir: path.join(tmp(t), 'outbox') });
  return { store: createRemoteFindingsStore({ client, outbox, buildPayload }), outbox, posted, client };
}
const input = (scanId, repository) => ({ scan: { id: scanId }, repository });

test('a scan is queued, sent, and removed from the outbox once the server has it; the outcome carries the gate', async (t) => {
  const { store, outbox, posted } = make(t);
  const out = await store.merge('org/a', [{ fingerprint: 'x' }], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.deepEqual([out.ok, out.analysisId, out.serverGate.status, out.gateSource], [true, 'S1:org/a', 'PASSED', 'default']);
  assert.deepEqual(posted, ['S1:org/a']);
  assert.deepEqual(outbox.list(), []);
  assert.equal(store.mode, 'remote');
});

test('with the server down the scan is kept in the outbox and reported as pending, not lost and not failed', async (t) => {
  const { store, outbox } = make(t, { postAnalysis: async () => { throw down(); } });
  const out = await store.merge('org/a', [{ fingerprint: 'x' }], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.deepEqual([out.ok, out.pending, out.unreachable], [false, true, true]);
  assert.match(out.error, /unreachable/);
  assert.deepEqual(outbox.list().map(e => e.id), ['S1:org/a']);
});

test('the next scan delivers the earlier ones first, in order', async (t) => {
  let up = false;
  const posted = [];
  const { store, outbox } = make(t, { postAnalysis: async p => { if (!up) throw down(); posted.push(p.analysisId); return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; } });
  await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  await store.merge('org/b', [], { coveredTypes: [], now: 2, analysis: input('S1', 'org/b') });
  assert.equal(outbox.list().length, 2);
  up = true;
  const out = await store.merge('org/a', [], { coveredTypes: [], now: 3, analysis: input('S2', 'org/a') });
  assert.deepEqual(posted, ['S1:org/a', 'S1:org/b', 'S2:org/a']);
  assert.equal(out.ok, true);
  assert.deepEqual(outbox.list(), []);
});

test('flush delivers whatever is waiting, for use at startup', async (t) => {
  let up = false;
  const { store, outbox, client } = make(t);
  client.postAnalysis = async p => { if (!up) throw down(); return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; };
  await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.equal(outbox.list().length, 1);
  assert.deepEqual(await store.flush(), { delivered: 0, remaining: 1, rejected: 0, blocked: null });
  up = true;
  assert.deepEqual(await store.flush(), { delivered: 1, remaining: 0, rejected: 0, blocked: null });
});

test('a scan the server calls malformed is set aside at once and the outcome says so', async (t) => {
  const { store, outbox } = make(t, { postAnalysis: async () => { throw http(400, 'bad payload'); } });
  const out = await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.deepEqual([out.ok, out.rejected], [false, true]);
  assert.match(out.error, /bad payload/);
  assert.equal(outbox.list().length, 0);
  assert.equal(outbox.stats().rejected, 1);
});

test('reads go to the server and fail loudly when it is down', async (t) => {
  const { store } = make(t);
  assert.deepEqual(await store.all(), [{ id: 'F-1', filter: { status: 'all' } }]);
  assert.deepEqual(await store.history(), [{ at: 1, total: 2 }]);
  assert.equal(await store.baseline(), null);
  assert.equal((await store.get('F-9')).id, 'F-9');
  const broken = make(t, { listFindings: async () => { throw down(); } }).store;
  await assert.rejects(broken.all(), e => e.code === 'UNREACHABLE');
});

test('update translates the scanner\'s patch into the server\'s triage call, and an unknown id is null', async (t) => {
  const sent = [];
  const { store } = make(t, { updateFinding: async (id, body) => { sent.push([id, body]); if (id === 'gone') throw http(404, 'nope'); return { id, status: body.status }; } });
  await store.update('F-1', { status: 'SUPPRESSED', suppression: { reason: 'ok', owner: 'al', expiresAt: 9, decidedAt: 1 } });
  await store.update('F-1', { status: 'FALSE_POSITIVE', suppression: { reason: 'fixture' } });
  await store.update('F-1', { status: 'REOPENED', suppression: null });
  assert.deepEqual(sent, [
    ['F-1', { status: 'SUPPRESSED', reason: 'ok', owner: 'al', expiresAt: 9 }],
    ['F-1', { status: 'FALSE_POSITIVE', reason: 'fixture', owner: undefined, expiresAt: undefined }],
    ['F-1', { status: 'REOPENED' }],
  ]);
  assert.equal(await store.update('gone', { status: 'REOPENED', suppression: null }), null);
});

test('finishScan has nothing to do: the server records one trend point per scan itself', async (t) => {
  assert.equal(await make(t).store.finishScan({ now: 1 }), undefined);
});

test('deferUpload queues the scan without contacting the server', async (t) => {
  const { store, outbox, posted } = make(t);
  const out = await store.merge('org/a', [{ fingerprint: 'x' }], { coveredTypes: [], now: 1, deferUpload: true, analysis: input('S1', 'org/a') });
  assert.deepEqual(posted, []);
  assert.deepEqual([out.ok, out.pending, out.unreachable], [false, true, true]);
  assert.match(out.error, /queued/i);
  assert.deepEqual(outbox.list().map(e => e.id), ['S1:org/a']);
});

test('two scans finishing together each get their own outcome, never "waiting behind an earlier upload"', async (t) => {
  const posted = [];
  const { store, outbox } = make(t, { postAnalysis: async p => { posted.push(p.analysisId); await new Promise(r => setTimeout(r, 30)); return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; } });
  const [a, b, c] = await Promise.all([
    store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') }),
    store.merge('org/b', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/b') }),
    store.merge('org/c', [], { coveredTypes: [], now: 1, analysis: input('S2', 'org/c') }),
  ]);
  assert.deepEqual([a.ok, b.ok, c.ok], [true, true, true]);
  assert.deepEqual([a.analysisId, b.analysisId, c.analysisId], ['S1:org/a', 'S1:org/b', 'S2:org/c']);
  assert.deepEqual(posted.sort(), ['S1:org/a', 'S1:org/b', 'S2:org/c']);
  assert.deepEqual(outbox.list(), []);
});

test('an upload the server will not take (401) stays queued, is reported as blocked, and is not counted as an outage', async (t) => {
  const { store, outbox } = make(t, { postAnalysis: async () => { throw http(401, 'UNAUTHORIZED'); } });
  for (const scanId of ['S1', 'S2', 'S3', 'S4']) {
    const out = await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input(scanId, 'org/a') });
    assert.deepEqual([out.ok, out.pending, out.blocked, out.unreachable], [false, true, true, false]);
    assert.match(out.error, /401/);
  }
  assert.equal(outbox.list().length, 4, 'nothing was quarantined by repeated 401s');
  assert.deepEqual(store.outboxStatus(), { queued: 4, rejected: 0, blocked: { status: 401, message: 'UNAUTHORIZED' } });
});

test('outboxStatus shows the queue and clears the blocked note once the server accepts uploads', async (t) => {
  let blocked = true;
  const { store } = make(t, { postAnalysis: async p => { if (blocked) throw http(403, 'forbidden'); return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; } });
  await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.equal(store.outboxStatus().blocked.status, 403);
  blocked = false;
  await store.flush();
  assert.deepEqual(store.outboxStatus(), { queued: 0, rejected: 0, blocked: null });
});

test('clearing a repository or resetting drops what was still queued for it, so old scans cannot flush back in', async (t) => {
  const { store, outbox } = make(t, {
    postAnalysis: async () => { throw down(); },
    clearFindings: async () => ({ findings: 0 }), reset: async () => ({ reset: true }),
  });
  await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  await store.merge('org/b', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/b') });
  await store.clear({ repository: 'org/a', keepSuppressed: true });
  assert.deepEqual(outbox.list().map(e => e.payload.projectKey), ['org/b']);
  await store.reset();
  assert.deepEqual(outbox.list(), []);
});

test('retryRejected puts quarantined scans back and delivers them', async (t) => {
  let bad = true;
  const { store } = make(t, { postAnalysis: async p => { if (bad) throw http(422, 'bad'); return { analysisId: p.analysisId, gate: { status: 'PASSED' } }; } });
  await store.merge('org/a', [], { coveredTypes: [], now: 1, analysis: input('S1', 'org/a') });
  assert.deepEqual(store.outboxStatus(), { queued: 0, rejected: 1, blocked: null });
  bad = false;
  assert.deepEqual(await store.retryRejected(), { requeued: 1, delivered: 1, remaining: 0, rejected: 0, blocked: null });
});

test('filtered reads and the repository list are done by the server', async (t) => {
  const asked = [];
  const { store } = make(t, {
    listFindings: async filter => { asked.push(filter); return []; },
    repositories: async () => [{ repository: 'org/a', findings: 3, active: 2 }],
  });
  await store.list({ repository: 'org/a', status: 'active', search: 'x' });
  assert.deepEqual(asked, [{ repository: 'org/a', status: 'active', search: 'x' }]);
  assert.deepEqual(await store.repositories(), [{ repository: 'org/a', findings: 3, active: 2 }]);
});
