'use strict';

// Findings held by the rule server. Every scan is queued in the outbox first and
// removed only once the server has it, so an outage never costs a finding: the
// scan completes, reports the upload as pending, and the next scan (or a restart)
// delivers it. Reads go straight to the server and fail loudly when it is down,
// rather than showing an empty list that reads as "no findings".

function toServerPatch(patch) {
  const decided = patch.status === 'SUPPRESSED' || patch.status === 'FALSE_POSITIVE';
  if (!decided) return { status: patch.status };
  const s = patch.suppression || {};
  return { status: patch.status, reason: s.reason, owner: s.owner, expiresAt: s.expiresAt };
}

function createRemoteFindingsStore({ client, outbox, buildPayload, log = () => {} }) {
  const notFound = e => e && e.code === 'HTTP' && e.status === 404;

  // Outcomes are kept per analysis for the whole store, not per call: uploads are
  // serialised, so the upload that delivers one scan's payload may be another
  // scan's flush, and each caller must still find its own answer.
  const outcomes = new Map();
  const failures = new Map();
  let lastFailure = null;
  let lastBlocked = null;

  const post = async p => {
    try {
      outcomes.set(p.analysisId, await client.postAnalysis(p));
      failures.delete(p.analysisId);
    } catch (e) {
      failures.set(p.analysisId, e);
      lastFailure = e;
      throw e;
    }
  };

  async function flushNow() {
    const result = await outbox.flush(post);
    lastBlocked = result.blocked;
    return result;
  }

  async function merge(repository, findings, { analysis, deferUpload = false }) {
    const payload = buildPayload({ ...analysis, repository, findings });
    const id = payload.analysisId;
    outbox.put(id, payload);

    // The caller has decided the server is down (three unreachable uploads in a
    // row): keep the scan safe, but do not spend another timeout on it.
    if (deferUpload) {
      return { ok: false, pending: true, unreachable: true, error: 'queued: the rule server was unreachable for the previous uploads' };
    }

    const flushed = await flushNow();

    const accepted = outcomes.get(id);
    if (accepted) {
      outcomes.delete(id);
      return { ok: true, analysisId: accepted.analysisId, serverGate: accepted.gate, gateSource: accepted.gateSource || null };
    }

    const error = failures.get(id);
    if (!outbox.list().some(e => e.id === id)) {
      failures.delete(id);
      // Gone from the queue without an answer: either the server already had it
      // (409) or it refused it as malformed and it was set aside.
      if (error && !(error.code === 'HTTP' && error.status === 409)) {
        return { ok: false, rejected: true, error: `the rule server refused this scan and it was set aside: ${error.message}` };
      }
      return { ok: true, analysisId: id, serverGate: null, gateSource: null, alreadyRecorded: true };
    }

    // Still queued. Say why: the server refused uploads (credentials, size), it was
    // unreachable, or an earlier payload stopped the flush before this one.
    const blocked = (error && error.code === 'HTTP' && flushed.blocked) ? flushed.blocked : flushed.blocked;
    if (blocked) {
      log(`security: ${repository} is queued: the rule server refused uploads (${blocked.status}: ${blocked.message})`);
      return { ok: false, pending: true, blocked: true, unreachable: false, error: `the rule server refused uploads (${blocked.status}: ${blocked.message}); the scan is queued` };
    }
    const reason = (error || lastFailure || {}).message || 'rule server unreachable';
    log(`security: ${repository} is queued for the rule server (${reason})`);
    return { ok: false, pending: true, unreachable: true, error: reason };
  }

  return {
    mode: 'remote',

    // Filters are applied by the server; only what the screen needs travels.
    list: filter => client.listFindings(filter || {}),
    all: () => client.listFindings({ status: 'all' }),
    repositories: () => client.repositories(),
    async get(id) {
      try { return await client.getFinding(id); } catch (e) { if (notFound(e)) return null; throw e; }
    },
    async history() { return (await client.history(400)).points; },
    baseline: () => client.getBaseline(),

    merge,
    flush: flushNow,
    // The server records one trend point per scan itself.
    async finishScan() {},

    // What is waiting, what was set aside, and whether the server is refusing uploads.
    outboxStatus: () => ({ ...outbox.stats(), blocked: lastBlocked }),
    async retryRejected() {
      const requeued = outbox.requeueRejected();
      return { requeued, ...(await flushNow()) };
    },

    async update(id, patch) {
      try { return await client.updateFinding(id, toServerPatch(patch)); } catch (e) { if (notFound(e)) return null; throw e; }
    },

    setBaseline: () => client.setBaseline(),
    clearBaseline: () => client.clearBaseline(),
    preview: ({ repository = null } = {}) => client.clearPreview(repository),
    // Clearing must not let a scan that was still queued flush back in afterwards.
    async clear({ repository = null, keepSuppressed = true } = {}) {
      outbox.purge(p => !repository || p.projectKey === repository);
      return client.clearFindings(repository, keepSuppressed);
    },
    async reset() {
      outbox.purge(() => true);
      return client.reset();
    },
    async setRisk(updates) { return (await client.setRisk(updates)).updated; },
  };
}

module.exports = { createRemoteFindingsStore };
