'use strict';
const { isActive, countBySeverity } = require('../finding');
const { createBaseline } = require('../ignore');

// Findings kept in the scanner's own store.json: what every install did before the
// rule server owned them, and still what an orchestrator without a rule server
// (tests, embedding) uses. The behaviour is the scanner's original, moved here
// behind the same interface as the remote store.

const TRIAGED = f => f.status === 'SUPPRESSED' || f.status === 'FALSE_POSITIVE';

function createLocalFindingsStore({ store, dir }) {
  const load = () => store.load(dir);

  function previewOf(data, repository) {
    const scoped = repository ? data.findings.filter(f => f.repository === repository) : data.findings;
    return {
      repository: repository || null,
      findings: scoped.length,
      suppressed: scoped.filter(TRIAGED).length,
      history: (data.history || []).length,
      repositories: new Set(data.findings.map(f => f.repository)).size,
    };
  }

  return {
    mode: 'local',

    async all() { return load().findings; },
    async get(id) { return load().findings.find(f => f.id === id) || null; },
    async history() { return load().history || []; },
    async baseline() { return load().baseline || null; },

    async merge(repository, findings, { coveredTypes, now }) {
      await store.mutate(dir, data => {
        data.findings = store.mergeFindings(data.findings, findings, { repository, coveredTypes, now });
      });
      return null;
    },

    // Snapshot AFTER the merge, so the point reflects what is actually open,
    // including findings resolved by this scan, which is the movement the trend
    // exists to show.
    async finishScan({ now }) {
      await store.mutate(dir, data => {
        const active = data.findings.filter(isActive);
        data.history = store.recordHistory(data.history, {
          at: now,
          counts: countBySeverity(active),
          total: active.length,
          byType: active.reduce((acc, f) => ({ ...acc, [f.type]: (acc[f.type] || 0) + 1 }), {}),
          repositories: new Set(data.findings.map(f => f.repository)).size,
        });
      });
    },

    update(id, patch) {
      return store.mutate(dir, data => {
        const finding = data.findings.find(f => f.id === id);
        if (!finding) return null;
        Object.assign(finding, patch);
        return finding;
      });
    },

    setBaseline(now = Date.now()) {
      return store.mutate(dir, data => {
        data.baseline = createBaseline(data.findings.filter(isActive), now);
        return data.baseline;
      });
    },
    async clearBaseline() { await store.mutate(dir, data => { data.baseline = null; }); },

    async preview({ repository = null } = {}) { return previewOf(load(), repository); },

    // keepSuppressed (default) keeps triage decisions: someone who marked a finding
    // a false positive should not lose that by clearing a repository.
    async clear({ repository = null, keepSuppressed = true } = {}) {
      const before = previewOf(load(), repository);
      await store.mutate(dir, data => {
        data.findings = data.findings.filter(f => {
          if (repository && f.repository !== repository) return true;
          return keepSuppressed && TRIAGED(f);
        });
      });
      return { ...before, keptSuppressed: keepSuppressed ? before.suppressed : 0, findings: before.findings - (keepSuppressed ? before.suppressed : 0) };
    },

    // Findings, trend history and the baseline: the two things that cannot be
    // rebuilt by scanning again, which is why this is separate from clear().
    async reset() {
      const before = previewOf(load(), null);
      await store.mutate(dir, data => { data.findings = []; data.history = []; data.baseline = null; });
      return { ...before, reset: true };
    },

    setRisk(updates) {
      return store.mutate(dir, data => {
        let updated = 0;
        for (const { id, risk } of updates) {
          const finding = data.findings.find(f => f.id === id);
          if (finding) { finding.risk = risk; updated += 1; }
        }
        return updated;
      });
    },
  };
}

module.exports = { createLocalFindingsStore };
