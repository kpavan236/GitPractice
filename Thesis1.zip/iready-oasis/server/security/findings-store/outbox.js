'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// A finished scan is written here BEFORE it is sent to the rule server and deleted
// only once the server has it. That keeps the guarantee this app has always made,
// that an outage cannot cost a finding, now that the server is where findings live.
//
// One JSON file per payload. Delivery is in the order scans were queued, stops at
// the first sign the server is down, and treats "already recorded" (409) as
// delivered: the analysis id is the idempotency key. A payload the server keeps
// refusing is quarantined in rejected/ with the reason, never silently dropped.

const MAX_ATTEMPTS = 3;

function createOutbox({ dir }) {
  const rejectedDir = path.join(dir, 'rejected');
  let seq = 0;

  const fileFor = id => path.join(dir, `${String(id).replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 80)}-${crypto.createHash('sha1').update(String(id)).digest('hex').slice(0, 8)}.json`);

  function write(file, entry) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(entry), { mode: 0o600 });
    fs.renameSync(tmp, file);
  }

  function quarantine(file, reason, entry) {
    fs.mkdirSync(rejectedDir, { recursive: true });
    const target = path.join(rejectedDir, `${Date.now()}-${path.basename(file)}`);
    let original = entry;
    if (!original) { try { original = fs.readFileSync(file, 'utf8'); } catch (_) { original = null; } }
    fs.writeFileSync(target, JSON.stringify({ reason, quarantinedAt: new Date().toISOString(), entry: original }));
    fs.rmSync(file, { force: true });
  }

  function put(id, payload) {
    write(fileFor(id), { id, queuedAt: Date.now(), order: seq += 1, attempts: 0, payload });
  }

  function remove(id) {
    fs.rmSync(fileFor(id), { force: true });
  }

  function readAll() {
    let names;
    try { names = fs.readdirSync(dir).filter(n => n.endsWith('.json')); } catch (_) { return []; }
    const entries = [];
    for (const name of names) {
      const file = path.join(dir, name);
      try {
        const entry = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!entry || entry.payload === undefined) throw new Error('not an outbox entry');
        entries.push({ file, ...entry });
      } catch (e) {
        quarantine(file, `unreadable: ${e.message}`);
        entries.corrupt = (entries.corrupt || 0) + 1;
      }
    }
    entries.sort((a, b) => (a.queuedAt - b.queuedAt) || (a.order - b.order));
    return entries;
  }

  const list = () => readAll().map(({ id, payload }) => ({ id, payload }));

  // What the server's answer means for a queued payload:
  //   409                      it already has it: delivered.
  //   401 403 408 413 429      the server cannot take uploads right now (credentials,
  //                            size, overload). Stop; nothing is counted against the
  //                            payload, because the payload is not what is wrong.
  //   400 404 410 422          the server says this payload is malformed. Retrying
  //                            cannot help: quarantine it with the reason.
  //   anything else            retried, quarantined after three separate flushes.
  const BLOCKING = new Set([401, 403, 408, 413, 429]);
  const MALFORMED = new Set([400, 404, 410, 422]);

  async function runFlush(post) {
    const result = { delivered: 0, remaining: 0, rejected: 0, blocked: null };
    const attempted = new Set();
    for (;;) {
      const batch = readAll();
      result.rejected += batch.corrupt || 0;
      const todo = batch.filter(e => !attempted.has(e.file));
      if (!todo.length) break;
      for (let i = 0; i < todo.length; i++) {
        const entry = todo[i];
        attempted.add(entry.file);
        try {
          await post(entry.payload);
          fs.rmSync(entry.file, { force: true });
          result.delivered += 1;
        } catch (e) {
          if (e.code === 'HTTP' && e.status === 409) {
            fs.rmSync(entry.file, { force: true });
            result.delivered += 1;
          } else if (e.code !== 'HTTP') {
            result.remaining += todo.length - i;
            return result;
          } else if (BLOCKING.has(e.status)) {
            result.blocked = { status: e.status, message: e.message };
            result.remaining += todo.length - i;
            return result;
          } else if (MALFORMED.has(e.status) || entry.attempts + 1 >= MAX_ATTEMPTS) {
            quarantine(entry.file, `refused (${e.status}): ${e.message}`, entry);
            result.rejected += 1;
          } else {
            const { file, ...rest } = entry;
            write(file, { ...rest, attempts: entry.attempts + 1, lastError: e.message });
            result.remaining += 1;
          }
        }
      }
    }
    return result;
  }

  // Flushes run one after another, each listing the queue afresh. A payload queued
  // while another flush is running is therefore attempted by the flush its own
  // caller started, never missed and never attributed to someone else's result.
  let chain = Promise.resolve();
  function flush(post) {
    const run = chain.then(() => runFlush(post));
    chain = run.catch(() => {});
    return run;
  }

  const count = d => { try { return fs.readdirSync(d).filter(n => n.endsWith('.json')).length; } catch (_) { return 0; } };
  const stats = () => ({ queued: count(dir), rejected: count(rejectedDir) });

  // Puts quarantined payloads back in the queue (after the cause is fixed).
  function requeueRejected() {
    let moved = 0;
    let names;
    try { names = fs.readdirSync(rejectedDir).filter(n => n.endsWith('.json')); } catch (_) { return 0; }
    for (const name of names) {
      const file = path.join(rejectedDir, name);
      try {
        const { entry } = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!entry || typeof entry !== 'object' || entry.payload === undefined) continue;   // a corrupt file has nothing to resend
        put(entry.id, entry.payload);
        fs.rmSync(file, { force: true });
        moved += 1;
      } catch (_) { /* leave it where it is */ }
    }
    return moved;
  }

  // Drops queued payloads that match (clearing a repository must not let its old
  // scans flush back in). Returns how many were dropped.
  function purge(matches) {
    let removed = 0;
    for (const entry of readAll()) {
      if (matches(entry.payload)) { fs.rmSync(entry.file, { force: true }); removed += 1; }
    }
    return removed;
  }

  return { put, remove, list, flush, stats, requeueRejected, purge, dir };
}

module.exports = { createOutbox, MAX_ATTEMPTS };
