'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { withTestRules, testRuleSet } = require('./test-support/rules');
const scanner = withTestRules(require('./scanners/sast-ast').scanner);
const engine = require('./ast/engine');

// TypeScript was a silent false-clean.
//
// The TypeScript grammar shipped and .ts/.tsx parsed fine, but rules are
// selected by exact language and no rule declares `typescript`. So every
// TypeScript file was read, parsed, matched against an empty rule set, and
// reported clean — while coverage said SAST had been analysed, with no
// truncation and nothing to indicate anything had been missed.
//
// That is precisely the failure this design is built to prevent, and it is the
// worst version of it: not a scanner that skipped and said so, but one that ran
// and found nothing because it was looking for nothing.

function tmpRepo(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-ts-sast-'));
  for (const [name, body] of Object.entries(files)) fs.writeFileSync(path.join(dir, name), body);
  return dir;
}

const VULNERABLE = [
  'const https = require("https");',
  'function go() {',
  '  eval("1+1");',
  '  https.request({ rejectUnauthorized: false });',
  '}',
].join('\n');

test('a .ts file is analysed with the same rules as its .js twin', async () => {
  // Identical content, two extensions. Anything the .js file catches, the .ts
  // file must catch — otherwise the extension decides whether a bug is found.
  const dir = tmpRepo({ 'app.js': VULNERABLE, 'app.ts': VULNERABLE });

  const { findings } = await scanner.scan({ repoPath: dir, repository: 'ts-demo', dir });
  const titlesFor = ext =>
    findings.filter(f => f.file.endsWith(ext)).map(f => f.title).sort();

  assert.deepEqual(titlesFor('.ts'), titlesFor('.js'));
  assert.ok(titlesFor('.ts').length >= 2, 'expected the .ts file to produce findings');
});

test('.tsx is covered too', async () => {
  const dir = tmpRepo({ 'view.tsx': VULNERABLE });
  const { findings } = await scanner.scan({ repoPath: dir, repository: 'ts-demo', dir });
  assert.ok(findings.length > 0, '.tsx files must be analysed, not silently passed');
});

test('every JavaScript rule compiles against the TypeScript grammar', async () => {
  // The fallback is only sound while this holds. A future JavaScript rule using
  // a node type TypeScript names differently would throw at scan time, and the
  // scanner would report a clean TypeScript file again.
  await engine.init();
  const js = testRuleSet().rules.filter(r => r.language === 'javascript' && r.query);
  assert.ok(js.length > 0, 'expected JavaScript rules to exist');

  for (const rule of js) {
    assert.doesNotThrow(
      () => engine.compileQuery('typescript', rule.query),
      `${rule.id} does not compile against the TypeScript grammar, so TypeScript files lose it`
    );
  }
});
