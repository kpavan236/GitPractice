'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { affecting, severityOf } = require('./ranges');

// An offline copy of the advisory database.
//
// WHY THIS IS AN INDEX AND NOT A MIRROR OF THE FILES.
//
// The full OSV export for npm alone is 219 MB, and the whole database is
// several gigabytes. Shipping that is out of the question, and even a local
// copy would make the SCA path read hundreds of megabytes to answer one
// question about one package.
//
// So the build step keeps only what the question needs: for each package, the
// affected ranges and enough advisory metadata to write a finding. Everything
// that makes an advisory large — the prose details, the reference lists, the
// credits — is dropped. That turns 219 MB into a few megabytes and makes the
// lookup a map read.
//
// WHAT THIS IS FOR. Air-gapped installs first: a network that cannot reach
// api.osv.dev today reports no vulnerable dependencies at all, which looks
// exactly like having none. It also removes a per-dependency network round trip
// from every scan, which on a large Maven tree is most of the scan's wall time.
//
// The mirror is NEVER the only source unless it is told to be. A mirror is a
// snapshot and goes stale; the default is to use it and still fall back to the
// live API for anything it does not know.

const DEFAULT_DIR = path.join(require('os').homedir(), '.oasis-security', 'advisories');

// Bumped when the index SHAPE changes. An index written by an older build is
// refused rather than half-read — a mirror that silently returns nothing is the
// failure this whole module exists to prevent.
const INDEX_VERSION = 1;

function indexPath(ecosystem, dir = DEFAULT_DIR) {
  const safe = String(ecosystem).replace(/[^A-Za-z0-9._-]/g, '_');
  return path.join(dir, `${safe}.json.gz`);
}

/**
 * Reads one ecosystem's index from disk.
 *
 * Gzipped, because the index is mostly repeated JSON keys and compresses about
 * eight to one — the difference between a mirror someone keeps and one they
 * delete when the disk fills up.
 */
function readIndex(ecosystem, dir = DEFAULT_DIR) {
  const file = indexPath(ecosystem, dir);
  if (!fs.existsSync(file)) return null;

  try {
    const index = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8'));
    if (index.indexVersion !== INDEX_VERSION) return null;
    return index;
  } catch (_) {
    // A truncated or corrupt index reads as absent, so the caller falls back to
    // the network instead of failing the scan.
    return null;
  }
}

/**
 * A mirror over a directory of per-ecosystem indexes.
 *
 * Indexes are loaded lazily and cached: a Java repository should never pay to
 * read the npm index, and a scan of four hundred Maven coordinates should read
 * the Maven index once.
 */
function createMirror({ dir = DEFAULT_DIR, load = readIndex } = {}) {
  const cache = new Map();

  function indexFor(ecosystem) {
    if (!cache.has(ecosystem)) cache.set(ecosystem, load(ecosystem, dir));
    return cache.get(ecosystem);
  }

  function has(ecosystem) {
    return Boolean(indexFor(ecosystem));
  }

  /**
   * Advisories affecting one package version.
   *
   * Returns null — NOT an empty array — when this ecosystem is not mirrored.
   * The distinction is the whole point: "no known vulnerabilities" and "we have
   * no data" must not be the same answer, or an unmirrored ecosystem silently
   * reports every package as clean.
   */
  function lookup(ecosystem, name, version) {
    const index = indexFor(ecosystem);
    if (!index) return null;

    const key = String(name).toLowerCase();
    const ids = index.packages[key];
    if (!ids || !ids.length) return [];

    const advisories = ids.map(id => index.advisories[id]).filter(Boolean);
    return affecting(advisories, { name, version }).map(a => ({
      id: a.id,
      aliases: a.aliases || [],
      summary: a.summary || null,
      severity: severityOf(a),
      published: a.published || null,
      modified: a.modified || null,
      // Where a reader goes for the full text this index deliberately dropped.
      url: `https://osv.dev/vulnerability/${a.id}`,
      source: 'mirror',
    }));
  }

  function status() {
    let entries = [];
    try {
      entries = fs.readdirSync(dir).filter(f => f.endsWith('.json.gz'));
    } catch (_) {
      return { available: false, ecosystems: [], dir };
    }

    const ecosystems = entries.map(file => {
      const ecosystem = file.replace(/\.json\.gz$/, '');
      const index = indexFor(ecosystem);
      const stat = (() => {
        try { return fs.statSync(path.join(dir, file)); } catch (_) { return null; }
      })();
      return {
        ecosystem,
        packages: index ? Object.keys(index.packages).length : 0,
        advisories: index ? Object.keys(index.advisories).length : 0,
        builtAt: index ? index.builtAt : null,
        // A mirror that stopped updating three months ago is a quiet failure,
        // so its age is reported next to it rather than left to be worked out.
        ageDays: stat ? Math.floor((Date.now() - stat.mtimeMs) / 86400000) : null,
      };
    });

    return { available: ecosystems.length > 0, ecosystems, dir };
  }

  return { lookup, has, status, indexFor, dir };
}

module.exports = { createMirror, readIndex, indexPath, DEFAULT_DIR, INDEX_VERSION };
