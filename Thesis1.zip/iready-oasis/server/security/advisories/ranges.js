'use strict';
const { compareVersions } = require('../../version-watch/compare-versions');

// Does this advisory affect this version?
//
// The single most consequential question the SCA path asks, and the easiest to
// get wrong in the direction that matters. Answer "no" incorrectly and a live
// CVE in a shipped dependency is never reported; answer "yes" incorrectly and
// people learn to ignore the SCA results, which has the same end state by a
// slower route.
//
// The comparator is the one already used by Version Watch rather than a second
// one written here. It is not fully SemVer- or PEP 440-compliant — it compares
// segment by segment, numerically where it can, and ranks a bare release above
// its own pre-release — but two comparators that disagree would be far worse
// than one that is imperfect in a documented way, because the same dependency
// would then be reported differently by two parts of the same product.

// Ranges expressed as git commits cannot be compared to a package version at
// all. Skipped rather than guessed: an advisory whose only range is GIT is
// resolved by its explicit `versions` list, or not at all.
const COMPARABLE_RANGE_TYPES = new Set(['SEMVER', 'ECOSYSTEM']);

function normaliseVersion(version) {
  // Strip a leading v, and Maven's common qualifiers stay as they are because
  // the comparator already handles suffixes.
  return String(version == null ? '' : version).trim().replace(/^v/i, '');
}

/**
 * Walks one OSV range's events.
 *
 * The events describe a timeline, not a set of intervals, so they have to be
 * processed IN VERSION ORDER: an `introduced` opens an affected window and the
 * next `fixed` or `last_affected` closes it. Processing them in array order
 * happens to work for the common single-interval case and quietly produces the
 * wrong answer for advisories that were fixed, regressed, and fixed again.
 */
function rangeAffects(range, version) {
  if (!range || !Array.isArray(range.events)) return false;
  if (range.type && !COMPARABLE_RANGE_TYPES.has(range.type)) return false;

  const events = range.events
    .map(e => {
      if (e.introduced !== undefined) return { kind: 'introduced', at: e.introduced };
      if (e.fixed !== undefined) return { kind: 'fixed', at: e.fixed };
      if (e.last_affected !== undefined) return { kind: 'last_affected', at: e.last_affected };
      // `limit` bounds a range's scope rather than its effect; it does not open
      // or close an affected window.
      return null;
    })
    .filter(Boolean)
    // "0" is OSV's "from the beginning of time" and must sort first.
    .sort((a, b) => (a.at === '0' ? -1 : b.at === '0' ? 1 : compareVersions(a.at, b.at)));

  let affected = false;
  for (const event of events) {
    if (event.kind === 'introduced') {
      if (event.at === '0' || compareVersions(version, event.at) >= 0) affected = true;
      continue;
    }
    if (event.kind === 'fixed') {
      // Fixed IN this version, so the fixed version itself is not affected.
      if (compareVersions(version, event.at) >= 0) affected = false;
      continue;
    }
    if (event.kind === 'last_affected') {
      // The last affected version IS affected; anything above it is not.
      if (compareVersions(version, event.at) > 0) affected = false;
    }
  }
  return affected;
}

/**
 * Whether one `affected` entry covers this package version.
 *
 * The explicit `versions` list is checked FIRST and is authoritative when it
 * matches: it is the database stating exactly which releases are affected, and
 * no amount of range arithmetic should override an exact enumeration.
 */
function affectedEntryMatches(entry, name, version) {
  if (!entry || !entry.package) return false;
  if (entry.package.name && entry.package.name.toLowerCase() !== String(name).toLowerCase()) return false;

  const target = normaliseVersion(version);
  if (!target) return false;

  if (Array.isArray(entry.versions) && entry.versions.length) {
    if (entry.versions.some(v => normaliseVersion(v) === target)) return true;
    // An enumeration that does not contain this version is NOT proof of
    // safety — OSV entries frequently carry both a list and a range, and the
    // list is often incomplete for ecosystems with many releases. Fall through
    // to the ranges rather than concluding "not affected".
  }

  return (entry.ranges || []).some(range => rangeAffects(range, target));
}

/**
 * Every advisory in `advisories` that affects this package version.
 */
function affecting(advisories, { name, version }) {
  return (advisories || []).filter(advisory =>
    (advisory.affected || []).some(entry => affectedEntryMatches(entry, name, version))
  );
}

// OSV records severity in two different places depending on who published it.
// GHSA puts a word in database_specific; others give a CVSS vector and nothing
// else. Both are read, and an advisory with neither is MEDIUM rather than being
// dropped or silently ranked lowest.
const SEVERITY_WORDS = new Set(['CRITICAL', 'HIGH', 'MEDIUM', 'MODERATE', 'LOW']);

function severityOf(advisory) {
  const declared = String(
    (advisory.database_specific && advisory.database_specific.severity) || ''
  ).toUpperCase();
  if (SEVERITY_WORDS.has(declared)) return declared === 'MODERATE' ? 'MEDIUM' : declared;

  const cvss = (advisory.severity || []).find(s => s && typeof s.score === 'string');
  if (cvss) return { vector: cvss.score };

  return 'MEDIUM';
}

module.exports = { affecting, affectedEntryMatches, rangeAffects, severityOf, normaliseVersion };
