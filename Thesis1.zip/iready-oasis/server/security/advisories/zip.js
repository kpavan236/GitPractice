'use strict';
const zlib = require('zlib');

// A ZIP reader, because OSV publishes its bulk exports only as .zip and there
// is no dependency to lean on.
//
// Scoped to what those archives contain: stored (method 0) and deflated
// (method 8) entries, read through the CENTRAL DIRECTORY rather than by
// scanning for local headers. That choice matters — a local-header scan can be
// fooled by a file whose contents happen to contain the signature bytes, and an
// archive of 250,000 JSON documents is exactly the kind of input where that
// eventually happens.
//
// Not supported, deliberately: encryption, ZIP64, and multi-disk archives. Each
// is refused by name rather than mis-parsed, because a reader that returns
// plausible garbage for an archive it does not understand is worse than one
// that says so.

const EOCD_SIGNATURE = 0x06054b50;
const CENTRAL_SIGNATURE = 0x02014b50;
const ZIP64_EOCD_LOCATOR = 0x07064b50;

// The end-of-central-directory record is at the very end, after a comment of up
// to 65535 bytes. Scanned backwards, which is both correct and far cheaper than
// searching a 200 MB buffer forwards.
function findEndOfCentralDirectory(buffer) {
  const minimum = 22;
  const from = Math.max(0, buffer.length - (minimum + 0xffff));
  for (let i = buffer.length - minimum; i >= from; i--) {
    if (buffer.readUInt32LE(i) === EOCD_SIGNATURE) return i;
  }
  return -1;
}

/**
 * Lists an archive's entries without decompressing any of them.
 *
 * Separated from reading so a caller can walk a 200 MB archive's table of
 * contents and inflate only the entries it wants — which is the difference
 * between bounded memory and holding the whole thing twice.
 */
function listEntries(buffer) {
  const eocd = findEndOfCentralDirectory(buffer);
  if (eocd === -1) throw new Error('not a zip archive (no end-of-central-directory record)');

  if (eocd >= 20 && buffer.readUInt32LE(eocd - 20) === ZIP64_EOCD_LOCATOR) {
    throw new Error('ZIP64 archives are not supported');
  }

  const count = buffer.readUInt16LE(eocd + 10);
  let offset = buffer.readUInt32LE(eocd + 16);

  const entries = [];
  for (let i = 0; i < count; i++) {
    if (buffer.readUInt32LE(offset) !== CENTRAL_SIGNATURE) {
      throw new Error(`corrupt central directory at entry ${i}`);
    }

    const flags = buffer.readUInt16LE(offset + 8);
    const method = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const uncompressedSize = buffer.readUInt32LE(offset + 24);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.toString('utf8', offset + 46, offset + 46 + nameLength);

    // Bit 0 is the encryption flag. An encrypted entry would inflate to
    // nonsense rather than fail, so it is caught here.
    if (flags & 0x1) throw new Error(`entry "${name}" is encrypted`);

    entries.push({ name, method, compressedSize, uncompressedSize, localOffset });
    offset += 46 + nameLength + extraLength + commentLength;
  }

  return entries;
}

/**
 * Decompresses one entry.
 *
 * The local header is re-read rather than trusted from the central directory:
 * its name and extra-field lengths can legitimately differ, and using the
 * central copy is the classic way to land a few bytes off the start of the data.
 */
function readEntry(buffer, entry) {
  const local = entry.localOffset;
  const nameLength = buffer.readUInt16LE(local + 26);
  const extraLength = buffer.readUInt16LE(local + 28);
  const start = local + 30 + nameLength + extraLength;
  const data = buffer.subarray(start, start + entry.compressedSize);

  if (entry.method === 0) return data;
  if (entry.method === 8) return zlib.inflateRawSync(data);
  throw new Error(`entry "${entry.name}" uses unsupported compression method ${entry.method}`);
}

/**
 * Every entry, as { name, data }, skipping directories.
 *
 * `onEntry` is called per entry instead of building an array when supplied, so
 * an archive of a quarter of a million files can be indexed without holding all
 * of them in memory at once.
 */
function eachEntry(buffer, onEntry) {
  const entries = listEntries(buffer);
  let count = 0;

  for (const entry of entries) {
    if (entry.name.endsWith('/')) continue;
    onEntry(entry.name, readEntry(buffer, entry));
    count += 1;
  }
  return count;
}

module.exports = { listEntries, readEntry, eachEntry, findEndOfCentralDirectory };
