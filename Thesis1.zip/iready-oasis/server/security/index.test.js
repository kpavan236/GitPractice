'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { createInstalledEngine, resolveChannel, stopSecurity } = require('./index');

const KEYS = { k1: crypto.generateKeyPairSync('ed25519').publicKey.export({ type: 'spki', format: 'pem' }) };

test('resolveChannel trims and lowercases, and treats blank or unset as the default', () => {
  assert.equal(resolveChannel(' Beta '), 'beta');
  assert.equal(resolveChannel('STABLE'), 'stable');
  assert.equal(resolveChannel(''), undefined);
  assert.equal(resolveChannel('   '), undefined);
  assert.equal(resolveChannel(undefined), undefined);
});

test('a mixed-case, padded OASIS_RULES_CHANNEL reaches the rule server as the beta channel', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sec-index-'));
  const urls = [];
  const fetchImpl = async (url) => { urls.push(String(url)); throw new TypeError('fetch failed'); };
  try {
    const { loader } = createInstalledEngine({ env: { OASIS_RULES_CHANNEL: ' Beta ', OASIS_RULE_SERVER_URL: 'https://rules.example.test' }, dir, publicKeys: KEYS, fetchImpl });
    await loader.update();
    assert.ok(urls.some((u) => /channel=beta(&|$)/.test(u)), urls.join(' '));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('an unknown channel is refused by update() with BAD_CHANNEL and the allowed values', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sec-index-'));
  try {
    const { loader } = createInstalledEngine({ env: { OASIS_RULES_CHANNEL: 'nightly', OASIS_RULE_SERVER_URL: 'https://rules.example.test' }, dir, publicKeys: KEYS });
    await assert.rejects(loader.update(), (e) => e.code === 'BAD_CHANNEL' && /allowed: beta, stable/.test(e.message));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('stopSecurity stops the rules updater, and is a no-op without one', () => {
  let stopped = 0;
  stopSecurity({ rulesUpdater: { stop: () => { stopped += 1; } } });
  assert.equal(stopped, 1);
  assert.doesNotThrow(() => stopSecurity({}));
  assert.doesNotThrow(() => stopSecurity(undefined));
});

test('server/index.js exports stop, and Electron calls it before quit', () => {
  const server = fs.readFileSync(path.join(__dirname, '..', 'index.js'), 'utf8');
  assert.match(server, /module\.exports = \{[^}]*\bstop\b[^}]*\}/);
  const main = fs.readFileSync(path.join(__dirname, '..', '..', 'electron', 'main.js'), 'utf8');
  assert.match(main, /app\.on\('before-quit'[\s\S]*?require\('\.\.\/server'\)\.stop\(\)/);
});
