'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { parseDiff, isInChangedCode, markNewCode } = require('./diff');

// Two layers. The parser is tested against fixture diffs, because that is where
// the off-by-one errors live and a fixture pins them exactly. The end-to-end
// path is tested against a real repository, because the interesting failure
// there — a shallow clone, an unknown ref — cannot be faked.

const DIFF = `diff --git a/src/App.java b/src/App.java
index 1234567..89abcde 100644
--- a/src/App.java
+++ b/src/App.java
@@ -10,0 +11,2 @@ public class App {
+    String q = request.getParameter("q");
+    stmt.executeQuery(q);
@@ -40 +42 @@ public class App {
-  old line
+  replaced line
diff --git a/package-lock.json b/package-lock.json
index aaa..bbb 100644
--- a/package-lock.json
+++ b/package-lock.json
@@ -100,0 +101,3 @@
+ "lodash": "4.17.19",
+ "x": "1",
+ "y": "2"
`;

test('parses added line ranges per file', () => {
  const changed = parseDiff(DIFF);
  assert.deepEqual([...changed.keys()].sort(), ['package-lock.json', 'src/App.java']);
  assert.deepEqual([...changed.get('src/App.java')].sort((a, b) => a - b), [11, 12, 42]);
  assert.deepEqual([...changed.get('package-lock.json')].sort((a, b) => a - b), [101, 102, 103]);
});

test('a hunk with no count means exactly one line', () => {
  // `@@ -40 +42 @@` — the count is implicit. Reading it as zero loses the line
  // entirely and a finding on it would be attributed to the backlog.
  const changed = parseDiff(DIFF);
  assert.ok(changed.get('src/App.java').has(42));
});

test('a pure deletion introduces nothing', () => {
  const changed = parseDiff(`--- a/x.js
+++ b/x.js
@@ -5,3 +4,0 @@
-gone
-gone
-gone
`);
  assert.equal(changed.get('x.js').size, 0);
});

test('a deleted file is not treated as changed code', () => {
  const changed = parseDiff(`--- a/gone.js
+++ /dev/null
@@ -1,3 +0,0 @@
-a
`);
  assert.equal(changed.size, 0);
});

test('an empty diff parses to nothing', () => {
  assert.equal(parseDiff('').size, 0);
  assert.equal(parseDiff(null).size, 0);
});

// ── Attributing a finding ──────────────────────────────────────────────────

test('a finding on a changed line is new', () => {
  const changed = parseDiff(DIFF);
  assert.equal(isInChangedCode({ file: 'src/App.java', startLine: 11 }, changed), true);
  assert.equal(isInChangedCode({ file: 'src/App.java', startLine: 12 }, changed), true);
});

test('a finding on an untouched line is not new', () => {
  const changed = parseDiff(DIFF);
  assert.equal(isInChangedCode({ file: 'src/App.java', startLine: 3 }, changed), false);
});

test('a finding in an untouched file is not new', () => {
  const changed = parseDiff(DIFF);
  assert.equal(isInChangedCode({ file: 'src/Other.java', startLine: 11 }, changed), false);
});

test('a multi-line finding is new if any of its lines changed', () => {
  const changed = parseDiff(DIFF);
  assert.equal(isInChangedCode({ file: 'src/App.java', startLine: 9, endLine: 11 }, changed), true);
});

test('a finding with no line is new when its file changed at all', () => {
  // An SCA advisory has no line number. A vulnerable dependency appears because
  // someone edited the lockfile, and refusing to attribute it for lack of a
  // line would let every new CVE straight through a gate.
  const changed = parseDiff(DIFF);
  assert.equal(isInChangedCode({ file: 'package-lock.json', startLine: null }, changed), true);
  assert.equal(isInChangedCode({ file: 'untouched.json', startLine: null }, changed), false);
});

test('nothing is new when there is no diff at all', () => {
  assert.equal(isInChangedCode({ file: 'a.js', startLine: 1 }, null), false);
});

// ── Against a real repository ──────────────────────────────────────────────

function git(dir, args) {
  execFileSync('git', args, {
    cwd: dir,
    stdio: 'pipe',
    env: {
      ...process.env,
      GIT_AUTHOR_NAME: 'Test', GIT_AUTHOR_EMAIL: 't@example.invalid',
      GIT_COMMITTER_NAME: 'Test', GIT_COMMITTER_EMAIL: 't@example.invalid',
    },
  });
}

function repoWithTwoCommits() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-diff-'));
  git(dir, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(dir, 'app.js'), 'const a = 1;\nconst b = 2;\nconst c = 3;\n');
  git(dir, ['add', '.']);
  git(dir, ['commit', '-qm', 'first']);

  fs.writeFileSync(path.join(dir, 'app.js'), 'const a = 1;\nconst b = 2;\nconst c = 3;\neval(userInput);\n');
  git(dir, ['add', '.']);
  git(dir, ['commit', '-qm', 'second']);
  return dir;
}

test('marks findings introduced by the last commit', async () => {
  const dir = repoWithTwoCommits();
  const findings = [
    { file: 'app.js', startLine: 4, title: 'eval' },   // added by the second commit
    { file: 'app.js', startLine: 1, title: 'old' },    // present in the first
  ];

  const result = await markNewCode(findings, dir, { base: 'HEAD~1' });
  assert.equal(result.available, true);
  assert.equal(result.findings.find(f => f.title === 'eval').isNewCode, true);
  assert.equal(result.findings.find(f => f.title === 'old').isNewCode, false);

  fs.rmSync(dir, { recursive: true, force: true });
});

test('an unknown base ref reports unavailable rather than "nothing is new"', () => {
  // The distinction the gate depends on. "Nothing changed" should let a build
  // through; "we could not tell what changed" must not.
  const dir = repoWithTwoCommits();
  return markNewCode([{ file: 'app.js', startLine: 4 }], dir, { base: 'origin/does-not-exist' })
    .then(result => {
      assert.equal(result.available, false);
      assert.match(result.reason, /could not diff/);
      assert.equal(result.findings[0].isNewCode, false);
      fs.rmSync(dir, { recursive: true, force: true });
    });
});

test('a repository with a single commit cannot diff HEAD~1', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-diff1-'));
  git(dir, ['init', '-q', '-b', 'main']);
  fs.writeFileSync(path.join(dir, 'a.js'), 'x\n');
  git(dir, ['add', '.']);
  git(dir, ['commit', '-qm', 'only']);

  const result = await markNewCode([{ file: 'a.js', startLine: 1 }], dir);
  assert.equal(result.available, false);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('a non-repository is unavailable, not a crash', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-nogit-'));
  const result = await markNewCode([{ file: 'a.js', startLine: 1 }], dir);
  assert.equal(result.available, false);
  fs.rmSync(dir, { recursive: true, force: true });
});
