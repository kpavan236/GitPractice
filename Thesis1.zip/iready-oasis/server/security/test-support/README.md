# Test rules

`rules.fixture.json` is a small slice of the rules held by `oasis-rule-server`
(`seed/rules`), checked in so engine tests can run without a server: all authored
rules plus `gitleaks-aws-access-token`, `gitleaks-github-pat`,
`gitleaks-generic-api-key` and three IaC policies.

Regenerate after the authored rules change:

    node -e "<select rules from ../oasis-rule-server/seed/rules>"   # see git history of this file

The full rule set is verified in `oasis-rule-server` (`npm test`), not here.
