'use strict';
// A real engine loader over a signed, in-memory rules release, for tests. Nothing here touches the network.
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { signManifest } = require('../engine-loader/manifest');
const { createEngineLoader } = require('../engine-loader');

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const PUBLIC_KEYS = { k1: publicKey.export({ type: 'spki', format: 'pem' }) };

const pack = (id, language, files) => zlib.gzipSync(JSON.stringify({
  id, kind: language ? 'language' : 'core', language, version: 'v',
  files: files.map(([p, d]) => ({ path: p, b64: Buffer.from(d).toString('base64') })),
}));

// A core pack whose analyze() reports one finding per rule it was handed (all on a.go), so a test can see exactly
// which rules reached the engine. Its one scanner has the id of the real pattern scanner.
const FAKE_CORE = [
  ['package.json', '{"main":"index.js"}'],
  ['index.js', `'use strict';
const fs = require('node:fs');
const path = require('node:path');
const scanners = { p: { id: 'PATTERN_SAST' } };
async function analyze({ ruleSet, repository, repoPath }) {
  const grammars = path.join(__dirname, 'src', 'ast', 'grammars');
  let wasm = [];
  try { wasm = fs.readdirSync(grammars); } catch (e) { /* none */ }
  const findings = ruleSet.rules.map((r) => ({
    id: null, fingerprint: 'fp-' + r.id, type: 'SAST', category: 'TEST', severity: r.severity, title: r.id, description: '',
    repository, file: 'a.go', startLine: 1, endLine: 1, cwe: null, cve: null, status: 'OPEN',
    detections: [{ source: 'PATTERN_SAST', ruleId: r.id, detectedAt: null }], remediation: null, evidence: null,
    risk: null, metadata: { ruleSetVersion: ruleSet.version, wasm }, firstSeenAt: null, lastSeenAt: null,
  }));
  return { results: new Map([['PATTERN_SAST', { findings, stats: { files: 1 }, error: null }]]), corpus: {}, cache: null };
}
module.exports = { analyze, scanners };
`],
];

// languages: { go: { extensions: ['.go'], rules: [...], grammar: 'WASM' } }
function releaseServer({ release = 1, languages = {}, core = [['package.json', '{"main":"index.js"}'], ['index.js', 'module.exports={}'], ['src/ast/.keep', '']] } = {}) {
  const packs = { core: pack('core', null, core) };
  for (const [lang, def] of Object.entries(languages)) {
    const files = [['rules.json', JSON.stringify(def.rules || [])], ['pack.json', JSON.stringify({ extensions: def.extensions || [] })]];
    if (def.grammar) files.push([`grammar/tree-sitter-${lang}.wasm`, def.grammar]);
    packs[`lang-${lang}`] = pack(`lang-${lang}`, lang, files);
  }
  const manifest = {
    release, channel: 'stable', createdAt: 'x', minLoader: 1,
    packs: Object.entries(packs).map(([packId, b]) => ({ packId, kind: packId === 'core' ? 'core' : 'language', language: packId === 'core' ? null : packId.slice(5), version: 'v', sha256: sha(b), size: b.length })),
  };
  const signed = signManifest(manifest, privateKey.export({ type: 'pkcs8', format: 'pem' }), 'k1');
  const blobs = new Map(Object.values(packs).map((b) => [sha(b), b]));
  return async (url) => {
    const u = new URL(url);
    if (u.pathname === '/v1/releases/latest') return Response.json({ ...signed, changedPackIds: Object.keys(packs) });
    return new Response(blobs.get(u.pathname.split('/').pop()));
  };
}

function tmpDir(t, prefix = 'oasis-loader-') {
  const d = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), prefix)));
  t.after(() => fs.rmSync(d, { recursive: true, force: true }));
  return d;
}

// Installs `release` into a fresh store and returns the loader. A later loader.update() against `serve` can be
// pointed at another release with setServe.
async function installedLoader(t, opts = {}) {
  const dir = tmpDir(t);
  let serve = releaseServer(opts);
  const loader = createEngineLoader({ dir, baseUrl: 'https://rules.example.test', fetchImpl: (u, o) => serve(u, o), publicKeys: PUBLIC_KEYS });
  assert.ok((await loader.update()).status === 'updated');
  loader.serve = (next) => { serve = releaseServer(next); };
  loader.dir = dir;
  return loader;
}
const assert = require('node:assert');

function offlineLoader(t) {
  return createEngineLoader({ dir: tmpDir(t), baseUrl: 'https://rules.example.test', publicKeys: PUBLIC_KEYS, fetchImpl: async () => { throw new TypeError('fetch failed'); } });
}

module.exports = { FAKE_CORE, installedLoader, offlineLoader, releaseServer, tmpDir, PUBLIC_KEYS };
