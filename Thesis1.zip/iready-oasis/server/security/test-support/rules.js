'use strict';
const fixture = require('./rules.fixture.json');

// Rules for tests. The scanner no longer ships any (they live on the rule
// server), so tests that run a real engine get this small checked-in set: every
// authored rule plus a few vendored secret rules and IaC policies. See README.md.

function testRuleSet(extra = []) {
  return { version: 'test@1', source: 'fixture', createdAt: null, rules: [...fixture.rules, ...extra] };
}

// Lets a test call `scanner.scan({ repoPath })` or `scanner.prepare({ dir })` the
// way it did when rules were built in: an explicit ruleSet still wins.
function withTestRules(scanner) {
  const inject = options => ({ ...options, ruleSet: options.ruleSet || testRuleSet() });
  return Object.assign(Object.create(scanner), {
    isAvailable: (options = {}) => scanner.isAvailable(inject(options)),
    prepare: options => scanner.prepare(inject(options)),
  });
}

module.exports = { testRuleSet, withTestRules };
