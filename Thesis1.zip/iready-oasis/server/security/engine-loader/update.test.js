'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { signManifest } = require('./manifest');
const { createStore } = require('./store');
const { updateEngine, MAX_MANIFEST_BYTES } = require('./update');

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const KEY = (() => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  return { pub: publicKey.export({ type: 'spki', format: 'pem' }), priv: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
})();
const OTHER = crypto.generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' });
const keys = { 'k1': KEY.pub };
const BASE = 'https://rules.example.test';

// Test-side pack builder (inverse of decodePack); it does not apply the service's path checks, so hostile packs can be made.
const pack = (id, files, meta = {}) => zlib.gzipSync(JSON.stringify({
  id, kind: id === 'core' ? 'core' : 'language', language: id === 'core' ? null : id.replace('lang-', ''), version: 'v', ...meta,
  files: files.map(([p, d]) => ({ path: p, b64: Buffer.from(d).toString('base64') })),
}));
const entry = (id, buf) => ({ packId: id, kind: id === 'core' ? 'core' : 'language', language: id === 'core' ? null : id.replace('lang-', ''), version: sha(buf).slice(0, 8), sha256: sha(buf), size: buf.length });

/** A fake service holding any number of releases. */
function fakeService() {
  const releases = new Map();   // no -> {signed, blobs: Map(sha -> buf)}
  const log = [];
  const blobs = new Map();
  const svc = {
    log, blobs, releases, latest: null, tamper: {}, redirect: null,
    publishRelease(no, packs, { channel = 'stable', minLoader = 1, priv = KEY.priv, keyId = 'k1' } = {}) {
      const bufs = Object.fromEntries(Object.entries(packs));
      const manifest = { release: no, channel, createdAt: '2026-10-13T00:00:00.000Z', minLoader, packs: Object.entries(bufs).map(([id, b]) => entry(id, b)) };
      for (const b of Object.values(bufs)) blobs.set(sha(b), b);
      releases.set(no, signManifest(manifest, priv, keyId));
      svc.latest = no;
    },
    fetchImpl: async (url, init = {}) => {
      log.push({ url: String(url), init });
      if (svc.offline) throw new TypeError('fetch failed');
      const u = new URL(url);
      if (svc.redirect) return new Response(null, { status: 302, headers: { location: svc.redirect } });
      if (u.pathname === '/v1/releases/latest') {
        const signed = JSON.parse(JSON.stringify(releases.get(svc.latest)));
        const since = u.searchParams.get('since');
        const known = new Set(since && releases.has(Number(since)) ? releases.get(Number(since)).manifest.packs.map((p) => p.sha256) : []);
        const changedPackIds = !Array.isArray(signed.manifest.packs) ? [] : signed.manifest.packs.filter((p) => !known.has(p.sha256)).map((p) => p.packId);
        return Response.json({ ...signed, changedPackIds: svc.changedOverride || changedPackIds });
      }
      const m = /^\/v1\/blobs\/([0-9a-f]{64})$/.exec(u.pathname);
      if (m) {
        let buf = blobs.get(m[1]);
        if (!buf) return new Response('{}', { status: 404 });
        if (svc.tamper[m[1]]) buf = svc.tamper[m[1]](Buffer.from(buf));
        return new Response(buf, { status: 200 });
      }
      return new Response('{}', { status: 404 });
    },
    blobCalls: () => log.filter((r) => r.url.includes('/v1/blobs/')).length,
  };
  return svc;
}

const goV1 = pack('lang-go', [['rules.json', '[{"id":"go-1"}]'], ['pack.json', '{"id":"lang-go","v":1}']]);
const goV2 = pack('lang-go', [['rules.json', '[{"id":"go-1"},{"id":"go-2"}]'], ['pack.json', '{"id":"lang-go","v":2}']]);
const jsV1 = pack('lang-javascript', [['rules.json', '[{"id":"js-1"}]']]);
const coreV1 = pack('core', [['src/index.js', 'module.exports = 1;'], ['package.json', '{}']]);

function env(fn) {
  return async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-update-'));
    const svc = fakeService();
    svc.publishRelease(1, { core: coreV1, 'lang-go': goV1, 'lang-javascript': jsV1 });
    const store = createStore(dir);
    const run = (over = {}) => updateEngine({ store, baseUrl: BASE, fetchImpl: svc.fetchImpl, publicKeys: keys, loaderVersion: 1, ...over });
    try { await fn({ dir, svc, store, run }); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  };
}
const litter = (dir) => fs.readdirSync(path.join(dir, 'staging'));

test('first update downloads every pack and makes the release current', env(async ({ svc, store, run }) => {
  const r = await run();
  assert.equal(r.status, 'updated');
  assert.equal(r.release, 1);
  assert.deepEqual([...r.downloaded].sort(), ['core', 'lang-go', 'lang-javascript']);
  assert.equal(store.current().release, 1);
  assert.equal(fs.readFileSync(path.join(store.current().packDirs.core, 'src/index.js'), 'utf8'), 'module.exports = 1;');
  assert.match(svc.log[0].url, /^https:\/\/rules\.example\.test\/v1\/releases\/latest\?channel=stable$/);
  assert.equal(svc.blobCalls(), 3);
}));

test('a second update after only lang-go changed downloads only lang-go', env(async ({ svc, store, run, dir }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 });
  svc.log.length = 0;
  const r = await run();
  assert.deepEqual(r, { status: 'updated', release: 2, downloaded: ['lang-go'] });
  assert.equal(svc.blobCalls(), 1);
  assert.match(svc.log.find((x) => x.url.includes('/v1/blobs/')).url, new RegExp(`/v1/blobs/${sha(goV2)}$`));
  assert.match(svc.log[0].url, /since=1/);
  const c = store.current();
  assert.equal(c.release, 2);
  assert.equal(fs.readFileSync(path.join(c.packDirs['lang-javascript'], 'rules.json'), 'utf8'), '[{"id":"js-1"}]');   // reused
  assert.equal(fs.readFileSync(path.join(c.packDirs['lang-go'], 'rules.json'), 'utf8'), '[{"id":"go-1"},{"id":"go-2"}]');
  assert.deepEqual(litter(dir), []);
  assert.equal(store.previous(), 1);
}));

test('the same release again is "current" and downloads nothing', env(async ({ svc, run }) => {
  await run();
  svc.log.length = 0;
  assert.deepEqual(await run(), { status: 'current', release: 1, downloaded: [] });
  assert.equal(svc.blobCalls(), 0);
}));

test('a server that under-reports changedPackIds cannot make us skip a pack we do not have', env(async ({ svc, store, run }) => {
  svc.changedOverride = [];
  const r = await run();
  assert.equal(r.downloaded.length, 3);
  assert.equal(store.current().release, 1);
}));

test('Review Focus 1: a tampered blob is refused with BLOB_HASH_MISMATCH, the old release kept, nothing stored', env(async ({ svc, store, run, dir }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 });
  svc.tamper[sha(goV2)] = (b) => { b[b.length - 1] ^= 1; return b; };
  await assert.rejects(run(), { code: 'BLOB_HASH_MISMATCH' });
  assert.equal(store.current().release, 1);
  assert.deepEqual(litter(dir), []);
  assert.equal(fs.existsSync(path.join(dir, 'blobs', sha(goV2))), false);
  assert.equal(fs.existsSync(path.join(dir, 'releases', '2')), false);
}));

test('a truncated or over-long blob is refused with BLOB_SIZE_MISMATCH and the old release kept', env(async ({ svc, store, run }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 });
  svc.tamper[sha(goV2)] = (b) => b.subarray(0, b.length - 5);
  await assert.rejects(run(), { code: 'BLOB_SIZE_MISMATCH' });
  svc.tamper[sha(goV2)] = (b) => Buffer.concat([b, Buffer.alloc(5000, 1)]);
  await assert.rejects(run(), { code: 'BLOB_SIZE_MISMATCH' });
  assert.equal(store.current().release, 1);
}));

test('a manifest with a bad signature (altered, or signed by another key) is refused', env(async ({ svc, store, run }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 }, { priv: OTHER });
  await assert.rejects(run(), { code: 'BAD_SIGNATURE' });
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 });
  svc.releases.get(2).manifest.packs[0].size += 1;
  await assert.rejects(run(), { code: 'BAD_SIGNATURE' });
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 }, { keyId: 'unknown' });
  await assert.rejects(run(), { code: 'UNKNOWN_KEY' });
  assert.equal(store.current().release, 1);
}));

test('with no pinned keys the update refuses before any network call', env(async ({ svc, run }) => {
  await assert.rejects(run({ publicKeys: undefined }), { code: 'NO_PINNED_KEYS' });
  await assert.rejects(run({ publicKeys: {} }), { code: 'NO_PINNED_KEYS' });
  assert.equal(svc.log.length, 0);
}));

test('a network failure returns offline and keeps the current release', env(async ({ svc, store, run }) => {
  await run();
  svc.offline = true;
  const r = await run();
  assert.equal(r.status, 'offline');
  assert.equal(r.release, 1);
  assert.equal(store.current().release, 1);
}));

test('a failure while downloading a blob (connection drops) is offline and leaves no litter', env(async ({ svc, store, run, dir }) => {
  const real = svc.fetchImpl;
  const r = await run({ fetchImpl: async (u, i) => { if (String(u).includes('/v1/blobs/')) throw new TypeError('fetch failed'); return real(u, i); } });
  assert.equal(r.status, 'offline');
  assert.equal(store.current(), null);
  assert.deepEqual(litter(dir), []);
}));

test('a server error is offline; other HTTP errors throw HTTP_ERROR', env(async ({ run }) => {
  assert.equal((await run({ fetchImpl: async () => new Response('', { status: 503 }) })).status, 'offline');
  await assert.rejects(run({ fetchImpl: async () => new Response('{}', { status: 404 }) }), { code: 'HTTP_ERROR' });
}));

test('minLoader above the loader returns UPGRADE_REQUIRED and keeps the release', env(async ({ svc, store, run }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': goV2, 'lang-javascript': jsV1 }, { minLoader: 2 });
  svc.log.length = 0;
  const r = await run();
  assert.deepEqual(r, { status: 'current', release: 1, downloaded: [], error: 'UPGRADE_REQUIRED' });
  assert.equal(svc.blobCalls(), 0);
  assert.equal(store.current().release, 1);
}));

test('the manifest channel must be the requested channel', env(async ({ svc, store, run }) => {
  svc.publishRelease(2, { core: coreV1 }, { channel: 'beta' });
  await assert.rejects(run(), { code: 'CHANNEL_MISMATCH' });
  assert.equal(store.current(), null);
  const r = await run({ channel: 'beta' });
  assert.equal(r.status, 'updated');
  assert.match(svc.log.at(-2).url, /channel=beta/);
}));

test('a lower release number than the installed one is a rollback attack and is refused', env(async ({ svc, store, run }) => {
  svc.publishRelease(5, { core: coreV1 });
  await run();
  svc.publishRelease(4, { core: coreV1, 'lang-go': goV1 });
  await assert.rejects(run(), { code: 'ROLLBACK_REJECTED' });
  assert.equal(store.current().release, 5);
}));

test('a malformed manifest is refused even when correctly signed', env(async ({ svc, run }) => {
  for (const bad of [
    { release: 0 }, { packs: 'x' }, { packs: [{ packId: '../x', sha256: 'a'.repeat(64), size: 1 }] },
    { packs: [{ packId: 'core', sha256: 'zz', size: 1 }] }, { packs: [{ packId: 'core', sha256: 'a'.repeat(64), size: -1 }] },
    { packs: [{ packId: 'core', sha256: 'a'.repeat(64), size: 1 }, { packId: 'core', sha256: 'b'.repeat(64), size: 1 }] },
  ]) {
    const manifest = { release: 7, channel: 'stable', createdAt: 'x', minLoader: 1, packs: [], ...bad };
    svc.releases.set(7, signManifest(manifest, KEY.priv, 'k1')); svc.latest = 7;
    await assert.rejects(run(), { code: 'BAD_MANIFEST' }, JSON.stringify(bad));
  }
}));

test('a pack with an unsafe path, or whose id is not its packId, is refused and leaves the old release', env(async ({ svc, store, run, dir }) => {
  await run();
  svc.publishRelease(2, { core: coreV1, 'lang-go': pack('lang-go', [['../evil', 'x']]), 'lang-javascript': jsV1 });
  await assert.rejects(run(), { code: 'UNSAFE_PATH' });
  svc.publishRelease(3, { core: coreV1, 'lang-go': pack('lang-rust', [['a', 'x']]), 'lang-javascript': jsV1 });
  await assert.rejects(run(), { code: 'PACK_MISMATCH' });
  assert.equal(store.current().release, 1);
  assert.deepEqual(litter(dir), []);
}));

test('Review Focus 2: killed between download and switch (a throw at every stage boundary) keeps the previous release', async () => {
  for (const boundary of ['writePack', 'copyPack', 'setManifest', 'activate']) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-kill-'));
    try {
      const svc = fakeService();
      svc.publishRelease(1, { core: coreV1, 'lang-go': goV1 });
      const store = createStore(dir);
      const base = { baseUrl: BASE, fetchImpl: svc.fetchImpl, publicKeys: keys, loaderVersion: 1 };
      await updateEngine({ store, ...base });
      svc.publishRelease(2, { core: coreV1, 'lang-go': goV2 });
      const failing = {
        ...store,
        stage(n) {
          const st = store.stage(n);
          const wrap = (name) => (...a) => { if (boundary === name) throw new Error(`killed at ${name}`); return st[name](...a); };
          return { ...st, writePack: wrap('writePack'), copyPack: wrap('copyPack'), setManifest: wrap('setManifest') };
        },
        activate(n) { if (boundary === 'activate') throw new Error('killed at activate'); return store.activate(n); },
      };
      await assert.rejects(updateEngine({ store: failing, ...base }), new RegExp(`killed at ${boundary}`));
      assert.equal(createStore(dir).current().release, 1, boundary);   // a fresh process sees release 1
      assert.equal(fs.readFileSync(path.join(createStore(dir).current().packDirs['lang-go'], 'rules.json'), 'utf8'), '[{"id":"go-1"}]');
      const ok = await updateEngine({ store: createStore(dir), ...base });   // and the retry succeeds
      assert.equal(ok.release, 2);
    } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  }
});

test('after an interrupted update the verified blobs are reused and not downloaded again', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-resume-'));
  try {
    const svc = fakeService();
    svc.publishRelease(1, { core: coreV1, 'lang-go': goV1 });
    const store = createStore(dir);
    const base = { baseUrl: BASE, fetchImpl: svc.fetchImpl, publicKeys: keys, loaderVersion: 1 };
    await assert.rejects(updateEngine({ store: { ...store, activate() { throw new Error('killed'); } }, ...base }), /killed/);
    assert.equal(svc.blobCalls(), 2);
    svc.log.length = 0;
    const r = await updateEngine({ store, ...base });
    assert.equal(r.status, 'updated');
    assert.equal(svc.blobCalls(), 0);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('network hygiene: http(s) only, a timeout and manual redirects on every fetch, cross-origin redirects refused', env(async ({ svc, run }) => {
  for (const baseUrl of ['ftp://rules.example.test', 'file:///etc', 'rules.example.test', 'javascript:alert(1)']) {
    await assert.rejects(run({ baseUrl }), { code: 'BAD_BASE_URL' }, baseUrl);
  }
  await run();
  for (const r of svc.log) {
    assert.equal(r.init.redirect, 'manual');
    assert.ok(r.init.signal instanceof AbortSignal);
  }
  svc.redirect = 'https://evil.example.test/v1/releases/latest';
  await assert.rejects(run(), { code: 'REDIRECT_REFUSED' });
  svc.redirect = 'http://rules.example.test/v1/releases/latest';   // same host, different scheme = different origin
  await assert.rejects(run(), { code: 'REDIRECT_REFUSED' });
}));

test('a same-origin redirect is followed, but not forever', env(async ({ svc, store, run }) => {
  const real = svc.fetchImpl;
  let hop = 0;
  const r = await run({ fetchImpl: async (u, i) => {
    if (String(u).includes('/v1/releases/latest') && !String(u).includes('moved') && hop++ === 0) return new Response(null, { status: 301, headers: { location: '/v1/releases/latest?channel=stable&moved=1' } });
    return real(u, i);
  } });
  assert.equal(r.status, 'updated');
  assert.equal(store.current().release, 1);
  await assert.rejects(run({ fetchImpl: async () => new Response(null, { status: 302, headers: { location: '/loop' } }) }), { code: 'TOO_MANY_REDIRECTS' });
}));

test('the body is read with a limit: a blob larger than its declared size is not buffered whole', env(async ({ svc, run }) => {
  let pulled = 0;
  const real = svc.fetchImpl;
  const r = run({ fetchImpl: async (u, i) => {
    if (!String(u).includes('/v1/blobs/')) return real(u, i);
    const body = new ReadableStream({ pull(c) { pulled += 1024; c.enqueue(new Uint8Array(1024)); } });
    return new Response(body, { status: 200, headers: { 'content-length': '10' } });   // a lying Content-Length
  } });
  await assert.rejects(r, { code: 'BLOB_SIZE_MISMATCH' });
  assert.ok(pulled < 64 * 1024, `read ${pulled} bytes`);
}));

test('an oversized manifest response is refused', env(async ({ run }) => {
  assert.ok(MAX_MANIFEST_BYTES > 0);
  await assert.rejects(run({ fetchImpl: async () => new Response(Buffer.alloc(MAX_MANIFEST_BYTES + 10, 0x20), { status: 200 }) }), { code: 'RESPONSE_TOO_LARGE' });
}));

test('HTTP 429 and 408 are transient: offline, error kept, installed release kept', env(async ({ store, run }) => {
  await run();
  for (const status of [429, 408]) {
    const r = await run({ fetchImpl: async () => new Response('', { status }) });
    assert.equal(r.status, 'offline');
    assert.equal(r.release, 1);
    assert.equal(r.error, 'RATE_LIMITED_OR_TIMEOUT');
    assert.equal(store.current().release, 1);
  }
}));
