'use strict';
// Fetch, verify and install a signed rules release. Order of trust: signature on the manifest first, then channel,
// release number and loader version, then each blob against the manifest's sha256 and size BEFORE it is stored or
// unpacked. Integrity failures reject with a coded error; being offline or needing a newer loader is a normal result.
const { verifyManifest, MIN_LOADER } = require('./manifest');
const { PINNED_KEYS } = require('./keys');
const { LIMITS, PACK_ID } = require('./store');

const MAX_MANIFEST_BYTES = 1024 * 1024;
const MAX_BLOB_BYTES = LIMITS.MAX_PACK_UNPACKED_BYTES;   // a packed blob never needs to exceed what it may unpack to
const MAX_REDIRECTS = 3;
const MANIFEST_TIMEOUT_MS = 30 * 1000;
const BLOB_TIMEOUT_MS = 5 * 60 * 1000;
const CHANNELS = ['beta', 'stable'];
const HEX64 = /^[0-9a-f]{64}$/;
const OFFLINE_CODES = new Set(['NETWORK', 'SERVER_ERROR', 'RATE_LIMITED_OR_TIMEOUT']);   // transient: try again later

const coded = (code, message) => Object.assign(new Error(message), { code });
const sha256 = (buf) => require('node:crypto').createHash('sha256').update(buf).digest('hex');

function parseBase(baseUrl) {
  let u;
  try { u = new URL(baseUrl); } catch { throw coded('BAD_BASE_URL', 'baseUrl is not a URL'); }
  if ((u.protocol !== 'https:' && u.protocol !== 'http:') || u.username || u.password) throw coded('BAD_BASE_URL', 'baseUrl must be a plain http(s) URL');
  return { origin: u.origin, prefix: `${u.origin}${u.pathname.replace(/\/+$/, '')}` };
}

/** Reads at most `limit` bytes; `overflow` is true when the body had more. Never trusts Content-Length. */
async function readLimited(res, limit) {
  if (!res.body || typeof res.body.getReader !== 'function') {
    const buf = Buffer.from(await res.arrayBuffer());
    return buf.length > limit ? { buf: buf.subarray(0, limit), overflow: true } : { buf, overflow: false };
  }
  const reader = res.body.getReader();
  const chunks = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = Buffer.from(value);
    if (n + chunk.length > limit) {
      chunks.push(chunk.subarray(0, limit - n));
      await reader.cancel().catch(() => {});
      return { buf: Buffer.concat(chunks), overflow: true };
    }
    chunks.push(chunk); n += chunk.length;
  }
  return { buf: Buffer.concat(chunks), overflow: false };
}

/** GET with a timeout, manual same-origin redirects only, and a body-size cap. */
async function get({ url, origin, fetchImpl, timeoutMs, limit }) {
  let target = url;
  for (let hop = 0; ; hop += 1) {
    let res;
    try {
      res = await fetchImpl(target, { redirect: 'manual', signal: AbortSignal.timeout(timeoutMs), headers: { accept: 'application/json, application/octet-stream' } });
    } catch (e) { throw Object.assign(coded('NETWORK', `request failed: ${e.message}`), { cause: e }); }
    if (res.url && new URL(res.url).origin !== origin) throw coded('REDIRECT_REFUSED', 'response came from another origin');
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get('location');
      let next;
      try { next = new URL(loc, target); } catch { throw coded('REDIRECT_REFUSED', 'redirect without a usable Location'); }
      if (next.origin !== origin) throw coded('REDIRECT_REFUSED', `redirect to another origin (${next.origin}) refused`);
      if (hop >= MAX_REDIRECTS) throw coded('TOO_MANY_REDIRECTS', 'too many redirects');
      target = next.toString();
      continue;
    }
    if (res.status === 429 || res.status === 408) throw coded('RATE_LIMITED_OR_TIMEOUT', `server answered ${res.status}`);
    if (res.status >= 500) throw coded('SERVER_ERROR', `server answered ${res.status}`);
    if (res.status < 200 || res.status >= 300) throw Object.assign(coded('HTTP_ERROR', `server answered ${res.status}`), { status: res.status });
    try { return await readLimited(res, limit); } catch (e) { throw Object.assign(coded('NETWORK', `reading the response failed: ${e.message}`), { cause: e }); }
  }
}

function checkManifest(m) {
  const bad = (why) => coded('BAD_MANIFEST', `manifest is malformed: ${why}`);
  if (!m || typeof m !== 'object') throw bad('not an object');
  if (!Number.isInteger(m.release) || m.release < 1) throw bad('release');
  if (typeof m.channel !== 'string') throw bad('channel');
  if (!Number.isInteger(m.minLoader) || m.minLoader < 1) throw bad('minLoader');
  if (!Array.isArray(m.packs) || m.packs.length === 0) throw bad('packs');
  const seen = new Set();
  for (const p of m.packs) {
    if (!p || typeof p.packId !== 'string' || !PACK_ID.test(p.packId) || p.packId === 'manifest.json') throw bad('packId');
    if (seen.has(p.packId)) throw bad(`duplicate pack ${p.packId}`);
    seen.add(p.packId);
    if (typeof p.sha256 !== 'string' || !HEX64.test(p.sha256)) throw bad(`sha256 of ${p.packId}`);
    if (!Number.isInteger(p.size) || p.size < 1 || p.size > MAX_BLOB_BYTES) throw bad(`size of ${p.packId}`);
  }
}

async function updateEngine({
  store, baseUrl, channel = 'stable', fetchImpl = fetch, publicKeys = PINNED_KEYS, loaderVersion = MIN_LOADER,
  timeoutMs = MANIFEST_TIMEOUT_MS, blobTimeoutMs = BLOB_TIMEOUT_MS,
}) {
  if (!publicKeys || Object.keys(publicKeys).length === 0) throw coded('NO_PINNED_KEYS', 'no signing keys are pinned in this build, so no release can be trusted');
  if (!CHANNELS.includes(channel)) throw coded('BAD_CHANNEL', `unknown channel ${JSON.stringify(channel)}; allowed: ${CHANNELS.join(', ')}`);
  const { origin, prefix } = parseBase(baseUrl);
  const installed = store.current();
  const state = (status, extra = {}) => ({ status, release: installed ? installed.release : null, downloaded: [], ...extra });

  let stage = null;
  try {
    const query = `channel=${encodeURIComponent(channel)}${installed ? `&since=${installed.release}` : ''}`;
    const { buf, overflow } = await get({ url: `${prefix}/v1/releases/latest?${query}`, origin, fetchImpl, timeoutMs, limit: MAX_MANIFEST_BYTES });
    if (overflow) throw coded('RESPONSE_TOO_LARGE', 'release response is larger than the manifest cap');
    let body;
    try { body = JSON.parse(buf.toString('utf8')); } catch { throw coded('BAD_RESPONSE', 'release response is not JSON'); }

    const manifest = verifyManifest(body, publicKeys);
    checkManifest(manifest);
    if (manifest.channel !== channel) throw coded('CHANNEL_MISMATCH', `asked for ${channel}, got a manifest for ${manifest.channel}`);
    if (installed && manifest.release < installed.release) throw coded('ROLLBACK_REJECTED', `release ${manifest.release} is older than the installed ${installed.release}`);
    if (installed && manifest.release === installed.release) return state('current');
    if (manifest.minLoader > loaderVersion) return state('current', { error: 'UPGRADE_REQUIRED' });

    // Decide what to fetch from what is installed, not from the server's changedPackIds: that list is a hint, and a
    // pack we do not hold must be fetched even if the server says it is unchanged.
    const have = new Map(installed ? installed.manifest.packs.map((p) => [p.packId, p.sha256]) : []);
    const downloaded = [];
    stage = store.stage(manifest.release);
    for (const p of manifest.packs) {
      if (have.get(p.packId) === p.sha256 && installed.packDirs[p.packId]) { stage.copyPack(p.packId, installed.packDirs[p.packId]); continue; }
      let blob = store.readBlob(p.sha256);
      if (!blob) {
        const got = await get({ url: `${prefix}/v1/blobs/${p.sha256}`, origin, fetchImpl, timeoutMs: blobTimeoutMs, limit: p.size });
        if (got.overflow || got.buf.length !== p.size) throw coded('BLOB_SIZE_MISMATCH', `pack ${p.packId}: expected ${p.size} bytes${got.overflow ? ', got more' : `, got ${got.buf.length}`}`);
        if (sha256(got.buf) !== p.sha256) throw coded('BLOB_HASH_MISMATCH', `pack ${p.packId} does not match its sha256`);
        store.writeBlob(p.sha256, got.buf);
        blob = got.buf;
        downloaded.push(p.packId);
      }
      const meta = stage.writePack(p.packId, blob);
      if (meta.id !== p.packId) throw coded('PACK_MISMATCH', `pack ${p.packId} identifies itself as ${JSON.stringify(meta.id)}`);
    }
    stage.setManifest({ manifest, keyId: body.keyId, signature: body.signature });
    store.activate(manifest.release);
    stage = null;
    try { store.gc(2); } catch { /* the new release is live; leftovers are removed by the next gc */ }
    return { status: 'updated', release: manifest.release, downloaded };
  } catch (e) {
    if (stage) { try { stage.abort(); } catch { /* best effort: a fresh store removes staging litter */ } }
    if (OFFLINE_CODES.has(e.code)) return state('offline', { error: e.code });
    throw e;
  }
}

module.exports = { updateEngine, MAX_MANIFEST_BYTES, MAX_BLOB_BYTES };
