'use strict';
// DEV ONLY: lets a developer trust a release signed by a local key, so the installed-rules path can be proven end to
// end before the production keys are pinned. It adds a key to the trusted set; it never turns verification off.
//
// OASIS_DEV_RULES_PUBLIC_KEYS = path of a JSON file { "<keyId>": "<Ed25519 public key PEM>" }. Loaded only when set,
// merged over the pinned keys (a pinned key id can never be replaced), private keys refused, and ignored altogether in
// a packaged desktop app. Every use is announced.
const fs = require('node:fs');
const crypto = require('node:crypto');
const { PINNED_KEYS } = require('./keys');

const ENV_NAME = 'OASIS_DEV_RULES_PUBLIC_KEYS';
const MAX_FILE_BYTES = 64 * 1024;
const coded = (code, message) => Object.assign(new Error(message), { code });

const DEV_WARNING = (ids) => `DEV rules signing key in use (${ids.join(', ')}): releases are trusted from a local file, not the pinned production keys`;
const IGNORED_NOTE = `${ENV_NAME} is ignored in a packaged app: development signing keys are not trusted there`;

const warned = new Set();
function warnOnce(message, log) { if (!warned.has(message)) { warned.add(message); log(message); } }
function resetWarnings() { warned.clear(); }

// A packaged build: app.isPackaged when Electron's app can be read (the way electron/main.js decides), otherwise
// Electron without process.defaultApp (which is only set for `electron .`).
function isPackagedApp({ electron = process.versions.electron, defaultApp = process.defaultApp, app } = {}) {
  if (!electron) return false;
  if (app && typeof app.isPackaged === 'boolean') return app.isPackaged;
  return !defaultApp;
}

function electronApp() {
  try { const e = require('electron'); return e && typeof e === 'object' ? e.app : undefined; } catch { return undefined; }
}

function readKeyFile(file) {
  let text;
  try {
    const st = fs.statSync(file);
    // A file others can write is a way to add a trusted signing key without the developer knowing. POSIX only:
    // Windows mode bits do not describe who can write.
    if (process.platform !== 'win32' && (st.mode & 0o022) !== 0) {
      throw coded('DEV_KEYS_INSECURE_FILE', `${ENV_NAME}: ${file} is group- or world-writable (mode ${(st.mode & 0o777).toString(8)}); run chmod go-w on it`);
    }
    if (st.size > MAX_FILE_BYTES) throw coded('DEV_KEYS_BAD_FILE', `${ENV_NAME}: the key file is larger than ${MAX_FILE_BYTES} bytes`);
    text = fs.readFileSync(file, 'utf8');
  } catch (e) {
    if (e.code === 'DEV_KEYS_BAD_FILE' || e.code === 'DEV_KEYS_INSECURE_FILE') throw e;
    throw coded('DEV_KEYS_UNREADABLE', `${ENV_NAME}: cannot read ${file} (${e.code || 'error'})`);
  }
  let parsed;
  try { parsed = JSON.parse(text); } catch { throw coded('DEV_KEYS_BAD_FILE', `${ENV_NAME}: ${file} is not JSON`); }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || Object.keys(parsed).length === 0) {
    throw coded('DEV_KEYS_BAD_FILE', `${ENV_NAME}: ${file} must be a JSON object of { keyId: public key PEM } with at least one key`);
  }
  return parsed;
}

function checkPublicKey(id, pem) {
  if (!id || typeof id !== 'string') throw coded('DEV_KEY_INVALID', `${ENV_NAME}: a key id must be a non-empty string`);
  if (typeof pem !== 'string') throw coded('DEV_KEY_INVALID', `${ENV_NAME}: key "${id}" must be a PEM string`);
  // createPublicKey happily derives a public key from a private PEM, so look for the marker first.
  if (/PRIVATE KEY/.test(pem)) throw coded('DEV_KEY_PRIVATE', `${ENV_NAME}: key "${id}" is a PRIVATE key; put only the public key in this file`);
  let key;
  try { key = crypto.createPublicKey(pem); } catch { throw coded('DEV_KEY_INVALID', `${ENV_NAME}: key "${id}" is not a valid public key PEM`); }
  if (key.asymmetricKeyType !== 'ed25519') throw coded('DEV_KEY_INVALID', `${ENV_NAME}: key "${id}" must be an Ed25519 public key`);
}

/** The trusted keys: pinned plus, when allowed and set, the dev keys. { keys, devKeys: [ids], ignored: boolean } */
function resolveKeys({ env = process.env, pinned = PINNED_KEYS, electron = process.versions.electron, defaultApp = process.defaultApp, log = () => {} } = {}) {
  const file = env[ENV_NAME];
  if (!file) return { keys: pinned, devKeys: [], ignored: false };
  if (isPackagedApp({ electron, defaultApp, app: electron ? electronApp() : undefined })) {
    warnOnce(IGNORED_NOTE, log);
    return { keys: pinned, devKeys: [], ignored: true };
  }
  const dev = readKeyFile(file);
  for (const [id, pem] of Object.entries(dev)) {
    checkPublicKey(id, pem);
    if (Object.prototype.hasOwnProperty.call(pinned, id)) throw coded('DEV_KEY_ID_PINNED', `${ENV_NAME}: key id "${id}" is already pinned in this build and cannot be overridden`);
  }
  const devKeys = Object.keys(dev);
  warnOnce(DEV_WARNING(devKeys), log);
  return { keys: { ...pinned, ...dev }, devKeys, ignored: false };
}

module.exports = { resolveKeys, resetWarnings, isPackagedApp, DEV_WARNING, ENV_NAME };
