'use strict';
// Dependency-free on purpose (only node:crypto): the Oasis client carries a byte-for-byte copy of this file.
const crypto = require('node:crypto');

const MIN_LOADER = 1;

const coded = (code, message) => Object.assign(new Error(message), { code });

/**
 * JSON with object keys sorted at every level and no whitespace. Like JSON.stringify, object keys whose value is
 * undefined are dropped, and undefined array items / non-finite numbers become null.
 */
function canonical(value) {
  if (Array.isArray(value)) return `[${value.map((v) => canonical(v === undefined ? null : v)).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().filter((k) => value[k] !== undefined)
      .map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  }
  const out = JSON.stringify(value);
  return out === undefined ? 'null' : out;
}

function signManifest(manifest, privateKeyPem, keyId) {
  const signature = crypto.sign(null, Buffer.from(canonical(manifest)), privateKeyPem).toString('base64');
  return { manifest, keyId, signature };
}

/** Returns the manifest when the signature is valid for one of the trusted keys ({[keyId]: publicKeyPem}). */
function verifyManifest(signed, publicKeys) {
  const { manifest, keyId, signature } = signed || {};
  if (!publicKeys || !Object.prototype.hasOwnProperty.call(publicKeys, keyId)) {
    throw coded('UNKNOWN_KEY', `manifest is signed with unknown key "${keyId}"`);
  }
  let ok = false;
  try {
    ok = crypto.verify(null, Buffer.from(canonical(manifest)), publicKeys[keyId], Buffer.from(String(signature), 'base64'));
  } catch { ok = false; }
  if (!ok) throw coded('BAD_SIGNATURE', 'manifest signature does not match');
  return manifest;
}

module.exports = { canonical, signManifest, verifyManifest, MIN_LOADER };
