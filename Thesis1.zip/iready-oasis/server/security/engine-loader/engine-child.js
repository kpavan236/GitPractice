'use strict';
// Runs inside the restricted child started by run.js. Reads ONE JSON job from stdin, loads the engine from the
// installed core pack, writes ONE framed JSON answer line to stdout (other output is ignored by the parent). It never logs repository content.
const fs = require('node:fs');
const path = require('node:path');

function readStdin() {
  return new Promise((resolve, reject) => {
    const chunks = [];
    process.stdin.on('data', (c) => chunks.push(c));
    process.stdin.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    process.stdin.on('error', reject);
  });
}

// A finding's plaintext credential is a non-enumerable field, which a JSON round trip would drop; it is carried
// explicitly, keyed by the finding's fingerprint, or by the hash of the secret when the engine has not assigned a
// fingerprint yet (the real analyzer never does: the host fingerprints after the run, and a secret's identity is that hash).
function extractSecrets(findings) {
  const secrets = new Map();
  for (const f of findings) {
    const key = f && (f.fingerprint || (f.metadata && f.metadata.secretHash));
    if (f && f._plaintext && typeof key === 'string' && key) secrets.set(key, f._plaintext);
  }
  return [...secrets];
}

async function main() {
  const job = JSON.parse(await readStdin());
  // The entry file is named explicitly: Node 20's permission model denies the directory-style require() lookup.
  const main = JSON.parse(fs.readFileSync(path.join(job.corePath, 'package.json'), 'utf8')).main || 'index.js';
  const core = require(path.join(job.corePath, main));
  // The findings cache is always off here: the child may not write, and a cache read from the repo directory is not
  // something a restricted run should trust. dir is only a placeholder the cache constructor insists on.
  let cache = null;
  try {
    cache = require(path.join(job.corePath, 'src', 'scan-cache.js')).createCache({ dir: job.repoPath, repository: job.repository, enabled: false });
  } catch { process.stderr.write('engine-child: no usable scan cache in the core pack; running uncached\n'); }

  const all = Object.values(core.scanners || {});
  const scanners = Array.isArray(job.scannerIds) ? job.scannerIds.map((id) => all.find((s) => s.id === id)).filter(Boolean) : all;
  const out = await core.analyze({
    scanners, repoPath: job.repoPath, repository: job.repository, maxFiles: job.maxFiles, files: job.files, ruleSet: job.ruleSet, cache,
  });

  const entries = out.results instanceof Map ? [...out.results] : out.results;
  const findings = Array.isArray(entries) ? entries.flatMap(([, r]) => (r && Array.isArray(r.findings) ? r.findings : [])) : [];
  const results = Array.isArray(entries)
    ? entries.map(([id, r]) => [id, r && typeof r === 'object' ? { findings: r.findings, stats: r.stats, error: r.error } : r])
    : entries;
  return { ok: true, result: { results, corpus: out.corpus, cacheStats: out.cache || out.cacheStats || null, secrets: extractSecrets(findings) } };
}

function finish(answer) {
  process.stdout.write(`\u0001OASIS_RESULT\u0001${JSON.stringify(answer)}\n`, () => process.exit(answer.ok ? 0 : 1));
}

main().then(finish, (e) => finish({
  ok: false,
  error: { code: (e && typeof e.code === 'string' && e.code) || 'ENGINE_ERROR', message: String((e && e.message) || e).slice(0, 300) },
}));
