'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { runEngine, supportFromFlags, MAX_RESULT_BYTES } = require('./run');

const STUB = path.join(__dirname, '__fixtures__', 'core-stub');

const made = [];
test.after(() => { for (const d of made) fs.rmSync(d, { recursive: true, force: true }); });

function scratch() {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'run-engine-')));
  made.push(root);
  const repo = path.join(root, 'repo');
  fs.mkdirSync(repo);
  fs.writeFileSync(path.join(repo, 'a.js'), 'x');
  fs.writeFileSync(path.join(root, 'outside.txt'), 'outside');
  return { root, repo };
}

// Whether the Node running these tests can deny network to the child; tests that need it skip where it cannot.
const ENFORCES = supportFromFlags(process.allowedNodeEnvironmentFlags).netDenial;
const OPEN = { allowNetworkOpenEngine: true };

const run = (over) => {
  const { repo } = scratch();
  return runEngine({ corePath: STUB, repoPath: repo, ruleSet: { rules: [], mode: 'ok' }, scannerIds: ['demo'], timeoutMs: 15000, ...OPEN, ...over });
};
const withMode = (mode, extra = {}) => {
  const { repo } = scratch();
  return runEngine({ corePath: STUB, repoPath: repo, ruleSet: { rules: [], mode, ...extra }, scannerIds: ['demo'], timeoutMs: 15000, ...OPEN });
};
const rejectsWith = (p, code) => assert.rejects(p, (e) => { assert.strictEqual(e.code, code, `got ${e.code}: ${e.message}`); return true; });

test('a normal job returns the worker result shape', async () => {
  const r = await run({ files: ['a.js'] });
  assert.deepStrictEqual(Object.keys(r).sort(), ['cacheStats', 'corpus', 'networkDenied', 'results', 'secrets', 'skippedSymlinks']);
  assert.deepStrictEqual(r.results, [['demo', { findings: [{ id: 'r1', file: 'a.js', line: 1, fingerprint: 'fp1' }], stats: { files: 1 }, error: null }]]);
  assert.deepStrictEqual(r.secrets, [['fp1', 'synthetic-secret']]);
  assert.deepStrictEqual(r.cacheStats, { hits: 0, misses: 1 });
});

test('the child does not inherit the parent environment and the job is not on the command line', async () => {
  process.env.OASIS_CANARY_TOKEN = 'ghp_canary_value';
  process.env.NODE_OPTIONS = '--max-old-space-size=1';
  try {
    const r = await run();
    assert.ok(!r.corpus.env.includes('OASIS_CANARY_TOKEN'));
    assert.ok(!r.corpus.env.includes('NODE_OPTIONS'));
    // macOS adds __CF_USER_TEXT_ENCODING to every process itself.
    assert.ok(r.corpus.env.every((k) => ['NODE_NO_WARNINGS', 'ELECTRON_RUN_AS_NODE', '__CF_USER_TEXT_ENCODING'].includes(k)), JSON.stringify(r.corpus.env));
    assert.ok(!JSON.stringify(r.corpus.argv).includes('ghp_canary_value'));
    assert.ok(!r.corpus.argv.some((a) => a.includes('mode')), 'the job (rule set) must not appear in argv');
  } finally {
    delete process.env.OASIS_CANARY_TOKEN;
    delete process.env.NODE_OPTIONS;
  }
});

const REAL_FLAG = supportFromFlags(process.allowedNodeEnvironmentFlags).flag;
const ENFORCING = { flag: REAL_FLAG, netDenial: true };
const NOT_ENFORCING = { flag: REAL_FLAG, netDenial: false };

test('without network denial the runner refuses unless the caller opts in', async () => {
  const { repo } = scratch();
  const base = { corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok' }, timeoutMs: 15000, permissionSupport: NOT_ENFORCING };
  await assert.rejects(runEngine(base), (e) => {
    assert.strictEqual(e.code, 'NETWORK_DENIAL_UNAVAILABLE');
    assert.match(e.message, /cannot deny network/);
    assert.match(e.message, /allowNetworkOpenEngine/);
    return true;
  });
  await rejectsWith(runEngine({ ...base, allowNetworkOpenEngine: false }), 'NETWORK_DENIAL_UNAVAILABLE');
});

test('with the opt-in the engine runs and reports networkDenied: false', async () => {
  const { repo } = scratch();
  const r = await runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok' }, timeoutMs: 15000, permissionSupport: NOT_ENFORCING, ...OPEN });
  assert.strictEqual(r.networkDenied, false);
  assert.ok(r.results);
});

test('on a Node that enforces denial the engine runs without opt-in and reports networkDenied: true', async () => {
  const { repo } = scratch();
  const r = await runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok' }, timeoutMs: 15000, permissionSupport: ENFORCING });
  assert.strictEqual(r.networkDenied, true);
});

test('this Node reports its own capability honestly', async () => {
  const { repo } = scratch();
  const job = { corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok' }, timeoutMs: 15000 };
  if (ENFORCES) assert.strictEqual((await runEngine(job)).networkDenied, true);
  else await rejectsWith(runEngine(job), 'NETWORK_DENIAL_UNAVAILABLE');
});

test('the net-guard still stops fetch and http (defence in depth)', async () => {
  await rejectsWith(withMode('fetch'), 'EPERM_NETWORK');
  await rejectsWith(withMode('http'), 'EPERM_NETWORK');
});

test('raw sockets and the agent connection path are denied where the Node enforces denial', { skip: !ENFORCES && 'this Node cannot deny network' }, async () => {
  for (const mode of ['rawSocket', 'agentConn']) {
    // net-guard may stop the probe first (EPERM_NETWORK); either way it must not connect.
    await assert.rejects(withMode(mode), (e) => { assert.ok(['ERR_ACCESS_DENIED', 'EPERM_NETWORK'].includes(e.code), `${mode}: ${e.code} ${e.message}`); return true; });
  }
});

test('the Node 20 branch: no permission flag means PERMISSION_UNSUPPORTED, and the flag is chosen from what exists', async () => {
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok' }, permissionSupport: { flag: null, netDenial: false }, ...OPEN }), 'PERMISSION_UNSUPPORTED');
  assert.deepStrictEqual(supportFromFlags(new Set(['--experimental-permission'])), { flag: '--experimental-permission', netDenial: false });
  assert.deepStrictEqual(supportFromFlags(new Set(['--permission', '--experimental-permission'])), { flag: '--permission', netDenial: false });
  assert.deepStrictEqual(supportFromFlags(new Set(['--permission', '--allow-net'])), { flag: '--permission', netDenial: true });
  assert.deepStrictEqual(supportFromFlags(new Set(['--allow-net'])), { flag: null, netDenial: false });
});

test('a read outside corePath and repoPath is denied', { skip: process.platform === 'win32' }, async () => {
  await rejectsWith(withMode('readOutside', { target: '/etc/hosts' }), 'ERR_ACCESS_DENIED');
});

test('a sibling directory whose name merely starts with the repo name is not readable', async () => {
  const { root, repo } = scratch();
  const sibling = `${repo}-secret`;
  fs.mkdirSync(sibling);
  fs.writeFileSync(path.join(sibling, 'k.txt'), 'secret');
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'readOutside', target: path.join(sibling, 'k.txt') }, timeoutMs: 15000, ...OPEN }), 'ERR_ACCESS_DENIED');
});

test('files inside the repo are readable', async () => {
  const r = await withMode('readRepo', { target: 'a.js' });
  assert.ok(r.results);
});

test('a write fails, even inside the repo', async () => {
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'write' }, timeoutMs: 15000, ...OPEN }), 'ERR_ACCESS_DENIED');
  assert.ok(!fs.existsSync(path.join(repo, 'pwned.txt')));
});

test('no child processes and no worker threads', async () => {
  await rejectsWith(withMode('spawn'), 'ERR_ACCESS_DENIED');
  await rejectsWith(withMode('worker'), 'ERR_ACCESS_DENIED');
});

test('an engine error keeps its code', async () => {
  await rejectsWith(withMode('throwCoded'), 'MY_CODE');
});

function strays(marker) {
  if (process.platform === 'win32') return [];
  return execFileSync('ps', ['-ax', '-o', 'pid=,command='], { encoding: 'utf8' }).split('\n').filter((l) => l.includes(marker));
}

test('a job that loops forever is killed at timeoutMs and leaves no process behind', async () => {
  const { repo } = scratch();
  const t0 = Date.now();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'loop' }, timeoutMs: 700, ...OPEN }), 'TIMEOUT');
  assert.ok(Date.now() - t0 < 8000);
  assert.deepStrictEqual(strays(repo), []);
});

test('a job that exhausts the heap rejects with MEMORY_LIMIT', async () => {
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'heap' }, memoryMb: 64, timeoutMs: 30000, ...OPEN }), 'MEMORY_LIMIT');
  assert.deepStrictEqual(strays(repo), []);
});

test('memory outside the V8 heap (Buffers) is caught by the resident-memory cap', async () => {
  const { repo } = scratch();
  const t0 = Date.now();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'buffers' }, memoryMb: 64, timeoutMs: 30000, ...OPEN }), 'MEMORY_LIMIT');
  assert.ok(Date.now() - t0 < 15000, 'killed by the cap, not by the wall clock');
  assert.deepStrictEqual(strays(repo), []);
});

test('a result over the size cap rejects RESULT_TOO_LARGE and the child is killed', async () => {
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'huge', size: MAX_RESULT_BYTES + 1024 }, timeoutMs: 30000, ...OPEN }), 'RESULT_TOO_LARGE');
  assert.deepStrictEqual(strays(repo), []);
});

test('a malformed result rejects BAD_RESULT', async () => {
  await rejectsWith(withMode('malformed'), 'BAD_RESULT');
});

test('a flood on stderr does not break the job', async () => {
  const r = await withMode('stderr');
  assert.ok(r.results);
});

test('bad paths are refused before anything is spawned', async () => {
  const { root, repo } = scratch();
  const base = { ruleSet: { mode: 'ok' }, timeoutMs: 5000, ...OPEN };
  await rejectsWith(runEngine({ ...base, corePath: 'relative/core', repoPath: repo }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: path.join(root, 'missing') }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: path.join(root, 'outside.txt') }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: '/' }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: '/', repoPath: repo }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: STUB }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: path.join(STUB, '..') }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: `${repo},/etc` }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: `${repo}/*` }), 'BAD_PATH');
  await rejectsWith(runEngine({ ...base, corePath: STUB, repoPath: undefined }), 'BAD_PATH');
});

test('a symlinked repo path is resolved so it cannot widen the read set', async () => {
  const { root, repo } = scratch();
  const link = path.join(root, 'link');
  fs.symlinkSync(root, link);
  // The link resolves to root, which contains the repo and the stub is elsewhere: root is a valid repo, so reading
  // outside.txt works only because the real path is what was allowed.
  const r = await runEngine({ corePath: STUB, repoPath: link, ruleSet: { mode: 'readRepo', target: 'outside.txt' }, timeoutMs: 15000, ...OPEN });
  assert.ok(r.results);
  // And a link pointing at the root of the filesystem is refused.
  const rootLink = path.join(root, 'rootlink');
  fs.symlinkSync('/', rootLink);
  await rejectsWith(runEngine({ corePath: STUB, repoPath: rootLink, ruleSet: { mode: 'ok' }, timeoutMs: 5000, ...OPEN }), 'BAD_PATH');
});

test('an oversized job is refused before spawning', async () => {
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'ok', pad: 'x'.repeat(33 * 1024 * 1024) }, timeoutMs: 5000, ...OPEN }), 'JOB_TOO_LARGE');
});

test('a symlink inside the repo that points outside is neither read nor returned', async () => {
  const { root, repo } = scratch();
  fs.writeFileSync(path.join(root, 'secret.txt'), 'TOP-SECRET-OUTSIDE');
  fs.symlinkSync(path.join(root, 'secret.txt'), path.join(repo, 'link.txt'));
  fs.mkdirSync(path.join(root, 'outdir'));
  fs.writeFileSync(path.join(root, 'outdir', 'k.txt'), 'TOP-SECRET-OUTSIDE');
  fs.symlinkSync(path.join(root, 'outdir'), path.join(repo, 'dirlink'));
  // an inside link is fine
  fs.symlinkSync(path.join(repo, 'a.js'), path.join(repo, 'inner.js'));
  for (const files of [undefined, ['a.js', 'link.txt', 'dirlink/k.txt']]) {
    const r = await runEngine({ corePath: STUB, repoPath: repo, ruleSet: { mode: 'echoFiles' }, files, timeoutMs: 15000, ...OPEN });
    assert.ok(!JSON.stringify(r).includes('TOP-SECRET-OUTSIDE'), `files=${JSON.stringify(files)}`);
    assert.ok(r.skippedSymlinks >= 2);
    assert.ok(r.results[0][1].findings.some((f) => f.file === 'a.js'));
  }
});

test('output other than the framed answer is ignored; no frame means BAD_RESULT', async () => {
  const r = await withMode('noise');
  assert.ok(r.results);
  const { FRAME } = require('./run');
  assert.strictEqual(FRAME, '\u0001OASIS_RESULT\u0001');
  await rejectsWith(withMode('plainStdout'), 'BAD_RESULT');
});

test('findings and stats are validated', async () => {
  for (const which of ['null', 'numFp', 'numFile', 'str']) await rejectsWith(withMode('badFinding', { which }), 'BAD_RESULT');
  await rejectsWith(withMode('badStats'), 'BAD_RESULT');
});

test('findings as the real analyzer returns them (fingerprint not assigned yet) are accepted, and a secret travels keyed by its hash', async () => {
  const r = await withMode('realShape');
  const found = r.results[0][1].findings;
  assert.deepStrictEqual(found.map((f) => f.fingerprint), [null, null]);
  assert.deepStrictEqual(r.secrets, [['hash-of-secret', 'synthetic-secret']]);
});

test('a ruleSet that cannot be serialised rejects BAD_JOB', async () => {
  const circular = { mode: 'ok' };
  circular.self = circular;
  const { repo } = scratch();
  await rejectsWith(runEngine({ corePath: STUB, repoPath: repo, ruleSet: circular, timeoutMs: 5000, ...OPEN }), 'BAD_JOB');
});
