'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { signManifest } = require('./manifest');
const { createEngineLoader } = require('./index');

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const pack = (id, language, files) => zlib.gzipSync(JSON.stringify({ id, kind: language ? 'language' : 'core', language, version: 'v', files: files.map(([p, d]) => ({ path: p, b64: Buffer.from(d).toString('base64') })) }));

test('the loader exposes rules, the core path and grammar paths from the current release', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-'));
  try {
    const packs = {
      core: pack('core', null, [['src/index.js', '1']]),
      'lang-go': pack('lang-go', 'go', [['rules.json', '[{"id":"go-1"},{"id":"go-2"}]'], ['grammar/tree-sitter-go.wasm', 'W']]),
      'lang-yaml': pack('lang-yaml', 'yaml', [['rules.json', '[{"id":"y-1"}]']]),
    };
    const manifest = { release: 1, channel: 'stable', createdAt: 'x', minLoader: 1, packs: Object.entries(packs).map(([packId, b]) => ({ packId, kind: packId === 'core' ? 'core' : 'language', language: packId === 'core' ? null : packId.slice(5), version: 'v', sha256: sha(b), size: b.length })) };
    const signed = signManifest(manifest, privateKey.export({ type: 'pkcs8', format: 'pem' }), 'k1');
    const blobs = new Map(Object.values(packs).map((b) => [sha(b), b]));
    const fetchImpl = async (url) => {
      const u = new URL(url);
      if (u.pathname === '/v1/releases/latest') return Response.json({ ...signed, changedPackIds: Object.keys(packs) });
      return new Response(blobs.get(u.pathname.split('/').pop()));
    };
    const loader = createEngineLoader({ dir, baseUrl: 'https://rules.example.test', fetchImpl, publicKeys: { k1: publicKey.export({ type: 'spki', format: 'pem' }) } });
    assert.equal(loader.current(), null);
    assert.throws(() => loader.rulesFor(['go']), { code: 'NO_RULES_INSTALLED' });
    assert.equal((await loader.update()).status, 'updated');
    assert.deepEqual(loader.rulesFor(['go', 'yaml', 'cobol']).map((r) => r.id), ['go-1', 'go-2', 'y-1']);
    assert.ok(fs.existsSync(path.join(loader.corePath(), 'src/index.js')));
    assert.equal(fs.readFileSync(loader.grammarPath('go'), 'utf8'), 'W');
    assert.equal(loader.grammarPath('yaml'), null);
    assert.equal(loader.grammarPath('cobol'), null);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('a loader built without pinned keys refuses to update (NO_PINNED_KEYS)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-'));
  try {
    const loader = createEngineLoader({ dir, baseUrl: 'https://rules.example.test', fetchImpl: async () => { throw new Error('no network expected'); } });
    await assert.rejects(loader.update(), { code: 'NO_PINNED_KEYS' });
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('offline first run leaves rulesFor, corePath and grammarPath throwing NO_RULES_INSTALLED', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-'));
  try {
    const loader = createEngineLoader({ dir, baseUrl: 'https://rules.example.test', publicKeys: { k1: publicKey.export({ type: 'spki', format: 'pem' }) }, fetchImpl: async () => { throw new TypeError('fetch failed'); } });
    const r = await loader.update();
    assert.equal(r.status, 'offline');
    assert.equal(r.release, null);
    assert.throws(() => loader.rulesFor(['go']), { code: 'NO_RULES_INSTALLED' });
    assert.throws(() => loader.corePath(), { code: 'NO_RULES_INSTALLED' });
    assert.throws(() => loader.grammarPath('go'), { code: 'NO_RULES_INSTALLED' });
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

async function installed(packs) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-'));
  const manifest = { release: 1, channel: 'stable', createdAt: 'x', minLoader: 1, packs: Object.entries(packs).map(([packId, b]) => ({ packId, kind: packId === 'core' ? 'core' : 'language', language: packId === 'core' ? null : packId.slice(5), version: 'v', sha256: sha(b), size: b.length })) };
  const signed = signManifest(manifest, privateKey.export({ type: 'pkcs8', format: 'pem' }), 'k1');
  const blobs = new Map(Object.values(packs).map((b) => [sha(b), b]));
  const fetchImpl = async (url) => {
    const u = new URL(url);
    if (u.pathname === '/v1/releases/latest') return Response.json({ ...signed, changedPackIds: Object.keys(packs) });
    return new Response(blobs.get(u.pathname.split('/').pop()));
  };
  const loader = createEngineLoader({ dir, baseUrl: 'https://rules.example.test', fetchImpl, publicKeys: { k1: publicKey.export({ type: 'spki', format: 'pem' }) } });
  assert.equal((await loader.update()).status, 'updated');
  return { dir, loader };
}

test('a rules.json that is not an array throws BAD_PACK', async () => {
  const { dir, loader } = await installed({ core: pack('core', null, [['a', '1']]), 'lang-go': pack('lang-go', 'go', [['rules.json', '{"id":"x"}']]) });
  try { assert.throws(() => loader.rulesFor(['go']), { code: 'BAD_PACK' }); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('a language with no pack in an installed release gives [] and a null grammar path', async () => {
  const { dir, loader } = await installed({ core: pack('core', null, [['a', '1']]), 'lang-go': pack('lang-go', 'go', [['rules.json', '[]']]) });
  try {
    assert.deepEqual(loader.rulesFor(['cobol']), []);
    assert.equal(loader.grammarPath('cobol'), null);
    assert.equal(loader.grammarPath('go'), null);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

// ── DEV-ONLY trusted key file (OASIS_DEV_RULES_PUBLIC_KEYS) ────────────────────────────────────────────────────
test('with OASIS_DEV_RULES_PUBLIC_KEYS the loader installs a release signed by that key and rejects one signed by another', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-dev-'));
  const { resetWarnings } = require('./dev-keys');
  try {
    const keyFile = path.join(dir, 'dev-keys.json');
    fs.writeFileSync(keyFile, JSON.stringify({ 'dev-1': publicKey.export({ type: 'spki', format: 'pem' }) }));
    const packs = { core: pack('core', null, [['src/index.js', '1']]), 'lang-go': pack('lang-go', 'go', [['rules.json', '[{"id":"go-1"}]']]) };
    const manifest = { release: 1, channel: 'stable', createdAt: 'x', minLoader: 1, packs: Object.entries(packs).map(([packId, b]) => ({ packId, kind: packId === 'core' ? 'core' : 'language', language: packId === 'core' ? null : packId.slice(5), version: 'v', sha256: sha(b), size: b.length })) };
    const blobs = new Map(Object.values(packs).map((b) => [sha(b), b]));
    const service = (priv, keyId) => async (url) => {
      const u = new URL(url);
      if (u.pathname === '/v1/releases/latest') return Response.json({ ...signManifest(manifest, priv, keyId), changedPackIds: Object.keys(packs) });
      return new Response(blobs.get(u.pathname.split('/').pop()));
    };
    const good = privateKey.export({ type: 'pkcs8', format: 'pem' });
    const other = crypto.generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' });
    const env = { OASIS_DEV_RULES_PUBLIC_KEYS: keyFile };

    resetWarnings();
    const logs = [];
    const bad = createEngineLoader({ dir: path.join(dir, 'a'), baseUrl: 'https://rules.example.test', env, log: (m) => logs.push(m), fetchImpl: service(other, 'dev-1') });
    await assert.rejects(bad.update(), { code: 'BAD_SIGNATURE' });
    const unknown = createEngineLoader({ dir: path.join(dir, 'b'), baseUrl: 'https://rules.example.test', env, fetchImpl: service(good, 'dev-2') });
    await assert.rejects(unknown.update(), { code: 'UNKNOWN_KEY' });

    const loader = createEngineLoader({ dir: path.join(dir, 'c'), baseUrl: 'https://rules.example.test', env, log: (m) => logs.push(m), fetchImpl: service(good, 'dev-1') });
    assert.deepEqual(loader.devKeys(), ['dev-1']);
    const r = await loader.update();
    assert.equal(r.status, 'updated');
    assert.deepEqual(r.devKeys, ['dev-1']);
    assert.match(r.warning, /DEV rules signing key in use \(dev-1\)/);
    assert.deepEqual(loader.rulesFor(['go']).map((x) => x.id), ['go-1']);
    assert.equal(logs.filter((m) => /DEV rules signing key in use \(dev-1\)/.test(m)).length, 1, 'warned once');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('OASIS_DEV_RULES_PUBLIC_KEYS: a bad file is a coded error of update(); unset leaves NO_PINNED_KEYS', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-dev-'));
  try {
    const noNet = async () => { throw new Error('no network expected'); };
    const keyFile = path.join(dir, 'k.json');
    fs.writeFileSync(keyFile, JSON.stringify({ 'dev-1': privateKey.export({ type: 'pkcs8', format: 'pem' }) }));
    const l = createEngineLoader({ dir: path.join(dir, 'a'), baseUrl: 'https://rules.example.test', env: { OASIS_DEV_RULES_PUBLIC_KEYS: keyFile }, fetchImpl: noNet });
    await assert.rejects(l.update(), { code: 'DEV_KEY_PRIVATE' });
    assert.deepEqual(l.devKeys(), []);
    const none = createEngineLoader({ dir: path.join(dir, 'b'), baseUrl: 'https://rules.example.test', env: {}, fetchImpl: noNet });
    await assert.rejects(none.update(), { code: 'NO_PINNED_KEYS' });
    assert.deepEqual(none.devKeys(), []);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('devKeys() reports what the last update() trusted, even if the key file changes afterwards', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'engine-index-devkeys-'));
  const { resetWarnings } = require('./dev-keys');
  try {
    resetWarnings();
    const keyFile = path.join(dir, 'dev-keys.json');
    const pem = publicKey.export({ type: 'spki', format: 'pem' });
    fs.writeFileSync(keyFile, JSON.stringify({ 'dev-1': pem }), { mode: 0o600 });
    const loader = createEngineLoader({ dir: path.join(dir, 'rules'), baseUrl: 'https://rules.example.test', env: { OASIS_DEV_RULES_PUBLIC_KEYS: keyFile }, fetchImpl: async () => { throw new TypeError('fetch failed'); } });
    await loader.update();
    assert.deepEqual(loader.devKeys(), ['dev-1']);
    fs.writeFileSync(keyFile, JSON.stringify({ 'dev-2': pem }), { mode: 0o600 });
    assert.deepEqual(loader.devKeys(), ['dev-1'], 'unchanged until the next update() trusts the new file');
    await loader.update();
    assert.deepEqual(loader.devKeys(), ['dev-2']);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
