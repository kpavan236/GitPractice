'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { canonical, verifyManifest } = require('./manifest');

const golden = JSON.parse(fs.readFileSync(path.join(__dirname, '__fixtures__', 'golden-manifest.json'), 'utf8'));
const keys = () => ({ 'golden-throwaway': golden.publicKey });
const clone = (o) => JSON.parse(JSON.stringify(o));

test('the golden signed manifest verifies with the golden public key', () => {
  const m = verifyManifest(clone(golden.signed), keys());
  assert.equal(m.release, 3);
  assert.equal(m.channel, 'stable');
});

test('flipping one character of packs[0].sha256 throws BAD_SIGNATURE', () => {
  const s = clone(golden.signed);
  const h = s.manifest.packs[0].sha256;
  s.manifest.packs[0].sha256 = (h[0] === '0' ? '1' : '0') + h.slice(1);
  assert.throws(() => verifyManifest(s, keys()), { code: 'BAD_SIGNATURE' });
});

test('an unknown key id is refused', () => {
  assert.throws(() => verifyManifest(clone(golden.signed), {}), { code: 'UNKNOWN_KEY' });
});

test('canonical matches the service for a nested object (golden vector)', () => {
  const v = { z: [{ b: 1, a: [undefined, NaN, 'x\u00e9'] }, null], a: { d: true, c: undefined, b: 1.5 }, m: 'q"' };
  // Output of oasis-rule-server/src/manifest.js canonical() for the same input.
  assert.equal(canonical(v), '{"a":{"b":1.5,"d":true},"m":"q\\"","z":[{"a":[null,null,"x\u00e9"],"b":1},null]}');
});

test('the Oasis copy is byte-for-byte the service file when the sibling repo is present', (t) => {
  const svc = path.join(__dirname, '..', '..', '..', '..', 'oasis-rule-server', 'src', 'manifest.js');
  if (!fs.existsSync(svc)) return t.skip('sibling repo not present');
  assert.ok(fs.readFileSync(svc).equals(fs.readFileSync(path.join(__dirname, 'manifest.js'))));
});
