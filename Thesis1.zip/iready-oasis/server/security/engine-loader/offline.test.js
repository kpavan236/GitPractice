'use strict';
// Offline behaviour of the scan path: first run with nothing installed, no pinned keys, and a scan after the
// network is gone. The loader here is the real one; only the network is faked.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createEngineLoader } = require('./index');
const { buildRuleSet, ensureRules, NoRulesError } = require('../rule-set');
const { createOrchestrator } = require('../orchestrator');
const { scanner: patternScanner } = require('../scanners/pattern-sast');
const { createFindingsStore } = require('../findings-store');
const { installedLoader, offlineLoader, FAKE_CORE, tmpDir } = require('../test-support/loader');

const MESSAGE = 'No rules installed and the rules service is unreachable. Connect to the network once so the rules can be downloaded, then retry.';
const lang = { go: { extensions: ['.go'], rules: [{ id: 'go-1', language: 'go', severity: 'HIGH', query: 'q' }] } };

test('empty store and update() offline: buildRuleSet throws NO_RULES with the plan message; no scan runs zero rules', async (t) => {
  const loader = offlineLoader(t);
  assert.equal((await loader.update()).status, 'offline');
  assert.throws(() => buildRuleSet({ loader, languages: ['go'], projectKey: 'p', userRulesDir: null, plugins: [] }),
    (e) => e instanceof NoRulesError && e.code === 'NO_RULES' && e.message === MESSAGE);
  await assert.rejects(ensureRules(loader), (e) => e.code === 'NO_RULES' && e.message === MESSAGE);

  const o = createOrchestrator({ scanners: [patternScanner], dir: tmpDir(t), userRulesDir: null, userGrammarsDir: null, loader, env: { OASIS_ALLOW_OPEN_NETWORK_ENGINE: '1' } });
  t.after(() => o.shutdown());
  const repoPath = tmpDir(t);
  fs.writeFileSync(path.join(repoPath, 'a.go'), 'package main\n');
  await assert.rejects(o.startScan({ targets: [{ repository: 'org/a', repoPath }] }), (e) => e.code === 'NO_RULES' && e.message === MESSAGE);
  assert.deepEqual(await o.listFindings({}), []);
});

test('a build with no pinned signing keys says so, keeping NO_PINNED_KEYS as the cause', async (t) => {
  const loader = createEngineLoader({ dir: tmpDir(t), baseUrl: 'https://rules.example.test', fetchImpl: async () => { throw new Error('no network expected'); } });
  await assert.rejects(ensureRules(loader), (e) => e.code === 'NO_RULES' && e.cause.code === 'NO_PINNED_KEYS' && e.message.startsWith(MESSAGE) && /NO_PINNED_KEYS/.test(e.message));
});

test('once a release is installed, scans keep working with the network gone', async (t) => {
  const loader = await installedLoader(t, { release: 1, core: FAKE_CORE, languages: lang });
  loader.serve({ release: 1 });
  const dead = { ...loader, update: async () => ({ status: 'offline', release: 1, downloaded: [], error: 'NETWORK' }) };
  const o = createOrchestrator({ scanners: [patternScanner], dir: tmpDir(t), userRulesDir: null, userGrammarsDir: null, loader: dead, env: { OASIS_ALLOW_OPEN_NETWORK_ENGINE: '1' } });
  t.after(() => o.shutdown());
  const repoPath = tmpDir(t);
  fs.writeFileSync(path.join(repoPath, 'a.go'), 'package main\n');
  const scan = await o.startScan({ targets: [{ repository: 'org/a', repoPath }] });
  let s;
  for (let i = 0; i < 400; i += 1) { s = o.getScan(scan.id); if (s.status !== 'QUEUED' && s.status !== 'RUNNING') break; await new Promise((r) => setTimeout(r, 25)); }
  assert.equal(s.status, 'COMPLETED', s.error || '');
});

test('findings default to the local store: no rules URL configured, a scan\'s findings are read back', async (t) => {
  delete process.env.OASIS_RULE_SERVER_URL;
  const store = require('../store');
  const dir = tmpDir(t);
  const fstore = createFindingsStore({ store, dir, log: () => {} });
  assert.equal(fstore.mode, 'local');
  // even with a rule-server sync in hand, the caller can keep findings on this machine
  const withSync = createFindingsStore({ ruleSync: { client: {}, buildAnalysisPayload() {} }, store, dir, log: () => {}, remote: false });
  assert.equal(withSync.mode, 'local');
  const remote = createFindingsStore({ ruleSync: { client: {}, buildAnalysisPayload() {} }, store, dir, log: () => {} });
  assert.notEqual(remote.mode, 'local');
});
