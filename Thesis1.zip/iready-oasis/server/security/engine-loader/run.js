'use strict';
// Runs the downloaded scanning engine on a customer's source in a restricted child process.
//
// What the child gets: the Node permission model with read access to the core pack, the repository and its own two
// entry files; no write, no child processes, no worker threads, no native addons, no WASI. On a Node that has
// --allow-net the network is denied by the permission model; on one that does not (Electron 32 ships Node 20) the
// only network defence is net-guard.js, which is not a security boundary. The child gets an EMPTY environment, the
// job on stdin only, and is killed (whole process group) on any rejection.
//
// Network: denied by the permission model on a Node that has --allow-net (Node 25+). On any other Node (Electron 32
// ships Node 20) the permission model does not cover the network, net-guard.js is bypassable, and runEngine REFUSES
// (NETWORK_DENIAL_UNAVAILABLE) unless the caller passes allowNetworkOpenEngine: true. The result says networkDenied.
//
// Residual risks (inherent or accepted):
//  - The child can still signal its parent and dlopen-style tricks are only as closed as Node's permission model.
//  - A detached child can outlive a crashed parent (the parent's kill is the only reaper; the wall clock dies with it).
//  - Windows has no RSS poll and gets a minimal environment.
//  - Symlinks that leave the repo are screened before the job starts; one created later in the scan is not.
//
// Limits and what they honestly are:
//  - timeoutMs is a hard wall clock.
//  - memoryMb becomes --max-old-space-size, which caps the V8 heap only. Buffers and WASM memory are outside it, so
//    the parent also polls the child's resident set (ps, macOS/Linux) and kills it above memoryMb + RSS_HEADROOM_MB.
//    That is a poll every RSS_POLL_MS, not a hard cap: a fast allocation can overshoot between polls, and on
//    Windows there is no RSS poll at all (heap cap and wall clock only).
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn, execFile, execFileSync } = require('node:child_process');

const MAX_JOB_BYTES = 32 * 1024 * 1024;
const MAX_RESULT_BYTES = 64 * 1024 * 1024;
const MAX_STDERR_BYTES = 16 * 1024;
const DEFAULT_TIMEOUT_MS = 10 * 60 * 1000;
const RSS_HEADROOM_MB = 256;
const RSS_POLL_MS = 250;

const CHILD = fs.realpathSync(path.join(__dirname, 'engine-child.js'));
const GUARD = fs.realpathSync(path.join(__dirname, 'net-guard.js'));
const FRAME = '\u0001OASIS_RESULT\u0001';

const fail = (code, message) => Object.assign(new Error(message), { code });

function checkDir(label, p) {
  if (typeof p !== 'string' || !path.isAbsolute(p) || /[\0,*?]/.test(p)) throw fail('BAD_PATH', `${label} must be an absolute path without wildcards or commas`);
  let real;
  try { real = fs.realpathSync(p); } catch { throw fail('BAD_PATH', `${label} does not exist`); }
  if (!fs.statSync(real).isDirectory()) throw fail('BAD_PATH', `${label} is not a directory`);
  if (real === path.parse(real).root) throw fail('BAD_PATH', `${label} must not be the filesystem root`);
  return real;
}

const inside = (child, parent) => child === parent || child.startsWith(parent.endsWith(path.sep) ? parent : parent + path.sep);

// Pure: what a Node with these allowed flags can do. Exported so the Node 20 branch is testable on any Node.
function supportFromFlags(flags) {
  const flag = flags.has('--permission') ? '--permission' : flags.has('--experimental-permission') ? '--experimental-permission' : null;
  return { flag, netDenial: flag === '--permission' && flags.has('--allow-net') };
}

let detected = null;
// Asks the Node that will actually be spawned. Under Electron that is the bundled Node, so it is probed once.
function detectPermissionSupport() {
  if (detected) return detected;
  if (!process.versions.electron) return (detected = supportFromFlags(process.allowedNodeEnvironmentFlags));
  try {
    const out = execFileSync(process.execPath, ['-e', "process.stdout.write(JSON.stringify([...process.allowedNodeEnvironmentFlags].filter(f=>/permission|allow-net/.test(f))))"],
      { env: { ELECTRON_RUN_AS_NODE: '1' }, timeout: 10000, encoding: 'utf8', windowsHide: true });
    return (detected = supportFromFlags(new Set(JSON.parse(out))));
  } catch {
    return { flag: null, netDenial: false };
  }
}

function permissionFlag(support) {
  if (!support.flag) throw fail('PERMISSION_UNSUPPORTED', 'this Node has no permission model, so the engine will not run unsandboxed');
  return support.flag;
}

// Symlinks that resolve outside the repo are how a hostile repo would make the engine read the owner's files. The
// walk never follows links; only escaping ones are counted. Returns { skipped: Set(relative paths), count }.
function findEscapingLinks(repo) {
  const skipped = new Set();
  const stack = [''];
  while (stack.length) {
    const rel = stack.pop();
    let entries;
    try { entries = fs.readdirSync(path.join(repo, rel), { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const r = rel ? path.join(rel, e.name) : e.name;
      if (e.isSymbolicLink()) {
        let real = null;
        try { real = fs.realpathSync(path.join(repo, r)); } catch { /* dangling: nothing to read */ }
        if (real === null || !inside(real, repo)) skipped.add(r);
      } else if (e.isDirectory()) stack.push(r);
    }
  }
  return skipped;
}

function listFiles(repo, files) {
  const skipped = findEscapingLinks(repo);
  if (Array.isArray(files)) {
    const keep = [];
    for (const f of files) {
      if (typeof f !== 'string') { keep.push(f); continue; }
      let real;
      try { real = fs.realpathSync(path.resolve(repo, f)); } catch { keep.push(f); continue; }
      if (inside(real, repo)) keep.push(f); else skipped.add(f);
    }
    return { files: keep, skippedSymlinks: skipped.size };
  }
  if (!skipped.size) return { files, skippedSymlinks: 0 };
  const all = [];
  const stack = [''];
  while (stack.length) {
    const rel = stack.pop();
    let entries;
    try { entries = fs.readdirSync(path.join(repo, rel), { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const r = rel ? path.join(rel, e.name) : e.name;
      if (skipped.has(r)) continue;
      if (e.isDirectory()) stack.push(r);
      else if (e.isFile() || e.isSymbolicLink()) all.push(r.split(path.sep).join('/'));
    }
  }
  return { files: all.sort(), skippedSymlinks: skipped.size };
}

// Environment the child is built from: nothing of the parent's. Tokens live in process.env of the parent.
function childEnv() {
  const env = { NODE_NO_WARNINGS: '1' };
  if (process.versions.electron) env.ELECTRON_RUN_AS_NODE = '1';
  return env;
}

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const optStr = (v) => v === undefined || v === null || typeof v === 'string';

// The analyzer returns findings WITHOUT a fingerprint (null): the host assigns it when it deduplicates. A fingerprint, if
// present, must be a non-empty string.
function isFinding(f) {
  return isObj(f) && (f.fingerprint === null || f.fingerprint === undefined || (typeof f.fingerprint === 'string' && f.fingerprint !== ''))
    && optStr(f.file) && optStr(f.id) && optStr(f.ruleId) && optStr(f.rule);
}

function isShape(r) {
  return isObj(r)
    && Array.isArray(r.results)
    && r.results.every((e) => Array.isArray(e) && e.length === 2 && typeof e[0] === 'string' && isObj(e[1])
      && Array.isArray(e[1].findings) && e[1].findings.every(isFinding)
      && (e[1].stats == null || isObj(e[1].stats)) && (e[1].error == null || isObj(e[1].error)))
    && isObj(r.corpus)
    && (r.cacheStats === null || isObj(r.cacheStats))
    && Array.isArray(r.secrets)
    && r.secrets.every((s) => Array.isArray(s) && s.length === 2 && typeof s[0] === 'string' && typeof s[1] === 'string');
}

// The child frames its answer; anything else it printed (a console.log in a rule) is ignored.
function extractFrame(buf) {
  const text = buf.toString('utf8');
  const at = text.lastIndexOf(FRAME);
  if (at < 0) return null;
  const end = text.indexOf('\n', at);
  try { return JSON.parse(text.slice(at + FRAME.length, end < 0 ? undefined : end)); } catch { return null; }
}

function residentMb(pid) {
  return new Promise((resolve) => {
    execFile('ps', ['-o', 'rss=', '-p', String(pid)], { timeout: 2000 }, (err, out) => {
      const kb = err ? NaN : parseInt(out, 10);
      resolve(Number.isFinite(kb) ? kb / 1024 : null);
    });
  });
}

/**
 * @param {object} [o.permissionSupport] test seam: { flag, netDenial } instead of asking the Node that will be spawned
 * @param {boolean} [o.allowNetworkOpenEngine] run even where the Node cannot deny network (result says networkDenied:false)
 * @returns {Promise<{results: Array, corpus: object, cacheStats: object|null, secrets: Array, networkDenied: boolean, skippedSymlinks: number}>}
 */
function runEngine({ corePath, repoPath, ruleSet, scannerIds, timeoutMs = DEFAULT_TIMEOUT_MS, memoryMb = 1024, files, repository, maxFiles, allowNetworkOpenEngine = false, permissionSupport } = {}) {
  let core, repo, args, input, networkDenied, skippedSymlinks;
  try {
    core = checkDir('corePath', corePath);
    repo = checkDir('repoPath', repoPath);
    if (inside(core, repo) || inside(repo, core)) throw fail('BAD_PATH', 'corePath and repoPath must not contain one another');
    if (!Number.isInteger(timeoutMs) || timeoutMs < 1) throw fail('BAD_PATH', 'timeoutMs must be a positive integer');
    if (!Number.isInteger(memoryMb) || memoryMb < 16 || memoryMb > 65536) throw fail('BAD_PATH', 'memoryMb must be an integer between 16 and 65536');
    const support = permissionSupport || detectPermissionSupport();
    const flag = permissionFlag(support);
    networkDenied = support.netDenial === true;
    if (!networkDenied && allowNetworkOpenEngine !== true) {
      throw fail('NETWORK_DENIAL_UNAVAILABLE', `the Node in use (${process.versions.electron ? `Electron ${process.versions.electron}, Node ${process.versions.node}` : `Node ${process.versions.node}`}) cannot deny network access to the engine; run the engine on Node 25 or later, or pass allowNetworkOpenEngine: true to accept a network-open engine`);
    }
    const listed = listFiles(repo, files);
    skippedSymlinks = listed.skippedSymlinks;
    try {
      input = JSON.stringify({ corePath: core, repoPath: repo, ruleSet, scannerIds, files: listed.files, repository, maxFiles });
    } catch (e) { throw fail('BAD_JOB', `the job cannot be serialised: ${e.message}`); }
    if (Buffer.byteLength(input) > MAX_JOB_BYTES) throw fail('JOB_TOO_LARGE', `job exceeds ${MAX_JOB_BYTES} bytes`);
    args = [
      flag,
      `--allow-fs-read=${core}`,
      `--allow-fs-read=${repo}`,
      `--allow-fs-read=${CHILD}`,
      `--allow-fs-read=${GUARD}`,
      `--max-old-space-size=${memoryMb}`,
      '--require', GUARD,
      CHILD,
    ];
  } catch (e) {
    return Promise.reject(e);
  }

  return new Promise((resolve, reject) => {
    const posix = process.platform !== 'win32';
    const child = spawn(process.execPath, args, { env: childEnv(), cwd: os.tmpdir(), stdio: ['pipe', 'pipe', 'pipe'], detached: posix, windowsHide: true });
    const out = [];
    let outBytes = 0;
    let stderrTail = '';
    let settled = false;
    let exited = false;
    let pending = null; // error to report once the child is really gone
    const timers = [];

    const kill = () => {
      if (exited) return;
      try { if (posix) process.kill(-child.pid, 'SIGKILL'); else child.kill('SIGKILL'); } catch { try { child.kill('SIGKILL'); } catch { /* gone */ } }
    };
    const abort = (err) => {
      if (settled || pending) return;
      pending = err;
      timers.forEach(clearTimeout);
      kill();
    };

    timers.push(setTimeout(() => abort(fail('TIMEOUT', `the engine did not finish within ${timeoutMs} ms`)), timeoutMs));

    if (posix) {
      const limit = memoryMb + RSS_HEADROOM_MB;
      let busy = false;
      const poll = setInterval(async () => {
        if (busy || exited || pending) return;
        busy = true;
        const mb = await residentMb(child.pid);
        busy = false;
        if (mb !== null && mb > limit && !exited) abort(fail('MEMORY_LIMIT', `the engine used more than ${limit} MB of resident memory`));
      }, RSS_POLL_MS);
      timers.push(poll);
    }

    child.stdout.on('data', (c) => {
      outBytes += c.length;
      if (outBytes > MAX_RESULT_BYTES) { abort(fail('RESULT_TOO_LARGE', `the engine result exceeds ${MAX_RESULT_BYTES} bytes`)); return; }
      out.push(c);
    });
    child.stderr.on('data', (c) => { stderrTail = (stderrTail + c.toString('latin1')).slice(-MAX_STDERR_BYTES); });
    child.stdin.on('error', () => { /* the child died before reading the job; the close handler reports why */ });
    child.on('error', (e) => abort(fail('SPAWN_FAILED', e.message)));

    child.on('close', (code, signal) => {
      exited = true;
      timers.forEach((t) => { clearTimeout(t); clearInterval(t); });
      if (settled) return;
      settled = true;
      if (pending) return reject(pending);
      const oom = code !== 0 && /heap out of memory|allocation failed|ERR_WORKER_OUT_OF_MEMORY/i.test(stderrTail);
      const answer = extractFrame(Buffer.concat(out));
      if (answer && answer.ok === false && answer.error) {
        return reject(fail(typeof answer.error.code === 'string' ? answer.error.code : 'ENGINE_ERROR', String(answer.error.message || 'engine failed').slice(0, 300)));
      }
      if (oom) return reject(fail('MEMORY_LIMIT', 'the engine ran out of memory'));
      if (code !== 0 && !answer) return reject(fail('CHILD_EXIT', `the engine exited with ${signal ? `signal ${signal}` : `code ${code}`}`));
      if (!answer || answer.ok !== true || !isShape(answer.result)) return reject(fail('BAD_RESULT', 'the engine returned a malformed result'));
      resolve({ results: answer.result.results, corpus: answer.result.corpus, cacheStats: answer.result.cacheStats, secrets: answer.result.secrets, networkDenied, skippedSymlinks });
    });

    child.stdin.end(input);
  });
}

module.exports = { runEngine, supportFromFlags, FRAME, MAX_JOB_BYTES, MAX_RESULT_BYTES, MAX_STDERR_BYTES, RSS_HEADROOM_MB };
