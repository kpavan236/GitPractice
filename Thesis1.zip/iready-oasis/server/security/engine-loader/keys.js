'use strict';
// The two Ed25519 public keys the rules service signs releases with, as { keyId: publicKeyPem }.
// EMPTY until the owner supplies them: generate with oasis-rule-server/scripts/gen-signing-key.js, then paste the two
// PUBLIC PEMs here ('rules-2026-a', 'rules-2026-b'). Never put a private key here. While this is empty, `update`
// refuses with NO_PINNED_KEYS rather than trusting anything. Tests inject their own keys. For local development only,
// dev-keys.js can add public keys from a file named by OASIS_DEV_RULES_PUBLIC_KEYS; it never replaces these.
const PINNED_KEYS = Object.freeze({});

module.exports = { PINNED_KEYS };
