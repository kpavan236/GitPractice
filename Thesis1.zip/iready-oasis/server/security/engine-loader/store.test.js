'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { createStore, decodePack, LIMITS } = require('./store');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'engine-store-'));
const done = (d) => fs.rmSync(d, { recursive: true, force: true });
const NAMES = { MAX_PACK_UNPACKED_BYTES: 'number', MAX_PACK_FILES: 'number', MAX_RELEASE_UNPACKED_BYTES: 'number', MAX_RELEASE_FILES: 'number' };

// Test-side inverse of the service's encodePack, deliberately without the service's path checks so hostile packs can be built.
const pack = (files, meta = {}) => zlib.gzipSync(JSON.stringify({
  id: 'p', kind: 'language', language: 'go', version: 'v1', ...meta,
  files: files.map(([p, d]) => ({ path: p, b64: Buffer.from(d).toString('base64') })),
}));
const M = (release, packs = [{ packId: 'p', kind: 'language', language: 'go', version: 'v1', sha256: 'a'.repeat(64), size: 1 }]) =>
  ({ release, channel: 'stable', createdAt: 'x', minLoader: 1, packs });
const publish = (store, n, files = [['rules.json', `[${n}]`]], manifest = M(n)) => {
  const st = store.stage(n);
  st.writePack('p', files.length ? pack(files) : pack([]));
  st.setManifest({ manifest, keyId: 'k', signature: 's' });
  store.activate(n);
};

test('limits are named constants', () => {
  for (const [k, t] of Object.entries(NAMES)) assert.equal(typeof LIMITS[k], t, k);
});

test('current() is null on an empty store; activate switches current()', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    assert.equal(s.current(), null);
    publish(s, 1);
    let c = s.current();
    assert.equal(c.release, 1);
    assert.equal(fs.readFileSync(path.join(c.packDirs.p, 'rules.json'), 'utf8'), '[1]');
    assert.equal(c.manifest.release, 1);
    publish(s, 2);
    c = s.current();
    assert.equal(c.release, 2);
    assert.equal(s.previous(), 1);
  } finally { done(d); }
});

test('a crash inside stage before activate leaves current() unchanged and no staging litter', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    publish(s, 1);
    const st = s.stage(2);
    st.writePack('p', pack([['rules.json', '[2]']]));
    assert.throws(() => st.writePack('p2', Buffer.from('not a gzip')));
    st.abort();
    assert.equal(s.current().release, 1);
    assert.equal(fs.existsSync(path.join(d, 'releases', '2')), false);
    assert.deepEqual(fs.readdirSync(path.join(d, 'staging')), []);
  } finally { done(d); }
});

test('a process killed after staging (no abort) leaves current() and a fresh store cleans the staging litter', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    publish(s, 1);
    const st = s.stage(2);
    st.writePack('p', pack([['rules.json', '[2]']]));   // "kill" here: neither activate nor abort
    const s2 = createStore(d);
    assert.equal(s2.current().release, 1);
    assert.deepEqual(fs.readdirSync(path.join(d, 'staging')), []);
  } finally { done(d); }
});

test('a crash between moving the release into place and writing current.json keeps the old current', () => {
  const d = tmp();
  try {
    publish(createStore(d), 1);
    const crashing = { ...fs, renameSync: (a, b) => { if (String(b).endsWith('current.json')) throw new Error('killed'); return fs.renameSync(a, b); } };
    const s = createStore(d, { fs: crashing });
    const st = s.stage(2);
    st.writePack('p', pack([['rules.json', '[2]']]));
    st.setManifest({ manifest: M(2), keyId: 'k', signature: 's' });
    assert.throws(() => s.activate(2), /killed/);
    const again = createStore(d);
    assert.equal(again.current().release, 1);
    assert.deepEqual(fs.readdirSync(d).filter((f) => f.startsWith('current.json.')), []);
  } finally { done(d); }
});

test('rollback() returns to the previous release, once', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    publish(s, 1); publish(s, 2);
    assert.equal(s.rollback(), 1);
    assert.equal(s.current().release, 1);
    assert.equal(s.previous(), null);
    assert.throws(() => s.rollback(), { code: 'NO_PREVIOUS' });
  } finally { done(d); }
});

test('gc(2) keeps the current and previous releases and removes older directories and unreferenced blobs', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    const sha = (n) => require('node:crypto').createHash('sha256').update(`blob${n}`).digest('hex');
    for (const n of [1, 2, 3, 4]) {
      s.writeBlob(sha(n), Buffer.from(`blob${n}`));
      publish(s, n, [['rules.json', `[${n}]`]], M(n, [{ packId: 'p', kind: 'language', language: 'go', version: 'v', sha256: sha(n), size: 1 }]));
    }
    s.gc(2);
    assert.deepEqual(fs.readdirSync(path.join(d, 'releases')).sort(), ['3', '4']);
    assert.deepEqual(fs.readdirSync(path.join(d, 'blobs')).sort(), [sha(3), sha(4)].sort());
    assert.equal(s.current().release, 4);
    assert.equal(s.previous(), 3);
  } finally { done(d); }
});

test('current.json is replaced by write-to-temp then rename (no partial file is ever read)', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    publish(s, 1);
    const seen = [];
    const spy = { ...fs, renameSync: (a, b) => { seen.push([path.basename(a), path.basename(b)]); return fs.renameSync(a, b); } };
    const s2 = createStore(d, { fs: spy });
    const st = s2.stage(2);
    st.writePack('p', pack([['rules.json', '[2]']]));
    st.setManifest({ manifest: M(2), keyId: 'k', signature: 's' });
    s2.activate(2);
    const last = seen[seen.length - 1];
    assert.equal(last[1], 'current.json');
    assert.match(last[0], /^current\.json\..+\.tmp$/);
  } finally { done(d); }
});

test('stage refuses a pack id that is not a plain name', () => {
  const d = tmp();
  try {
    const st = createStore(d).stage(1);
    for (const id of ['..', '../x', 'a/b', '', '.', 'a\\b']) assert.throws(() => st.writePack(id, pack([['a', 'b']])), { code: 'UNSAFE_PATH' }, id);
    st.abort();
  } finally { done(d); }
});

// ---- decodePack: untrusted input ----
const refuse = (files, code, opts) => assert.throws(() => decodePack(pack(files), opts), { code }, JSON.stringify(files.map((f) => f[0])));

test('decodePack refuses unsafe paths', () => {
  for (const p of ['/etc/passwd', '../x', 'a/../b', 'a/./b', 'a\\b', 'a\0b', 'C:/x', 'c:x', 'a//b', '', 'a/', 'caf\u00e9', 'cafe\u0301', '\u0430', 'a\nb']) {
    refuse([[p, 'x']], 'UNSAFE_PATH');
  }
});

test('decodePack refuses case-insensitive duplicates and a file used as a directory', () => {
  refuse([['a.json', '1'], ['A.JSON', '2']], 'DUPLICATE_PATH');
  refuse([['a', '1'], ['a', '2']], 'DUPLICATE_PATH');
  refuse([['a', '1'], ['a/b', '2']], 'DUPLICATE_PATH');
});

test('decodePack enforces the file-count and unpacked-size caps', () => {
  refuse([['a', 'x'], ['b', 'x'], ['c', 'x']], 'PACK_TOO_MANY_FILES', { maxFiles: 2 });
  refuse([['a', '12345'], ['b', '12345']], 'PACK_TOO_LARGE', { maxBytes: 9 });
  assert.equal(decodePack(pack([['a', '12345'], ['b', '1234']]), { maxBytes: 9, maxFiles: 2 }).files.length, 2);
});

test('decodePack caps a decompression bomb before it is parsed', () => {
  const bomb = zlib.gzipSync(Buffer.alloc(4 * 1024 * 1024, 0x20));
  assert.throws(() => decodePack(bomb, { maxBytes: 1024, maxFiles: 1 }), { code: 'PACK_TOO_LARGE' });
});

test('decodePack refuses malformed packs', () => {
  assert.throws(() => decodePack(Buffer.from('nope')), { code: 'BAD_PACK' });
  assert.throws(() => decodePack(zlib.gzipSync('{"files":5}')), { code: 'BAD_PACK' });
  assert.throws(() => decodePack(zlib.gzipSync(JSON.stringify({ id: 'p', files: [{ path: 'a', b64: 7 }] }))), { code: 'BAD_PACK' });
});

test('the release-wide caps stop a pack that would push the staged release over', () => {
  const d = tmp();
  try {
    const st = createStore(d, { limits: { MAX_RELEASE_UNPACKED_BYTES: 8, MAX_RELEASE_FILES: 100 } }).stage(1);
    st.writePack('a', pack([['x', '12345']], { id: 'a' }));
    assert.throws(() => st.writePack('b', pack([['x', '12345']], { id: 'b' })), { code: 'PACK_TOO_LARGE' });
    st.abort();
    const st2 = createStore(d, { limits: { MAX_RELEASE_UNPACKED_BYTES: 1000, MAX_RELEASE_FILES: 2 } }).stage(1);
    st2.writePack('a', pack([['x', '1'], ['y', '1']], { id: 'a' }));
    assert.throws(() => st2.writePack('b', pack([['x', '1']], { id: 'b' })), { code: 'PACK_TOO_MANY_FILES' });
    st2.abort();
  } finally { done(d); }
});

test('unpacking stays inside the staged directory, makes only regular files, and leaves no temp files', () => {
  const d = tmp();
  try {
    const s = createStore(d);
    const st = s.stage(1);
    st.writePack('p', pack([['grammar/x.wasm', 'W'], ['rules.json', '[]'], ['node_modules/m/i.js', 'm']]));
    st.setManifest({ manifest: M(1), keyId: 'k', signature: 's' });
    s.activate(1);
    const root = s.current().packDirs.p;
    const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
      const f = path.join(dir, e.name);
      assert.equal(e.isSymbolicLink(), false);
      return e.isDirectory() ? walk(f) : [path.relative(root, f)];
    });
    assert.deepEqual(walk(root).sort(), ['grammar/x.wasm', 'node_modules/m/i.js', 'rules.json']);
    assert.equal(fs.readdirSync(path.join(d, 'releases')).join(), '1');
  } finally { done(d); }
});

test('a symlink planted in the staging directory cannot redirect a write outside it', () => {
  const d = tmp(); const outside = tmp();
  try {
    const s = createStore(d);
    const st = s.stage(1);
    st.writePack('p', pack([['a/one', '1']]));
    // an attacker (or a bug) swaps a directory for a symlink between two writes
    const pdir = path.join(st.dir, 'q');
    fs.symlinkSync(outside, pdir);
    assert.throws(() => st.writePack('q', pack([['evil', 'x']], { id: 'q' })), { code: 'UNSAFE_PATH' });
    assert.deepEqual(fs.readdirSync(outside), []);
    st.abort();
  } finally { done(d); done(outside); }
});

test('both decoders agree on the golden pack bytes produced by the service', () => {
  const bytes = fs.readFileSync(path.join(__dirname, '__fixtures__', 'golden-pack.bin'));
  const ours = decodePack(bytes);
  const view = { id: ours.id, kind: ours.kind, language: ours.language, version: ours.version, files: ours.files.map((f) => [f.path, f.data.toString('hex')]) };
  assert.deepEqual(view, {
    id: 'lang-go', kind: 'language', language: 'go', version: 'v1',
    files: [['grammar/tree-sitter-go.wasm', '0061736d01000000'], ['pack.json', Buffer.from('{"id":"lang-go"}').toString('hex')], ['rules.json', Buffer.from('[{"id":"go-1"}]').toString('hex')]],
  });
  const svc = path.join(__dirname, '..', '..', '..', '..', 'oasis-rule-server', 'src', 'packs', 'blobs.js');
  if (fs.existsSync(svc)) {
    const theirs = require(svc).decodePack(bytes);
    assert.deepEqual(theirs.files.map((f) => [f.path, f.data.toString('hex')]), view.files);
  }
});
