'use strict';
// Release store: dir/releases/<n>/<packId>/<files>, dir/blobs/<sha256>, dir/current.json.
// A release is built under dir/staging, then moved into place with one rename, and made current by replacing
// current.json with a rename (atomic), so a crash at any point leaves the previous release as current().
// Everything that comes out of a pack is untrusted: see decodePack and writeFiles.
const nodeFs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

const LIMITS = Object.freeze({
  MAX_PACK_UNPACKED_BYTES: 256 * 1024 * 1024,
  MAX_PACK_FILES: 20000,
  MAX_RELEASE_UNPACKED_BYTES: 768 * 1024 * 1024,
  MAX_RELEASE_FILES: 60000,
});

const coded = (code, message) => Object.assign(new Error(message), { code });
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const isInt = (n) => Number.isInteger(n) && n > 0;
const PACK_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const HEX64 = /^[0-9a-f]{64}$/;

// Printable ASCII only: we refuse non-ASCII names instead of normalising (NFC and NFD spellings of one name would be
// two files on Linux and one on macOS). NFC-equal is checked too so the rule reads the same as the policy.
function assertSafePath(p) {
  const bad = typeof p !== 'string' || p === '' || p !== p.normalize('NFC')
    || !/^[\x20-\x7e]+$/.test(p) || p.startsWith('/') || /^[A-Za-z]:/.test(p)
    || /[\\<>:"|?*]/.test(p)
    || p.split('/').some((s) => s === '' || s === '.' || s === '..' || /[. ]$/.test(s));
  if (bad) throw coded('UNSAFE_PATH', `unsafe pack path: ${JSON.stringify(p)}`);
}

function assertNoCollisions(paths) {
  const seen = new Map();
  for (const p of paths) {
    const key = p.toLowerCase();
    if (seen.has(key)) throw coded('DUPLICATE_PATH', `duplicate pack path: ${JSON.stringify(seen.get(key))} and ${JSON.stringify(p)}`);
    seen.set(key, p);
  }
  for (const key of seen.keys()) {
    for (let i = key.indexOf('/'); i !== -1; i = key.indexOf('/', i + 1)) {
      if (seen.has(key.slice(0, i))) throw coded('DUPLICATE_PATH', `${JSON.stringify(seen.get(key.slice(0, i)))} is both a file and a directory`);
    }
  }
}

/** Gunzip + parse a pack with size and count caps; every path is validated. Pure: touches no disk. */
function decodePack(buf, { maxBytes = LIMITS.MAX_PACK_UNPACKED_BYTES, maxFiles = LIMITS.MAX_PACK_FILES } = {}) {
  let json;
  try {
    // base64 inflates 4/3, plus a little JSON per file; anything bigger cannot be a pack within the caps.
    json = zlib.gunzipSync(buf, { maxOutputLength: Math.ceil(maxBytes * 4 / 3) + maxFiles * 512 + 4096 }).toString('utf8');
  } catch (e) {
    if (e.code === 'ERR_BUFFER_TOO_LARGE') throw coded('PACK_TOO_LARGE', 'pack expands beyond the size cap');
    throw coded('BAD_PACK', `pack is not valid gzip: ${e.message}`);
  }
  let p;
  try { p = JSON.parse(json); } catch { throw coded('BAD_PACK', 'pack is not valid JSON'); }
  if (!p || typeof p !== 'object' || typeof p.id !== 'string' || !Array.isArray(p.files)) throw coded('BAD_PACK', 'pack has no id or files');
  if (p.files.length > maxFiles) throw coded('PACK_TOO_MANY_FILES', `pack has more than ${maxFiles} files`);
  let total = 0;
  const files = p.files.map((f) => {
    if (!f || typeof f.b64 !== 'string') throw coded('BAD_PACK', 'pack file entry is malformed');
    assertSafePath(f.path);
    total += Math.floor(f.b64.length * 3 / 4);
    if (total > maxBytes + 3 * p.files.length) throw coded('PACK_TOO_LARGE', `pack unpacks beyond ${maxBytes} bytes`);
    return { path: f.path, data: Buffer.from(f.b64, 'base64') };
  });
  assertNoCollisions(files.map((f) => f.path).sort());
  if (files.reduce((n, f) => n + f.data.length, 0) > maxBytes) throw coded('PACK_TOO_LARGE', `pack unpacks beyond ${maxBytes} bytes`);
  return { id: p.id, kind: p.kind, language: p.language, version: p.version, files };
}

function createStore(dir, { fs = nodeFs, limits = {} } = {}) {
  const lim = { ...LIMITS, ...limits };
  const releasesDir = path.join(dir, 'releases');
  const blobsDir = path.join(dir, 'blobs');
  const stagingRoot = path.join(dir, 'staging');
  const currentFile = path.join(dir, 'current.json');
  const rnd = () => crypto.randomBytes(6).toString('hex');
  const stages = new Map();

  fs.mkdirSync(dir, { recursive: true });
  // A previous process killed mid-update leaves staging litter; nothing in it was ever current.
  fs.rmSync(stagingRoot, { recursive: true, force: true });
  fs.mkdirSync(stagingRoot, { recursive: true });
  for (const f of fs.readdirSync(dir)) if (/^current\.json\..+\.tmp$/.test(f)) fs.rmSync(path.join(dir, f), { force: true });

  function readPointer() {
    let raw;
    try { raw = fs.readFileSync(currentFile, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
    try {
      const j = JSON.parse(raw);
      if (!isInt(j.release)) return null;
      return { release: j.release, previous: isInt(j.previous) ? j.previous : null };
    } catch { return null; }
  }
  function writePointer(release, previous) {
    const tmp = path.join(dir, `current.json.${rnd()}.tmp`);
    try {
      fs.writeFileSync(tmp, `${JSON.stringify({ release, previous })}\n`, { flag: 'wx' });
      fs.renameSync(tmp, currentFile);
    } catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
  }
  const releaseDir = (n) => path.join(releasesDir, String(n));
  function readRelease(n) {
    try {
      const signed = JSON.parse(fs.readFileSync(path.join(releaseDir(n), 'manifest.json'), 'utf8'));
      const packDirs = {};
      for (const p of signed.manifest.packs) packDirs[p.packId] = path.join(releaseDir(n), p.packId);
      return { release: n, manifest: signed.manifest, signed, packDirs };
    } catch { return null; }
  }

  function writeFiles(packRoot, files) {
    const realRoot = fs.realpathSync(packRoot);
    for (const f of files) {
      const target = path.resolve(realRoot, ...f.path.split('/'));
      if (!target.startsWith(realRoot + path.sep)) throw coded('UNSAFE_PATH', `pack path escapes the release: ${JSON.stringify(f.path)}`);
      const parent = path.dirname(target);
      fs.mkdirSync(parent, { recursive: true });
      const realParent = fs.realpathSync(parent);
      if (realParent !== realRoot && !realParent.startsWith(realRoot + path.sep)) throw coded('UNSAFE_PATH', `pack path escapes the release: ${JSON.stringify(f.path)}`);
      const tmp = path.join(realParent, `.${path.basename(target)}.${rnd()}.tmp`);
      try {
        fs.writeFileSync(tmp, f.data, { flag: 'wx', mode: 0o644 });
        fs.renameSync(tmp, path.join(realParent, path.basename(target)));
      } catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
    }
  }

  function stage(releaseNo) {
    if (!isInt(releaseNo)) throw coded('BAD_RELEASE', 'release number must be a positive integer');
    const sdir = path.join(stagingRoot, `${releaseNo}-${rnd()}`);
    fs.mkdirSync(sdir, { recursive: true });
    const st = { dir: sdir, packs: new Set(), bytes: 0, files: 0, manifest: false };
    stages.set(releaseNo, st);

    function put(packId, files) {
      if (!PACK_ID.test(packId) || packId === 'manifest.json') throw coded('UNSAFE_PATH', `bad pack id: ${JSON.stringify(packId)}`);
      if (st.packs.has(packId)) throw coded('DUPLICATE_PACK', `pack ${packId} staged twice`);
      const bytes = files.reduce((n, f) => n + f.data.length, 0);
      if (st.files + files.length > lim.MAX_RELEASE_FILES) throw coded('PACK_TOO_MANY_FILES', 'release exceeds the file-count cap');
      if (st.bytes + bytes > lim.MAX_RELEASE_UNPACKED_BYTES) throw coded('PACK_TOO_LARGE', 'release exceeds the unpacked-size cap');
      const root = path.join(sdir, packId);
      let exists = true;
      try { fs.lstatSync(root); } catch (e) { if (e.code === 'ENOENT') exists = false; else throw e; }
      if (exists) throw coded('UNSAFE_PATH', `staging path for ${packId} already exists`);
      fs.mkdirSync(root);
      writeFiles(root, files);
      st.packs.add(packId); st.bytes += bytes; st.files += files.length;
    }

    return {
      dir: sdir,
      // Returns the pack's own metadata so the caller can check it is the pack it asked for.
      writePack(packId, buf) {
        const { files, ...meta } = decodePack(buf, { maxBytes: lim.MAX_PACK_UNPACKED_BYTES, maxFiles: lim.MAX_PACK_FILES });
        put(packId, files);
        return meta;
      },
      // Reuse an unchanged pack from an installed release: re-validated and re-written, never linked, never a symlink.
      copyPack(packId, srcDir) {
        const files = [];
        (function walk(rel) {
          for (const e of fs.readdirSync(path.join(srcDir, rel), { withFileTypes: true })) {
            const r = rel ? `${rel}/${e.name}` : e.name;
            if (e.isSymbolicLink()) throw coded('UNSAFE_PATH', `symlink in installed pack: ${r}`);
            if (e.isDirectory()) walk(r);
            else if (e.isFile()) files.push({ path: r, data: fs.readFileSync(path.join(srcDir, r)) });
          }
        })('');
        files.forEach((f) => assertSafePath(f.path));
        assertNoCollisions(files.map((f) => f.path).sort());
        put(packId, files);
      },
      setManifest(signed) {
        fs.writeFileSync(path.join(sdir, 'manifest.json'), JSON.stringify(signed), { flag: 'w' });
        st.manifest = true;
      },
      abort() { stages.delete(releaseNo); fs.rmSync(sdir, { recursive: true, force: true }); },
    };
  }

  function activate(releaseNo) {
    const st = stages.get(releaseNo);
    if (!st) throw coded('NOT_STAGED', `release ${releaseNo} is not staged`);
    if (!st.manifest) throw coded('NOT_STAGED', `release ${releaseNo} has no manifest`);
    const ptr = readPointer();
    if (ptr && (ptr.release === releaseNo || ptr.previous === releaseNo)) throw coded('RELEASE_EXISTS', `release ${releaseNo} is already installed`);
    fs.mkdirSync(releasesDir, { recursive: true });
    fs.rmSync(releaseDir(releaseNo), { recursive: true, force: true });   // leftover of a crashed activate
    fs.renameSync(st.dir, releaseDir(releaseNo));
    stages.delete(releaseNo);
    writePointer(releaseNo, ptr ? ptr.release : null);
  }

  function current() {
    const ptr = readPointer();
    return ptr ? readRelease(ptr.release) : null;
  }
  function previous() {
    const ptr = readPointer();
    return ptr && ptr.previous && readRelease(ptr.previous) ? ptr.previous : null;
  }
  function rollback() {
    const prev = previous();
    if (prev === null) throw coded('NO_PREVIOUS', 'there is no previous release to roll back to');
    writePointer(prev, null);
    return prev;
  }

  function gc(keep = 2) {
    const ptr = readPointer();
    let nums = [];
    try { nums = fs.readdirSync(releasesDir).filter((n) => /^\d+$/.test(n)).map(Number).sort((a, b) => b - a); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    const kept = new Set();
    if (ptr) { kept.add(ptr.release); if (ptr.previous) kept.add(ptr.previous); }
    for (const n of nums) { if (kept.size >= keep) break; if (!ptr || n <= ptr.release) kept.add(n); }
    const shas = new Set();
    for (const n of nums) {
      if (kept.has(n)) {
        const r = readRelease(n);
        if (r) r.manifest.packs.forEach((p) => shas.add(p.sha256));
      } else fs.rmSync(releaseDir(n), { recursive: true, force: true });
    }
    let blobs = [];
    try { blobs = fs.readdirSync(blobsDir); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    for (const b of blobs) if (!shas.has(b)) fs.rmSync(path.join(blobsDir, b), { force: true });
  }

  // The download cache. A blob is re-verified on the way in and on the way out.
  function writeBlob(hash, buf) {
    if (!HEX64.test(hash) || sha256(buf) !== hash) throw coded('BLOB_HASH_MISMATCH', 'refusing to store a blob that does not match its hash');
    fs.mkdirSync(blobsDir, { recursive: true });
    const tmp = path.join(blobsDir, `.${hash}.${rnd()}.tmp`);
    try { fs.writeFileSync(tmp, buf, { flag: 'wx' }); fs.renameSync(tmp, path.join(blobsDir, hash)); } catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
  }
  function readBlob(hash) {
    if (!HEX64.test(hash)) return null;
    try {
      const buf = fs.readFileSync(path.join(blobsDir, hash));
      return sha256(buf) === hash ? buf : null;
    } catch { return null; }
  }

  return { current, stage, activate, previous, rollback, gc, writeBlob, readBlob };
}

module.exports = { createStore, decodePack, assertSafePath, LIMITS, PACK_ID };
