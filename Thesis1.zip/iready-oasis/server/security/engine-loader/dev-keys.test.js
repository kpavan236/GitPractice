'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { resolveKeys, resetWarnings, isPackagedApp, DEV_WARNING } = require('./dev-keys');

const pair = () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  return { pub: publicKey.export({ type: 'spki', format: 'pem' }), priv: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
};
const K = pair();
const PINNED = Object.freeze({ 'rules-2026-a': pair().pub });

function withFile(content, fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dev-keys-'));
  const file = path.join(dir, 'keys.json');
  fs.writeFileSync(file, typeof content === 'string' ? content : JSON.stringify(content));
  try { return fn(file); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const resolve = (env, extra = {}) => resolveKeys({ env, pinned: PINNED, electron: undefined, log: () => {}, ...extra });

test('env unset: the pinned keys only, no dev keys, nothing logged', () => {
  resetWarnings();
  const logs = [];
  const r = resolve({}, { log: (m) => logs.push(m) });
  assert.deepEqual(r.keys, PINNED);
  assert.deepEqual(r.devKeys, []);
  assert.deepEqual(logs, []);
});

test('env set: the file keys are merged over the pinned ones and a one-line warning is logged once per process', () => {
  resetWarnings();
  const logs = [];
  withFile({ 'dev-1': K.pub }, (file) => {
    const r = resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }, { log: (m) => logs.push(m) });
    assert.deepEqual(Object.keys(r.keys).sort(), ['dev-1', 'rules-2026-a']);
    assert.deepEqual(r.devKeys, ['dev-1']);
    resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }, { log: (m) => logs.push(m) });
  });
  assert.equal(logs.length, 1, 'once per process start');
  assert.equal(logs[0], DEV_WARNING(['dev-1']));
  assert.match(logs[0], /^DEV rules signing key in use \(dev-1\): releases are trusted from a local file, not the pinned production keys$/);
});

test('a missing, unreadable or malformed file is a coded error', () => {
  assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: '/nonexistent/keys.json' }), { code: 'DEV_KEYS_UNREADABLE' });
  withFile('not json', (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEYS_BAD_FILE' }));
  withFile('[1,2]', (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEYS_BAD_FILE' }));
  withFile({}, (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEYS_BAD_FILE' }));
  withFile({ 'dev-1': 42 }, (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEY_INVALID' }));
  withFile({ 'dev-1': 'not a pem' }, (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEY_INVALID' }));
  withFile({ '': K.pub }, (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEY_INVALID' }));
});

test('a private key in the file is refused, and its text never appears in the error', () => {
  withFile({ 'dev-1': K.priv }, (file) => {
    assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), (e) => {
      assert.equal(e.code, 'DEV_KEY_PRIVATE');
      assert.ok(!e.message.includes(K.priv.split('\n')[1]), 'no key material in the message');
      return true;
    });
  });
});

test('only Ed25519 public keys are accepted', () => {
  const rsa = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).publicKey.export({ type: 'spki', format: 'pem' });
  withFile({ 'dev-1': rsa }, (file) => assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEY_INVALID' }));
});

test('a key id that is already pinned cannot be overridden', () => {
  withFile({ 'rules-2026-a': K.pub }, (file) => {
    assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), { code: 'DEV_KEY_ID_PINNED' });
  });
});

test('a packaged desktop app ignores the variable and says so', () => {
  resetWarnings();
  const logs = [];
  withFile({ 'dev-1': K.pub }, (file) => {
    const r = resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }, { electron: '30.0.0', defaultApp: undefined, log: (m) => logs.push(m) });
    assert.deepEqual(r.keys, PINNED);
    assert.deepEqual(r.devKeys, []);
    assert.equal(r.ignored, true);
  });
  assert.equal(logs.length, 1);
  assert.match(logs[0], /OASIS_DEV_RULES_PUBLIC_KEYS is ignored in a packaged app/);
});

test('an unpackaged Electron run (electron .) and plain Node honour the variable; app.isPackaged wins when readable', () => {
  assert.equal(isPackagedApp({ electron: '30.0.0', defaultApp: true }), false);
  assert.equal(isPackagedApp({ electron: '30.0.0', defaultApp: undefined }), true);
  assert.equal(isPackagedApp({ electron: undefined, defaultApp: undefined }), false);
  assert.equal(isPackagedApp({ electron: '30.0.0', defaultApp: true, app: { isPackaged: true } }), true);
  assert.equal(isPackagedApp({ electron: '30.0.0', defaultApp: undefined, app: { isPackaged: false } }), false);
  withFile({ 'dev-1': K.pub }, (file) => {
    assert.deepEqual(resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }, { electron: '30.0.0', defaultApp: true }).devKeys, ['dev-1']);
  });
});

test('a group- or world-writable key file is refused on POSIX with DEV_KEYS_INSECURE_FILE; 0644 and 0600 are accepted', { skip: process.platform === 'win32' }, () => {
  resetWarnings();
  withFile({ 'dev-1': K.pub }, (file) => {
    for (const mode of [0o664, 0o666, 0o622, 0o646]) {
      fs.chmodSync(file, mode);
      assert.throws(() => resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }), (e) => e.code === 'DEV_KEYS_INSECURE_FILE' && /chmod go-w/.test(e.message), mode.toString(8));
    }
    for (const mode of [0o644, 0o600]) {
      fs.chmodSync(file, mode);
      assert.deepEqual(resolve({ OASIS_DEV_RULES_PUBLIC_KEYS: file }).devKeys, ['dev-1']);
    }
  });
});
