'use strict';
// Loaded with --require in the engine child. Defence in depth ONLY: the permission model is the boundary, and
// on a Node without --allow-net it does not cover the network at all, so this is then the only network defence.
// Rule logic is untrusted, so do not read this as a sandbox: code that reaches the native bindings through some
// other route is not stopped here.

// Standard streams are built on net.Socket / tty; make them now, before the modules below are replaced.
void process.stdin; void process.stdout; void process.stderr;

function denied() {
  return Object.assign(new Error('network access is not allowed in the rules engine'), { code: 'EPERM_NETWORK' });
}
const deny = () => { throw denied(); };
const denyAsync = async () => { throw denied(); };

function lock(mod) {
  for (const key of Object.keys(mod)) {
    let value;
    try { value = mod[key]; } catch { continue; }
    if (typeof value === 'function') {
      try { mod[key] = deny; } catch { /* non-writable: the permission model still applies */ }
    } else if (key === 'promises' && value && typeof value === 'object') {
      lock(value);
    }
  }
}

// Load every module first: they extend each other's classes while loading, which breaks once one is replaced.
const mods = ['net', 'dns', 'http', 'https', 'http2', 'tls', 'dgram', 'dns/promises'].map((n) => require(`node:${n}`));
for (const mod of mods) lock(mod);

for (const name of ['fetch', 'WebSocket', 'EventSource', 'XMLHttpRequest']) {
  if (typeof globalThis[name] === 'undefined') continue;
  Object.defineProperty(globalThis, name, { value: name === 'fetch' ? denyAsync : deny, writable: false, configurable: false });
}
