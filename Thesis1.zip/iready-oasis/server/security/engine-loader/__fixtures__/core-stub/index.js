'use strict';
// A stand-in for the analyzer's core pack: analyze() does whatever ruleSet.mode asks, so the runner's
// restrictions can be tested without the real engine.
const fs = require('node:fs');

const scanners = { demo: { id: 'demo' } };

async function analyze({ repoPath, ruleSet, files }) {
  const mode = ruleSet && ruleSet.mode;
  if (mode === 'fetch') await fetch('http://127.0.0.1:1');
  if (mode === 'http') require('node:http').get('http://127.0.0.1:1');
  if (mode === 'readOutside') fs.readFileSync(ruleSet.target, 'utf8');
  if (mode === 'readRepo') fs.readFileSync(`${repoPath}/${ruleSet.target}`, 'utf8');
  if (mode === 'write') fs.writeFileSync(`${repoPath}/pwned.txt`, 'x');
  if (mode === 'spawn') require('node:child_process').execSync('echo hi');
  if (mode === 'worker') new (require('node:worker_threads').Worker)('1', { eval: true });
  if (mode === 'rawSocket') {
    await new Promise((res, rej) => { const sock = new (process.stdin.constructor)(); sock.on('error', rej); sock.on('connect', res); sock.connect(1, '127.0.0.1'); });
  }
  if (mode === 'agentConn') {
    await new Promise((res, rej) => {
      const c = require('node:http').globalAgent.constructor.prototype.createConnection.call({}, { port: 1, host: '127.0.0.1' });
      c.on('error', rej); c.on('connect', res);
    });
  }
  if (mode === 'echoFiles') {
    const list = files || fs.readdirSync(repoPath, { recursive: true });
    const found = [];
    for (const f of list) {
      let text;
      try { text = fs.readFileSync(`${repoPath}/${f}`, 'utf8'); } catch { continue; }
      found.push({ id: 'r', file: f, fingerprint: `fp-${f}`, text });
    }
    return { results: new Map([['demo', { findings: found, stats: null, error: null }]]), corpus: {}, cache: null };
  }
  if (mode === 'plainStdout') { process.stdout.write('{"ok":true}'); process.exit(0); }
  if (mode === 'noise') { console.log('noise before'); console.log('{"ok":false}'); }
  if (mode === 'badFinding') {
    const bad = { null: null, noFp: { id: 'x', file: 'a.js' }, numFp: { fingerprint: 5 }, numFile: { fingerprint: 'f', file: 7 }, str: 'text' }[ruleSet.which];
    return { results: new Map([['demo', { findings: [bad], stats: null, error: null }]]), corpus: {}, cache: null };
  }
  if (mode === 'badStats') return { results: new Map([['demo', { findings: [], stats: 'x', error: null }]]), corpus: {}, cache: null };
  if (mode === 'loop') for (;;);
  if (mode === 'heap') { const keep = []; for (;;) keep.push({ a: new Array(1000).fill(keep.length) }); }
  if (mode === 'buffers') {
    const keep = [];
    for (let i = 0; i < 12; i++) keep.push(Buffer.alloc(50 * 1024 * 1024, 1));
    await new Promise((r) => setTimeout(r, 20000));
  }
  if (mode === 'huge') return { results: [['demo', { findings: [{ x: 'y'.repeat(ruleSet.size) }], stats: null, error: null }]], corpus: {}, cache: {} };
  if (mode === 'malformed') return { results: 'nope' };
  if (mode === 'throwCoded') throw Object.assign(new Error('boom'), { code: 'MY_CODE' });
  if (mode === 'stderr') { process.stderr.write('e'.repeat(1024 * 1024)); }
  if (mode === 'realShape') {
    // What the real analyzer returns: no fingerprint yet (the host assigns it), a secret's plaintext only on a non-enumerable field.
    const secret = { id: null, fingerprint: null, type: 'SECRET', file: 'config.env', startLine: 1, detections: [{ source: 'BUILTIN_SECRETS', ruleId: 's1', detectedAt: null }], metadata: { secretHash: 'hash-of-secret' } };
    Object.defineProperty(secret, '_plaintext', { value: 'synthetic-secret', enumerable: false });
    const sast = { id: null, fingerprint: null, type: 'SAST', file: 'a.js', startLine: 2, detections: [{ source: 'PATTERN_SAST', ruleId: 'p1', detectedAt: null }], metadata: {} };
    return { results: new Map([['demo', { findings: [secret, sast], stats: null, error: null }]]), corpus: {}, cache: null };
  }
  const finding = { id: 'r1', file: 'a.js', line: 1 };
  Object.defineProperty(finding, '_plaintext', { value: 'synthetic-secret', enumerable: false });
  finding.fingerprint = 'fp1';
  return {
    results: new Map([['demo', { findings: [finding], stats: { files: (files || []).length }, error: null }]]),
    corpus: { filesScanned: 1, env: Object.keys(process.env), argv: process.argv.slice(2) },
    cache: { hits: 0, misses: 1 },
  };
}

module.exports = { analyze, scanners };
