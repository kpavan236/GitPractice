'use strict';
// Client-side rules loader: keeps a verified, atomically switched copy of the central rules release on disk.
// It runs no engine and scans nothing; callers use rulesFor / corePath / grammarPath on the current release.
//
// CALLER CONTRACT
//  1. Wrap update() in try/catch: integrity failures (bad signature, hash/size mismatch, unsafe pack, ...) REJECT with
//     a coded error; offline and rate-limited answers are returned as {status:'offline'}.
//  2. After any status other than 'updated', check result.release !== null before scanning. On a first run
//     UPGRADE_REQUIRED is {status:'current', release:null, error:'UPGRADE_REQUIRED'}, which is NOT "up to date".
//     rulesFor/corePath/grammarPath throw NO_RULES_INSTALLED when nothing is installed, so a scan can never run
//     with zero rules by accident.
//  3. Never call update() concurrently; serialise calls.
const fs = require('node:fs');
const path = require('node:path');
const { createStore } = require('./store');
const { updateEngine } = require('./update');
const { resolveKeys, DEV_WARNING } = require('./dev-keys');

function createEngineLoader({ dir, baseUrl, env = process.env, log = () => {}, ...options }) {
  const store = createStore(dir);
  const current = () => store.current();
  const installed = () => {
    const c = current();
    if (!c) throw Object.assign(new Error('no rules release is installed; run update() first'), { code: 'NO_RULES_INSTALLED' });
    return c;
  };

  function packFor(language) {
    const c = installed();
    const p = c.manifest.packs.find((x) => x.kind === 'language' && x.language === language);
    return p && c.packDirs[p.packId] ? c.packDirs[p.packId] : null;
  }

  // Keys come from the caller (tests) or, by default, the pinned keys plus the DEV-ONLY key file (dev-keys.js).
  // Resolved on every call so a bad file is a coded error of update(), not of construction.
  const keysFor = () => (options.publicKeys ? { keys: options.publicKeys, devKeys: [] } : resolveKeys({ env, log }));

  // The dev key ids the last update() trusted, so devKeys() never reports something other than what verified a
  // release. Before any update() it is what a resolve would give now.
  let trusted = null;

  return {
    update: async () => {
      const { keys, devKeys } = keysFor();
      trusted = devKeys;
      const result = await updateEngine({ store, baseUrl, ...options, publicKeys: keys });
      return devKeys.length ? { ...result, devKeys, warning: DEV_WARNING(devKeys) } : result;
    },
    /** Ids of the DEV-ONLY signing keys the last update() trusted ([] normally); never throws. */
    devKeys() { if (trusted) return [...trusted]; try { return keysFor().devKeys; } catch { return []; } },
    current,
    rollback: () => store.rollback(),
    rulesFor(languages) {
      installed();
      const out = [];
      for (const language of [...new Set(languages)]) {
        const dir_ = packFor(language);
        if (!dir_) continue;
        const rules = JSON.parse(fs.readFileSync(path.join(dir_, 'rules.json'), 'utf8'));
        if (!Array.isArray(rules)) throw Object.assign(new Error(`rules.json of the ${language} pack is not an array`), { code: 'BAD_PACK' });
        out.push(...rules);
      }
      return out;
    },
    corePath() {
      const c = installed();
      return c.packDirs.core || null;
    },
    grammarPath(language) {
      const d = packFor(language);
      if (!d) return null;
      const g = path.join(d, 'grammar');
      let names = [];
      try { names = fs.readdirSync(g).filter((n) => n.endsWith('.wasm')).sort(); } catch { return null; }
      return names.length ? path.join(g, names[0]) : null;
    },
  };
}

module.exports = { createEngineLoader };
