'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  parsePackageLock, parseYarnLock, parsePnpmLock, parseGoMod,
  parseCargoLock, parseComposerLock, parseGemfileLock,
  parsePipfileLock, parsePoetryLock, parseLockfile, lockfileFor,
  NO_LOCKFILE_ECOSYSTEMS,
} = require('./lockfiles');

const find = (deps, name) => deps.find(d => d.name === name);

// ── npm, the format that matters most ──────────────────────────────────────

test('package-lock v3 reports transitive dependencies, not just declared ones', () => {
  // The whole point of reading lockfiles: express is declared, but the
  // vulnerable thing is usually three levels down.
  const lock = JSON.stringify({
    lockfileVersion: 3,
    packages: {
      '': { dependencies: { express: '^4.18.0' } },
      'node_modules/express': { version: '4.18.2' },
      'node_modules/body-parser': { version: '1.20.1' },
      'node_modules/body-parser/node_modules/qs': { version: '6.11.0' },
    },
  });
  const deps = parsePackageLock(lock);

  assert.equal(deps.length, 3);
  assert.equal(find(deps, 'express').direct, true);
  assert.equal(find(deps, 'body-parser').direct, false);
  assert.equal(find(deps, 'qs').version, '6.11.0');
  assert.equal(find(deps, 'qs').direct, false);
});

test('a scoped package keeps its scope', () => {
  const lock = JSON.stringify({
    lockfileVersion: 3,
    packages: { '': { dependencies: { '@babel/core': '^7' } }, 'node_modules/@babel/core': { version: '7.23.0' } },
  });
  assert.equal(find(parsePackageLock(lock), '@babel/core').version, '7.23.0');
});

test('dev dependencies are included — a vulnerable build tool is still a risk', () => {
  const lock = JSON.stringify({
    lockfileVersion: 3,
    packages: { '': { devDependencies: { jest: '^29' } }, 'node_modules/jest': { version: '29.7.0' } },
  });
  assert.equal(find(parsePackageLock(lock), 'jest').direct, true);
});

test('package-lock v1 nested trees are walked', () => {
  // npm 6 lockfiles are still common in repositories that have not been
  // regenerated, and dropping them would silently lose those projects.
  const lock = JSON.stringify({
    lockfileVersion: 1,
    dependencies: {
      express: { version: '4.18.2', dependencies: { qs: { version: '6.11.0' } } },
    },
  });
  const deps = parsePackageLock(lock);
  assert.equal(find(deps, 'express').direct, true);
  assert.equal(find(deps, 'qs').direct, false);
});

test('the same package at the same version from two paths is one dependency', () => {
  const lock = JSON.stringify({
    lockfileVersion: 3,
    packages: {
      '': { dependencies: {} },
      'node_modules/a/node_modules/ms': { version: '2.1.3' },
      'node_modules/b/node_modules/ms': { version: '2.1.3' },
    },
  });
  assert.equal(parsePackageLock(lock).filter(d => d.name === 'ms').length, 1);
});

test('yarn.lock v1 resolves descriptors to versions', () => {
  const deps = parseYarnLock(`# yarn lockfile v1

"@babel/core@^7.0.0", "@babel/core@^7.1.0":
  version "7.23.0"
  resolved "https://registry.yarnpkg.com/..."

lodash@^4.17.20:
  version "4.17.21"
`);
  assert.equal(find(deps, '@babel/core').version, '7.23.0');
  assert.equal(find(deps, 'lodash').version, '4.17.21');
});

test('pnpm keys parse in both the v5 and v6 formats', () => {
  const v6 = parsePnpmLock("packages:\n  /lodash@4.17.21:\n    resolution: {integrity: sha512-x}\n");
  assert.equal(find(v6, 'lodash').version, '4.17.21');

  const v5 = parsePnpmLock("packages:\n  /lodash/4.17.20:\n    resolution: {integrity: sha512-y}\n");
  assert.equal(find(v5, 'lodash').version, '4.17.20');
});

// ── Other ecosystems ───────────────────────────────────────────────────────

test('go.mod distinguishes direct from indirect', () => {
  const deps = parseGoMod(`module example.com/x

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	golang.org/x/crypto v0.14.0 // indirect
)
`);
  assert.equal(find(deps, 'github.com/gin-gonic/gin').direct, true);
  assert.equal(find(deps, 'golang.org/x/crypto').direct, false);
});

test('a single-line go require is parsed too', () => {
  assert.equal(find(parseGoMod('require github.com/pkg/errors v0.9.1'), 'github.com/pkg/errors').version, '0.9.1');
});

test('the Go "v" prefix is stripped for OSV', () => {
  // OSV records Go ranges as "1.9.0"; querying "v1.9.1" matches nothing and the
  // module reports falsely clean.
  const deps = parseGoMod('require (\n\tgithub.com/gin-gonic/gin v1.9.1\n)');
  assert.equal(find(deps, 'github.com/gin-gonic/gin').version, '1.9.1');
});

test('Cargo.lock packages are parsed', () => {
  const deps = parseCargoLock(`[[package]]
name = "serde"
version = "1.0.190"

[[package]]
name = "libc"
version = "0.2.149"
`);
  assert.equal(deps.length, 2);
  assert.equal(find(deps, 'serde').version, '1.0.190');
});

test('composer.lock includes both runtime and dev packages', () => {
  const deps = parseComposerLock(JSON.stringify({
    packages: [{ name: 'monolog/monolog', version: '2.9.1' }],
    'packages-dev': [{ name: 'phpunit/phpunit', version: 'v10.4.2' }],
  }));
  assert.equal(find(deps, 'monolog/monolog').version, '2.9.1');
  // The leading v is stripped so the version matches what OSV expects.
  assert.equal(find(deps, 'phpunit/phpunit').version, '10.4.2');
});

test('Gemfile.lock reads resolved gems and not their requirement lines', () => {
  const deps = parseGemfileLock(`GEM
  remote: https://rubygems.org/
  specs:
    rails (7.0.8)
      actionpack (= 7.0.8)
    actionpack (7.0.8)

PLATFORMS
  ruby
`);
  assert.equal(find(deps, 'rails').version, '7.0.8');
  assert.equal(find(deps, 'actionpack').version, '7.0.8');
  assert.equal(deps.length, 2);
});

test('Pipfile.lock strips the == pin', () => {
  const deps = parsePipfileLock(JSON.stringify({
    default: { requests: { version: '==2.31.0' } },
    develop: { pytest: { version: '==7.4.3' } },
  }));
  assert.equal(find(deps, 'requests').version, '2.31.0');
  assert.equal(find(deps, 'pytest').version, '7.4.3');
});

test('poetry.lock packages are parsed', () => {
  const deps = parsePoetryLock(`[[package]]
name = "urllib3"
version = "2.0.7"
`);
  assert.equal(find(deps, 'urllib3').version, '2.0.7');
});

// ── Dispatch and failure ───────────────────────────────────────────────────

test('lockfiles are recognised by filename', () => {
  assert.equal(lockfileFor('package-lock.json').ecosystem, 'npm');
  assert.equal(lockfileFor('yarn.lock').ecosystem, 'npm');
  assert.equal(lockfileFor('pom.xml'), null);
});

test('a malformed lockfile returns null rather than crashing the scan', () => {
  assert.equal(parseLockfile('package-lock.json', '{"broken'), null);
  assert.equal(parseLockfile('Pipfile.lock', 'not json at all'), null);
});

test('an empty lockfile is an empty list, not a parse failure', () => {
  // "this project has no dependencies" and "this file is corrupt" are different
  // outcomes; only the second should suppress the result.
  assert.deepEqual(parseLockfile('Cargo.lock', ''), []);
  assert.deepEqual(parseLockfile('package-lock.json', '{"lockfileVersion":3,"packages":{}}'), []);
});

test('an unknown filename is not parsed', () => {
  assert.equal(parseLockfile('README.md', 'anything'), null);
});

test('Maven and Gradle are recorded as having no lockfile', () => {
  // Not an oversight — Maven has no lockfile format, and this list is what the
  // scanner reads to report the limitation instead of implying full coverage.
  assert.deepEqual(NO_LOCKFILE_ECOSYSTEMS, ['maven', 'gradle']);
});

test('entries without a version are dropped rather than sent to OSV as undefined', () => {
  const lock = JSON.stringify({
    lockfileVersion: 3,
    packages: { '': {}, 'node_modules/broken': {}, 'node_modules/ok': { version: '1.0.0' } },
  });
  const deps = parsePackageLock(lock);
  assert.equal(deps.length, 1);
  assert.equal(deps[0].name, 'ok');
});