'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildSnapshot, readBaseline } = require('./snapshot');

test('every baselined rule still reports exactly what it reported before the migration', async () => {
  const current = new Map((await buildSnapshot()).map(s => [s.ruleId, s]));
  for (const before of readBaseline()) {
    assert.ok(current.has(before.ruleId), `rule ${before.ruleId} disappeared`);
    assert.deepEqual(current.get(before.ruleId), before, `behavior of ${before.ruleId} changed`);
  }
});

test('baseline detects on the vulnerable example and is silent on the fixed one', () => {
  for (const s of readBaseline()) {
    assert.ok(s.vulnerable.some(f => f.detections[0].ruleId === s.ruleId), `${s.ruleId} must detect`);
    assert.ok(!s.fixed.some(f => f.detections[0].ruleId === s.ruleId), `${s.ruleId} must stay silent`);
  }
});
