'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { missing, startRuleServer } = require('./rule-server-fixture');
const { createOrchestrator } = require('../orchestrator');
const { createRuleServerClient } = require('../rule-sync/client');
const { createRuleSetCache } = require('../rule-sync/cache');
const { createRuleSync } = require('../rule-sync/sync');

// What the server stores must equal what the scanner stores, scan after scan:
// same findings, same triage and resolution decisions, same gate verdict.

const REPO = 'student-api';
const TOKEN = 'ghp_' + 'aB3dE5gH7jK9mN1pQ3sT5vW7yZ9bC1dE3fG5';
const scanners = ['secrets-builtin', 'pattern-sast', 'iac-policy', 'sast-ast'].map(n => require(`../scanners/${n}`).scanner);

// COMPLETED is set before the best-effort uploads run (as with publishScan), so
// a finished scan is one whose upload outcome has also been recorded.
async function waitForScan(orchestrator, id) {
  for (let i = 0; i < 800; i++) {
    const scan = orchestrator.getScan(id);
    if (['FAILED', 'CANCELLED'].includes(scan.status)) return scan;
    if (scan.status === 'COMPLETED' && (scan.perRepository || []).every(r => r.ruleServer)) return scan;
    await new Promise(r => setTimeout(r, 25));
  }
  throw new Error('scan did not finish in time');
}
const view = f => ({ status: f.status, severity: f.severity, type: f.type, file: f.file, startLine: f.startLine });

test('findings, triage, resolution and gate verdict on the server match the scanner\'s own', { skip: missing }, async (t) => {
  const server = await startRuleServer(t);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-fe-'));
  t.after(() => fs.rmSync(work, { recursive: true, force: true }));

  const repoPath = path.join(work, REPO);
  // The example rules come from the live server: they are its authored rules.
  const authored = (await (await fetch(`${server.base}/api/v1/rules?origin=builtin`)).json())
    .map(r => r.body).filter(r => (r.query || r.pattern) && !r.provenance && r.example);
  for (const r of authored) {
    fs.mkdirSync(path.join(repoPath, r.id), { recursive: true });
    { const file = path.join(repoPath, r.id, r.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, r.example.vulnerable); }
  }
  fs.writeFileSync(path.join(repoPath, 'config.env'), `GITHUB_TOKEN=${TOKEN}\n`);

  // A real history, so "new code" (the diff against HEAD~1) is evaluated by both
  // gates instead of both reporting NOT_EVALUATED. The second commit introduces a
  // CRITICAL finding.
  const git = (...args) => execFileSync('git', args, { cwd: repoPath, stdio: 'pipe' });
  git('init', '-q'); git('config', 'user.email', 't@example.com'); git('config', 'user.name', 't');
  git('add', '-A'); git('commit', '-q', '-m', 'base');
  const critical = authored.find(r => r.severity === 'CRITICAL');
  const newDir = path.join(repoPath, `new-${critical.id}`);
  fs.mkdirSync(newDir, { recursive: true });
  { const file = path.join(newDir, critical.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, critical.example.vulnerable); }
  git('add', '-A'); git('commit', '-q', '-m', 'introduce a critical');

  const sync = createRuleSync({
    client: createRuleServerClient({ baseUrl: server.base }),
    cache: createRuleSetCache(work),
    baseUrl: server.base,
  });
  const orchestrator = createOrchestrator({ scanners, dir: path.join(work, 'store'), userRulesDir: null, userGrammarsDir: null, ruleSync: sync });
  t.after(() => orchestrator.shutdown());

  const api = async (p, init) => {
    const res = await fetch(`${server.base}/api/v1${p}`, { headers: { 'content-type': 'application/json' }, ...init });
    return res.json();
  };
  const serverView = async () => Object.fromEntries((await api(`/projects/${REPO}/findings?status=all`)).map(f => [f.fingerprint, view(f)]));
  const localView = async () => Object.fromEntries((await orchestrator.listFindings({ repository: REPO, status: 'all' })).map(f => [f.fingerprint, view(f)]));
  const scan = async () => {
    const started = await orchestrator.startScan({ targets: [{ repository: REPO, repoPath }] });
    const done = await waitForScan(orchestrator, started.id);
    assert.equal(done.status, 'COMPLETED', done.error || '');
    return done.perRepository[0];
  };

  // Scan 1
  const first = await scan();
  assert.equal(first.ruleServer.ok, true, first.ruleServer.error);
  assert.equal(first.newCode.available, true, 'the temp repository has a real diff');
  assert.equal(first.gate.status, 'FAILED', 'a new CRITICAL finding fails the default gate');
  assert.equal(first.ruleServer.serverGate.status, first.gate.status, 'gate verdicts differ');
  assert.equal(first.ruleServer.gateMismatch, undefined);
  // Not just the verdict: every condition measured the same thing.
  const conditions = g => g.conditions.map(c => [c.metric, c.scope, c.actual, c.status]);
  assert.deepEqual(conditions(first.ruleServer.serverGate), conditions(first.gate));
  assert.ok(first.gate.conditions.some(c => c.metric === 'critical_issues' && c.actual >= 1));
  const local1 = await localView();
  assert.ok(Object.keys(local1).length >= 25, `expected a meaningful number of findings, got ${Object.keys(local1).length}`);
  assert.deepEqual(await serverView(), local1);
  assert.ok(!JSON.stringify(await api(`/projects/${REPO}/findings?status=all`)).includes(TOKEN), 'secret plaintext reached the server');
  assert.equal((await api('/history')).points.length, 1);

  // Triage one finding on both sides, then remove half the vulnerable files.
  // The victim lives in a directory that survives the deletion below, so the
  // second scan really reports it again and the suppression has to hold.
  const removed = new Set(authored.slice(0, Math.floor(authored.length / 2)).map(r => r.id));
  const victim = (await orchestrator.listFindings({ repository: REPO }))
    .find(f => f.type === 'SAST' && !removed.has(f.file.split('/')[0]) && !f.file.startsWith('new-'));
  assert.ok(victim, 'a SAST finding in a surviving directory');
  await orchestrator.updateFinding(victim.id, { status: 'SUPPRESSED', suppression: { reason: 'accepted' } });
  await api(`/projects/${REPO}/findings/${victim.fingerprint}/status`, { method: 'POST', body: JSON.stringify({ status: 'SUPPRESSED', reason: 'accepted' }) });
  for (const id of removed) fs.rmSync(path.join(repoPath, id), { recursive: true, force: true });
  fs.rmSync(newDir, { recursive: true, force: true });
  git('add', '-A'); git('commit', '-q', '-m', 'remove findings');

  // Scan 2
  const second = await scan();
  assert.equal(second.ruleServer.ok, true, second.ruleServer.error);
  assert.equal(second.ruleServer.gateMismatch, undefined);
  assert.equal(second.ruleServer.serverGate.status, second.gate.status, 'gate verdicts differ after the fix');
  assert.notEqual(second.gate.status, 'FAILED', 'removing the critical finding clears the gate');
  assert.deepEqual(conditions(second.ruleServer.serverGate), conditions(second.gate));
  const local2 = await localView();
  const server2 = await serverView();
  assert.deepEqual(server2, local2);
  const statuses = new Set(Object.values(local2).map(f => f.status));
  assert.ok(statuses.has('RESOLVED'), 'removed files should resolve their findings');
  assert.equal(local2[victim.fingerprint].status, 'SUPPRESSED', 'suppression must outlive the rescan, on both sides');
  assert.ok((await orchestrator.listFindings({ repository: REPO, status: 'all' })).some(f => f.fingerprint === victim.fingerprint && f.lastSeenAt > f.firstSeenAt),
    'the suppressed finding was reported again by the second scan');
  assert.equal((await api('/history')).points.length, 2);
  assert.equal((await api(`/projects/${REPO}/analyses`)).length, 2);

  // Scan 3 with the server down: the scan still completes, its findings wait in the
  // outbox, and reads say the server is unreachable instead of showing nothing.
  await server.stop();
  const third = await scan();
  assert.deepEqual([third.ruleServer.ok, third.ruleServer.pending], [false, true]);
  assert.match(third.ruleServer.error, /unreachable/i);
  const outboxDir = path.join(work, 'store', 'outbox');
  const queued = () => (fs.existsSync(outboxDir) ? fs.readdirSync(outboxDir).filter(n => n.endsWith('.json')).length : 0);
  assert.equal(queued(), 1, 'the scan is waiting in the outbox');
  await assert.rejects(orchestrator.listFindings({ repository: REPO }), e => e.code === 'UNREACHABLE');
  assert.deepEqual(require('../store').load(path.join(work, 'store')).findings, [], 'no findings are kept in the scanner\'s own store');

  // The server returns: the next scan delivers what was waiting, in order.
  await server.restart();
  const fourth = await scan();
  assert.equal(fourth.ruleServer.ok, true, fourth.ruleServer.error);
  assert.equal(queued(), 0, 'the outbox is empty once the server has everything');
  assert.equal((await api(`/projects/${REPO}/analyses`)).length, 4, 'every scan, including the one made during the outage, reached the server');
  assert.deepEqual(await serverView(), await localView(), 'the gateway shows exactly what the server holds');
});
