'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { missing, startRuleServer } = require('./rule-server-fixture');
const { buildSnapshot, readBaseline } = require('./snapshot');
const { createRuleServerClient } = require('../rule-sync/client');
const { createRuleSetCache } = require('../rule-sync/cache');
const { createRuleSync } = require('../rule-sync/sync');
const { runCorpusScanners } = require('../corpus');

// The proof that moving rules to the rule server changed nothing the scanner
// reports: a REAL rule server feeds the REAL engines, and each rule must still
// detect what the committed baseline says it detected.

test('rules served by the rule server give the scanner exactly the pre-migration behavior', { skip: missing }, async (t) => {
  const server = await startRuleServer(t);
  const sync = createRuleSync({ client: createRuleServerClient({ baseUrl: server.base }), cache: createRuleSetCache(server.tmp), baseUrl: server.base });
  const ruleSet = await sync.refresh('student-api');
  assert.equal(ruleSet.source, 'rule-server');
  assert.ok(ruleSet.rules.length >= 296, `got ${ruleSet.rules.length} rules`);

  // 1. Per-rule behavior equals the committed baseline.
  const served = new Map((await buildSnapshot({ ruleSet })).map(s => [s.ruleId, s]));
  for (const before of readBaseline()) {
    assert.deepEqual(served.get(before.ruleId), before, `rule ${before.ruleId} behaves differently when served`);
  }

  // 2. A whole-repository run through all four engines with the served rules.
  const repo = path.join(server.tmp, 'repo');
  const authored = ruleSet.rules.filter(r => (r.query || r.pattern) && !r.provenance && r.example);
  for (const r of authored) {
    fs.mkdirSync(path.join(repo, r.id), { recursive: true });
    { const file = path.join(repo, r.id, r.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, r.example.vulnerable); }
  }
  const token = 'ghp_' + 'aB3dE5gH7jK9mN1pQ3sT5vW7yZ9bC1dE3fG5';
  fs.writeFileSync(path.join(repo, 'config.env'), `GITHUB_TOKEN=${token}\n`);

  const scanners = ['secrets-builtin', 'pattern-sast', 'iac-policy', 'sast-ast'].map(n => require(`../scanners/${n}`).scanner);
  const { results } = await runCorpusScanners(scanners, { repoPath: repo, repository: 'r', dir: server.tmp, ruleSet });
  let total = 0;
  const versions = new Set();
  for (const [id, r] of results) {
    assert.equal(r.error, null, `${id}: ${r.error}`);
    total += r.findings.length;
    for (const f of r.findings) if (f.metadata && f.metadata.ruleBundleVersion) versions.add(f.metadata.ruleBundleVersion);
  }
  assert.ok(total >= 25, `expected a meaningful number of findings, got ${total}`);
  assert.deepEqual([...versions], [ruleSet.version], 'findings must record the profile version that produced them');
  assert.ok(!JSON.stringify([...results.values()].map(r => r.findings)).includes(token), 'secret plaintext must never appear in findings');

  // 3. Changing the rule on the server changes what the scanner gets, and its version.
  const put = await fetch(`${server.base}/api/v1/rules/docker-add-remote-url`, {
    method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ severity: 'LOW' }),
  });
  assert.equal(put.status, 200);
  const updated = await sync.refresh('student-api');
  assert.notEqual(updated.version, ruleSet.version);
  assert.equal(updated.rules.find(r => r.id === 'docker-add-remote-url').severity, 'LOW');
});
