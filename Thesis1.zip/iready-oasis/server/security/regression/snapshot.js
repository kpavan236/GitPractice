'use strict';
const fs = require('fs');
const path = require('path');
const { scanSource } = require('../scanners/sast-ast');
const { scanContent, compileRule } = require('../scanners/pattern-sast');
const { testRuleSet } = require('../test-support/rules');

// Records what the current scanner reports for every authored rule's own
// example (the vulnerable and the fixed variant). This is the "before" side of
// the before/after regression comparison for the rule-server migration.
// Findings are deterministic here (ids, timestamps and bundle version are null).

const BASELINE_PATH = path.join(__dirname, 'baseline.json');

async function scanExample(rule, source, allRules, patternRules) {
  const findings = rule.query
    ? await scanSource(source, rule.example.file, 'repo', allRules)
    : scanContent(source, rule.example.file, 'repo', patternRules);
  return findings.sort((a, b) =>
    (a.detections[0].ruleId + a.startLine).localeCompare(b.detections[0].ruleId + b.startLine));
}

async function buildSnapshot({ ruleSet = null } = {}) {
  const rules = ruleSet ? ruleSet.rules : testRuleSet().rules;
  const patternRules = rules.filter(r => r.pattern).map(compileRule).filter(Boolean);
  const authored = rules.filter(r => (r.query || r.pattern) && !r.provenance && r.example);

  const snapshot = [];
  for (const rule of authored) {
    snapshot.push({
      ruleId: rule.id,
      vulnerable: await scanExample(rule, rule.example.vulnerable, rules, patternRules),
      fixed: await scanExample(rule, rule.example.fixed, rules, patternRules),
    });
  }
  return snapshot.sort((a, b) => a.ruleId.localeCompare(b.ruleId));
}

function readBaseline() {
  return JSON.parse(fs.readFileSync(BASELINE_PATH, 'utf8'));
}

if (require.main === module && process.argv.includes('--write')) {
  buildSnapshot().then(snapshot => {
    fs.writeFileSync(BASELINE_PATH, JSON.stringify(snapshot, null, 2) + '\n');
    console.log(`wrote ${snapshot.length} rule snapshots to ${path.relative(process.cwd(), BASELINE_PATH)}`);
  });
}

module.exports = { buildSnapshot, readBaseline, BASELINE_PATH };
