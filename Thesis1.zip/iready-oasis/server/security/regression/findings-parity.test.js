'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { missing, startRuleServer } = require('./rule-server-fixture');
const store = require('../store');
const { createOrchestrator } = require('../orchestrator');
const { createLocalFindingsStore } = require('../findings-store/local');
const { createRuleServerClient } = require('../rule-sync/client');
const { createRuleSetCache } = require('../rule-sync/cache');
const { createRuleSync } = require('../rule-sync/sync');

// The server now keeps findings, merges rescans and records history. This holds it
// to what the scanner's own store did: the same scans, triage and baseline go
// through BOTH, and every finding, dashboard number and trend point must agree.

const REPO = 'parity-api';
const scanners = ['secrets-builtin', 'pattern-sast', 'iac-policy', 'sast-ast'].map(n => require(`../scanners/${n}`).scanner);

// A remote scan is finished once its upload outcome has been recorded; a local one has none.
async function waitForScan(orchestrator, id, expectOutcome) {
  for (let i = 0; i < 800; i++) {
    const scan = orchestrator.getScan(id);
    if (['FAILED', 'CANCELLED'].includes(scan.status)) return scan;
    if (scan.status === 'COMPLETED' && (!expectOutcome || (scan.perRepository || []).every(r => r.ruleServer))) return scan;
    await new Promise(r => setTimeout(r, 25));
  }
  throw new Error('scan did not finish in time');
}

// Everything about a finding that is a fact or a decision; ids and timestamps differ by design.
const view = f => ({
  status: f.status, severity: f.severity, type: f.type, file: f.file, startLine: f.startLine,
  suppression: f.suppression ? f.suppression.reason : null, resolvedBy: f.resolvedBy || null,
  riskScore: f.risk ? f.risk.score : null,
});

test('the rule server keeps findings exactly as the scanner\'s own store does, through scans, triage, resolution and baseline', { skip: missing }, async (t) => {
  const server = await startRuleServer(t);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-parity-'));
  t.after(() => fs.rmSync(work, { recursive: true, force: true }));

  const sync = createRuleSync({ client: createRuleServerClient({ baseUrl: server.base }), cache: createRuleSetCache(work), baseUrl: server.base });
  const ruleSet = await sync.refresh(REPO);
  const authored = ruleSet.rules.filter(r => (r.query || r.pattern) && !r.provenance && r.example).slice(0, 14);

  const repoPath = path.join(work, REPO);
  const git = (...a) => execFileSync('git', a, { cwd: repoPath, stdio: 'pipe' });
  for (const r of authored) {
    fs.mkdirSync(path.join(repoPath, r.id), { recursive: true });
    { const file = path.join(repoPath, r.id, r.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, r.example.vulnerable); }
  }
  git('init', '-q'); git('config', 'user.email', 't@example.com'); git('config', 'user.name', 't');
  git('add', '-A'); git('commit', '-q', '-m', 'base');

  const localDir = path.join(work, 'local');
  const remoteDir = path.join(work, 'remote');
  const local = createOrchestrator({ scanners, dir: localDir, userRulesDir: null, userGrammarsDir: null, findingsStore: createLocalFindingsStore({ store, dir: localDir }) });
  const remote = createOrchestrator({ scanners, dir: remoteDir, userRulesDir: null, userGrammarsDir: null, ruleSync: sync });
  t.after(() => Promise.all([local.shutdown(), remote.shutdown()]));
  assert.equal(remote.outboxStatus().queued, 0);

  const scanBoth = async () => {
    for (const [o, isLocal] of [[local, true], [remote, false]]) {
      const started = await o.startScan({ targets: [{ repository: REPO, repoPath, ruleSet }] });
      const done = await waitForScan(o, started.id, !isLocal);
      assert.equal(done.status, 'COMPLETED', done.error || '');
    }
  };
  const byFingerprint = async o => Object.fromEntries((await o.listFindings({ status: 'all' })).map(f => [f.fingerprint, view(f)]));
  const compare = async (label) => {
    assert.deepEqual(await byFingerprint(remote), await byFingerprint(local), `${label}: findings differ`);
    const [dl, dr] = [await local.dashboard(), await remote.dashboard()];
    for (const key of ['counts', 'total', 'resolved', 'suppressed', 'byType', 'newSinceBaseline']) {
      assert.deepEqual(dr[key], dl[key], `${label}: dashboard.${key} differs`);
    }
    assert.deepEqual(dr.byRepository, dl.byRepository, `${label}: dashboard.byRepository differs`);
    assert.deepEqual((dr.baseline || {}).count, (dl.baseline || {}).count, `${label}: baseline size differs`);
    const [tl, tr] = [await local.trends({ points: 50 }), await remote.trends({ points: 50 })];
    assert.deepEqual(tr.points.map(p => [p.total, p.counts]), tl.points.map(p => [p.total, p.counts]), `${label}: trend differs`);
    assert.deepEqual(tr.sinceLastScan, tl.sinceLastScan, `${label}: sinceLastScan differs`);
    for (const status of ['active', 'new', 'SUPPRESSED', 'RESOLVED']) {
      assert.deepEqual((await remote.listFindings({ status })).map(f => f.fingerprint).sort(),
        (await local.listFindings({ status })).map(f => f.fingerprint).sort(), `${label}: list ${status} differs`);
    }
  };

  await scanBoth();
  await compare('after the first scan');
  assert.ok(Object.keys(await byFingerprint(local)).length >= 10);

  // The same triage decision on both.
  const target = (await local.listFindings({})).find(f => f.type === 'SAST');
  const suppress = async o => {
    const f = (await o.listFindings({ status: 'all' })).find(x => x.fingerprint === target.fingerprint);
    return o.updateFinding(f.id, { status: 'SUPPRESSED', suppression: { reason: 'accepted', owner: 'me', decidedAt: 1 } });
  };
  await suppress(local); await suppress(remote);
  await local.setBaseline(); await remote.setBaseline();
  await compare('after triage and baseline');

  // Half the vulnerable code is fixed; one new finding appears.
  for (const r of authored.slice(0, 5).filter(r => r.id !== target.file.split('/')[0])) fs.rmSync(path.join(repoPath, r.id), { recursive: true, force: true });
  const fresh = authored[authored.length - 1];
  fs.mkdirSync(path.join(repoPath, 'brand-new'), { recursive: true });
  { const file = path.join(repoPath, 'brand-new', fresh.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, fresh.example.vulnerable); }
  git('add', '-A'); git('commit', '-q', '-m', 'fix some, add one');
  await scanBoth();
  await compare('after the second scan');
  const after = await byFingerprint(remote);
  assert.ok(Object.values(after).some(f => f.status === 'RESOLVED'), 'fixed code resolves its findings');
  assert.equal(after[target.fingerprint].status, 'SUPPRESSED', 'the suppression survived the rescan');

  // A third scan with nothing changed.
  await scanBoth();
  await compare('after an unchanged rescan');

  // Server-side history: one point per scan, in order, no duplicates.
  const history = (await (await fetch(`${server.base}/api/v1/history`)).json()).points;
  assert.equal(history.length, 3);
  assert.deepEqual(history.map(p => p.at), [...history.map(p => p.at)].sort((a, b) => a - b));
  assert.equal(new Set(history.map(p => p.analysisId)).size, 3);

  // Clearing behaves the same.
  assert.deepEqual((({ findings, suppressed }) => ({ findings, suppressed }))(await remote.clearPreview({ repository: REPO })),
    (({ findings, suppressed }) => ({ findings, suppressed }))(await local.clearPreview({ repository: REPO })));
});

test('a repository scanned on the new server before migrating gets its old suppressions and baseline through --merge, and nothing else changes', { skip: missing }, async (t) => {
  const { runMigration } = require('../../../tools/migrate-findings-to-rule-server');
  const server = await startRuleServer(t);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-migrate-e2e-'));
  t.after(() => fs.rmSync(work, { recursive: true, force: true }));
  const client = createRuleServerClient({ baseUrl: server.base });
  const sync = createRuleSync({ client, cache: createRuleSetCache(work), baseUrl: server.base });
  const ruleSet = await sync.refresh(REPO);
  const authored = ruleSet.rules.filter(r => (r.query || r.pattern) && !r.provenance && r.example).slice(0, 6);

  const repoPath = path.join(work, REPO);
  for (const r of authored) {
    fs.mkdirSync(path.join(repoPath, r.id), { recursive: true });
    { const file = path.join(repoPath, r.id, r.example.file); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, r.example.vulnerable); }
  }
  const target = { repository: REPO, repoPath, ruleSet };
  const run = async o => {
    const s = await o.startScan({ targets: [target] });
    for (let i = 0; i < 400; i++) {
      const x = o.getScan(s.id);
      if (x.status === 'COMPLETED' && (!x.perRepository.length || x.perRepository.every(r => r.ruleServer || o.outboxStatus() === null))) return;
      await new Promise(r => setTimeout(r, 25));
    }
  };

  // The old installation: findings in its own store, one suppressed, a baseline.
  const oldDir = path.join(work, 'old');
  const old = createOrchestrator({ scanners, dir: oldDir, userRulesDir: null, userGrammarsDir: null, findingsStore: createLocalFindingsStore({ store, dir: oldDir }) });
  t.after(() => old.shutdown());
  await run(old);
  const victim = (await old.listFindings({})).find(f => f.type === 'SAST');
  await old.updateFinding(victim.id, { status: 'SUPPRESSED', suppression: { reason: 'accepted long ago', owner: 'me', decidedAt: 1 } });
  await old.setBaseline();

  // The user scans on the new server BEFORE migrating: the finding comes back OPEN.
  const fresh = createOrchestrator({ scanners, dir: path.join(work, 'new'), userRulesDir: null, userGrammarsDir: null, ruleSync: sync });
  t.after(() => fresh.shutdown());
  await run(fresh);
  const before = (await fresh.listFindings({ status: 'all' })).find(f => f.fingerprint === victim.fingerprint);
  assert.equal(before.status, 'OPEN');
  const serverIds = Object.fromEntries((await fresh.listFindings({ status: 'all' })).map(f => [f.fingerprint, f.id]));

  // Plain migration refuses and says what to do instead.
  await assert.rejects(runMigration({ dir: oldDir, client, apply: true, log: () => {} }), /--merge/);

  const result = await runMigration({ dir: oldDir, client, apply: true, merge: true, log: () => {} });
  assert.equal(result.imported.adopted, 1);
  assert.equal(result.imported.inserted, 0);

  const after = await fresh.listFindings({ status: 'all' });
  const adopted = after.find(f => f.fingerprint === victim.fingerprint);
  assert.deepEqual([adopted.status, adopted.suppression.reason, adopted.suppression.owner], ['SUPPRESSED', 'accepted long ago', 'me']);
  assert.deepEqual(Object.fromEntries(after.map(f => [f.fingerprint, f.id])), serverIds, 'the server\'s ids are untouched');
  assert.ok((await fresh.dashboard()).baseline, 'the old baseline came across');

  // Migrating again changes nothing (re-running is safe).
  const again = await runMigration({ dir: oldDir, client, apply: true, merge: true, log: () => {} });
  assert.deepEqual([again.imported.inserted, again.imported.adopted], [0, 0]);
});
