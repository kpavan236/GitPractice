'use strict';
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const { spawn, execFileSync } = require('child_process');

// Starts a REAL oasis-rule-server (sibling repo) on a free port, seeded from its own
// seed/rules. Shared by the regression tests that prove the rule server
// changes nothing the scanner reports.

const OASIS = path.join(__dirname, '..', '..', '..');
const SERVER = path.join(OASIS, '..', 'oasis-rule-server');
const missing = fs.existsSync(path.join(SERVER, 'src', 'server.js')) ? false : 'sibling repo ../oasis-rule-server not found';

const freePort = () => new Promise(resolve => {
  const s = net.createServer().listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
});

async function waitHealthy(base) {
  for (let i = 0; i < 100; i++) {
    try { if ((await fetch(`${base}/api/v1/health`)).ok) return; } catch (_) { /* not up yet */ }
    await new Promise(r => setTimeout(r, 50));
  }
  throw new Error('rule server did not start');
}

async function startRuleServer(t) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-rs-'));
  t.after(() => fs.rmSync(tmp, { recursive: true, force: true }));
  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  const env = { ...process.env, OASIS_RULE_SERVER_DB: path.join(tmp, 'rules.db'), OASIS_RULE_SERVER_PORT: String(port) };
  execFileSync('node', [path.join(SERVER, 'scripts', 'seed.js')], { env, stdio: 'pipe' });

  let child = null;
  const spawnServer = () => { child = spawn('node', [path.join(SERVER, 'src', 'server.js')], { env, stdio: 'ignore' }); };
  spawnServer();
  t.after(() => { if (child) child.kill(); });
  await waitHealthy(base);

  return {
    base,
    tmp,
    // Stops the process and resolves once it has really exited (the port is free).
    stop: () => new Promise(resolve => {
      if (!child) return resolve();
      const done = child;
      child = null;
      done.once('exit', resolve);
      done.kill();
    }),
    // Brings the same database back on the same port.
    async restart() {
      if (child) return;
      spawnServer();
      await waitHealthy(base);
    },
  };
}

module.exports = { missing, startRuleServer, OASIS };
