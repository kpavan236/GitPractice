'use strict';
const path = require('path');
const os = require('os');

// Path helpers moved to oasis-analyzer; the user-level directories are
// scanner configuration and stay here.
const helpers = require('oasis-analyzer/src/paths');

const USER_SECURITY_DIR  = path.join(os.homedir(), '.oasis', 'security');
const USER_RULES_DIR     = path.join(USER_SECURITY_DIR, 'rules');
const USER_GRAMMARS_DIR  = path.join(USER_SECURITY_DIR, 'grammars');

module.exports = { ...helpers, USER_SECURITY_DIR, USER_RULES_DIR, USER_GRAMMARS_DIR };
