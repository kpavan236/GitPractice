'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scanContent, compileRule, rulesForPath } = require('./scanners/pattern-sast');

// The pattern engine's job is to be USEFUL WITHOUT BEING NOISY, so most of
// these tests are about what it refuses to report. A regex over a line will
// find its text anywhere; every mechanism below exists to stop it.

function rule(overrides = {}) {
  return compileRule({
    id: 'test-rule',
    language: 'dockerfile',
    files: '**/Dockerfile',
    pattern: 'USER\\s+root',
    severity: 'MEDIUM',
    category: 'CONTAINER_ROOT_USER',
    title: 'Runs as root',
    ...overrides,
  });
}

test('matches a line in a file its glob covers', () => {
  const findings = scanContent('FROM alpine\nUSER root\n', 'Dockerfile', 'repo', [rule()]);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].startLine, 2);
  assert.equal(findings[0].detections[0].ruleId, 'test-rule');
});

test('a glob is required — a rule without one does not compile', () => {
  // The single most damaging mistake available in this format. Without a glob
  // the rule runs against every file in the repository, so it is rejected here
  // and at build time rather than being given a permissive default.
  assert.equal(compileRule({ id: 'x', pattern: 'USER root', severity: 'LOW' }), null);
});

test('an invalid regex disables its own rule rather than throwing', () => {
  assert.equal(compileRule({ id: 'x', files: '**/*', pattern: '([unclosed', severity: 'LOW' }), null);
});

test('does not run against files outside its glob', () => {
  const findings = scanContent('USER root', 'README.md', 'repo', [rule()]);
  assert.deepEqual(findings, []);
  assert.deepEqual(rulesForPath([rule()], 'README.md'), []);
});

test('a glob matches at the repository root and in a subdirectory', () => {
  const r = rule({ files: '**/Dockerfile' });
  assert.equal(rulesForPath([r], 'Dockerfile').length, 1);
  assert.equal(rulesForPath([r], 'services/api/Dockerfile').length, 1);
});

test('accepts a list of globs', () => {
  const r = rule({ files: ['**/Dockerfile', '**/*.dockerfile'] });
  assert.equal(rulesForPath([r], 'build.dockerfile').length, 1);
});

test('ignores commented-out lines', () => {
  // The dominant false positive in config formats: half of a real Terraform or
  // Kubernetes file is commented-out configuration, and a warning that fires on
  // "# do not do this: USER root" trains people to ignore the scanner.
  const findings = scanContent('FROM alpine\n# USER root\n', 'Dockerfile', 'repo', [rule()]);
  assert.deepEqual(findings, []);
});

test('a rule can opt back into commented lines', () => {
  const findings = scanContent('# USER root\n', 'Dockerfile', 'repo', [rule({ includeComments: true })]);
  assert.equal(findings.length, 1);
});

test('is case-insensitive by default and exact when asked', () => {
  assert.equal(scanContent('user root\n', 'Dockerfile', 'repo', [rule()]).length, 1);
  assert.equal(scanContent('user root\n', 'Dockerfile', 'repo', [rule({ caseSensitive: true })]).length, 0);
});

test('negate suppresses the whole file', () => {
  const r = rule({ negate: 'USER\\s+app' });
  const findings = scanContent('USER root\nUSER app\n', 'Dockerfile', 'repo', [r]);
  assert.deepEqual(findings, []);
});

test('requiresContext gates on nearby text', () => {
  const r = rule({ requiresContext: 'production' });
  assert.equal(scanContent('USER root\n', 'Dockerfile', 'repo', [r]).length, 0);
  assert.equal(scanContent('# production image\nUSER root\n', 'Dockerfile', 'repo', [r]).length, 1);
});

test('an inline oasis:ignore marker suppresses the finding', () => {
  const findings = scanContent('USER root # oasis:ignore -- base image builds here', 'Dockerfile', 'repo', [rule()]);
  assert.deepEqual(findings, []);
});

test('a rule declares its own finding type', () => {
  // Without this every Dockerfile finding files itself under SAST, and "we have
  // no IaC coverage" becomes indistinguishable from "our IaC findings are
  // mislabelled".
  assert.equal(scanContent('USER root', 'Dockerfile', 'repo', [rule({ type: 'IAC' })])[0].type, 'IAC');
  assert.equal(scanContent('USER root', 'Dockerfile', 'repo', [rule()])[0].type, 'SAST');
});

test('low confidence drops the reported severity a band', () => {
  const findings = scanContent('USER root', 'Dockerfile', 'repo', [rule({ severity: 'HIGH', confidence: 'LOW' })]);
  assert.equal(findings[0].severity, 'MEDIUM');
  assert.match(findings[0].description, /without parsing the file/);
});

test('skips pathologically long lines', () => {
  // A minified bundle on one line: nothing useful is ever found there, and a
  // rule with a bad regex would run over the whole thing.
  const findings = scanContent(`${'x'.repeat(5000)}USER root`, 'Dockerfile', 'repo', [rule()]);
  assert.deepEqual(findings, []);
});

test('reports every occurrence in a file', () => {
  const findings = scanContent('USER root\nRUN x\nUSER root\n', 'Dockerfile', 'repo', [rule()]);
  assert.deepEqual(findings.map(f => f.startLine), [1, 3]);
});

test('records the engine that produced the finding', () => {
  // A reader deciding how much to trust a finding needs to know whether a
  // parser or a regex found it.
  assert.equal(scanContent('USER root', 'Dockerfile', 'repo', [rule()])[0].metadata.engine, 'pattern');
});

test('a bundled rule tags its finding metadata.ruleSource as bundled', () => {
  assert.equal(scanContent('USER root', 'Dockerfile', 'repo', [rule()])[0].metadata.ruleSource, 'bundled');
});

test("a user-pack rule's finding is tagged metadata.ruleSource: 'user'", () => {
  // The rule carries source:'user' (local-rules.js's loadUserPacks tags it);
  // the finding it produces has to say so too, so the UI can filter or badge
  // findings that came from an unsigned, user-authored rule.
  const r = rule({ source: 'user' });
  assert.equal(scanContent('USER root', 'Dockerfile', 'repo', [r])[0].metadata.ruleSource, 'user');
});
