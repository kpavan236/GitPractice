'use strict';
const https = require('https');

// Secret validity checking.
//
// The question that separates a real incident from a chore: is this credential
// still live? A rotated AWS key in an old config file and an active one are the
// same string to a regex, and treating them alike is why secret scanners get
// ignored. Asking the provider collapses that ambiguity — GitHub, TruffleHog v3
// and GitGuardian all do it, and it is what turns 27 maybes into a short list.
//
// OFF BY DEFAULT, AND THAT IS NOT TIMIDITY.
//
// Verifying means transmitting a live credential over the network. It goes to
// the credential's own issuer — an AWS key to AWS, a GitHub token to GitHub —
// which is the least surprising possible destination, and each probe below is
// read-only and identity-shaped (`GetCallerIdentity`, `GET /user`). But it is
// still an outbound call carrying a CA secret from a developer laptop, and that
// is a decision for the person running the scan, not a default someone
// discovers afterwards. Enable with OASIS_SECRET_VERIFY=1.
//
// A verified-live credential is an incident: it is in git history, and rotation
// is the only remedy.

const TIMEOUT_MS = 8000;

// Probes are deliberately the cheapest read-only identity endpoint each
// provider offers. Nothing here creates, modifies, or lists resources.
const PROBES = {
  'github-pat': {
    provider: 'GitHub',
    check: token => request({ host: 'api.github.com', path: '/user', headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'i-Ready-OASIS' } }),
    live: status => status === 200,
    dead: status => status === 401,
  },
  'github-fine-grained-pat': {
    provider: 'GitHub',
    check: token => request({ host: 'api.github.com', path: '/user', headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'i-Ready-OASIS' } }),
    live: status => status === 200,
    dead: status => status === 401,
  },
  'slack-token': {
    provider: 'Slack',
    check: token => request({ host: 'slack.com', path: '/api/auth.test', headers: { Authorization: `Bearer ${token}` } }),
    // Slack answers 200 with {"ok":false} for a dead token, so the body decides.
    live: (status, body) => status === 200 && /"ok"\s*:\s*true/.test(body),
    dead: (status, body) => status === 200 && /"ok"\s*:\s*false/.test(body),
  },
  'npm-token': {
    provider: 'npm',
    check: token => request({ host: 'registry.npmjs.org', path: '/-/whoami', headers: { Authorization: `Bearer ${token}` } }),
    live: status => status === 200,
    dead: status => status === 401,
  },
  'stripe-secret-key': {
    provider: 'Stripe',
    // /v1/account is read-only and returns 401 for a revoked key.
    check: key => request({ host: 'api.stripe.com', path: '/v1/account', headers: { Authorization: `Bearer ${key}` } }),
    live: status => status === 200,
    dead: status => status === 401,
  },
  'google-api-key': {
    provider: 'Google',
    check: key => request({ host: 'www.googleapis.com', path: `/customsearch/v1?key=${encodeURIComponent(key)}&q=t` }),
    // 400 means the key was accepted and the request was malformed; 403 with
    // API_KEY_INVALID means the key itself is rejected.
    live: (status, body) => status === 400 || (status === 403 && !/API_KEY_INVALID/.test(body)),
    dead: (status, body) => status === 403 && /API_KEY_INVALID/.test(body),
  },
};

function request({ host, path, headers = {} }) {
  return new Promise(resolve => {
    const req = https.request({ host, path, method: 'GET', headers, timeout: TIMEOUT_MS }, res => {
      let body = '';
      res.setEncoding('utf8');
      // Identity endpoints return small payloads; cap anyway so a hostile or
      // misbehaving endpoint cannot stream indefinitely into memory.
      res.on('data', chunk => { if (body.length < 8192) body += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('timeout', () => { req.destroy(); resolve({ status: 0, body: '', error: 'timeout' }); });
    req.on('error', err => resolve({ status: 0, body: '', error: err.message }));
    req.end();
  });
}

function isEnabled(env = process.env) {
  return env.OASIS_SECRET_VERIFY === '1';
}

function canVerify(ruleId) {
  return Object.prototype.hasOwnProperty.call(PROBES, ruleId);
}

/**
 * Verifies one credential.
 *
 * Returns { verified, state, provider } where state is:
 *   'live'      the provider accepted it — this is an incident
 *   'revoked'   the provider rejected it — still worth removing, not urgent
 *   'unknown'   we could not tell: no probe, network failure, or an
 *               unexpected status. Never reported as either of the above.
 */
async function verifySecret(ruleId, secret, { fetch = null } = {}) {
  const probe = PROBES[ruleId];
  if (!probe || !secret) return { verified: false, state: 'unknown', provider: null };

  const result = await (fetch ? fetch(ruleId, secret) : probe.check(secret));
  const { status, body = '' } = result || {};

  if (probe.live(status, body)) return { verified: true, state: 'live', provider: probe.provider };
  if (probe.dead(status, body)) return { verified: true, state: 'revoked', provider: probe.provider };

  // Rate limits, outages, proxies, anything unexpected. Guessing here would be
  // worse than admitting ignorance: a false "revoked" retires a live key in
  // someone's head.
  return { verified: false, state: 'unknown', provider: probe.provider, reason: result && result.error };
}

/**
 * Verifies the secrets behind a set of findings, in place.
 *
 * The plaintext is not on the finding — it is deliberately never stored — so
 * the caller supplies a lookup from finding to secret, which only the scanner
 * that produced it can provide, and only during the scan that found it.
 */
async function verifyFindings(findings, secretsByFingerprint, { env = process.env, fetch = null } = {}) {
  if (!isEnabled(env)) {
    return { attempted: 0, live: 0, revoked: 0, skipped: 'verification disabled (set OASIS_SECRET_VERIFY=1)' };
  }

  let attempted = 0;
  let live = 0;
  let revoked = 0;

  for (const finding of findings) {
    if (finding.type !== 'SECRET') continue;
    const ruleId = finding.detections[0] && finding.detections[0].ruleId;
    if (!canVerify(ruleId)) continue;

    const secret = secretsByFingerprint.get(finding.fingerprint);
    if (!secret) continue;

    attempted += 1;
    const result = await verifySecret(ruleId, secret, { fetch });
    const md = finding.metadata || (finding.metadata = {});
    md.verified = result.verified && result.state === 'live';
    md.verificationState = result.state;
    md.verificationProvider = result.provider;

    if (result.state === 'live') {
      live += 1;
      // A live credential in source is not a "potential" anything.
      finding.severity = 'CRITICAL';
      finding.title = `${finding.title} — VERIFIED LIVE`;
      finding.description =
        `This credential was confirmed active with ${result.provider}. It is in the repository and must be rotated now; ` +
        'removing the file does not revoke it.';
    } else if (result.state === 'revoked') {
      revoked += 1;
      // Still worth removing — it documents an old leak and clutters triage —
      // but it is not an incident, and pretending otherwise costs credibility.
      finding.severity = 'LOW';
      finding.description = `${finding.description} ${result.provider} reports this credential is no longer valid.`;
    }
  }

  return { attempted, live, revoked };
}

module.exports = { verifySecret, verifyFindings, isEnabled, canVerify, PROBES };