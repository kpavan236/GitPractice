'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { publishScan, buildPayload, platformUrl } = require('./publish');

const SCAN = { id: 'SCAN-1', status: 'COMPLETED', startedAt: 1000, finishedAt: 2000, ruleBundleVersion: '1.1.4' };
const COVERAGE = [{ type: 'SAST', analysed: true }];

function secretFinding() {
  const f = {
    fingerprint: 'abc',
    type: 'SECRET',
    category: 'AWS_ACCESS_KEY_ID',
    severity: 'CRITICAL',
    title: 'AWS access key',
    file: 'src/App.java',
    startLine: 4,
    detections: [{ source: 'BUILTIN_SECRETS', ruleId: 'aws-access-key-id' }],
    metadata: { masked: 'AKIA****LKEY', secretHash: 'a'.repeat(64), entropy: 3.9 },
  };
  // The scanner attaches the plaintext on a non-enumerable field. It must not
  // survive into anything that crosses a network.
  Object.defineProperty(f, '_plaintext', { value: 'AKIAIOSFODNN7REALKEY', enumerable: false });
  return f;
}

test('does nothing when no platform is configured', () => {
  // The normal case. OASIS is a desktop tool that must work with no server, so
  // an unconfigured install must not warn, retry, or fail.
  return publishScan({ repository: 'r', scan: SCAN, findings: [], coverage: COVERAGE }, { env: {} })
    .then(result => {
      assert.equal(result.skipped, true);
      assert.equal(result.published, false);
    });
});

test('posts to the platform when configured', async () => {
  let seen = null;
  const send = async (url, body) => {
    seen = { url, body };
    return { opened: 2, resolved: 1 };
  };

  const result = await publishScan(
    { repository: 'iready-core', scan: SCAN, findings: [secretFinding()], coverage: COVERAGE, gate: { status: 'PASSED' } },
    { env: { OASIS_PLATFORM_URL: 'https://platform.example.invalid/' }, send }
  );

  assert.equal(result.published, true);
  // The trailing slash on the configured URL must not produce a double slash.
  assert.equal(seen.url, 'https://platform.example.invalid/api/v1/scans');
  assert.equal(seen.body.project.key, 'iready-core');
  assert.equal(seen.body.scan.externalId, 'SCAN-1');
  assert.equal(seen.body.findings.length, 1);
});

test('THE SECRET NEVER CROSSES THE NETWORK', () => {
  // The single most important property of this module. The scanner already
  // keeps the plaintext non-enumerable so JSON.stringify skips it, but this
  // payload is built by hand precisely so a future field cannot smuggle it out.
  const payload = buildPayload({
    repository: 'r',
    scan: SCAN,
    findings: [secretFinding()],
    coverage: COVERAGE,
  });

  const serialised = JSON.stringify(payload);
  assert.equal(serialised.includes('AKIAIOSFODNN7REALKEY'), false, 'the raw credential left the machine');
  assert.equal(serialised.includes('_plaintext'), false);
  // …while the parts that SHOULD travel do.
  assert.equal(payload.findings[0].metadata.masked, 'AKIA****LKEY');
  assert.equal(payload.findings[0].metadata.secretHash.length, 64);
});

test('the payload is an explicit projection, not the whole finding', () => {
  // Spreading the finding would forward the per-scanner stats blob and any
  // field added later, including ones nobody meant to publish.
  const payload = buildPayload({
    repository: 'r',
    scan: SCAN,
    coverage: COVERAGE,
    findings: [{
      fingerprint: 'x', type: 'SAST', severity: 'HIGH', title: 't', detections: [],
      metadata: { snippet: 'const password = "hunter2"', internalDebugState: { huge: true } },
    }],
  });

  const meta = payload.findings[0].metadata;
  // The snippet can contain the very line a credential sits on.
  assert.equal(meta.snippet, undefined);
  assert.equal(meta.internalDebugState, undefined);
});

test('a failure is reported, never thrown', async () => {
  // The findings are already stored locally. Failing the scan over a 502 would
  // teach people to switch the integration off.
  const send = async () => { throw new Error('HTTP 502: bad gateway'); };
  const result = await publishScan(
    { repository: 'r', scan: SCAN, findings: [], coverage: COVERAGE },
    { env: { OASIS_PLATFORM_URL: 'https://x.invalid' }, send }
  );

  assert.equal(result.published, false);
  assert.equal(result.skipped, false);
  assert.match(result.error, /502/);
});

test('sends the token when one is configured', async () => {
  let opts = null;
  const send = async (_url, _body, o) => { opts = o; return {}; };
  await publishScan(
    { repository: 'r', scan: SCAN, findings: [], coverage: COVERAGE },
    { env: { OASIS_PLATFORM_URL: 'https://x.invalid', OASIS_PLATFORM_TOKEN: 'tok' }, send }
  );
  assert.equal(opts.token, 'tok');
});

test('new-code marking survives the trip', async () => {
  // The gate on the platform side is only as good as this flag arriving.
  const payload = buildPayload({
    repository: 'r', scan: SCAN, coverage: COVERAGE,
    findings: [{ fingerprint: 'a', type: 'SAST', severity: 'HIGH', title: 't', isNewCode: true, detections: [] }],
  });
  assert.equal(payload.findings[0].isNewCode, true);
});

test('platformUrl reads the environment', () => {
  assert.equal(platformUrl({}), null);
  assert.equal(platformUrl({ OASIS_PLATFORM_URL: 'http://x' }), 'http://x');
});
