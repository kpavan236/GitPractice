'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parsePom, resolve, expand } = require('./maven-resolver');

// A tiny in-memory Maven repository. Keys are group:artifact:version.
function repo(poms) {
  const calls = [];
  const fetchPom = async (g, a, v) => {
    calls.push(`${g}:${a}:${v}`);
    return poms[`${g}:${a}:${v}`] || null;
  };
  fetchPom.calls = calls;
  return fetchPom;
}

const pom = ({ g = 'com.example', a, v, parent, props = {}, deps = [], managed = [], licenses = [] }) => `
<project>
  ${parent ? `<parent><groupId>${parent.g}</groupId><artifactId>${parent.a}</artifactId><version>${parent.v}</version></parent>` : ''}
  <groupId>${g}</groupId><artifactId>${a}</artifactId>${v ? `<version>${v}</version>` : ''}
  ${licenses.length ? `<licenses>${licenses.map(n => `<license><name>${n}</name></license>`).join('')}</licenses>` : ''}
  <properties>${Object.entries(props).map(([k, val]) => `<${k}>${val}</${k}>`).join('')}</properties>
  ${managed.length ? `<dependencyManagement><dependencies>${managed.map(depXml).join('')}</dependencies></dependencyManagement>` : ''}
  <dependencies>${deps.map(depXml).join('')}</dependencies>
</project>`;

function depXml(d) {
  return `<dependency>
    <groupId>${d.g}</groupId><artifactId>${d.a}</artifactId>
    ${d.v ? `<version>${d.v}</version>` : ''}
    ${d.scope ? `<scope>${d.scope}</scope>` : ''}
    ${d.optional ? '<optional>true</optional>' : ''}
    ${d.exclude ? `<exclusions>${d.exclude.map(e => `<exclusion><groupId>${e.split(':')[0]}</groupId><artifactId>${e.split(':')[1]}</artifactId></exclusion>`).join('')}</exclusions>` : ''}
  </dependency>`;
}

const names = r => r.dependencies.map(d => `${d.name}@${d.version}`).sort();

// ── Parsing ────────────────────────────────────────────────────────────────

test('a POM yields coordinates, properties, and dependencies', () => {
  const parsed = parsePom(pom({ a: 'app', v: '1.0', props: { 'log4j.version': '2.14.1' }, deps: [{ g: 'org.apache', a: 'log4j', v: '${log4j.version}' }] }));
  assert.equal(parsed.artifactId, 'app');
  assert.equal(parsed.version, '1.0');
  assert.equal(parsed.properties['log4j.version'], '2.14.1');
  assert.equal(parsed.dependencies.length, 1);
});

test('a module inherits its version from the parent', () => {
  // The norm in a multi-module build, and a POM the parser must not reject.
  const parsed = parsePom(pom({ a: 'child', parent: { g: 'com.example', a: 'parent', v: '2.0' } }));
  assert.equal(parsed.version, '2.0');
  assert.equal(parsed.parent.artifactId, 'parent');
});

test('properties expand, including nested references', () => {
  assert.equal(expand('${a}', { a: '1.0' }), '1.0');
  assert.equal(expand('${a}', { a: '${b}', b: '2.0' }), '2.0');
  // A cycle must terminate rather than hang the scan.
  assert.equal(typeof expand('${a}', { a: '${a}' }), 'string');
});

// ── The point of the exercise ──────────────────────────────────────────────

test('transitive dependencies are resolved, not just declared ones', async () => {
  const fetchPom = repo({
    'org.springframework.boot:spring-boot-starter-log4j2:2.5.0': pom({
      g: 'org.springframework.boot', a: 'spring-boot-starter-log4j2', v: '2.5.0',
      deps: [{ g: 'org.apache.logging.log4j', a: 'log4j-core', v: '2.14.1' }],
    }),
    'org.apache.logging.log4j:log4j-core:2.14.1': pom({ g: 'org.apache.logging.log4j', a: 'log4j-core', v: '2.14.1' }),
  });

  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'org.springframework.boot', a: 'spring-boot-starter-log4j2', v: '2.5.0' }] }),
    fetchPom
  );

  // The Log4Shell shape exactly: the vulnerable artifact is never declared.
  const log4j = result.dependencies.find(d => d.name === 'org.apache.logging.log4j:log4j-core');
  assert.ok(log4j, `log4j-core not resolved; got ${JSON.stringify(names(result))}`);
  assert.equal(log4j.version, '2.14.1');
  assert.equal(log4j.direct, false);
  assert.equal(log4j.depth, 1);
});

test('a BOM import supplies versions for dependencies that omit them', async () => {
  // Every Spring Boot project works this way. Without import support these
  // dependencies resolve to no version at all.
  const fetchPom = repo({
    'org.springframework.boot:spring-boot-dependencies:2.5.0': pom({
      g: 'org.springframework.boot', a: 'spring-boot-dependencies', v: '2.5.0',
      managed: [{ g: 'com.fasterxml.jackson.core', a: 'jackson-databind', v: '2.12.3' }],
    }),
    'com.fasterxml.jackson.core:jackson-databind:2.12.3': pom({ g: 'com.fasterxml.jackson.core', a: 'jackson-databind', v: '2.12.3' }),
  });

  const rootXml = `<project><groupId>com.example</groupId><artifactId>app</artifactId><version>1.0</version>
    <dependencyManagement><dependencies><dependency>
      <groupId>org.springframework.boot</groupId><artifactId>spring-boot-dependencies</artifactId>
      <version>2.5.0</version><type>pom</type><scope>import</scope>
    </dependency></dependencies></dependencyManagement>
    <dependencies><dependency>
      <groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId>
    </dependency></dependencies></project>`;

  const result = await resolve(rootXml, fetchPom);
  const jackson = result.dependencies.find(d => d.name === 'com.fasterxml.jackson.core:jackson-databind');
  assert.ok(jackson, `jackson not resolved; unresolved: ${JSON.stringify(result.unresolved)}`);
  assert.equal(jackson.version, '2.12.3');
});

test('dependencyManagement in a parent supplies a missing version', async () => {
  const fetchPom = repo({
    'com.example:parent:1.0': pom({ a: 'parent', v: '1.0', managed: [{ g: 'org.apache', a: 'commons', v: '3.2.1' }] }),
    'org.apache:commons:3.2.1': pom({ g: 'org.apache', a: 'commons', v: '3.2.1' }),
  });
  const result = await resolve(
    pom({ a: 'child', parent: { g: 'com.example', a: 'parent', v: '1.0' }, deps: [{ g: 'org.apache', a: 'commons' }] }),
    fetchPom
  );
  assert.equal(result.dependencies.find(d => d.name === 'org.apache:commons').version, '3.2.1');
});

// ── Maven's rules ──────────────────────────────────────────────────────────

test('nearest wins when two paths disagree on a version', async () => {
  const fetchPom = repo({
    'com.example:direct:1.0': pom({ a: 'direct', v: '1.0', deps: [{ g: 'com.example', a: 'shared', v: '1.0' }] }),
    'com.example:middle:1.0': pom({ a: 'middle', v: '1.0', deps: [{ g: 'com.example', a: 'deep', v: '1.0' }] }),
    'com.example:deep:1.0': pom({ a: 'deep', v: '1.0', deps: [{ g: 'com.example', a: 'shared', v: '9.9' }] }),
    'com.example:shared:1.0': pom({ a: 'shared', v: '1.0' }),
    'com.example:shared:9.9': pom({ a: 'shared', v: '9.9' }),
  });
  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'com.example', a: 'direct', v: '1.0' }, { g: 'com.example', a: 'middle', v: '1.0' }] }),
    fetchPom
  );
  // 1.0 sits one level down; 9.9 sits three. Maven takes the nearer.
  assert.equal(result.dependencies.find(d => d.name === 'com.example:shared').version, '1.0');
});

test('test and provided scopes do not propagate', async () => {
  // Maven's rule. Treating them as transitive would report libraries that are
  // never shipped.
  const fetchPom = repo({
    'com.example:lib:1.0': pom({ a: 'lib', v: '1.0', deps: [{ g: 'junit', a: 'junit', v: '4.12', scope: 'test' }] }),
  });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'com.example', a: 'lib', v: '1.0' }] }), fetchPom);
  assert.equal(result.dependencies.some(d => d.name === 'junit:junit'), false);
});

test("a project's own test dependencies are still reported", async () => {
  // They are not shipped, but a vulnerable test library still runs on a build
  // agent — and it is declared here, not dragged in.
  const fetchPom = repo({ 'junit:junit:4.12': pom({ g: 'junit', a: 'junit', v: '4.12' }) });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'junit', a: 'junit', v: '4.12', scope: 'test' }] }), fetchPom);
  assert.ok(result.dependencies.some(d => d.name === 'junit:junit'));
});

test('exclusions prune the subtree', async () => {
  const fetchPom = repo({
    'com.example:lib:1.0': pom({ a: 'lib', v: '1.0', deps: [{ g: 'bad', a: 'transitive', v: '1.0' }] }),
    'bad:transitive:1.0': pom({ g: 'bad', a: 'transitive', v: '1.0' }),
  });
  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'com.example', a: 'lib', v: '1.0', exclude: ['bad:transitive'] }] }),
    fetchPom
  );
  assert.equal(result.dependencies.some(d => d.name === 'bad:transitive'), false);
});

test('an optional transitive dependency is not pulled in', async () => {
  const fetchPom = repo({
    'com.example:lib:1.0': pom({ a: 'lib', v: '1.0', deps: [{ g: 'opt', a: 'thing', v: '1.0', optional: true }] }),
  });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'com.example', a: 'lib', v: '1.0' }] }), fetchPom);
  assert.equal(result.dependencies.some(d => d.name === 'opt:thing'), false);
});

// ── Licences ───────────────────────────────────────────────────────────────
//
// A dependency's licence decides whether it is reported as an obligation, so a
// licence the resolver fails to read becomes a MEDIUM "unknown licence" finding
// against an artifact that declared one all along. Those false positives are
// what make the whole licence report unreadable: 40 rows nobody can act on.

test("a dependency's own <licenses> is read", async () => {
  const fetchPom = repo({ 'ok:lib:1.0': pom({ g: 'ok', a: 'lib', v: '1.0', licenses: ['Apache License, Version 2.0'] }) });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'ok', a: 'lib', v: '1.0' }] }), fetchPom);

  assert.deepEqual(result.dependencies[0].licenses, ['Apache License, Version 2.0']);
});

test('a licence declared on the immediate parent is inherited', async () => {
  const fetchPom = repo({
    'ok:lib:1.0': pom({ g: 'ok', a: 'lib', v: '1.0', parent: { g: 'ok', a: 'lib-parent', v: '1.0' } }),
    'ok:lib-parent:1.0': pom({ g: 'ok', a: 'lib-parent', v: '1.0', licenses: ['Apache License, Version 2.0'] }),
  });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'ok', a: 'lib', v: '1.0' }] }), fetchPom);

  assert.deepEqual(result.dependencies[0].licenses, ['Apache License, Version 2.0']);
});

test('a licence on an intermediate parent survives a grandparent that declares none', async () => {
  // Netty exactly: netty-codec-http declares no licence, netty-parent declares
  // Apache-2.0, and netty-parent's own parent (org.sonatype.oss:oss-parent)
  // declares nothing. Only consulting the TOP of the chain reads the empty
  // grandparent and reports Apache-licensed Netty as an unknown licence.
  const fetchPom = repo({
    'io.netty:netty-codec-http:4.1.127.Final': pom({
      g: 'io.netty', a: 'netty-codec-http', v: '4.1.127.Final',
      parent: { g: 'io.netty', a: 'netty-parent', v: '4.1.127.Final' },
    }),
    'io.netty:netty-parent:4.1.127.Final': pom({
      g: 'io.netty', a: 'netty-parent', v: '4.1.127.Final',
      parent: { g: 'org.sonatype.oss', a: 'oss-parent', v: '9' },
      licenses: ['Apache License, Version 2.0'],
    }),
    'org.sonatype.oss:oss-parent:9': pom({ g: 'org.sonatype.oss', a: 'oss-parent', v: '9' }),
  });

  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'io.netty', a: 'netty-codec-http', v: '4.1.127.Final' }] }),
    fetchPom
  );

  assert.deepEqual(result.dependencies[0].licenses, ['Apache License, Version 2.0']);
});

test('the nearest declaration wins when a child and its parent disagree', async () => {
  // Maven does not merge them: a child that states its own licence has restated
  // it deliberately, and the parent's is not also in force.
  const fetchPom = repo({
    'ok:lib:1.0': pom({ g: 'ok', a: 'lib', v: '1.0', parent: { g: 'ok', a: 'p', v: '1.0' }, licenses: ['MIT'] }),
    'ok:p:1.0': pom({ g: 'ok', a: 'p', v: '1.0', licenses: ['GPL-3.0'] }),
  });
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'ok', a: 'lib', v: '1.0' }] }), fetchPom);

  assert.deepEqual(result.dependencies[0].licenses, ['MIT']);
});

test('a dependency whose POM could not be fetched is marked unavailable, not unlicensed', async () => {
  // "No licence declared" and "we never saw the POM" are different facts. An
  // artifact in a private Nexus reads as the first and is really the second,
  // and telling them apart is the difference between "add a licence" and
  // "point the scanner at the repository that has it".
  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'com.cainc.commons', a: 'internal-lib', v: '1.0' }] }),
    repo({})
  );

  const dep = result.dependencies[0];
  assert.equal(dep.name, 'com.cainc.commons:internal-lib');
  assert.deepEqual(dep.licenses, []);
  assert.equal(dep.pomAvailable, false);
});

// ── Failure is reported, never guessed ─────────────────────────────────────

test('a dependency with no resolvable version is recorded, not invented', async () => {
  // Querying OSV with a guessed version returns a confident wrong answer.
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'x', a: 'y' }] }), repo({}));
  assert.equal(result.dependencies.length, 0);
  assert.equal(result.unresolved[0].artifactId, 'y');
  assert.match(result.unresolved[0].reason, /no version/);
});

test('a version range is refused rather than approximated', async () => {
  const result = await resolve(pom({ a: 'app', v: '1.0', deps: [{ g: 'x', a: 'y', v: '[1.0,2.0)' }] }), repo({}));
  assert.equal(result.dependencies.length, 0);
  assert.match(result.unresolved[0].reason, /unresolvable/);
});

test('a POM that cannot be fetched is recorded and the walk continues', async () => {
  const fetchPom = repo({ 'ok:lib:1.0': pom({ g: 'ok', a: 'lib', v: '1.0' }) });
  const result = await resolve(
    pom({ a: 'app', v: '1.0', deps: [{ g: 'missing', a: 'lib', v: '1.0' }, { g: 'ok', a: 'lib', v: '1.0' }] }),
    fetchPom
  );
  // The reachable half still resolves.
  assert.ok(result.dependencies.some(d => d.name === 'ok:lib'));
  assert.ok(result.fetchFailures.some(f => f.startsWith('missing:lib')));
});

test('the artifact cap is reported rather than silently applied', async () => {
  const poms = {};
  const deps = [];
  for (let i = 0; i < 20; i++) {
    deps.push({ g: 'com.example', a: `lib${i}`, v: '1.0' });
    poms[`com.example:lib${i}:1.0`] = pom({ a: `lib${i}`, v: '1.0' });
  }
  const result = await resolve(pom({ a: 'app', v: '1.0', deps }), repo(poms), { maxArtifacts: 5 });
  assert.equal(result.truncated, true);
});

test('a parent cycle terminates', async () => {
  const fetchPom = repo({
    'com.example:a:1.0': pom({ a: 'a', v: '1.0', parent: { g: 'com.example', a: 'b', v: '1.0' } }),
    'com.example:b:1.0': pom({ a: 'b', v: '1.0', parent: { g: 'com.example', a: 'a', v: '1.0' } }),
  });
  const result = await resolve(pom({ a: 'app', v: '1.0', parent: { g: 'com.example', a: 'a', v: '1.0' } }), fetchPom);
  assert.ok(Array.isArray(result.dependencies));
});
