'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  load,
  save,
  mergeFindings,
  recordScan,
  MAX_SCAN_HISTORY,
  EMPTY,
  loadGateConfig,
  saveGateConfig,
  clearGateConfig,
  loadIgnoreConfig,
  saveIgnoreConfig,
  clearIgnoreConfig,
} = require('./store');

const NOW = 1700000000000;

function stored(overrides = {}) {
  return {
    id: 'F-1',
    fingerprint: 'fp-1',
    type: 'SAST',
    repository: 'repo-a',
    severity: 'HIGH',
    status: 'OPEN',
    detections: [{ source: 'SEMGREP', ruleId: 'r1' }],
    firstSeenAt: NOW - 86400000,
    lastSeenAt: NOW - 86400000,
    ...overrides,
  };
}

function incoming(overrides = {}) {
  return { ...stored(), firstSeenAt: null, lastSeenAt: null, ...overrides };
}

const opts = { repository: 'repo-a', coveredTypes: ['SAST'], now: NOW };

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-secstore-'));
}

// ── Persistence ────────────────────────────────────────────────────────────

test('a missing store reads as empty', () => {
  assert.deepEqual(load(path.join(tmpDir(), 'absent')), EMPTY);
});

test('the store survives a round trip', () => {
  const dir = tmpDir();
  save({ ...EMPTY, findings: [stored()] }, dir);
  assert.equal(load(dir).findings.length, 1);
});

test('a corrupt store starts clean rather than breaking the tab', () => {
  // Every finding is reproducible by rescanning, so refusing to open would
  // cost more than starting over.
  const dir = tmpDir();
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'store.json'), '{"findings": [tru');
  assert.deepEqual(load(dir), EMPTY);
});

test('the store is not world readable', () => {
  const dir = tmpDir();
  save({ ...EMPTY }, dir);
  assert.equal(fs.statSync(path.join(dir, 'store.json')).mode & 0o077, 0);
});

// ── Merging: the part that is easy to get wrong ────────────────────────────

test('a finding reported again keeps its original first-seen date', () => {
  const merged = mergeFindings([stored()], [incoming()], opts);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].firstSeenAt, NOW - 86400000);
  assert.equal(merged[0].lastSeenAt, NOW);
});

test('a finding that stops being reported is resolved', () => {
  const merged = mergeFindings([stored()], [], opts);
  assert.equal(merged[0].status, 'RESOLVED');
  assert.equal(merged[0].resolvedAt, NOW);
});

test('resolution says it was only "no longer detected"', () => {
  // No build ran, no tests ran, no verification happened. Labelling this
  // VERIFIED would claim something we have not earned.
  const merged = mergeFindings([stored()], [], opts);
  assert.equal(merged[0].resolvedBy, 'NOT_DETECTED');
});

test('a scan that could not have found it does NOT resolve it', () => {
  // The bug this prevents: Semgrep is not installed, the SAST scanner is
  // skipped, and every SAST finding silently reports itself fixed.
  const merged = mergeFindings([stored()], [], { repository: 'repo-a', coveredTypes: ['SECRET'], now: NOW });
  assert.equal(merged[0].status, 'OPEN');
});

test('scanning one repository does not resolve findings in another', () => {
  const merged = mergeFindings([stored({ repository: 'repo-b' })], [], opts);
  assert.equal(merged[0].status, 'OPEN');
});

test('a resolved finding that comes back is reopened, not created fresh', () => {
  const merged = mergeFindings([stored({ status: 'RESOLVED' })], [incoming()], opts);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].status, 'REOPENED');
  assert.equal(merged[0].id, 'F-1');
});

test('a suppression survives a rescan', () => {
  // Someone who triaged this once should not have to triage it again every
  // time a scan runs.
  const suppression = { reason: 'accepted risk', owner: 'sec-team', decidedAt: NOW };
  const merged = mergeFindings([stored({ status: 'SUPPRESSED', suppression })], [incoming()], opts);
  assert.equal(merged[0].status, 'SUPPRESSED');
  assert.deepEqual(merged[0].suppression, suppression);
});

test('a false positive stays a false positive when re-detected', () => {
  const merged = mergeFindings([stored({ status: 'FALSE_POSITIVE' })], [incoming()], opts);
  assert.equal(merged[0].status, 'FALSE_POSITIVE');
});

test('a suppressed finding is not resolved when it stops being reported', () => {
  const merged = mergeFindings([stored({ status: 'SUPPRESSED' })], [], opts);
  assert.equal(merged[0].status, 'SUPPRESSED');
});

test('facts are refreshed even when the status is preserved', () => {
  const merged = mergeFindings(
    [stored({ status: 'SUPPRESSED', severity: 'LOW' })],
    [incoming({ severity: 'CRITICAL' })],
    opts
  );
  assert.equal(merged[0].severity, 'CRITICAL');
  assert.equal(merged[0].status, 'SUPPRESSED');
});

test('a genuinely new finding is added', () => {
  const merged = mergeFindings([stored()], [incoming({ fingerprint: 'fp-2', id: 'F-2' })], opts);
  assert.equal(merged.length, 2);
  assert.equal(merged.find(f => f.fingerprint === 'fp-2').firstSeenAt, NOW);
});

test('an existing finding keeps its id so links stay valid', () => {
  const merged = mergeFindings([stored()], [incoming({ id: 'F-999' })], opts);
  assert.equal(merged[0].id, 'F-1');
});

// ── Scan history ───────────────────────────────────────────────────────────

test('scan history is capped and newest first', () => {
  let scans = [];
  for (let i = 0; i < MAX_SCAN_HISTORY + 10; i++) scans = recordScan(scans, { id: `SCAN-${i}` });
  assert.equal(scans.length, MAX_SCAN_HISTORY);
  assert.equal(scans[0].id, `SCAN-${MAX_SCAN_HISTORY + 9}`);
});

test('re-recording a scan replaces it rather than duplicating it', () => {
  const scans = recordScan(recordScan([], { id: 'SCAN-1', status: 'RUNNING' }), { id: 'SCAN-1', status: 'COMPLETED' });
  assert.equal(scans.length, 1);
  assert.equal(scans[0].status, 'COMPLETED');
});

// ── Gate and Ignore Config ──────────────────────────────────────────────────

test('loadGateConfig returns null when no gate stored', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  assert.equal(loadGateConfig('org/repo', dir), null);
});

test('saveGateConfig + loadGateConfig round-trip', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const gate = { name: 'strict', conditions: [{ metric: 'secrets', operator: 'GT', threshold: 0, scope: 'NEW_CODE' }] };
  await saveGateConfig('org/repo', gate, dir);
  assert.deepEqual(loadGateConfig('org/repo', dir), gate);
});

test('clearGateConfig removes the stored gate', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-gate-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const gate = { name: 'strict', conditions: [] };
  await saveGateConfig('org/repo', gate, dir);
  await clearGateConfig('org/repo', dir);
  assert.equal(loadGateConfig('org/repo', dir), null);
});

test('ignore config round-trip', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-ign-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  const text = 'src/generated/**\njava-sql-injection: src/test/**';
  await saveIgnoreConfig('org/repo', text, dir);
  assert.equal(loadIgnoreConfig('org/repo', dir), text);
});

test('clearIgnoreConfig removes stored ignore rules', async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-store-ign-'));
  t.after(() => fs.rmSync(dir, { recursive: true }));
  await saveIgnoreConfig('org/repo', 'src/**', dir);
  await clearIgnoreConfig('org/repo', dir);
  assert.equal(loadIgnoreConfig('org/repo', dir), null);
});