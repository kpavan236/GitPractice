'use strict';
const crypto = require('crypto');
const { SEVERITY_RANK, countBySeverity, isActive } = require('./finding');
const { dedupe } = require('./fingerprint');
const { runCorpusScanners } = require('./corpus');
const { createCache, clearCache } = require('./scan-cache');
const path = require('path');
const { createPool, defaultSize: defaultPoolSize } = require('./pool');
const { buildRuleSet, cacheVersionFor, NoRulesError, noRulesFrom, detectLanguages, ensureRules } = require('./rule-set');
const { runEngine } = require('./engine-loader/run');
const { acquireCore } = require('./engine-workdir');
const { createFindingsStore } = require('./findings-store');
const { scoreFinding } = require('./risk');
const storeModule = require('./store');
const threatIntel = require('./threat-intel');
const { loadIgnoreFile, ignoreReasonFor, isNewSinceBaseline, saveIgnoreRules, clearIgnoreRules } = require('./ignore');
const { verifyFindings, isEnabled: verifyEnabled } = require('./secret-verify');
const { markNewCode, changedLines } = require('./diff');
const { evaluateGate, loadGate, saveGate, clearGate } = require('./gate');
const { publishScan } = require('./publish');
const { RESTRICTION_ORDER } = require('./licenses');
const { USER_RULES_DIR, USER_GRAMMARS_DIR } = require('./paths');

// Runs scanners over a repository and turns their output into scored,
// deduplicated findings.
//
//   scanners → raw findings → dedupe → risk score → merge with history → store
//
// One scanner failing never fails the scan. A missing Semgrep, a repository
// Syft chokes on, a network blip mid-advisory-lookup: each is recorded against
// that scanner and the rest of the run continues. A security tool that returns
// nothing because one of five tools was unhappy is a tool people stop running.

const SCAN_STATUSES = ['QUEUED', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED'];

// Quick Scan restricts to scanners that can be pointed at an explicit file
// list. Everything else — SCA (whole dependency manifest), SBOM/version-watch
// (same), git-history secrets (commits, not working-tree files), SARIF import
// (whatever a tool already left on disk) — has no notion of "changed files"
// and only ever runs in a Full scan.
const QUICK_SCAN_SCANNER_IDS = ['ESLINT', 'PATTERN_SAST', 'IAC_POLICY', 'AST_SAST', 'BUILTIN_SECRETS'];
const QUICK_SCAN_DEFAULT_BASE = '@{upstream}';

function newId(prefix) {
  return `${prefix}-${crypto.randomBytes(6).toString('hex')}`;
}

// Secrets are deliberately never stored on a finding, so the only moment
// verification is possible is during the scan that produced it. The scanner
// attaches the plaintext under a non-enumerable key; this collects it and it is
// discarded with the scan.
function secretsByFingerprint(findings) {
  const map = new Map();
  for (const f of findings) {
    if (f.type === 'SECRET' && f._plaintext && f.fingerprint) map.set(f.fingerprint, f._plaintext);
  }
  return map;
}

/**
 * One repository's shared pass, on a worker thread.
 *
 * Returns null if the pool cannot take it, so the caller falls back to running
 * inline: a worker that will not start is a slower scan, never a failed one.
 */
// Maps with at most `limit` calls in flight; results keep input order. The first
// rejection wins, and calls not yet started are skipped.
async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  let failed = false;
  async function lane() {
    while (!failed && next < items.length) {
      const i = next++;
      try { out[i] = await fn(items[i]); } catch (e) { failed = true; throw e; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, lane));
  return out;
}

async function runShared(pool, shared, target, dir, bundleVersion, onProgress = null, files = null, ruleSet = null) {
  let payload;
  try {
    payload = await pool.run(
      {
        repoPath: target.repoPath,
        repository: target.repository,
        dir,
        bundleVersion,
        scannerIds: shared.map(s => s.id),
        files,
        ruleSet,
      },
      { onProgress }
    );
  } catch (_) {
    return null;                       // fall back to the main thread
  }

  // Structured clone copies own ENUMERABLE properties, and a secret finding
  // carries its plaintext on a non-enumerable one so the value can never be
  // serialised into the store or a log. That protection also means it does not
  // survive the trip back, silently — secret verification would have kept
  // reporting success while verifying nothing. The worker sends the plaintexts
  // alongside, and they are put back here, non-enumerable again.
  return restoreResults(payload);
}

// Turns a worker's or the engine's answer back into what the scanners returned: a Map of results, with each secret
// finding's plaintext put back as a non-enumerable field.
function restoreResults(payload) {
  const secrets = new Map(payload.secrets || []);
  const results = new Map(payload.results);
  for (const [, result] of results) {
    for (const finding of result.findings || []) {
      // The engine child keys a secret by its hash when the finding has no fingerprint yet (see engine-child.js).
      const plaintext = secrets.get(finding.fingerprint) || (finding.metadata && secrets.get(finding.metadata.secretHash));
      if (plaintext) Object.defineProperty(finding, '_plaintext', { value: plaintext, enumerable: false });
    }
  }
  return { results, cacheStats: payload.cacheStats };
}

// Failures that must fail the scan itself rather than one scanner: running with no rules, or an engine that would
// not run safely, must never look like a scan that found nothing.
const FATAL_ENGINE_CODES = new Set(['NO_RULES', 'NO_RULES_INSTALLED', 'NETWORK_DENIAL_UNAVAILABLE', 'PERMISSION_UNSUPPORTED']);

function engineRefusal(e) {
  if (e.code === 'NO_RULES_INSTALLED') return noRulesFrom(e);
  if (e.code !== 'NETWORK_DENIAL_UNAVAILABLE') return e;
  const node = process.versions.electron ? `Electron ${process.versions.electron}, Node ${process.versions.node}` : `Node ${process.versions.node}`;
  return Object.assign(new Error(
    `The rules engine will not run: this app's Node (${node}) cannot deny the engine network access. `
    + 'Set OASIS_ALLOW_OPEN_NETWORK_ENGINE=1 to accept a network-open engine, or run on Node 25 or later.', { cause: e }), { code: e.code });
}

function createOrchestrator({
  scanners,
  dir = storeModule.DEFAULT_DIR,
  store = storeModule,
  intel = threatIntel,
  now = () => Date.now(),
  log = () => {},
  // Injectable for tests; production gets the real ~/.oasis/security paths.
  // Each worker thread has its own module state, so these are handed to
  // every worker as workerData — see the comment on workerPool() below.
  userRulesDir = USER_RULES_DIR,
  userGrammarsDir = USER_GRAMMARS_DIR,
  // Fetches each project's rules and quality profile from the rule server
  // before its scan. Null keeps the built-in bundle.
  ruleSync = null,
  // Where findings, history and the baseline live: the rule server when there is
  // one, otherwise the scanner's own store.json. Injectable for tests.
  findingsStore = null,
  // The installed-rules loader (server/security/engine-loader). With it, and unless OASIS_ENGINE=bundled, scans use
  // the downloaded rules and engine; without it, the rule-server rules and the bundled worker pool as before.
  loader = null,
  // Per-project rule overrides (overrides.js); optional.
  overrides = null,
  env = process.env,
  // Passed through to runEngine (timeoutMs, memoryMb, permissionSupport for tests).
  engineOptions = {},
}) {
  const fstore = findingsStore || createFindingsStore({ ruleSync, store, dir, log });
  // Scans in flight, by id. A desktop app runs one or two at a time, so this
  // does not need to be a queue with workers — but the status vocabulary
  // matches the one a queue would use, so moving to one later changes the
  // execution, not the API.
  const running = new Map();

  // Created on the first scan rather than at startup: most sessions never open
  // the security tab, and idle threads in a desktop app are memory somebody
  // paid for. OASIS_SCAN_WORKERS=0 keeps everything on the main thread, which
  // is the first thing to try if a scan misbehaves.
  let pool = null;
  // Each worker thread loads the analyzer's worker into its OWN module scope, so
  // the loadPlugins() call server/security/index.js makes on the main thread never
  // reaches it. workerData is how a worker learns where the grammar plugins are.
  // Rules are not loaded in the worker at all: they arrive in each message.
  function workerPool() {
    if (Number(process.env.OASIS_SCAN_WORKERS) === 0) return null;
    if (!pool) {
      try {
        pool = createPool({
          workerPath: require('oasis-analyzer').workerPath,
          workerData: { userGrammarsDir },
        });
      } catch (_) {
        pool = null;                   // no workers is slow, not broken
      }
    }
    return pool;
  }

  // How many repositories to scan at once. Matches the pool, because the
  // expensive part of each ends up on a worker thread.
  function poolSize() {
    if (Number(process.env.OASIS_SCAN_WORKERS) === 0) return 1;
    return defaultPoolSize();
  }

  // The installed-rules path is the default when a loader is configured. The engine run has the per-file result
  // cache OFF (the child may not write) and streams no progress: the file counter moves when the run finishes.
  const installedMode = () => !!loader && env.OASIS_ENGINE !== 'bundled';

  async function shutdown() {
    if (pool) { await pool.destroy(); pool = null; }
  }

  async function availability() {
    return Promise.all(
      scanners.map(async s => {
        let state;
        try {
          state = await s.isAvailable({ dir });
        } catch (e) {
          state = { available: false, version: null, hint: e.message };
        }
        return { id: s.id, type: s.type, name: s.name, requires: s.requires, ...state };
      })
    );
  }

  function getScan(id) {
    return running.get(id) || store.load(dir).scans.find(s => s.id === id) || null;
  }

  /**
   * @param {string} repository  repo name, used as the finding's owner
   * @param {string} repoPath    absolute path to a local clone
   * @param {Array}  only        scanner ids to run, or null for all available
   */
  /**
   * Scans one or more repositories in a single run.
   *
   * @param {Array}  targets  [{ repository, repoPath }]
   * @param {Array}  only     scanner ids to run, or null for all available
   * @param {string} mode     'full' (default) or 'quick' — quick restricts to
   *                          QUICK_SCAN_SCANNER_IDS, scoped to files changed
   *                          vs baseRef (default '@{upstream}' for quick).
   */
  async function startScan({ targets, only = null, baseRef = undefined, mode = 'full' }) {
    const list = (targets || []).filter(t => t && t.repository && t.repoPath);
    if (!list.length) throw new Error('No repositories to scan');

    // Rules are fetched BEFORE anything is created or started, so a profile the
    // scanner cannot run rejects the request outright instead of producing a
    // scan that quietly checked less than the profile asked for.
    const ruleSets = [];
    if (installedMode()) {
      // Nothing installed: ask the rules service once. Throws NoRulesError (code NO_RULES) when that gets us nothing.
      const rel = await ensureRules(loader);
      for (const target of list) {
        target.release = rel;   // the one release this scan uses, for the rules and the engine copy alike
        target.ruleSet = { source: 'rules-service', version: `release-${rel.release}`, createdAt: rel.manifest.createdAt || null, rules: [] };
        ruleSets.push({ repository: target.repository, source: 'rules-service', version: target.ruleSet.version, fetchedAt: null, stale: false, projectKnown: true, warning: null });
      }
    } else if (ruleSync) {
      // Bounded concurrency: an all-repositories scan must not wait through one
      // round trip per repository before the request can answer.
      const fetched = await mapLimit(list, 8, target => ruleSync.refresh(target.repository));
      list.forEach((target, i) => {
        const ruleSet = fetched[i];
        target.ruleSet = ruleSet;
        if (ruleSet) {
          ruleSets.push({
            repository: target.repository, source: ruleSet.source, version: ruleSet.version,
            fetchedAt: ruleSet.fetchedAt, stale: !!ruleSet.stale,
            projectKnown: ruleSet.projectKnown !== false, warning: ruleSet.warning || null,
          });
        }
      });
    }

    // No rules means nothing would be checked, and an empty scan reads as a clean
    // repository. Say so now, before any scan exists.
    for (const target of list) {
      if (!target.ruleSet) throw new NoRulesError();
    }

    const scan = {
      id: newId('SCAN'),
      repositories: list.map(t => t.repository),
      // Kept for the single-repository case so existing callers and the scan
      // history read naturally.
      repository: list.length === 1 ? list[0].repository : null,
      status: 'QUEUED',
      startedAt: now(),
      finishedAt: null,
      // Repository-level counts, plus what each repository being scanned right
      // now is actually doing. A sweep that reports only "3 of 12" says nothing
      // for the minutes each repository takes, and a scan nobody can see inside
      // is indistinguishable from a scan that has hung.
      progress: {
        total: list.length,
        completed: 0,
        current: null,
        running: [],
        active: [],
        filesScanned: 0,
      },
      mode,
      ruleSets,
      // What "new code" is measured against, and — in quick mode — what gets
      // scanned at all. Undefined means diff.js decides — HEAD~1 locally; a CI
      // job passes its PR target branch instead. Quick scan defaults to the
      // upstream tracking branch instead, since "changed" there means "not yet
      // pushed", not merely "in the last commit".
      baseRef: baseRef !== undefined ? baseRef : (mode === 'quick' ? QUICK_SCAN_DEFAULT_BASE : undefined),
      perRepository: [],
      scanners: [],
      counts: null,
      error: null,
    };
    running.set(scan.id, scan);

    // Anything an earlier scan could not deliver goes out now, without making this
    // scan wait for it.
    if (typeof fstore.flush === 'function') {
      fstore.flush().catch(e => log(`security: could not deliver queued scans - ${e.message}`));
    }

    // Deliberately not awaited: the request returns the id immediately and the
    // UI polls. A scan across 250 repositories runs for a long time.
    run(scan, list, only).catch(err => {
      scan.status = 'FAILED';
      scan.error = err.message;
      scan.finishedAt = now();
      log('security: scan failed —', err.message);
    });

    return scan;
  }

  // Runs every selected scanner over one repository. Returns the raw findings
  // plus what was actually covered, without touching the store — the caller
  // merges once for the whole run.
  async function scanRepository(scan, target, selected) {
    const entries = [];
    const rawFindings = [];
    const artifacts = [];

    // What this repository is doing, published on the record the dashboard
    // polls and removed when it finishes. One entry per repository in flight,
    // because several are scanned at once and a single "current" would flicker
    // between them.
    const activity = {
      repository: target.repository,
      stage: 'Starting',
      file: null,
      filesScanned: 0,
      filesTotal: 0,
    };
    // Removed by the caller, in the same `finally` that clears the in-flight
    // set, so a repository that throws mid-scan does not leave a line on screen
    // claiming to still be working.
    const progress = scan.progress;
    progress.active.push(activity);

    // The file counter for this repository, and the run's total alongside it.
    // Deltas rather than assignment: reports are throttled on the worker, so
    // they arrive in jumps, and several repositories add to the same total.
    const reportFile = ({ file, filesScanned, filesTotal }) => {
      progress.filesScanned += Math.max(0, filesScanned - activity.filesScanned);
      activity.filesScanned = filesScanned;
      activity.filesTotal = filesTotal;
      activity.file = file;
    };

    // Shared within one repository's scan. The SCA scanners resolve a full
    // dependency tree — with licences — and the SBOM generator needs exactly
    // that; re-resolving it would mean fetching several hundred POMs twice.
    //
    // This makes scanner ORDER meaningful for the first time: SBOM is listed
    // after the SCA scanners in index.js so the tree exists by the time it
    // runs. It degrades rather than breaks if that changes — an empty context
    // falls back to the Version Watch rows.
    const context = { dependencies: [] };

    // Entries are built up front and in the order the scanners were selected,
    // because the shared pass below completes several of them at once and the
    // UI lists them in this order.
    const entryFor = new Map();
    for (const scanner of selected) {
      const entry = {
        id: scanner.id, type: scanner.type, name: scanner.name,
        status: 'QUEUED', findings: 0, stats: null, error: null,
      };
      entries.push(entry);
      entryFor.set(scanner.id, entry);
    }

    // Quick scan: resolve the changed-file list up front, once, for every
    // scanner in this repository to share. `null` from changedLines means
    // "could not tell" (no upstream, a shallow clone) — fail closed rather
    // than let every scanner silently fall back to scanning everything, which
    // would make "quick" mode quietly do a full scan with no indication.
    let files = null;
    let quickUnavailableReason = null;
    if (scan.mode === 'quick') {
      const changed = await changedLines(target.repoPath, { base: scan.baseRef });
      if (!changed) {
        quickUnavailableReason =
          `Quick scan needs a base to diff against (${scan.baseRef}) — no upstream tracking branch, ` +
          'or a shallow clone. Run a Full scan for this repository instead.';
      } else {
        files = [...changed.keys()];
      }
    }

    const runnable = [];
    for (const scanner of selected) {
      const entry = entryFor.get(scanner.id);
      if (quickUnavailableReason) {
        entry.status = 'SKIPPED';
        entry.error = quickUnavailableReason;
        continue;
      }
      let available;
      try {
        // repoPath is passed because availability is not always a property of
        // the machine. ESLint is normally installed per project, not globally,
        // so a scanner that could only ask "is there a global binary" would
        // skip itself on exactly the repositories it should run on.
        available = await scanner.isAvailable({ dir, repoPath: target.repoPath });
      } catch (e) {
        available = { available: false, hint: e.message };
      }
      if (!available.available) {
        entry.status = 'SKIPPED';
        entry.error = available.hint || 'not available';
        continue;
      }
      runnable.push(scanner);
    }

    // ── One walk for every scanner that can share one ────────────────────────
    //
    // The content scanners each used to walk the repository and read every file
    // themselves, so a scan walked the same tree four times and pulled the same
    // bytes off disk four times to feed four pure functions. They now take one
    // pass together. Everything else — SCA, git history, SARIF import — does
    // not read the file tree that way and still runs on its own below.
    const shared = runnable.filter(s => typeof s.prepare === 'function' && typeof s.scanFile === 'function');
    if (shared.length) {
      const startedAt = now();
      activity.stage = 'Scanning files';
      try {
        // Findings for unchanged files come back from the cache instead of
        // being recomputed. Keyed on the rule bundle version among other
        // things, so shipping a new rule re-scans everything — a new rule that
        // silently never fires on existing code would be worse than no cache.
        // The complete rule set for this target (the server's rules plus the
        // user's local packs), resolved once and handed to the analyzer; workers
        // get it in the message. The analyzer never chooses. The cache key is its
        // cacheVersion, not just the server's version: editing a local pack busts
        // the cache the same way a new profile version does.
        let results;
        let cacheStats = null;
        let ruleSet;
        if (installedMode()) {
          // Only the language packs this repository needs, then the project's overrides, then the user's packs.
          // One release for the whole scan: the rules and the engine copy must come from the same one, even if an
          // update lands while this runs.
          const release = target.release || loader.current();
          if (!release) throw noRulesFrom(Object.assign(new Error('no rules release is installed'), { code: 'NO_RULES_INSTALLED' }), loader);
          const languages = detectLanguages({ repoPath: target.repoPath, files, loader, release });
          ruleSet = buildRuleSet({ loader, release, languages, projectKey: target.repository, overrides, userRulesDir });
          let answer;
          let lease = null;
          try {
            lease = await acquireCore({ loader, workDir: path.join(dir, 'engine-work'), release });
            answer = await runEngine({
              corePath: lease.path,
              repoPath: target.repoPath,
              repository: target.repository,
              ruleSet,
              scannerIds: shared.map(s => s.id),
              files,
              allowNetworkOpenEngine: env.OASIS_ALLOW_OPEN_NETWORK_ENGINE === '1',
              ...engineOptions,
            });
          } catch (e) { throw engineRefusal(e); } finally { if (lease) lease.done(); }
          ({ results, cacheStats } = restoreResults(answer));
        } else {
        ruleSet = buildRuleSet({ ruleSet: target.ruleSet, userRulesDir });
        const bundleVersion = cacheVersionFor(ruleSet);
        // Run it on a worker thread where one exists. Everything expensive in a
        // scan is in this pass, and on the main thread it blocked the HTTP
        // server for its whole duration — so the dashboard could not report the
        // progress of the scan that was blocking it.
        const active = workerPool();
        const pooled = active && await runShared(active, shared, target, dir, bundleVersion, reportFile, files, ruleSet);
        if (pooled) {
          results = pooled.results;
          cacheStats = pooled.cacheStats;
        } else {
          const cache = createCache({ dir, repository: target.repository, bundleVersion });
          ({ results } = await runCorpusScanners(shared, {
            repoPath: target.repoPath, repository: target.repository, dir, cache,
            // On the main thread the reports are not throttled — there is no
            // message to post, only a field to set — but the HTTP server cannot
            // answer until the pass finishes either, so nothing sees them until
            // it does. Passed anyway so the counters end up correct.
            onProgress: reportFile,
            files,
            ruleSet,
          }));
          cacheStats = cache.stats;
        }
        }
        const durationMs = now() - startedAt;

        for (const scanner of shared) {
          const entry = entryFor.get(scanner.id);
          const result = results.get(scanner.id) || { findings: [], stats: null, error: 'no result' };
          if (result.error) {
            entry.status = 'FAILED';
            entry.error = result.error;
            entry.durationMs = durationMs;
            log(`security: ${scanner.id} failed on ${target.repository} —`, result.error);
            continue;
          }
          const found = result.findings || [];
          for (const f of found) {
            for (const d of f.detections) d.detectedAt = startedAt;
          }
          rawFindings.push(...found);
          entry.status = 'COMPLETED';
          entry.findings = found.length;
          entry.stats = result.stats || null;
          // The wall clock of the pass they shared, not of this scanner alone —
          // they are no longer separable, and reporting a share of it would be
          // a number nobody could act on.
          entry.durationMs = durationMs;
          entry.sharedPass = true;
          entry.cache = cacheStats;
        }
      } catch (e) {
        if (FATAL_ENGINE_CODES.has(e.code)) throw e;
        // The walk itself failed (an unreadable repository path), which is not
        // attributable to any one scanner.
        for (const scanner of shared) {
          const entry = entryFor.get(scanner.id);
          entry.status = 'FAILED';
          entry.error = e.message;
        }
        log(`security: shared pass failed on ${target.repository} —`, e.message);
      }
    }

    for (const scanner of runnable.filter(s => !shared.includes(s))) {
      const entry = entryFor.get(scanner.id);
      entry.status = 'RUNNING';
      // These do not walk the file tree — Maven resolution fetches several
      // hundred POMs, the history scanner reads the git log — so the file
      // counter stops here and the scanner's own name is what says why.
      activity.stage = scanner.name;
      activity.file = null;
      const startedAt = now();
      try {
        const result = await scanner.scan({ repoPath: target.repoPath, repository: target.repository, dir, context, files });
        if (Array.isArray(result.dependencies)) context.dependencies.push(...result.dependencies);
        const found = result.findings || [];
        for (const f of found) {
          for (const d of f.detections) d.detectedAt = startedAt;
        }
        rawFindings.push(...found);
        for (const artifact of result.artifacts || []) artifacts.push({ ...artifact, generatedAt: now() });
        entry.status = 'COMPLETED';
        entry.findings = found.length;
        entry.stats = result.stats || null;
        entry.durationMs = now() - startedAt;
      } catch (e) {
        entry.status = 'FAILED';
        entry.error = e.message;
        entry.durationMs = now() - startedAt;
        log(`security: ${scanner.id} failed on ${target.repository} —`, e.message);
      }
    }

    // Coverage is per CAPABILITY TYPE, not per scanner.
    //
    // Getting this wrong made every scan report partial coverage: Gitleaks,
    // Semgrep and Syft are optional and usually absent, and counting each as an
    // uncovered scanner meant SECRET looked unchecked even though two other
    // scanners had just checked it. A warning that fires on every scan is a
    // warning nobody reads, which is worse than none — it was hiding the real
    // partial-coverage cases it exists to surface.
    //
    // So a type is covered if ANY scanner of that type analysed something. An
    // absent optional scanner whose type is covered is redundant, not a gap.
    const byType = new Map();
    for (const entry of entries) {
      const scanner = scanners.find(s => s.id === entry.id);
      // `stats.produced` wins where a scanner reports it, because for some
      // scanners the answer is only known after the run. SARIF import covers
      // whatever tools actually left a file: a Trivy report is container
      // coverage and says nothing about DAST, and a static list would have
      // claimed both. Coverage overstated is worse than coverage absent — it
      // is a dashboard reporting that something was checked when nothing was.
      const produced =
        (entry.stats && Array.isArray(entry.stats.produced) && entry.stats.produced) ||
        (scanner && scanner.produces) ||
        [entry.type];
      const analysed = entry.status === 'COMPLETED' && !(entry.stats && entry.stats.skipped);

      for (const type of produced) {
        const current = byType.get(type) || { type, analysed: false, truncated: false, by: [], reasons: [], limits: [] };
        if (analysed) {
          current.analysed = true;
          current.by.push(entry.id);
        } else if (entry.status !== 'SKIPPED' || !current.analysed) {
          // A reason is kept for anything that did not analyse, so a genuinely
          // uncovered type can say why.
          const reason = entry.status === 'COMPLETED' ? (entry.stats && entry.stats.reason) : entry.error;
          if (reason) current.reasons.push({ id: entry.id, reason });
        }
        // A truncation carries its own explanation where the scanner gave one.
        // "Analysed, but hit a limit" tells a reader that the result is
        // incomplete and gives them nothing to do about it; naming the limit
        // and the setting that raises it is the difference between a warning
        // and an instruction.
        if (entry.stats && entry.stats.truncated) {
          current.truncated = true;
          const reason = entry.stats.truncatedReason;
          if (reason && !current.limits.some(l => l.reason === reason)) {
            current.limits.push({ id: entry.id, reason });
          }
        }
        byType.set(type, current);
      }
    }
    const coverage = [...byType.values()];
    activity.stage = 'Finishing';

    // Optional scanners are labelled against what actually happened: absent but
    // redundant reads very differently from absent and leaving a gap.
    for (const entry of entries) {
      if (entry.status !== 'SKIPPED') continue;
      const scanner = scanners.find(s => s.id === entry.id);
      const produced = (scanner && scanner.produces) || [entry.type];
      entry.redundant = produced.every(t => (byType.get(t) || {}).analysed);
    }

    return { entries, rawFindings, artifacts, coverage };
  }

  async function run(scan, targets, only) {
    scan.status = 'RUNNING';
    // Quick scan can only run the scanners that accept a file-list restriction
    // (see QUICK_SCAN_SCANNER_IDS) — narrowed here so `only` still composes
    // normally (a caller asking for a subset gets the intersection).
    const effectiveOnly = scan.mode === 'quick'
      ? (only ? only.filter(id => QUICK_SCAN_SCANNER_IDS.includes(id)) : QUICK_SCAN_SCANNER_IDS)
      : only;
    const selected = scanners.filter(s => !effectiveOnly || effectiveOnly.includes(s.id));

    const perRepo = [];
    const allArtifacts = [];
    let allFindings = [];

    // Repositories are scanned CONCURRENTLY, up to a small limit.
    //
    // The loop was sequential, so a sweep of 250 repositories took the sum of
    // 250 scans — around an hour — while one core worked and the rest of the
    // machine sat idle. Each repository is independent: its own walk, its own
    // cache file, its own git commands, and the store is written once at the
    // end for the whole run.
    //
    // The limit is the pool's, because the expensive part of each repository
    // ends up on a worker thread and queueing more than there are threads buys
    // nothing but memory.
    const limit = Math.max(1, poolSize());
    const slots = new Array(targets.length);
    const inFlight = new Set();

    async function scanOne(target, index) {
      const result = await scanRepository(scan, target, selected);

      const ignoreRules = loadIgnoreFile(target.repoPath, { repository: target.repository, store: storeModule, dir });
      let ignored = 0;
      let findings = dedupe(result.rawFindings, { severityRank: SEVERITY_RANK });
      if (ignoreRules.length) {
        findings = findings.filter(f => {
          const reason = ignoreReasonFor(ignoreRules, f);
          if (reason) ignored += 1;
          return !reason;
        });
      }

      // Validity checking needs the plaintext, which only exists on the raw
      // findings from this repository's scan.
      if (verifyEnabled()) {
        try {
          const verification = await verifyFindings(findings, secretsByFingerprint(result.rawFindings));
          scan.verification = mergeVerification(scan.verification, verification);
        } catch (e) {
          scan.verification = { error: e.message };
        }
      }

      // Which findings this change introduced, from the git diff. Marked here
      // rather than at report time because the answer depends on the working
      // tree as it was scanned — by the time someone opens the dashboard the
      // branch may have moved on.
      const diff = await markNewCode(findings, target.repoPath, { base: scan.baseRef });
      findings = diff.findings;

      // The gate is evaluated PER REPOSITORY, because the gate file lives in
      // the repository and a sweep of twelve repositories has twelve different
      // owners with twelve different thresholds.
      const { gate, source: gateSource, error: gateError } = loadGate(target.repoPath, { repository: target.repository, store: storeModule, dir });
      const gateResult = evaluateGate({
        findings,
        coverage: result.coverage,
        gate,
        gateError,
        newCodeAvailable: diff.available,
      });

      // Written to a fixed slot rather than appended, so the report is in the
      // order the user chose regardless of which repository finished first.
      slots[index] = {
        entry: {
          repository: target.repository,
          scanners: result.entries,
          coverage: result.coverage,
          ignored,
          counts: countBySeverity(findings),
          newCode: {
            available: diff.available,
            reason: diff.reason,
            base: diff.base,
            changedFiles: diff.changedFiles || 0,
            count: findings.filter(f => f.isNewCode).length,
          },
          gate: { ...gateResult, source: gateSource },
          // Partial means a capability went unchecked, not that an optional
          // scanner was missing.
          partial: result.coverage.some(c => !c.analysed || c.truncated),
        },
        findings,
        artifacts: result.artifacts,
      };

      scan.progress.completed += 1;
      // Only what has finished, still in input order, so the dashboard can show
      // partial results while the rest of the sweep runs.
      scan.perRepository = slots.filter(Boolean).map(s => s.entry);
    }

    let next = 0;
    async function worker() {
      for (;;) {
        // Cancellation is checked between repositories. A running scanner
        // cannot be interrupted, but a 250-repository sweep should not have to
        // finish just because someone changed their mind on repository three.
        if (scan.status === 'CANCELLED') return;
        const index = next++;
        if (index >= targets.length) return;

        const target = targets[index];
        inFlight.add(target.repository);
        // With several in flight there is no single "current". The first is
        // shown, and the full set is published for a UI that wants it.
        scan.progress.current = [...inFlight][0];
        scan.progress.running = [...inFlight];
        try {
          await scanOne(target, index);
        } finally {
          inFlight.delete(target.repository);
          scan.progress.running = [...inFlight];
          scan.progress.active = scan.progress.active.filter(a => a.repository !== target.repository);
        }
      }
    }

    await Promise.all(Array.from({ length: Math.min(limit, targets.length) }, worker));

    for (const slot of slots) {
      if (!slot) continue;                       // cancelled before it ran
      perRepo.push(slot.entry);
      allFindings.push(...slot.findings);
      allArtifacts.push(...slot.artifacts);
    }

    scan.progress.current = null;
    scan.progress.running = [];

    // One exploit-intelligence fetch for the whole run rather than one per
    // repository: KEV is a single 1600-entry document and EPSS is batched, so
    // asking once for 250 repositories costs what asking once for one does.
    scan.intel = { kev: null, epss: null };
    try {
      const cves = allFindings.map(f => f.cve).filter(Boolean);
      if (cves.length) {
        const [kev, epss] = await Promise.all([
          intel.loadKev({ dir, now }),
          intel.loadEpss(cves, { dir, now }),
        ]);
        const applied = intel.enrich(allFindings, { kev, epss });
        scan.intel = {
          kev: { hits: applied.kevHits, fetchedAt: kev.fetchedAt, stale: Boolean(kev.stale), error: kev.error || null },
          epss: { scored: applied.epssScored, fetchedAt: epss.fetchedAt, error: epss.error || null },
        };
        if (applied.kevHits) log(`security: ${applied.kevHits} finding(s) match the CISA KEV catalog`);
      }
    } catch (e) {
      scan.intel = { error: e.message };
    }

    // Aggregate per-scanner totals across repositories, for the summary view.
    scan.scanners = aggregateScanners(perRepo);
    scan.counts = countBySeverity(allFindings);
    scan.newFindings = allFindings.length;
    scan.ignored = perRepo.reduce((sum, r) => sum + r.ignored, 0);
    scan.newCodeCount = allFindings.filter(f => f.isNewCode).length;

    // The scan-level verdict is the WORST repository's. A sweep where eleven
    // repositories pass and one fails has failed — reporting the majority would
    // let a build through on the strength of the repositories it did not break.
    const gates = perRepo.map(r => r.gate).filter(Boolean);
    scan.gate = gates.length
      ? {
          status: gates.some(g => g.status === 'FAILED') ? 'FAILED'
            : gates.some(g => g.status === 'NOT_EVALUATED') ? 'NOT_EVALUATED'
            : gates.some(g => g.status === 'WARN') ? 'WARN'
            : 'PASSED',
          blocking: gates.some(g => g.blocking),
          failed: perRepo.filter(r => r.gate && r.gate.blocking).map(r => r.repository),
        }
      : null;
    scan.partial = perRepo.some(r => r.partial);
    // The verdict is known now but announced only after the findings have been
    // merged: the UI reloads its lists the moment it sees COMPLETED, and with the
    // rule server that is up to 250 uploads later than the scan itself.
    const finalStatus = scan.status !== 'CANCELLED'
      ? (perRepo.length && perRepo.some(r => r.coverage.some(c => c.analysed)) ? 'COMPLETED' : 'FAILED')
      : scan.status;
    scan.finishedAt = now();

    // Findings, trend history and the baseline belong to the findings store: the rule
    // server in production, the scanner's own store.json when there is none. Merged
    // per repository, because resolution is scoped to what a given repository's scan
    // actually covered. With the rule server this merge IS the upload: the finished
    // scan is queued in the outbox first, so an outage cannot cost a finding.
    const assets = store.load(dir).assets;
    const mergedAt = now();
    // A server that hangs would cost its full timeout once per repository, in a
    // 250-repository sweep for hours. After three unreachable uploads in a row the
    // rest are only queued (still safe in the outbox), not attempted.
    let unreachableInARow = 0;
    for (const repo of perRepo) {
      const mine = allFindings.filter(f => f.repository === repo.repository);
      const asset = assets[repo.repository] || {};
      for (const finding of mine) {
        finding.id = finding.id || newId('F');
        finding.risk = scoreFinding(finding, asset);
      }
      const target = targets.find(t => t.repository === repo.repository);
      let outcome;
      try {
        outcome = await fstore.merge(repo.repository, mine, {
          coveredTypes: repo.coverage.filter(c => c.analysed).map(c => c.type),
          now: mergedAt,
          deferUpload: unreachableInARow >= 3,
          analysis: {
            scan,
            repo,
            ruleSet: target && target.ruleSet,
            scannerVersion: require('../../package.json').version,
            analyzerVersion: require('oasis-analyzer').version,
          },
        });
      } catch (e) {
        // The scanner's own store failing is a real failure. The rule server's side
        // (a full disk for the outbox, a payload that cannot be built) must not take
        // the whole scan down with it: record it on that repository and carry on, so
        // the other repositories are kept and the scan itself is still recorded.
        if (fstore.mode === 'local') throw e;
        log(`security: could not store ${repo.repository}'s findings - ${e.message}`);
        outcome = { ok: false, failed: true, error: e.message };
      }
      if (!outcome) continue;
      unreachableInARow = outcome.unreachable ? unreachableInARow + 1 : 0;
      if (outcome.ok && outcome.serverGate && repo.gate) {
        // Only two default gates are the same question. A repository's own gate
        // file or a gate set on the server is meant to disagree.
        if (repo.gate.source === 'default' && outcome.gateSource === 'default') {
          if (outcome.serverGate.status !== repo.gate.status) {
            outcome.gateMismatch = { local: repo.gate.status, server: outcome.serverGate.status };
            log(`security: ${repo.repository} quality gate differs - local ${repo.gate.status}, rule server ${outcome.serverGate.status}`);
          }
        } else {
          outcome.gateComparison = `not compared: different gates (local ${repo.gate.source || 'unknown'}, server ${outcome.gateSource || 'unknown'})`;
        }
      }
      repo.ruleServer = outcome;
    }
    // Snapshot AFTER the merges, so the trend point reflects what is actually open,
    // including findings resolved by this scan, which is the movement it exists to show.
    await fstore.finishScan({ now: mergedAt });

    scan.status = finalStatus;
    if (scan.status === 'FAILED' && !scan.error) {
      scan.error = 'No scanner completed on any repository. Check the per-scanner errors.';
    }

    await store.mutate(dir, data => {
      for (const artifact of allArtifacts) {
        if (artifact.kind === 'SBOM' && artifact.document) {
          const savedTo = store.saveSbom(artifact.document, artifact.repository, dir);
          data.sboms = [
            { repository: artifact.repository, format: artifact.format, summary: artifact.summary, generatedAt: artifact.generatedAt, path: savedTo },
            ...data.sboms.filter(s => s.repository !== artifact.repository),
          ];
        }
      }

      data.scans = store.recordScan(data.scans, { ...scan });
    });

    // Pushed AFTER the local store is written, so a platform outage can never
    // cost a finding: the authoritative copy is already on disk. Sequential and
    // awaited so a 250-repository sweep does not open 250 sockets at once.
    for (const repo of perRepo) {
      const result = await publishScan(
        {
          repository: repo.repository,
          scan,
          findings: allFindings.filter(f => f.repository === repo.repository),
          coverage: repo.coverage,
          gate: repo.gate,
        },
        { log }
      );
      repo.published = result.published ? true : result.skipped ? null : false;
      if (result.error) repo.publishError = result.error;
    }

    // The stored scan was written BEFORE this — deliberately, so a platform
    // outage can never cost a finding — which means the publish outcome would
    // otherwise never be persisted and the UI could not report "this scan did
    // not reach the platform". A second small write closes that.
    if (perRepo.some(r => r.published !== null || r.ruleServer)) {
      await store.mutate(dir, data => {
        const stored = data.scans.find(s => s.id === scan.id);
        if (!stored) return data;
        for (const repo of stored.perRepository || []) {
          const fresh = perRepo.find(r => r.repository === repo.repository);
          if (!fresh) continue;
          repo.published = fresh.published;
          if (fresh.publishError) repo.publishError = fresh.publishError;
          if (fresh.ruleServer) repo.ruleServer = fresh.ruleServer;
        }
        return data;
      });
    }

    running.delete(scan.id);
    return scan;
  }

  // Per-scanner rollup across repositories: "Built-in SAST — 4 findings across
  // 12 repositories, skipped on 2".
  function aggregateScanners(perRepo) {
    const byId = new Map();
    for (const repo of perRepo) {
      for (const entry of repo.scanners) {
        const agg = byId.get(entry.id) || {
          id: entry.id, type: entry.type, name: entry.name,
          findings: 0, completed: 0, skipped: 0, failed: 0, notAnalysed: 0, errors: [],
        };
        agg.findings += entry.findings || 0;
        // How much of this scan was re-examined and how much was reused. A run
        // served almost entirely from cache should say so: "coverage" that came
        // from a previous scan is still coverage, but a reader deciding whether
        // to trust a suspiciously fast result deserves to know which it was.
        if (entry.cache) {
          agg.cacheHits = (agg.cacheHits || 0) + (entry.cache.hits || 0);
          agg.cacheMisses = (agg.cacheMisses || 0) + (entry.cache.misses || 0);
        }
        if (entry.status === 'COMPLETED') {
          agg.completed += 1;
          if (entry.stats && entry.stats.skipped) agg.notAnalysed += 1;
        } else if (entry.status === 'SKIPPED') {
          agg.skipped += 1;
          // Only counts as a coverage gap if nothing else covered the type.
          if (!entry.redundant) agg.gaps = (agg.gaps || 0) + 1;
          else agg.redundant = (agg.redundant || 0) + 1;
        }
        else if (entry.status === 'FAILED') {
          agg.failed += 1;
          if (entry.error && !agg.errors.includes(entry.error)) agg.errors.push(entry.error);
        }
        if (entry.status === 'SKIPPED' && entry.error && !agg.errors.includes(entry.error)) {
          agg.errors.push(entry.error);
        }
        byId.set(entry.id, agg);
      }
    }
    return [...byId.values()].map(a => ({
      ...a,
      status: a.completed ? 'COMPLETED' : a.failed ? 'FAILED' : 'SKIPPED',
    }));
  }

  function mergeVerification(existing, next) {
    if (!existing || existing.skipped) return next;
    if (next.skipped) return existing;
    return {
      attempted: (existing.attempted || 0) + (next.attempted || 0),
      live: (existing.live || 0) + (next.live || 0),
      revoked: (existing.revoked || 0) + (next.revoked || 0),
    };
  }

  function cancelScan(id) {
    const scan = running.get(id);
    if (!scan) return null;
    // Cooperative only: the scanner subprocess keeps going until it exits. An
    // honest CANCELLED with the work still finishing beats pretending we can
    // kill a Semgrep run mid-file.
    scan.status = 'CANCELLED';
    scan.finishedAt = now();
    running.delete(id);
    return scan;
  }

  // ── Queries ──────────────────────────────────────────────────────────────

  async function listFindings({ repository = null, type = null, severity = null, status = 'active', search = null } = {}) {
    // A store that can filter (the rule server) does, so only what the screen needs
    // travels. The filters below then run again on that smaller list, harmlessly.
    const filtering = typeof fstore.list === 'function';
    let findings = filtering ? await fstore.list({ repository, type, severity, status, search }) : await fstore.all();

    // "new" is what a CI gate asks for: a 27-finding backlog should not fail
    // every build, but the 28th should.
    if (status === 'new' && !filtering) {
      const baseline = await fstore.baseline();
      findings = findings.filter(f => isActive(f) && isNewSinceBaseline(baseline, f));
    }

    if (repository) findings = findings.filter(f => f.repository === repository);
    if (type) findings = findings.filter(f => f.type === type);
    if (severity) findings = findings.filter(f => f.severity === severity);
    if (status === 'active') findings = findings.filter(isActive);
    else if (status && status !== 'all' && status !== 'new') findings = findings.filter(f => f.status === status);

    if (search) {
      const q = search.toLowerCase();
      findings = findings.filter(f =>
        [f.title, f.file, f.cve, f.category, f.repository].some(v => v && String(v).toLowerCase().includes(q))
      );
    }

    // Risk order, not severity order. That is the whole argument of the risk
    // engine: a HIGH on an internet-facing production service outranks a
    // CRITICAL in a scratch repository.
    return [...findings].sort((a, b) => (b.risk?.score || 0) - (a.risk?.score || 0));
  }

  /**
   * The gate verdict for the most recent completed scan.
   *
   * Read from the stored scan rather than recomputed, because a CI job asks
   * repeatedly and a gate that could change its answer between two reads of the
   * same scan would be unusable as a build blocker.
   */
  function gateStatus({ repository = null } = {}) {
    const data = store.load(dir);
    const scan = data.scans.find(s =>
      s.status === 'COMPLETED'
      && (!repository || (s.repositories || []).includes(repository))
    );
    if (!scan) return null;

    const perRepo = repository
      ? (scan.perRepository || []).filter(r => r.repository === repository)
      : (scan.perRepository || []);

    const gates = perRepo.map(r => r.gate).filter(Boolean);
    if (!gates.length) {
      return {
        status: 'NOT_EVALUATED',
        blocking: true,
        reason: 'the last scan predates quality gates — run a new scan',
        scanId: scan.id,
      };
    }

    return {
      status: gates.some(g => g.status === 'FAILED') ? 'FAILED'
        : gates.some(g => g.status === 'NOT_EVALUATED') ? 'NOT_EVALUATED'
        : gates.some(g => g.status === 'WARN') ? 'WARN'
        : 'PASSED',
      blocking: gates.some(g => g.blocking),
      scanId: scan.id,
      scannedAt: scan.startedAt,
      repositories: perRepo.map(r => ({
        repository: r.repository,
        status: r.gate.status,
        blocking: r.gate.blocking,
        gate: r.gate.gate,
        newCode: r.newCode,
        // Every condition, with its actual value. A red build that cannot say
        // which threshold it crossed is a red build people override.
        conditions: r.gate.conditions,
      })),
      reason: perRepo
        .filter(r => r.gate.blocking)
        .map(r => `${r.repository}: ${r.gate.reason}`)
        .join('; ') || null,
    };
  }

  async function dashboard() {
    const [allFindings, history, baseline] = await Promise.all([fstore.all(), fstore.history(), fstore.baseline()]);
    const data = store.load(dir);
    const active = allFindings.filter(isActive);
    const counts = countBySeverity(active);

    const byRepo = {};
    for (const f of active) {
      byRepo[f.repository] = byRepo[f.repository] || { repository: f.repository, count: 0, maxRisk: 0 };
      byRepo[f.repository].count += 1;
      byRepo[f.repository].maxRisk = Math.max(byRepo[f.repository].maxRisk, f.risk?.score || 0);
    }

    return {
      counts,
      total: active.length,
      resolved: allFindings.filter(f => f.status === 'RESOLVED').length,
      suppressed: allFindings.filter(f => f.status === 'SUPPRESSED' || f.status === 'FALSE_POSITIVE').length,
      byType: active.reduce((acc, f) => ({ ...acc, [f.type]: (acc[f.type] || 0) + 1 }), {}),
      topRisks: [...active].sort((a, b) => (b.risk?.score || 0) - (a.risk?.score || 0)).slice(0, 10),
      byRepository: Object.values(byRepo).sort((a, b) => b.maxRisk - a.maxRisk),
      lastScan: data.scans[0] || null,
      history: (history || []).slice(-30),
      baseline: baseline
        ? { createdAt: baseline.createdAt, count: baseline.fingerprints.length }
        : null,
      newSinceBaseline: baseline
        ? active.filter(f => isNewSinceBaseline(baseline, f)).length
        : null,
      sboms: data.sboms,
    };
  }

  function updateFinding(id, patch) {
    return fstore.update(id, patch);
  }

  function getFinding(id) {
    return fstore.get(id);
  }

  // Repositories that have findings, without downloading the findings.
  async function scannedRepositories() {
    if (typeof fstore.repositories === 'function') return (await fstore.repositories()).map(r => r.repository);
    return [...new Set((await fstore.all()).map(f => f.repository))];
  }

  // What is waiting to reach the findings store, and whether it is being refused.
  const outboxStatus = () => (typeof fstore.outboxStatus === 'function' ? fstore.outboxStatus() : null);
  const retryRejected = async () => (typeof fstore.retryRejected === 'function'
    ? fstore.retryRejected()
    : { requeued: 0, delivered: 0, remaining: 0, rejected: 0, blocked: null });

  /**
   * Licence inventory across everything scanned.
   *
   * Built from the stored LICENSE findings plus each scan's recorded inventory,
   * because the findings only cover licences that needed a decision — a report
   * that listed the AGPL dependency and omitted the 300 permissive ones would
   * not be an inventory.
   */
  /**
   * The trend series, plus the deltas people actually read.
   */
  async function trends({ points = 30 } = {}) {
    const history = ((await fstore.history()) || []).slice(-points);
    const first = history[0];
    const last = history[history.length - 1];

    const delta = (a, b) => (a === undefined || b === undefined ? null : b - a);

    return {
      points: history,
      // Two comparisons, because they answer different questions: "did that
      // last scan help" and "are we better than we were".
      sinceLastScan: history.length >= 2
        ? {
            total: delta(history[history.length - 2].total, last.total),
            critical: delta(history[history.length - 2].counts.CRITICAL, last.counts.CRITICAL),
            high: delta(history[history.length - 2].counts.HIGH, last.counts.HIGH),
          }
        : null,
      sinceFirst: history.length >= 2
        ? { total: delta(first.total, last.total), from: first.at, to: last.at }
        : null,
    };
  }

  async function licenseInventory({ repository = null } = {}) {
    const data = store.load(dir);
    const stored = await fstore.all();
    const byLicense = new Map();

    const add = (license, category, name, severity) => {
      const key = license || 'UNKNOWN';
      const entry = byLicense.get(key) || { license: key, category, severity: severity || null, count: 0, packages: [] };
      if (!entry.packages.includes(name)) {
        entry.count += 1;
        if (entry.packages.length < 50) entry.packages.push(name);
      }
      byLicense.set(key, entry);
    };

    // Everything the scans catalogued, decision-needing or not.
    for (const scan of data.scans) {
      for (const repo of scan.perRepository || []) {
        if (repository && repo.repository !== repository) continue;
        for (const entry of repo.scanners || []) {
          for (const item of (entry.stats && entry.stats.licenseInventory) || []) {
            for (const pkg of item.packages) add(item.license, item.category, pkg, item.severity);
          }
        }
      }
    }

    // Plus anything currently open as a LICENSE finding, which is what carries
    // the triage state.
    const findings = stored.filter(
      f => f.type === 'LICENSE' && (!repository || f.repository === repository) && isActive(f)
    );
    for (const f of findings) {
      add(f.metadata.license, f.metadata.licenseCategory, `${f.metadata.packageName}@${f.metadata.versionInUse}`, f.severity);
    }

    const licenses = [...byLicense.values()].sort(
      (a, b) => RESTRICTION_ORDER.indexOf(b.category) - RESTRICTION_ORDER.indexOf(a.category) || b.count - a.count
    );

    return {
      licenses,
      totalPackages: licenses.reduce((n, l) => n + l.count, 0),
      needingReview: findings.length,
      // Named explicitly: "no licence recorded" is a gap in the data, not a
      // clean bill of health.
      unknown: licenses.filter(l => l.category === 'unknown').reduce((n, l) => n + l.count, 0),
    };
  }

  function setBaseline() {
    return fstore.setBaseline(now());
  }

  // ── Clearing results ──────────────────────────────────────────────────────
  //
  // Findings and SBOMs are cheap: a rescan regenerates them. Two things in this
  // store are NOT, and the difference is the whole design of these functions.
  //
  //   Suppressions and false-positive marks are human decisions with reasons
  //   attached, and they live ON the findings — so a naive "delete the
  //   findings" throws them away, and the next scan resurrects forty issues
  //   somebody already judged. They are kept by default.
  //
  //   Trend history cannot be regenerated at all. You cannot rescan last month.
  //   Only the full reset touches it, and it says so.
  //
  // Repository criticality and environment survive everything here. They are
  // configuration, not results, and clearing results must not silently reset
  // how the risk engine scores a repository.

  /**
   * What clearing would remove, without removing it.
   *
   * The confirm step reads this. A destructive action that cannot say what it
   * is about to destroy is one people either avoid or regret.
   */
  async function clearPreview({ repository = null } = {}) {
    const stored = await fstore.preview({ repository });
    const data = store.load(dir);
    return {
      repository,
      findings: stored.findings,
      suppressed: stored.suppressed,
      scans: repository
        ? data.scans.filter(s => (s.repositories || []).includes(repository)).length
        : data.scans.length,
      sboms: repository
        ? data.sboms.filter(s => s.repository === repository).length
        : data.sboms.length,
      history: stored.history,
      repositories: stored.repositories,
    };
  }

  /**
   * Clears findings, optionally for one repository.
   *
   * @param {string}  repository      one repository, or null for all
   * @param {boolean} keepSuppressed  keep triage decisions (default true)
   */
  async function clearFindings({ repository = null, keepSuppressed = true } = {}) {
    const removed = await clearPreview({ repository });

    clearCache({ dir, repository });
    await fstore.clear({ repository, keepSuppressed });

    // Scans and SBOMs are the scanner's own; findings were cleared by the store.
    await store.mutate(dir, data => {
      data.scans = repository
        ? data.scans.filter(s => {
            const repos = s.repositories || [];
            return !(repos.length === 1 && repos[0] === repository);
          })
        : [];

      for (const sbom of data.sboms) {
        if (!repository || sbom.repository === repository) store.deleteSbom(sbom.repository, dir);
      }
      data.sboms = repository ? data.sboms.filter(s => s.repository !== repository) : [];
    });

    return {
      ...removed,
      keptSuppressed: keepSuppressed ? removed.suppressed : 0,
      findings: removed.findings - (keepSuppressed ? removed.suppressed : 0),
    };
  }

  /**
   * Empties the security store completely.
   *
   * Everything above plus the trend history and the baseline — the two things
   * that cannot be rebuilt by scanning again. Separate from clearFindings so it
   * can never be reached by accident from a repository-scoped action.
   */
  async function resetSecurity() {
    clearCache({ dir });

    const removed = await clearPreview({});
    await fstore.reset();

    await store.mutate(dir, data => {
      for (const sbom of data.sboms) store.deleteSbom(sbom.repository, dir);
      data.scans = [];
      data.sboms = [];
    });
    return { ...removed, reset: true };
  }

  function clearBaseline() {
    return fstore.clearBaseline();
  }

  async function setAsset(repository, settings) {
    const asset = await store.mutate(dir, data => {
      data.assets[repository] = { ...(data.assets[repository] || {}), ...settings };
      return data.assets[repository];
    });

    // Asset context is a risk input, so changing it changes every score for that
    // repository. Rescoring now means the dashboard is correct immediately,
    // instead of after the next scan. If the findings store cannot be reached the
    // asset is still saved, and the next scan scores with it.
    try {
      const mine = (await fstore.all()).filter(f => f.repository === repository);
      if (mine.length) await fstore.setRisk(mine.map(f => ({ id: f.id, risk: scoreFinding(f, asset) })));
    } catch (e) {
      if (e.code !== 'UNREACHABLE') throw e;
      log(`security: asset saved for ${repository}; findings will be re-scored on the next scan (${e.message})`);
    }
    return asset;
  }

  return {
    SCAN_STATUSES,
    ruleSync,
    availability,
    startScan,
    getScan,
    cancelScan,
    listFindings,
    getFinding,
    scannedRepositories,
    outboxStatus,
    retryRejected,
    // Delivers scans still waiting for the findings store (the rule server was down).
    flushPending: async () => (typeof fstore.flush === 'function' ? fstore.flush() : { delivered: 0, remaining: 0, rejected: 0 }),
    dashboard,
    gateStatus,
    updateFinding,
    setAsset,
    setBaseline,
    clearBaseline,
    clearPreview,
    clearFindings,
    shutdown,
    resetSecurity,
    licenseInventory,
    trends,
    getAssets: () => store.load(dir).assets,
    getSbom: repository => store.loadSbom(repository, dir),
    getRepositorySettings(repository) {
      const data = storeModule.load(dir);
      const storedGate = (data.gates || {})[repository] ?? null;
      const storedIgnore = (data.ignores || {})[repository] ?? null;

      let gateSource = 'default';
      let gate = null;
      if (storedGate !== null) {
        gate = storedGate;
        gateSource = 'settings';
      } else {
        const loaded = loadGate('.', { repository, store: storeModule, dir });
        gate = loaded.gate;
        gateSource = loaded.source;
      }

      return {
        gate,
        gateSource,
        ignoreRules: storedIgnore,
        ignoreSource: storedIgnore !== null ? 'settings' : 'file',
      };
    },
    saveGate(repository, gate) {
      return storeModule.saveGateConfig(repository, gate, dir);
    },
    clearGate(repository) {
      return storeModule.clearGateConfig(repository, dir);
    },
    saveIgnoreRules(repository, text) {
      return storeModule.saveIgnoreConfig(repository, text, dir);
    },
    clearIgnoreRules(repository) {
      return storeModule.clearIgnoreConfig(repository, dir);
    },
  };
}

module.exports = { createOrchestrator, SCAN_STATUSES };