'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadLocalRules } = require('./local-rules');

// Rules that live on this machine rather than on the rule server: the user's own
// packs (~/.oasis/security/rules) and rules shipped by a grammar plugin.

const makePack = rules => JSON.stringify({ version: '1', rules });
const validRule = (overrides = {}) => ({
  id: 'custom/test-rule', language: 'javascript', query: '(identifier) @id', severity: 'HIGH', type: 'SAST',
  message: 'test', fixture: { detect: 'eval("x")', clean: 'console.log("x")' }, ...overrides,
});
const tmp = t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-local-rules-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  return dir;
};

test('loads user pack rules and reports each pack', (t) => {
  const dir = tmp(t);
  fs.writeFileSync(path.join(dir, 'my-rules.json'), makePack([validRule()]));
  const { rules, packs } = loadLocalRules({ userRulesDir: dir, plugins: [] });
  assert.ok(rules.some(r => r.id === 'custom/test-rule'));
  assert.deepEqual(packs.map(p => [p.name, p.ruleCount]), [['my-rules.json', 1]]);
});

test('user rules are tagged with source: user', (t) => {
  const dir = tmp(t);
  fs.writeFileSync(path.join(dir, 'my-rules.json'), makePack([validRule()]));
  assert.equal(loadLocalRules({ userRulesDir: dir, plugins: [] }).rules[0].source, 'user');
});

test('a pack without a fixture is rejected, and a broken pack is skipped with its error', (t) => {
  const dir = tmp(t);
  const { fixture: _drop, ...noFixture } = validRule();
  fs.writeFileSync(path.join(dir, 'bad.json'), makePack([noFixture]));
  fs.writeFileSync(path.join(dir, 'broken.json'), 'not json {{{');
  const { rules, packs } = loadLocalRules({ userRulesDir: dir, plugins: [] });
  assert.deepEqual(rules, []);
  assert.equal(packs.length, 2);
  assert.ok(packs.every(p => p.error));
});

test('no directory and no plugins means no local rules', () => {
  const r = loadLocalRules({ userRulesDir: null, plugins: [] });
  assert.deepEqual(r.rules, []);
  assert.deepEqual(r.packs, []);
  assert.equal(r.hash, 'none');
});

test("a grammar plugin's rules.json is loaded and tagged as user; a plugin without one is ignored", (t) => {
  const dir = tmp(t);
  const rulesFile = path.join(dir, 'rules.json');
  fs.writeFileSync(rulesFile, makePack([validRule({ id: 'ruby/plugin-rule' })]));
  const { rules, packs } = loadLocalRules({ userRulesDir: null, plugins: [{ language: 'ruby', rulesFile }, { language: 'go', rulesFile: null }] });
  assert.equal(rules.find(r => r.id === 'ruby/plugin-rule').source, 'user');
  assert.deepEqual(packs.map(p => p.name), ['ruby/rules.json']);
});

test('the hash changes when a pack is edited and is stable otherwise', (t) => {
  const dir = tmp(t);
  const file = path.join(dir, 'my-rules.json');
  fs.writeFileSync(file, makePack([validRule()]));
  const a = loadLocalRules({ userRulesDir: dir, plugins: [] }).hash;
  assert.equal(loadLocalRules({ userRulesDir: dir, plugins: [] }).hash, a);
  fs.writeFileSync(file, makePack([validRule({ severity: 'LOW' })]));
  assert.notEqual(loadLocalRules({ userRulesDir: dir, plugins: [] }).hash, a);
});
