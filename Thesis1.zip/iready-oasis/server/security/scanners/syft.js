'use strict';
const { runTool, toolAvailability } = require('../scanner');

// Syft adapter — SBOM generation.
//
// An SBOM is not a list of problems, so this scanner produces no findings. It
// produces an ARTIFACT: a CycloneDX document describing what the application is
// made of. That is the thing a customer asks for during procurement, and the
// input every future component-level analysis needs.
//
// Kept behind the same interface as the finding-producing scanners so the
// orchestrator runs it the same way, rather than growing a special case.

// Optional extra: the bundled SBOM generator produces CycloneDX from the
// dependency data already collected.
const INSTALL_HINT = 'optional — github.com/anchore/syft/releases';

// CycloneDX over SPDX: it is the format most tooling ingests, and its component
// list maps cleanly onto the dependency rows we already hold.
const FORMAT = 'cyclonedx-json';

function summarise(sbom) {
  const components = (sbom && sbom.components) || [];
  const byType = {};
  for (const c of components) {
    const key = c.type || 'library';
    byType[key] = (byType[key] || 0) + 1;
  }
  return {
    components: components.length,
    byType,
    // Licence coverage is the question procurement actually asks of an SBOM,
    // and an SBOM where most components have no licence is not much of an
    // answer. Surfaced rather than left for someone to discover later.
    withLicenses: components.filter(c => (c.licenses || []).length > 0).length,
  };
}

const scanner = {
  id: 'SYFT',
  type: 'SBOM',
  name: 'Syft (SBOM)',
  requires: 'syft',

  isAvailable() {
    return toolAvailability('syft', ['version'], INSTALL_HINT);
  },

  async scan({ repoPath, repository, timeoutMs = 300000 }) {
    const result = await runTool('syft', [`dir:${repoPath}`, '-o', FORMAT, '-q'], {
      cwd: repoPath,
      timeoutMs,
    });

    if (result.timedOut) throw new Error(`Syft timed out after ${Math.round(timeoutMs / 1000)}s`);
    if (result.error) throw new Error(`Syft could not run: ${result.error}`);

    let sbom;
    try {
      sbom = JSON.parse(result.stdout);
    } catch (_) {
      throw new Error(`Syft produced unreadable output: ${result.stderr.slice(0, 300)}`);
    }

    return {
      findings: [],
      artifacts: [
        {
          kind: 'SBOM',
          format: FORMAT,
          repository,
          generatedAt: null, // stamped by the orchestrator, which owns the clock
          summary: summarise(sbom),
          document: sbom,
        },
      ],
      stats: summarise(sbom),
    };
  },
};

module.exports = { scanner, summarise, INSTALL_HINT, FORMAT };