'use strict';
const fs = require('fs');
const path = require('path');
const { fromSarif, typeForTool } = require('../sarif-ingest');

// Ingests SARIF files that other tools left in the repository.
//
// The contract is a directory, not an integration: anything that can write a
// SARIF file into `.oasis/sarif/` becomes a scanner here. A CI job that already
// runs Trivy adds one `--format sarif --output` flag and this app gains
// container scanning; the same for Checkov, ZAP, Prowler, or a commercial
// product nobody here will ever write an adapter for.
//
// A directory beats a plugin API because there is nothing to version. The tools
// keep their own release cadence, the CI job owns its own configuration, and
// this module's only job is to read what is there and refuse what is not SARIF.

const SARIF_DIR = path.join('.oasis', 'sarif');

// A SARIF file is text; 32 MB is already an enormous one. The cap exists so a
// wrong path — a directory of core dumps renamed .sarif — cannot be read into
// memory.
const MAX_FILE_BYTES = 32 * 1024 * 1024;

// Bounded so a directory nobody prunes cannot make every scan slower forever.
const MAX_FILES = 50;

function isSarifName(name) {
  const lower = name.toLowerCase();
  return lower.endsWith('.sarif') || lower.endsWith('.sarif.json');
}

/**
 * Directories to read, in order.
 *
 * The env override is absolute and deliberately NOT required to be inside the
 * repository: in CI the natural place for a tool's output is a workspace
 * artifacts directory beside the checkout, not inside it.
 */
function sarifDirs(repoPath, env = process.env) {
  const dirs = [];
  if (repoPath) dirs.push(path.join(repoPath, SARIF_DIR));
  if (env.OASIS_SARIF_DIR) dirs.push(env.OASIS_SARIF_DIR);
  return dirs;
}

function listSarifFiles(dirs) {
  const files = [];
  for (const dir of dirs) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      continue; // absent is the normal case, not an error
    }
    for (const entry of entries) {
      if (files.length >= MAX_FILES) break;
      if (!entry.isFile() || !isSarifName(entry.name)) continue;
      files.push(path.join(dir, entry.name));
    }
  }
  return files;
}

const scanner = {
  id: 'SARIF_IMPORT',
  type: 'SAST',
  // A fallback only. What this scanner covers depends entirely on which tools
  // left a file, so each scan reports the real answer in `stats.produced` and
  // the orchestrator prefers that. A static list here would credit DAST and
  // cloud coverage to a repository whose only SARIF file came from Trivy.
  produces: ['CONTAINER', 'IAC', 'DAST', 'CLOUD', 'API'],
  name: 'SARIF import',
  requires: null,

  async isAvailable() {
    // Nothing to install and nothing that can be missing: reading a directory
    // is always possible. Whether anything is IN it is a per-scan fact, not an
    // availability one.
    return { available: true, version: `reads ${SARIF_DIR}/*.sarif`, hint: null };
  },

  async scan({ repoPath, repository, env = process.env }) {
    const files = listSarifFiles(sarifDirs(repoPath, env));

    if (!files.length) {
      return {
        findings: [],
        stats: {
          skipped: true,
          reason: `no SARIF files in ${SARIF_DIR}/ — write another scanner's SARIF output there to import it`,
        },
      };
    }

    const findings = [];
    const tools = new Set();
    const produced = new Set();
    const rejected = [];

    for (const file of files) {
      let stat;
      try {
        stat = fs.statSync(file);
      } catch (_) {
        continue;
      }
      if (stat.size > MAX_FILE_BYTES) {
        rejected.push({ file: path.basename(file), reason: `larger than ${MAX_FILE_BYTES / 1024 / 1024} MB` });
        continue;
      }

      let document;
      try {
        document = JSON.parse(fs.readFileSync(file, 'utf8'));
      } catch (e) {
        // One unreadable file never costs the others. A half-written SARIF from
        // a CI job that was cancelled is the common case, and it should not
        // discard the four files that are fine.
        rejected.push({ file: path.basename(file), reason: `unreadable: ${e.message.slice(0, 120)}` });
        continue;
      }

      const imported = fromSarif(document, { repository, repoPath, origin: path.basename(file) });
      if (!imported.length && !Array.isArray(document.runs)) {
        rejected.push({ file: path.basename(file), reason: 'not a SARIF document (no runs array)' });
        continue;
      }

      for (const run of document.runs || []) {
        const name = (((run.tool || {}).driver) || {}).name;
        if (name) tools.add(name);
        // Coverage is credited from the RUNS, not from the findings, so a ZAP
        // report with nothing in it still counts as "DAST was tested". A clean
        // result is a result; the case this must not confuse it with is nobody
        // having run ZAP at all.
        produced.add((run.properties || {}).oasisType || typeForTool(name));
      }
      findings.push(...imported);
    }

    if (!produced.size) {
      // Files were present and none of them parsed. Completing with zero
      // findings here would credit coverage for tools whose output was thrown
      // away, which is the failure this scanner exists to avoid.
      return {
        findings: [],
        stats: {
          skipped: true,
          reason: `no readable SARIF among ${files.length} file(s)`,
          files: files.length,
          rejected,
        },
      };
    }

    return {
      findings,
      stats: {
        files: files.length,
        // What this run actually covered. The orchestrator prefers this over
        // the scanner's static `produces` list — see its coverage loop.
        produced: [...produced],
        // Which tools actually contributed. Without this, an imported finding's
        // provenance lives only on the finding, and "what scanned this repo"
        // has no answer at the scan level.
        tools: [...tools],
        // Surfaced, never swallowed: a rejected file means a tool that ran in
        // CI and whose results are not in this scan.
        rejected,
        truncated: files.length >= MAX_FILES,
        truncatedReason: files.length >= MAX_FILES ? `stopped after ${MAX_FILES} SARIF files` : null,
      },
    };
  },
};

module.exports = { scanner, sarifDirs, listSarifFiles, isSarifName, SARIF_DIR, MAX_FILES };