'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const http = require('http');
const { createFinding, severityFromCvss } = require('../finding');
const { relativeToRepo } = require('../paths');
const { resolve, parsePom, DEFAULT_REPOSITORY } = require('../maven-resolver');
const { fetchOsvVulnerabilities } = require('../../version-watch/registries/osv');
const { makeThrottle } = require('../../version-watch/scan');
const { walk } = require('./secrets-builtin');
const { chooseGoverning, inventory } = require('../licenses');

// Maven SCA over the RESOLVED tree.
//
// Every other ecosystem hands us a lockfile. Maven does not, so this resolves
// the graph itself — see maven-resolver.js for the rules it follows. For a Java
// codebase this is the difference between seeing a dozen declared starters and
// seeing the several hundred jars that actually ship.
//
// Two practical concerns drive the design here:
//
// THE REPOSITORY IS CONFIGURABLE. Maven Central may be unreachable from a
// corporate network; CA's own Nexus mirror is the likely source. Set
// OASIS_MAVEN_REPO — the app already references nexus.cainc.com elsewhere.
//
// POMS ARE CACHED ON DISK. A released POM is immutable, so it can be cached
// forever. Resolving a Spring Boot project fetches hundreds; without a cache,
// scanning twelve services would fetch the same Spring POMs twelve times.

const POM_CONCURRENCY = 8;
const OSV_CONCURRENCY = 8;
const POM_TIMEOUT_MS = 15000;

function repositoryUrl(env = process.env) {
  return (env.OASIS_MAVEN_REPO || DEFAULT_REPOSITORY).replace(/\/+$/, '');
}

function cacheDir(dir) {
  return path.join(dir, 'maven-poms');
}

function cachePath(dir, groupId, artifactId, version) {
  const safe = `${groupId}_${artifactId}_${version}`.replace(/[^A-Za-z0-9._-]/g, '_');
  return path.join(cacheDir(dir), `${safe}.pom`);
}

function get(url, timeoutMs) {
  const client = url.startsWith('https:') ? https : http;
  return new Promise(resolve_ => {
    const req = client.get(url, { headers: { 'User-Agent': 'i-Ready-OASIS' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve_(get(res.headers.location, timeoutMs));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return resolve_(null);
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', c => (body += c));
      res.on('end', () => resolve_(body));
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); resolve_(null); });
    req.on('error', () => resolve_(null));
  });
}

/**
 * The POMs that are IN the repository being scanned, keyed as Maven coordinates.
 *
 * Maven calls this the reactor: a module of the project under build is resolved
 * from the workspace, not downloaded. Without it, a multi-module repository asks
 * a public repository for its own unpublished modules, gets nothing, and reports
 * the company's own code as an artifact of unknown licence and unknown
 * dependencies — including the root POM every module inherits its licence from.
 *
 * @param {Array<string>} pomFiles  absolute paths
 */
function indexWorkspacePoms(pomFiles) {
  const index = new Map();

  for (const file of pomFiles || []) {
    let parsed;
    try {
      parsed = parsePom(fs.readFileSync(file, 'utf8'));
    } catch (_) {
      continue;                        // unreadable or malformed — the network still has a turn
    }
    const { groupId, artifactId, version } = parsed;
    if (!groupId || !artifactId || !version) continue;
    // A version that is still a property (${revision}, the flatten-plugin
    // convention) cannot be keyed on: the coordinate a dependency asks for is
    // the expanded one, and guessing at it would serve the wrong POM.
    if (String(version).includes('${')) continue;
    index.set(`${groupId}:${artifactId}:${version}`, file);
  }

  return index;
}

/**
 * A POM fetcher backed by the workspace, a disk cache, and a concurrency limit.
 * Returns null for anything it cannot retrieve; the resolver records the miss.
 *
 * @param {Map} workspace  coordinate -> path of a POM inside the repository,
 *                         consulted before anything leaves the machine
 */
function createPomFetcher({ dir, env = process.env, timeoutMs = POM_TIMEOUT_MS, workspace = null }) {
  const base = repositoryUrl(env);
  const throttle = makeThrottle(POM_CONCURRENCY);
  const memory = new Map();
  const stats = { fetched: 0, cached: 0, missed: 0, workspace: 0 };

  const fetchPom = async (groupId, artifactId, version) => {
    if (!groupId || !artifactId || !version) return null;
    const key = `${groupId}:${artifactId}:${version}`;
    if (memory.has(key)) return memory.get(key);

    // The repository's own modules first. They are the authority on themselves,
    // and the copy on disk is newer than anything published.
    const local = workspace && workspace.get(key);
    if (local) {
      try {
        const xml = fs.readFileSync(local, 'utf8');
        stats.workspace += 1;
        memory.set(key, xml);
        return xml;
      } catch (_) {
        // Vanished mid-scan; fall through to the repository.
      }
    }

    const file = cachePath(dir, groupId, artifactId, version);
    try {
      const cached = fs.readFileSync(file, 'utf8');
      stats.cached += 1;
      memory.set(key, cached);
      return cached;
    } catch (_) {}

    const url = `${base}/${groupId.replace(/\./g, '/')}/${artifactId}/${version}/${artifactId}-${version}.pom`;
    const body = await throttle(() => get(url, timeoutMs));

    if (body) {
      stats.fetched += 1;
      try {
        fs.mkdirSync(cacheDir(dir), { recursive: true });
        // A released POM never changes, so this cache needs no expiry.
        fs.writeFileSync(file, body);
      } catch (_) {}
    } else {
      stats.missed += 1;
    }

    memory.set(key, body);
    return body;
  };

  fetchPom.stats = stats;
  fetchPom.repository = base;
  return fetchPom;
}

function findPoms(repoPath, maxFiles = 20000) {
  const found = [];
  for (const file of walk(repoPath, repoPath, { files: 0, maxFiles })) {
    if (path.basename(file) === 'pom.xml') found.push(file);
  }
  return found;
}

function severityOf(advisory) {
  return advisory.severity || severityFromCvss(advisory.cvss) || 'unknown';
}

function toFinding(dep, advisory, repository, pomPath) {
  const transitive = !dep.direct;
  return createFinding({
    type: 'SCA',
    category: 'VULNERABLE_DEPENDENCY',
    severity: severityOf(advisory),
    title: `${advisory.id} in ${dep.name} ${dep.version}`,
    description:
      (advisory.summary || 'A known vulnerability affects this dependency version.') +
      (transitive
        ? ` This is a transitive dependency at depth ${dep.depth}${dep.path ? `, reached via ${dep.path}` : ''}. It is not declared in the POM, so upgrading means bumping whatever brings it in, or pinning it in dependencyManagement.`
        : ''),
    repository,
    file: pomPath,
    cve: advisory.id && advisory.id.startsWith('CVE-') ? advisory.id : null,
    source: 'MAVEN_SCA',
    ruleId: advisory.id,
    remediation: transitive
      ? `Pin ${dep.name} to a fixed version in <dependencyManagement>, or upgrade the dependency that brings it in.`
      : `Upgrade ${dep.name} past the affected range.`,
    evidence: `maven · ${dep.name} ${dep.version}${transitive ? ` (transitive, depth ${dep.depth})` : ' (direct)'} — ${advisory.id}`,
    metadata: {
      ecosystem: 'Maven',
      packageName: dep.name,
      versionInUse: dep.version,
      transitive,
      directnessKnown: true,
      dependencyDepth: dep.depth,
      dependencyPath: dep.path || null,
      scope: dep.scope,
      advisoryUrl: advisory.url || null,
      lockfile: pomPath,
      reachability: 'UNKNOWN',
    },
  });
}

// A licence obligation is not a vulnerability, but it is a finding: something
// discovered in the code that somebody has to decide about. Same model, same
// triage, same suppression — which is why it is a finding type rather than a
// separate report nobody opens.
function toLicenseFinding(dep, governing, repository, pomPath, mavenRepository = null) {
  // "Nobody declared a licence" and "we never got the POM to look at" are
  // different facts with different remedies, and reporting the second as the
  // first is how a scan tells someone to add a licence that already exists. An
  // artifact from a private Nexus is unreadable from here, not unlicensed.
  const unreachable = governing.category === 'unknown' && dep.pomAvailable === false;

  return createFinding({
    type: 'LICENSE',
    category: `LICENSE_${governing.category.toUpperCase().replace(/-/g, '_')}`,
    severity: governing.severity || 'INFO',
    title: `${governing.spdx || (unreachable ? 'Unreadable licence' : 'Unknown licence')} — ${dep.name}`,
    description: unreachable
      ? `${dep.name} ${dep.version}: its POM could not be retrieved from ${mavenRepository || 'the configured Maven repository'}, so no licence could be read. ` +
        'That is a gap in what this scan could see, not a statement about the dependency — an internal artifact published only to a private repository looks exactly like this.'
      : `${dep.name} ${dep.version} is licensed under ${governing.spdx || 'a licence that could not be identified'}` +
        (governing.declared && governing.declared !== governing.spdx ? ` (declared as "${governing.declared}")` : '') +
        `. ${governing.reason || ''} ` +
        'Whether this is acceptable depends on how the software is distributed, which is a legal question rather than a technical one.',
    repository,
    file: pomPath,
    source: 'MAVEN_SCA',
    ruleId: `license-${governing.category}`,
    remediation: unreachable
      ? 'Point OASIS_MAVEN_REPO at a repository that holds this artifact — the internal Nexus for a company-published module — and rescan. If it is genuinely unpublished, record its licence where the build declares it.'
      : governing.category === 'unknown'
        ? 'Identify the licence from the project page and record it, or replace the dependency.'
        : 'Have legal review the obligation for how this product is distributed, or replace the dependency.',
    evidence:
      `${dep.name} ${dep.version}${dep.direct ? ' (direct)' : ` (transitive, depth ${dep.depth})`} — ` +
      (unreachable ? 'POM not retrievable' : governing.declared || 'no licence declared'),
    metadata: {
      // Whether the POM was read at all, so the reader can tell a licence
      // nobody declared from one nobody could reach.
      pomAvailable: dep.pomAvailable === undefined ? null : dep.pomAvailable,
      ecosystem: 'Maven',
      packageName: dep.name,
      versionInUse: dep.version,
      license: governing.spdx,
      licenseDeclared: governing.declared,
      licenseCategory: governing.category,
      transitive: !dep.direct,
      dependencyDepth: dep.depth,
      reachability: 'UNKNOWN',
    },
  });
}

const scanner = {
  id: 'MAVEN_SCA',
  type: 'SCA',
  // Two finding types from one resolution pass: the dependency graph answers
  // both "what is vulnerable" and "what are we obliged to".
  produces: ['SCA', 'LICENSE'],
  name: 'Maven SCA + licences',
  requires: null,

  async isAvailable() {
    return { available: true, version: `built-in · ${repositoryUrl()}`, hint: null };
  },

  async scan({ repoPath, repository, dir, env = process.env, httpClient }) {
    if (!fs.existsSync(repoPath)) throw new Error(`Repository path does not exist: ${repoPath}`);

    const poms = findPoms(repoPath);
    if (!poms.length) {
      return { findings: [], stats: { skipped: true, reason: 'no pom.xml found — not a Maven project' } };
    }

    const cacheRoot = dir || path.join(os.homedir(), '.oasis-security');
    const fetchPom = createPomFetcher({ dir: cacheRoot, env, workspace: indexWorkspacePoms(poms) });

    const byCoordinate = new Map();
    const unresolved = [];
    const fetchFailures = [];
    let truncated = false;
    let truncatedReason = null;

    for (const pomFile of poms) {
      let xml;
      try {
        xml = fs.readFileSync(pomFile, 'utf8');
      } catch (_) {
        continue;
      }

      let result;
      try {
        result = await resolve(xml, fetchPom);
      } catch (e) {
        fetchFailures.push(`${relativeToRepo(repoPath, pomFile)}: ${e.message}`);
        continue;
      }

      const rel = relativeToRepo(repoPath, pomFile);
      for (const dep of result.dependencies) {
        // A multi-module build resolves the same artifact from several POMs.
        // Keep the shallowest occurrence, matching nearest-wins.
        const existing = byCoordinate.get(`${dep.name}@${dep.version}`);
        if (!existing || dep.depth < existing.depth) {
          byCoordinate.set(`${dep.name}@${dep.version}`, { ...dep, pom: rel });
        }
      }
      unresolved.push(...result.unresolved.map(u => ({ ...u, pom: rel })));
      fetchFailures.push(...result.fetchFailures);
      truncated = truncated || result.truncated;
      if (result.truncated && !truncatedReason) {
        truncatedReason = `stopped at the ${result.limit}-dependency limit`
          + ` — raise OASIS_MAVEN_MAX_ARTIFACTS to resolve the whole graph`;
      }
    }

    const dependencies = [...byCoordinate.values()];
    const throttle = makeThrottle(OSV_CONCURRENCY);
    const findings = [];
    let lookupErrors = 0;

    await Promise.all(
      dependencies.map(dep =>
        throttle(async () => {
          let result;
          try {
            result = await fetchOsvVulnerabilities('Maven', dep.name, dep.version, httpClient);
          } catch (_) {
            lookupErrors += 1;
            return;
          }
          if (result.error) {
            lookupErrors += 1;
            return;
          }
          for (const advisory of result.cves || []) {
            findings.push(toFinding(dep, advisory, repository, dep.pom));
          }
        })
      )
    );

    // Licence evaluation is local — the POMs are already fetched — so it costs
    // nothing beyond the walk we just did.
    const licenseInventory = inventory(dependencies);
    for (const dep of dependencies) {
      const governing = chooseGoverning(dep.licenses);
      if (governing.action === 'allow') continue;
      findings.push(toLicenseFinding(dep, governing, repository, dep.pom, fetchPom.repository));
    }

    return {
      findings,
      // Published for the SBOM generator: the same tree, licences included.
      dependencies: dependencies.map(d => ({
        ecosystem: 'Maven', name: d.name, version: d.version,
        licenses: d.licenses || [], direct: d.direct, path: d.path,
      })),
      stats: {
        licenseInventory,
        licensesUnknown: licenseInventory.filter(l => l.category === 'unknown').reduce((n, l) => n + l.count, 0),
        poms: poms.length,
        dependencies: dependencies.length,
        directDependencies: dependencies.filter(d => d.direct).length,
        transitiveDependencies: dependencies.filter(d => !d.direct).length,
        maxDepth: dependencies.reduce((m, d) => Math.max(m, d.depth), 0),
        pomsFetched: fetchPom.stats.fetched,
        pomsFromCache: fetchPom.stats.cached,
        // Modules of this repository, resolved from the working tree rather than
        // looked for in a repository that has never seen them.
        pomsFromWorkspace: fetchPom.stats.workspace,
        // Each of these is a subtree that was NOT walked. Reported so an
        // unreachable repository cannot pass as a small dependency graph.
        pomsUnavailable: fetchPom.stats.missed,
        unresolvedVersions: unresolved.length,
        lookupErrors,
        truncated,
        truncatedReason,
        repository: fetchPom.repository,
        vulnerableTransitive: findings.filter(f => f.metadata.transitive).length,
      },
    };
  },
};

module.exports = { scanner, createPomFetcher, findPoms, indexWorkspacePoms, repositoryUrl, toFinding };
