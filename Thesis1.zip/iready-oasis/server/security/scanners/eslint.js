'use strict';
const fs = require('fs');
const path = require('path');
const { createFinding } = require('../finding');
const { toPosix } = require('../paths');
const { runTool, toolAvailability } = require('../scanner');

// ESLint adapter — code quality, plus the security rules ESLint already has.
//
// Three tiers, tried in order, so a repository's own setup always wins when
// it has one:
//   1. The REPOSITORY'S own local ESLint (node_modules/.bin/eslint) — its
//      version, config, and plugins are the only combination that produces
//      results its developers will accept.
//   2. OASIS's own bundled ESLint (a real `dependencies` entry, shipped
//      inside the packaged app — see the `web-tree-sitter` dependency for
//      the same pattern). Run in-process via ESLint's Node API rather than
//      spawned as a binary, because a packaged Electron app's node_modules
//      lives inside app.asar — not a real path a subprocess can exec. This
//      still resolves the repository's OWN config file from its checkout
//      (ESLint auto-discovers config from `cwd`), so the common case this
//      unlocks is a repo whose config is committed but whose own ESLint was
//      never `npm install`ed — no eslint of its own, but not un-lintable.
//      Pinned to ESLint 8.x specifically (not the current v9 major), because
//      v9 dropped default support for legacy `.eslintrc*` config — most
//      repositories with no local ESLint to fall back on still use that
//      format, and v8 auto-detects either it or flat `eslint.config.js`.
//   3. A global `eslint` on PATH, kept only as a last-resort fallback for the
//      unexpected case where the bundled dependency itself failed to load.
//
// Why quality findings are a separate TYPE rather than more SAST:
// there are usually hundreds of them, and a queue where a CRITICAL sits under
// 400 `no-unused-vars` entries is a queue people stop opening. QUALITY is
// filterable in and out on its own; the security-relevant handful that ESLint
// finds are promoted to SAST below so they do not get filtered out with the
// noise.

const INSTALL_HINT =
  'bundled ESLint failed to load — this should not happen; falling back to a global `eslint` on PATH';

// ESLint severities. 2 is an error and 1 is a warning; neither is a security
// severity, and pretending otherwise would put lint above real vulnerabilities.
// MEDIUM is the ceiling for quality, which keeps an unused import below every
// CRITICAL and HIGH in the same list.
const LEVELS = { 2: 'MEDIUM', 1: 'LOW' };

// The core ESLint rules that are genuinely security findings rather than style.
// These are promoted out of QUALITY into SAST with a CWE, because a queue that
// buries `no-eval` under formatting complaints has lost the finding.
//
// Deliberately short and core-only. Plugin rules (eslint-plugin-security,
// eslint-plugin-no-unsanitized) are recognised by prefix below instead, since
// enumerating them would rot every time those plugins release.
const SECURITY_RULES = {
  'no-eval': { cwe: 'CWE-95', severity: 'HIGH' },
  'no-implied-eval': { cwe: 'CWE-95', severity: 'HIGH' },
  'no-new-func': { cwe: 'CWE-95', severity: 'HIGH' },
  'no-script-url': { cwe: 'CWE-79', severity: 'MEDIUM' },
  'no-proto': { cwe: 'CWE-1321', severity: 'MEDIUM' },
};

const SECURITY_PLUGINS = ['security/', 'no-unsanitized/', 'xss/'];

function isSecurityRule(ruleId) {
  if (!ruleId) return false;
  return Boolean(SECURITY_RULES[ruleId]) || SECURITY_PLUGINS.some(p => ruleId.startsWith(p));
}

// `@typescript-eslint/no-explicit-any` → NO_EXPLICIT_ANY. The plugin prefix is
// dropped: it says where the rule came from, not what it found, and keeping it
// would split the same concern across two categories when a project switches
// plugins.
function categoryFrom(ruleId) {
  if (!ruleId) return 'PARSE_ERROR';
  const tail = String(ruleId).split('/').pop();
  return tail.toUpperCase().replace(/[^A-Z0-9]+/g, '_');
}

// The repository's own ESLint, when it has one. A project pinned to ESLint 8
// with a legacy .eslintrc produces nothing but errors under a global ESLint 9,
// so preferring the local binary is the difference between useful output and a
// wall of config failures.
function localBinary(repoPath) {
  if (!repoPath) return null;
  for (const name of ['eslint', 'eslint.cmd']) {
    const candidate = path.join(repoPath, 'node_modules', '.bin', name);
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

// OASIS's own bundled ESLint version, read lazily so a broken/absent install
// (should not happen — it is a `dependencies` entry) degrades to the global
// binary instead of throwing at module load time.
function bundledVersion() {
  try {
    return require('eslint/package.json').version;
  } catch (_) {
    return null;
  }
}

// Runs the bundled ESLint in-process via its Node API rather than spawning a
// binary. A packaged Electron app's node_modules lives inside app.asar, which
// is not a real filesystem path a subprocess can exec — the API call has no
// such requirement. ESLint still resolves the TARGET repository's own config
// file from `cwd`, so this only ever substitutes the ESLint *engine*, never
// the project's own rules.
async function runBundled(repoPath, files) {
  const { ESLint } = require('eslint');
  const eslint = new ESLint({ cwd: repoPath, errorOnUnmatchedPattern: false });
  return eslint.lintFiles(Array.isArray(files) ? files : ['.']);
}

/**
 * ESLint's JSON output → findings.
 *
 * @param {Array}  payload     parsed `eslint --format json` output
 * @param {string} repository
 * @param {string} repoPath    to make absolute file paths repository-relative
 */
function toFindings(payload, repository, repoPath) {
  const findings = [];

  for (const result of payload || []) {
    const file = repoPath ? toPosix(path.relative(repoPath, result.filePath || '')) : result.filePath;

    for (const message of result.messages || []) {
      // A parse error is not a finding about the code, it is a statement that
      // this file was never analysed. Counted in stats instead — reported as a
      // finding it would read as a defect in the source, and hundreds of them
      // (the usual result of the wrong ESLint version) would bury everything.
      if (message.fatal || !message.ruleId) continue;

      const security = SECURITY_RULES[message.ruleId];
      const promoted = isSecurityRule(message.ruleId);

      findings.push(
        createFinding({
          type: promoted ? 'SAST' : 'QUALITY',
          category: categoryFrom(message.ruleId),
          severity: (security && security.severity) || (promoted ? 'MEDIUM' : LEVELS[message.severity]) || 'LOW',
          title: message.message ? String(message.message).slice(0, 140) : message.ruleId,
          description: message.message || '',
          repository,
          file,
          startLine: message.line || null,
          endLine: message.endLine || message.line || null,
          cwe: (security && security.cwe) || null,
          source: 'ESLINT',
          ruleId: message.ruleId,
          // ESLint's own autofix, reported as guidance rather than applied.
          remediation: message.fix ? 'ESLint can fix this automatically: eslint --fix' : null,
          evidence: `${file}:${message.line || '?'} — ${message.ruleId}`,
          metadata: {
            snippet: null,
            confidence: 'HIGH',
            engine: 'eslint',
            eslintSeverity: message.severity,
            fixable: Boolean(message.fix),
          },
        })
      );
    }
  }

  return findings;
}

function parseErrorCount(payload) {
  return (payload || []).reduce(
    (n, r) => n + (r.messages || []).filter(m => m.fatal || (!m.ruleId && m.message)).length,
    0
  );
}

// Same contract as the binary path above (findings, or a graceful skip), but
// via the in-process API — ESLint's own result objects are already the same
// shape the CLI's `--format json` serializes, so `toFindings`/`parseErrorCount`
// need no changes to accept either source.
async function scanBundled(repoPath, repository, files) {
  let payload;
  try {
    payload = await runBundled(repoPath, files);
  } catch (e) {
    // Overwhelmingly "no ESLint configuration found" — most repositories
    // without their own ESLint also have no config for one to use. A fact
    // about the repository, not a broken scanner.
    return {
      findings: [],
      stats: { skipped: true, reason: `ESLint produced no results — ${String(e.message || e).slice(0, 200)}` },
    };
  }

  if (!Array.isArray(payload)) {
    return { findings: [], stats: { skipped: true, reason: 'ESLint output was not a results array' } };
  }

  return {
    findings: toFindings(payload, repository, repoPath),
    stats: {
      filesAnalysed: payload.length,
      binary: 'bundled',
      parseErrors: parseErrorCount(payload),
    },
  };
}

const scanner = {
  id: 'ESLINT',
  type: 'QUALITY',
  produces: ['QUALITY', 'SAST'],
  name: 'ESLint',
  requires: 'eslint',

  // repoPath is passed by the orchestrator during a scan and absent on the
  // dashboard's availability listing, where there is no repository yet.
  // Bundled ESLint needs no repository to be available, so this reports
  // available even before a repository is chosen — unlike the old
  // binary-only check, which showed "not installed" on the dashboard for a
  // project whose ESLint was only ever local.
  async isAvailable({ repoPath = null } = {}) {
    const local = localBinary(repoPath);
    if (local) return toolAvailability(local, ['--version'], INSTALL_HINT);

    const version = bundledVersion();
    if (version) return { available: true, version, hint: null };

    return toolAvailability('eslint', ['--version'], INSTALL_HINT);
  },

  async scan({ repoPath, repository, timeoutMs = 600000, files = null }) {
    // Quick Scan passes an explicit (possibly empty) file list. Empty means the
    // diff touched nothing ESLint would look at — skip the process entirely
    // rather than let '.' silently fall back to a full-repo lint.
    if (Array.isArray(files) && files.length === 0) {
      return { findings: [], stats: { filesAnalysed: 0, skipped: true, reason: 'no changed files to lint' } };
    }

    const local = localBinary(repoPath);

    if (!local && bundledVersion()) {
      return scanBundled(repoPath, repository, files);
    }

    const binary = local || 'eslint';

    const result = await runTool(
      binary,
      [
        '--format', 'json',
        // Without this, a repository with no matching files exits non-zero and
        // the run reads as a failure rather than as "nothing to lint".
        '--no-error-on-unmatched-pattern',
        ...(Array.isArray(files) ? files : ['.']),
      ],
      { cwd: repoPath, timeoutMs }
    );

    if (result.timedOut) {
      throw new Error(`ESLint timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    if (result.error) {
      throw new Error(`ESLint could not run: ${result.error}`);
    }

    let payload;
    try {
      payload = JSON.parse(result.stdout);
    } catch (_) {
      // Overwhelmingly this is "no ESLint configuration found", which is a fact
      // about the repository, not a broken scanner: most repositories are not
      // ESLint projects. Reported as SKIPPED so the scan stays green and the
      // orchestrator does not credit QUALITY as covered.
      const reason = (result.stderr || result.stdout || 'no JSON output').trim().split('\n')[0].slice(0, 200);
      return {
        findings: [],
        stats: { skipped: true, reason: `ESLint produced no results — ${reason}` },
      };
    }

    if (!Array.isArray(payload)) {
      return { findings: [], stats: { skipped: true, reason: 'ESLint output was not a results array' } };
    }

    return {
      findings: toFindings(payload, repository, repoPath),
      stats: {
        filesAnalysed: payload.length,
        binary: local ? 'repository-local' : 'global',
        // A repository where ESLint could not parse most files has not been
        // meaningfully scanned, and the finding count alone would hide that.
        parseErrors: parseErrorCount(payload),
      },
    };
  },
};

module.exports = { scanner, toFindings, categoryFrom, isSecurityRule, localBinary, bundledVersion, parseErrorCount, LEVELS, SECURITY_RULES, INSTALL_HINT };