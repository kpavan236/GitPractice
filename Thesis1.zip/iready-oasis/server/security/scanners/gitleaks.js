'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { createFinding } = require('../finding');
const { runTool, toolAvailability } = require('../scanner');
const { maskSecret } = require('./secrets-builtin');

// Gitleaks adapter — secret scanning, and the second opinion that makes the
// correlation engine do something visible.
//
// Gitleaks and the built-in scanner will both find the same AWS key. They
// produce the same fingerprint (repository + file + hash of the secret), so the
// dashboard shows ONE finding carrying two detection sources — which is the
// point of normalising in the first place.
//
// Gitleaks also reads git history, so it finds credentials that were removed
// from the working tree but are still recoverable from earlier commits. The
// built-in scanner cannot do that.

// Optional extra: the bundled working-tree and git-history scanners already
// cover secrets on every platform.
const INSTALL_HINT = 'optional — github.com/gitleaks/gitleaks/releases';

function hashSecret(secret) {
  return crypto.createHash('sha256').update(secret).digest('hex');
}

function toFindings(rows, repository) {
  return (rows || []).map(row => {
    // Gitleaks hands back the credential in `Secret`. It is hashed for
    // deduplication and masked for display, and the raw value is dropped here
    // — it must not reach the findings file or a log line.
    const secret = row.Secret || row.Match || '';
    const fromHistory = Boolean(row.Commit);

    return createFinding({
      type: 'SECRET',
      category: String(row.RuleID || 'secret').toUpperCase().replace(/-/g, '_'),
      severity: 'CRITICAL',
      title: row.Description || row.RuleID || 'Secret detected',
      description:
        (row.Description || 'A credential was found in this repository.') +
        (fromHistory
          ? ' Found in git history — removing the file does not remove it; the credential must be rotated.'
          : ''),
      repository,
      file: row.File || null,
      startLine: row.StartLine || null,
      endLine: row.EndLine || row.StartLine || null,
      cwe: 'CWE-798',
      source: 'GITLEAKS',
      ruleId: row.RuleID || null,
      remediation:
        'Rotate the credential at its provider, then remove it from the file and ' +
        'from git history (git filter-repo or BFG).',
      evidence: `${row.File || '?'}:${row.StartLine || '?'}${fromHistory ? ` (commit ${String(row.Commit).slice(0, 8)})` : ''} — ${maskSecret(secret)}`,
      metadata: {
        secretHash: hashSecret(secret),
        masked: maskSecret(secret),
        entropy: typeof row.Entropy === 'number' ? Math.round(row.Entropy * 100) / 100 : null,
        commit: row.Commit || null,
        author: row.Author || null,
        date: row.Date || null,
        inHistory: fromHistory,
        verified: false,
      },
    });
  });
}

const scanner = {
  id: 'GITLEAKS',
  type: 'SECRET',
  name: 'Gitleaks',
  requires: 'gitleaks',

  isAvailable() {
    return toolAvailability('gitleaks', ['version'], INSTALL_HINT);
  },

  async scan({ repoPath, repository, timeoutMs = 300000 }) {
    // Report to a temp file rather than stdout. Gitleaks mixes its banner and
    // progress output into stdout, and parsing around that is fragile.
    const reportPath = path.join(
      fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-gitleaks-')),
      'report.json'
    );

    try {
      const result = await runTool(
        'gitleaks',
        ['detect', '--source', repoPath, '--report-format', 'json', '--report-path', reportPath, '--redact=0', '--exit-code', '0'],
        { cwd: repoPath, timeoutMs }
      );

      if (result.timedOut) throw new Error(`Gitleaks timed out after ${Math.round(timeoutMs / 1000)}s`);
      if (result.error) throw new Error(`Gitleaks could not run: ${result.error}`);

      let rows = [];
      if (fs.existsSync(reportPath)) {
        const raw = fs.readFileSync(reportPath, 'utf8').trim();
        // An empty report file means a clean repository, not a broken run.
        if (raw) rows = JSON.parse(raw);
      }

      return { findings: toFindings(rows, repository), stats: { leaks: rows.length } };
    } finally {
      // The report holds unredacted credentials. Delete it whatever happened.
      try {
        fs.rmSync(path.dirname(reportPath), { recursive: true, force: true });
      } catch (_) {}
    }
  },
};

module.exports = { scanner, toFindings, INSTALL_HINT };