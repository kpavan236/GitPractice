'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createFinding } = require('../finding');
const { runTool, streamTool } = require('../scanner');
const { toPosix } = require('../paths');
const { PATTERNS, isPlaceholder, shannonEntropy } = require('../secret-patterns');
const { maskSecret } = require('./secrets-builtin');

// Secret scanning through git history.
//
// This is the half that matters most and the half people forget. Deleting a
// credential from a file does not remove it: `git log -p` still hands it to
// anyone who clones the repository, and the working-tree scanner sees nothing.
// A repository can look completely clean while every key it has ever held
// remains one command away.
//
// Gitleaks does this well, but requires an install. git does not — OASIS
// already shells out to it 65 times to clone and inspect repositories, so it is
// a hard dependency of the app either way, and `git` behaves the same on
// Windows, macOS, and Linux.
//
// As with the working-tree scanner, THE SECRET IS NEVER STORED: a hash for
// deduplication and a masked preview, nothing else.

// History is unbounded, so the scan is. Both limits are reported in the stats
// rather than silently applied — a partial history scan must not read as a
// clean one.
const DEFAULT_MAX_COMMITS = Number(process.env.OASIS_HISTORY_MAX_COMMITS) || 500;
const MAX_LINE_LENGTH = 4000;

function hashSecret(secret) {
  return crypto.createHash('sha256').update(secret).digest('hex');
}

/**
 * An incremental parser for `git log -p` output.
 *
 * Stateful and line-at-a-time BY DESIGN. The whole-string version worked only
 * because the caller had already buffered the complete diff, which is what
 * broke the scanner on every repository with real history. Nothing here holds
 * more than the current line plus the commit header it belongs to, so the
 * memory cost is the same for a hundred commits and a hundred thousand.
 *
 * Only ADDED lines are examined. A removed line is the credential leaving the
 * working tree, which is not itself a new leak — the commit that added it is
 * already reported, and counting both would double every rotation.
 */
function createDiffParser(repository, { commitLimitHit = false } = {}) {
  const findings = [];
  const seen = new Set();

  let commit = null;
  let author = null;
  let date = null;
  let file = null;
  let commitCount = 0;

  function pushLine(rawLine) {
    if (rawLine.startsWith('\x00commit ')) {
      const [, sha, who, when] = rawLine.split('\x00');
      commit = sha ? sha.replace('commit ', '').trim() : null;
      author = who || null;
      date = when || null;
      commitCount++;
      return;
    }
    if (rawLine.startsWith('+++ b/')) {
      file = toPosix(rawLine.slice(6).trim());
      return;
    }
    // Added lines only, and not the diff header itself.
    if (!rawLine.startsWith('+') || rawLine.startsWith('+++')) return;

    const line = rawLine.slice(1);
    if (!line.trim() || line.length > MAX_LINE_LENGTH) return;

    for (const rule of PATTERNS) {
      rule.pattern.lastIndex = 0;
      const match = rule.pattern.exec(line);
      if (!match) continue;

      const secret = match[1] || match[0];
      if (!secret || isPlaceholder(secret)) continue;
      if (rule.entropyFloor && shannonEntropy(secret) < rule.entropyFloor) continue;

      // One finding per (file, secret). The same credential appears in every
      // commit that touched its line; reporting each would bury the signal.
      const key = `${file}|${hashSecret(secret)}`;
      if (seen.has(key)) return;
      seen.add(key);

      const finding = createFinding({
          type: 'SECRET',
          category: rule.id.toUpperCase().replace(/-/g, '_'),
          severity: rule.severity,
          title: `${rule.name} (in git history)`,
          description:
            `A ${rule.name.toLowerCase()} was committed to this repository's history. ` +
            'It is recoverable by anyone who can clone the repository, whether or not it is still in the working tree. ' +
            'Removing the file does not remove the credential — it must be rotated.',
          repository,
          file,
          cwe: 'CWE-798',
          source: 'GIT_HISTORY',
          ruleId: rule.id,
          remediation:
            'Rotate the credential at its provider first. Purging history (git filter-repo, BFG) is secondary and ' +
            'does not help if the repository has already been cloned or forked.',
          evidence: `${file} — ${maskSecret(secret)}${commit ? ` (commit ${commit.slice(0, 8)})` : ''}`,
          metadata: {
            secretHash: hashSecret(secret),
            masked: maskSecret(secret),
            entropy: Math.round(shannonEntropy(secret) * 100) / 100,
            commit,
            author,
            date,
            inHistory: true,
            historyTruncated: commitLimitHit,
            verified: false,
          },
      });
      // Non-enumerable: needed for validity checking during this scan, and
      // invisible to JSON.stringify so it can never be persisted or logged.
      Object.defineProperty(finding, '_plaintext', { value: secret, enumerable: false });
      findings.push(finding);
      return;
    }
  }

  return {
    pushLine,
    findings,
    get commitCount() { return commitCount; },
  };
}

/**
 * The whole-string form, kept for callers that already have the text.
 *
 * The scanner itself does NOT use this — it streams — but a diff pasted into a
 * test or arriving from elsewhere is still worth parsing with the same code.
 */
function parseDiff(diff, repository, options = {}) {
  const parser = createDiffParser(repository, options);
  for (const line of diff.split('\n')) parser.pushLine(line);
  return parser.findings;
}

const scanner = {
  id: 'GIT_HISTORY',
  type: 'SECRET',
  name: 'Git history secrets',
  requires: 'git',

  async isAvailable() {
    // git is already required by OASIS to clone repositories, so this is a
    // sanity check rather than an expected failure.
    const result = await runTool('git', ['--version'], { timeoutMs: 8000 });
    return result.error
      ? { available: false, version: null, hint: 'git is not on PATH — OASIS needs it to clone repositories too' }
      : { available: true, version: (result.stdout || '').trim(), hint: null };
  },

  /**
   * @param {function} streamer  injectable for tests; defaults to the real one.
   *                             The volume and the failure modes here are the
   *                             whole point, and neither is controllable from a
   *                             test through whatever history a machine happens
   *                             to have.
   */
  async scan({ repoPath, repository, maxCommits = DEFAULT_MAX_COMMITS, timeoutMs = 300000, streamer = streamTool }) {
    if (!fs.existsSync(path.join(repoPath, '.git'))) {
      // A directory that is not a git repository has no history to scan. Not
      // an error, but not "clean" either.
      return { findings: [], stats: { skipped: true, reason: 'not a git repository' } };
    }

    const parser = createDiffParser(repository);

    // STREAMED, not buffered. `git log -p --all` over real history is tens to
    // hundreds of megabytes; holding it cost this scanner every scan it ever
    // ran ("stdout maxBuffer length exceeded"), and the dashboard then showed
    // secret coverage as though only the working tree mattered.
    const result = await streamer(
      'git',
      [
        '-C', repoPath, 'log',
        // Every ref, not just the current branch. A credential committed to a
        // feature branch that was never merged is still in the repository and
        // still clonable; scanning only HEAD would miss it entirely.
        '--all',
        `--max-count=${maxCommits}`,
        '--format=%x00commit %H%x00%an <%ae>%x00%aI',
        '-p', '--no-color', '--no-renames',
        // Binary blobs carry no readable credentials and dominate the output.
        '--diff-filter=AM', '--',
      ],
      { cwd: repoPath, timeoutMs, onLine: line => parser.pushLine(line) }
    );

    // A timeout is NOT thrown away. Whatever git printed before the deadline
    // has already been parsed, and a credential found in the first two minutes
    // of a five-minute history is still a credential. It is reported as a
    // partial scan instead — the one thing it must never look like is clean.
    if (result.error) throw new Error(`git log failed: ${result.error}`);
    if (!result.ok && !result.timedOut) {
      throw new Error(`git log failed: ${(result.stderr || '').trim() || `exit ${result.code}`}`);
    }

    const commitCount = parser.commitCount;
    const commitLimitHit = commitCount >= maxCommits;
    const linesTruncated = result.linesTruncated || 0;

    // Every reason the scan saw less than the whole history, named. A partial
    // history scan that reads as a complete one is worse than no scan: it is a
    // clean bill of health nobody checked.
    const reasons = [];
    if (result.timedOut) {
      reasons.push(
        `the search timed out after ${Math.round(timeoutMs / 1000)}s — ${commitCount} commits were searched ` +
        'before it stopped; lower OASIS_HISTORY_MAX_COMMITS or raise the timeout'
      );
    }
    if (commitLimitHit) {
      // Almost every long-lived repository hits this, and a secret committed
      // and removed years ago is exactly what history scanning is FOR — so
      // the limit has to name itself rather than hide behind "a limit".
      reasons.push(
        `only the last ${maxCommits} commits were searched — raise OASIS_HISTORY_MAX_COMMITS to search further back`
      );
    }
    if (linesTruncated) {
      reasons.push(
        `${linesTruncated} line${linesTruncated === 1 ? ' was' : 's were'} too long to scan in full ` +
        '(usually a minified or generated file committed as a single line)'
      );
    }

    return {
      findings: parser.findings,
      stats: {
        commitsScanned: commitCount,
        bytesScanned: result.bytes || 0,
        linesTruncated,
        timedOut: Boolean(result.timedOut),
        // Reported, never silent: a repository with more history than the limit
        // has been only partly examined.
        truncated: reasons.length > 0,
        truncatedReason: reasons.length ? reasons.join('; ') : null,
        maxCommits,
      },
    };
  },
};

module.exports = { scanner, parseDiff, createDiffParser, DEFAULT_MAX_COMMITS };