'use strict';

// SBOM generation with no external tooling.
//
// Syft would do this, and needs installing. But Version Watch already parses
// manifests across ~20 ecosystems and resolves each dependency's version and
// advisories — which is exactly the information a CycloneDX document holds. The
// SBOM was already in the data; it only needed writing out in the format
// procurement asks for.
//
// CycloneDX 1.5 over SPDX: it is what most tooling ingests, and its component
// model maps cleanly onto a dependency row.

const { normaliseLicense } = require('../licenses');

const SPEC_VERSION = '1.5';
const FORMAT = 'cyclonedx-json';

// Package URL (purl) is how a CycloneDX component is identified across tools.
// The type segment differs from our ecosystem names in a few places.
const PURL_TYPES = {
  maven: 'maven',
  gradle: 'maven',
  npm: 'npm',
  pip: 'pypi',
  pypi: 'pypi',
  go: 'golang',
  cargo: 'cargo',
  nuget: 'nuget',
  composer: 'composer',
  rubygems: 'gem',
  hex: 'hex',
  pub: 'pub',
  cpan: 'cpan',
  conda: 'conda',
  conan: 'conan',
  hackage: 'hackage',
  swift: 'swift',
  sbt: 'maven',
};

function purlFor(row) {
  const type = PURL_TYPES[String(row.ecosystem || '').toLowerCase()] || 'generic';
  const version = row.versionInUse ? `@${encodeURIComponent(row.versionInUse)}` : '';

  // A Maven coordinate is group:artifact, and purl wants them as namespace and
  // name. Everything else is a bare name.
  if (type === 'maven' && String(row.package).includes(':')) {
    const [group, artifact] = String(row.package).split(':');
    return `pkg:maven/${encodeURIComponent(group)}/${encodeURIComponent(artifact)}${version}`;
  }
  return `pkg:${type}/${encodeURIComponent(row.package)}${version}`;
}

// A component's known vulnerabilities, in CycloneDX's own vulnerability shape,
// so the SBOM is useful on its own rather than needing our findings alongside.
function vulnerabilitiesFor(row) {
  return (row.cves || []).map(cve => ({
    id: cve.id,
    source: { name: 'OSV', url: cve.url || undefined },
    ratings: cve.severity ? [{ severity: String(cve.severity).toLowerCase() }] : undefined,
    description: cve.summary || undefined,
    affects: [{ ref: purlFor(row) }],
  }));
}

/**
 * Builds a CycloneDX document for one repository from Version Watch rows.
 *
 * @param {Array}  rows        dependency rows
 * @param {string} repository  restricts to components this repository uses
 * @param {object} opts        { generatedAt, appVersion }
 */
function buildSbom(rows, repository, { generatedAt = Date.now(), appVersion = null, resolved = null } = {}) {
  // Prefer the resolved dependency tree. It is the accurate component list —
  // transitive artifacts included — and it carries licences, which is the whole
  // reason an SBOM gets requested. Version Watch rows are the fallback for a
  // repository no SCA scanner could resolve.
  const mine = resolved && resolved.length
    ? resolved.map(d => ({
        ecosystem: d.ecosystem,
        package: d.name,
        versionInUse: d.version,
        licenses: d.licenses || [],
        cves: [],
      }))
    : (rows || []).filter(r => (r.usedBy || []).includes(repository));

  const components = mine.map(row => {
    const component = {
      type: 'library',
      'bom-ref': purlFor(row),
      name: row.package,
      version: row.versionInUse || 'unknown',
      purl: purlFor(row),
      // The ecosystem is recorded as a property rather than squeezed into a
      // CycloneDX field that does not mean quite the same thing.
      properties: [{ name: 'oasis:ecosystem', value: String(row.ecosystem || 'unknown') }],
    };

    // CycloneDX takes either an SPDX id or a free-text name. The normalised id
    // is used when we recognise the licence, and the declared text is kept
    // alongside it — an auditor needs to see what the package actually said.
    const licenses = (row.licenses || []).filter(Boolean);
    if (licenses.length) {
      component.licenses = licenses.map(text => {
        const spdx = normaliseLicense(text);
        return spdx && spdx !== 'PROPRIETARY'
          ? { license: { id: spdx, name: text !== spdx ? text : undefined } }
          : { license: { name: text } };
      });
    }
    if (row.manifest) {
      component.properties.push({ name: 'oasis:manifest', value: String(row.manifest) });
    }
    if (row.latestVersion) {
      component.properties.push({ name: 'oasis:latestVersion', value: String(row.latestVersion) });
    }
    return component;
  });

  const vulnerabilities = mine.flatMap(vulnerabilitiesFor);

  return {
    bomFormat: 'CycloneDX',
    specVersion: SPEC_VERSION,
    version: 1,
    metadata: {
      timestamp: new Date(generatedAt).toISOString(),
      tools: [{ vendor: 'Curriculum Associates', name: 'i-Ready OASIS', version: appVersion || 'unknown' }],
      component: { type: 'application', name: repository, 'bom-ref': `app:${repository}` },
    },
    components,
    ...(vulnerabilities.length ? { vulnerabilities } : {}),
  };
}

function summarise(sbom) {
  const components = sbom.components || [];
  const byEcosystem = {};
  for (const c of components) {
    const eco = (c.properties || []).find(p => p.name === 'oasis:ecosystem');
    const key = eco ? eco.value : 'unknown';
    byEcosystem[key] = (byEcosystem[key] || 0) + 1;
  }
  return {
    components: components.length,
    byEcosystem,
    vulnerabilities: (sbom.vulnerabilities || []).length,
    // Licence coverage is the question procurement actually asks of an SBOM.
    // Populated when the SBOM is built from a resolved tree; zero when it falls
    // back to Version Watch manifests, which carry no licence data.
    withLicenses: components.filter(c => (c.licenses || []).length > 0).length,
  };
}

function createSbomScanner({ loadRows, appVersion = null }) {
  return {
    id: 'BUILTIN_SBOM',
    type: 'SBOM',
    name: 'Built-in SBOM',
    requires: null,

    async isAvailable() {
      // Always available. It has two possible inputs — the resolved dependency
      // tree from this scan, or Version Watch's manifests — and only the scan
      // itself knows which exists. Gating on Version Watch here would skip the
      // SBOM for every Maven-only repository, which is exactly the case the
      // resolved tree now handles best.
      return { available: true, version: 'CycloneDX 1.5', hint: null };
    },

    async scan({ repository, context }) {
      const resolved = (context && context.dependencies) || [];
      // A resolved tree stands on its own; no Version Watch data is needed.
      if (resolved.length) {
        const document = buildSbom([], repository, { appVersion, resolved });
        return {
          findings: [],
          artifacts: [{ kind: 'SBOM', format: FORMAT, repository, summary: summarise(document), document }],
          stats: { ...summarise(document), source: 'resolved dependency tree' },
        };
      }

      const data = await loadRows();
      if (!data || !data.rows) {
        return { findings: [], stats: { skipped: true, reason: 'no Version Watch scan data' } };
      }
      if (!data.rows.some(r => (r.usedBy || []).includes(repository))) {
        return {
          findings: [],
          stats: {
            skipped: true,
            reason: `${repository} was not part of the last Version Watch scan — no components to list`,
          },
        };
      }

      const document = buildSbom(data.rows, repository, { appVersion });
      return {
        // An SBOM is an inventory, not a list of problems.
        findings: [],
        artifacts: [{ kind: 'SBOM', format: FORMAT, repository, summary: summarise(document), document }],
        stats: { ...summarise(document), source: 'Version Watch manifests (no licences)' },
      };
    },
  };
}

module.exports = { createSbomScanner, buildSbom, summarise, purlFor, FORMAT, SPEC_VERSION };