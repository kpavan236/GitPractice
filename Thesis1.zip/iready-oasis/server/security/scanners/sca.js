'use strict';
const { createFinding } = require('../finding');

// SCA — built on Version Watch rather than beside it.
//
// Version Watch already discovers manifests across ~20 ecosystems from the
// GitHub file tree, resolves versions against each registry, and enriches every
// dependency with OSV advisories. That is software composition analysis; it was
// simply presented as an upgrade report rather than a security one.
//
// This adapter re-reads those rows as findings, so the security tab inherits
// every ecosystem Version Watch supports and gains new ones for free. Adding a
// second dependency scanner later (Trivy, osv-scanner) means another adapter
// producing the same shape — and where the two agree on a package and advisory,
// the fingerprint collapses them into one finding with two sources.
//
// Note what this does NOT claim. A vulnerable package being present is not the
// same as the vulnerable code path being used; reachability stays UNKNOWN and
// the risk engine scores it as unknown rather than assuming the worst or the
// best.

// OSV severity words already match our vocabulary once `moderate` is mapped,
// which finding.js handles. Advisories with no severity are common on
// non-GitHub-reviewed entries; those become MEDIUM there, not LOW.
function severityOf(cve) {
  return cve.severity || 'unknown';
}

function titleFor(cve, row) {
  const id = cve.id || 'Advisory';
  return `${id} in ${row.package} ${row.versionInUse}`;
}

/**
 * Converts Version Watch rows into SCA findings.
 *
 * @param {Array}  rows        rows from version-watch/scan.js
 * @param {string} repository  restrict to one repo, or null for all of them
 */
function toFindings(rows, repository = null) {
  const findings = [];

  for (const row of rows || []) {
    const cves = row.cves || [];
    if (!cves.length) continue;

    // A Version Watch row is deduplicated across repositories — one row can be
    // used by several. Security findings are per repository, because a
    // vulnerable package in a production service and in a scratch tool are
    // different problems with different owners.
    const repos = repository ? (row.usedBy || []).filter(r => r === repository) : row.usedBy || [];

    for (const repo of repos) {
      for (const cve of cves) {
        findings.push(
          createFinding({
            type: 'SCA',
            category: 'VULNERABLE_DEPENDENCY',
            severity: severityOf(cve),
            title: titleFor(cve, row),
            description: cve.summary || 'A known vulnerability affects this dependency version.',
            repository: repo,
            // The manifest, when the row records which one it came from.
            file: row.manifest || null,
            cve: cve.id && cve.id.startsWith('CVE-') ? cve.id : null,
            source: 'VERSION_WATCH',
            ruleId: cve.id,
            remediation: row.latestPatchVersion
              ? `Upgrade ${row.package} to ${row.latestPatchVersion} (patch) or ${row.latestVersion} (latest).`
              : row.latestVersion
                ? `Upgrade ${row.package} to ${row.latestVersion}.`
                : 'No fixed version is published yet — track the advisory.',
            evidence: `${row.ecosystem} · ${row.package} ${row.versionInUse} — advisory ${cve.id}`,
            metadata: {
              ecosystem: row.ecosystem,
              packageName: row.package,
              versionInUse: row.versionInUse,
              latestVersion: row.latestVersion || null,
              latestPatchVersion: row.latestPatchVersion || null,
              fixAvailable: Boolean(row.latestPatchVersion || row.latestVersion),
              advisoryUrl: cve.url || null,
              // Reachability analysis does not exist here. Saying so explicitly
              // keeps the risk engine honest — an absent field would be read as
              // a default rather than as "we did not look".
              reachability: 'UNKNOWN',
            },
          })
        );
      }
    }
  }

  return findings;
}

/**
 * The adapter is constructed with a function that returns Version Watch rows,
 * rather than reaching for the cache itself. Keeps this file testable and lets
 * the orchestrator decide whether to reuse the last scan or force a fresh one.
 */
// "2699 dependencies, scanned 3 days ago" beats "2699 dependencies" — the age
// is the part that decides whether to trust the result.
// Accepts epoch millis or an ISO string: the caller normalises, but a second
// caller wiring this up later should not be able to reintroduce "NaN days ago".
function toMillis(value) {
  if (value == null) return null;
  const ms = typeof value === 'number' ? value : new Date(value).getTime();
  return Number.isFinite(ms) ? ms : null;
}

function describeFreshness(data) {
  const count = `${data.rows.length} dependencies`;
  const at = toMillis(data.scannedAt);
  if (!at) return count;
  const days = Math.floor((Date.now() - at) / 86400000);
  if (days <= 0) return `${count}, scanned today`;
  return `${count}, scanned ${days} day${days === 1 ? '' : 's'} ago`;
}

function createScaScanner({ loadRows }) {
  return {
    id: 'VERSION_WATCH',
    type: 'SCA',
    name: 'Version Watch (SCA)',
    requires: null,

    async isAvailable() {
      const data = await loadRows();
      if (!data || !data.rows) {
        return {
          available: false,
          version: null,
          hint: 'Run a Version Watch scan first — the security tab reads its dependency data.',
        };
      }
      return { available: true, version: describeFreshness(data), hint: null };
    },

    async scan({ repository }) {
      const data = await loadRows();
      if (!data || !data.rows) {
        // Not an error: there is simply no dependency data yet. Reporting zero
        // findings here would read as "clean", so the stats say why instead.
        return { findings: [], stats: { skipped: true, reason: 'no Version Watch scan data' } };
      }

      // The critical distinction. Version Watch scans a set of repositories; a
      // repository outside that set has no dependency data at all, and
      // returning an empty finding list would present "never analysed" as
      // "nothing wrong". This repository has to appear in the data before its
      // zero means anything.
      const covered = data.rows.some(r => (r.usedBy || []).includes(repository));
      if (!covered) {
        return {
          findings: [],
          stats: {
            skipped: true,
            reason: `${repository} was not part of the last Version Watch scan — its dependencies have not been analysed`,
          },
        };
      }

      const findings = toFindings(data.rows, repository);
      return {
        findings,
        stats: {
          dependenciesConsidered: data.rows.length,
          vulnerableDependencies: new Set(findings.map(f => f.metadata.packageName)).size,
          // Surfaced so the UI can say how old this is. SCA results are only as
          // current as the dependency scan behind them, and presenting
          // month-old advisories as a fresh result is its own kind of lie.
          dataScannedAt: toMillis(data.scannedAt),
          dataAgeDays: toMillis(data.scannedAt)
            ? Math.floor((Date.now() - toMillis(data.scannedAt)) / 86400000)
            : null,
        },
      };
    },
  };
}

module.exports = { createScaScanner, toFindings };