'use strict';
const fs = require('fs');
const path = require('path');
const { createFinding, severityFromCvss } = require('../finding');
const { relativeToRepo } = require('../paths');
const { parseLockfile, lockfileFor, NO_LOCKFILE_ECOSYSTEMS } = require('../lockfiles');
const { fetchOsvVulnerabilities } = require('../../version-watch/registries/osv');
const { makeThrottle } = require('../../version-watch/scan');
const { walk } = require('./secrets-builtin');
const { chooseGoverning, inventory } = require('../licenses');

// SCA over the resolved dependency tree.
//
// The existing Version Watch adapter reads manifests fetched from GitHub, which
// gives the DECLARED dependencies. This one reads lockfiles from the local
// clone, which gives what the resolver actually installed — including the
// transitive packages that make up most of a real dependency tree and most of
// its vulnerabilities.
//
// Both run. Where they agree on a package and advisory the fingerprint collapses
// them into one finding with two detection sources, which is the correlation
// engine doing its job; where only this one fires, it is almost always a
// transitive dependency the manifest never mentioned.
//
// Advisory lookup reuses version-watch's OSV client deliberately: it carries
// the proxy handling that api.osv.dev needs on a corporate network, and
// reimplementing that here would work on a laptop and fail in the office.

const OSV_CONCURRENCY = 8;

// A large monorepo can resolve to thousands of packages. The cap is reported
// rather than applied silently.
const MAX_DEPENDENCIES = Number(process.env.OASIS_SCA_MAX_PACKAGES) || 4000;

function findLockfiles(repoPath, maxFiles = 20000) {
  const found = [];
  for (const file of walk(repoPath, repoPath, { files: 0, maxFiles })) {
    const handler = lockfileFor(path.basename(file));
    if (handler) found.push({ file, handler });
  }
  return found;
}

// OSV returns a severity word on GitHub-reviewed advisories and a CVSS vector
// on others; either is better than defaulting everything to MEDIUM.
function severityOf(advisory) {
  if (advisory.severity) return advisory.severity;
  const fromCvss = severityFromCvss(advisory.cvss);
  return fromCvss || 'unknown';
}

function toFinding(dep, advisory, repository, manifestPath) {
  const transitive = dep.direct === false;
  const unknownDirectness = dep.direct === null;

  return createFinding({
    type: 'SCA',
    category: 'VULNERABLE_DEPENDENCY',
    severity: severityOf(advisory),
    title: `${advisory.id} in ${dep.name} ${dep.version}`,
    description:
      (advisory.summary || 'A known vulnerability affects this dependency version.') +
      (transitive
        ? ` This is a transitive dependency — it was pulled in by something else, so upgrading it means upgrading whatever requires it.${dep.path ? ` Path: ${dep.path}.` : ''}`
        : ''),
    repository,
    file: manifestPath,
    cve: advisory.id && advisory.id.startsWith('CVE-') ? advisory.id : null,
    source: 'LOCKFILE_SCA',
    ruleId: advisory.id,
    remediation: transitive
      ? `Update the parent that requires ${dep.name}, or add an override/resolution pinning it to a fixed version.`
      : `Upgrade ${dep.name} past the affected range.`,
    evidence: `${dep.ecosystem} · ${dep.name} ${dep.version}${transitive ? ' (transitive)' : ''} — ${advisory.id}`,
    metadata: {
      ecosystem: dep.ecosystem,
      packageName: dep.name,
      versionInUse: dep.version,
      // The distinction the manifest-only scanner could not make.
      transitive,
      directnessKnown: !unknownDirectness,
      dependencyPath: dep.path || null,
      advisoryUrl: advisory.url || null,
      lockfile: manifestPath,
      reachability: 'UNKNOWN',
    },
  });
}

const scanner = {
  id: 'LOCKFILE_SCA',
  type: 'SCA',
  produces: ['SCA', 'LICENSE'],
  name: 'Lockfile SCA + licences',
  requires: null,

  async isAvailable() {
    return { available: true, version: 'built-in · resolved dependency tree', hint: null };
  },

  async scan({ repoPath, repository, httpClient, maxDependencies = MAX_DEPENDENCIES }) {
    if (!fs.existsSync(repoPath)) throw new Error(`Repository path does not exist: ${repoPath}`);

    const lockfiles = findLockfiles(repoPath);

    // No lockfile is not a clean result. A Maven project has no lockfile to
    // read, and reporting zero vulnerable dependencies for it would be exactly
    // the "silence looks like clean" failure this scanner exists to avoid.
    if (!lockfiles.length) {
      return {
        findings: [],
        stats: {
          skipped: true,
          reason:
            'no lockfile found — only the resolved tree can be analysed. ' +
            `Maven and Gradle have no lockfile (${NO_LOCKFILE_ECOSYSTEMS.join(', ')}), so their transitive ` +
            'dependencies are not covered here; Version Watch still reports their declared ones.',
        },
      };
    }

    const dependencies = [];
    const parsed = [];
    const unreadable = [];

    for (const { file, handler } of lockfiles) {
      let text;
      try {
        text = fs.readFileSync(file, 'utf8');
      } catch (_) {
        unreadable.push(relativeToRepo(repoPath, file));
        continue;
      }
      const deps = parseLockfile(path.basename(file), text);
      if (deps === null) {
        unreadable.push(relativeToRepo(repoPath, file));
        continue;
      }
      const rel = relativeToRepo(repoPath, file);
      parsed.push({ lockfile: rel, ecosystem: handler.ecosystem, dependencies: deps.length });
      for (const dep of deps) dependencies.push({ ...dep, lockfile: rel });
    }

    const capped = dependencies.length > maxDependencies;
    const toQuery = capped ? dependencies.slice(0, maxDependencies) : dependencies;

    const throttle = makeThrottle(OSV_CONCURRENCY);
    const findings = [];
    let queried = 0;
    let lookupErrors = 0;

    await Promise.all(
      toQuery.map(dep =>
        throttle(async () => {
          let result;
          try {
            result = await fetchOsvVulnerabilities(dep.ecosystem, dep.name, dep.version, httpClient);
          } catch (e) {
            lookupErrors += 1;
            return;
          }
          queried += 1;
          if (result.error) {
            lookupErrors += 1;
            return;
          }
          for (const advisory of result.cves || []) {
            findings.push(toFinding(dep, advisory, repository, dep.lockfile));
          }
        })
      )
    );

    // npm lockfiles record a licence per package when the publisher set one.
    // Absent is "not stated in the lockfile", never "no licence".
    const withLicenses = dependencies.filter(d => (d.licenses || []).length);
    const licenseInventory = inventory(withLicenses);
    for (const dep of withLicenses) {
      const governing = chooseGoverning(dep.licenses);
      if (governing.action === 'allow') continue;
      findings.push(
        createFinding({
          type: 'LICENSE',
          category: `LICENSE_${governing.category.toUpperCase().replace(/-/g, '_')}`,
          severity: governing.severity || 'INFO',
          title: `${governing.spdx || 'Unknown licence'} — ${dep.name}`,
          description:
            `${dep.name} ${dep.version} is licensed under ${governing.spdx || 'an unidentified licence'}. ` +
            `${governing.reason || ''} Whether that is acceptable depends on distribution, which is a legal question.`,
          repository,
          file: dep.lockfile,
          source: 'LOCKFILE_SCA',
          ruleId: `license-${governing.category}`,
          remediation: 'Have legal review the obligation, or replace the dependency.',
          evidence: `${dep.ecosystem} · ${dep.name} ${dep.version} — ${governing.declared}`,
          metadata: {
            ecosystem: dep.ecosystem,
            packageName: dep.name,
            versionInUse: dep.version,
            license: governing.spdx,
            licenseDeclared: governing.declared,
            licenseCategory: governing.category,
            transitive: dep.direct === false,
            reachability: 'UNKNOWN',
          },
        })
      );
    }

    const transitiveCount = findings.filter(f => f.metadata.transitive).length;

    return {
      findings,
      dependencies: dependencies.map(d => ({
        ecosystem: d.ecosystem, name: d.name, version: d.version,
        licenses: d.licenses || [], direct: d.direct, path: d.path,
      })),
      stats: {
        lockfiles: parsed,
        dependencies: dependencies.length,
        directDependencies: dependencies.filter(d => d.direct === true).length,
        transitiveDependencies: dependencies.filter(d => d.direct === false).length,
        queried,
        // Every one of these is a dependency we could not check. Reported, so a
        // network problem cannot masquerade as a clean tree.
        lookupErrors,
        unreadableLockfiles: unreadable,
        truncated: capped,
        truncatedReason: capped
          ? `only the first ${maxDependencies} of ${dependencies.length} packages were checked`
            + ` — raise OASIS_SCA_MAX_PACKAGES to check them all`
          : null,
        vulnerableTransitive: transitiveCount,
        licenseInventory,
        // Reported so an empty inventory reads as "the lockfile did not say"
        // rather than "everything is permissive".
        licensesStated: withLicenses.length,
      },
    };
  },
};

module.exports = { scanner, findLockfiles, toFinding, MAX_DEPENDENCIES };