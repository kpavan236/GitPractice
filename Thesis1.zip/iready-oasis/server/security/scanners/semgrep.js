'use strict';
const { createFinding } = require('../finding');
const { runTool, toolAvailability } = require('../scanner');

// Semgrep adapter — SAST.
//
// Optional. When Semgrep is not installed the tab still works; this scanner
// reports itself unavailable and the orchestrator skips it, rather than the
// whole scan failing over a missing binary.

// Optional extra. The bundled SAST engine covers this capability on every
// platform, so the hint names installers rather than implying a requirement.
const INSTALL_HINT = 'optional — pipx install semgrep (macOS/Linux/Windows)';

// p/security-audit is a curated security ruleset that runs offline. `auto`
// would pick rules based on the project but needs a Semgrep account for some of
// them, which is a poor default for a tool that must work on a laptop with no
// setup. Override with OASIS_SEMGREP_CONFIG.
const DEFAULT_CONFIG = 'p/security-audit';

// Semgrep puts the CWE in metadata as either a string or a list, and formats it
// as "CWE-89: Improper Neutralization of ...". We want just the identifier.
function extractCwe(metadata = {}) {
  const raw = metadata.cwe;
  const first = Array.isArray(raw) ? raw[0] : raw;
  if (!first) return null;
  const match = /CWE-\d+/i.exec(String(first));
  return match ? match[0].toUpperCase() : null;
}

// check_id looks like "java.lang.security.audit.sqli.jdbc-sqli". The last
// segment is the useful part for a category.
function categoryFrom(checkId) {
  if (!checkId) return 'UNCATEGORISED';
  const tail = String(checkId).split('.').pop();
  return tail.toUpperCase().replace(/[^A-Z0-9]+/g, '_');
}

function toFindings(payload, repository) {
  const results = (payload && payload.results) || [];
  return results.map(r => {
    const extra = r.extra || {};
    const metadata = extra.metadata || {};
    return createFinding({
      type: 'SAST',
      category: categoryFrom(r.check_id),
      severity: extra.severity,
      title: metadata.shortDescription || (extra.message || '').split('\n')[0].slice(0, 140),
      description: extra.message || '',
      repository,
      file: r.path,
      startLine: (r.start && r.start.line) || null,
      endLine: (r.end && r.end.line) || null,
      cwe: extractCwe(metadata),
      source: 'SEMGREP',
      ruleId: r.check_id,
      remediation: metadata.fix || extra.fix || null,
      evidence: extra.lines ? String(extra.lines).trim().slice(0, 500) : null,
      metadata: {
        // The flagged code, normalised into the fingerprint so the finding
        // follows the code when lines shift.
        snippet: extra.lines || null,
        owasp: metadata.owasp || null,
        confidence: metadata.confidence || null,
        references: metadata.references || [],
      },
    });
  });
}

const scanner = {
  id: 'SEMGREP',
  type: 'SAST',
  name: 'Semgrep',
  requires: 'semgrep',

  isAvailable() {
    return toolAvailability('semgrep', ['--version'], INSTALL_HINT);
  },

  async scan({ repoPath, repository, timeoutMs = 600000, env = process.env }) {
    const config = env.OASIS_SEMGREP_CONFIG || DEFAULT_CONFIG;

    const result = await runTool(
      'semgrep',
      ['--config', config, '--json', '--quiet', '--metrics=off', '--timeout', '30', repoPath],
      { cwd: repoPath, timeoutMs }
    );

    if (result.timedOut) {
      throw new Error(`Semgrep timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    if (result.error) {
      throw new Error(`Semgrep could not run: ${result.error}`);
    }

    let payload;
    try {
      payload = JSON.parse(result.stdout);
    } catch (_) {
      // Semgrep writes diagnostics to stderr, so that is where the reason will
      // be. Truncated: it can be extremely long.
      throw new Error(`Semgrep produced unreadable output: ${result.stderr.slice(0, 300)}`);
    }

    return {
      findings: toFindings(payload, repository),
      stats: {
        rulesRun: config,
        // Semgrep reports files it could not parse. Worth surfacing — a scan
        // that skipped half the repository is not a clean scan.
        parseErrors: ((payload.errors || []).length) || 0,
        filesScanned: (payload.paths && payload.paths.scanned && payload.paths.scanned.length) || null,
      },
    };
  },
};

module.exports = { scanner, toFindings, extractCwe, categoryFrom, INSTALL_HINT };