'use strict';
// Moved to oasis-analyzer; this path stays until the import shims are removed.
module.exports = require('oasis-analyzer/src/scanners/iac-policy');
