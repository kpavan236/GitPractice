'use strict';
const express = require('express');
const { createRuleAdminRouter } = require('./rule-admin/routes');
const { localOriginGuard } = require('./local-origin');
const { toSarif } = require('./sarif');
const { readSource } = require('./source');
const { byCategory, summary } = require('./capabilities');
const fs = require('fs');
const path = require('path');

// The security API. Mirrors the shape of the platform spec's REST design
// (/scans, /findings, /findings/:id/suppress, /dashboard, /assets) so that the
// frontend written against it here would keep working if the backend were later
// replaced by the standalone service.

// Rule-server problems are configuration, not crashes: say which, and for
// unsupported rules say exactly which rules. A findings store that cannot be reached
// is a 503 with the reason, never an empty list that would read as "no findings".
const RULE_SERVER_STATUS = { UNSUPPORTED_RULES: 422, UNREACHABLE: 503, NO_RULES: 503, HTTP: 502 };

function sendError(res, err, code = 500) {
  const status = RULE_SERVER_STATUS[err && err.code];
  if (!status) return res.status(code).json({ error: err.message || String(err) });
  return res.status(status).json({ error: err.message, code: err.code, ...(err.rules ? { rules: err.rules } : {}) });
}

/**
 * @param {object} orchestrator
 * @param {function} resolveRepoPath  repository name -> absolute local path, or
 *                                    null if it is not cloned
 */
// The worked example belongs to the RULE, not the finding, so it is looked up
// rather than copied onto every finding — 500 SCA findings do not need 500
// copies of the same two code samples in the store.
//
// Rules live on the rule server, so the example is fetched from it (and
// remembered); a rule the server cannot supply simply has no example.
async function ruleExample(finding, ruleSync) {
  const ruleId = (finding.detections || []).map(d => d.ruleId).find(Boolean);
  if (!ruleId || !ruleSync) return null;

  const rule = await ruleSync.getRule(ruleId);
  if (!rule || !rule.example) return null;

  return {
    ...rule.example,
    language: rule.language,
    // Ingested rules have no hand-written example. Saying which rule set a
    // finding came from lets the UI point at the upstream project instead of
    // inventing an example nobody verified.
    provenance: rule.provenance || null,
  };
}

function createSecurityRouter(orchestrator, { resolveRepoPath, listRepositories = () => [], appVersion = null }) {
  const router = express.Router();

  // First: nothing below is served to a foreign web page, reads included.
  router.use(localOriginGuard);

  // Rules, profiles and which profile each repository uses: forwarded to the rule
  // server (see rule-admin/routes.js for why this is a gateway).
  router.use('/rule-admin', createRuleAdminRouter({
    getClient: () => (orchestrator.ruleSync && orchestrator.ruleSync.client) || null,
    listRepositories,
  }));

  router.get('/scanners', async (_req, res) => {
    try {
      res.json({ scanners: await orchestrator.availability() });
    } catch (e) {
      sendError(res, e);
    }
  });

  // Where the rules come from and what the last sync did. Rules that quietly
  // stopped updating, or a server nobody started, are a silent failure.
  router.get('/rules', (_req, res) => {
    try {
      res.json({
        ...(orchestrator.ruleSync ? orchestrator.ruleSync.status() : { configured: false }),
        // Scans waiting for the rule server, scans it set aside, and whether it is
        // refusing uploads: a queue nobody can see is a finding nobody can find.
        outbox: orchestrator.outboxStatus ? orchestrator.outboxStatus() : null,
      });
    } catch (e) {
      sendError(res, e);
    }
  });

  // Puts scans the server set aside back in the queue and delivers them (after the
  // cause, e.g. a version mismatch, has been fixed).
  router.post('/rules/outbox/retry', async (_req, res) => {
    try {
      res.json(await orchestrator.retryRejected());
    } catch (e) {
      sendError(res, e);
    }
  });

  // The read-only rules view. In legacy mode (OASIS_ENGINE is not "installed") there is no installed release to
  // show, and the answer says so, so the page can keep the rule-server editor.
  router.get('/rules/installed', (req, res) => {
    try {
      if (!orchestrator.rulesView) return res.json({ mode: 'legacy', release: null, updateAvailable: false, updateError: null, rules: [] });
      res.json(orchestrator.rulesView.installed(typeof req.query.project === 'string' ? req.query.project : undefined));
    } catch (e) { sendError(res, e); }
  });

  // Per-project switches: rules a project turns off and severities it changes. Stored on this machine only.
  router.put('/rules/overrides/:project', (req, res) => {
    try {
      if (!orchestrator.rulesView) return res.status(409).json({ error: 'Installed-release mode is not enabled (set OASIS_ENGINE=installed).' });
      res.json(orchestrator.rulesView.setOverrides(req.params.project, req.body));
    } catch (e) {
      if (e && e.status === 400) return res.status(400).json({ error: e.message });
      sendError(res, e);
    }
  });

  router.get('/rules/config', (_req, res) => {
    try {
      const { loadLocalRules } = require('./local-rules');
      const { listLoadedPlugins } = require('./ast/engine');
      const { USER_RULES_DIR } = require('./paths');
      res.json({
        ruleServer: orchestrator.ruleSync ? orchestrator.ruleSync.status() : { configured: false },
        userPacks: loadLocalRules({}).packs,
        grammarPlugins: listLoadedPlugins(),
        userRulesDir: USER_RULES_DIR,
      });
    } catch (e) { sendError(res, e); }
  });

  // What this product does, and what it does not. Served from the register that
  // the test suite verifies, so it cannot overstate the product.
  router.get('/capabilities', (_req, res) => {
    res.json({ summary: summary(), categories: byCategory() });
  });

  router.get('/dashboard', async (_req, res) => {
    try {
      res.json(await orchestrator.dashboard());
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/findings', async (req, res) => {
    try {
      const { repository, type, severity, status, search } = req.query;
      res.json({ findings: await orchestrator.listFindings({ repository, type, severity, status, search }) });
    } catch (e) {
      sendError(res, e);
    }
  });

  // The code around a finding, plus the rule's worked example.
  //
  // One call rather than two: the detail view needs both together, and a second
  // round trip would show the reader a half-drawn panel.
  router.get('/findings/:id/source', async (req, res) => {
    try {
      const finding = await orchestrator.getFinding(req.params.id);
      if (!finding) return res.status(404).json({ error: 'unknown finding' });

      const repoPath = resolveRepoPath(finding.repository);
      // Written out rather than chained: the clever one-liner this replaces
      // evaluated to NaN when the parameter was absent, which silently produced
      // an empty window with no error — the code frame simply did not appear.
      const requested = parseInt(req.query.context, 10);
      const options = Number.isFinite(requested)
        ? { context: Math.min(30, Math.max(0, requested)) }
        : {};

      const source = readSource(finding, repoPath, options);

      res.json({ source, example: await ruleExample(finding, orchestrator.ruleSync) });
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/findings/:id', async (req, res) => {
    try {
      const finding = await orchestrator.getFinding(req.params.id);
      if (!finding) return res.status(404).json({ error: 'No such finding' });
      res.json(finding);
    } catch (e) {
      sendError(res, e);
    }
  });

  // Suppression is a decision with an owner and a reason, never a silent hide.
  // The spec calls for expiry and an audit trail; both are recorded here so the
  // data is right even though the UI for reviewing them is not built yet.
  router.post('/findings/:id/suppress', async (req, res) => {
    const { reason, owner, expiresAt, falsePositive } = req.body || {};
    if (!reason || !String(reason).trim()) {
      return res.status(400).json({ error: 'A reason is required to suppress a finding' });
    }
    try {
      // Awaited: mutations are serialised against in-flight scans, so this
      // resolves once the write has actually landed.
      const updated = await orchestrator.updateFinding(req.params.id, {
        status: falsePositive ? 'FALSE_POSITIVE' : 'SUPPRESSED',
        suppression: {
          reason: String(reason).trim(),
          owner: owner || null,
          expiresAt: expiresAt || null,
          decidedAt: Date.now(),
        },
      });
      if (!updated) return res.status(404).json({ error: 'No such finding' });
      res.json(updated);
    } catch (e) {
      sendError(res, e);
    }
  });

  router.post('/findings/:id/reopen', async (req, res) => {
    try {
      const updated = await orchestrator.updateFinding(req.params.id, { status: 'REOPENED', suppression: null });
      if (!updated) return res.status(404).json({ error: 'No such finding' });
      res.json(updated);
    } catch (e) {
      sendError(res, e);
    }
  });

  // Repositories available to scan — every local clone, with whether each one
  // has been scanned before.
  router.get('/repositories', async (_req, res) => {
    try {
      const scanned = new Set(await orchestrator.scannedRepositories());
      res.json({
        repositories: listRepositories().map(name => ({ name, scanned: scanned.has(name) })),
      });
    } catch (e) {
      sendError(res, e);
    }
  });

  router.post('/scans', async (req, res) => {
    try {
      const { repository, repositories, all, only, baseRef, mode } = req.body || {};

      // Three ways to say what to scan: everything, an explicit list, or one
      // repository (the original single-repo form, still accepted).
      const names = all
        ? listRepositories()
        : Array.isArray(repositories) && repositories.length
          ? repositories
          : repository
            ? [repository]
            : [];

      if (!names.length) {
        return res.status(400).json({ error: 'Select at least one repository, or pass all:true' });
      }

      const targets = [];
      const unavailable = [];
      for (const name of names) {
        const repoPath = resolveRepoPath(name);
        if (repoPath && fs.existsSync(repoPath)) targets.push({ repository: name, repoPath });
        else unavailable.push(name);
      }

      if (!targets.length) {
        return res.status(400).json({
          error: `None of the selected repositories are cloned locally: ${unavailable.join(', ')}`,
        });
      }

      const scan = await orchestrator.startScan({
        targets,
        only: only || null,
        baseRef,
        mode: mode === 'quick' ? 'quick' : 'full',
      });
      // Named rather than dropped: a repository that could not be scanned is
      // not a repository that came back clean.
      res.json({ ...scan, unavailable });
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/scans/:id', (req, res) => {
    const scan = orchestrator.getScan(req.params.id);
    if (!scan) return res.status(404).json({ error: 'No such scan' });
    res.json(scan);
  });

  router.post('/scans/:id/cancel', (req, res) => {
    const scan = orchestrator.cancelScan(req.params.id);
    if (!scan) return res.status(404).json({ error: 'That scan is not running' });
    res.json(scan);
  });

  // Asset criticality: the user telling us what matters. These are the risk
  // factors the platform cannot infer on its own, and without them the risk
  // score runs at low confidence.
  router.get('/assets', (_req, res) => res.json({ assets: orchestrator.getAssets() }));

  router.post('/assets/:repository', async (req, res) => {
    const { criticality, environment, internetFacing, sensitiveData } = req.body || {};
    const CRITICALITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    const ENVIRONMENTS = ['production', 'staging', 'development'];

    if (criticality !== undefined && !CRITICALITIES.includes(criticality)) {
      return res.status(400).json({ error: `criticality must be one of ${CRITICALITIES.join(', ')}` });
    }
    if (environment !== undefined && !ENVIRONMENTS.includes(environment)) {
      return res.status(400).json({ error: `environment must be one of ${ENVIRONMENTS.join(', ')}` });
    }

    const settings = {};
    if (criticality !== undefined) settings.criticality = criticality;
    if (environment !== undefined) settings.environment = environment;
    if (internetFacing !== undefined) settings.internetFacing = Boolean(internetFacing);
    if (sensitiveData !== undefined) settings.sensitiveData = Boolean(sensitiveData);

    try {
      res.json(await orchestrator.setAsset(req.params.repository, settings));
    } catch (e) {
      sendError(res, e);
    }
  });

  // SARIF 2.1.0 — the interchange format GitHub code scanning, GitLab, Azure
  // DevOps and the VS Code viewer all read. `?repository=` narrows it to one
  // repo; `?status=all` includes suppressed findings, which are exported as
  // SARIF suppressions rather than dropped.
  // Baseline: "everything today is known; tell me what arrives next". The
  // mechanism a CI gate needs, and the only realistic path from a large backlog
  // to a green build that still means something.
  // The CI endpoint: one binary answer, and the reasoning behind it.
  //
  // Deliberately a GET with no side effects, so a pipeline can poll it and a
  // human can open it in a browser while arguing about why the build went red.
  // The HTTP STATUS carries the verdict as well as the body — 200 passed, 422
  // blocked — because that is the part a shell script can act on without a JSON
  // parser:
  //
  //   curl -fsS "$OASIS/api/security/gate?repository=$REPO" || exit 1
  router.get('/gate', (req, res) => {
    try {
      const { repository } = req.query;
      const result = orchestrator.gateStatus({ repository });

      if (!result) {
        // No scan means no evidence, and no evidence is not a pass. A pipeline
        // that has never run a scan must not be told its code is clean.
        return res.status(422).json({
          status: 'NOT_EVALUATED',
          blocking: true,
          reason: repository
            ? `no completed scan for ${repository}`
            : 'no completed scan',
        });
      }

      res.status(result.blocking ? 422 : 200).json(result);
    } catch (e) {
      sendError(res, e);
    }
  });

  // What clearing would remove. Read before the confirm step: a destructive
  // action that cannot say what it is about to destroy is one people either
  // avoid or regret.
  router.get('/clear/preview', async (req, res) => {
    try {
      res.json(await orchestrator.clearPreview({ repository: req.query.repository || null }));
    } catch (e) {
      sendError(res, e);
    }
  });

  // Clears findings, for one repository or all of them.
  //
  // `keepSuppressed` defaults to TRUE and must be switched off explicitly.
  // Suppressions are the only thing in a findings list that represents work
  // rather than output, and the default for a destructive action should never
  // be the one that destroys the irreplaceable part.
  router.delete('/findings', async (req, res) => {
    try {
      const removed = await orchestrator.clearFindings({
        repository: req.query.repository || null,
        keepSuppressed: req.query.keepSuppressed !== 'false',
      });
      res.json(removed);
    } catch (e) {
      sendError(res, e);
    }
  });

  // The full wipe, including the trend history and the baseline — the two
  // things a rescan cannot rebuild. A POST rather than a DELETE on some
  // collection, because it is not "delete this thing", it is an action with
  // consequences beyond any one resource.
  router.post('/reset', async (_req, res) => {
    try {
      res.json(await orchestrator.resetSecurity());
    } catch (e) {
      sendError(res, e);
    }
  });

  router.post('/baseline', async (_req, res) => {
    try {
      res.json(await orchestrator.setBaseline());
    } catch (e) {
      sendError(res, e);
    }
  });

  router.delete('/baseline', async (_req, res) => {
    try {
      await orchestrator.clearBaseline();
      res.json({ baseline: null });
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/sarif', async (req, res) => {
    try {
      const { repository, status } = req.query;
      const findings = await orchestrator.listFindings({ repository, status: status || 'active' });
      const sarif = toSarif(findings, { toolVersion: appVersion, repository: repository || null });
      res.setHeader('Content-Disposition', `attachment; filename="oasis-security.sarif"`);
      res.setHeader('Content-Type', 'application/sarif+json');
      res.json(sarif);
    } catch (e) {
      sendError(res, e);
    }
  });

  // The licence inventory a procurement questionnaire or an audit asks for:
  // which licences are in use, on what, and which need a decision.
  // The trend series. Counts over time, so the dashboard can answer "is this
  // getting better" rather than only "how bad is it now".
  router.get('/trends', async (req, res) => {
    try {
      res.json(await orchestrator.trends({ points: Math.min(400, Number(req.query.points) || 30) }));
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/licenses', async (req, res) => {
    try {
      res.json(await orchestrator.licenseInventory({ repository: req.query.repository || null }));
    } catch (e) {
      sendError(res, e);
    }
  });

  router.get('/sbom/:repository', (req, res) => {
    const sbom = orchestrator.getSbom(req.params.repository);
    if (!sbom) return res.status(404).json({ error: 'No SBOM has been generated for that repository' });
    res.setHeader('Content-Disposition', `attachment; filename="${req.params.repository}-sbom.json"`);
    res.json(sbom);
  });

  // GET /settings/:repository  — effective gate + ignore for a repo
  router.get('/settings/:repository', (req, res) => {
    try {
      const repository = decodeURIComponent(req.params.repository);
      const settings = orchestrator.getRepositorySettings(repository);
      res.json(settings);
    } catch (e) { sendError(res, e); }
  });

  // PUT /settings/:repository/gate  — body: { name?, conditions }
  router.put('/settings/:repository/gate', async (req, res) => {
    try {
      const repository = decodeURIComponent(req.params.repository);
      const { name, conditions } = req.body || {};
      if (!Array.isArray(conditions) || !conditions.length) {
        return res.status(400).json({ error: 'conditions array required' });
      }
      await orchestrator.saveGate(repository, { name: name || 'custom', conditions });
      res.json({ ok: true });
    } catch (e) { sendError(res, e); }
  });

  // DELETE /settings/:repository/gate  — revert to YAML/default
  router.delete('/settings/:repository/gate', async (req, res) => {
    try {
      const repository = decodeURIComponent(req.params.repository);
      await orchestrator.clearGate(repository);
      res.json({ ok: true });
    } catch (e) { sendError(res, e); }
  });

  // PUT /settings/:repository/ignore  — body: { rules: string }  (raw text)
  router.put('/settings/:repository/ignore', async (req, res) => {
    try {
      const repository = decodeURIComponent(req.params.repository);
      const { rules } = req.body || {};
      if (typeof rules !== 'string') return res.status(400).json({ error: 'rules string required' });
      await orchestrator.saveIgnoreRules(repository, rules);
      res.json({ ok: true });
    } catch (e) { sendError(res, e); }
  });

  // DELETE /settings/:repository/ignore  — revert to file
  router.delete('/settings/:repository/ignore', async (req, res) => {
    try {
      const repository = decodeURIComponent(req.params.repository);
      await orchestrator.clearIgnoreRules(repository);
      res.json({ ok: true });
    } catch (e) { sendError(res, e); }
  });

  return router;
}

module.exports = { createSecurityRouter };