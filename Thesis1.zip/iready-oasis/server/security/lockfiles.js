'use strict';
const yaml = require('js-yaml');
const { parseToml } = require('../version-watch/parse-toml');

// Lockfile parsers — the fix for the coverage gap that mattered most.
//
// Version Watch reads MANIFESTS: pom.xml, package.json, requirements.txt. A
// manifest lists what a project asked for. A lockfile lists what it actually
// got, including every transitive dependency the resolver pulled in.
//
// That distinction is most of software composition analysis. In a real
// application the large majority of dependencies — and therefore of vulnerable
// dependencies — are transitive. Log4Shell reached most of its victims through
// spring-boot-starter-log4j2, not a direct log4j-core declaration. A scanner
// that reads only manifests would have reported those projects clean.
//
// Every parser returns the same shape:
//   { ecosystem, name, version, direct, path }
//     direct  true | false | null when the file cannot distinguish
//     path    where in the tree it came from, when the format records it
//
// Parsers are pure and take text. Discovery and I/O live in the scanner.

// ── npm ────────────────────────────────────────────────────────────────────

// package-lock.json v2 and v3 (npm 7+) key everything under `packages`, with
// the root project as "" and each installed package as its node_modules path.
// v1 (npm 6) uses a nested `dependencies` tree instead; both are handled
// because plenty of repositories have not regenerated their lockfile.
function parsePackageLock(text) {
  const json = JSON.parse(text);
  const out = [];

  if (json.packages) {
    // The root entry lists what the project itself depends on, which is how a
    // direct dependency is told apart from one that was dragged in.
    const root = json.packages[''] || {};
    const directNames = new Set([
      ...Object.keys(root.dependencies || {}),
      ...Object.keys(root.devDependencies || {}),
      ...Object.keys(root.optionalDependencies || {}),
    ]);

    for (const [pkgPath, meta] of Object.entries(json.packages)) {
      if (!pkgPath || !meta || !meta.version) continue;
      // "node_modules/a/node_modules/b" → "b", nested under a.
      const name = pkgPath.split('node_modules/').pop();
      if (!name) continue;
      out.push({
        ecosystem: 'npm',
        name,
        version: meta.version,
        direct: directNames.has(name) && !pkgPath.slice('node_modules/'.length).includes('node_modules/'),
        path: pkgPath,
        // npm records the licence per package in v2/v3 lockfiles. Not always
        // present, so an empty list means "not stated here", never "none".
        licenses: meta.license ? [meta.license] : [],
      });
    }
    return dedupe(out);
  }

  // v1: walk the nested tree. Top level is direct, anything below is not.
  const walk = (deps, depth, prefix) => {
    for (const [name, meta] of Object.entries(deps || {})) {
      if (!meta || !meta.version) continue;
      out.push({
        ecosystem: 'npm',
        name,
        version: meta.version,
        direct: depth === 0 && !meta.dev ? true : depth === 0,
        path: prefix ? `${prefix} > ${name}` : name,
      });
      if (meta.dependencies) walk(meta.dependencies, depth + 1, prefix ? `${prefix} > ${name}` : name);
    }
  };
  walk(json.dependencies, 0, '');
  return dedupe(out);
}

// yarn.lock v1 is a bespoke text format: one or more descriptor lines, then an
// indented body carrying the resolved version.
function parseYarnLock(text) {
  const out = [];
  const blocks = String(text).split(/\n(?=\S)/);

  for (const block of blocks) {
    const header = block.split('\n')[0];
    if (!header || header.startsWith('#') || header.startsWith('__metadata')) continue;

    const versionMatch = /\n\s+version:?\s+"?([^"\n]+)"?/.exec(block);
    if (!versionMatch) continue;

    // `"@scope/pkg@^1.0.0", "@scope/pkg@^1.2.0":` — the name is everything
    // before the LAST @, so scoped packages survive.
    const descriptor = header.replace(/:$/, '').split(',')[0].trim().replace(/^"|"$/g, '');
    const at = descriptor.lastIndexOf('@');
    const name = at > 0 ? descriptor.slice(0, at) : descriptor;
    if (!name) continue;

    out.push({
      ecosystem: 'npm',
      name,
      version: versionMatch[1].trim(),
      // yarn.lock does not record which entries the project asked for
      // directly; package.json would be needed to tell.
      direct: null,
      path: null,
    });
  }
  return dedupe(out);
}

// pnpm-lock.yaml. Package keys changed format between major versions:
//   v5   /name/1.2.3
//   v6+  /name@1.2.3
function parsePnpmLock(text) {
  const doc = yaml.load(text) || {};
  const out = [];
  const direct = new Set(Object.keys(doc.dependencies || {}).concat(Object.keys(doc.devDependencies || {})));

  for (const key of Object.keys(doc.packages || {})) {
    const stripped = key.replace(/^\//, '').split('(')[0];
    let name;
    let version;

    const atIndex = stripped.lastIndexOf('@');
    if (atIndex > 0) {
      name = stripped.slice(0, atIndex);
      version = stripped.slice(atIndex + 1);
    } else {
      const parts = stripped.split('/');
      version = parts.pop();
      name = parts.join('/');
    }
    if (!name || !version || !/^\d/.test(version)) continue;

    out.push({ ecosystem: 'npm', name, version, direct: direct.has(name), path: key });
  }
  return dedupe(out);
}

// ── Go ─────────────────────────────────────────────────────────────────────

// go.mod marks anything the resolver added rather than the author with
// "// indirect", which is exactly the direct/transitive distinction.
function parseGoMod(text) {
  const out = [];
  let inBlock = false;

  for (const line of String(text).split('\n')) {
    const trimmed = line.trim();
    if (/^require\s*\($/.test(trimmed)) { inBlock = true; continue; }
    if (inBlock && trimmed === ')') { inBlock = false; continue; }

    const single = /^require\s+(\S+)\s+(v\S+)/.exec(trimmed);
    const inside = inBlock ? /^(\S+)\s+(v\S+)/.exec(trimmed) : null;
    const match = single || inside;
    if (!match) continue;

    out.push({
      ecosystem: 'Go',
      name: match[1],
      // OSV records Go versions without the leading "v" (introduced: "1.9.0"),
      // so a query carrying "v1.9.1" fails to match any range and the module
      // comes back falsely clean.
      version: match[2].replace(/^v/, '').replace(/\+incompatible$/, ''),
      direct: !/\/\/\s*indirect/.test(trimmed),
      path: null,
    });
  }
  return dedupe(out);
}

// ── Rust, PHP, Ruby, Python ────────────────────────────────────────────────

function parseCargoLock(text) {
  const doc = parseToml(text) || {};
  const packages = Array.isArray(doc.package) ? doc.package : [];
  return dedupe(
    packages
      .filter(p => p && p.name && p.version)
      // Cargo.lock is a flat resolved set with no root marker, so directness
      // is not recoverable from this file alone.
      .map(p => ({ ecosystem: 'crates.io', name: p.name, version: p.version, direct: null, path: null }))
  );
}

function parseComposerLock(text) {
  const json = JSON.parse(text);
  const out = [];
  for (const [key, isDev] of [['packages', false], ['packages-dev', true]]) {
    for (const p of json[key] || []) {
      if (!p || !p.name || !p.version) continue;
      out.push({
        ecosystem: 'Packagist',
        name: p.name,
        version: String(p.version).replace(/^v/, ''),
        // composer.lock is the fully resolved set; it does not separate the
        // project's own requires from what they pulled in.
        direct: null,
        path: isDev ? 'dev' : null,
      });
    }
  }
  return dedupe(out);
}

// Gemfile.lock: indentation carries the meaning. Four spaces under "specs:" is
// a resolved gem; six spaces is that gem's own dependency.
function parseGemfileLock(text) {
  const out = [];
  let inSpecs = false;

  for (const line of String(text).split('\n')) {
    if (/^\s{2}specs:\s*$/.test(line)) { inSpecs = true; continue; }
    if (/^\S/.test(line)) { inSpecs = false; continue; }
    if (!inSpecs) continue;

    const match = /^\s{4}([A-Za-z0-9_.-]+)\s+\(([^)]+)\)\s*$/.exec(line);
    if (!match) continue;
    out.push({ ecosystem: 'RubyGems', name: match[1], version: match[2], direct: null, path: null });
  }
  return dedupe(out);
}

function parsePipfileLock(text) {
  const json = JSON.parse(text);
  const out = [];
  for (const [section, isDev] of [['default', false], ['develop', true]]) {
    for (const [name, meta] of Object.entries(json[section] || {})) {
      const version = meta && typeof meta.version === 'string' ? meta.version.replace(/^==/, '') : null;
      if (!version) continue;
      out.push({ ecosystem: 'PyPI', name, version, direct: null, path: isDev ? 'dev' : null });
    }
  }
  return dedupe(out);
}

// poetry.lock records the resolved set; category/optional tell dev from main
// but not direct from transitive.
function parsePoetryLock(text) {
  const doc = parseToml(text) || {};
  const packages = Array.isArray(doc.package) ? doc.package : [];
  return dedupe(
    packages
      .filter(p => p && p.name && p.version)
      .map(p => ({ ecosystem: 'PyPI', name: p.name, version: p.version, direct: null, path: null }))
  );
}

// ── Registry ───────────────────────────────────────────────────────────────

// Filename → parser. Matched on basename, so a lockfile in a subdirectory of a
// monorepo is picked up the same as one at the root.
const LOCKFILES = [
  { file: 'package-lock.json', ecosystem: 'npm', parse: parsePackageLock },
  { file: 'npm-shrinkwrap.json', ecosystem: 'npm', parse: parsePackageLock },
  { file: 'yarn.lock', ecosystem: 'npm', parse: parseYarnLock },
  { file: 'pnpm-lock.yaml', ecosystem: 'npm', parse: parsePnpmLock },
  { file: 'go.mod', ecosystem: 'Go', parse: parseGoMod },
  { file: 'Cargo.lock', ecosystem: 'crates.io', parse: parseCargoLock },
  { file: 'composer.lock', ecosystem: 'Packagist', parse: parseComposerLock },
  { file: 'Gemfile.lock', ecosystem: 'RubyGems', parse: parseGemfileLock },
  { file: 'Pipfile.lock', ecosystem: 'PyPI', parse: parsePipfileLock },
  { file: 'poetry.lock', ecosystem: 'PyPI', parse: parsePoetryLock },
];

// Java is the conspicuous absence, and it is not an oversight: Maven has no
// lockfile. `mvn dependency:tree` resolves the closure, and Maven is exactly
// the kind of installed tooling this build cannot assume. Gradle only writes
// gradle.lockfile when dependency locking is explicitly enabled, which is rare.
//
// So for Maven and Gradle, coverage stays at the direct dependencies Version
// Watch reads from pom.xml and build.gradle. The scanner reports that as a
// coverage limitation rather than letting it read as a clean result.
const NO_LOCKFILE_ECOSYSTEMS = ['maven', 'gradle'];

function lockfileFor(basename) {
  return LOCKFILES.find(l => l.file === basename) || null;
}

function parseLockfile(basename, text) {
  const handler = lockfileFor(basename);
  if (!handler) return null;
  try {
    return handler.parse(text);
  } catch (_) {
    // A malformed lockfile is a bad file, not a crashed scan.
    return null;
  }
}

// Same package at the same version from several paths is one dependency.
// Directness is sticky: seen as direct anywhere means direct.
function dedupe(entries) {
  const byKey = new Map();
  for (const entry of entries) {
    if (!entry.name || !entry.version) continue;
    const key = `${entry.ecosystem}|${entry.name}|${entry.version}`;
    const existing = byKey.get(key);
    if (!existing) {
      byKey.set(key, entry);
      continue;
    }
    if (entry.direct === true) existing.direct = true;
    if (!existing.licenses?.length && entry.licenses?.length) existing.licenses = entry.licenses;
  }
  return [...byKey.values()];
}

module.exports = {
  LOCKFILES,
  NO_LOCKFILE_ECOSYSTEMS,
  lockfileFor,
  parseLockfile,
  parsePackageLock,
  parseYarnLock,
  parsePnpmLock,
  parseGoMod,
  parseCargoLock,
  parseComposerLock,
  parseGemfileLock,
  parsePipfileLock,
  parsePoetryLock,
  dedupe,
};