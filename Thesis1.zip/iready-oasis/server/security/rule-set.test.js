'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildRuleSet, cacheVersionFor, NoRulesError } = require('./rule-set');

const server = { version: 'default@4', source: 'rule-server', createdAt: '2026-10-01T00:00:00.000Z',
  rules: [{ id: 'S-1', language: 'text', severity: 'LOW', pattern: 'x', files: ['**'] }] };

const pack = (t, rules) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-rs-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(dir, 'p.json'), JSON.stringify({ rules }));
  return dir;
};
const userRule = { id: 'U-1', language: 'text', severity: 'LOW', pattern: 'y', files: ['**'], fixture: { detect: 'y', clean: 'z' } };

test('no rule set is a loud, typed failure that says what to do', () => {
  assert.throws(() => buildRuleSet({ ruleSet: null, userRulesDir: null, plugins: [] }),
    e => e instanceof NoRulesError && e.code === 'NO_RULES' && /rules service is unreachable/.test(e.message));
});

test('the server\'s rules come first, local rules after, and the server\'s identity is kept', (t) => {
  const rs = buildRuleSet({ ruleSet: server, userRulesDir: pack(t, [userRule]), plugins: [] });
  assert.deepEqual(rs.rules.map(r => r.id), ['S-1', 'U-1']);
  assert.equal(rs.version, 'default@4');
  assert.equal(rs.source, 'rule-server');
  assert.equal(rs.createdAt, server.createdAt);
});

test('the cache version is the server version plus a hash of the local rules', (t) => {
  assert.equal(buildRuleSet({ ruleSet: server, userRulesDir: null, plugins: [] }).cacheVersion, 'default@4:none');
  const withPack = buildRuleSet({ ruleSet: server, userRulesDir: pack(t, [userRule]), plugins: [] }).cacheVersion;
  assert.match(withPack, /^default@4:[0-9a-f]{12}$/);
});

test('the scan cache is also keyed on the oasis release', () => {
  const app = require('../../package.json').version;
  assert.equal(cacheVersionFor({ cacheVersion: 'default@4:none' }), `default@4:none|oasis@${app}`);
  assert.equal(cacheVersionFor(null), `none|oasis@${app}`);
});

test('a rule set with no rules at all is refused, because an empty scan reads as a clean repository', (t) => {
  const empty = { ...server, rules: [], profile: { id: 'default', name: 'Default', version: 1 } };
  assert.throws(() => buildRuleSet({ ruleSet: empty, userRulesDir: null, plugins: [] }),
    e => e instanceof NoRulesError && e.code === 'NO_RULES' && /no active rules/i.test(e.message) && /Default/.test(e.message) && /seed/i.test(e.message));
  // Local rules alone are a legitimate rule set.
  const rs = buildRuleSet({ ruleSet: empty, userRulesDir: pack(t, [userRule]), plugins: [] });
  assert.deepEqual(rs.rules.map(r => r.id), ['U-1']);
});

// ---- installed rules (loader) ----
const { installedLoader, offlineLoader } = require('./test-support/loader');
const { createOverrides } = require('./overrides');
const { detectLanguages, ensureRules } = require('./rule-set');

const GO_RULES = [
  { id: 'go-insecure-skip-verify', language: 'go', severity: 'HIGH', query: 'q' },
  { id: 'go-other', language: 'go', severity: 'LOW', query: 'q' },
];
const PY_RULES = [{ id: 'py-eval', language: 'python', severity: 'HIGH', query: 'q' }];
const languages = (release = 1) => ({ release, languages: { go: { extensions: ['.go'], rules: GO_RULES }, python: { extensions: ['.py'], rules: PY_RULES } } });

const repoWith = (t, files) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-rs-repo-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  for (const f of files) { fs.mkdirSync(path.dirname(path.join(dir, f)), { recursive: true }); fs.writeFileSync(path.join(dir, f), 'x'); }
  return dir;
};

test('the empty-store message is the one the plan specifies', () => {
  assert.equal(new NoRulesError().message, 'No rules installed and the rules service is unreachable. Connect to the network once so the rules can be downloaded, then retry.');
});

test('languages are detected from the repository using the installed packs\' pack.json extensions', async (t) => {
  const loader = await installedLoader(t, languages());
  assert.deepEqual(detectLanguages({ repoPath: repoWith(t, ['a.go', 'sub/b.go']), loader }), ['go']);
  assert.deepEqual(detectLanguages({ repoPath: repoWith(t, ['a.go', 'x.py']), loader }).sort(), ['go', 'python']);
  assert.deepEqual(detectLanguages({ repoPath: repoWith(t, ['a.txt']), loader }), []);
  // an explicit file list (quick scan) wins over the tree
  assert.deepEqual(detectLanguages({ repoPath: repoWith(t, ['a.go', 'x.py']), files: ['x.py'], loader }), ['python']);
  // the analyzer's own extension map still applies
  assert.deepEqual(detectLanguages({ repoPath: repoWith(t, ['A.java']), loader }), ['java']);
});

test('a repository with only .go files gets only the Go rules', async (t) => {
  const loader = await installedLoader(t, languages());
  const rs = buildRuleSet({ loader, languages: ['go'], projectKey: 'org/a', userRulesDir: null, plugins: [] });
  assert.deepEqual(rs.rules.map((r) => r.id), ['go-insecure-skip-verify', 'go-other']);
  assert.equal(rs.version, 'release-1');
  assert.equal(rs.source, 'rules-service');
  assert.deepEqual(rs.rejected, []);
});

test('a project override disables a rule and another changes a severity; other projects are unaffected', async (t) => {
  const loader = await installedLoader(t, languages());
  const overrides = createOverrides({ file: path.join(tmpDirOf(t), 'o.json') });
  overrides.set('org/a', { disabled: ['go-insecure-skip-verify'], severity: { 'go-other': 'CRITICAL' } });
  const a = buildRuleSet({ loader, languages: ['go'], projectKey: 'org/a', overrides, userRulesDir: null, plugins: [] });
  assert.deepEqual(a.rules.map((r) => [r.id, r.severity]), [['go-other', 'CRITICAL']]);
  const b = buildRuleSet({ loader, languages: ['go'], projectKey: 'org/b', overrides, userRulesDir: null, plugins: [] });
  assert.equal(b.rules.length, 2);
});

function tmpDirOf(t) { return require('./test-support/loader').tmpDir(t); }

test('user packs still merge after the installed rules', async (t) => {
  const loader = await installedLoader(t, languages());
  const rs = buildRuleSet({ loader, languages: ['go'], projectKey: 'p', userRulesDir: pack(t, [userRule]), plugins: [] });
  assert.deepEqual(rs.rules.map((r) => r.id), ['go-insecure-skip-verify', 'go-other', 'U-1']);
});

test('a new release changes the cache version, so the per-file scan cache is busted', async (t) => {
  const loader = await installedLoader(t, languages(1));
  const one = buildRuleSet({ loader, languages: ['go'], projectKey: 'p', userRulesDir: null, plugins: [] });
  assert.match(one.cacheVersion, /^release-1:none$/);
  loader.serve(languages(2));
  assert.equal((await loader.update()).status, 'updated');
  const two = buildRuleSet({ loader, languages: ['go'], projectKey: 'p', userRulesDir: null, plugins: [] });
  assert.equal(two.version, 'release-2');
  assert.notEqual(one.cacheVersion, two.cacheVersion);
  assert.notEqual(cacheVersionFor(one), cacheVersionFor(two));
});

test('nothing installed is NO_RULES with the plan message and the loader\'s coded cause kept', async (t) => {
  const loader = offlineLoader(t);
  assert.throws(() => buildRuleSet({ loader, languages: ['go'], projectKey: 'p', userRulesDir: null, plugins: [] }),
    (e) => e instanceof NoRulesError && e.code === 'NO_RULES' && e.cause.code === 'NO_RULES_INSTALLED' && /Connect to the network once/.test(e.message));
});

test('installed packs that yield no rules at all are refused, not scanned as a clean repository', async (t) => {
  const loader = await installedLoader(t, languages());
  assert.throws(() => buildRuleSet({ loader, languages: ['cobol'], projectKey: 'p', userRulesDir: null, plugins: [] }),
    (e) => e instanceof NoRulesError && /release-1/.test(e.message));
});

test('ensureRules: an installed release is left alone; offline with nothing installed is NO_RULES', async (t) => {
  const loader = await installedLoader(t, languages());
  let updates = 0;
  const spy = { ...loader, update: async () => { updates += 1; return loader.update(); } };
  assert.equal((await ensureRules(spy)).release, 1);
  assert.equal(updates, 0);
  await assert.rejects(ensureRules(offlineLoader(t)), (e) => e.code === 'NO_RULES' && /Connect to the network once/.test(e.message));
});

// ---- always-on packs and extensionless names (fix round 1) ----
const MIXED = {
  release: 1,
  languages: {
    go: { extensions: ['.go'], rules: GO_RULES },
    secrets: { extensions: ['.env', '.pem'], rules: [{ id: 'sec-1', language: 'secrets', severity: 'HIGH' }] },
    iac: { extensions: ['.tf'], rules: [{ id: 'iac-1', language: 'iac', severity: 'HIGH' }] },
    dockerfile: { extensions: ['.dockerfile'], rules: [{ id: 'docker-1', language: 'dockerfile', severity: 'LOW' }] },
    groovy: { extensions: ['.groovy'], rules: [{ id: 'groovy-1', language: 'groovy', severity: 'LOW' }] },
  },
};

test('secrets and iac packs are always included, even in a Go-only repository', async (t) => {
  const loader = await installedLoader(t, MIXED);
  const rs = buildRuleSet({ loader, languages: detectLanguages({ repoPath: repoWith(t, ['main.go']), loader }), projectKey: 'p', userRulesDir: null, plugins: [] });
  assert.deepEqual(rs.rules.map((r) => r.id).sort(), ['go-insecure-skip-verify', 'go-other', 'iac-1', 'sec-1']);
});

test('extensionless names select their pack: Dockerfile, Dockerfile.prod, Jenkinsfile, .env', async (t) => {
  const loader = await installedLoader(t, MIXED);
  const detect = (files) => detectLanguages({ repoPath: repoWith(t, []), files, loader }).sort();
  assert.deepEqual(detect(['Dockerfile']), ['dockerfile']);
  assert.deepEqual(detect(['svc/Dockerfile.prod']), ['dockerfile']);
  assert.deepEqual(detect(['ci/Jenkinsfile']), ['groovy']);
  assert.deepEqual(detect(['.env']), ['secrets']);
  assert.deepEqual(detect(['README']), []);
  const rs = buildRuleSet({ loader, languages: detect(['Dockerfile']), projectKey: 'p', userRulesDir: null, plugins: [] });
  assert.ok(rs.rules.some((r) => r.id === 'docker-1'));
});

test('a pinned release is used as given, even if a newer one has been installed since', async (t) => {
  const loader = await installedLoader(t, MIXED);
  const pinned = loader.current();
  loader.serve({ ...MIXED, release: 2 });
  assert.equal((await loader.update()).status, 'updated');
  const rs = buildRuleSet({ loader, release: pinned, languages: ['go'], projectKey: 'p', userRulesDir: null, plugins: [] });
  assert.equal(rs.version, 'release-1');
});

test('noRulesFrom names a development signing key in use and explains a dev key file error', () => {
  const { noRulesFrom } = require('./rule-set');
  const plain = noRulesFrom(null, { devKeys: () => [] });
  assert.doesNotMatch(plain.message, /DEV rules signing key/);
  const dev = noRulesFrom(Object.assign(new Error('x is a PRIVATE key'), { code: 'DEV_KEY_PRIVATE' }), { devKeys: () => ['dev-1'] });
  assert.match(dev.message, /DEV_KEY_PRIVATE: x is a PRIVATE key/);
  assert.match(dev.message, /DEV rules signing key in use \(dev-1\): releases are trusted from a local file, not the pinned production keys/);
});

test('an extension that several installed packs claim selects every one of them (.yml, .cls), not just the last', async (t) => {
  const loader = await installedLoader(t, { release: 1, languages: {
    ansible: { extensions: ['.yml'], rules: [{ id: 'a-1', language: 'ansible', severity: 'LOW' }] },
    kubernetes: { extensions: ['.yml', '.yaml'], rules: [{ id: 'k-1', language: 'kubernetes', severity: 'LOW' }] },
    yaml: { extensions: ['.yml'], rules: [{ id: 'y-1', language: 'yaml', severity: 'LOW' }] },
    apex: { extensions: ['.cls'], rules: [{ id: 'ap-1', language: 'apex', severity: 'LOW' }] },
    vb6: { extensions: ['.cls'], rules: [{ id: 'vb-1', language: 'vb6', severity: 'LOW' }] },
  } });
  const detect = (files) => detectLanguages({ repoPath: repoWith(t, []), files, loader }).sort();
  assert.deepEqual(detect(['deploy/app.yml']), ['ansible', 'kubernetes', 'yaml']);
  assert.deepEqual(detect(['deploy/app.yaml']), ['kubernetes']);
  assert.deepEqual(detect(['src/Account.cls']), ['apex', 'vb6']);
});
