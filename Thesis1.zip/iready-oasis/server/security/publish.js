'use strict';
const http = require('http');
const https = require('https');

// Pushes a completed scan to the central platform.
//
// Opt-in, and silent when unconfigured: OASIS is a desktop tool that must work
// with no server at all, so the absence of OASIS_PLATFORM_URL is the normal
// case and not a warning.
//
// The direction is deliberate. The app PUSHES; it never reads through the
// platform. A desktop tool that needed a server to show its own findings would
// have given up the property that makes it useful — that it runs on a laptop on
// a plane — and a push that fails costs nothing, because the findings are
// already stored locally.
//
// FAILURE IS NEVER FATAL. A scan that found things and could not report them
// upstream still found them, and failing the scan over a 502 would teach people
// to turn the integration off.

const TIMEOUT_MS = 30000;

function platformUrl(env = process.env) {
  return env.OASIS_PLATFORM_URL || null;
}

function post(url, body, { token = null, timeoutMs = TIMEOUT_MS } = {}) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const client = target.protocol === 'https:' ? https : http;
    const payload = Buffer.from(JSON.stringify(body), 'utf8');

    const req = client.request(
      target,
      {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'content-length': payload.length,
          'user-agent': 'i-Ready-OASIS',
          ...(token ? { authorization: `Bearer ${token}` } : {}),
        },
      },
      res => {
        let text = '';
        res.setEncoding('utf8');
        res.on('data', c => { text += c; });
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              resolve(JSON.parse(text));
            } catch (_) {
              resolve({});
            }
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${text.slice(0, 200)}`));
          }
        });
      }
    );

    req.setTimeout(timeoutMs, () => req.destroy(new Error('timed out')));
    req.on('error', reject);
    req.end(payload);
  });
}

/**
 * The payload shape the platform expects.
 *
 * Built explicitly rather than by spreading the scan, because two things must
 * NOT travel: anything carrying a credential, and the enormous per-scanner
 * stats blob the platform has no use for. An explicit projection is the only
 * version of this that stays correct as the finding shape grows.
 */
function buildPayload({ repository, scan, findings, coverage, gate, appVersion = null }) {
  return {
    project: { key: repository, name: repository },
    scan: {
      externalId: scan.id,
      status: scan.status,
      trigger: 'MANUAL',
      startedAt: scan.startedAt,
      finishedAt: scan.finishedAt,
      ruleBundleVersion: scan.ruleBundleVersion || null,
      scannerVersion: appVersion,
      ignored: scan.ignored || 0,
      baseCommitSha: scan.baseRef || null,
    },
    coverage,
    gate,
    findings: (findings || []).map(f => ({
      fingerprint: f.fingerprint,
      type: f.type,
      category: f.category,
      severity: f.severity,
      title: f.title,
      description: f.description,
      remediation: f.remediation,
      file: f.file,
      startLine: f.startLine,
      endLine: f.endLine,
      cwe: f.cwe,
      cve: f.cve,
      risk: f.risk,
      isNewCode: Boolean(f.isNewCode),
      detections: (f.detections || []).map(d => ({ source: d.source, ruleId: d.ruleId })),
      // Metadata is filtered, not forwarded. `_plaintext` is already
      // non-enumerable and cannot reach JSON, but `masked` and `secretHash` are
      // the only secret-related fields that SHOULD cross a network boundary,
      // and naming them beats trusting that nothing else ever gets added.
      metadata: {
        masked: f.metadata && f.metadata.masked,
        secretHash: f.metadata && f.metadata.secretHash,
        entropy: f.metadata && f.metadata.entropy,
        owasp: f.metadata && f.metadata.owasp,
        cvssVector: f.metadata && f.metadata.cvssVector,
        knownExploited: f.metadata && f.metadata.knownExploited,
        engine: f.metadata && f.metadata.engine,
      },
    })),
  };
}

/**
 * Publishes one repository's results.
 *
 * @returns {{ published, skipped, error, response }} — never throws.
 */
async function publishScan(
  { repository, scan, findings, coverage, gate, appVersion },
  { env = process.env, send = post, log = () => {} } = {}
) {
  const base = platformUrl(env);
  if (!base) return { published: false, skipped: true, reason: 'no OASIS_PLATFORM_URL configured' };

  const url = `${String(base).replace(/\/+$/, '')}/api/v1/scans`;

  try {
    const response = await send(
      url,
      buildPayload({ repository, scan, findings, coverage, gate, appVersion }),
      { token: env.OASIS_PLATFORM_TOKEN || null }
    );
    log(
      `security: published ${repository} to the platform — `
      + `${response.opened || 0} opened, ${response.resolved || 0} resolved`
    );
    return { published: true, skipped: false, response };
  } catch (e) {
    // Reported, never thrown. The findings are already stored locally; failing
    // the scan over an unreachable server would teach people to switch the
    // integration off.
    log(`security: could not publish ${repository} — ${e.message}`);
    return { published: false, skipped: false, error: e.message };
  }
}

module.exports = { publishScan, buildPayload, platformUrl };
