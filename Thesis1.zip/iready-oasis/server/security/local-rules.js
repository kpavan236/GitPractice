'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Rules that live on THIS machine rather than on the rule server: the user's own
// packs (~/.oasis/security/rules/*.json) and the default rules a grammar plugin
// ships next to its grammar. They are unsigned, so each must carry a fixture
// that proves it detects and stays silent; a pack that fails is reported, never
// thrown. The rule server's own rules are merged with these in rule-set.js.

// A short fingerprint over every user-supplied rule actually loaded (packs and
// plugin rules.json alike). Folded into cacheVersion below so that editing a
// custom rule busts the scan cache the same way a new signed bundle does —
// otherwise a fixed rule can silently keep reporting the old result until an
// unrelated file in the repository changes.
function hashUserRules(rules) {
  if (!rules.length) return 'none';
  return crypto.createHash('sha256').update(JSON.stringify(rules)).digest('hex').slice(0, 12);
}

let _defaultUserRulesDir = null;

function setUserRulesDir(dir) {
  _defaultUserRulesDir = dir;
}

function validateUserRule(rule) {
  if (!rule.id) return 'a rule has no id';
  if (!rule.language) return `${rule.id}: no language`;
  if (!rule.query && !rule.pattern && !rule.definition) return `${rule.id}: no query, pattern or definition`;
  if (!rule.severity) return `${rule.id}: no severity`;
  if (!rule.fixture || typeof rule.fixture.detect !== 'string' || typeof rule.fixture.clean !== 'string') {
    return `${rule.id}: fixture with detect and clean strings is required`;
  }
  return null;
}

/**
 * Reads and validates one rule-pack file — a user's own, or one a grammar
 * plugin ships alongside its `.wasm`. Both are unsigned, both hold the app to
 * the same fixture requirement, and both are reported back the same way: a
 * pack that fails to parse or validate is dropped with an error, never thrown.
 */
function loadRulePackFile(filePath, label) {
  let pack;
  try { pack = JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch (e) { return { rules: [], pack: { name: label, ruleCount: 0, error: `parse error: ${e.message}` } }; }

  if (!pack || !Array.isArray(pack.rules)) {
    return { rules: [], pack: { name: label, ruleCount: 0, error: 'missing rules array' } };
  }

  for (const rule of pack.rules) {
    const err = validateUserRule(rule);
    if (err) return { rules: [], pack: { name: label, ruleCount: 0, error: err } };
  }

  return {
    rules: pack.rules.map(rule => ({ ...rule, source: 'user' })),
    pack: { name: label, ruleCount: pack.rules.length },
  };
}

function loadUserPacks(userRulesDir) {
  if (!userRulesDir) return { rules: [], packs: [] };
  let files;
  try { files = fs.readdirSync(userRulesDir).filter(f => f.endsWith('.json')); }
  catch (_) { return { rules: [], packs: [] }; }

  const rules = [];
  const packs = [];
  for (const file of files) {
    const { rules: r, pack } = loadRulePackFile(path.join(userRulesDir, file), file);
    rules.push(...r);
    packs.push(pack);
  }
  return { rules, packs };
}

// A grammar plugin can ship a rules.json next to its grammar.wasm — default
// rules for the language it adds. Read the same way as a hand-authored user
// pack, and tagged the same `source: 'user'`: both are unsigned and both are
// excluded from the official bundle's rule count for the same reason.
function loadPluginPacks(plugins) {
  const rules = [];
  const packs = [];
  for (const plugin of plugins || []) {
    if (!plugin.rulesFile) continue;
    const { rules: r, pack } = loadRulePackFile(plugin.rulesFile, `${plugin.language}/rules.json`);
    rules.push(...r);
    packs.push(pack);
  }
  return { rules, packs };
}

/**
 * User packs plus grammar-plugin packs, validated.
 *
 * @returns {{ rules: object[], packs: object[], hash: string }} `hash` changes
 *   whenever a local rule does, which is what lets editing a pack bust the scan
 *   cache even though the server's rule set did not change.
 */
function loadLocalRules({ userRulesDir, plugins } = {}) {
  const effectiveDir = userRulesDir !== undefined ? userRulesDir : _defaultUserRulesDir;
  // Lazy: avoids loading the AST engine (and its WASM) when plugins are passed.
  const effectivePlugins = plugins !== undefined ? plugins : require('./ast/engine').listLoadedPlugins();
  const user = loadUserPacks(effectiveDir);
  const fromPlugins = loadPluginPacks(effectivePlugins);
  const rules = [...user.rules, ...fromPlugins.rules];
  return { rules, packs: [...user.packs, ...fromPlugins.packs], hash: hashUserRules(rules) };
}

module.exports = { loadLocalRules, setUserRulesDir };
