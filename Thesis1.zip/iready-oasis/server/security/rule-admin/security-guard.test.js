'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const express = require('express');
const cors = require('cors');
const { createSecurityRouter } = require('../routes');

// oasis answers every origin (`app.use(cors())` in server/index.js), so a web page
// the user happens to visit can call 127.0.0.1 and READ the responses. The Security
// API holds findings, source excerpts and, now, the means to change what gets
// scanned. It answers only the app itself and tools that send no Origin at all.

async function call(method, path, headers = {}) {
  const orchestrator = {
    listFindings: async () => [{ id: 'F1' }], dashboard: async () => ({}), outboxStatus: () => null,
    ruleSync: { status: () => ({}), client: { listProfiles: async () => [{ id: 'default' }] } },
    startScan: async () => ({ id: 'S1' }),
  };
  const app = express();
  app.use(cors());                       // as in server/index.js
  app.use(express.json());
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => ['x'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/api/security${path}`, {
      method, headers: { 'content-type': 'application/json', ...headers }, body: method === 'GET' ? undefined : '{}',
    });
    return { status: res.status, body: await res.json().catch(() => null) };
  } finally {
    server.close();
  }
}

const EVIL = { origin: 'https://evil.example' };

test('a foreign web page can neither read nor change anything', async () => {
  for (const [method, path] of [
    ['GET', '/findings'], ['GET', '/dashboard'], ['GET', '/rule-admin/profiles'],
    ['POST', '/scans'], ['POST', '/rule-admin/rules/test'], ['POST', '/rule-admin/rules'],
    ['PUT', '/rule-admin/profiles/default/rules/R1'], ['DELETE', '/rule-admin/rules/R1'], ['DELETE', '/findings'], ['POST', '/reset'],
  ]) {
    const r = await call(method, path, EVIL);
    assert.equal(r.status, 403, `${method} ${path}`);
    assert.match(r.body.error, /origin/i);
  }
});

test('an opaque or unparseable origin is refused too', async () => {
  assert.equal((await call('GET', '/findings', { origin: 'null' })).status, 403);
  assert.equal((await call('GET', '/findings', { origin: 'not a url' })).status, 403);
});

test('the app itself (any local port) and tools that send no origin are served', async () => {
  for (const origin of ['http://localhost:3000', 'http://127.0.0.1:3917', 'http://[::1]:3000']) {
    assert.equal((await call('GET', '/findings', { origin })).status, 200, origin);
    assert.equal((await call('GET', '/rule-admin/profiles', { origin })).status, 200, origin);
  }
  assert.equal((await call('GET', '/findings')).status, 200, 'curl, CI and the CLI send no Origin');
  assert.equal((await call('POST', '/scans')).status < 500, true);
});
