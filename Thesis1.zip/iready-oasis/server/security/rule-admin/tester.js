'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Worker } = require('worker_threads');
const core = require('./tester-core');

// Tests a rule with the real analyzer, in a worker thread with a time limit.
//
// The rule is supplied by a person (or by whatever can reach the gateway), and its
// regular expression runs in this process. A pattern such as ^(a+)+$ takes minutes
// on a short input and blocks everything while it does. In a worker it can simply
// be stopped, and the answer is "that rule is too slow", which is true: it would
// freeze every scan it ever ran in.

const blank = errors => ({ ok: false, errors, file: null, detect: { found: null }, clean: { found: null } });

function testRule(rule, { tmpRoot = os.tmpdir(), timeoutMs = 15000 } = {}) {
  // A private directory per test, removed afterwards even if the worker is killed.
  const root = fs.mkdtempSync(path.join(tmpRoot, 'oasis-rule-test-'));
  return new Promise(resolve => {
    const worker = new Worker(path.join(__dirname, 'tester-worker.js'), { workerData: { rule, tmpRoot: root } });
    let done = false;
    const finish = report => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      worker.terminate().catch(() => {});
      fs.rmSync(root, { recursive: true, force: true });
      resolve(report);
    };
    const timer = setTimeout(() => finish(blank([
      `the rule took too long to run (over ${Math.round(timeoutMs / 1000)}s). A pattern that backtracks catastrophically would freeze every scan it ran in; simplify the pattern`,
    ])), timeoutMs);
    worker.once('message', finish);
    worker.once('error', e => finish(blank([`the test could not run: ${e.message}`])));
  });
}

module.exports = { testRule, sampleFileName: core.sampleFileName };
