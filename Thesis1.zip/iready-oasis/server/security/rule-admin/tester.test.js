'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { testRule, sampleFileName } = require('./tester');

const pattern = (extra = {}) => ({
  id: 'T-1', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'], title: 'eval',
  fixture: { detect: 'eval(x);', clean: 'run(x);' }, ...extra,
});
const ast = (extra = {}) => ({
  id: 'T-AST', language: 'javascript', severity: 'HIGH', title: 'eval', category: 'INJECTION',
  query: '(call_expression function: (identifier) @f (#eq? @f "eval")) @sink',
  fixture: { detect: 'eval(x);', clean: 'run(x);' }, ...extra,
});

test('a pattern rule that detects its sample and stays silent on the clean one passes', async () => {
  const r = await testRule(pattern());
  assert.deepEqual([r.ok, r.detect.found, r.clean.found, r.errors], [true, 1, 0, []]);
  assert.equal(r.file, 'sample.js');
});

test('a syntax-tree rule passes the same way, for each supported language', async () => {
  assert.equal((await testRule(ast())).ok, true);
  const java = ast({ id: 'T-J', language: 'java', query: '(method_invocation name: (identifier) @n (#eq? @n "exec")) @sink', fixture: { detect: 'class A { void f() { rt.exec(c); } }', clean: 'class A { void f() { rt.run(c); } }' } });
  assert.equal((await testRule(java)).ok, true);
  const py = ast({ id: 'T-P', language: 'python', query: '(call function: (identifier) @f (#eq? @f "eval")) @sink', fixture: { detect: 'eval(x)', clean: 'run(x)' } });
  assert.equal((await testRule(py)).ok, true);
});

test('a rule that misses its own detect sample fails and says so', async () => {
  const r = await testRule(pattern({ fixture: { detect: 'run(x);', clean: 'run(x);' } }));
  assert.equal(r.ok, false);
  assert.equal(r.detect.found, 0);
  assert.ok(r.errors.some(e => /did not fire on the detect sample/i.test(e)), r.errors.join('|'));
});

test('a rule that also fires on its clean sample fails and says so', async () => {
  const r = await testRule(pattern({ fixture: { detect: 'eval(x);', clean: 'eval(y);' } }));
  assert.equal(r.ok, false);
  assert.equal(r.clean.found, 1);
  assert.ok(r.errors.some(e => /fired on the clean sample/i.test(e)));
});

test('compile problems are reported before anything is run', async () => {
  assert.match((await testRule(ast({ query: '(not_a_node @x' }))).errors.join('|'), /query does not compile/i);
  assert.match((await testRule(pattern({ pattern: '(' }))).errors.join('|'), /pattern does not compile/i);
  assert.match((await testRule(pattern({ pattern: 'a*' }))).errors.join('|'), /matches the empty string/i);
  assert.match((await testRule(pattern({ files: undefined }))).errors.join('|'), /files/i);
  assert.match((await testRule(ast({ language: 'cobol' }))).errors.join('|'), /no grammar for cobol/i);
});

test('the samples are required, and a rule with neither query nor pattern is refused', async () => {
  assert.match((await testRule(pattern({ fixture: undefined }))).errors.join('|'), /detect and clean/i);
  assert.match((await testRule(pattern({ fixture: { detect: 'x' } }))).errors.join('|'), /detect and clean/i);
  assert.match((await testRule({ id: 'X', language: 'javascript', severity: 'LOW', fixture: { detect: 'a', clean: 'b' } })).errors.join('|'), /query or a pattern/i);
});

test('the sample file name follows the rule: its example file, its file glob, or its language', () => {
  assert.equal(sampleFileName(pattern({ example: { file: 'Dockerfile' } })), 'Dockerfile');
  assert.equal(sampleFileName(pattern({ files: ['**/Dockerfile'] })), 'Dockerfile');
  assert.equal(sampleFileName(pattern({ files: ['**/*.tf'] })), 'sample.tf');
  assert.equal(sampleFileName(pattern({ files: ['**/*.env*'] })), 'sample.env');
  assert.equal(sampleFileName(ast({ language: 'java' })), 'Sample.java');
  assert.equal(sampleFileName(ast({ language: 'python' })), 'sample.py');
  assert.equal(sampleFileName(ast({ language: 'typescript' })), 'sample.ts');
});

test('a Dockerfile-style pattern rule is tested against a file of the right name', async () => {
  const r = await testRule({ id: 'D-1', language: 'dockerfile', severity: 'LOW', pattern: '^USER\\s+root', files: ['**/Dockerfile'], title: 'root', fixture: { detect: 'FROM a\nUSER root\n', clean: 'FROM a\nUSER app\n' } });
  assert.equal(r.ok, true, r.errors.join('|'));
  assert.equal(r.file, 'Dockerfile');
});

test('testing leaves nothing behind and never needs a repository', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-rule-test-root-'));
  try {
    await testRule(pattern(), { tmpRoot: root });
    await testRule(pattern({ fixture: { detect: 'nope', clean: 'nope' } }), { tmpRoot: root });
    assert.deepEqual(fs.readdirSync(root), []);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test('rule text is never executed or interpreted as markup by the tester', async () => {
  const r = await testRule(pattern({ id: 'X-1', title: '<img src=x onerror=alert(1)>', fixture: { detect: 'eval(x);', clean: 'run(x);' } }));
  assert.equal(r.ok, true);
  assert.equal(JSON.stringify(r).includes('<script'), false);
});

// ── Review fixes: the tester runs rules that people (or web pages) supply ──────

test('a sample file name from the rule can never leave the temp directory', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-rule-test-root-'));
  const outside = path.join(root, 'escaped.js');
  fs.mkdirSync(path.join(root, 'inner'));
  try {
    for (const evil of ['../escaped.js', '../../escaped.js', '/tmp/oasis-abs-escape.js', 'a/../../escaped.js', '..\\escaped.js']) {
      const r = await testRule(pattern({ example: { file: evil } }), { tmpRoot: path.join(root, 'inner') });
      assert.equal(fs.existsSync(outside), false, `${evil} escaped`);
      assert.equal(fs.existsSync('/tmp/oasis-abs-escape.js'), false, `${evil} wrote an absolute path`);
      assert.match(r.file || '', /^[^/\\]+$/, 'the reported name is a bare file name');
    }
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
  assert.equal(sampleFileName(pattern({ example: { file: '../../etc/x.js' } })), 'x.js');
  assert.equal(sampleFileName(pattern({ example: { file: '/abs/Dockerfile' } })), 'Dockerfile');
  assert.equal(sampleFileName(pattern({ example: { file: '..' } })), 'sample.js');
});

test('a rule is a query OR a pattern, so nothing can hide untested behind the half that is tested', async () => {
  const both = ast({ pattern: '.', files: ['**/*.py'] });
  const r = await testRule(both);
  assert.equal(r.ok, false);
  assert.match(r.errors.join('|'), /either a query or a pattern, not both/i);
});

test('only a query or a pattern can be authored here; a policy definition or engine override is refused', async () => {
  assert.match((await testRule(pattern({ definition: { any: true } }))).errors.join('|'), /query or a pattern/i);
  assert.match((await testRule(pattern({ engine: 'iac-policy' }))).errors.join('|'), /query or a pattern/i);
  assert.match((await testRule(pattern({ engine: 'secret' }))).errors.join('|'), /query or a pattern/i);
});

test('patterns are tested the way a scan runs them: case-insensitive unless the rule says otherwise', async () => {
  assert.equal((await testRule(pattern({ pattern: 'EVAL\\(' }))).ok, true, 'a scan matches case-insensitively by default');
  const strict = await testRule(pattern({ pattern: 'EVAL\\(', caseSensitive: true }));
  assert.equal(strict.ok, false);
  assert.match(strict.errors.join('|'), /did not fire/);
});

test('a regex that backtracks catastrophically is stopped, and the server keeps answering', async () => {
  const started = Date.now();
  const r = await testRule(pattern({ pattern: '^(a+)+$', files: ['**/*.js'], fixture: { detect: `${'a'.repeat(40)}!`, clean: 'ok' } }), { timeoutMs: 1500 });
  assert.equal(r.ok, false);
  assert.match(r.errors.join('|'), /took too long/i);
  assert.ok(Date.now() - started < 6000, 'it was cut off, not waited for');
  let ticks = 0;
  const timer = setInterval(() => { ticks += 1; }, 20);
  await testRule(pattern({ pattern: '^(a+)+$', fixture: { detect: `${'a'.repeat(40)}!`, clean: 'ok' } }), { timeoutMs: 1000 });
  clearInterval(timer);
  assert.ok(ticks > 20, 'the event loop stayed free while the rule ran');
});
