'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const analyzer = require('oasis-analyzer');
const engine = require('oasis-analyzer/src/ast/engine');

// The test itself (see tester.js, which runs this in a worker with a time limit).
//
// Proves a rule works before it is saved, with the same analyzer a real scan uses:
// the rule must fire on its "detect" sample and stay silent on its "clean" one. A
// rule that finds nothing looks exactly like a rule that is not there, so this is
// the gate for everything a person writes.

const EXTENSIONS = { javascript: '.js', typescript: '.ts', java: '.java', python: '.py' };

// The name the sample is saved under matters: a line pattern is scoped by a file
// glob, and a tree-sitter grammar is chosen by extension.
// A bare file name from something a person (or a web page) supplied. Anything that
// could name a place outside the sample directory is reduced to its last segment,
// and a name that is nothing (`..`, empty) is dropped.
function bareName(value) {
  const base = String(value || '').split(/[\\/]/).pop();
  return !base || base === '.' || base === '..' ? null : base;
}

function sampleFileName(rule) {
  const given = rule.example && bareName(rule.example.file);
  if (given) return given;
  if (rule.query) return `${rule.language === 'java' ? 'Sample' : 'sample'}${EXTENSIONS[rule.language] || '.txt'}`;
  const glob = Array.isArray(rule.files) ? rule.files[0] : rule.files;
  if (!glob) return 'sample.txt';
  const last = String(glob).split('/').pop();
  if (!/[*?]/.test(last)) return last;                       // 'Dockerfile', '.env', 'pom.xml'
  const named = last.replace(/\*+$/, '').replace(/^\*+/, 'sample').replace(/\*/g, '').replace(/\?/g, 'x');
  return named.includes('.') ? named : `${named || 'sample'}.txt`;   // '*.tf' -> sample.tf, '*.env*' -> sample.env
}

async function compileProblems(rule) {
  const problems = [];
  if (!rule.query && !rule.pattern) problems.push('the rule needs a query or a pattern');
  // One half only: whichever half is not tested would still run in a real scan.
  if (rule.query && rule.pattern) problems.push('a rule is either a query or a pattern, not both');
  if (rule.definition !== undefined || rule.engine !== undefined) {
    problems.push('only a query or a pattern can be authored here (policy definitions and engine overrides cannot)');
  }
  if (rule.query) {
    if (!engine.availableLanguages().includes(rule.language)) {
      problems.push(`no grammar for ${rule.language} (available: ${engine.availableLanguages().join(', ')})`);
    } else if (!(await engine.compileQuery(rule.language, rule.query))) {
      problems.push(`the query does not compile for ${rule.language}`);
    }
  } else if (rule.pattern) {
    if (rule.engine !== 'secret' && (!Array.isArray(rule.files) || !rule.files.length)) problems.push('a line pattern needs files (a glob such as **/*.js) to say where it applies');
    try {
      // Compiled the way a scan compiles it: case-insensitive unless the rule says so.
      const re = new RegExp(rule.pattern, rule.caseSensitive ? '' : 'i');
      if (re.test('')) problems.push('the pattern matches the empty string, so it would fire on every line');
    } catch (e) {
      problems.push(`the pattern does not compile: ${e.message}`);
    }
  }
  return problems;
}

async function runOnce(rule, source, file, tmpRoot) {
  const dir = fs.mkdtempSync(path.join(tmpRoot, 'oasis-rule-test-'));
  try {
    const target = path.resolve(dir, file);
    if (!target.startsWith(path.resolve(dir) + path.sep)) throw new Error('sample file name leaves the sample directory');
    fs.writeFileSync(target, source);
    const ruleSet = { rules: [rule], version: 'rule-test', source: 'rule-test' };
    const { results } = await analyzer.analyze({ repoPath: dir, repository: 'rule-test', dir, ruleSet });
    const errors = [];
    let found = 0;
    for (const [id, r] of results) {
      if (r.error) errors.push(`${id}: ${r.error}`);
      found += (r.findings || []).filter(f => (f.detections || []).some(d => d.ruleId === rule.id)).length;
    }
    return { found, errors };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

/**
 * @returns {Promise<{ ok: boolean, errors: string[], file: string|null,
 *                     detect: { found: number|null }, clean: { found: number|null } }>}
 */
async function testRule(rule, { tmpRoot = os.tmpdir() } = {}) {
  const report = { ok: false, errors: [], file: null, detect: { found: null }, clean: { found: null } };
  const fixture = rule && rule.fixture;
  if (!fixture || typeof fixture.detect !== 'string' || typeof fixture.clean !== 'string' || !fixture.detect.trim()) {
    report.errors.push('a fixture with detect and clean samples is required');
  }
  report.errors.push(...await compileProblems(rule || {}));
  if (report.errors.length) return report;

  const file = sampleFileName(rule);
  report.file = file;
  const detect = await runOnce(rule, fixture.detect, file, tmpRoot);
  const clean = await runOnce(rule, fixture.clean, file, tmpRoot);
  report.detect.found = detect.found;
  report.clean.found = clean.found;
  report.errors.push(...detect.errors, ...clean.errors);
  if (!detect.found) report.errors.push(`the rule did not fire on the detect sample (saved as ${file})`);
  if (clean.found) report.errors.push(`the rule fired on the clean sample (${clean.found} finding${clean.found === 1 ? '' : 's'}); a rule that cannot tell the problem from its fix trains people to ignore it`);
  report.ok = report.errors.length === 0;
  return report;
}

module.exports = { testRule, sampleFileName };
