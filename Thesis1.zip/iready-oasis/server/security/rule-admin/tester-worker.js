'use strict';
const { parentPort, workerData } = require('worker_threads');
const { testRule } = require('./tester-core');

// Runs one rule test off the main thread, so a rule whose regex backtracks
// catastrophically can be stopped without freezing the server.
testRule(workerData.rule, { tmpRoot: workerData.tmpRoot })
  .then(report => parentPort.postMessage(report))
  .catch(e => parentPort.postMessage({ ok: false, errors: [`the test could not run: ${e.message}`], file: null, detect: { found: null }, clean: { found: null } }));
