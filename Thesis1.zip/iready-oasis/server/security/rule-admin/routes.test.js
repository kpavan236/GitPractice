'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const { createRuleAdminRouter } = require('./routes');

const goodRule = () => ({ id: 'U-1', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'], title: 'eval', fixture: { detect: 'eval(x);', clean: 'run(x);' } });
const http = (status, message) => Object.assign(new Error(message), { code: 'HTTP', status });

function fakeClient(overrides = {}) {
  const calls = [];
  const rec = (name, result) => async (...args) => { calls.push([name, ...args]); return typeof result === 'function' ? result(...args) : result; };
  const client = {
    calls,
    listRules: rec('listRules', [{ id: 'R1' }]),
    getRule: rec('getRule', id => ({ id, origin: id.startsWith('U') ? 'user' : 'builtin', body: id.startsWith('U') ? goodRule() : { id, query: '(a)' } })),
    createRule: rec('createRule', (rule, activateIn) => ({ rule: { id: rule.id }, needsScannerValidation: false, activateIn })),
    updateRule: rec('updateRule', (id, patch) => ({ id, ...patch })),
    deprecateRule: rec('deprecateRule', id => ({ id, status: 'DEPRECATED' })),
    listProfiles: rec('listProfiles', [{ id: 'default', name: 'Default' }]),
    createProfile: rec('createProfile', p => p),
    deleteProfile: rec('deleteProfile', id => ({ deleted: id })),
    profileRules: rec('profileRules', { rules: [], counts: {} }),
    setProfileRule: rec('setProfileRule', { id: 'strict' }),
    clearProfileRule: rec('clearProfileRule', { id: 'strict' }),
    listProjects: rec('listProjects', [{ key: 'org-a', name: 'A', profileId: 'strict', profileName: 'Strict' }]),
    assignProject: rec('assignProject', (key, b) => ({ key, ...b })),
    ...overrides,
  };
  return client;
}

async function withRouter(client, fn, options = {}) {
  const app = express();
  app.use(express.json());
  app.use('/rule-admin', createRuleAdminRouter({ getClient: () => client, listRepositories: () => ['org-a', 'org-b'], ...options }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/rule-admin`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  try { await fn(call, client); } finally { server.close(); }
}

test('testing a rule returns the report and never touches the server', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    const ok = await call('POST', '/rules/test', goodRule());
    assert.deepEqual([ok.status, ok.body.ok, ok.body.detect.found, ok.body.clean.found], [200, true, 1, 0]);
    const bad = await call('POST', '/rules/test', { ...goodRule(), fixture: { detect: 'nothing', clean: 'nothing' } });
    assert.deepEqual([bad.status, bad.body.ok], [200, false]);
    assert.deepEqual(client.calls, []);
  });
});

test('a rule that fails its own test cannot be created, whatever the browser sent', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    const r = await call('POST', '/rules', { rule: { ...goodRule(), fixture: { detect: 'nothing', clean: 'nothing' } }, activateIn: ['default'] });
    assert.equal(r.status, 422);
    assert.equal(r.body.report.ok, false);
    assert.match(r.body.error, /failed its test/i);
    assert.deepEqual(client.calls, [], 'nothing was forwarded');
  });
});

test('a rule that passes is forwarded with the profiles to activate it in, and gets an example for the detail view', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    const r = await call('POST', '/rules', { rule: goodRule(), activateIn: ['default', 'strict'] });
    assert.equal(r.status, 201);
    assert.equal(r.body.report.ok, true);
    const [, sent, activateIn] = client.calls.find(c => c[0] === 'createRule');
    assert.deepEqual(activateIn, ['default', 'strict']);
    assert.deepEqual(sent.example, { file: 'sample.js', vulnerable: 'eval(x);', fixed: 'run(x);' });
    assert.equal(sent.id, 'U-1');
  });
});

test('a rule without a body to create is a 400, and a server refusal keeps its status and message', async () => {
  await withRouter(fakeClient({ createRule: async () => { throw http(409, 'rule U-1 already exists'); } }), async (call) => {
    assert.equal((await call('POST', '/rules', {})).status, 400);
    const r = await call('POST', '/rules', { rule: goodRule() });
    assert.deepEqual([r.status, r.body.error], [409, 'rule U-1 already exists']);
  });
});

test('editing a custom rule re-tests the edited rule; a failing edit is refused, a passing one forwarded', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    const bad = await call('PUT', '/rules/U-1', { fixture: { detect: 'nothing', clean: 'nothing' } });
    assert.equal(bad.status, 422);
    assert.equal(client.calls.filter(c => c[0] === 'updateRule').length, 0);
    const ok = await call('PUT', '/rules/U-1', { pattern: 'exec\\(', fixture: { detect: 'exec(x);', clean: 'run(x);' } });
    assert.equal(ok.status, 200);
    // The samples double as the worked example in a finding's detail view, so editing
    // them must update the example too.
    assert.deepEqual(client.calls.find(c => c[0] === 'updateRule').slice(1), ['U-1', {
      pattern: 'exec\\(', fixture: { detect: 'exec(x);', clean: 'run(x);' },
      example: { file: 'sample.js', vulnerable: 'exec(x);', fixed: 'run(x);' },
    }]);
  });
});

test('a built-in rule edit goes straight to the server, which decides what may change', async () => {
  await withRouter(fakeClient({ updateRule: async () => { throw http(400, 'R1 is a built-in rule and read-only'); } }), async (call) => {
    const r = await call('PUT', '/rules/R1', { query: '(x)' });
    assert.deepEqual([r.status, /read-only/.test(r.body.error)], [400, true]);
  });
});

test('rules and profiles are passed through with their filters', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    assert.deepEqual((await call('GET', '/rules?search=sql&language=java')).body, [{ id: 'R1' }]);
    assert.deepEqual(client.calls.find(c => c[0] === 'listRules')[1], { search: 'sql', language: 'java' });
    assert.equal((await call('GET', '/rules/R1')).body.id, 'R1');
    assert.deepEqual((await call('DELETE', '/rules/U-1')).body, { id: 'U-1', status: 'DEPRECATED' });
    assert.equal((await call('GET', '/profiles')).body[0].id, 'default');
    assert.equal((await call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' })).status, 201);
    await call('GET', '/profiles/strict/rules?state=disabled');
    assert.deepEqual(client.calls.find(c => c[0] === 'profileRules').slice(1), ['strict', { state: 'disabled' }]);
    await call('PUT', '/profiles/strict/rules/R1', { enabled: false });
    assert.deepEqual(client.calls.find(c => c[0] === 'setProfileRule').slice(1), ['strict', 'R1', { enabled: false }]);
    await call('DELETE', '/profiles/strict/rules/R1');
    assert.deepEqual(client.calls.find(c => c[0] === 'clearProfileRule').slice(1), ['strict', 'R1']);
  });
});

test('deleting a profile that is in use keeps the server\'s reason and status', async () => {
  await withRouter(fakeClient({ deleteProfile: async () => { throw http(409, '"Strict" is assigned to org-a; assign another profile first'); } }), async (call) => {
    const r = await call('DELETE', '/profiles/strict');
    assert.deepEqual([r.status, /assigned to org-a/.test(r.body.error)], [409, true]);
  });
});

test('assignments list every local repository with the profile it will use, registered or not', async () => {
  await withRouter(fakeClient(), async (call) => {
    const r = await call('GET', '/assignments');
    assert.deepEqual(r.body.assignments, [
      { repository: 'org-a', registered: true, profileId: 'strict', profileName: 'Strict' },
      { repository: 'org-b', registered: false, profileId: null, profileName: 'Default' },
    ]);
    const put = await call('PUT', '/projects/org-b', { profileId: 'strict' });
    assert.equal(put.status, 200);
  });
});

test('an unreachable rule server is a 503 with the reason; no configured server is a 503 that says so', async () => {
  const down = () => { throw Object.assign(new Error('rule server unreachable: refused'), { code: 'UNREACHABLE' }); };
  await withRouter(fakeClient({ listRules: down, listProfiles: down }), async (call) => {
    const r = await call('GET', '/rules');
    assert.deepEqual([r.status, r.body.code], [503, 'UNREACHABLE']);
  });
  await withRouter(null, async (call) => {
    const r = await call('GET', '/profiles');
    assert.deepEqual([r.status, /not configured/.test(r.body.error)], [503, true]);
  });
});

test('the Security router mounts the gateway under /rule-admin and feeds it the orchestrator\'s rule server client', async () => {
  const os = require('os');
  const { createSecurityRouter } = require('../routes');
  const client = fakeClient();
  const orchestrator = { ruleSync: { client, status: () => ({}) }, outboxStatus: () => null };
  const app = express();
  app.use(express.json());
  app.use('/api/security', createSecurityRouter(orchestrator, { resolveRepoPath: () => os.tmpdir(), listRepositories: () => ['org-a'], appVersion: 't' }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  try {
    const base = `http://127.0.0.1:${server.address().port}/api/security/rule-admin`;
    assert.equal((await (await fetch(`${base}/profiles`)).json())[0].id, 'default');
    const a = await (await fetch(`${base}/assignments`)).json();
    assert.equal(a.assignments[0].repository, 'org-a');
  } finally {
    server.close();
  }
});


// ── Review fixes: edits are tested as they will be stored ───────────────────────

test('an edit is tested against a sample file that fits the EDITED rule, not the one saved with the old rule', async () => {
  const stored = { ...goodRule(), example: { file: 'old.js', vulnerable: 'eval(x);', fixed: 'run(x);' } };
  const client = fakeClient({ getRule: async id => ({ id, origin: 'user', body: stored }) });
  await withRouter(client, async (call) => {
    const r = await call('PUT', '/rules/U-1', { files: ['**/*.py'], pattern: 'eval\\(', fixture: { detect: 'eval(x)', clean: 'run(x)' } });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(r.body.report.file, 'sample.py');
    const sent = client.calls.find(c => c[0] === 'updateRule')[2];
    assert.equal(sent.example.file, 'sample.py', 'the stored example follows the edit');
  });
});

test('null in an edit removes that field, in the test and in what is sent', async () => {
  const stored = { id: 'U-1', language: 'javascript', severity: 'HIGH', title: 't', query: '(call_expression function: (identifier) @f (#eq? @f "eval")) @sink', fixture: { detect: 'eval(x);', clean: 'run(x);' }, cwe: 'CWE-95' };
  const client = fakeClient({ getRule: async id => ({ id, origin: 'user', body: stored }) });
  await withRouter(client, async (call) => {
    // Switch from a syntax-tree query to a line pattern: the query must go.
    const r = await call('PUT', '/rules/U-1', { query: null, pattern: 'eval\\(', files: ['**/*.js'], cwe: null });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    const sent = client.calls.find(c => c[0] === 'updateRule')[2];
    assert.equal(sent.query, null);
    assert.equal(sent.cwe, null);
  });
});

test('an edit that leaves both a query and a pattern is refused, so no half goes untested', async () => {
  const client = fakeClient();
  await withRouter(client, async (call) => {
    const r = await call('PUT', '/rules/U-1', { query: '(call_expression) @sink' });   // stored rule has a pattern
    assert.equal(r.status, 422);
    assert.match(r.body.error, /either a query or a pattern/);
    assert.equal(client.calls.filter(c => c[0] === 'updateRule').length, 0);
  });
});

test('a client-supplied worked example is ignored: it is always the tested samples', async () => {
  await withRouter(fakeClient(), async (call, client) => {
    await call('POST', '/rules', { rule: { ...goodRule(), example: { file: '../../x', vulnerable: '<script>', fixed: 'y' } } });
    const sent = client.calls.find(c => c[0] === 'createRule')[1];
    assert.deepEqual(sent.example, { file: 'sample.js', vulnerable: 'eval(x);', fixed: 'run(x);' });
  });
});
