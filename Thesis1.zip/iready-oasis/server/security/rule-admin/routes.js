'use strict';
const express = require('express');
const defaultTester = require('./tester');

// The rules, profiles and assignments screens talk to this, not to the rule server:
// the server is loopback-only without CORS, and its token must never reach a
// browser. The gateway also does the one thing the server cannot, testing a rule
// with the real analyzer, and it makes that test mandatory: a rule that fails it
// is not forwarded, whatever the browser claims to have checked.

const RULE_SERVER_STATUS = { UNSUPPORTED_RULES: 422, UNREACHABLE: 503, NO_RULES: 503 };

function fail(res, e) {
  // The server's own refusals (a profile in use, a built-in rule edit) keep their
  // status and message: they are the answer, not a crash.
  if (e && e.code === 'HTTP' && e.status >= 400 && e.status < 500) {
    return res.status(e.status).json({ error: e.message, code: 'HTTP' });
  }
  const status = RULE_SERVER_STATUS[e && e.code] || (e && e.code === 'HTTP' ? 502 : 500);
  return res.status(status).json({ error: (e && e.message) || String(e), ...(e && e.code ? { code: e.code } : {}) });
}

// A patch value of null means "remove this field".
const compact = rule => Object.fromEntries(Object.entries(rule).filter(([, v]) => v !== null && v !== undefined));

const failedTest = (res, report) =>
  res.status(422).json({ error: `the rule failed its test: ${report.errors.join('; ')}`, report });

function createRuleAdminRouter({ getClient, listRepositories = () => [], tester = defaultTester }) {
  const router = express.Router();

  // One wrapper: resolve the client (or say there is none), run the handler, map errors.
  const route = handler => async (req, res) => {
    try {
      const client = getClient();
      if (!client) return res.status(503).json({ error: 'the rule server is not configured', code: 'NO_RULE_SERVER' });
      await handler(client, req, res);
    } catch (e) {
      fail(res, e);
    }
  };

  // ── Rules ──────────────────────────────────────────────────────────────────
  router.get('/rules', route(async (client, req, res) => res.json(await client.listRules(req.query))));
  router.get('/rules/:id', route(async (client, req, res) => res.json(await client.getRule(req.params.id))));

  // The test run alone: nothing is saved.
  router.post('/rules/test', async (req, res) => {
    try {
      res.json(await tester.testRule(req.body || {}));
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/rules', route(async (client, req, res) => {
    const { rule, activateIn } = req.body || {};
    if (!rule || typeof rule !== 'object') return res.status(400).json({ error: 'send { rule, activateIn }' });
    const { example: _clientExample, ...candidate } = rule;
    const report = await tester.testRule(candidate);
    if (!report.ok) return failedTest(res, report);
    // The samples double as the worked example shown in a finding's detail view. It
    // is always derived from the tested samples, never taken from the request.
    const toSave = { ...candidate, example: { file: report.file, vulnerable: rule.fixture.detect, fixed: rule.fixture.clean } };
    const created = await client.createRule(toSave, Array.isArray(activateIn) ? activateIn : undefined);
    res.status(201).json({ ...created, report });
  }));

  router.put('/rules/:id', route(async (client, req, res) => {
    const patch = req.body || {};
    const current = await client.getRule(req.params.id);
    // Custom rules are re-tested as they would be after the edit. Built-in rules go
    // straight to the server, which allows a default-severity change and nothing more.
    if (current.origin === 'user') {
      // Exactly the rule the server will hold after the edit: `null` removes a field
      // (switching from a query to a pattern drops the query), and the stored example is
      // left out because it belongs to the OLD rule and would pick the wrong sample file.
      const { example: _stale, ...base } = current.body;
      const merged = compact({ ...base, ...patch, id: req.params.id });
      const report = await tester.testRule(merged);
      if (!report.ok) return failedTest(res, report);
      const { example: _ignored, ...clean } = patch;
      const toSave = { ...clean, example: { file: report.file, vulnerable: merged.fixture.detect, fixed: merged.fixture.clean } };
      return res.json({ ...(await client.updateRule(req.params.id, toSave)), report });
    }
    res.json(await client.updateRule(req.params.id, patch));
  }));

  router.delete('/rules/:id', route(async (client, req, res) => res.json(await client.deprecateRule(req.params.id))));

  // ── Profiles ───────────────────────────────────────────────────────────────
  router.get('/profiles', route(async (client, _req, res) => res.json(await client.listProfiles())));
  router.post('/profiles', route(async (client, req, res) => res.status(201).json(await client.createProfile(req.body || {}))));
  router.delete('/profiles/:id', route(async (client, req, res) => res.json(await client.deleteProfile(req.params.id))));
  router.get('/profiles/:id/rules', route(async (client, req, res) => res.json(await client.profileRules(req.params.id, req.query))));
  router.put('/profiles/:id/rules/:ruleId', route(async (client, req, res) =>
    res.json(await client.setProfileRule(req.params.id, req.params.ruleId, req.body || {}))));
  router.delete('/profiles/:id/rules/:ruleId', route(async (client, req, res) =>
    res.json(await client.clearProfileRule(req.params.id, req.params.ruleId))));

  // ── Assignments ────────────────────────────────────────────────────────────
  // Every local repository with the profile it will be scanned with. One the server
  // has never heard of uses Default, and says it is not registered.
  router.get('/assignments', route(async (client, _req, res) => {
    const known = new Map((await client.listProjects()).map(p => [p.key, p]));
    res.json({
      assignments: listRepositories().map(name => {
        const p = known.get(name);
        return { repository: name, registered: !!p, profileId: p ? p.profileId : null, profileName: p ? p.profileName : 'Default' };
      }),
    });
  }));
  router.put('/projects/:key', route(async (client, req, res) => {
    const { name, profileId = null } = req.body || {};
    res.json(await client.assignProject(req.params.key, { name: name || req.params.key, profileId }));
  }));

  return router;
}

module.exports = { createRuleAdminRouter };
