# OASIS Commands

Every command for running, testing, and building OASIS, with the licensing
runtime (§3–10) and the security tab (§14) covered in full.

Run everything from the repo root: `/Users/pkamisetti/dev/projects/iready/iready-oasis`.

---

## 1. Running the app

```bash
# Web app on http://localhost:3000. Licensing is ON by default (see §3);
# OASIS_LICENSE_DISABLED=1 gives the unlicensed internal build.
npm start

# Same thing. `start:web` is an alias kept for the shell scripts.
npm run start:web

# Auto-restarts on file changes. Use while editing server code.
npm run dev

# Desktop app (Electron). The server runs IN-PROCESS on a random port, so any
# env var you set here also reaches the licensing code.
npm run start:desktop

# Equivalent, via the checked-in launcher scripts.
./start-web.sh
./start-desktop.sh

# Run on a different port when 3000 is taken, or to run two copies side by side.
PORT=3999 npm start

# The server binds 127.0.0.1 ONLY. The security API is unauthenticated and
# serves finding locations — including where credentials appear in the codebase
# — so it must not be reachable from the network by default.
#
# Expose it deliberately (a container, a shared box) with OASIS_BIND. Anything
# other than loopback prints a warning at startup.
OASIS_BIND=0.0.0.0 npm start
```

---

## 2. Tests

```bash
# Everything: 903 tests across version-watch, licensing, and security.
npm test

# One subsystem.
node --test "server/licensing/**/*.test.js"
node --test "server/version-watch/**/*.test.js"
node --test "server/security/**/*.test.js"

# One file — fastest loop while editing.
node --test server/licensing/state.test.js

# Only tests whose name matches, e.g. every offline-activation case.
node --test --test-name-pattern="offline" "server/licensing/**/*.test.js"

# Syntax-check the renderer. It is browser JS, so `npm test` never loads it and
# a typo there would otherwise only show up in the browser console.
node --check public/js/modules/license.js
```

---

## 3. Licensing: on by default

Enforcement is **on by default**, so the **Start trial** and **Activate licence**
options are there from the first launch with nothing to configure. With no service
address set, the app looks for the licence service on this computer
(`http://localhost:4020/v1`, oasis-licence-service, kept running by `tools/oasis-services.sh`). If it is
not running, the trial cannot start and the app says it could not reach the licence
service. A build that must run with no licensing at all opts out with
`OASIS_LICENSE_DISABLED=1`.

There are two levels of refusal. **Locked** — no licence and no live trial —
blocks every API route, because unlicensed OASIS runs for a 7-day trial and
then stops. **Licensed but missing a feature** blocks only `/api/version-watch`
or `/api/security`; those two are the only things sold separately, and every
other tab is included in every tier. See `FEATURES` in
`server/licensing/tiers.js`.

```bash
# The default: ON, using the local licence service at http://localhost:4020/v1.
npm start

# ON, pointed at a different licence service. This is how a commercial build runs.
OASIS_LICENSE_URL=https://license.example.com npm start

# OFF, even on a build that has a service URL baked in. Highest precedence.
OASIS_LICENSE_DISABLED=1 npm start

# Persist it instead of retyping. .env is gitignored and loaded before
# licensing initialises. Remember to remove it later — a stale .env silently
# overrides what you type on the command line.
echo 'OASIS_LICENSE_URL=http://localhost:4010' >> .env
```

### Environment variables

| Variable | Meaning |
|---|---|
| `OASIS_LICENSE_URL` | Licence service base URL. Default: `http://localhost:4020/v1` (oasis-licence-service). |
| `OASIS_LICENSE_ENABLED=1` | No longer needed: enforcement is on by default. Still accepted. |
| `OASIS_LICENSE_DISABLED=1` | Turn enforcement off. Beats everything else. |
| `OASIS_LICENSE_PUBLIC_KEY` | A single verification key: PEM text, or a path to one. |
| `OASIS_LICENSE_PUBLIC_KEYS` | A key **set** for rotation: JSON `[{"kid":"…","pem":"…"}]`, or a path to that JSON. |
| `OASIS_LICENSE_PRIVATE_KEY` | Signing key, **dev tools only**. Never needed by the app. |
| `LICENSE_SERVICE_PORT` | Port for the dev licence service (default `4010`). |
| `LICENSE_SERVICE_DB` | Where the dev service keeps its JSON database. |

### Confirming it is on

```bash
# The startup log names the service it will call. A build pointed at the wrong
# host fails identically to a service outage, so check this first.
npm start 2>&1 | grep license:
#   license: enforcement ON, service http://localhost:4020/v1
#   license: trusting 1 signing key(s): dev
#   license: WARNING — using the development verification key. Do not ship this build.

# Any route answers 402 when locked — core included, once the trial is over.
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:3000/api/repos

# On a licence that omits a paid tab, that ONE route answers 403 instead.
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:3000/api/security/findings
```

---

## 3a. The local service stack (licence, support, billing, portal, rules, Studio)

```bash
../oasis-support-portal/scripts/stack.sh init   # once: databases, .env files, signing key
../oasis-support-portal/scripts/stack.sh up     # starts licence, support, portal and now also the billing service (oasis-billing-service, port 4060)
tools/oasis-services.sh install                 # all six as launchd agents (licence 4020, support 4040, billing 4060, portal 4030, rules 5090, studio 4050)
tools/oasis-services.sh status                  # loaded? answering?
tools/oasis-services.sh restart licence         # also start | stop | logs [name] | uninstall
./start-licensed.sh --web                       # the app, enforcement on, trusting the stack's key
bash tools/license-doctor.sh                    # "could not reach the licence service": checks each link
npm run e2e:stack                               # end-to-end check over the real APIs: licensing, seat limit, trial, support actions, invoicing (writes test data locally)
```

Where the app looks for these services: environment variable, then `~/.oasis-services.json` (or `OASIS_SERVICES_CONFIG`), then `config/services.json`, then each module's default (`server/service-config.js`; details in README, "Where OASIS finds the services"). `licence-public.pem` is created by `start-licensed.sh`; on a machine that never ran it: `openssl pkey -in ~/.oasis-local-stack/licence-signing.pem -pubout -out ~/.oasis-local-stack/licence-public.pem`. `tools/oasis-services.sh` writes launchd agents named `com.cainc.oasis.*` under `~/Library/LaunchAgents`.

---

## 4. The legacy dev licence service (port 4010)

A stand-in for the real service, which does not exist yet. **Not** production:
no auth, no database, no payment, and it issues licences to anyone who asks.

```bash
# Terminal 1 — the service.
node tools/license-service-dev.js

# Terminal 2 — OASIS pointed at it.
OASIS_LICENSE_URL=http://localhost:4010 npm start

# On a different port, with its own database (for parallel test runs).
LICENSE_SERVICE_PORT=4011 LICENSE_SERVICE_DB=/tmp/lic-db.json node tools/license-service-dev.js
```

### Licence keys you can activate with

| Key | Tier |
|---|---|
| `OASIS-INDV-0001-0001` | individual, 1 seat — legacy, unlocks nothing now |
| `OASIS-VIEW-0001-0001` | viewer, 10 seats — Version Watch, no Security |
| `OASIS-VWSC-0001-0001` | viewer-security, 10 seats — Version Watch and Security |
| `OASIS-TEAM-0001-0001` | team, 10 seats — legacy, Version Watch only |
| `OASIS-ENTR-0001-0001` | enterprise, unlimited seats |
| `OASIS-TEAM-TINY-0002` | team, **2 seats** — for reaching seat exhaustion |

`samples/README.md` covers all of this plus the enterprise licence *file*, which
activates with no service running at all. Note that only enterprise may activate
from a file — the per-seat tiers are seat-counted, and a file that never contacts
the service has no seat to claim.

### Admin levers

Endpoints a real service would never expose. They exist so you can watch the
app react to revocation and expiry without waiting a year.

```bash
# Revoke a licence. The app locks at its next revalidation.
curl -X POST localhost:4010/admin/revoke \
  -H 'content-type: application/json' \
  -d '{"licenseKey":"OASIS-TEAM-0001-0001"}'

# End a trial early. Use the machine ID shown on the lock screen.
curl -X POST localhost:4010/admin/expire \
  -H 'content-type: application/json' \
  -d '{"machineId":"7606014e477f…"}'

# Expire a paid licence.
curl -X POST localhost:4010/admin/expire \
  -H 'content-type: application/json' \
  -d '{"licenseKey":"OASIS-TEAM-0001-0001"}'

# Wipe everything — all trials become available again.
curl -X POST localhost:4010/admin/reset

# Inspect trials, licences, and seat assignments.
curl -s localhost:4010/admin/state | python3 -m json.tool
```

### The quick way: `./start-dev.sh`

```bash
./start-dev.sh              # web app on http://localhost:3000, with the dev licence service
./start-dev.sh --desktop    # the Electron desktop app instead
./start-dev.sh --fresh      # first wipe the dev licence data and this machine's licence state,
                            # so "Start trial" can be tried again from scratch
npm run start:dev           # the same as ./start-dev.sh  (add `-- --fresh` for options)
```

It starts the dev licence service (`tools/license-service-dev.js`) if one is not already
running, starts the app pointed at it, and on Ctrl+C stops only what it started: a service you
launched yourself keeps running. It refuses, with a plain message, if the app's port or the
service's port is taken by something else, and if the dev signing key is missing. `PORT` and
`LICENSE_SERVICE_PORT` change the ports; `OASIS_LICENSE_DISABLED=1 ./start-dev.sh` runs the app
with no licensing and starts no service. The service's data is `~/.oasis-license-dev/service-db.json`
and its log is `~/.oasis-license-dev/service.log`.

`./start-licensed.sh` (below) is the fuller setup for the separate `oasis-license-service`
project, with shop and Stripe options.

### One command for all of it

`./start-licensed.sh` does the whole setup: starts the dev licence service if it
is not already up, puts the machine into a known licence state, and launches the
app with `OASIS_LICENSE_URL` set. The ordinary launchers (`start-web.sh`,
`start-desktop.sh`) set no licensing environment, which now means enforcement is
on with the default local service; add `OASIS_LICENSE_DISABLED=1` to run them as
the unlicensed internal build.

```bash
./start-licensed.sh                              # desktop, fresh machine
./start-licensed.sh --web                        # web server instead of Electron
./start-licensed.sh --reset --issue viewer-security --web   # typical first run
./start-licensed.sh --state viewer               # skip activation, write a state
./start-licensed.sh --keep                       # keep the stored licence
./start-licensed.sh --legacy                     # use the old bundled dev service
./start-licensed.sh --shop --web                  # buy a licence the way a customer does
./start-licensed.sh --states                     # list the states and exit
```

**`--shop`** is the one to reach for when the question is "does buying actually
work". It configures Price IDs, starts a stand-in Stripe
(`oasis-license-service/tools/stripe-dev.js`), and points the service at it — so
**See plans and pricing** on the lock screen leads to real buttons, a pay page,
a signed webhook, and a key in the log. Without it the pricing page renders every
plan as *"not available"*, because no Stripe Price is configured.

The stand-in signs its webhooks properly, so the service verifies them exactly
as it would in production. It is not a Stripe emulator — it implements creating
a Checkout Session and the events that follow a payment, and nothing else.

It starts the licence service from `../oasis-license-service` (override with
`OASIS_LICENSE_SERVICE_DIR`), waits for it, optionally issues a key, then
launches the app pointed at it. Both processes stop together when you stop the
script. If that repository is not checked out it falls back to the bundled
`tools/license-service-dev.js` and says so.

**`--reset` is usually what you want when checking the trial.** Clearing
`~/.oasis-license.json` is only half of "fresh machine": the service records
which machines have already had a trial — that is what stops a reinstall from
resetting the clock — so a cleared local file still gets *"Your trial has already
ended"* until the service forgets too.

Against the real service, `--reset` deletes its SQLite database, which drops
**issued licence keys as well as trials** — hence `--issue`, which mints a fresh
one and prints it. Pair them: `--reset --issue viewer-security`.

It reuses a licence service that is already running rather than starting a second
one, and only stops the service on exit if it was the one that started it. A
service left running from an earlier session is a stale process holding old code
— the script warns about this, because it is how a tier change appears not to
have taken effect.

---

## 5. Driving the UI into any licence state

Writes a signed entitlement straight into `~/.oasis-license.json`, bypassing the
service. **Reload the app after each one.**

```bash
node tools/license-dev.js states              # list the scenarios
node tools/license-dev.js install <state>     # write one
node tools/license-dev.js show                # what the app currently sees
node tools/license-dev.js clear               # back to unregistered
```

A **locked** state covers the whole app with the lock screen — Home, Local
Repos, Dependency Graph, Docker Services and JIRA included, since those run
unlicensed only for the 7-day trial. An **unlocked** state with a partial
licence keeps the app and drops just the tab that was not bought.

The trial is itself a partial licence: it grants no features, so Version Watch
and Security are absent for its whole 7 days. It evaluates the core product;
the paid tabs are what a licence adds.

| State | What you should see |
|---|---|
| `unregistered` | Lock screen with "Start 7-day free trial" and a key field |
| `trial` | Core tabs only, amber "Trial — 20h left" chip — no Version Watch or Security |
| `trial-ending` | Core tabs only, amber "Trial — 1h left" chip |
| `trial-expired` | Lock screen: "Your trial has ended" |
| `licensed` | Legacy team licence — every tab except Security |
| `individual` | Legacy tier — core tabs only, both paid tabs hidden |
| `viewer` | Core tabs and Version Watch — Security hidden, `/api/security` 403s |
| `viewer-security` | Every tab — the upgrade SKU |
| `enterprise` | Every tab, offline code bound to this machine |
| `grace` | Every tab, amber "Offline — locks in 3d" chip |
| `grace-exhausted` | Lock screen: could not reach the licence service in time |
| `expired` | Lock screen: "Your licence has expired" |
| `revoked` | Lock screen: "Licence revoked" |
| `clock-tampered` | Lock screen: system clock is behind the last verified time |
| `tampered` | Lock screen, red banner: the stored licence failed verification |

### Minting tokens by hand

```bash
# An enterprise offline code bound to THIS machine (the default).
node tools/license-dev.js mint --tier enterprise --offline --days 365

# Bound to some other machine — use it to prove the binding is enforced.
node tools/license-dev.js mint --tier enterprise --offline --machine some-other-id

# A custom feature set, to check what the gate blocks. Only 'version-watch'
# and 'security' mean anything — any other key is dropped as unknown.
node tools/license-dev.js mint --tier team --features version-watch --customer "Acme Ltd"
```

---

## 6. Enterprise offline activation

> **Removed from the app.** The lock screen no longer offers this — it now shows
> start a trial, buy a licence, or enter a key. The API below still works and
> the `enterprise` tier still permits it, so a negotiated air-gapped deal can be
> served with `curl`, but no user will find it on their own.
>
> Kept rather than deleted because it is built and tested, and because losing an
> air-gapped enterprise deal costs more than a dormant code path. Worth noting
> though: OASIS needs GitHub Enterprise to list repositories and falls back to
> api.osv.dev for advisories unless an operator has built an offline mirror, so
> a genuinely air-gapped install gets a much reduced product either way.

The four-step exchange: the air-gapped machine asks, an administrator carries
the request to the portal, and the response code is bound to that one machine.

```bash
# 1. Start from a locked app so the lock screen is showing.
node tools/license-dev.js clear

# 2. In the UI: expand "Enterprise: activate offline" and click
#    "Copy request code".

# 3. Play the administrator — request code in, response code out.
pbpaste | node tools/license-dev.js portal | pbcopy

#    A different licence key:
pbpaste | node tools/license-dev.js portal --key OASIS-ENTR-0001-0001 | pbcopy

# 4. Paste into step 2's box in the UI and click "Activate offline".
```

Doing it entirely from the shell:

```bash
# Fetch the request code this machine would display.
curl -s http://localhost:3000/api/license/offline-request \
  | node -pe 'JSON.parse(require("fs").readFileSync(0,"utf8")).code' > /tmp/req.txt

# Take it to the portal.
OASIS_LICENSE_URL=http://localhost:4010 \
  node tools/license-dev.js portal < /tmp/req.txt > /tmp/resp.txt

# Install it. (Built with node rather than an inline -d string: bash brace-
# expands {"a":1,"b":2} into two words and silently corrupts the JSON.)
node -e 'const fs=require("fs");
  fs.writeFileSync("/tmp/inst.json",
    JSON.stringify({license: fs.readFileSync("/tmp/resp.txt","utf8")}))'
curl -s -X POST -H 'content-type: application/json' --data @/tmp/inst.json \
  http://localhost:3000/api/license/offline
```

Proving the binding — the same code on a different machine must be refused:

```bash
node -e '
const {createLicenseService}=require("./server/licensing/service");
const {trustedKeys}=require("./server/licensing/keys");
const fs=require("fs"),os=require("os"),path=require("path");
const svc=createLicenseService({
  storePath: path.join(fs.mkdtempSync(path.join(os.tmpdir(),"other-")),"l.json"),
  provider:{}, keys:trustedKeys(), machineId:"some-other-laptop"});
try { svc.installOfflineLicense(fs.readFileSync("/tmp/resp.txt","utf8"));
      console.log("ACCEPTED — bug"); }
catch(e){ console.log("refused —", e.message); }'
```

---

## 7. Diagnosing "Could not reach the licence service"

```bash
# Checks each link in the chain and names the broken one: is the dev service
# up, is OASIS up, is licensing enabled, which URL is it calling, can it
# actually complete a trial request.
bash tools/license-doctor.sh

# Non-default ports: <app-port> <service-port>
bash tools/license-doctor.sh 3999 4011
```

The usual cause is starting with `OASIS_LICENSE_ENABLED=1` instead of
`OASIS_LICENSE_URL=…`, which enables enforcement but points at the unreachable
placeholder host.

---

## 8. Signing keys

Only the **public** key is ever in this repo or a build. The private key signs
entitlements on the licence service and belongs in a secret manager — if it
leaks, anyone can mint a perpetual enterprise licence.

```bash
# Generate a production keypair. Write the private half to a secret manager and
# never into this repository.
node -e 'const {generateKeyPair}=require("./server/licensing/token");
  const k=generateKeyPair();
  require("fs").writeFileSync("/tmp/oasis-private.pem",k.privateKey,{mode:0o600});
  console.log(k.publicKey)'

# Generate a local dev pair, if ~/.oasis-license-dev/private.pem is missing.
node -e 'const {generateKeyPair}=require("./server/licensing/token");
  const fs=require("fs"),os=require("os"),p=require("path");
  const d=p.join(os.homedir(),".oasis-license-dev"); fs.mkdirSync(d,{recursive:true});
  const k=generateKeyPair();
  fs.writeFileSync(p.join(d,"private.pem"),k.privateKey,{mode:0o600});
  fs.writeFileSync(p.join(d,"public.pem"),k.publicKey);
  console.log("wrote "+d)'

# Run against a key you generated yourself.
OASIS_LICENSE_ENABLED=1 \
OASIS_LICENSE_PUBLIC_KEY=~/.oasis-license-dev/public.pem npm start

# Key ROTATION: trust two keys at once so licences signed either side of the
# switch keep working. Drop the retired key a release later.
OASIS_LICENSE_PUBLIC_KEYS='[
  {"kid":"2026-01","pem":"-----BEGIN PUBLIC KEY-----\n…\n-----END PUBLIC KEY-----\n"},
  {"kid":"2026-08","pem":"-----BEGIN PUBLIC KEY-----\n…\n-----END PUBLIC KEY-----\n"}
]' OASIS_LICENSE_URL=https://license.example.com npm start

# Or from a file.
OASIS_LICENSE_PUBLIC_KEYS=/etc/oasis/keys.json npm start
```

---

## 9. Inspecting licence state

```bash
# The stored licence. Readable on purpose — nothing in it is secret, and
# deleting it only sends the app back to the service, which returns the
# ORIGINAL trial expiry rather than a fresh one.
cat ~/.oasis-license.json

# What the app makes of it.
curl -s http://localhost:3000/api/license/status | python3 -m json.tool

# The token is JWS: three segments, EdDSA, with a key id.
node -e 'const s=require("./server/licensing/store").load();
  const {peekHeader}=require("./server/licensing/token");
  console.log(s.token.split(".").length,"segments |",JSON.stringify(peekHeader(s.token)))'

# Decode the payload without verifying (diagnostics only — never branch on this).
node -e 'const s=require("./server/licensing/store").load();
  console.log(JSON.parse(Buffer.from(s.token.split(".")[1],"base64url").toString()))'

# This machine's fingerprint. A salted hash — the raw hardware id never leaves
# the device.
node -e 'console.log(require("./server/licensing/fingerprint").machineFingerprint())'

# Start over completely.
rm ~/.oasis-license.json
```

---

## 10. Licence API

`/api/license/*` is never gated — the lock screen has to be able to reach it,
or there would be no way to become licensed.

```bash
BASE=http://localhost:3000

curl -s $BASE/api/license/status            # current state
curl -s $BASE/api/license/tiers             # the tier catalogue
curl -s $BASE/api/license/offline-request   # this machine's request code

curl -s -X POST -H 'content-type: application/json' -d '{}' \
  $BASE/api/license/trial                   # start the 7-day trial

curl -s -X POST -H 'content-type: application/json' \
  -d '{"licenseKey":"OASIS-TEAM-0001-0001"}' \
  $BASE/api/license/activate                # activate with a key

curl -s -X POST -H 'content-type: application/json' -d '{}' \
  $BASE/api/license/revalidate              # force a check now

curl -s -X POST -H 'content-type: application/json' -d '{}' \
  $BASE/api/license/deactivate              # free this seat
```

Status codes: `402` the app is locked — no licence and no live trial · `403`
the licence is valid but does not include that feature · `400` your key was
refused · `503` we could not reach the service.
The last two must never be conflated — telling a customer their key is invalid
during our own outage sends them hunting for a problem that is not theirs.

---

## 11. Security checks

```bash
# alg:none forgery. The algorithm is pinned before any signature work happens,
# so the header cannot talk the verifier out of checking.
node -e 'const {verifyToken}=require("./server/licensing/token");
  const {trustedKeys}=require("./server/licensing/keys");
  const e=o=>Buffer.from(JSON.stringify(o)).toString("base64url"), n=Date.now();
  console.log(verifyToken(
    e({alg:"none",typ:"JWT"})+"."+
    e({licenseId:"free",tier:"enterprise",features:"*",issuedAt:n,exp:n+3e10})+".",
    trustedKeys()))'

# Payload tampering: edit the stored licence to enterprise and watch it fail.
node tools/license-dev.js install tampered && node tools/license-dev.js show

# Clock rollback.
node tools/license-dev.js install clock-tampered && node tools/license-dev.js show

# Trial anti-reset: deleting the local file does NOT buy another trial.
rm ~/.oasis-license.json
curl -s -X POST -H 'content-type: application/json' -d '{}' \
  http://localhost:3000/api/license/trial \
  | node -pe 'JSON.parse(require("fs").readFileSync(0,"utf8")).hoursRemaining'
# → the ORIGINAL hours remaining, not 24
```

---

## 12. Building and releasing

```bash
npm run dist              # current platform
npm run dist:mac          # macOS dmg + zip (signed and notarised)
npm run dist:pkg          # macOS .pkg installer
npm run dist:win          # Windows NSIS installer
npm run dist:win-pkg
npm run publish           # build and push to nexus.cainc.com
npm run install:local     # install the built app locally
```

A commercial build **must** override the development verification key, or the
startup log warns and anyone holding the dev private key can mint themselves a
licence:

```bash
OASIS_LICENSE_PUBLIC_KEY=/path/to/production-public.pem \
OASIS_LICENSE_URL=https://license.your-domain.com \
npm run dist:mac
```

`tools/` is deliberately outside electron-builder's `files` list, so the
licence-minting tools never ship inside the product.

---

## 13. Version Watch

```bash
# Scan dependencies across the org's repos.
curl -s -X POST http://localhost:3000/api/version-watch/scan

curl -s http://localhost:3000/api/version-watch/status
cat ~/.oasis-version-watch.json    # cached results

node --test "server/version-watch/**/*.test.js"
```

The Version Watch **tab is hidden** (`public/index.html`, the `hidden` class on
`#tab-btn-version-watch`). The panel and its routes still work — remove that
class to bring the tab back.

---

## 14. Security tab

Findings are ordered by **risk**, not severity — a HIGH on an internet-facing
production service outranks a CRITICAL in a scratch repository.

Everything below runs with **nothing installed**. Five scanners ship with the
app; three optional external tools are used only if they happen to be present.

### Scanners

```bash
# What is available, and what each one covers.
curl -s http://localhost:3000/api/security/scanners | python3 -m json.tool
```

| Scanner | Type | Needs | Covers |
|---|---|---|---|
| Built-in secret scanner | SECRET | — | Working tree, ~15 provider patterns + entropy |
| Git history secrets | SECRET | `git` (already required) | Every ref, not just HEAD |
| AST SAST (tree-sitter) | SAST | — | 19 rules over a real syntax tree, Java/JS/TS/Python |
| Pattern rules | IAC, SAST | — | 10 line rules over Dockerfile, Terraform, Kubernetes — the file types with no grammar |
| IaC policies (structured) | IAC | — | 44 Checkov graph checks evaluated against parsed Terraform/Kubernetes resources |
| Lockfile SCA + licences | SCA, LICENSE | — | npm, Go, Rust, PHP, Ruby, Python resolved trees |
| Maven SCA + licences | SCA, LICENSE | — | Resolves POMs — transitive Java dependencies |
| Version Watch (SCA) | SCA | — | Declared dependencies across ~20 ecosystems, from the last Version Watch scan |
| Built-in SBOM | SBOM | — | CycloneDX 1.5, with licences |
| SARIF import | CONTAINER, IAC, DAST, CLOUD, API | — | Any tool's SARIF left in `.oasis/sarif/` — Trivy, Checkov, ZAP, Prowler |
| Gitleaks / Semgrep / Syft | — | optional binaries | Second opinions, used when installed |
| ESLint | QUALITY, SAST | optional `eslint` | The repository's own ESLint when it has one; security rules promoted to SAST |

### Scanning

```bash
# Repositories available to scan (every local clone).
curl -s http://localhost:3000/api/security/repositories | python3 -m json.tool

# A selected set. Returns a scan id immediately; scans take minutes, so poll.
curl -s -X POST -H 'content-type: application/json' \
  -d '{"repositories":["iready-core","basalcheck"]}' \
  http://localhost:3000/api/security/scans

# Everything cloned locally. With ~83 repos this runs for a long time.
curl -s -X POST -H 'content-type: application/json' \
  -d '{"all":true}' http://localhost:3000/api/security/scans

# One scanner only, which is how to iterate while developing a rule.
curl -s -X POST -H 'content-type: application/json' \
  -d '{"repositories":["iready-core"],"only":["BUILTIN_SAST"]}' \
  http://localhost:3000/api/security/scans

curl -s http://localhost:3000/api/security/scans/SCAN-abc123 | python3 -m json.tool
```

A scan reports **coverage per repository**. `partial: true` and a scanner
showing `not analysed — <reason>` mean that repository was not cleared — which
is a different statement from "no findings", and the reason it is reported
separately.

### Reading results

```bash
curl -s http://localhost:3000/api/security/findings                    # risk order
curl -s 'http://localhost:3000/api/security/findings?type=LICENSE'     # by type
curl -s 'http://localhost:3000/api/security/findings?status=new'       # since the baseline
curl -s http://localhost:3000/api/security/dashboard                   # counts, top risks, trend
curl -s http://localhost:3000/api/security/trends                      # counts over time
curl -s http://localhost:3000/api/security/licenses                    # licence inventory
```

### Asset context

The risk factors the platform cannot infer. Without them the score runs at low
confidence; setting them rescores that repository immediately.

```bash
curl -s -X POST -H 'content-type: application/json' \
  -d '{"criticality":"CRITICAL","environment":"production","internetFacing":true,"sensitiveData":true}' \
  http://localhost:3000/api/security/assets/iready-core
```

### Controlling noise

Three mechanisms, for three different kinds of "yes, we know".

```bash
# 1. Paths and rules that are permanently uninteresting. Checked into the repo,
#    so the decision is reviewable in a pull request.
cat > .oasis-security-ignore <<'IGN'
src/test/**                        # test fixtures contain deliberate vulnerabilities
java-ssrf: src/legacy/**           # one rule, one path
GENERIC_SECRET_ASSIGNMENT          # one rule, everywhere
IGN

# 2. One reviewed line, with the justification beside the code it excuses.
#    Works with // # -- comment syntax, on the line or the line above.
#    stmt.executeQuery(sql); // oasis:ignore java-sql-injection -- table name is a constant

# 3. Baseline: "everything today is known, tell me what arrives next".
curl -s -X POST http://localhost:3000/api/security/baseline
curl -s 'http://localhost:3000/api/security/findings?status=new'
curl -s -X DELETE http://localhost:3000/api/security/baseline
```

Suppressing a single finding needs a reason — it is a decision with an owner,
not a way to hide a row, and a request without one is refused with 400:

```bash
curl -s -X POST -H 'content-type: application/json' \
  -d '{"reason":"accepted for Q3","owner":"sec-team"}' \
  http://localhost:3000/api/security/findings/F-abc123/suppress
```

### Export

```bash
# SARIF 2.1.0 — GitHub code scanning, GitLab, Azure DevOps, VS Code all read it.
curl -s 'http://localhost:3000/api/security/sarif?repository=iready-core' > oasis.sarif

# CycloneDX SBOM, licences included.
curl -s http://localhost:3000/api/security/sbom/iready-core > sbom.json
```

### Environment variables

| Variable | Meaning |
|---|---|
| `OASIS_MAVEN_REPO` | Maven repository for POM resolution. **Set this to `https://nexus.cainc.com/repository/maven-public` if Maven Central is blocked.** Defaults to Central |
| `OASIS_SECRET_VERIFY=1` | Enable live credential checking. **Off by default** — it transmits a live secret to its own issuer, which is a decision, not a default |
| `OASIS_SEMGREP_CONFIG` | Ruleset for the optional Semgrep adapter |
| `OASIS_SARIF_DIR` | An extra directory of SARIF files to import, in addition to `.oasis/sarif/` in the repository. For CI, where tools write to a workspace artifacts directory beside the checkout |
| `OASIS_RULES_URL` | Override the rule bundle URL. Normally unset: rules are fetched from `<OASIS_LICENSE_URL>/rules/latest`, so the licence host is the only setting. Use this for an air-gapped mirror or to stage rules |
| `OASIS_SCAN_MAX_FILES` | Files a secret/SAST scan will read per repository. Default 20000 |
| `OASIS_HISTORY_MAX_COMMITS` | Commits git-history secret scanning searches back through. Default 500 — **most long-lived repositories hit this**, and a secret committed and later removed is exactly what history scanning is for |
| `OASIS_SCA_MAX_PACKAGES` | Lockfile packages checked against advisories. Default 4000 |
| `OASIS_MAVEN_MAX_ARTIFACTS` | Dependencies the Maven resolver will walk. Default 1500 |
| `OASIS_ENGINE=installed` | Opt in to scanning with the signed rules release installed in `~/.oasis-security/rules` (see "Installed rules releases" in §15). Unset keeps the legacy rule-server path |
| `OASIS_ALLOW_OPEN_NETWORK_ENGINE=1` | Accept a rules engine that cannot be network-isolated (Node before 25 lacks the permission flags). Only used with `OASIS_ENGINE=installed` |
| `OASIS_DEV_RULES_PUBLIC_KEYS=<file>` | DEV ONLY: JSON file `{ "dev-1": "<public key PEM>" }` of extra public keys to trust for `OASIS_ENGINE=installed` (a release signed by a local key). Public Ed25519 keys only; ids already pinned are refused; ignored in a packaged app; the Rules banner says "Development key". See `oasis-rule-studio/docs/E2E.md` |
| `OASIS_RULES_CHANNEL=beta` | Follow the `beta` channel of the rules service instead of `stable`. Only used with `OASIS_ENGINE=installed` |
| `OASIS_RULES_UPDATE=0` | Never check for rule updates — for air-gapped installs. With no `OASIS_LICENSE_URL` set there is no rule host at all, and no check is attempted |
| `OASIS_BIND` | Listen address. Defaults to `127.0.0.1`; see §1 |

`OASIS_LICENSE_PRIVATE_KEY` (§8) belongs to the licensing dev tools, not the
security tab — the app never needs a signing key.

### Optional external scanners

Not required. The bundled scanners cover every capability; these add a second
opinion, and where two scanners agree the correlation engine merges them into
one finding with two detection sources.

```bash
brew install semgrep gitleaks syft         # macOS
# Linux/Windows: see each project's releases page
```

### Storage

```
~/.oasis-security/
  store.json          findings, scans, assets, baseline, trend series (mode 600)
  sbom/               CycloneDX documents per repository
  intel/              CISA KEV + EPSS caches (24h)
  maven-poms/         resolved POMs — immutable, so cached forever
```

**Credentials are never stored.** A secret finding carries a SHA-256 of the
value and a masked preview; the plaintext exists only in memory during the scan
that found it, on a non-enumerable field so `JSON.stringify` cannot reach it.

```bash
node --test "server/security/**/*.test.js"     # ~300 tests
```

---

## 15. SAST rules and the rule bundle

Rules are **data, not code**, and they ship **separately from the app**. Rule
fixes are weekly; installers are not, so a noisy rule would otherwise stay noisy
until the next release.

### Anatomy of a rule

`rules/<language>/<name>.json` — one rule per file, matched against a
tree-sitter **syntax tree** rather than lines of text:

```json
{
  "id": "java-sql-injection",
  "language": "java",
  "severity": "HIGH",
  "confidence": "HIGH",
  "requiresTaint": true,
  "query": "(method_invocation name: (identifier) @sink (#match? @sink \"^(execute|executeQuery)$\") arguments: (argument_list) @args)",
  "cwe": "CWE-89",
  "cvss": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
  "owasp": "A03:2021-Injection",
  "title": "SQL query built from external input",
  "description": "...",
  "remediation": "Use a parameterised query."
}
```

| Field | Effect |
|---|---|
| `query` | tree-sitter query. **Field order must follow the grammar** — `object:` before `name:`, or it will not compile |
| `requiresTaint` | Only report when something attacker-controlled reaches the match |
| `negate` | Regex over the whole file that means the risk was handled (an XXE factory that calls `setFeature`) |
| `requiresContext` | Regex near the match that establishes it matters (a `Random` used for a token, not a retry delay) |
| `confidence` | `LOW` reports one severity band down and says so on the finding |
| `example` | `{ file, vulnerable, fixed }` — **required on authored rules.** Shown in the finding detail view AND executed by the test suite: the vulnerable sample must be detected, the fixed one must not. Documentation that cannot drift, because drift fails the build |

### Pattern rules — the file types with no grammar

Four grammars ship (Java, JavaScript, TypeScript, Python). Dockerfiles,
Terraform, Kubernetes manifests, and CI configuration have none, and a grammar
per config format costs more than it returns. Those get a **line pattern**
instead, run by `scanners/pattern-sast.js`:

```json
{
  "id": "docker-run-as-root",
  "language": "dockerfile",
  "type": "IAC",
  "files": ["**/Dockerfile", "**/Dockerfile.*"],
  "pattern": "^\\s*USER\\s+(root|0)\\s*$",
  "severity": "MEDIUM",
  "confidence": "HIGH",
  "cwe": "CWE-250",
  "title": "Container runs as root",
  "description": "...",
  "remediation": "..."
}
```

| Field | Effect |
|---|---|
| `pattern` | Regex, tested per line. Case-insensitive unless `caseSensitive` is set |
| `files` | **Required.** Globs the rule applies to. A rule without one would run against every file in the repository, so the build rejects it |
| `type` | Finding type — `IAC`, `SAST`, … Defaults to `SAST` |
| `includeComments` | Commented-out lines are skipped by default; set this to match them too |

`negate`, `requiresContext`, and `confidence` behave exactly as they do for AST
rules.

**Use `query`, not `pattern`, for any language with a grammar.** A regex cannot
tell code from a comment or a value from a string that mentions it; that ceiling
is why the AST engine exists. `pattern` is for the formats it cannot reach.

### Managing rules in the Security tab

Open **Security → Rules**. It works like SonarQube's rules and quality profiles:

- **Browse and filter** every rule by language, type, severity and origin, or search its id, title and description. Click one for what it finds, how to fix it, its examples, its CWE/OWASP mapping and where it came from.
- **Quality profiles** decide which rules run and at what severity. Pick a profile at the top; the switch on each row turns a rule on or off *in that profile*, and the rule's drawer changes its severity there. A new profile **inherits** another (default: Default), so it only records what you change, and "Reset to inherited" removes an override. A profile cannot be deleted while it is the default, the parent of another, or assigned to a repository, and the message says which.
- **Repositories…** assigns a profile to each local repository. A repository nobody assigned uses Default. Changes apply from the repository's next scan.
- **Built-in and vendored rules are read-only** (a profile controls whether they run and their severity, never their text). **Your own rules are editable**, and are deprecated instead of deleted so findings that reference them keep a rule to point at.
- **+ Add rule** opens the editor: a line pattern (regular expression + the files it applies to) or a syntax-tree query, a *vulnerable* sample and a *clean* sample, severity, text, and which profiles turn it on. **Test rule** runs both samples through the real analyzer: the rule must fire on the first and stay silent on the second, and its pattern or query must compile. **Save stays disabled until the exact content you are saving has passed**; any later edit takes it away again. The gateway re-runs the test itself, so a rule that fails cannot be saved by any other route either.

Everything here goes through oasis to the rule server (`/api/security/rule-admin/*`); you never talk to the server's port from the browser.

### Installed rules releases (opt-in)

With `OASIS_ENGINE=installed` the app scans with a signed release of the central rules service instead of asking the rule server per scan:

```bash
OASIS_ENGINE=installed OASIS_RULE_SERVER_URL=http://localhost:5091 npm start
```

- The release is downloaded, verified against the public keys pinned in `server/security/engine-loader/keys.js`, and installed under `~/.oasis-security/rules`. It is refreshed on launch and every six hours; scans run on the installed copy and work offline. With no keys pinned, nothing is installed and `update` fails with `NO_PINNED_KEYS`.
- **Security → Rules** becomes a read-only list: each rule's language, pillar and severity, a banner "Using rules from release N, updated <time>", and an "Update available" state. Per repository you can switch a rule off or change its severity (Save / Reset). The legacy editor is hidden in this mode; without the opt-in it stays and the section shows a notice.
- Overrides live only on this machine, in `~/.oasis-security/overrides.json`. API: `GET /api/security/rules/installed[?project=name]` and `PUT /api/security/rules/overrides/:project` with `{"disabled": ["rule-id"], "severity": {"rule-id": "LOW"}}`.
- Findings stay in the local store; the rules service never sees them.
- Rules are authored, tested and released by staff in the Rule Studio (`oasis-rule-studio`, port 4050); the public release service is `oasis-rule-server`'s central service (port 5091).

The legacy editor and rule-server flow described above stay in place until the installed path becomes the default.

### Adding, editing and ingesting rules

Rules are no longer part of this repository. They live in **oasis-rule-server**
(`../oasis-rule-server`), which owns the rule sources, the quality profiles and
the ingest tooling, and verifies every rule (`npm test` there: it must compile,
detect its own `example.vulnerable` and stay silent on `example.fixed`).

```bash
# Add or edit a rule:   oasis-rule-server/seed/rules/<language>/my-rule.json
# Refresh upstream sets: node tools/ingest-rules.js   (in oasis-rule-server)
# Verify:                npm test                     (in oasis-rule-server)
# Load into the server:  node scripts/seed.js         (in oasis-rule-server)
```

Licence handling for vendored rule sets (Gitleaks, Checkov, the non-redistributable
Semgrep rules) and their attributions moved with them: see that repository's
`THIRD_PARTY_LICENSES/` and `test/rule-licensing.test.js`.

Oasis fetches its rules from the server before every scan (`OASIS_RULE_SERVER_URL`,
default `http://127.0.0.1:5090`). With the server down it uses the last rules it
fetched for that repository and says so on the scan; with nothing cached the scan
is refused (503 `NO_RULES`). Your own rule packs in `~/.oasis/security/rules/` and
rules shipped by a grammar plugin still apply on top.

### Why the findings table shows fewer rows than findings

SCA findings are grouped **per dependency** in the table: one Tomcat version
carried 22 advisories in one manifest here, and across the estate 500 SCA
findings collapse to 115 rows. All of a package's advisories have the same
answer — upgrade it — so a row per advisory is a row of noise per advisory.

The count line says `115 rows · 500 findings` rather than pretending the two are
the same number. Severity tiles and gate metrics keep counting **findings**,
because six CVEs are six problems.

Grouping is presentation only. Underneath, each advisory is still its own
finding with its own severity, fixed version and suppression state — opening a
grouped row lists them, and each one opens individually. Only SCA is grouped;
collapsing SAST by file would hide genuinely distinct bugs.

### Quality gates and "new code"

One endpoint, one binary answer, designed to be consumed by a shell:

```bash
# 200 = proceed, 422 = block. curl -f turns that into an exit code.
curl -fsS "http://localhost:3000/api/security/gate?repository=iready-core" || exit 1

# The reasoning, for a human arguing about why the build went red.
curl -s "http://localhost:3000/api/security/gate?repository=iready-core" | python3 -m json.tool
```

**The default gate is scoped to NEW CODE**, and that is the whole design. A gate
on a repository's total count fails on day one against a 700-finding backlog,
never goes green, and is switched off within a week. A gate on what *this change*
introduced is one a team can hold while the backlog is worked down separately.

New code is derived from `git diff -U0 <base>...HEAD` on every scan — actual
changed line numbers, not a snapshot. Pass a PR target with
`{"baseRef": "origin/main"}` on `POST /scans`; it defaults to `HEAD~1`.

| Default condition | Scope | Fails when |
|---|---|---|
| `critical_issues` | new code | > 0 |
| `secrets` | new code | > 0 |
| `high_severity_cves` | new code | > 0 |
| `coverage_gaps` | overall | > 0 — **warns**, does not block |

Override per repository with a checked-in `.oasis-security-gate.yml`, so a
threshold change is a reviewable diff rather than a setting someone moved in a
UI at 6pm:

```yaml
name: strict
conditions:
  - metric: blocker_issues     # CRITICAL + HIGH
    scope: OVERALL
    operator: GT
    threshold: 0
  - metric: secrets
    scope: NEW_CODE
    operator: GT
    threshold: 0
```

Metrics: `vulnerabilities`, `secrets`, `high_severity_cves`, `critical_issues`,
`blocker_issues`, `iac_misconfigurations`, `license_violations`, `risk_score`,
`coverage_gaps`. Operators: `GT`, `GTE`, `LT`, `LTE`, `EQ`. Add `level: WARN` to
report without blocking, or `severity:` to count one band only.

**It fails closed, deliberately.** Each of these blocks rather than passing:

| Situation | Why it must not be a pass |
|---|---|
| No completed scan | No evidence is not the same as clean |
| Shallow clone, so no diff | CI clones shallow by default — "no diff" meaning "nothing new" would silently disable the gate exactly where it matters |
| `.oasis-security-gate.yml` is malformed | Someone edited the gate and got it wrong; running different thresholds silently is how a build passes for reasons nobody can reconstruct |

A green tick that appears when the tool could not work something out is worse
than no gate at all, because the tick gets trusted.

### Offline advisory mirror

Removes the per-dependency call to api.osv.dev. Two reasons to want it: an
air-gapped network reports **no vulnerable dependencies at all** today, which
looks exactly like having none; and on a Maven tree of several hundred
coordinates the round trips are most of the scan's wall time.

```bash
node tools/build-advisories.js --list           # what is available
node tools/build-advisories.js Maven npm        # mirror only what you use
OASIS_ADVISORY_OFFLINE=1 npm start              # never call the network
```

**Ecosystems are opt-in because the exports are large** — npm alone is 219 MB.
The build keeps only what a finding needs (affected ranges, id, aliases,
severity, dates) and drops the prose, references and credits that make an
advisory big, which is what turns hundreds of megabytes into a few. Hex, for
example, goes from a 436 KB export to a 61 KB index.

The mirror is tried first and the live API is the fallback. The distinction that
makes that safe: a lookup for an ecosystem that is **not** mirrored returns
`null`, not an empty list, so it falls through to the network instead of
reporting every package clean. With `OASIS_ADVISORY_OFFLINE=1` an unmirrored
ecosystem returns an explicit error rather than a silent zero.

Verified against the live API — for `ash_authentication_phoenix` the mirror and
`api.osv.dev` agree on all four version probes, including the boundary case
where the fixed version reports nothing.

### The central platform (optional)

Aggregates scans from many developers and CI jobs. **Not required** — OASIS is a
desktop tool and works with no server at all; the app pushes to the platform and
never reads through it, so an outage costs nothing.

```bash
# In memory — no database, everything lost on restart. A real mode for a team
# with two repositories.
node platform/server.js

# Durable. Apply db/schema.sql first.
DATABASE_URL=postgres://user@host/oasis node platform/server.js

# Point the desktop app at it. Unset means "do not publish", silently.
OASIS_PLATFORM_URL=http://localhost:4020 npm start
```

| Endpoint | Purpose |
|---|---|
| `POST /api/v1/scans` | Ingest. Returns `{opened, reopened, resolved, unverified}` |
| `GET /api/v1/projects/:key` | Summary — open issues, severity split, gate |
| `GET /api/v1/projects/:key/gate` | Same 200/422 contract as the desktop app |

`platform/` has its **own package.json** and is outside the electron-builder
`files` globs, so `pg` and `express` can never reach the installer — the
no-install guarantee is about the desktop app, not about servers we deploy.

Two behaviours worth knowing, both tested:

- **Coverage is required on ingest.** Without it the platform cannot tell
  "fixed" from "not checked", and would resolve issues because a scanner
  crashed. Issues of a type the scan did not analyse are returned as
  `unverified`, never resolved.
- **A suppressed issue stays suppressed.** A scan re-sighting it does not
  reopen it, and a scan missing it does not resolve it — otherwise triage would
  have to be redone on every run.

### Importing another tool's results

Anything that writes SARIF into `.oasis/sarif/` becomes a scanner. This is how
container, cloud, DAST, and API coverage arrive — those tools already exist and
already emit SARIF, so they are ingested rather than reimplemented.

```bash
mkdir -p .oasis/sarif

trivy image --format sarif  -o .oasis/sarif/trivy.sarif   myimage:1.2.3
checkov -d . --output sarif --output-file-path .oasis/sarif
zap-cli report -o .oasis/sarif/zap.sarif -f sarif

# Or point at a directory beside the checkout, which is the natural place in CI:
OASIS_SARIF_DIR=/build/artifacts/sarif npm start
```

The finding type is inferred from the tool name (Trivy → `CONTAINER`, Checkov →
`IAC`, ZAP → `DAST`, Prowler → `CLOUD`). For a tool OASIS does not recognise,
set `runs[].properties.oasisType` in the SARIF itself. A file that is corrupt or
not SARIF is reported in the scan's `rejected` list rather than silently
dropped — a rejected file means a tool ran and its results are missing.

### Publishing rules to running installs

There is nothing to publish. Installs read the rule server directly, so an edit
to a rule or a quality profile reaches the next scan on every machine that uses
that server.

### The rule server

Rules, quality profiles and (from plan 3b) findings live in **oasis-rule-server**, a separate
process. Oasis cannot scan without it: start it first.

```bash
bash start-rule-server.sh            # seeds its database on first run, listens on 127.0.0.1:5090
curl -s http://localhost:3000/api/security/rules | python3 -m json.tool          # last sync, per repository
curl -s http://localhost:3000/api/security/rules/config | python3 -m json.tool   # server, local packs, grammar plugins
```

**Findings live there too.** The rule server is the system of record for findings, their
triage (suppress, false positive, reopen), the trend history and the baseline; the Security tab
reads them from it. Oasis keeps only its scan records, repository asset settings and SBOMs.

- A finished scan is written to an **outbox** (`~/.oasis-security/outbox/`) before it is sent, and
  removed only once the server has it. With the server down the scan still completes and says
  `pending`; the next scan, or the next start of oasis, delivers it. What waits, what was set
  aside and whether the server is refusing uploads (a wrong token, say) is on
  `GET /api/security/rules` under `outbox`.
- A server that refuses uploads for **credentials, size or overload** (401, 403, 408, 413, 429)
  leaves everything queued; nothing is discarded while the cause is fixed. A scan the server
  calls **malformed** (400, 404, 410, 422) is set aside in `outbox/rejected/` with the reason, and
  `POST /api/security/rules/outbox/retry` puts those back in the queue and delivers them.
- With the server down the Security tab answers **503** with the reason instead of an empty list.
- Moving findings you already have in `~/.oasis-security/store.json`:

```bash
node tools/migrate-findings-to-rule-server.js            # dry run: counts only
node tools/migrate-findings-to-rule-server.js --apply    # send findings, history and baseline
```

  **Do this before your first scan on the new server.** It only reads the local store (your
  rollback). If the server already holds findings (you scanned first, so your suppressions came
  back as open), use `--apply --merge`: it adds what is missing and brings your old suppressions
  across without touching what the server already has. `--force` instead overwrites the server's
  copy with the local one. Entries without a repository or fingerprint are reported and skipped,
  and a big store is sent in batches.

`OASIS_RULE_SERVER_URL` points oasis at a different server. If it is unreachable, a repository
that was scanned before uses its last rules and the scan says `rule-server-cache`; one that
never was is refused with a message that names the server. A server with no active rules is
refused too, because a scan that ran nothing would read as a clean repository.

### Grammars

`server/security/ast/grammars/*.wasm` — 2.6 MB for Java, JavaScript, TypeScript
and Python, vendored from the `@vscode/tree-sitter-wasm` devDependency because
electron-builder packages `server/**` but not devDependencies.

Grammar `.wasm` files are tied to a tree-sitter ABI. If a grammar stops loading
after a dependency bump, that mismatch is the first thing to check —
`tree-sitter-wasms` builds against grammars `^0.20` and fails on
`web-tree-sitter@0.26` with an opaque dylink error.

---

## 16. What this product does and does not do

```bash
curl -s http://localhost:3000/api/security/capabilities | python3 -m json.tool
```

`server/security/capabilities.js` holds one row per capability, each either
naming the module that implements it or recording why it does not exist.

It is **verified by tests**: a row claiming `implemented` must name a module
that exists and exports something, `planned` rows must *not* name one, `partial`
rows must state what they miss, and `declined` rows must give a reason. A
capability list nobody verifies becomes the optimistic README everyone stops
believing — these assertions make drift a test failure.

Adding a capability is: implement it, flip the row, name the module.
