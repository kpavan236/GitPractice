'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { reconcile, summarise } = require('./transitions');

// These tests are the specification for issue lifecycle. Every one of them is
// about a way of being WRONG that would look fine on a dashboard.

const COVERED = [{ type: 'SAST', analysed: true }, { type: 'SECRET', analysed: true }];

function issue(over = {}) {
  return { fingerprint: 'f1', type: 'SAST', status: 'OPEN', ...over };
}
function finding(over = {}) {
  return { fingerprint: 'f1', type: 'SAST', severity: 'HIGH', ...over };
}

test('a finding never seen before is opened', () => {
  const r = reconcile([], [finding()], COVERED);
  assert.equal(r.opened.length, 1);
  assert.equal(r.opened[0].status, 'OPEN');
});

test('a finding already open stays open', () => {
  const r = reconcile([issue()], [finding()], COVERED);
  assert.equal(r.unchanged.length, 1);
  assert.equal(r.opened.length, 0);
  assert.equal(r.resolved.length, 0);
});

test('an issue no longer found is resolved', () => {
  const r = reconcile([issue()], [], COVERED);
  assert.equal(r.resolved.length, 1);
  assert.equal(r.resolved[0].status, 'RESOLVED');
});

test('a resolved issue found again is REOPENED, not opened fresh', () => {
  // A regression must be visibly a regression. Opening it as new loses the
  // history that says this was fixed once and came back — which is exactly the
  // signal that the fix was wrong.
  const r = reconcile([issue({ status: 'RESOLVED' })], [finding()], COVERED);
  assert.equal(r.reopened.length, 1);
  assert.equal(r.opened.length, 0);
  assert.match(r.reopened[0].reason, /after being resolved/);
});

// ── The rule that matters most ─────────────────────────────────────────────

test('an issue is NOT resolved when its type was not analysed', () => {
  // The dangerous failure. A SAST scanner that failed to run does not mean the
  // SQL injection is fixed. A platform that closes issues because a scanner
  // crashed reports a clean estate while the findings are still in the code.
  const notCovered = [{ type: 'SAST', analysed: false }, { type: 'SECRET', analysed: true }];
  const r = reconcile([issue({ type: 'SAST' })], [], notCovered);

  assert.equal(r.resolved.length, 0, 'must not resolve what was never checked');
  assert.equal(r.untouched.length, 1);
  assert.match(r.untouched[0].reason, /not analysed/);
});

test('unverified issues are reported separately, not rounded down to fixed', () => {
  const notCovered = [{ type: 'SAST', analysed: false }];
  const r = reconcile([issue()], [], notCovered);
  assert.equal(summarise(r).unverified, 1);
  assert.equal(summarise(r).resolved, 0);
});

test('coverage is per type — an unanalysed type does not block resolving others', () => {
  const mixed = [{ type: 'SAST', analysed: true }, { type: 'SECRET', analysed: false }];
  const r = reconcile(
    [issue({ fingerprint: 'a', type: 'SAST' }), issue({ fingerprint: 'b', type: 'SECRET' })],
    [],
    mixed
  );
  assert.deepEqual(r.resolved.map(x => x.issue.fingerprint), ['a']);
  assert.deepEqual(r.untouched.map(x => x.issue.fingerprint), ['b']);
});

// ── Human decisions outrank the scanner ────────────────────────────────────

test('a suppressed issue found again is not reopened', () => {
  // Seeing a suppressed finding again is exactly what suppression means. If the
  // scan overruled it, the feature would be useless after one run.
  const r = reconcile([issue({ status: 'SUPPRESSED' })], [finding()], COVERED);
  assert.equal(r.reopened.length, 0);
  assert.equal(r.opened.length, 0);
  assert.equal(r.unchanged.length, 1);
});

test('a false positive stays a false positive', () => {
  const r = reconcile([issue({ status: 'FALSE_POSITIVE' })], [finding()], COVERED);
  assert.equal(r.unchanged.length, 1);
  assert.equal(r.reopened.length, 0);
});

test('a suppressed issue that disappears is not resolved either', () => {
  // Resolving it would silently discard the suppression, so when the finding
  // came back it would arrive as brand new and someone would triage it twice.
  const r = reconcile([issue({ status: 'SUPPRESSED' })], [], COVERED);
  assert.equal(r.resolved.length, 0);
  assert.equal(r.untouched.length, 0);
});

// ── Robustness ─────────────────────────────────────────────────────────────

test('a finding with no fingerprint is ignored rather than duplicating', () => {
  // Without a fingerprint there is no identity, so it would be opened fresh on
  // every single scan and the backlog would grow forever.
  const r = reconcile([], [finding({ fingerprint: null })], COVERED);
  assert.equal(r.opened.length, 0);
});

test('several findings sharing a fingerprint collapse to one issue', () => {
  const r = reconcile([], [finding(), finding()], COVERED);
  assert.equal(r.opened.length, 2, 'the caller dedupes; reconcile reports what it was given');
  // …but the second is seen, so nothing is resolved.
  assert.equal(r.resolved.length, 0);
});

test('empty inputs are safe', () => {
  assert.deepEqual(summarise(reconcile([], [], [])), {
    opened: 0, reopened: 0, resolved: 0, unchanged: 0, unverified: 0,
  });
  assert.doesNotThrow(() => reconcile(null, null, null));
});

test('a full cycle: open, persist, fix, regress', () => {
  // The lifecycle end to end, because each step is only correct in the context
  // of the one before it.
  const first = reconcile([], [finding()], COVERED);
  assert.equal(summarise(first).opened, 1);

  const open = [issue({ status: 'OPEN' })];
  assert.equal(summarise(reconcile(open, [finding()], COVERED)).unchanged, 1);

  const fixed = reconcile(open, [], COVERED);
  assert.equal(summarise(fixed).resolved, 1);

  const regressed = reconcile([issue({ status: 'RESOLVED' })], [finding()], COVERED);
  assert.equal(summarise(regressed).reopened, 1);
});
