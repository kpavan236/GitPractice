'use strict';

// Issue state transitions across scans.
//
// This is the heart of the central platform and the only part with genuinely
// interesting logic, so it lives on its own with no database anywhere near it.
// Everything else up here is plumbing; this is the thing that decides whether a
// team's triage survives contact with the next scan.
//
// The model: an ISSUE is a problem, identified by its fingerprint. A SCAN is a
// sighting. Reconciling one scan against the stored issues produces four
// outcomes, and each has a rule that is easy to get subtly wrong:
//
//   OPENED     seen now, never seen before
//   REOPENED   seen now, previously RESOLVED — the fix regressed
//   UNCHANGED  seen now, already open
//   RESOLVED   NOT seen now, but was open — and the scan actually looked
//
// That last clause is the one that matters. An issue must only be resolved when
// the scan COVERED the thing that would have found it. A SAST scanner that
// failed to run does not mean the SQL injection is fixed, and a platform that
// closes issues because a scanner crashed will quietly report a clean estate
// while the findings are still in the code. Coverage is therefore a required
// input, not an optional refinement.

const ACTIVE = ['OPEN', 'REOPENED', 'FIXED_PENDING_VERIFICATION'];

// Statuses a human set deliberately. A scan must never move these: if someone
// marked a finding a false positive, the next scan finding it again does not
// overrule them, and closing a SUPPRESSED issue would silently discard the
// suppression when it reappeared.
const HUMAN_OWNED = ['SUPPRESSED', 'FALSE_POSITIVE'];

/**
 * Reconciles one scan's findings against the issues already stored.
 *
 * @param {Array}  existing   stored issues: { fingerprint, status, ... }
 * @param {Array}  incoming   this scan's findings
 * @param {Array}  coverage   [{ type, analysed }] from the scan
 * @param {object} opts       { scanId, now }
 *
 * @returns {{ opened, reopened, unchanged, resolved, untouched }}
 *   Arrays of the ACTIONS to apply, not the rows themselves, so the caller can
 *   write them in one transaction and a test can assert on intent.
 */
function reconcile(existing, incoming, coverage, { scanId = null, now = Date.now() } = {}) {
  const byFingerprint = new Map((existing || []).map(i => [i.fingerprint, i]));
  const seen = new Set();

  const opened = [];
  const reopened = [];
  const unchanged = [];

  for (const finding of incoming || []) {
    if (!finding.fingerprint) continue;
    seen.add(finding.fingerprint);

    const known = byFingerprint.get(finding.fingerprint);

    if (!known) {
      opened.push({ finding, status: 'OPEN', scanId, at: now });
      continue;
    }

    // A human's decision outranks a scanner's sighting. Seeing a suppressed
    // finding again is expected — that is what suppression means — and
    // reopening it would make the feature useless within one scan.
    if (HUMAN_OWNED.includes(known.status)) {
      unchanged.push({ issue: known, finding, scanId, at: now });
      continue;
    }

    if (known.status === 'RESOLVED') {
      reopened.push({
        issue: known,
        finding,
        status: 'REOPENED',
        scanId,
        at: now,
        reason: 'found again after being resolved',
      });
      continue;
    }

    unchanged.push({ issue: known, finding, scanId, at: now });
  }

  // What this scan was actually able to see. An issue of a type nobody checked
  // cannot be declared fixed.
  const covered = new Set(
    (coverage || []).filter(c => c.analysed).map(c => c.type)
  );

  const resolved = [];
  const untouched = [];

  for (const issue of existing || []) {
    if (seen.has(issue.fingerprint)) continue;
    if (!ACTIVE.includes(issue.status)) continue;

    if (!covered.has(issue.type)) {
      // Not seen, but not looked for either. Left exactly as it was, and
      // reported separately so "we could not verify these" is visible rather
      // than being rounded down to "fixed".
      untouched.push({ issue, reason: `${issue.type} was not analysed by this scan` });
      continue;
    }

    resolved.push({ issue, status: 'RESOLVED', scanId, at: now, reason: 'no longer detected' });
  }

  return { opened, reopened, unchanged, resolved, untouched };
}

/**
 * A one-line summary of what a scan changed, for the ingest response.
 *
 * The numbers a reviewer looks at first: what appeared, what came back, and
 * what could not be checked.
 */
function summarise(result) {
  return {
    opened: result.opened.length,
    reopened: result.reopened.length,
    resolved: result.resolved.length,
    unchanged: result.unchanged.length,
    unverified: result.untouched.length,
  };
}

module.exports = { reconcile, summarise, ACTIVE, HUMAN_OWNED };
