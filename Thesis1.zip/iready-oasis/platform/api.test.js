'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const { createPlatformApi } = require('./api');
const { createMemoryStore } = require('./store/memory');

// Driven over real HTTP against a real express app, because the contract this
// module offers IS the HTTP contract — status codes included. A pipeline reads
// the status code, not the body.

function server() {
  const store = createMemoryStore();
  const app = express();
  app.use('/api', createPlatformApi({ store }));
  const listener = app.listen(0);
  const base = `http://127.0.0.1:${listener.address().port}/api`;
  return { store, base, close: () => listener.close() };
}

const COVERAGE = [{ type: 'SAST', analysed: true }, { type: 'SECRET', analysed: true }];

function scanBody(over = {}) {
  return {
    project: { key: 'iready-core', name: 'iready-core' },
    scan: { externalId: 'SCAN-1', status: 'COMPLETED', startedAt: 1000, finishedAt: 2000 },
    coverage: COVERAGE,
    findings: [],
    ...over,
  };
}

async function post(base, body) {
  const res = await fetch(`${base}/v1/scans`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

test('ingests a scan and reports what changed', async () => {
  const s = server();
  const res = await post(s.base, scanBody({
    findings: [{ fingerprint: 'a', type: 'SAST', severity: 'HIGH', title: 'SQLi' }],
  }));

  assert.equal(res.status, 201);
  assert.equal(res.body.opened, 1);
  assert.equal(res.body.resolved, 0);
  s.close();
});

test('a second scan resolves what is gone and reopens what came back', async () => {
  const s = server();
  const finding = { fingerprint: 'a', type: 'SAST', severity: 'HIGH', title: 'SQLi' };

  await post(s.base, scanBody({ findings: [finding] }));
  const fixed = await post(s.base, scanBody({ findings: [] }));
  assert.equal(fixed.body.resolved, 1);

  const regressed = await post(s.base, scanBody({ findings: [finding] }));
  assert.equal(regressed.body.reopened, 1);
  assert.equal(regressed.body.opened, 0);
  s.close();
});

test('coverage is required, because without it nothing can ever resolve', async () => {
  const s = server();
  const res = await post(s.base, scanBody({ coverage: [] }));
  assert.equal(res.status, 400);
  assert.match(res.body.error, /coverage is required/);
  s.close();
});

test('a scan that did not analyse a type does not resolve its issues', async () => {
  const s = server();
  const finding = { fingerprint: 'a', type: 'SAST', severity: 'HIGH', title: 'SQLi' };
  await post(s.base, scanBody({ findings: [finding] }));

  // SAST failed to run this time. The issue must survive, and be reported as
  // unverified rather than fixed.
  const res = await post(s.base, scanBody({
    findings: [],
    coverage: [{ type: 'SAST', analysed: false }, { type: 'SECRET', analysed: true }],
  }));

  assert.equal(res.body.resolved, 0);
  assert.equal(res.body.unverified, 1);
  assert.equal(s.store.listIssues({ projectKey: 'iready-core' }).length, 1);
  s.close();
});

test('rejects a malformed payload rather than storing half of it', async () => {
  const s = server();
  assert.equal((await post(s.base, { scan: {}, coverage: COVERAGE })).status, 400);
  assert.equal((await post(s.base, { project: { key: 'x' }, coverage: COVERAGE })).status, 400);
  assert.equal((await post(s.base, scanBody({ findings: 'nope' }))).status, 400);
  s.close();
});

test('caps the findings a single scan may post', async () => {
  // An unbounded write would let one runaway scanner take the platform down
  // for everyone.
  const s = server();
  const many = Array.from({ length: 50001 }, (_, i) => ({ fingerprint: `f${i}`, type: 'SAST', severity: 'LOW' }));
  const res = await post(s.base, scanBody({ findings: many }));
  assert.equal(res.status, 413);
  s.close();
});

// ── The gate contract ──────────────────────────────────────────────────────

test('the gate endpoint mirrors the desktop app: 200 proceed, 422 block', async () => {
  const s = server();

  await post(s.base, scanBody({ gate: { status: 'PASSED', blocking: false, conditions: [] } }));
  const pass = await fetch(`${s.base}/v1/projects/iready-core/gate`);
  assert.equal(pass.status, 200);
  assert.equal((await pass.json()).status, 'PASSED');

  await post(s.base, scanBody({
    scan: { externalId: 'SCAN-2', status: 'COMPLETED' },
    gate: { status: 'FAILED', blocking: true, reason: 'a new secret', conditions: [] },
  }));
  const fail = await fetch(`${s.base}/v1/projects/iready-core/gate`);
  assert.equal(fail.status, 422);
  assert.equal((await fail.json()).blocking, true);
  s.close();
});

test('an unknown or unscanned project blocks rather than passing', async () => {
  // No evidence is not the same as clean. A pipeline pointed at a project
  // nobody has scanned must not be told to proceed.
  const s = server();
  const unknown = await fetch(`${s.base}/v1/projects/never-seen/gate`);
  assert.equal(unknown.status, 422);
  assert.equal((await unknown.json()).blocking, true);

  // Known project, scan posted with no gate result at all.
  await post(s.base, scanBody({ gate: null }));
  const noGate = await fetch(`${s.base}/v1/projects/iready-core/gate`);
  assert.equal(noGate.status, 422);
  s.close();
});

// ── Reads ──────────────────────────────────────────────────────────────────

test('a project summary counts only active issues', async () => {
  const s = server();
  await post(s.base, scanBody({
    findings: [
      { fingerprint: 'a', type: 'SAST', severity: 'CRITICAL', isNewCode: true },
      { fingerprint: 'b', type: 'SECRET', severity: 'HIGH' },
    ],
  }));

  const summary = await (await fetch(`${s.base}/v1/projects/iready-core`)).json();
  assert.equal(summary.openIssues, 2);
  assert.equal(summary.bySeverity.CRITICAL, 1);
  assert.equal(summary.newCode, 1);
  s.close();
});

test('an unknown project reads as 404, not an empty success', async () => {
  const s = server();
  assert.equal((await fetch(`${s.base}/v1/projects/nope`)).status, 404);
  assert.equal((await fetch(`${s.base}/v1/projects/nope/issues`)).status, 404);
  s.close();
});

test('health reports which store is behind it', async () => {
  const s = server();
  const health = await (await fetch(`${s.base}/health`)).json();
  assert.equal(health.ok, true);
  assert.equal(health.store, 'memory');
  s.close();
});
