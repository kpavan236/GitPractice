#!/usr/bin/env node
'use strict';
const express = require('express');
const { createPlatformApi } = require('./api');
const { createMemoryStore } = require('./store/memory');

// The central platform, as a process.
//
//   DATABASE_URL=postgres://… node platform/server.js    → Postgres
//   node platform/server.js                              → in memory
//
// The in-memory mode is a real mode, not a stub: a team with two repositories
// should not have to run a database to get aggregated scans and a gate. It is
// also what the tests drive. What it is NOT is durable, and it says so at
// startup rather than letting someone discover it after a restart.

const PORT = Number(process.env.PORT) || 4020;
// Loopback by default, exactly like the desktop app: this serves finding
// locations, including where credentials appear in a codebase, and must not be
// reachable from the network unless someone chose that.
const BIND = process.env.PLATFORM_BIND || '127.0.0.1';

function createStore() {
  if (!process.env.DATABASE_URL) return createMemoryStore();
  // Required here rather than at the top so a memory-mode run needs no `pg`
  // installed at all.
  // eslint-disable-next-line global-require
  const { createPostgresStore } = require('./store/postgres');
  return createPostgresStore({ connectionString: process.env.DATABASE_URL });
}

function main() {
  const store = createStore();
  const app = express();
  app.use('/api', createPlatformApi({ store, log: console.log }));

  app.listen(PORT, BIND, () => {
    console.log(`  i-Ready OASIS platform on http://${BIND}:${PORT}`);
    console.log(`  store: ${store.kind}`);
    if (store.kind === 'memory') {
      console.log('  WARNING — in-memory store. Everything is lost on restart.');
      console.log('            Set DATABASE_URL and apply db/schema.sql for a durable one.');
    }
    if (BIND !== '127.0.0.1') {
      console.log(`  WARNING — bound to ${BIND}. This API serves finding locations, including`);
      console.log('            where credentials appear in source. Put it behind auth.');
    }
  });
}

if (require.main === module) main();
module.exports = { createStore };
