'use strict';

// The store interface, implemented in memory.
//
// This is not only a test double. A team running one or two repositories does
// not need Postgres, and making the storage swappable means the platform has a
// zero-infrastructure mode as well as a production one. The Postgres adapter
// beside it implements exactly these methods and nothing else, which is what
// keeps the API layer free of SQL.
//
// The interface is deliberately COARSE — `ingestScan` does the whole
// reconciliation in one call rather than exposing rows — because the alternative
// is the API layer orchestrating a dozen fine-grained writes and needing a
// transaction it cannot express portably.

const { reconcile, summarise } = require('../transitions');

function createMemoryStore() {
  const projects = new Map();     // key → project
  const scans = [];               // newest first
  const issues = new Map();       // `${projectKey}:${fingerprint}` → issue
  let nextId = 1;

  function upsertProject({ key, name, ...rest }) {
    const existing = projects.get(key);
    const project = {
      id: existing ? existing.id : nextId++,
      key,
      name: name || key,
      criticality: 'MEDIUM',
      ...existing,
      ...rest,
      updatedAt: Date.now(),
    };
    projects.set(key, project);
    return project;
  }

  function getProject(key) {
    return projects.get(key) || null;
  }

  function listProjects() {
    return [...projects.values()];
  }

  function issuesFor(projectKey) {
    return [...issues.values()].filter(i => i.projectKey === projectKey);
  }

  /**
   * The one write that matters: a scan arrives, and the stored issues are
   * reconciled against it.
   *
   * Returns what changed rather than the rows, so a CI job posting a scan gets
   * back "3 opened, 1 reopened, 2 resolved" — the only summary anyone reads.
   */
  function ingestScan({ projectKey, scan, findings = [], coverage = [], gate = null, now = Date.now() }) {
    const project = getProject(projectKey) || upsertProject({ key: projectKey });

    const record = {
      id: nextId++,
      projectKey,
      externalId: scan.externalId || scan.id || null,
      status: scan.status || 'COMPLETED',
      trigger: scan.trigger || 'MANUAL',
      gitRef: scan.gitRef || null,
      commitSha: scan.commitSha || null,
      baseCommitSha: scan.baseCommitSha || null,
      startedAt: scan.startedAt || now,
      finishedAt: scan.finishedAt || now,
      ruleBundleVersion: scan.ruleBundleVersion || null,
      coverage,
      partial: coverage.some(c => !c.analysed),
      gate,
      createdAt: now,
    };
    scans.unshift(record);

    const result = reconcile(issuesFor(projectKey), findings, coverage, { scanId: record.id, now });

    for (const { finding } of result.opened) {
      issues.set(`${projectKey}:${finding.fingerprint}`, {
        ...finding,
        projectKey,
        status: 'OPEN',
        firstSeenScan: record.id,
        lastSeenScan: record.id,
        firstSeenAt: now,
        lastSeenAt: now,
        isNewCode: Boolean(finding.isNewCode),
      });
    }

    for (const { issue, finding } of result.reopened) {
      issues.set(`${projectKey}:${issue.fingerprint}`, {
        ...issue, ...finding, projectKey,
        status: 'REOPENED', lastSeenScan: record.id, lastSeenAt: now, resolvedAt: null,
      });
    }

    for (const { issue, finding } of result.unchanged) {
      issues.set(`${projectKey}:${issue.fingerprint}`, {
        // The stored status wins: a scan re-sighting a suppressed issue must
        // not overwrite the human decision with the finding's default OPEN.
        ...issue, ...finding, projectKey, status: issue.status,
        lastSeenScan: record.id, lastSeenAt: now,
      });
    }

    for (const { issue } of result.resolved) {
      issues.set(`${projectKey}:${issue.fingerprint}`, {
        ...issue, status: 'RESOLVED', resolvedAt: now, lastSeenScan: record.id,
      });
    }

    return { project, scan: record, ...summarise(result) };
  }

  function latestScan(projectKey) {
    return scans.find(s => s.projectKey === projectKey && s.status === 'COMPLETED') || null;
  }

  function projectSummary(projectKey) {
    const active = issuesFor(projectKey).filter(i =>
      ['OPEN', 'REOPENED', 'FIXED_PENDING_VERIFICATION'].includes(i.status)
    );
    const scan = latestScan(projectKey);

    return {
      project: getProject(projectKey),
      openIssues: active.length,
      bySeverity: active.reduce((acc, i) => ({ ...acc, [i.severity]: (acc[i.severity] || 0) + 1 }), {}),
      byType: active.reduce((acc, i) => ({ ...acc, [i.type]: (acc[i.type] || 0) + 1 }), {}),
      newCode: active.filter(i => i.isNewCode).length,
      lastScannedAt: scan ? scan.startedAt : null,
      gate: scan ? scan.gate : null,
    };
  }

  function listIssues({ projectKey, status = 'active' } = {}) {
    let rows = projectKey ? issuesFor(projectKey) : [...issues.values()];
    if (status === 'active') {
      rows = rows.filter(i => ['OPEN', 'REOPENED', 'FIXED_PENDING_VERIFICATION'].includes(i.status));
    } else if (status !== 'all') {
      rows = rows.filter(i => i.status === status);
    }
    return rows;
  }

  return {
    kind: 'memory',
    upsertProject, getProject, listProjects,
    ingestScan, latestScan, projectSummary, listIssues,
    // Exposed for tests and for the /health endpoint's row counts.
    _counts: () => ({ projects: projects.size, scans: scans.length, issues: issues.size }),
  };
}

module.exports = { createMemoryStore };
