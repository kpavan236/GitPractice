'use strict';
const { reconcile, summarise } = require('../transitions');

// The same store interface, backed by the schema in db/schema.sql.
//
// UNTESTED AGAINST A LIVE DATABASE, and that is stated here rather than
// discovered later: there is no Postgres in the development environment, so
// every query below is reviewed SQL, not executed SQL. The reconciliation logic
// it depends on IS tested — it lives in transitions.js with no database near
// it, and the memory store exercises the same interface over HTTP. What remains
// unverified is the mapping, which is the part a reviewer can read.
//
// `pg` is required lazily so this file can be imported — and the module graph
// type-checked by a test — on a machine that has never installed it.
//
// Every query is parameterised. Not one string is concatenated into SQL: the
// values arriving here come from a scan payload posted over the network, and a
// platform that stores security findings is a poor place to have an injection.

function createPostgresStore({ connectionString, pool = null, now = () => Date.now() } = {}) {
  let db = pool;

  function client() {
    if (db) return db;
    // eslint-disable-next-line global-require
    const { Pool } = require('pg');
    db = new Pool({ connectionString });
    return db;
  }

  const one = async (text, values) => (await client().query(text, values)).rows[0] || null;
  const many = async (text, values) => (await client().query(text, values)).rows;

  async function upsertProject({ key, name, criticality, repositoryUrl, defaultBranch, ownerTeam }) {
    return one(
      `INSERT INTO oasis.project (key, name, repository_url, default_branch, criticality, owner_team)
            VALUES ($1, $2, $3, COALESCE($4, 'main'), COALESCE($5, 'MEDIUM'), $6)
       ON CONFLICT (key) DO UPDATE
            SET name           = COALESCE(EXCLUDED.name, oasis.project.name),
                repository_url = COALESCE(EXCLUDED.repository_url, oasis.project.repository_url),
                criticality    = COALESCE(EXCLUDED.criticality, oasis.project.criticality),
                owner_team     = COALESCE(EXCLUDED.owner_team, oasis.project.owner_team),
                updated_at     = now()
         RETURNING *`,
      [key, name || key, repositoryUrl || null, defaultBranch || null, criticality || null, ownerTeam || null]
    );
  }

  const getProject = key => one('SELECT * FROM oasis.project WHERE key = $1', [key]);
  const listProjects = () => many('SELECT * FROM oasis.project WHERE archived_at IS NULL ORDER BY key');

  /**
   * Ingest, in ONE transaction.
   *
   * A scan that fails halfway through would otherwise leave issues resolved
   * against a scan row that does not exist — a state nothing else in the system
   * knows how to interpret.
   */
  async function ingestScan({ projectKey, scan, findings = [], coverage = [], gate = null }) {
    const conn = await client().connect();
    try {
      await conn.query('BEGIN');

      const project = (await conn.query('SELECT * FROM oasis.project WHERE key = $1', [projectKey])).rows[0];
      if (!project) throw new Error(`unknown project ${projectKey}`);

      const scanRow = (await conn.query(
        `INSERT INTO oasis.scan
            (project_id, external_id, status, trigger, git_ref, commit_sha, base_commit_sha,
             started_at, finished_at, rule_bundle_version, scanner_version, coverage, partial, ignored_count)
          VALUES ($1,$2,$3,COALESCE($4,'MANUAL'),$5,$6,$7,
                  to_timestamp($8/1000.0), to_timestamp($9/1000.0), $10, $11, $12::jsonb, $13, $14)
       ON CONFLICT (project_id, external_id) DO UPDATE SET status = EXCLUDED.status
          RETURNING *`,
        [
          project.id, scan.externalId || scan.id, scan.status || 'COMPLETED', scan.trigger,
          scan.gitRef || null, scan.commitSha || null, scan.baseCommitSha || null,
          scan.startedAt || now(), scan.finishedAt || now(),
          scan.ruleBundleVersion || null, scan.scannerVersion || null,
          JSON.stringify(coverage), coverage.some(c => !c.analysed), scan.ignored || 0,
        ]
      )).rows[0];

      const existing = (await conn.query(
        `SELECT id, fingerprint, type, status FROM oasis.issue WHERE project_id = $1`,
        [project.id]
      )).rows;

      const result = reconcile(existing, findings, coverage, { scanId: scanRow.id, now: now() });

      for (const { finding } of result.opened) await insertIssue(conn, project.id, scanRow.id, finding);

      for (const { issue, finding } of result.reopened) {
        await conn.query(
          `UPDATE oasis.issue
              SET status = 'REOPENED', resolved_at = NULL, last_seen_scan = $2, last_seen_at = now(),
                  severity = $3, risk_score = $4, is_new_code = $5
            WHERE id = $1`,
          [issue.id, scanRow.id, finding.severity, (finding.risk && finding.risk.score) || null, Boolean(finding.isNewCode)]
        );
        await transition(conn, issue.id, issue.status, 'REOPENED', scanRow.id, 'found again after being resolved');
      }

      for (const { issue, finding } of result.unchanged) {
        // Status is deliberately NOT written. A suppressed issue re-sighted by
        // a scan stays suppressed; overwriting it here would undo triage on
        // every run.
        await conn.query(
          `UPDATE oasis.issue
              SET last_seen_scan = $2, last_seen_at = now(), severity = $3, is_new_code = $4
            WHERE id = $1`,
          [issue.id, scanRow.id, finding.severity, Boolean(finding.isNewCode)]
        );
      }

      for (const { issue } of result.resolved) {
        await conn.query(
          `UPDATE oasis.issue SET status = 'RESOLVED', resolved_at = now(), last_seen_scan = $2 WHERE id = $1`,
          [issue.id, scanRow.id]
        );
        await transition(conn, issue.id, issue.status, 'RESOLVED', scanRow.id, 'no longer detected');
      }

      if (gate) {
        await conn.query(
          `INSERT INTO oasis.quality_gate_result (scan_id, status, conditions)
                VALUES ($1, $2, $3::jsonb)
           ON CONFLICT (scan_id) DO UPDATE SET status = EXCLUDED.status, conditions = EXCLUDED.conditions`,
          [scanRow.id, gate.status, JSON.stringify(gate.conditions || [])]
        );
      }

      await conn.query('COMMIT');
      return { project, scan: scanRow, ...summarise(result) };
    } catch (e) {
      await conn.query('ROLLBACK');
      throw e;
    } finally {
      conn.release();
    }
  }

  async function insertIssue(conn, projectId, scanId, f) {
    const issue = (await conn.query(
      `INSERT INTO oasis.issue
          (project_id, fingerprint, type, category, severity, status, title, description, remediation,
           file_path, start_line, end_line, rule_id, cwe, cve, owasp, cvss_vector,
           risk_score, risk_priority, risk_factors, is_new_code, first_seen_scan, last_seen_scan, metadata)
        VALUES ($1,$2,$3,$4,$5,'OPEN',$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19::jsonb,$20,$21,$21,$22::jsonb)
     ON CONFLICT (project_id, fingerprint) DO UPDATE SET last_seen_scan = EXCLUDED.last_seen_scan
        RETURNING id`,
      [
        projectId, f.fingerprint, f.type, f.category || 'UNCATEGORISED', f.severity,
        f.title, f.description || null, f.remediation || null,
        f.file || null, f.startLine || null, f.endLine || null,
        (f.detections && f.detections[0] && f.detections[0].ruleId) || null,
        f.cwe || null, f.cve || null,
        (f.metadata && f.metadata.owasp) || null, (f.metadata && f.metadata.cvssVector) || null,
        (f.risk && f.risk.score) || null, (f.risk && f.risk.priority) || null,
        JSON.stringify((f.risk && f.risk.factors) || []),
        Boolean(f.isNewCode), scanId, JSON.stringify(f.metadata || {}),
      ]
    )).rows[0];

    for (const d of f.detections || []) {
      await conn.query(
        `INSERT INTO oasis.issue_detection (issue_id, scan_id, source, rule_id)
              VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING`,
        [issue.id, scanId, d.source, d.ruleId || null]
      );
    }

    // A secret's VALUE is never written — there is no column for it. Only the
    // hash and the mask the scanner produced.
    if (f.type === 'SECRET' && f.metadata && f.metadata.secretHash) {
      await conn.query(
        `INSERT INTO oasis.secret_finding (issue_id, provider, secret_hash, masked_preview, entropy, in_git_history, commit_sha)
              VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (issue_id) DO NOTHING`,
        [
          issue.id, f.category || null, f.metadata.secretHash, f.metadata.masked || '',
          f.metadata.entropy || null, Boolean(f.metadata.commit), f.metadata.commit || null,
        ]
      );
    }
    return issue;
  }

  const transition = (conn, issueId, from, to, scanId, reason) =>
    conn.query(
      `INSERT INTO oasis.issue_transition (issue_id, from_status, to_status, scan_id, reason, actor)
            VALUES ($1,$2,$3,$4,$5,'scanner')`,
      [issueId, from, to, scanId, reason]
    );

  const latestScan = projectKey =>
    one(
      `SELECT s.* FROM oasis.scan s
         JOIN oasis.project p ON p.id = s.project_id
        WHERE p.key = $1 AND s.status = 'COMPLETED'
        ORDER BY s.started_at DESC LIMIT 1`,
      [projectKey]
    );

  async function projectSummary(projectKey) {
    const summary = await one('SELECT * FROM oasis.project_summary WHERE key = $1', [projectKey]);
    const scan = await latestScan(projectKey);
    const gate = scan
      ? await one('SELECT status, conditions FROM oasis.quality_gate_result WHERE scan_id = $1', [scan.id])
      : null;
    return { ...summary, gate };
  }

  const listIssues = ({ projectKey, status = 'active' } = {}) =>
    many(
      `SELECT i.* FROM oasis.issue i
         JOIN oasis.project p ON p.id = i.project_id
        WHERE p.key = $1
          AND ($2 = 'all'
               OR ($2 = 'active' AND i.status IN ('OPEN','REOPENED','FIXED_PENDING_VERIFICATION'))
               OR i.status = $2)
        ORDER BY i.risk_score DESC NULLS LAST`,
      [projectKey, status]
    );

  return {
    kind: 'postgres',
    upsertProject, getProject, listProjects,
    ingestScan, latestScan, projectSummary, listIssues,
    close: () => (db ? db.end() : Promise.resolve()),
  };
}

module.exports = { createPostgresStore };
