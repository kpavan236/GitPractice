'use strict';
const express = require('express');

// The platform's HTTP surface.
//
// Small on purpose. The desktop app and CI push scans in; dashboards and
// pipelines read summaries and gate verdicts out. Everything else — triage, rule
// authoring, scanning itself — stays where it already works, because a central
// server that duplicates the desktop app's features is two implementations of
// the same behaviour drifting apart.
//
// Storage is injected, so the same API runs on Postgres or in memory. That is
// not only for tests: a team with two repositories should not have to stand up
// a database to use this.

const MAX_FINDINGS_PER_SCAN = 50000;

function createPlatformApi({ store, log = () => {} } = {}) {
  if (!store) throw new Error('a store is required');
  const router = express.Router();

  router.use(express.json({ limit: '64mb' }));

  router.get('/health', (_req, res) => {
    res.json({ ok: true, store: store.kind, counts: store._counts ? store._counts() : undefined });
  });

  // ── Ingest ────────────────────────────────────────────────────────────────
  //
  // One call per scan. The response is what changed, because that is the only
  // part a CI log should print.
  router.post('/v1/scans', (req, res) => {
    try {
      const { project, scan, findings = [], coverage = [], gate = null } = req.body || {};

      if (!project || !project.key) {
        return res.status(400).json({ error: 'project.key is required' });
      }
      if (!scan) {
        return res.status(400).json({ error: 'scan is required' });
      }
      if (!Array.isArray(findings)) {
        return res.status(400).json({ error: 'findings must be an array' });
      }
      // A bound rather than an unbounded write. A runaway scanner posting a
      // million findings would otherwise take the platform down for everyone.
      if (findings.length > MAX_FINDINGS_PER_SCAN) {
        return res.status(413).json({
          error: `too many findings (${findings.length}); the limit is ${MAX_FINDINGS_PER_SCAN}`,
        });
      }
      // Coverage is required, not optional. Without it the reconciler cannot
      // tell "fixed" from "not checked", and it defaults to the safe answer —
      // but silently accepting a scan with no coverage means every issue is
      // permanently unverifiable and nothing ever resolves.
      if (!Array.isArray(coverage) || !coverage.length) {
        return res.status(400).json({
          error: 'coverage is required — without it, resolved and unchecked cannot be told apart',
        });
      }

      store.upsertProject(project);
      const result = store.ingestScan({
        projectKey: project.key,
        scan,
        findings,
        coverage,
        gate,
      });

      log(
        `platform: ${project.key} — ${result.opened} opened, ${result.reopened} reopened, `
        + `${result.resolved} resolved, ${result.unverified} unverified`
      );

      res.status(201).json({
        scanId: result.scan.id,
        project: project.key,
        opened: result.opened,
        reopened: result.reopened,
        resolved: result.resolved,
        unchanged: result.unchanged,
        // Surfaced in the response, not buried: these are the issues this scan
        // could not verify either way.
        unverified: result.unverified,
      });
    } catch (e) {
      log('platform: ingest failed —', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ── Read ──────────────────────────────────────────────────────────────────

  router.get('/v1/projects', (_req, res) => {
    res.json({
      projects: store.listProjects().map(p => store.projectSummary(p.key)),
    });
  });

  router.get('/v1/projects/:key', (req, res) => {
    const project = store.getProject(req.params.key);
    if (!project) return res.status(404).json({ error: 'unknown project' });
    res.json(store.projectSummary(req.params.key));
  });

  router.get('/v1/projects/:key/issues', (req, res) => {
    if (!store.getProject(req.params.key)) return res.status(404).json({ error: 'unknown project' });
    res.json({ issues: store.listIssues({ projectKey: req.params.key, status: req.query.status || 'active' }) });
  });

  // The CI contract, identical in shape to the desktop app's /api/security/gate
  // so a pipeline can point at either without changing the script.
  //
  // 200 proceed, 422 block. Fails closed: a project nobody has ever scanned is
  // not passing, it is unevaluated, and no evidence must never read as clean.
  router.get('/v1/projects/:key/gate', (req, res) => {
    const project = store.getProject(req.params.key);
    if (!project) {
      return res.status(422).json({ status: 'NOT_EVALUATED', blocking: true, reason: 'unknown project' });
    }

    const scan = store.latestScan(req.params.key);
    if (!scan) {
      return res.status(422).json({ status: 'NOT_EVALUATED', blocking: true, reason: 'no completed scan' });
    }
    if (!scan.gate) {
      return res.status(422).json({
        status: 'NOT_EVALUATED',
        blocking: true,
        reason: 'the last scan reported no gate result',
        scanId: scan.id,
      });
    }

    res.status(scan.gate.blocking ? 422 : 200).json({ ...scan.gate, scanId: scan.id, scannedAt: scan.startedAt });
  });

  return router;
}

module.exports = { createPlatformApi, MAX_FINDINGS_PER_SCAN };
