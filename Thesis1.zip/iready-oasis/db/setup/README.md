# Database setup (PostgreSQL)

Complete, runnable setup for every PostgreSQL database described by this repository. Files are **generated** by `scripts/build-db-setup.js` from the source SQL; do not edit them by hand. After changing a source file run:

```bash
npm run db:setup:build            # rewrite the files
node scripts/build-db-setup.js --check   # exit 1 if the files on disk are stale
```

## What gets created

| Database | Source files (in order) |
|----------|-------------------------|
| `oasis_platform` (schema `oasis`) | `db/schema.sql` |
| `customer_db` | `docs/superpowers/db/customer/001_customer_schema.up.sql`, `002_reference_data.sql`, `004_purchase_request.up.sql` |
| `identity_db` | `docs/superpowers/db/identity/001_identity_schema.up.sql`, `002_reference_data.sql` |
| `license_db` | `docs/superpowers/db/license/001_license_schema.up.sql`, `002_reference_data.sql` |
| `billing_db` | `docs/superpowers/db/billing/001_billing_schema.up.sql`, `002_reference_data.sql` |

Not included: the `.down.sql` rollbacks and the `test/` SQL (they are test and rollback tools, not setup). The rule server's SQLite database lives in the `oasis-rule-server` repository and is not set up here. The event outbox/inbox tables referred to in the identity, licence and billing schemas come from a shared library migration that is not in this repository.

The repository has no migrator and no migration-bookkeeping table, so none is created. The schema files are not idempotent; reference-data files use `ON CONFLICT DO NOTHING`.

## Files

| File | Purpose |
|------|---------|
| `00_create_databases_and_roles.sql` | Roles `oasis_app` and `oasis_readonly` (placeholder password `CHANGE_ME_use_a_secret_manager`), the five databases, `CONNECT` grants. Re-runnable. |
| `01_schema_and_seed.sql` | For each database: `\connect`, tables, indexes, views, triggers, functions, constraints, reference data, then table grants for the two roles. Creates the `btree_gist` extension in `license_db` and `billing_db`. |
| `02_optional_dev_data.sql` | **DEV ONLY.** Invented sample rows (addresses end in `.example.test`). Guarded, so re-running does nothing. |

## Run

Run as a PostgreSQL superuser. The files use `psql` meta-commands (`\connect`, `\set`, `\gset`), so they need `psql`, not another SQL client. Order matters.

```bash
export PGHOST=localhost PGPORT=5432 PGUSER=postgres   # PGPASSWORD from your secret manager, not from a file in git
psql -d postgres -f db/setup/00_create_databases_and_roles.sql
psql -d postgres -f db/setup/01_schema_and_seed.sql
psql -d postgres -f db/setup/02_optional_dev_data.sql   # local development only
```

Before using anything beyond a throwaway local server, edit the placeholder passwords in file 00 (or `ALTER ROLE` afterwards) using values from a secret manager. Never commit real passwords.

Using Docker instead of a local `psql`:

```bash
docker exec -i <container> psql -U postgres -d postgres < db/setup/00_create_databases_and_roles.sql
```

### Prefix option (throwaway copies)

All three files accept a psql variable `setup_prefix` that is prepended to every database and role name, so a scratch copy never touches existing databases:

```bash
psql -d postgres -v setup_prefix=scratch_ -f db/setup/00_create_databases_and_roles.sql
psql -d postgres -v setup_prefix=scratch_ -f db/setup/01_schema_and_seed.sql
```

This creates `scratch_oasis_platform`, `scratch_customer_db`, `scratch_oasis_app`, and so on. Use the same prefix on every file.

## Verify

```sql
-- in oasis_platform
SELECT count(*) FROM information_schema.tables WHERE table_schema = 'oasis';   -- 17

-- in customer_db / identity_db / license_db / billing_db
SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';  -- 21 / 28 / 41 / 20
SELECT extname FROM pg_extension WHERE extname = 'btree_gist';                 -- license_db and billing_db

-- after 02_optional_dev_data.sql
SELECT count(*) FROM customer;               -- customer_db: 6
SELECT count(*) FROM v_license;              -- license_db: 3
SELECT count(*) FROM entitlement_current;    -- license_db: 5
```

The table counts are those observed when the files were verified on PostgreSQL 16; they change if the source SQL changes. The constraint tests in `docs/superpowers/db/<name>/test/*.sql` expect an empty database (no dev data), so run them after file 01 only.

## Reset

Drop and recreate. This destroys data; never run it against a shared environment.

```sql
-- connected to the postgres database
DROP DATABASE oasis_platform;
DROP DATABASE customer_db;
DROP DATABASE identity_db;
DROP DATABASE license_db;
DROP DATABASE billing_db;
DROP ROLE oasis_app;
DROP ROLE oasis_readonly;
```

Then run the three files again. To reset only the sample data, recreate the affected database and run files 01 and 02 for it.

## Troubleshooting

- `syntax error ... \connect` or similar: the file was run with a client other than `psql`.
- `database ... already exists` while running 01: schema files are not idempotent. Drop the database (see Reset) or use a new `setup_prefix`.
- `permission denied to create extension "btree_gist"`: run as a superuser, or as the database owner on PostgreSQL 13 or newer (the extension is trusted).
- Password prompt after `\connect` over TCP: set `PGPASSWORD` or use a `~/.pgpass` entry (outside the repo).

## Which service uses which database

`platform/server.js` reads `DATABASE_URL` and expects `oasis_platform` (tables in schema `oasis`). The OASIS desktop app never connects to a database; `customer_db`, `identity_db`, `license_db` and `billing_db` belong to the licence service (see `docs/superpowers/specs/2026-10-08-licence-service-api-contract.md`). Note that `platform/store/postgres.js` states it was written without a live database to test against.
