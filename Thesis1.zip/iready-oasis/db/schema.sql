-- =============================================================================
-- i-Ready OASIS — central security platform schema (PostgreSQL 14+)
-- =============================================================================
--
-- WHERE THIS RUNS, AND WHERE IT DOES NOT.
--
-- This is the schema for the CENTRAL server: the thing that aggregates scans
-- from many developers and CI jobs, evaluates quality gates, and answers "is
-- this repository getting better". It is NOT the desktop app's storage. The
-- desktop app keeps its JSON store in ~/.oasis-security and must keep working
-- with no server at all, because "nothing may be installed" is the constraint
-- the whole product is built around and a Postgres dependency would end it.
--
-- The desktop app therefore PUSHES to this schema and never reads through it.
--
-- THE RULE BUNDLE IS NOT IN HERE EITHER, DELIBERATELY.
--
-- Rules are authored as files, compile-checked, and shipped as an Ed25519-signed
-- bundle precisely because a rule controls what the scanner reports and can be
-- crafted to HIDE findings. Moving rule text into a table anyone can UPDATE
-- destroys that guarantee. What belongs here is which bundle VERSION produced a
-- finding, so any result can be traced back to a signed artifact — hence
-- `scan.rule_bundle_version` rather than a `rule` table.
--
-- CONVENTIONS
--   * Identity: `bigint generated always as identity`. Findings arrive in the
--     tens of thousands per scan and an int would be a migration in a year.
--   * Times: `timestamptz`, always. A build failing at 23:00 in one timezone
--     and passing in another is the classic reason not to use `timestamp`.
--   * Enumerations are CHECK constraints, not PG enums: adding a value to a PG
--     enum is a migration that locks, and these lists (finding types, statuses)
--     change as scanners are added. They mirror server/security/finding.js.

BEGIN;

CREATE SCHEMA IF NOT EXISTS oasis;
SET search_path TO oasis, public;

-- ── Projects ────────────────────────────────────────────────────────────────
--
-- A project is a repository. `criticality` is not decoration: the risk engine
-- already scores a HIGH on an internet-facing production service above a
-- CRITICAL in a scratch repository, and that judgement needs somewhere to live
-- that is not one developer's laptop.

CREATE TABLE project (
  id                bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  key               text        NOT NULL UNIQUE,          -- 'iready-core'
  name              text        NOT NULL,
  repository_url    text,
  default_branch    text        NOT NULL DEFAULT 'main',
  criticality       text        NOT NULL DEFAULT 'MEDIUM'
                                CHECK (criticality IN ('CRITICAL','HIGH','MEDIUM','LOW')),
  internet_facing   boolean     NOT NULL DEFAULT false,
  handles_pii       boolean     NOT NULL DEFAULT false,
  owner_team        text,
  quality_gate_id   bigint,                                -- FK added after gate table
  archived_at       timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

COMMENT ON COLUMN project.handles_pii IS
  'Drives risk scoring and reporting. Student and customer data raises the '
  'consequence of any finding in this repository.';

-- ── Scans ───────────────────────────────────────────────────────────────────
--
-- One row per scan run. `coverage` is a first-class column rather than a
-- detail, because the difference between "no container findings" and "nobody
-- scanned the container" is the single most dangerous ambiguity this product
-- has, and a schema that cannot express it will produce dashboards that lie.

CREATE TABLE scan (
  id                   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  project_id           bigint      NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  external_id          text        NOT NULL,               -- the desktop/CI scan id
  status               text        NOT NULL
                                   CHECK (status IN ('QUEUED','RUNNING','COMPLETED','FAILED','CANCELLED')),
  trigger              text        NOT NULL DEFAULT 'MANUAL'
                                   CHECK (trigger IN ('MANUAL','CI','SCHEDULED','PULL_REQUEST')),

  git_ref              text,                               -- branch or tag
  commit_sha           text,
  base_commit_sha      text,                               -- what "new code" is measured against
  pull_request         text,

  started_at           timestamptz NOT NULL,
  finished_at          timestamptz,
  duration_ms          integer GENERATED ALWAYS AS
                         (CASE WHEN finished_at IS NULL THEN NULL
                               ELSE (EXTRACT(EPOCH FROM (finished_at - started_at)) * 1000)::integer END) STORED,

  -- Provenance of the analysis itself. Without these, a change in results
  -- cannot be attributed to a code change rather than a rule change.
  rule_bundle_version  text,
  scanner_version      text,

  -- Per-capability coverage, exactly as the orchestrator computes it:
  -- [{"type":"SAST","analysed":true,"by":["AST_SAST"],"truncated":false}]
  coverage             jsonb       NOT NULL DEFAULT '[]'::jsonb,
  partial              boolean     NOT NULL DEFAULT false,
  ignored_count        integer     NOT NULL DEFAULT 0,
  error                text,
  created_at           timestamptz NOT NULL DEFAULT now(),

  UNIQUE (project_id, external_id)
);

CREATE INDEX scan_project_started_idx ON scan (project_id, started_at DESC);
CREATE INDEX scan_commit_idx          ON scan (project_id, commit_sha);
-- Partial index: "the latest completed scan for this project" is the single
-- most frequent query the dashboard makes.
CREATE INDEX scan_completed_idx       ON scan (project_id, started_at DESC) WHERE status = 'COMPLETED';

-- ── Issues ──────────────────────────────────────────────────────────────────
--
-- The core table, and the one whose identity model decides whether the product
-- is usable. An issue is a PROBLEM, not a sighting: it persists across scans,
-- and `fingerprint` is what makes that possible.
--
-- The fingerprint is computed by the scanner as
--   hash(rule_id + normalised_relative_path + AST context tokens)
-- deliberately WITHOUT the line number, so reformatting a file or inserting an
-- import does not close every issue in it and open a new one. That property is
-- the difference between a triage queue people maintain and one they abandon
-- after the first big refactor.

CREATE TABLE issue (
  id                bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  project_id        bigint      NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  fingerprint       text        NOT NULL,

  type              text        NOT NULL
                                CHECK (type IN ('SAST','SCA','SECRET','SBOM','LICENSE',
                                                'CONTAINER','IAC','DAST','API','CLOUD','QUALITY')),
  category          text        NOT NULL,
  severity          text        NOT NULL
                                CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW','INFO')),
  status            text        NOT NULL DEFAULT 'OPEN'
                                CHECK (status IN ('OPEN','REOPENED','FIXED_PENDING_VERIFICATION',
                                                  'RESOLVED','SUPPRESSED','FALSE_POSITIVE')),

  title             text        NOT NULL,
  description       text,
  remediation       text,

  file_path         text,
  start_line        integer,
  end_line          integer,

  rule_id           text,
  cwe               text,
  cve               text,
  owasp             text,
  cvss_vector       text,

  -- Explainable risk. The score is stored because it is expensive to recompute
  -- across a fleet, and the factors are stored because a score nobody can
  -- interrogate gets ignored the first time it looks wrong.
  risk_score        integer     CHECK (risk_score BETWEEN 0 AND 100),
  risk_priority     text        CHECK (risk_priority IN ('P1','P2','P3','P4')),
  risk_factors      jsonb,

  -- "Clean as you code". Set when the issue was introduced by the diff the scan
  -- was measured against, so a gate can fail on new problems without demanding
  -- the backlog be cleared first — which is the only realistic path from a
  -- 700-finding backlog to a green build that still means something.
  is_new_code       boolean     NOT NULL DEFAULT false,
  introduced_commit text,

  first_seen_scan   bigint      REFERENCES scan(id) ON DELETE SET NULL,
  last_seen_scan    bigint      REFERENCES scan(id) ON DELETE SET NULL,
  first_seen_at     timestamptz NOT NULL DEFAULT now(),
  last_seen_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at       timestamptz,

  metadata          jsonb       NOT NULL DEFAULT '{}'::jsonb,

  -- One row per problem per project. This is what turns a stream of sightings
  -- into a queue with history.
  UNIQUE (project_id, fingerprint)
);

CREATE INDEX issue_open_idx     ON issue (project_id, severity, risk_score DESC)
                                   WHERE status IN ('OPEN','REOPENED','FIXED_PENDING_VERIFICATION');
CREATE INDEX issue_type_idx     ON issue (project_id, type);
CREATE INDEX issue_new_code_idx ON issue (project_id, is_new_code) WHERE is_new_code;
CREATE INDEX issue_cve_idx      ON issue (cve) WHERE cve IS NOT NULL;
CREATE INDEX issue_file_idx     ON issue (project_id, file_path);
CREATE INDEX issue_metadata_idx ON issue USING gin (metadata);

-- Which scanners reported an issue, and when. One issue, many detections: two
-- engines agreeing is stronger evidence than either alone, and collapsing them
-- into one row would throw that away.
CREATE TABLE issue_detection (
  issue_id     bigint      NOT NULL REFERENCES issue(id) ON DELETE CASCADE,
  scan_id      bigint      NOT NULL REFERENCES scan(id)  ON DELETE CASCADE,
  source       text        NOT NULL,      -- 'AST_SAST', 'GITLEAKS', 'TRIVY'
  rule_id      text,
  detected_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (issue_id, scan_id, source)
);

CREATE INDEX issue_detection_scan_idx ON issue_detection (scan_id);

-- Every status change, with an author and a reason.
--
-- Suppression without an accountable owner is how a security backlog quietly
-- empties itself, so the reason is NOT NULL for the states that hide a finding.
CREATE TABLE issue_transition (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  issue_id      bigint      NOT NULL REFERENCES issue(id) ON DELETE CASCADE,
  from_status   text,
  to_status     text        NOT NULL,
  actor         text,                      -- employee identifier; treat as PII
  reason        text,
  scan_id       bigint      REFERENCES scan(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT hiding_an_issue_needs_a_reason
    CHECK (to_status NOT IN ('SUPPRESSED','FALSE_POSITIVE') OR reason IS NOT NULL)
);

CREATE INDEX issue_transition_issue_idx ON issue_transition (issue_id, created_at DESC);

-- ── Secrets ─────────────────────────────────────────────────────────────────
--
-- A separate table for one reason: THE SECRET IS NEVER STORED. Only a SHA-256
-- for deduplication and a masked preview for recognition. A security platform
-- that copies credentials into its own database is a second copy of the leak,
-- and giving secrets their own table with no value column makes that structural
-- rather than a convention someone can forget.

CREATE TABLE secret_finding (
  id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  issue_id        bigint      NOT NULL UNIQUE REFERENCES issue(id) ON DELETE CASCADE,
  provider        text,                    -- 'aws-access-token'
  secret_hash     text        NOT NULL,    -- SHA-256; NEVER the credential
  masked_preview  text        NOT NULL,    -- 'AKIA************LKEY'
  entropy         numeric(5,2),

  -- A secret found in history is still live until rotated; the commit is what
  -- makes "we removed it" checkable.
  in_git_history  boolean     NOT NULL DEFAULT false,
  commit_sha      text,
  committed_at    timestamptz,
  author_email    text,                    -- PII: employee identifier

  -- Live-validity checking is opt-in because it transmits a credential to its
  -- issuer. Recorded so a rotation can be proven rather than assumed.
  verified        boolean     NOT NULL DEFAULT false,
  verified_active boolean,
  verified_at     timestamptz,
  rotated_at      timestamptz,

  CONSTRAINT secret_hash_is_a_hash CHECK (secret_hash ~ '^[0-9a-f]{64}$')
);

CREATE INDEX secret_hash_idx ON secret_finding (secret_hash);

-- ── Dependencies ────────────────────────────────────────────────────────────

CREATE TABLE dependency (
  id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  project_id     bigint      NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  scan_id        bigint      NOT NULL REFERENCES scan(id)    ON DELETE CASCADE,
  ecosystem      text        NOT NULL,     -- 'npm', 'maven', 'pypi'
  name           text        NOT NULL,
  version        text        NOT NULL,
  purl           text,
  manifest_path  text,
  -- Direct and transitive are different remediation problems: one is an edit,
  -- the other is a negotiation with whatever pulled it in.
  is_direct      boolean     NOT NULL DEFAULT true,
  depth          integer     NOT NULL DEFAULT 0,
  parent_name    text,
  license        text,
  license_risk   text        CHECK (license_risk IN ('PROHIBITED','RESTRICTED','RECIPROCAL','PERMISSIVE','UNKNOWN')),
  latest_version text,

  UNIQUE (scan_id, ecosystem, name, version, manifest_path)
);

CREATE INDEX dependency_project_idx ON dependency (project_id, ecosystem, name);
CREATE INDEX dependency_purl_idx    ON dependency (purl);

-- Advisories are shared facts about the world, not facts about one project, so
-- they are stored once and joined. Source data is OSV/GHSA (CC0).
CREATE TABLE advisory (
  id             text        PRIMARY KEY,  -- 'GHSA-xxxx' or 'CVE-2021-44228'
  aliases        text[]      NOT NULL DEFAULT '{}',
  summary        text,
  details        text,
  severity       text        CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW','INFO')),
  cvss_vector    text,
  cvss_score     numeric(3,1),
  -- Exploitation reality, which outranks severity for scheduling: a MEDIUM
  -- being exploited today beats a CRITICAL nobody has ever weaponised.
  epss_score     numeric(6,5),
  known_exploited boolean    NOT NULL DEFAULT false,
  kev_added_at   date,
  published_at   timestamptz,
  modified_at    timestamptz,
  raw            jsonb                     -- the OSV record, verbatim
);

CREATE INDEX advisory_kev_idx  ON advisory (known_exploited) WHERE known_exploited;
CREATE INDEX advisory_epss_idx ON advisory (epss_score DESC NULLS LAST);

CREATE TABLE dependency_vulnerability (
  dependency_id  bigint NOT NULL REFERENCES dependency(id) ON DELETE CASCADE,
  advisory_id    text   NOT NULL REFERENCES advisory(id)   ON DELETE CASCADE,
  issue_id       bigint          REFERENCES issue(id)      ON DELETE SET NULL,
  fixed_version  text,
  PRIMARY KEY (dependency_id, advisory_id)
);

-- ── IaC checks ──────────────────────────────────────────────────────────────
--
-- An IaC finding is about a RESOURCE, not a line. In a file with forty
-- resources, "line 312" is not actionable and "aws_s3_bucket.logs" is.

CREATE TABLE iac_check (
  id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  issue_id       bigint      NOT NULL UNIQUE REFERENCES issue(id) ON DELETE CASCADE,
  framework      text        NOT NULL CHECK (framework IN ('TERRAFORM','KUBERNETES','DOCKERFILE','CLOUDFORMATION','HELM','ARM')),
  resource_type  text        NOT NULL,     -- 'aws_s3_bucket'
  resource_name  text        NOT NULL,
  policy_id      text,                     -- 'CKV2_AWS_34'
  -- Where an ingested policy came from, so a finding can be traced to its
  -- upstream project and licence.
  policy_source  text,                     -- 'checkov'
  evaluated_by   text        NOT NULL DEFAULT 'IAC_POLICY'
);

CREATE INDEX iac_resource_idx ON iac_check (resource_type, policy_id);

-- ── Quality profiles and gates ──────────────────────────────────────────────
--
-- A profile says WHICH rules run. A gate says WHAT FAILS A BUILD. They are
-- separate because they change for different reasons and by different people:
-- security tunes the profile, delivery negotiates the gate.

CREATE TABLE quality_profile (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name         text        NOT NULL UNIQUE,
  description  text,
  is_default   boolean     NOT NULL DEFAULT false,
  -- Deviations from the shipped bundle, not a copy of it. The bundle stays the
  -- signed source of truth; this records only what an organisation turned off
  -- or re-graded, which is the part worth auditing.
  rule_overrides jsonb     NOT NULL DEFAULT '[]'::jsonb,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- Only one default profile, enforced rather than assumed.
CREATE UNIQUE INDEX quality_profile_one_default ON quality_profile (is_default) WHERE is_default;

CREATE TABLE quality_gate (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name         text        NOT NULL UNIQUE,
  description  text,
  is_default   boolean     NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX quality_gate_one_default ON quality_gate (is_default) WHERE is_default;

-- One row per threshold. Rows rather than a JSON blob so a gate can be queried
-- ("which gates block on secrets?") and changed field by field with an audit
-- trail, instead of being replaced wholesale.
CREATE TABLE quality_gate_condition (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  gate_id     bigint NOT NULL REFERENCES quality_gate(id) ON DELETE CASCADE,
  metric      text   NOT NULL
                     CHECK (metric IN ('vulnerabilities','secrets','high_severity_cves',
                                       'critical_issues','blocker_issues','iac_misconfigurations',
                                       'license_violations','coverage_gaps','risk_score')),
  -- The distinction "clean as you code" rests on. A gate on overall code fails
  -- forever on a legacy repository and gets switched off; a gate on new code
  -- holds the line from today.
  scope       text   NOT NULL DEFAULT 'NEW_CODE' CHECK (scope IN ('NEW_CODE','OVERALL')),
  operator    text   NOT NULL CHECK (operator IN ('GT','GTE','LT','LTE','EQ')),
  threshold   numeric NOT NULL,
  severity    text   CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW','INFO')),

  UNIQUE (gate_id, metric, scope, severity)
);

ALTER TABLE project
  ADD CONSTRAINT project_quality_gate_fk
  FOREIGN KEY (quality_gate_id) REFERENCES quality_gate(id) ON DELETE SET NULL;

ALTER TABLE project
  ADD COLUMN quality_profile_id bigint REFERENCES quality_profile(id) ON DELETE SET NULL;

-- The evaluated result for one scan. Stored rather than recomputed: a CI job
-- asks for it repeatedly, and a gate that could change answer between two reads
-- of the same scan would be unusable as a build blocker.
CREATE TABLE quality_gate_result (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  scan_id       bigint      NOT NULL UNIQUE REFERENCES scan(id) ON DELETE CASCADE,
  gate_id       bigint      REFERENCES quality_gate(id) ON DELETE SET NULL,
  status        text        NOT NULL CHECK (status IN ('PASSED','FAILED','WARN','NOT_EVALUATED')),
  -- Which conditions passed and which failed, with actual values. A red build
  -- that cannot say which threshold it crossed is a red build people override.
  conditions    jsonb       NOT NULL DEFAULT '[]'::jsonb,
  evaluated_at  timestamptz NOT NULL DEFAULT now()
);

-- ── Trend ───────────────────────────────────────────────────────────────────
--
-- Counts only. The question is "is this getting better", and storing whole
-- findings per day to answer it would grow without bound.

CREATE TABLE project_metric_daily (
  project_id   bigint      NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  day          date        NOT NULL,
  open_total   integer     NOT NULL DEFAULT 0,
  by_severity  jsonb       NOT NULL DEFAULT '{}'::jsonb,
  by_type      jsonb       NOT NULL DEFAULT '{}'::jsonb,
  new_code_total integer   NOT NULL DEFAULT 0,
  risk_score   integer,
  PRIMARY KEY (project_id, day)
);

-- ── Views ───────────────────────────────────────────────────────────────────

-- What the dashboard asks for. Kept as a view so the definition of "active"
-- lives in one place instead of being re-expressed in every query that needs
-- it — which is how a suppressed finding eventually reappears in one report and
-- not another.
CREATE VIEW active_issue AS
  SELECT * FROM issue
   WHERE status IN ('OPEN','REOPENED','FIXED_PENDING_VERIFICATION');

CREATE VIEW project_summary AS
  SELECT
    p.id,
    p.key,
    p.name,
    p.criticality,
    count(i.id)                                        AS open_issues,
    count(i.id) FILTER (WHERE i.severity = 'CRITICAL') AS critical,
    count(i.id) FILTER (WHERE i.severity = 'HIGH')     AS high,
    count(i.id) FILTER (WHERE i.is_new_code)           AS new_code_issues,
    count(i.id) FILTER (WHERE i.type = 'SECRET')       AS secrets,
    max(i.risk_score)                                  AS worst_risk,
    (SELECT max(started_at) FROM scan s
      WHERE s.project_id = p.id AND s.status = 'COMPLETED') AS last_scanned_at
  FROM project p
  LEFT JOIN active_issue i ON i.project_id = p.id
  WHERE p.archived_at IS NULL
  GROUP BY p.id;

COMMIT;

-- =============================================================================
-- PII NOTE, for whoever operates this.
--
-- Three columns hold personal data, all of them employee identifiers rather
-- than student or customer data: issue_transition.actor,
-- secret_finding.author_email, and project.owner_team. They exist because
-- accountability for a suppression decision is the point of recording it.
-- They are in scope for retention policy and for any data-subject request, and
-- should be the first thing considered before this database is replicated
-- anywhere outside its primary region.
--
-- No student, customer, or assessment data belongs in this schema at any point.
-- =============================================================================
