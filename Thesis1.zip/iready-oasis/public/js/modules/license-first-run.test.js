'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Loads the real license.js into a sandbox with a tiny fake page and a fake network, to check
// what a brand-new install shows first and when its trial starts.

const UNREGISTERED = {
  status: 'unregistered', locked: true, reason: 'no_entitlement', features: [], tokenError: null, trialDays: 7,
  message: 'Start your 7-day trial, buy a licence, or enter a key you already have.',
};
const EXPIRED = { status: 'expired', locked: true, reason: 'trial_expired', features: [], message: 'Your trial has ended.' };
const TRIAL = { status: 'trial', locked: false, reason: 'trial_active', features: [], daysRemaining: 7, hoursRemaining: 168, expiresAt: Date.now() + 7 * 864e5 };

function load({ status, startOk = true }) {
  const calls = [];
  const elements = {};
  const makeEl = id => {
    const classes = new Set();
    return { id, className: '', innerHTML: '', textContent: '', style: {},
      classList: { add: c => classes.add(c), remove: c => classes.delete(c), contains: c => classes.has(c), toggle: (c, on) => (on === undefined ? (classes.has(c) ? classes.delete(c) : classes.add(c)) : (on ? classes.add(c) : classes.delete(c))) },
      remove() { delete elements[id]; }, prepend() {}, appendChild() {} };
  };
  elements['main-app'] = makeEl('main-app');
  elements['main-app'].classList.add('hidden');            // the setup wizard is what is on screen
  const sandbox = {
    API: 'http://app.test', sessionId: 'sess-1', console, setInterval() {}, clearInterval() {}, alert() {}, toast() {}, autoResumeCalls: 0,
    autoResume() { sandbox.autoResumeCalls += 1; },
    location: { reload() { calls.push('RELOAD'); } },
    document: {
      readyState: 'complete', hidden: false, addEventListener() {},
      getElementById: id => elements[id] || null,
      createElement: () => makeEl(''),
      body: { appendChild(el) { elements[el.id] = el; } },
      querySelectorAll: () => [],
      querySelector: () => null,
    },
    fetch: async (url, opts = {}) => {
      const u = String(url);
      calls.push(`${opts.method || 'GET'} ${u.replace('http://app.test', '')}`);
      if (u.endsWith('/api/license/status')) return { ok: true, status: 200, json: async () => status };
      if (u.endsWith('/api/license/trial')) return startOk
        ? { ok: true, status: 200, json: async () => TRIAL }
        : { ok: false, status: 503, json: async () => ({ message: 'Could not reach the licence service' }) };
      return { ok: true, status: 200, json: async () => ({}) };
    },
  };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'license.js'), 'utf8'), sandbox);
  const overlay = () => elements['license-overlay'];
  const shown = () => !!overlay() && !overlay().classList.contains('hidden');
  return { sandbox, calls, shown, overlay, run: code => vm.runInContext(code, sandbox) };
}
const tick = () => new Promise(r => setImmediate(r));

test('a brand-new install shows the licence page first, even though the setup wizard is what is on screen', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  assert.equal(t.shown(), true, 'the licence page is up');
  assert.match(t.overlay().innerHTML, /Start your 7-day trial, buy a licence, or enter a key you already have\./);
  assert.match(t.overlay().innerHTML, /Start 7-day free trial/);
  assert.match(t.overlay().innerHTML, /Activate licence/, 'and an Activate licence button');
  assert.match(t.overlay().innerHTML, /Buy a licence/, 'and a Buy a licence button');
  assert.doesNotMatch(t.overlay().innerHTML, /Already have a licence key|lic-key/, 'the key box is gone');
});

test('the licence page cannot be dismissed on a machine with no licence: there is nothing behind it to use', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  assert.doesNotMatch(t.overlay().innerHTML, /lic-dismiss-btn/);
});

test('"Start trial" takes the user to setup and does NOT start the trial yet', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  t.run('startLicenseTrial()');
  await tick();
  assert.equal(t.shown(), false, 'the licence page gets out of the way');
  assert.equal(t.sandbox.autoResumeCalls, 1, 'a saved setup is picked up straight away');
  assert.ok(!t.calls.some(c => c === 'POST /api/license/trial'), 'no trial yet: it starts when GitHub and Jenkins connect');
});

test('once the user has chosen the trial, the licence page does not come back over the wizard', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  t.run('startLicenseTrial()');
  t.run('applyLicenseStatus(_license)');               // the minute-by-minute refresh
  assert.equal(t.shown(), false);
});

test('connecting setup does not start a trial the user never chose', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  const ok = await t.run('ensureLicenseReady()');
  assert.equal(ok, false);
  assert.equal(t.shown(), true, 'the licence page is shown so they can choose');
  assert.ok(!t.calls.some(c => c === 'POST /api/license/trial'));
});

test('after choosing, connecting setup starts the trial, with the setup session, and carries on', async () => {
  const t = load({ status: UNREGISTERED });
  await tick(); await tick();
  t.run('startLicenseTrial()');
  const ok = await t.run('ensureLicenseReady()');
  assert.equal(ok, true);
  assert.ok(t.calls.includes('POST /api/license/trial'));
  assert.equal(t.shown(), false);
  assert.ok(!t.calls.includes('RELOAD'), 'no page reload in the middle of setup');
});

test('if the trial cannot start, the licence page comes back with the reason, and Start trial now retries for real', async () => {
  const t = load({ status: UNREGISTERED, startOk: false });
  await tick(); await tick();
  t.run('startLicenseTrial()');
  assert.equal(await t.run('ensureLicenseReady()'), false);
  assert.equal(t.shown(), true);
  t.calls.length = 0;
  t.run('startLicenseTrial()');                        // a retry is a real request this time
  await tick();
  assert.ok(t.calls.includes('POST /api/license/trial'), 'the retry reaches the licence service');
});

test('an expired trial still gets the licence page at once, with no Start trial button', async () => {
  const t = load({ status: EXPIRED });
  await tick(); await tick();
  assert.equal(t.shown(), true);
  assert.doesNotMatch(t.overlay().innerHTML, /lic-trial-btn/);
});

test('a machine that already has a trial goes straight to the app', async () => {
  const t = load({ status: TRIAL });
  await tick(); await tick();
  assert.equal(t.shown(), false);
  assert.equal(await t.run('ensureLicenseReady()'), true);
});
