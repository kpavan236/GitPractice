'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { validateSupportTicket, validateContactDetails, describeSubmitResult } = require('./usermenu');

// The support-ticket form never lets an empty or half-filled ticket through, and
// the answer from the server is turned into the one sentence the person sees.

test('a title and description together are valid', () => {
  const result = validateSupportTicket({ title: 'Scan hangs on large repo', description: 'It never finishes.' });
  assert.deepEqual(result, { valid: true, error: null });
});

test('an empty title is rejected', () => {
  const result = validateSupportTicket({ title: '', description: 'Details here' });
  assert.equal(result.valid, false);
  assert.match(result.error, /title/i);
});

test('a whitespace-only title is rejected, not just an empty string', () => {
  const result = validateSupportTicket({ title: '   ', description: 'Details here' });
  assert.equal(result.valid, false);
});

test('a missing description is rejected', () => {
  const result = validateSupportTicket({ title: 'Something broke', description: '' });
  assert.equal(result.valid, false);
  assert.match(result.error, /description/i);
});

test('an overly long title is rejected with a specific reason', () => {
  const result = validateSupportTicket({ title: 'x'.repeat(121), description: 'Details' });
  assert.equal(result.valid, false);
  assert.match(result.error, /120/);
});

test('a title at the length limit is accepted', () => {
  const result = validateSupportTicket({ title: 'x'.repeat(120), description: 'Details' });
  assert.equal(result.valid, true);
});

test('a name and an email address are both needed to contact support', () => {
  assert.deepEqual(validateContactDetails({ contactName: 'Nia Patel', email: 'nia@example.test' }), { valid: true, error: null });
  assert.match(validateContactDetails({ contactName: '', email: 'nia@example.test' }).error, /name/i);
  assert.match(validateContactDetails({ contactName: 'Nia', email: '' }).error, /email/i);
  assert.match(validateContactDetails({ contactName: 'Nia', email: 'not-an-address' }).error, /email/i);
});

test('feedback may leave the email blank, but a typed one must look like an address', () => {
  assert.equal(validateContactDetails({ email: '' }, { emailRequired: false, nameRequired: false }).valid, true);
  assert.equal(validateContactDetails({ email: 'nope' }, { emailRequired: false, nameRequired: false }).valid, false);
});

test('a stored submission names its reference', () => {
  assert.deepEqual(describeSubmitResult(200, { ok: true, reference: 'SR-000012' }), { kind: 'success', message: 'Thanks — received. Your reference is SR-000012.' });
});

test('a submission kept only on this computer says so, and is not shown as a plain success', () => {
  const r = describeSubmitResult(202, { ok: true, savedLocally: true });
  assert.equal(r.kind, 'warning');
  assert.match(r.message, /saved on this computer/i);
  assert.match(r.message, /could not reach support/i);
});

test('a refusal shows the service\'s own words and the first field problem', () => {
  const r = describeSubmitResult(400, { error: 'Some details need fixing.', errors: { email: 'Enter a valid email address.' } });
  assert.equal(r.kind, 'error');
  assert.match(r.message, /Enter a valid email address\./);
});

test('anything else is an error with a plain message', () => {
  assert.equal(describeSubmitResult(503, { error: 'Could not reach support.' }).kind, 'error');
  assert.equal(describeSubmitResult(500, null).kind, 'error');
});
