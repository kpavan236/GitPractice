// =============================================================================
// Security — the read-only Rules view (installed-release mode)
// =============================================================================
// Shows the rules of the installed release and lets each project switch rules off or change their severity.
// Rule definitions are not edited here: they come from the central rules service. Overrides are kept on this machine.
//
// Everything is built with createElement and textContent. Rule text comes from a service and is never parsed as HTML.
// Pure helpers and the renderer take the document as an argument so they can be unit-tested without a browser.

const RRO_SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
const RRO_LEGACY_TEXT = 'Rules come from the rule server; installed-release mode is not enabled (set OASIS_ENGINE=installed).';

function rroBanner(view, locale) {
  const dev = Array.isArray(view.devKeys) && view.devKeys.length ? ` Development key (${view.devKeys.join(', ')}): this release is trusted from a local file, not the pinned production keys.` : '';
  if (!view.release) return `No rules release is installed yet.${dev}`;
  const when = view.release.installedAt ? new Date(view.release.installedAt).toLocaleString(locale) : 'at an unknown time';
  return `Using rules from release ${view.release.number}, updated ${when}.${dev}`;
}

function rroState(view) {
  if (view.mode === 'legacy') return 'legacy';
  if (!view.release || !view.rules.length) return view.updateError ? 'error' : 'empty';
  return 'ready';
}

function rroDraftFrom(overrides) {
  const o = overrides || {};
  return { disabled: [...(o.disabled || [])], severity: { ...(o.severity || {}) } };
}
function rroSetDisabled(draft, id, off) {
  const has = draft.disabled.includes(id);
  if (off && !has) draft.disabled.push(id);
  if (!off && has) draft.disabled = draft.disabled.filter((x) => x !== id);
}
function rroSetSeverity(draft, rule, severity) {
  if (!severity || severity === rule.severity) delete draft.severity[rule.id];
  else draft.severity[rule.id] = severity;
}
function rroIsOverridden(draft, rule) {
  return draft.disabled.includes(rule.id) || Object.prototype.hasOwnProperty.call(draft.severity, rule.id);
}
function rroBody(draft) { return { disabled: [...draft.disabled], severity: { ...draft.severity } }; }
function rroReset(draft) { draft.disabled = []; draft.severity = {}; }

function rroEl(doc, tag, props = {}, ...kids) {
  const el = doc.createElement(tag);
  if (props.cls) el.className = props.cls;
  if (props.text !== undefined) el.textContent = props.text;
  for (const [k, v] of Object.entries(props.attrs || {})) el.setAttribute(k, v);
  if (kids.length) el.append(...kids);
  return el;
}

function rroRender(doc, root, view, { projects, project, draft, handlers }) {
  const h = handlers || {};
  const state = rroState(view);
  const parts = [];

  if (state === 'legacy') {
    parts.push(rroEl(doc, 'div', { cls: 'sr-note', text: RRO_LEGACY_TEXT, attrs: { role: 'status' } }));
    root.replaceChildren(...parts);
    return;
  }

  const banner = rroEl(doc, 'div', { cls: 'sr-note rro-banner', attrs: { role: 'status' } }, rroEl(doc, 'span', { text: rroBanner(view) }));
  if (view.updateAvailable) banner.append(rroEl(doc, 'strong', { cls: 'rro-update', text: ' Update available: a newer rules release needs a newer version of this app.' }));
  parts.push(banner);
  if (view.updateError) parts.push(rroEl(doc, 'div', { cls: 'sr-note sr-error', text: view.updateError.message, attrs: { role: 'alert' } }));

  if (state !== 'ready') {
    if (state === 'empty') parts.push(rroEl(doc, 'div', { cls: 'sr-empty', text: 'No rules are installed yet. They download from the rules service when this machine can reach it.' }));
    root.replaceChildren(...parts);
    return;
  }

  // Project picker and the Save/Reset buttons.
  const select = rroEl(doc, 'select', { cls: 'sec-select', attrs: { id: 'rro-project', 'aria-label': 'Project' } });
  for (const p of projects) { const o = rroEl(doc, 'option', { text: p, attrs: { value: p } }); select.append(o); }
  select.value = project || '';
  select.addEventListener('change', () => h.project && h.project(select.value));
  const save = rroEl(doc, 'button', { cls: 'btn btn-primary btn-sm', text: 'Save', attrs: { type: 'button' } });
  save.addEventListener('click', () => h.save && h.save());
  const reset = rroEl(doc, 'button', { cls: 'btn btn-ghost btn-sm', text: 'Reset', attrs: { type: 'button' } });
  reset.addEventListener('click', () => h.reset && h.reset());
  parts.push(rroEl(doc, 'div', { cls: 'sr-bar' },
    rroEl(doc, 'label', { cls: 'sr-field' }, rroEl(doc, 'span', { text: 'Project' }), select),
    rroEl(doc, 'span', { cls: 'sr-spacer' }), save, reset));
  parts.push(rroEl(doc, 'div', { cls: 'sr-counts', text: `${view.rules.length} rules in this release. Switch a rule off or change its severity for the selected project.` }));

  const table = rroEl(doc, 'table', { cls: 'sr-table' });
  table.append(rroEl(doc, 'thead', {}, rroEl(doc, 'tr', {}, ...['On', 'Rule', 'Language', 'Pillar', 'Severity', ''].map((t) => rroEl(doc, 'th', { text: t })))));
  const tbody = rroEl(doc, 'tbody');
  for (const rule of view.rules) {
    const on = rroEl(doc, 'input', { attrs: { type: 'checkbox', 'aria-label': `Run ${rule.id}` } });
    on.checked = !draft.disabled.includes(rule.id);
    const sev = rroEl(doc, 'select', { cls: 'sec-select', attrs: { 'aria-label': `Severity of ${rule.id}` } });
    for (const s of RRO_SEVERITIES) sev.append(rroEl(doc, 'option', { text: s, attrs: { value: s } }));
    sev.value = draft.severity[rule.id] || rule.severity || '';
    const mark = rroEl(doc, 'span', { cls: 'sr-on', text: rroIsOverridden(draft, rule) ? 'Override' : '' });
    const refresh = () => { mark.textContent = rroIsOverridden(draft, rule) ? 'Override' : ''; };
    on.addEventListener('change', () => { rroSetDisabled(draft, rule.id, !on.checked); refresh(); if (h.change) h.change(); });
    sev.addEventListener('change', () => { rroSetSeverity(draft, rule, sev.value); refresh(); if (h.change) h.change(); });
    const title = rroEl(doc, 'td', {}, rroEl(doc, 'strong', { text: rule.id }), rroEl(doc, 'div', { cls: 'rro-sub', text: rule.title }));
    tbody.append(rroEl(doc, 'tr', { attrs: { 'data-rule': rule.id } },
      rroEl(doc, 'td', {}, on), title, rroEl(doc, 'td', { text: rule.language || '' }), rroEl(doc, 'td', { text: rule.pillar || '' }), rroEl(doc, 'td', {}, sev), rroEl(doc, 'td', {}, mark)));
  }
  table.append(tbody);
  parts.push(table);
  root.replaceChildren(...parts);
}

// ── Browser wiring ────────────────────────────────────────────────────────────

let _rroProject = null;
let _rroView = null;
let _rroDraft = rroDraftFrom({});

function rroProjects() {
  return (typeof _secRepos !== 'undefined' && Array.isArray(_secRepos) ? _secRepos : []).map((r) => r.name).filter(Boolean);
}

function rroNotice(message, isError) {
  const box = document.getElementById('sr-notice');
  if (!box) return;
  box.className = `sr-notice ${isError ? 'sr-notice-error' : 'sr-notice-ok'}`;
  box.textContent = message;
}

function rroPaint() {
  const root = document.getElementById('rro-root');
  rroRender(document, root, _rroView, {
    projects: rroProjects(), project: _rroProject, draft: _rroDraft,
    handlers: { project: (p) => { _rroProject = p; rroLoad(); }, save: rroSave, reset: () => { rroReset(_rroDraft); rroPaint(); } },
  });
}

async function rroLoad() {
  const q = _rroProject ? `?project=${encodeURIComponent(_rroProject)}` : '';
  _rroView = await secFetch(`/rules/installed${q}`);
  _rroDraft = rroDraftFrom(_rroView.overrides);
  rroPaint();
}

async function rroSave() {
  if (!_rroProject) { rroNotice('Choose a project first.', true); return; }
  try {
    const stored = await secFetch(`/rules/overrides/${encodeURIComponent(_rroProject)}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(rroBody(_rroDraft)),
    });
    _rroDraft = rroDraftFrom(stored);
    rroNotice(`Saved for ${_rroProject}. The next scan of it uses these settings.`, false);
    rroPaint();
  } catch (e) { rroNotice(e.message, true); }
}

// Called when the Rules section opens. Installed-release mode shows this view and hides the rule-server editor;
// legacy mode shows a short notice above the editor, which stays as it was. Returns the mode.
async function initRulesReadonly() {
  const root = document.getElementById('rro-root');
  const legacy = document.getElementById('sr-legacy');
  try {
    if (!rroProjects().length && typeof loadSecurityRepos === 'function') await loadSecurityRepos();
    if (!_rroProject) _rroProject = rroProjects()[0] || null;
    await rroLoad();
  } catch (e) {
    _rroView = { mode: 'legacy' };
    root.classList.remove('hidden');
    rroRender(document, root, _rroView, { projects: [], project: null, draft: _rroDraft, handlers: {} });
    legacy.classList.remove('hidden');
    return 'legacy';
  }
  root.classList.remove('hidden');
  legacy.classList.toggle('hidden', _rroView.mode !== 'legacy');
  return _rroView.mode;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { rroBanner, rroState, rroDraftFrom, rroSetDisabled, rroSetSeverity, rroIsOverridden, rroBody, rroReset, rroRender, RRO_LEGACY_TEXT };
}
