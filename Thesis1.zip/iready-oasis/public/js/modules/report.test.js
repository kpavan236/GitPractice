'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildReport, reportFileName, reportEscape } = require('./report');

// A report leaves the application and gets attached to tickets, so the tests
// that matter are about it being HONEST: saying what it covers, and never
// looking complete when it is filtered.

const SPEC = {
  title: 'Security scan report',
  subtitle: 'iready-core',
  scope: [{ label: 'Repository', value: 'iready-core' }, { label: 'Severity', value: 'CRITICAL' }],
  summary: [{ label: 'Critical', value: 2, tone: 'critical' }],
  columns: [{ key: 'severity', label: 'Severity' }, { key: 'title', label: 'Finding' }],
  rows: [{ severity: 'CRITICAL', title: 'SQL injection' }],
};

test('states the scope it was generated under', () => {
  // The single most important property. A filtered export that does not say so
  // is indistinguishable from the complete picture once it is an attachment on
  // a ticket.
  const html = buildReport(SPEC);
  assert.match(html, /Repository:.*iready-core/s);
  assert.match(html, /Severity:.*CRITICAL/s);
});

test('an unfiltered report says so explicitly', () => {
  // "No filters" and "somebody cropped this" look identical on paper if the
  // line is simply left blank.
  const html = buildReport({ ...SPEC, scope: [] });
  assert.match(html, /No filters applied/);
});

test('renders every row, and the columns asked for', () => {
  const html = buildReport({
    ...SPEC,
    rows: [
      { severity: 'CRITICAL', title: 'A' },
      { severity: 'HIGH', title: 'B' },
      { severity: 'LOW', title: 'C' },
    ],
  });
  for (const t of ['A', 'B', 'C']) assert.ok(html.includes(`>${t}<`), `row ${t} missing`);
  assert.match(html, /3 rows/);
});

test('an empty result set says so rather than printing a bare table', () => {
  const html = buildReport({ ...SPEC, rows: [] });
  assert.match(html, /Nothing to report for this scope/);
  assert.match(html, /0 rows/);
});

test('a missing cell is blank, not "undefined"', () => {
  const html = buildReport({ ...SPEC, rows: [{ severity: 'HIGH' }] });
  assert.equal(html.includes('undefined'), false);
});

test('escapes everything that comes from scanned code', () => {
  // Findings carry file paths, code snippets and advisory text from other
  // people's repositories. Interpolated raw, a title containing markup would
  // rewrite the report — and this is the document that gets shared.
  const html = buildReport({
    ...SPEC,
    subtitle: '<img src=x onerror=alert(1)>',
    scope: [{ label: 'Search', value: '"><script>alert(1)</script>' }],
    rows: [{ severity: 'HIGH', title: '<script>alert("xss")</script>' }],
  });
  // The property is that no NEW ELEMENT can be created from input — not that
  // the characters never appear. "onerror=" inside escaped text is inert, and
  // asserting on the substring fails on correct output.
  assert.equal(/<script/i.test(html), false, 'a script tag was created from input');
  assert.equal(/<img/i.test(html), false, 'an img tag was created from input');
  assert.ok(html.includes('&lt;script&gt;'), 'the input survives, escaped');
  assert.ok(html.includes('&lt;img'), 'the attribute payload is escaped, not stripped');
});

test('only the columns that ask for it may break mid-word', () => {
  // A file path has no break opportunity, so without the hint the table's
  // min-content width exceeds the page and the right-hand columns are clipped
  // off the printed sheet — with no scrollbar to reveal it.
  //
  // But the hint has to stay OFF everywhere else. It drops a column's
  // min-content to one character, and auto table layout then starves the short
  // columns: applied to the whole table it printed "SEVERITY" as "SEVE/RITY".
  const html = buildReport({
    ...SPEC,
    columns: [
      { key: 'severity', label: 'Severity' },
      { key: 'location', label: 'Location', wrap: 'anywhere' },
    ],
    rows: [{ severity: 'CRITICAL', location: 'src/main/java/com/x/Handler.java' }],
  });
  const cells = html.match(/<t[dh] class="[^"]*"/g);
  const wrapping = cells.filter(c => c.includes('rpt-wrap'));
  assert.equal(wrapping.length, 2, 'the marked column, header and cell — and nothing else');
  assert.equal(/class="rpt-left rpt-wrap"[^>]*>Severity/.test(html), false, 'severity must not break');
});

test('the note survives into the document', () => {
  // Partial coverage is carried in the note. A report that omits it claims more
  // than the scan established.
  const html = buildReport({ ...SPEC, note: 'Coverage was PARTIAL for this scan' });
  assert.match(html, /Coverage was PARTIAL/);
});

test('summary tones are classes, and the label always accompanies the number', () => {
  // Printed in greyscale, colour carries nothing — so the label has to.
  const html = buildReport(SPEC);
  assert.match(html, /rpt-tone-critical/);
  assert.match(html, /rpt-stat-label">Critical/);
});

test('file names are dated and safe for a filesystem', () => {
  const name = reportFileName({ title: 'Security scan report' });
  assert.match(name, /^security-scan-report-\d{4}-\d{2}-\d{2}\.pdf$/);
  // A title with slashes must not turn into a path.
  assert.equal(reportFileName({ title: 'a/b: c' }).includes('/'), false);
  assert.match(reportFileName({}), /^report-/);
});

test('escaping handles nothing gracefully', () => {
  assert.equal(reportEscape(null), '');
  assert.equal(reportEscape(undefined), '');
  assert.equal(reportEscape(0), '0');
});
