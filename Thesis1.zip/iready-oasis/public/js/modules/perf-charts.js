// =============================================================================
// Performance Diagnostics charts — inline SVG, no dependencies (same approach
// as security-charts.js). One metric per chart; two named lines share an axis
// only when they're the same metric/unit — never mixed units on one chart.
// =============================================================================

function perfTimeSeriesChart(seriesByLabel, { unit = '', highLoadBuckets = [], height = 120, from, to } = {}) {
  const labels = Object.keys(seriesByLabel || {});
  const allPoints = labels.flatMap(l => seriesByLabel[l] || []);
  if (!allPoints.length) return `<div class="chart-empty">No data for this window</div>`;

  const lo = Math.min(...allPoints.map(p => p.v));
  const hi = Math.max(...allPoints.map(p => p.v));
  const span = hi - lo || Math.max(1, hi * 0.1 || 1);
  const floor = Math.max(0, lo - span * 0.15);
  const ceil = hi + span * 0.15;

  const t0 = from ?? Math.min(...allPoints.map(p => p.t));
  const t1 = to ?? Math.max(...allPoints.map(p => p.t));
  const tSpan = (t1 - t0) || 1;

  const px = t => ((t - t0) / tSpan) * 100;
  const py = v => ((ceil - v) / (ceil - floor)) * 100;

  const COLORS = ['var(--chart-accent)', 'var(--chart-sev-medium)'];

  const bands = (highLoadBuckets || []).map(b =>
    `<rect x="${px(b.from).toFixed(2)}" y="0" width="${Math.max(0, px(b.to) - px(b.from)).toFixed(2)}" height="100"
       fill="var(--chart-sev-critical)" opacity="0.12"/>`
  ).join('');

  const lines = labels.map((label, i) => {
    const points = (seriesByLabel[label] || []).slice().sort((a, b) => a.t - b.t);
    if (points.length < 2) return '';
    const path = points.map(p => `${px(p.t).toFixed(2)},${py(p.v).toFixed(2)}`).join(' ');
    return `<polyline points="${path}" fill="none" stroke="${COLORS[i % COLORS.length]}" stroke-width="2"
              vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/>`;
  }).join('');

  const legend = labels.length > 1
    ? `<div class="perf-chart-legend">${labels.map((l, i) =>
        `<span class="perf-chart-legend-item"><span class="perf-chart-legend-dot" style="background:${COLORS[i % COLORS.length]}"></span>${escHtml(l)}</span>`).join('')}</div>`
    : '';

  return `<div class="perf-chart-wrap">
    ${legend}
    <div class="perf-chart-plot" style="height:${height}px">
      <svg class="perf-chart-svg" viewBox="0 0 100 100" preserveAspectRatio="none" role="img">
        ${bands}
        ${lines}
      </svg>
    </div>
    <div class="perf-chart-axis">
      <span>${escHtml(new Date(t0).toLocaleTimeString())}</span>
      <span>${escHtml(unit)}: ${hi.toFixed(1)} max</span>
      <span>${escHtml(new Date(t1).toLocaleTimeString())}</span>
    </div>
  </div>`;
}
