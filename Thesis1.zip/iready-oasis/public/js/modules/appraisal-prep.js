// =============================================================================
// Appraisal Prep — a private pack for your own appraisal discussion
// =============================================================================
//
// Choose a period, build a pack from YOUR OWN JIRA (and GitHub review) data, look
// at the statistics and graphs, confirm the kudos you want to keep, write what
// you want to raise, and download or print the report.
//
// Private by design. This module never names another person, never shares, and
// never touches the Notes tab or the prefs file. What you write is saved to its
// own owner-only file on this machine by the server; the numbers themselves are
// held in the server's memory for the session and nowhere else.
//
// The first half of this file is pure (dates, request building, draft edits) so
// it is unit-tested without a browser; the second half is the tab.

// ── Pure helpers ────────────────────────────────────────────────────────────

const APT_MAX_SPAN_DAYS = 731;                 // 24 months, as the server enforces

const aptPad = n => String(n).padStart(2, '0');

// A local calendar date as YYYY-MM-DD.
function aptFmtDate(d) {
  return `${d.getFullYear()}-${aptPad(d.getMonth() + 1)}-${aptPad(d.getDate())}`;
}

function aptParseDate(str) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(str || ''));
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return aptFmtDate(d) === str ? d : null;     // rejects 2026-02-31
}

// The same day N months earlier, clamped to the end of a shorter month.
function aptMonthsBefore(date, months) {
  const target = new Date(date.getFullYear(), date.getMonth() - months, 1);
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return new Date(target.getFullYear(), target.getMonth(), Math.min(date.getDate(), lastDay));
}

/** The dates a preset stands for. `today` is a local Date. */
function aptPresetRange(preset, today = new Date()) {
  if (preset === 'last-6-months') return { mode: 'range', from: aptFmtDate(aptMonthsBefore(today, 6)), to: aptFmtDate(today) };
  if (preset === 'last-12-months') return { mode: 'range', from: aptFmtDate(aptMonthsBefore(today, 12)), to: aptFmtDate(today) };
  if (preset === 'last-quarter') {
    const q = Math.floor(today.getMonth() / 3);
    const year = q === 0 ? today.getFullYear() - 1 : today.getFullYear();
    const startMonth = ((q + 3) % 4) * 3;
    return { mode: 'range', from: aptFmtDate(new Date(year, startMonth, 1)), to: aptFmtDate(new Date(year, startMonth + 3, 0)) };
  }
  return null;
}

const aptStartIso = day => aptParseDate(day).toISOString();
const aptEndIso = day => { const d = aptParseDate(day); return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999).toISOString(); };

/**
 * Turns the form into the request body, or says what is wrong with it.
 * The instants are the start of the first day and the end of the last day in the
 * user's own time zone, which is what makes the end day inclusive.
 *
 * @returns { ok: true, body } | { ok: false, error }
 */
function aptBuildRequest(form, now = new Date(), tz = Intl.DateTimeFormat().resolvedOptions().timeZone) {
  const today = aptFmtDate(now);
  const from = aptParseDate(form.from);
  if (!from) return { ok: false, error: 'Choose a start date.' };
  if (form.from > today) return { ok: false, error: 'The start date is in the future.' };
  const toDate = form.mode === 'to-date';
  let to = null;
  if (!toDate) {
    to = aptParseDate(form.to);
    if (!to) return { ok: false, error: 'Choose an end date, or switch to "To date".' };
    if (form.to < form.from) return { ok: false, error: 'The start date must not be after the end date.' };
    if (form.to > today) return { ok: false, error: 'The end date is in the future. Use "To date" to run up to today.' };
  }
  const end = toDate ? now : to;
  if ((end - from) / 86400000 > APT_MAX_SPAN_DAYS) return { ok: false, error: 'The period can be at most 24 months.' };
  return {
    ok: true,
    body: { mode: toDate ? 'to-date' : 'range', from: aptStartIso(form.from), to: toDate ? undefined : aptEndIso(form.to), tz },
  };
}

// ── Draft edits (immutable, so a render never sees a half-changed draft) ────

const aptEmptyDraft = () => ({ confirmed: [], dismissed: [], talkingPoints: '', include: {} });

function aptNormaliseDraft(d) {
  return { ...aptEmptyDraft(), ...(d || {}), confirmed: [...((d && d.confirmed) || [])], dismissed: [...((d && d.dismissed) || [])], include: { ...((d && d.include) || {}) } };
}

function aptConfirmCandidate(draft, candidate, narrativeItem) {
  const d = aptNormaliseDraft(draft);
  if (d.confirmed.some(k => k.id === candidate.id)) return d;
  d.confirmed.push({
    id: candidate.id, title: candidate.title,
    text: (narrativeItem && narrativeItem.text) || candidate.text,
    source: 'suggested', ai: !!(narrativeItem && narrativeItem.ai),
  });
  d.dismissed = d.dismissed.filter(id => id !== candidate.id);
  return d;
}

function aptDismissCandidate(draft, id) {
  const d = aptNormaliseDraft(draft);
  d.confirmed = d.confirmed.filter(k => k.id !== id);
  if (!d.dismissed.includes(id)) d.dismissed.push(id);
  return d;
}

function aptRestoreDismissed(draft) {
  return { ...aptNormaliseDraft(draft), dismissed: [] };
}

function aptAddOwnKudos(draft, title, text) {
  const d = aptNormaliseDraft(draft);
  const clean = String(text || '').trim();
  if (!clean) return d;
  d.confirmed.push({ id: `own-${d.confirmed.length + 1}-${clean.length}`, title: String(title || '').trim(), text: clean, source: 'own', ai: false });
  return d;
}

function aptUpdateConfirmed(draft, index, text) {
  const d = aptNormaliseDraft(draft);
  if (d.confirmed[index]) d.confirmed[index] = { ...d.confirmed[index], text: String(text) };
  return d;
}

function aptRemoveConfirmed(draft, index) {
  const d = aptNormaliseDraft(draft);
  d.confirmed.splice(index, 1);
  return d;
}

function aptInsertPrompt(draft, prompt) {
  const d = aptNormaliseDraft(draft);
  const line = `- ${prompt}\n`;
  const base = d.talkingPoints && !d.talkingPoints.endsWith('\n') ? `${d.talkingPoints}\n` : d.talkingPoints;
  d.talkingPoints = `${base}${line}`;
  return d;
}

// Candidates still waiting for a decision.
function aptPending(candidates, draft) {
  const d = aptNormaliseDraft(draft);
  return candidates.filter(c => !d.dismissed.includes(c.id) && !d.confirmed.some(k => k.id === c.id));
}

// ── The tab ─────────────────────────────────────────────────────────────────

const aptState = {
  status: null, form: { mode: 'range', from: '', to: '' }, useAi: true, includeCodeReview: true,
  building: false, abort: null, pack: null, draft: aptEmptyDraft(), error: null,
  saveTimer: null, paperTimer: null, saveFailed: false,
};

const aptEl = id => document.getElementById(id);
const aptE = s => aprEsc(s);
const APT_A4_CONTENT_MM = 277;                 // A4 height less the 10mm print margins

async function aptApi(method, path, body) {
  const sep = path.includes('?') ? '&' : '?';
  const url = `${API}/api/appraisal${path}${method === 'GET' || method === 'DELETE' ? `${sep}session=${encodeURIComponent(sessionId)}` : ''}`;
  const res = await fetch(url, {
    method, headers: { 'Content-Type': 'application/json' },
    body: method === 'GET' || method === 'DELETE' ? undefined : JSON.stringify({ session: sessionId, ...body }),
    signal: method === 'POST' && path === '/build' && aptState.abort ? aptState.abort.signal : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data.error || `Request failed (${res.status})`); e.code = data.code; e.status = res.status; throw e; }
  return data;
}

async function initAppraisalPrepTab() {
  if (!aptEl('apt-root')) return;
  await aptRefreshStatus();
  if (!aptState.pack) {
    try { aptState.pack = await aptApi('GET', '/pack'); await aptLoadDraft(); } catch (_) { /* nothing built yet */ }
  }
  aptRender();
}

async function aptRefreshStatus() {
  try { aptState.status = await aptApi('GET', '/status'); aptState.error = null; } catch (e) { aptState.status = null; aptState.error = e.message; }
}

async function aptLoadDraft() {
  try { aptState.draft = aptNormaliseDraft((await aptApi('GET', `/draft?period=${encodeURIComponent(aptState.pack.period.key)}`)).draft); }
  catch (_) { aptState.draft = aptEmptyDraft(); }
}

// ── Rendering ───────────────────────────────────────────────────────────────

function aptRender() {
  const root = aptEl('apt-root');
  if (!root) return;
  root.innerHTML = `<div id="apt-controls">${aptControlsHtml()}</div><div id="apt-results">${aptResultsHtml()}</div>`;
  aptRefreshPaper();
}

function aptRenderControls() { const el = aptEl('apt-controls'); if (el) el.innerHTML = aptControlsHtml(); }
function aptRenderKudos() { const el = aptEl('apt-kudos'); if (el) el.innerHTML = aptKudosHtml(); aptRefreshPaperSoon(); }

function aptControlsHtml() {
  const s = aptState.status;
  const f = aptState.form;
  const jiraOk = !!(s && s.jira.connected);
  const ai = s && s.ai;
  const needsNotice = !!(ai && ai.available && aptState.useAi && !ai.noticeAcknowledged);
  const aiLabel = ai && ai.available ? `${ai.provider || 'AI'}${ai.model ? ` · ${ai.model}` : ''}` : '';
  const seg = (mode, label) => `<button type="button" class="apt-seg-btn ${f.mode === mode ? 'on' : ''}" aria-pressed="${f.mode === mode}" onclick="aptSetMode('${mode}')">${label}</button>`;
  return `
    <section class="apt-toolbar" aria-label="Build your pack">
      <div class="apt-seg" role="group" aria-label="Period type">${seg('range', 'Date range')}${seg('to-date', 'To date')}</div>
      <label class="apt-field"><span>Start</span><input type="date" id="apt-from" value="${aptE(f.from)}" max="${aptFmtDate(new Date())}" oninput="aptState.form.from=this.value"></label>
      <label class="apt-field"><span>End</span><input type="date" id="apt-to" value="${aptE(f.to)}" max="${aptFmtDate(new Date())}" ${f.mode === 'to-date' ? 'disabled' : ''} oninput="aptState.form.to=this.value"></label>
      <label class="apt-field"><span>Preset</span><select id="apt-preset" onchange="aptApplyPreset(this.value)">
        <option value="">Choose…</option><option value="last-quarter">Last quarter</option><option value="last-6-months">Last 6 months</option><option value="last-12-months">Last 12 months</option></select></label>
      <div class="apt-toolbar-end">
        <div class="apt-checks">
          <label class="apt-check"><input type="checkbox" id="apt-review" ${aptState.includeCodeReview && s && s.github.connected ? 'checked' : ''} ${s && s.github.connected ? '' : 'disabled'} onchange="aptState.includeCodeReview=this.checked"> Code review${s && s.github.connected ? '' : ' <em>(GitHub not connected)</em>'}</label>
          ${ai && ai.available ? `<label class="apt-check" title="${aptE(aiLabel)}"><input type="checkbox" id="apt-ai" ${aptState.useAi ? 'checked' : ''} onchange="aptSetUseAi(this.checked)"> AI wording</label>` : ''}
        </div>
        <button class="btn btn-primary" id="apt-build" onclick="aptBuild()" ${aptState.building || !jiraOk || needsNotice ? 'disabled' : ''}>${aptState.building ? 'Building…' : (aptState.pack ? 'Rebuild pack' : 'Build pack')}</button>
        ${aptState.building ? '<button class="btn btn-ghost" onclick="aptCancel()">Cancel</button>' : ''}
      </div>
    </section>
    <p class="apt-private"><span><span aria-hidden="true">🔒</span> Private to you. Built from your own JIRA${s && s.github.connected ? ' and GitHub' : ''} data; never shared. Only the highlights and notes you write are saved, on this machine.</span>
      <button type="button" class="apt-link" onclick="aptClearData()" title="Delete what Appraisal Prep has saved, and the numbers held in memory">Clear my data</button></p>
    ${aptState.error ? `<div class="apt-alert apt-alert-error" role="alert">${aptE(aptState.error)}</div>` : ''}
    ${s && !jiraOk ? `<div class="apt-alert"><span>Connect JIRA first, so there is something to build the pack from.</span><button class="btn btn-ghost btn-sm" onclick="showTab('jira')">Go to the JIRA tab</button></div>` : ''}
    ${needsNotice ? `<div class="apt-alert" role="note"><span>When AI is used, <strong>statistics only</strong> (counts and times; no ticket or pull request names, no people, nothing you write) are sent to <strong>${aptE(aiLabel)}</strong>${ai.local ? ', which runs on this machine' : ''}. AI-written text is marked and fully editable.</span><button class="btn btn-ghost btn-sm" onclick="aptAckNotice()">I understand</button></div>` : ''}
    <div class="sr-only" role="status" aria-live="polite" id="apt-live">${aptState.building ? 'Building your pack' : ''}</div>`;
}

function aptResultsHtml() {
  const pack = aptState.pack;
  if (!pack) {
    return `<div class="apt-empty"><h3>Get ready for your appraisal discussion</h3>
      <p>Choose a period and build your pack. You get a one-page summary of your work, suggested highlights, and room for your own notes, to download or print.</p></div>`;
  }
  const reasons = { 'ai-off': 'AI was switched off, so the wording comes from rules.', 'ai-unavailable': 'AI is not available, so the wording comes from rules.',
    'ai-failed': 'AI did not answer, so the wording comes from rules.', 'ai-rejected': 'AI wrote something that could not be checked, so the wording comes from rules.' };
  const n = pack.narrative;
  return `
    <div class="apt-banner">${n.source === 'ai'
      ? `<span class="apt-badge">AI-assisted</span> Wording drafted with ${aptE(n.provider || 'AI')}${n.model ? ` · ${aptE(n.model)}` : ''}. Every figure is calculated, not written by AI. Edit anything.`
      : `<span class="apt-badge apt-badge-rules">Rule-based</span> ${aptE(reasons[n.reason] || 'The wording comes from rules.')}`}</div>
    <div class="apt-grid">
      <div class="apt-main">
        <div class="apt-actions" role="toolbar" aria-label="Report actions">
          <button class="btn btn-primary btn-sm" onclick="aptDownload('pdf')">Download PDF</button>
          <button class="btn btn-ghost btn-sm" onclick="aptDownload('csv')">CSV</button>
          <button class="btn btn-ghost btn-sm" onclick="aptPrint()">Print</button>
          <span class="apt-grow"></span>
          <span class="apt-fit" id="apt-fit" aria-live="polite"></span>
        </div>
        <div class="apt-paper-scroll"><div class="apt-paper" id="apt-paper"></div></div>
      </div>
      <aside class="apt-side" aria-label="Edit your highlights and notes">
        <section class="apt-panel"><h3>Highlights</h3><div id="apt-kudos">${aptKudosHtml()}</div></section>
        <section class="apt-panel"><h3>Notes for the discussion</h3>
          <p class="apt-dim">Printed on the ruled area, with room left to write by hand.</p>
          <div class="apt-prompts">${n.prompts.slice(0, 4).map((p, i) => `<button type="button" class="apt-chip" onclick="aptUsePrompt(${i})" title="Add to my notes">${aptE(p.text)}</button>`).join('')}</div>
          <label class="sr-only" for="apt-points">Notes for the discussion</label>
          <textarea id="apt-points" rows="9" maxlength="20000" oninput="aptEditPoints(this.value)" placeholder="What went well, what was hard, goals, support you need…">${aptE(aptState.draft.talkingPoints)}</textarea>
          <div class="apt-dim" id="apt-saved" aria-live="polite">${aptState.saveFailed ? 'Could not save. Your text is still here.' : ''}</div>
        </section>
      </aside>
    </div>`;
}

function aptKudosHtml() {
  const pack = aptState.pack;
  const d = aptNormaliseDraft(aptState.draft);
  const pending = aptPending(pack.candidates, d);
  const narrativeFor = id => pack.narrative.kudos.find(k => k.id === id);
  return `
    ${d.confirmed.length ? `<ul class="apt-conf-list">${d.confirmed.map((k, i) => `
      <li><div class="apt-conf-head"><strong>${aptE(k.title || 'Your own')}</strong>${k.ai ? ' <span class="apt-badge">AI</span>' : ''}${i >= APR_MAX_HIGHLIGHTS ? ' <span class="apt-dim">not on the page</span>' : ''}
        <button type="button" class="apt-x" onclick="aptRemoveKudo(${i})" aria-label="Remove ${aptE(k.title || 'this highlight')}">✕</button></div>
        <label class="sr-only" for="apt-k-${i}">Text for ${aptE(k.title || 'your own highlight')}</label>
        <textarea id="apt-k-${i}" rows="2" maxlength="2000" oninput="aptEditKudo(${i}, this.value)">${aptE(k.text)}</textarea></li>`).join('')}</ul>`
      : '<p class="apt-dim">Add the highlights you want to raise. They appear on your one-page report.</p>'}
    ${d.confirmed.length > APR_MAX_HIGHLIGHTS ? `<p class="apt-dim">Only the first ${APR_MAX_HIGHLIGHTS} fit on the one-page report.</p>` : ''}
    <div class="apt-own"><label class="sr-only" for="apt-own-text">Your own highlight</label>
      <input type="text" id="apt-own-text" maxlength="400" placeholder="Add your own, e.g. mentored two new joiners" onkeydown="if(event.key==='Enter')aptAddOwn()">
      <button type="button" class="btn btn-ghost btn-sm" onclick="aptAddOwn()">Add</button></div>
    ${pending.length ? `<h4>Suggested from your figures</h4><ul class="apt-sug-list">${pending.map(c => { const n = narrativeFor(c.id); return `
      <li><div class="apt-sug-text"><strong>${aptE(c.title)}</strong>${n && n.ai ? ' <span class="apt-badge">AI</span>' : ''}<span>${aptE((n && n.text) || c.text)}</span></div>
        <button type="button" class="apt-add" onclick="aptConfirm('${aptE(c.id)}')" aria-label="Add ${aptE(c.title)} to the report" title="Add to the report">+</button>
        <button type="button" class="apt-x" onclick="aptDismiss('${aptE(c.id)}')" aria-label="Dismiss ${aptE(c.title)}" title="Dismiss">✕</button></li>`; }).join('')}</ul>`
      : (pack.candidates.length ? '' : '<p class="apt-dim">Nothing stood out from the figures in this period.</p>')}
    ${d.dismissed.length ? `<button type="button" class="apt-link" onclick="aptRestore()">Show ${d.dismissed.length} dismissed again</button>` : ''}`;
}

// ── The live preview: the exact report, and whether it still fits one page ──

function aptRefreshPaper() {
  const paper = aptEl('apt-paper');
  if (!paper || !aptState.pack) return;
  paper.innerHTML = aprBuildReportHtml(aptReportArgs());
  const doc = paper.firstElementChild;
  const fit = aptEl('apt-fit');
  if (!doc || !fit) return;
  const mm = doc.offsetHeight / 3.7795;
  const pages = Math.max(1, Math.ceil(mm / APT_A4_CONTENT_MM));
  fit.textContent = pages === 1 ? '' : `Runs to ${pages} pages: shorten your notes or highlights to fit one`;
  fit.classList.toggle('apt-fit-warn', pages > 1);
}

function aptRefreshPaperSoon() {
  clearTimeout(aptState.paperTimer);
  aptState.paperTimer = setTimeout(aptRefreshPaper, 180);
}

// ── Handlers ────────────────────────────────────────────────────────────────

function aptSetMode(mode) {
  aptState.form.mode = mode;
  aptRenderControls();
}

function aptApplyPreset(preset) {
  const range = aptPresetRange(preset);
  if (!range) return;
  aptState.form = { mode: 'range', from: range.from, to: range.to };
  aptRenderControls();
}

function aptSetUseAi(on) { aptState.useAi = on; aptRenderControls(); }

async function aptAckNotice() {
  try { await aptApi('POST', '/ai-notice', {}); await aptRefreshStatus(); } catch (e) { toast(e.message, 'error'); }
  aptRenderControls();
}

async function aptBuild() {
  const check = aptBuildRequest(aptState.form);
  if (!check.ok) { aptState.error = check.error; aptRenderControls(); return; }
  aptState.error = null;
  aptState.building = true;
  aptState.abort = new AbortController();
  aptRenderControls();
  try {
    const pack = await aptApi('POST', '/build', { ...check.body, useAi: aptState.useAi, includeCodeReview: aptState.includeCodeReview });
    aptState.pack = pack;
    await aptLoadDraft();
    await aptRefreshStatus();
  } catch (e) {
    if (e.name === 'AbortError' || e.code === 'SUPERSEDED') { /* a newer build, or the user cancelled */ }
    else aptState.error = e.message;
  } finally {
    aptState.building = false;
    aptState.abort = null;
  }
  aptRender();
}

function aptCancel() { if (aptState.abort) aptState.abort.abort(); }

async function aptClearData() {
  if (!window.confirm('Delete everything saved for Appraisal Prep (your highlights and notes) and the numbers held in memory? This cannot be undone.')) return;
  try {
    await aptApi('DELETE', '/data');
    aptState.pack = null; aptState.draft = aptEmptyDraft(); aptState.error = null;
    await aptRefreshStatus();
    toast('Appraisal data cleared', 'success');
  } catch (e) { toast(e.message, 'error'); }
  aptRender();
}

// ── Drafts: autosave, debounced, to the private file via the server ─────────

function aptSaveSoon() {
  clearTimeout(aptState.saveTimer);
  aptState.saveTimer = setTimeout(aptSaveNow, 600);
}

async function aptSaveNow() {
  if (!aptState.pack) return;
  try {
    await aptApi('PUT', '/draft', { period: aptState.pack.period.key, draft: aptState.draft });
    aptState.saveFailed = false;
  } catch (_) { aptState.saveFailed = true; }
  const el = aptEl('apt-saved');
  if (el) el.textContent = aptState.saveFailed ? 'Could not save. Your text is still here.' : '';
}

// Every edit saves the draft and refreshes the live preview. Only structural
// edits (add, remove, dismiss) redraw the side list; typing never does, so a
// text box never loses focus under the cursor.
function aptChange(next, { redrawKudos = false } = {}) {
  aptState.draft = next;
  aptSaveSoon();
  if (redrawKudos) aptRenderKudos(); else aptRefreshPaperSoon();
}

function aptEditPoints(text) { aptChange({ ...aptNormaliseDraft(aptState.draft), talkingPoints: text }); }
function aptEditKudo(i, text) { aptChange(aptUpdateConfirmed(aptState.draft, i, text)); }
function aptRemoveKudo(i) { aptChange(aptRemoveConfirmed(aptState.draft, i), { redrawKudos: true }); }
function aptRestore() { aptChange(aptRestoreDismissed(aptState.draft), { redrawKudos: true }); }
function aptDismiss(id) { aptChange(aptDismissCandidate(aptState.draft, id), { redrawKudos: true }); }
function aptConfirm(id) {
  const c = aptState.pack.candidates.find(x => x.id === id);
  if (c) aptChange(aptConfirmCandidate(aptState.draft, c, aptState.pack.narrative.kudos.find(k => k.id === id)), { redrawKudos: true });
}
function aptAddOwn() {
  const box = aptEl('apt-own-text');
  if (!box || !box.value.trim()) return;
  aptChange(aptAddOwnKudos(aptState.draft, '', box.value), { redrawKudos: true });
}
function aptUsePrompt(i) {
  const p = aptState.pack.narrative.prompts[i];
  if (!p) return;
  aptChange(aptInsertPrompt(aptState.draft, p.text));
  const box = aptEl('apt-points');
  if (box) box.value = aptState.draft.talkingPoints;
}

// ── Download and print ──────────────────────────────────────────────────────

function aptReportArgs() { return { pack: aptState.pack, draft: aptNormaliseDraft(aptState.draft), now: new Date() }; }

function aptDownloadText(name, mime, text) {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function aptDownload(kind) {
  if (!aptState.pack) return;
  const pack = aptState.pack;
  try {
    if (kind === 'html') aptDownloadText(aprReportFileName(pack, 'html'), 'text/html;charset=utf-8', aprBuildStandaloneHtml(aptReportArgs()));
    else if (kind === 'csv') aptDownloadText(aprReportFileName(pack, 'csv'), 'text/csv;charset=utf-8', aprBuildCsv(pack));
    else {
      const out = await produceHtml({ html: aprBuildReportHtml(aptReportArgs()), fileName: aprReportFileName(pack, 'pdf') }, 'pdf');
      if (out.ok && out.path) toast('Saved the PDF', 'success');
    }
  } catch (e) { toast(`Could not create the file: ${e.message}`, 'error'); }
}

async function aptPrint() {
  if (!aptState.pack) return;
  try { await produceHtml({ html: aprBuildReportHtml(aptReportArgs()), fileName: aprReportFileName(aptState.pack, 'pdf') }, 'print'); }
  catch (e) { toast(`Could not print: ${e.message}`, 'error'); }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    aptFmtDate, aptParseDate, aptPresetRange, aptBuildRequest, aptMonthsBefore,
    aptEmptyDraft, aptNormaliseDraft, aptConfirmCandidate, aptDismissCandidate, aptRestoreDismissed, aptAddOwnKudos,
    aptUpdateConfirmed, aptRemoveConfirmed, aptInsertPrompt, aptPending,
  };
}
