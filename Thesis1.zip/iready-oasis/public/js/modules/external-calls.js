// =============================================================================
// External calls — the client side of the GitHub / Jenkins switch
// =============================================================================
//
// The switch itself lives on the server (server/external-calls.js), which refuses
// every call to GitHub and Jenkins while it is off, whatever tab makes it. This file
// only (1) asks the server where the switch stands, (2) lets the user flip it from
// Settings, (3) stops the app from starting GitHub work it knows will be refused, and
// (4) says so, once, when something is refused, instead of failing silently.
//
// Fails safe: if the state cannot be read, the switch is treated as OFF.

let _extCalls = { enabled: false, source: 'default', loaded: false };
const EXT_NOTICE_GAP_MS = 20000;
let _extNoticeAt = 0;

function externalCallsOn() {
  return _extCalls.enabled === true;
}

async function loadExternalCalls() {
  try {
    const resp = await fetch(`${API}/api/external-calls`);
    if (resp.ok) {
      const data = await resp.json();
      _extCalls = { enabled: data.enabled === true, source: data.source || 'default', loaded: true };
    }
  } catch (_) { /* server not answering: stay off */ }
  renderExternalCallsChip();
  return _extCalls;
}

async function setExternalCalls(enabled) {
  let ok = false;
  try {
    const resp = await fetch(`${API}/api/external-calls`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled }),
    });
    const data = await resp.json().catch(() => ({}));
    if (resp.ok) { _extCalls = { enabled: data.enabled === true, source: data.source || 'settings', loaded: true }; ok = true; }
    else toast(data.error || 'Could not change the setting.', 'error');
  } catch (_) { toast('Could not reach OASIS to change the setting.', 'error'); }

  renderExternalCallsChip();
  syncExternalCallsControl();
  if (!ok) return;
  toast(_extCalls.enabled ? 'GitHub and Jenkins calls are on.' : 'GitHub and Jenkins calls are off.', 'success');
  // The repository list was left empty while the switch was off; fill it now.
  if (_extCalls.enabled && typeof sessionId !== 'undefined' && sessionId && typeof reloadRepos === 'function') reloadRepos();
}

// The Settings checkbox follows the real state, including after a failed change.
function syncExternalCallsControl() {
  const box = document.getElementById('s-external-calls');
  if (box) box.checked = externalCallsOn();
  const src = document.getElementById('s-external-calls-source');
  if (src) src.textContent = _extCalls.source === 'settings' ? 'Saved in Settings.'
    : _extCalls.source === 'environment' ? 'Set by this build; changing it here saves your choice.' : 'Off until you turn it on.';
}

// A small notice in the top bar while the switch is off, so an empty repository list or a
// failed pull is never a mystery. It opens Settings.
function renderExternalCallsChip() {
  const bar = document.querySelector('#main-topbar .topbar-right');
  if (!bar) return;
  let chip = document.getElementById('ext-chip');
  if (externalCallsOn()) { if (chip) chip.remove(); return; }
  if (!chip) {
    chip = document.createElement('span');
    chip.id = 'ext-chip';
    chip.className = 'lic-chip lic-chip-warn';
    chip.setAttribute('role', 'button');
    chip.tabIndex = 0;
    chip.textContent = 'External calls off';
    chip.title = 'OASIS is not contacting GitHub or Jenkins, and is not syncing JIRA automatically. Click to open Settings.';
    chip.onclick = () => { if (typeof openSettingsModal === 'function') openSettingsModal(); };
    chip.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') chip.click(); };
    bar.prepend(chip);
  }
}

// Says why, once in a while, when the server refuses something because the switch is off.
function installExternalCallsNotice() {
  const original = window.fetch;
  window.fetch = async function (...args) {
    const resp = await original.apply(this, args);
    if (resp.status === 503) {
      try {
        const data = await resp.clone().json();
        if (data && data.code === 'EXTERNAL_CALLS_DISABLED' && Date.now() - _extNoticeAt > EXT_NOTICE_GAP_MS) {
          _extNoticeAt = Date.now();
          if (typeof toast === 'function') toast(data.message, 'info');
        }
      } catch (_) { /* not our response */ }
    }
    return resp;
  };
}
installExternalCallsNotice();

// Shown in the repository list instead of a spinner that would never finish.
function showReposSwitchedOff() {
  const list = document.getElementById('repo-list');
  if (!list) return;
  list.innerHTML = `<div class="loading-repos" style="text-align:center;padding:24px 16px">
      <div style="font-weight:600;margin-bottom:6px">GitHub calls are switched off</div>
      <div class="field-hint" style="margin-bottom:12px">OASIS is not loading your repositories from GitHub.</div>
      <button class="btn btn-primary btn-sm" onclick="openSettingsModal()">Open Settings</button>
    </div>`;
  const count = document.getElementById('sidebar-repo-count');
  if (count) count.textContent = '–';
}
