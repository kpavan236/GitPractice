// =============================================================================
// Security — scope, grouping and scoring
// =============================================================================
// The pure half of the security tab: what the reader is currently looking at,
// how dependency findings collapse into rows, and how a set of findings becomes
// a score. Nothing here touches the DOM beyond reading the search box, which is
// why it is the part that can be tested without a browser.

const SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];

// Each severity band contributes a BOUNDED amount with diminishing returns, so
// the twentieth critical hurts less than the first and every fix moves the
// number. A flat deduction saturated at seven criticals: with 22 open the score
// read 0, and fixing fifteen of them still read 0 — a metric that cannot move
// tells you nothing and never rewards the work.
const SCORE_BANDS = [
  { key: 'CRITICAL', weight: 45, scale: 4 },
  { key: 'HIGH', weight: 30, scale: 8 },
  { key: 'MEDIUM', weight: 18, scale: 25 },
  { key: 'LOW', weight: 7, scale: 50 },
];

/**
 * @param {Array}  findings
 * @param {object} filter    { type, severity, repository, search }
 * @param {object} opts      { except: ['severity'|'type'|'repository'] }
 */
function scopeFindings(findings, filter = {}, { except = [] } = {}) {
  const skip = new Set(except);
  const search = String(filter.search || '').toLowerCase();
  const repositories = filter.repositories || [];

  return (findings || []).filter(f => {
    // QUALITY is out of scope until asked for by name. There are usually
    // hundreds of lint findings and a handful of vulnerabilities, and a list
    // where a CRITICAL sits below four hundred `no-unused-vars` entries is a
    // list people stop opening.
    if (!skip.has('type') && (filter.type ? f.type !== filter.type : f.type === 'QUALITY')) return false;
    if (!skip.has('repository') && repositories.length && !repositories.includes(f.repository)) return false;
    if (!skip.has('severity') && filter.severity && f.severity !== filter.severity) return false;
    if (!skip.has('newCode') && filter.newCodeOnly && !f.isNewCode) return false;
    if (!search) return true;
    return [f.title, f.file, f.cve, f.repository, f.category].some(
      v => v && String(v).toLowerCase().includes(search)
    );
  });
}

// The live filter, including the search box — which lives in the DOM rather
// than in _secFilter because the user types into it directly.
function currentSecurityFilter() {
  return { ..._secFilter, search: document.getElementById('sec-search')?.value || '' };
}

// Everything in scope except the severity narrowing: the set the tiles, the
// score and the severity facet are all counted from. Scoping the score this way
// is the point — "this repository scores 41" is a fact someone can act on in a
// way that an estate-wide average never is.
function scopeBase() {
  return scopeFindings(_secFindings, currentSecurityFilter(), { except: ['severity'] });
}

// What the table shows.
function scopedFindings() {
  return scopeFindings(_secFindings, currentSecurityFilter());
}

// Whether anything is narrowing the view. Drives the scope bar, and tells the
// global-only tiles to say so.
function securityScopeChips() {
  const filter = currentSecurityFilter();
  const repos = filter.repositories || [];
  return [
    repos.length === 1 ? { dimension: 'repository', label: repos[0] } : null,
    repos.length > 1 ? { dimension: 'repository', label: `${repos.length} repositories` } : null,
    filter.type ? { dimension: 'type', label: filter.type } : null,
    filter.severity ? { dimension: 'severity', label: filter.severity } : null,
    filter.newCodeOnly ? { dimension: 'newCode', label: 'New code' } : null,
    filter.search ? { dimension: 'search', label: `“${filter.search}”` } : null,
  ].filter(Boolean);
}

// ── Grouping ───────────────────────────────────────────────────────────────
//
// One row per PROBLEM a person can act on, not one per advisory.
//
// A single Tomcat version carried 55 CVEs in one repository here, and 500 SCA
// findings collapse to 115 rows. All 55 have the same answer — upgrade the
// dependency — so 55 rows is 54 rows of noise pushing everything else off the
// screen, and it makes the queue look unmanageable when it is not.
//
// PRESENTATION ONLY. The findings underneath stay one per CVE, because each has
// its own severity, its own fixed version and its own suppression decision.
// Collapsing them for real would break per-CVE triage, the gate's CVE count,
// deduplication, and the SARIF export. Nothing below writes to a finding.
//
// SCA only. Grouping SAST by file would hide genuinely distinct bugs that
// happen to share a location, which is the opposite of the problem being solved.
function scaGroupKey(finding) {
  if (!finding || finding.type !== 'SCA') return null;
  const meta = finding.metadata || {};
  if (!meta.packageName) return null;
  // The package AT A VERSION in ONE manifest. Two manifests pinning different
  // versions are two upgrades, so they stay two rows.
  return [finding.repository, meta.packageName, meta.versionInUse || '', finding.file || ''].join('\u0000');
}

/**
 * Collapses SCA findings into per-package rows, preserving order.
 *
 * A group inherits the position of its highest-risk member, so the list stays
 * sorted by risk without re-sorting — the caller has already done that, and
 * re-sorting here would silently disagree with it.
 */
function groupFindings(findings) {
  const rows = [];
  const byKey = new Map();

  for (const finding of findings || []) {
    const key = scaGroupKey(finding);
    if (!key) {
      rows.push({ kind: 'finding', finding });
      continue;
    }
    let group = byKey.get(key);
    if (!group) {
      group = { kind: 'group', key, findings: [] };
      byKey.set(key, group);
      rows.push(group);
    }
    group.findings.push(finding);
  }

  // A package with one advisory is just a finding. Rendering it as a group of
  // one would add a badge and a second click to reach what a normal row already
  // shows.
  return rows.map(row =>
    row.kind === 'group' && row.findings.length === 1
      ? { kind: 'finding', finding: row.findings[0] }
      : row
  );
}

// What a grouped row states. The WORST of everything, because the row stands in
// for its members and a row summarising six CVEs as the least severe of them
// would be actively misleading.
function summariseGroup(group) {
  const first = group.findings[0];
  const meta = first.metadata || {};
  const severity = SEVERITY_ORDER.find(s => group.findings.some(f => f.severity === s)) || first.severity;

  return {
    packageName: meta.packageName,
    version: meta.versionInUse || null,
    file: first.file,
    repository: first.repository,
    type: first.type,
    count: group.findings.length,
    severity,
    risk: group.findings.reduce(
      (worst, f) => ((f.risk && f.risk.score) > (worst.score || 0) ? f.risk : worst),
      first.risk || { score: 0, priority: 'P4' }
    ),
    sources: [...new Set(group.findings.flatMap(f => f.detections.map(d => d.source)))],
    // Surfaced on the row because it changes who does the upgrade: a transitive
    // dependency means negotiating with whatever pulled it in.
    transitive: Boolean(meta.transitive),
  };
}

// Counts come from the loaded set, not the dashboard, so they stay truthful
// when the status filter changes what is loaded. A chip reading "High 12" over
// a list that cannot contain 12 highs is worse than no count at all.
function countBy(findings, key) {
  return findings.reduce((acc, f) => ({ ...acc, [f[key]]: (acc[f[key]] || 0) + 1 }), {});
}

function securityScore(counts) {
  const penalty = SCORE_BANDS.reduce(
    (sum, b) => sum + b.weight * (1 - Math.exp(-(counts[b.key] || 0) / b.scale)),
    0
  );
  return Math.max(0, Math.round(100 - penalty));
}

// The number alone invites false precision. A grade says how bad it is; the
// severity tiles beside it say why.
function securityGrade(score) {
  if (score >= 90) return 'A';
  if (score >= 75) return 'B';
  if (score >= 55) return 'C';
  if (score >= 35) return 'D';
  return 'F';
}


// Exported for tests only — see the note in security.js. The browser loads this
// as a plain script, where `module` is undefined.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { scopeFindings, groupFindings, summariseGroup, scaGroupKey, securityScore, securityGrade, countBy, SEVERITY_ORDER };
}
