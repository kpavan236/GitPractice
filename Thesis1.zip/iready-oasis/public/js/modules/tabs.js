// =============================================================================
// Tabs — showTab() and tab-switch side-effects
// =============================================================================

let activeTab = 'home';

function showTab(name) {
  activeTab = name;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`tab-btn-${name}`)?.classList.add('active');
  // The bar scrolls sideways; keep the tab you just opened in view.
  document.getElementById(`tab-btn-${name}`)?.scrollIntoView?.({ inline: 'nearest', block: 'nearest' });

  const homeEl     = document.getElementById('tab-home');
  const existingEl = document.getElementById('tab-existing');
  const depsEl     = document.getElementById('tab-deps');
  const dockerEl   = document.getElementById('tab-docker');
  const jiraEl     = document.getElementById('tab-jira');
  const versionWatchEl = document.getElementById('tab-version-watch');
  const securityEl = document.getElementById('tab-security');
  const notesEl    = document.getElementById('tab-notes');
  const perfDiagnosticsEl = document.getElementById('tab-perf-diagnostics');
  const appraisalPrepEl = document.getElementById('tab-appraisal-prep');
  if (homeEl)     homeEl.classList.toggle('hidden', name !== 'home');
  if (existingEl) existingEl.classList.toggle('hidden', name !== 'existing');
  if (depsEl)     depsEl.classList.toggle('hidden', name !== 'deps');
  if (dockerEl)   dockerEl.classList.toggle('hidden', name !== 'docker');
  if (jiraEl)     jiraEl.classList.toggle('hidden', name !== 'jira');
  if (versionWatchEl) versionWatchEl.classList.toggle('hidden', name !== 'version-watch');
  if (securityEl) securityEl.classList.toggle('hidden', name !== 'security');
  if (notesEl)    notesEl.classList.toggle('hidden', name !== 'notes');
  if (perfDiagnosticsEl) perfDiagnosticsEl.classList.toggle('hidden', name !== 'perf-diagnostics');
  if (appraisalPrepEl) appraisalPrepEl.classList.toggle('hidden', name !== 'appraisal-prep');

  if (name === 'existing') loadExistingProjects();
  if (name === 'deps') {
    // If the background prefetch already warmed the graph, just render it —
    // no spinner, no extra round-trip. If a prefetch is still in flight, show a
    // spinner and let it fill the list when it finishes. Otherwise load on demand.
    if (_dgPrefetched) dgRenderRepoList();
    else if (_dgPrefetching) {
      const listEl = document.getElementById('dg-list');
      if (listEl) listEl.innerHTML = `<div class="dg-list-loading"><div class="spinner"></div></div>`;
    } else loadDependencyGraph();
  }
  if (name !== 'deps') stopDgSim();
  if (name === 'docker') initDockerTab();
  else { stopDockerPolling(); stopDockerLogs(); }
  if (name === 'jira') initJiraTab();
  if (name === 'version-watch') initVersionWatchTab();
  if (name === 'security') initSecurityTab();
  if (name === 'notes') initNotesTab();
  if (name === 'perf-diagnostics') initPerfDiagnosticsTab();
  if (name === 'appraisal-prep') initAppraisalPrepTab();
}
