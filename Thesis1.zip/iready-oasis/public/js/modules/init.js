// =============================================================================
// Init — auto-resume last session, dark/light theme toggle, DOMContentLoaded bootstrap
// =============================================================================
// Opt-in crash/error reporting (Settings → Diagnostics, off by default).
// Checking cfg.errorReportingEnabled here is just a fast path so an error is
// never even worth a network call when nobody opted in — the server
// independently re-checks the same flag from prefs, which is the actual
// trust boundary (a stale page that had it on when loaded, then off since,
// must not still be able to write anything).
function reportRendererError(source, message, stack, url, line, col) {
  if (!cfg.errorReportingEnabled) return;
  fetch(`${API}/api/error-report`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source, message, stack, url, line, col }),
  }).catch(() => {});
}
window.addEventListener('error', (event) => {
  reportRendererError('renderer error', event.message, event.error?.stack, event.filename, event.lineno, event.colno);
});
window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason;
  reportRendererError('unhandled rejection', reason?.message || String(reason), reason?.stack);
});

// If we have cached config AND a remembered token, recreate the session and go
// straight to the main screen — so a page refresh restores the dashboard
// instead of dumping the user back on the onboarding wizard.
async function autoResume() {
  const token = getCookie(TOKEN_COOKIE);
  const savedJenkinsToken = loadJenkinsCredentials()?.token || '';
  if (!token || !savedJenkinsToken || !cfg.githubUrl || !cfg.org || !cfg.cloneDir) return false;
  cfg.token = token;

  try {
    const resp = await fetch(`${API}/api/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        githubUrl: cfg.githubUrl, org: cfg.org, token, cloneDir: cfg.cloneDir,
        intellijPath: cfg.intellijPath || '', mavenArgs: cfg.mavenArgs || '', extraEnv: cfg.extraEnv || '',
        awsProfile: cfg.awsProfile || '',
        // The server requires the Jenkins address; without it every resume was refused with a 400.
        jenkinsUrl: cfg.jenkinsUrl || '', jenkinsToken: savedJenkinsToken,
        aiEnabled: cfg.aiEnabled !== false, aiProvider: cfg.aiProvider || '', aiModel: cfg.aiModel || '',
        aiHost: cfg.aiHost || '', aiApiKey: loadAiApiKey(),
      })
    });
    if (!resp.ok) return false;
    const sd = await resp.json();
    sessionId = sd.sessionId;
    if (sd.githubLogin) cfg.githubLogin = sd.githubLogin;
  } catch (e) {
    return false;
  }

  // The session just validated the GitHub token and the Jenkins login. On a machine whose
  // trial has not started yet (setup was completed on an older version), start it now.
  if (typeof ensureLicenseReady === 'function' && !(await ensureLicenseReady())) return false;

  // With GitHub calls switched off the login above is all the proof we need: loading page 1
  // of the repositories just to test the token would be a GitHub call.
  if (externalCallsOn()) {
    // Validate the token by fetching page 1 before entering the app
    const data = await fetchRepos(1).catch(() => null);
    if (!data) {
      sessionId = null;
      return false;
    }
  }
  if (!(await enterApp())) return false;
  // Load remaining pages in the background (guard in fetchAllRepos prevents duplication)
  fetchAllRepos();
  return true;
}

// ── Init ───────────────────────────────────────────────────────────────────
// ── Theme (dark / light) ─────────────────────────────────────────────────────
const THEME_KEY = 'oasis_theme';

function currentTheme() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
}

// DOM-only: updates attribute + localStorage + button without saving to prefs.
// Used during init so startup never overwrites the user's saved preference.
function _applyThemeDom(theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  if (t === 'light') document.documentElement.setAttribute('data-theme', 'light');
  else document.documentElement.removeAttribute('data-theme');
  try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
  const btn = document.getElementById('theme-toggle');
  if (btn) {
    btn.textContent = t === 'light' ? '☀️' : '🌙';
    btn.title = t === 'light' ? 'Switch to dark theme' : 'Switch to light theme';
  }
}

// Full apply: updates DOM and persists to ~/.oasis-prefs.json via the server.
// Persisting to the prefs file (not localStorage) survives Electron port changes.
function applyTheme(theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  _applyThemeDom(t);
  fetch(`${API}/api/prefs`, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ theme: t }) }).catch(() => {});
}

function toggleTheme() {
  applyTheme(currentTheme() === 'light' ? 'dark' : 'light');
}

(async function init() {
  // Load the saved theme from prefs (survives port changes); don't re-save it.
  // The server also pre-injects data-theme on <html> to avoid a flash on load.
  try {
    const prefs = await fetch(`${API}/api/prefs`).then(r => r.json()).catch(() => ({}));
    _applyThemeDom(prefs.theme === 'light' || prefs.theme === 'dark' ? prefs.theme : currentTheme());
  } catch (_) {
    _applyThemeDom(currentTheme());
  }
  loadCache();
  await loadCacheFromFile(); // merge file-persisted prefs (survives Electron restarts)
  prefillWizard();
  await loadExternalCalls();   // autoResume depends on it: with GitHub calls off it must not load repositories
  autoResume();
})();


// ─────────────────────────────────────────────────────────────────────────────
// Docker Services Tab — flat card grid, sourced from your personal catalog
// (added via the Docker Hub search modal, not a cloned repo's compose files)
// ─────────────────────────────────────────────────────────────────────────────

let _dockerServices   = [];        // catalog from /api/docker/services
let _dockerGroups     = [];        // [{id,label}] — derived from your services' group tags
let _dockerContainers = {};        // container name → live status object
let _dockerFilter     = 'all';     // active group filter
let _dockerPollTimer  = null;
let _dockerBusy       = new Set();  // service names with an op in flight
let _dockerOpId       = 0;
let _dockerLoaded     = false;
let _dockerPrefetching = false;     // true while the background prefetch is in flight

// Route a streamed log line to the right place: docker op logs → drawer; else jobs.
function routeLog(jobId, level, message, ts) {
  if (typeof jobId === 'string' && jobId.startsWith('docker-op-')) {
    appendDockerLog(level, message);
  } else {
    appendLog(jobId, level, message, ts);
    // Mirror to ep-card console when a launch is actively running for this repo
    if (epLaunchState[jobId]?.running) appendEpConsoleLog(jobId, level, message, ts);
  }
}

async function initDockerTab(forceRefresh = false, bg = false) {
  // A background prefetch already fetched the catalog and rendered into the
  // (hidden) tab DOM — just resume live polling on a real tab open.
  if (_dockerLoaded && !forceRefresh) { if (!bg) startDockerPolling(); return; }
  // A prefetch is mid-flight and will render shortly. Don't fire a duplicate
  // fetch; just start polling so the cards go live the moment it lands.
  if (_dockerPrefetching && !bg && !forceRefresh) { startDockerPolling(); return; }
  const grid = document.getElementById('docker-cards-grid');
  if (grid && !_dockerServices.length) grid.innerHTML = '<div class="docker-empty">Loading services…</div>';

  try {
    const resp = await fetch(`${API}/api/docker/services?session=${sessionId}`);
    const data = await resp.json();
    _dockerGroups   = data.groups   || [];
    _dockerServices = data.services || [];
    _dockerLoaded = true;

    const notice = document.getElementById('docker-notice');
    if (!data.dockerOk) {
      notice.classList.remove('hidden');
      notice.innerHTML = '🐳 <strong>Docker isn\'t running.</strong> Start Docker Desktop (or the daemon), then click ↻ Refresh. ' +
        '<a href="https://www.docker.com/products/docker-desktop/" target="_blank" rel="noopener">Get Docker Desktop ↗</a>';
    } else {
      notice.classList.add('hidden');
    }

    renderDockerChips();
    await refreshDockerContainers();   // also calls renderDockerCards()
    if (!bg) startDockerPolling();     // polling is a tab-active concern, not a prefetch one
  } catch (e) {
    const notice = document.getElementById('docker-notice');
    if (notice) { notice.classList.remove('hidden'); notice.textContent = 'Could not reach the OASIS server.'; }
  }
}

function renderDockerChips() {
  const wrap = document.getElementById('docker-filter-chips');
  if (!wrap) return;
  // Nothing to filter → no chips at all (don't show a lone "All").
  if (!_dockerServices.length) { wrap.innerHTML = ''; return; }
  // Count services per group
  const counts = {};
  for (const s of _dockerServices) counts[s.group] = (counts[s.group] || 0) + 1;
  const groups = [{ id: 'all', label: 'All' }, ..._dockerGroups.filter(g => counts[g.id])];
  wrap.innerHTML = groups.map(g => {
    const n = g.id === 'all' ? _dockerServices.length : counts[g.id];
    // Group ids are freeform user text (not a fixed enum) — pass them through
    // encodeURIComponent so a stray quote/backslash can't break the attribute.
    return `<span class="dchip ${_dockerFilter === g.id ? 'active' : ''}" onclick="setDockerFilter('${encodeURIComponent(g.id)}')">${escHtml(g.label)}<span class="dchip-count">${n}</span></span>`;
  }).join('');
}

function setDockerFilter(id) {
  _dockerFilter = decodeURIComponent(id);
  renderDockerChips();
  renderDockerCards();
}

// Map a container's live status into a state string.
function containerState(c) {
  if (!c) return 'absent';
  return /^up/i.test(c.Status || c.State || '') ? 'running' : 'stopped';
}

// Build the HTML for one service card.
function dockerCardHtml(s) {
  const c = _dockerContainers[s.container];
  const state = _dockerBusy.has(s.name) ? 'busy' : containerState(c);
  const stateText = { running: 'running', stopped: 'stopped', absent: 'not installed', busy: 'working…' }[state];
  const portStr = s.ports && s.ports.length ? s.ports.map(p => `:${p}`).join(' ') : '';
  const uptime = c && /^up/i.test(c.Status || '') ? (c.Status || '').replace(/^Up\s*/i, '') : '';

  let actions = '';
  if (state === 'busy') {
    actions = `<button class="dbtn" disabled>working…</button>`;
  } else if (state === 'running') {
    actions =
      `<button class="dbtn warn"   onclick="dockerCardOp('restart','${s.name}','${s.container}')">↻ Restart</button>` +
      `<button class="dbtn danger" onclick="dockerCardOp('stop','${s.name}','${s.container}')">■ Stop</button>` +
      `<button class="dbtn"        onclick="dockerCardLogs('${s.name}','${s.container}')">📄 Logs</button>` +
      `<button class="dbtn danger" onclick="dockerCardOp('delete','${s.name}','${s.container}')" title="Stop and remove the container">🗑 Delete</button>`;
  } else if (state === 'stopped') {
    actions =
      `<button class="dbtn primary" onclick="dockerCardOp('start','${s.name}','${s.container}')">▶ Start</button>` +
      `<button class="dbtn"         onclick="dockerCardLogs('${s.name}','${s.container}')">📄 Logs</button>` +
      `<button class="dbtn danger"  onclick="dockerCardOp('delete','${s.name}','${s.container}')" title="Remove the container">🗑 Delete</button>`;
  } else { // absent
    actions =
      `<button class="dbtn primary" onclick="dockerCardOp('install','${s.name}','${s.container}')">⬇ Install</button>`;
  }

  return `
    <div class="dcard s-${state}" id="dcard-${s.name}">
      <div class="dcard-top">
        <span class="dcard-dot"></span>
        <span class="dcard-name" title="${escHtml(s.name)}">${escHtml(s.label)}</span>
        <span class="dcard-state">${stateText}</span>
        <button class="dcard-remove" title="Remove from your catalog" onclick="dockerRemoveFromCatalog('${s.name}')">✕</button>
      </div>
      <div class="dcard-cat">${escHtml(s.group)}</div>
      <div class="dcard-img" title="${escHtml(s.fullImage || '')}">${escHtml(s.fullImage || '—')}</div>
      <div class="dcard-meta">
        ${portStr ? `<span>ports <b>${escHtml(portStr)}</b></span>` : '<span style="color:var(--text3)">no published ports</span>'}
        ${uptime ? `<span class="dcard-uptime">up ${escHtml(uptime)}</span>` : ''}
      </div>
      <div class="dcard-actions">${actions}</div>
    </div>`;
}

// Remove a service from your catalog (stops + removes its container, best-effort).
async function dockerRemoveFromCatalog(name) {
  const ok = await uiConfirm({
    title: `Remove "${name}"?`,
    message: 'This removes it from your Docker Services list and deletes its container, if any.\nThe image itself is untouched.',
    confirmText: '✕ Remove', danger: true,
  });
  if (!ok) return;
  try {
    const resp = await fetch(`${API}/api/docker/catalog/${encodeURIComponent(name)}?session=${sessionId}`, { method: 'DELETE' });
    if (!resp.ok) throw new Error((await resp.json()).error || 'failed');
    toast(`Removed "${name}"`, 'success');
    initDockerTab(true);
  } catch (e) { toast(`Could not remove "${name}": ${e.message}`, 'error'); }
}

function renderDockerCards() {
  const grid = document.getElementById('docker-cards-grid');
  if (!grid) return;
  const q = (document.getElementById('docker-search')?.value || '').toLowerCase().trim();

  let list = _dockerServices.slice();
  if (_dockerFilter !== 'all') list = list.filter(s => s.group === _dockerFilter);
  if (q) list = list.filter(s =>
    s.name.toLowerCase().includes(q) || (s.image || '').toLowerCase().includes(q) || s.label.toLowerCase().includes(q));

  // Summary (always over the full catalog, not the filtered view)
  const runningAll   = _dockerServices.filter(s => containerState(_dockerContainers[s.container]) === 'running').length;
  const installedAll = _dockerServices.filter(s => _dockerContainers[s.container]).length;
  const sum = document.getElementById('docker-summary');
  if (sum) sum.textContent = _dockerServices.length
    ? `${runningAll} running · ${installedAll} installed · ${_dockerServices.length} total`
    : '—';

  if (!_dockerServices.length) {
    grid.innerHTML = '<div class="docker-empty">Nothing here yet — click <b>+ Add Image</b> above to search Docker Hub and add one.</div>';
    return;
  }
  if (!list.length) { grid.innerHTML = '<div class="docker-empty">No services match your filter.</div>'; return; }

  // Partition into Running / Stopped / Not installed (busy keeps its underlying state for grouping).
  const buckets = { running: [], stopped: [], absent: [] };
  for (const s of list) buckets[containerState(_dockerContainers[s.container])].push(s);
  for (const k of Object.keys(buckets)) buckets[k].sort((a, b) => a.name.localeCompare(b.name));

  const sections = [
    { key: 'running', label: 'Running',       cls: 'sec-running' },
    { key: 'stopped', label: 'Stopped',       cls: 'sec-stopped' },
    { key: 'absent',  label: 'Not Installed', cls: 'sec-absent'  },
  ];

  grid.innerHTML = sections.filter(sec => buckets[sec.key].length).map(sec => `
    <div class="docker-section">
      <div class="docker-section-head ${sec.cls}">
        <span class="docker-section-dot"></span>${sec.label}
        <span class="docker-section-count">${buckets[sec.key].length}</span>
      </div>
      <div class="row g-3 docker-section-grid">
        ${buckets[sec.key].map(s => `<div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6">${dockerCardHtml(s)}</div>`).join('')}
      </div>
    </div>`).join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// Add Image modal — search Docker Hub (defaults to popular official images),
// pick one, configure it, add it to your catalog.
// ─────────────────────────────────────────────────────────────────────────────

let _dockerHubResults  = [];    // current result list (popular or search)
let _dockerHubSelected = null;  // { repo, description } once a result is picked
let _dockerHubTags     = [];    // tags for the selected repo
let _dockerHubSearchTimer = null;

function openDockerAddModal() {
  document.getElementById('docker-add-modal').classList.remove('hidden');
  backToDockerHubResults();
  document.getElementById('docker-hub-search').value = '';
  dockerHubLoadPopular();
}

async function dockerHubLoadPopular() {
  const box = document.getElementById('docker-hub-results');
  box.innerHTML = '<div class="docker-empty">Loading popular images…</div>';
  try {
    const resp = await fetch(`${API}/api/docker/hub/popular?session=${sessionId}`);
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'failed');
    _dockerHubResults = data.results || [];
    renderDockerHubResults('Popular official images');
  } catch (e) { box.innerHTML = `<div class="docker-empty">${escHtml(e.message)}</div>`; }
}

function dockerHubSearchInput() {
  clearTimeout(_dockerHubSearchTimer);
  const q = document.getElementById('docker-hub-search').value.trim();
  if (!q) { dockerHubLoadPopular(); return; }
  _dockerHubSearchTimer = setTimeout(() => dockerHubSearch(q), 350);
}

async function dockerHubSearch(q) {
  const box = document.getElementById('docker-hub-results');
  box.innerHTML = '<div class="docker-empty">Searching…</div>';
  try {
    const resp = await fetch(`${API}/api/docker/hub/search?session=${sessionId}&q=${encodeURIComponent(q)}`);
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'failed');
    _dockerHubResults = data.results || [];
    renderDockerHubResults(`Results for "${q}"`);
  } catch (e) { box.innerHTML = `<div class="docker-empty">${escHtml(e.message)}</div>`; }
}

function renderDockerHubResults(heading) {
  const box = document.getElementById('docker-hub-results');
  if (!_dockerHubResults.length) { box.innerHTML = '<div class="docker-empty">No matching images.</div>'; return; }
  box.innerHTML = `<div class="docker-hub-heading">${escHtml(heading)}</div>` +
    _dockerHubResults.map((r, i) => `
      <div class="docker-hub-row" onclick="selectDockerHubImage(${i})">
        <div class="docker-hub-row-name">${escHtml(r.repo)}${r.isOfficial ? ' <span class="docker-hub-badge">official</span>' : ''}</div>
        <div class="docker-hub-row-desc">${escHtml(r.description || 'No description')}</div>
        <div class="docker-hub-row-meta">⭐ ${r.starCount.toLocaleString()} · ⬇ ${r.pullCount.toLocaleString()}</div>
      </div>`).join('');
}

function backToDockerHubResults() {
  _dockerHubSelected = null;
  document.getElementById('docker-hub-search-wrap').classList.remove('hidden');
  document.getElementById('docker-hub-results').classList.remove('hidden');
  document.getElementById('docker-add-form').classList.add('hidden');
}

async function selectDockerHubImage(i) {
  const r = _dockerHubResults[i];
  _dockerHubSelected = r;
  document.getElementById('docker-hub-search-wrap').classList.add('hidden');
  document.getElementById('docker-hub-results').classList.add('hidden');
  const form = document.getElementById('docker-add-form');
  form.classList.remove('hidden');

  const suggestedName = r.repo.split('/').pop();
  const knownGroups = _dockerGroups.map(g => g.id).filter(g => g !== 'Ungrouped');
  form.innerHTML = `
    <div class="field-hint" style="margin-bottom:10px"><a onclick="backToDockerHubResults()" style="cursor:pointer">← Back to results</a></div>
    <div class="field">
      <label>Image</label>
      <input id="da-image" type="text" value="${escHtml(r.repo)}" readonly/>
    </div>
    <div class="field">
      <label>Tag / version</label>
      <select id="da-tag"><option>Loading…</option></select>
    </div>
    <div class="field">
      <label>Name <span class="opt">used for the container — letters, numbers, dashes</span></label>
      <input id="da-name" type="text" value="${escHtml(suggestedName)}"/>
    </div>
    <div class="field">
      <label>Group <span class="opt">optional — for filtering your grid</span></label>
      <input id="da-group" type="text" list="da-group-list" placeholder="e.g. Infrastructure"/>
      <datalist id="da-group-list">${knownGroups.map(g => `<option value="${escHtml(g)}">`).join('')}</datalist>
    </div>
    <div class="field">
      <label>Ports <span class="opt">optional — one per line, host:container</span></label>
      <textarea id="da-ports" rows="2" placeholder="6379:6379"></textarea>
    </div>
    <div class="field">
      <label>Environment variables <span class="opt">optional — one per line, KEY=value</span></label>
      <textarea id="da-env" rows="2" placeholder="FOO=bar"></textarea>
    </div>
    <button class="btn btn-primary" onclick="submitDockerAdd()">+ Add to my services</button>
  `;

  try {
    const resp = await fetch(`${API}/api/docker/hub/tags?session=${sessionId}&repo=${encodeURIComponent(r.repo)}`);
    const data = await resp.json();
    const tags = (data.tags && data.tags.length) ? data.tags : ['latest'];
    document.getElementById('da-tag').innerHTML = tags.map(t => `<option ${t === 'latest' ? 'selected' : ''}>${escHtml(t)}</option>`).join('');
  } catch (e) { document.getElementById('da-tag').innerHTML = '<option>latest</option>'; }
}

// Parse "host:container" lines into [{host,container}], skipping malformed ones.
function parsePortLines(text) {
  return text.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
    const m = l.match(/^(\d+):(\d+)$/);
    return m ? { host: Number(m[1]), container: Number(m[2]) } : null;
  }).filter(Boolean);
}
// Parse "KEY=value" lines into an object, skipping malformed ones.
function parseEnvLines(text) {
  const env = {};
  for (const l of text.split('\n').map(l => l.trim()).filter(Boolean)) {
    const idx = l.indexOf('=');
    if (idx > 0) env[l.slice(0, idx)] = l.slice(idx + 1);
  }
  return env;
}

async function submitDockerAdd() {
  const image = _dockerHubSelected.repo;
  const tag   = document.getElementById('da-tag').value;
  const name  = document.getElementById('da-name').value.trim();
  const group = document.getElementById('da-group').value.trim();
  const ports = parsePortLines(document.getElementById('da-ports').value);
  const env   = parseEnvLines(document.getElementById('da-env').value);

  try {
    const resp = await fetch(`${API}/api/docker/catalog`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, name, image, tag, ports, env, group }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'failed');
    closeModal('docker-add-modal');
    toast(`Added "${data.service.name}" — click Install on its card to start it`, 'success');
    initDockerTab(true);
  } catch (e) { toast(`Could not add image: ${e.message}`, 'error'); }
}
