'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const A = require('./appraisal-prep');

const local = (y, m, d, h = 12) => new Date(y, m - 1, d, h, 0, 0, 0);

test('dates format and parse as local calendar days, and reject impossible ones', () => {
  assert.equal(A.aptFmtDate(local(2026, 3, 5)), '2026-03-05');
  assert.equal(A.aptFmtDate(A.aptParseDate('2026-03-05')), '2026-03-05');
  for (const bad of ['2026-02-31', '2026-13-01', 'yesterday', '', null, undefined, '26-01-01']) assert.equal(A.aptParseDate(bad), null, String(bad));
});

test('"months before" clamps to the end of a shorter month', () => {
  assert.equal(A.aptFmtDate(A.aptMonthsBefore(local(2026, 8, 31), 6)), '2026-02-28');
  assert.equal(A.aptFmtDate(A.aptMonthsBefore(local(2026, 3, 15), 12)), '2025-03-15');
  assert.equal(A.aptFmtDate(A.aptMonthsBefore(local(2026, 1, 10), 6)), '2025-07-10');
});

test('presets: last quarter is the previous calendar quarter, including across a year end', () => {
  assert.deepEqual(A.aptPresetRange('last-quarter', local(2026, 10, 6)), { mode: 'range', from: '2026-07-01', to: '2026-09-30' });
  assert.deepEqual(A.aptPresetRange('last-quarter', local(2026, 1, 15)), { mode: 'range', from: '2025-10-01', to: '2025-12-31' });
  assert.deepEqual(A.aptPresetRange('last-quarter', local(2026, 4, 1)), { mode: 'range', from: '2026-01-01', to: '2026-03-31' });
  assert.deepEqual(A.aptPresetRange('last-6-months', local(2026, 10, 6)), { mode: 'range', from: '2026-04-06', to: '2026-10-06' });
  assert.deepEqual(A.aptPresetRange('last-12-months', local(2026, 10, 6)), { mode: 'range', from: '2025-10-06', to: '2026-10-06' });
  assert.equal(A.aptPresetRange('nonsense'), null);
});

const NOW = local(2026, 10, 6);

test('a range becomes the start of the first day and the end of the last day, with the time zone', () => {
  const r = A.aptBuildRequest({ mode: 'range', from: '2026-01-01', to: '2026-03-31' }, NOW, 'Europe/London');
  assert.equal(r.ok, true);
  assert.equal(r.body.mode, 'range');
  assert.equal(r.body.tz, 'Europe/London');
  const from = new Date(r.body.from); const to = new Date(r.body.to);
  assert.deepEqual([from.getFullYear(), from.getMonth(), from.getDate(), from.getHours(), from.getMinutes(), from.getSeconds(), from.getMilliseconds()], [2026, 0, 1, 0, 0, 0, 0]);
  assert.deepEqual([to.getFullYear(), to.getMonth(), to.getDate(), to.getHours(), to.getMinutes(), to.getSeconds(), to.getMilliseconds()], [2026, 2, 31, 23, 59, 59, 999]);
});

test('"to date" sends no end date', () => {
  const r = A.aptBuildRequest({ mode: 'to-date', from: '2026-07-01', to: 'ignored' }, NOW, 'UTC');
  assert.equal(r.ok, true);
  assert.equal(r.body.mode, 'to-date');
  assert.equal(r.body.to, undefined);
});

test('every way the form can be wrong is explained', () => {
  const cases = [
    [{ mode: 'range', from: '', to: '2026-03-31' }, /start date/],
    [{ mode: 'range', from: '2026-02-31', to: '2026-03-31' }, /start date/],
    [{ mode: 'range', from: '2026-12-01', to: '2026-12-31' }, /future/],
    [{ mode: 'range', from: '2026-01-01', to: '' }, /end date/],
    [{ mode: 'range', from: '2026-04-01', to: '2026-03-01' }, /must not be after/],
    [{ mode: 'range', from: '2026-01-01', to: '2026-12-31' }, /future/],
    [{ mode: 'range', from: '2023-01-01', to: '2026-03-31' }, /24 months/],
    [{ mode: 'to-date', from: '2023-01-01' }, /24 months/],
    [{ mode: 'to-date', from: '2027-01-01' }, /future/],
  ];
  for (const [form, message] of cases) {
    const r = A.aptBuildRequest(form, NOW, 'UTC');
    assert.equal(r.ok, false, JSON.stringify(form));
    assert.match(r.error, message);
  }
});

test('starting today is allowed, and a one-day range is valid', () => {
  assert.equal(A.aptBuildRequest({ mode: 'to-date', from: '2026-10-06' }, NOW, 'UTC').ok, true);
  assert.equal(A.aptBuildRequest({ mode: 'range', from: '2026-10-06', to: '2026-10-06' }, NOW, 'UTC').ok, true);
});

const CAND = { id: 'quickTurnaround', title: 'Quick turnaround', text: 'Rule text.' };

test('confirming a suggestion keeps its AI wording and flag, once, and un-dismisses it', () => {
  let d = A.aptDismissCandidate(A.aptEmptyDraft(), CAND.id);
  assert.deepEqual(d.dismissed, ['quickTurnaround']);
  d = A.aptConfirmCandidate(d, CAND, { id: CAND.id, text: 'AI wording.', ai: true });
  assert.deepEqual(d.confirmed, [{ id: 'quickTurnaround', title: 'Quick turnaround', text: 'AI wording.', source: 'suggested', ai: true }]);
  assert.deepEqual(d.dismissed, []);
  assert.equal(A.aptConfirmCandidate(d, CAND, null).confirmed.length, 1, 'no duplicate');
  assert.equal(A.aptConfirmCandidate(A.aptEmptyDraft(), CAND, null).confirmed[0].text, 'Rule text.');
});

test('dismissing removes a confirmed one too, and dismissed ones can be restored', () => {
  let d = A.aptConfirmCandidate(A.aptEmptyDraft(), CAND, null);
  d = A.aptDismissCandidate(d, CAND.id);
  assert.deepEqual([d.confirmed.length, d.dismissed], [0, ['quickTurnaround']]);
  assert.deepEqual(A.aptRestoreDismissed(d).dismissed, []);
});

test('own kudos, edits and removal work, and blanks are ignored', () => {
  let d = A.aptAddOwnKudos(A.aptEmptyDraft(), '', '  Mentored two new joiners  ');
  assert.equal(d.confirmed[0].text, 'Mentored two new joiners');
  assert.equal(d.confirmed[0].source, 'own');
  assert.equal(A.aptAddOwnKudos(d, '', '   ').confirmed.length, 1);
  d = A.aptUpdateConfirmed(d, 0, 'Mentored three');
  assert.equal(d.confirmed[0].text, 'Mentored three');
  assert.equal(A.aptUpdateConfirmed(d, 9, 'x').confirmed.length, 1, 'a bad index changes nothing');
  assert.equal(A.aptRemoveConfirmed(d, 0).confirmed.length, 0);
});

test('edits never change the draft they were given', () => {
  const original = A.aptConfirmCandidate(A.aptEmptyDraft(), CAND, null);
  const snapshot = JSON.stringify(original);
  A.aptDismissCandidate(original, CAND.id);
  A.aptAddOwnKudos(original, 't', 'x');
  A.aptUpdateConfirmed(original, 0, 'changed');
  A.aptRemoveConfirmed(original, 0);
  A.aptInsertPrompt(original, 'q');
  assert.equal(JSON.stringify(original), snapshot);
});

test('a prompt is appended as its own bullet line', () => {
  let d = A.aptInsertPrompt(A.aptEmptyDraft(), 'What went well?');
  assert.equal(d.talkingPoints, '- What went well?\n');
  d = A.aptInsertPrompt({ ...d, talkingPoints: 'My own line' }, 'What was hard?');
  assert.equal(d.talkingPoints, 'My own line\n- What was hard?\n');
});

test('pending suggestions exclude the confirmed and the dismissed', () => {
  const cands = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
  let d = A.aptConfirmCandidate(A.aptEmptyDraft(), { id: 'a', title: 'A', text: 'x' }, null);
  d = A.aptDismissCandidate(d, 'b');
  assert.deepEqual(A.aptPending(cands, d).map(c => c.id), ['c']);
  assert.deepEqual(A.aptPending(cands, null).map(c => c.id), ['a', 'b', 'c']);
});

test('a missing or partial saved draft is filled out, never undefined', () => {
  assert.deepEqual(A.aptNormaliseDraft(null), A.aptEmptyDraft());
  const d = A.aptNormaliseDraft({ talkingPoints: 'x' });
  assert.deepEqual([d.confirmed, d.dismissed, d.include], [[], [], {}]);
});

test('this tab never reads the Notes tab or the prefs file (static guard on the source)', () => {
  const code = fs.readFileSync(path.join(__dirname, 'appraisal-prep.js'), 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
  // Identifiers and endpoints that would reach the Notes tab or the prefs file. The word
  // "notes" in user-facing labels ("Notes for the discussion") is this tab's own text.
  assert.doesNotMatch(code, /\/api\/prefs|oasis-prefs|localStorage|sessionStorage|initNotesTab|renderNotes|persistNotes|noteId|notes-grid|tab-notes|\bnotes\s*[.\[=]|getElementById\(['"]notes/);
  assert.match(code, /\/api\/appraisal/);
});

test('this tab offers no way to share: no mail, upload, share-sheet or clipboard, and one network call to its own API', () => {
  const code = fs.readFileSync(path.join(__dirname, 'appraisal-prep.js'), 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
  assert.doesNotMatch(code, /mailto:|navigator\.share|navigator\.clipboard|sendBeacon|XMLHttpRequest|WebSocket|window\.open|\.upload\b/);
  assert.equal((code.match(/\bfetch\(/g) || []).length, 1, 'the only request is aptApi');
  assert.match(code, /fetch\(url,/);
  assert.match(code, /\$\{API\}\/api\/appraisal/);
});
