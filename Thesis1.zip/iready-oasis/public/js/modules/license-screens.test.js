'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// The licence page's Activate and Buy screens, driven against the real license.js with a small fake
// page and a fake network.

const UNREGISTERED = { status: 'unregistered', locked: true, reason: 'no_entitlement', features: [], tokenError: null, trialDays: 7,
  serviceUrl: 'http://localhost:4010', message: 'Start your 7-day trial, buy a licence, or enter a key you already have.' };
const EXPIRED = { status: 'expired', locked: true, reason: 'license_expired', features: [], message: 'This licence expired.' };

function load({ status = UNREGISTERED, answers = {} } = {}) {
  const calls = [];
  const fields = {};
  let overlayHtml = '';
  const classes = new Set(['hidden']);          // the overlay exists but is not showing yet
  const overlay = {
    id: 'license-overlay', className: '',
    get innerHTML() { return overlayHtml; },
    set innerHTML(v) { overlayHtml = v; for (const k of Object.keys(fields)) delete fields[k]; },
    classList: { add: c => classes.add(c), remove: c => classes.delete(c), contains: c => classes.has(c), toggle() {} },
  };
  // Like a browser, a field starts out hidden or disabled when its tag says so.
  const flag = (id, name) => { const tag = overlayHtml.match(new RegExp(`<[^>]*id="${id}"[^>]*>`)); return !!tag && new RegExp(`\\s${name}(\\s|>|=|/)`).test(tag[0]); };
  const field = id => {
    if (!fields[id]) fields[id] = { id, value: '', textContent: '', disabled: flag(id, 'disabled'), hidden: flag(id, 'hidden'), focused: false, attrs: {}, focus() { this.focused = true; }, setAttribute(k, v) { this.attrs[k] = v; }, removeAttribute(k) { delete this.attrs[k]; }, classList: { add() {}, remove() {}, contains: () => false, toggle() {} } };
    return fields[id];
  };
  const appEl = { classList: { contains: () => true, add() {}, remove() {}, toggle() {} } };
  const sandbox = {
    API: 'http://app.test', sessionId: 'sess-1', console, setInterval() {}, clearInterval() {}, alert() {}, toast() {}, autoResume() {},
    location: { reload() { calls.push('RELOAD'); } },
    document: {
      readyState: 'complete', hidden: false, addEventListener() {}, createElement: () => overlay, querySelectorAll: () => [], querySelector: () => null,
      body: { appendChild() {} },
      getElementById(id) {
        if (id === 'license-overlay') return overlay;
        if (id === 'main-app') return appEl;
        return overlayHtml.includes(`id="${id}"`) ? field(id) : null;
      },
    },
    fetch: async (url, opts = {}) => {
      const route = String(url).replace('http://app.test', '');
      const body = opts.body ? JSON.parse(opts.body) : null;
      calls.push({ route, method: opts.method || 'GET', body, headers: opts.headers || {} });
      if (route === '/api/license/status') return { ok: true, status: 200, json: async () => status };
      const a = answers[route];
      const r = typeof a === 'function' ? a(body) : a;
      if (!r) return { ok: true, status: 200, json: async () => ({}) };
      if (r.throws) throw new Error('network down');
      return { ok: r.status < 400, status: r.status, json: async () => r.body };
    },
  };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'license.js'), 'utf8'), sandbox);
  const posts = route => calls.filter(c => c.route === route && c.method === 'POST');
  return { sandbox, calls, posts, html: () => overlayHtml, field, run: code => vm.runInContext(code, sandbox), shown: () => !classes.has('hidden') && !!overlayHtml };
}
const settle = async () => { for (let i = 0; i < 4; i++) await new Promise(r => setImmediate(r)); };
async function ready(opts) { const t = load(opts); await settle(); return t; }

// ── The first page ────────────────────────────────────────────────────────────

test('the first page offers Start trial, Activate licence and Buy a licence, and no key box', async () => {
  const t = await ready();
  assert.match(t.html(), /Start 7-day free trial/);
  assert.match(t.html(), /id="lic-activate-btn"[^>]*>\s*Activate licence/);
  assert.match(t.html(), /id="lic-buy-btn"[^>]*>\s*Buy a licence/);
  assert.doesNotMatch(t.html(), /Already have a licence key|id="lic-key"|OASIS-XXXX/);
  assert.match(t.html(), /Start your 7-day trial, buy a licence, or enter a key you already have\./);
});

test('an expired trial offers Activate and Buy, and no trial', async () => {
  const t = await ready({ status: EXPIRED });
  assert.doesNotMatch(t.html(), /lic-trial-btn/);
  assert.match(t.html(), /lic-activate-btn/);
  assert.match(t.html(), /lic-buy-btn/);
});

// ── Activate: the email ───────────────────────────────────────────────────────

test('Activate licence asks for the corporate email, with a way to buy instead and a way back', async () => {
  const t = await ready();
  t.run('showLicenseView("activate")');
  assert.match(t.html(), /<label for="lic-email">[^<]*email/i);
  assert.match(t.html(), /id="lic-email"[^>]*type="email"/);
  assert.match(t.html(), /id="lic-send-btn"/);
  assert.match(t.html(), /id="lic-buy-instead"/);
  assert.match(t.html(), /id="lic-back-btn"/);
  assert.equal(t.field('lic-email').focused, true, 'the cursor is already in the box');
  assert.doesNotMatch(t.html(), /lic-trial-btn/);
});

test('a bad email is caught on the page, with nothing sent', async () => {
  const t = await ready();
  t.run('showLicenseView("activate")');
  for (const bad of ['', 'nonsense', 'a@b', 'two@@x.com']) {
    t.field('lic-email').value = bad;
    await t.run('licenseSendCode()');
    assert.equal(t.posts('/api/license/email-code').length, 0, bad);
  }
  assert.match(t.field('lic-error').textContent, /valid email/i);
});

test('a good email asks for a code, then shows the masked address and the code box', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 200, body: { ok: true, sentTo: 'p***@acme.example.test', expiresInMinutes: 10 } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = '  Pat@Acme.Example.Test ';
  await t.run('licenseSendCode()');
  assert.deepEqual(t.posts('/api/license/email-code')[0].body, { email: 'pat@acme.example.test' });
  assert.match(t.html(), /p\*\*\*@acme\.example\.test/);
  assert.match(t.html(), /id="lic-code"[^>]*inputmode="numeric"[^>]*maxlength="6"[^>]*autocomplete="one-time-code"/);
  assert.equal(t.field('lic-code').focused, true);
});

test('sending twice quickly sends one request', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 200, body: { ok: true, sentTo: 'p***@acme.example.test' } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  const first = t.run('licenseSendCode()');
  const second = t.run('licenseSendCode()');
  await Promise.all([first, second]);
  assert.equal(t.posts('/api/license/email-code').length, 1);
});

test('a company with no licence is told so, and is offered the way to buy', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 400, body: { error: 'rejected', message: 'No licence was found for nobody.example.test.', details: { reason: 'no_domain_licence' } } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@nobody.example.test';
  await t.run('licenseSendCode()');
  assert.match(t.field('lic-error').textContent, /No licence was found for nobody\.example\.test/);
  assert.match(t.html(), /id="lic-buy-instead"/, 'the buy link is still there');
  assert.equal(t.field('lic-send-btn').disabled, false, 'and they can try another address');
});

test('an unreachable service is reported with the address that was tried', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 503, body: { error: 'unreachable', message: 'Could not reach the licence service' } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()');
  assert.match(t.field('lic-error').textContent, /Could not reach the licence service \(http:\/\/localhost:4010\)/);
});

test('the server\'s words are shown as text, never as page markup', async () => {
  const evil = '<img src=x onerror=alert(1)>';
  const t = await ready({ answers: { '/api/license/email-code': { status: 400, body: { error: 'rejected', message: evil, details: {} } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()');
  assert.equal(t.field('lic-error').textContent, evil);
  assert.doesNotMatch(t.html(), /onerror/);
});

test('a masked address from the server cannot inject markup into the code screen', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 200, body: { ok: true, sentTo: '<b onmouseover=x>p***</b>' } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()');
  assert.doesNotMatch(t.html(), /<b onmouseover/);
  assert.match(t.html(), /&lt;b onmouseover/);
});

// ── Activate: the code ────────────────────────────────────────────────────────

async function atCodeScreen(extra = {}) {
  const t = await ready({ answers: { '/api/license/email-code': { status: 200, body: { ok: true, sentTo: 'p***@acme.example.test' } }, ...extra } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()');
  return t;
}

test('a code that is not six digits is caught on the page, with nothing sent', async () => {
  const t = await atCodeScreen();
  for (const bad of ['', '123', '12345a', '1234567']) {
    t.field('lic-code').value = bad;
    await t.run('licenseVerifyCode()');
  }
  assert.equal(t.posts('/api/license/activate-email').length, 0);
  assert.match(t.field('lic-error').textContent, /6-digit/);
});

test('the right code activates, and the app reloads into setup', async () => {
  const t = await atCodeScreen({ '/api/license/activate-email': { status: 200, body: { status: 'licensed', locked: false, expiresAt: Date.UTC(2099, 11, 31) } } });
  t.field('lic-code').value = ' 123456 ';
  await t.run('licenseVerifyCode()');
  assert.deepEqual(t.posts('/api/license/activate-email')[0].body, { email: 'pat@acme.example.test', code: '123456' });
  assert.ok(t.calls.includes('RELOAD'), 'out of the lock, the page reloads against a valid licence');
});

test('a wrong code says how many tries are left, and lets them try again', async () => {
  const t = await atCodeScreen({ '/api/license/activate-email': { status: 400, body: { error: 'rejected', message: 'That code is not right. 4 tries left.', details: { reason: 'wrong_code' } } } });
  t.field('lic-code').value = '000000';
  await t.run('licenseVerifyCode()');
  assert.match(t.field('lic-error').textContent, /4 tries left/);
  assert.equal(t.field('lic-verify-btn').disabled, false);
  assert.equal(t.field('lic-code').value, '', 'the box is cleared for the next try');
  assert.ok(!t.calls.includes('RELOAD'));
});

test('an ended licence is reported with its date, and the buy link is offered', async () => {
  const t = await atCodeScreen({ '/api/license/activate-email': { status: 400, body: { error: 'rejected', message: 'Your organization\'s licence ended on 2026-09-08. Contact support to renew it.', details: { reason: 'expired', expiredOn: '2026-09-08' } } } });
  t.field('lic-code').value = '123456';
  await t.run('licenseVerifyCode()');
  assert.match(t.field('lic-error').textContent, /ended on 2026-09-08/);
  assert.match(t.html(), /id="lic-buy-instead"/);
  assert.ok(!t.calls.includes('RELOAD'));
});

test('a code that has expired or been used up sends them back to ask for a new one', async () => {
  for (const reason of ['expired', 'too_many_attempts', 'no_code']) {
    const t = await atCodeScreen({ '/api/license/activate-email': { status: 400, body: { error: 'rejected', message: `code problem: ${reason}`, details: { reason } } } });
    t.field('lic-code').value = '123456';
    await t.run('licenseVerifyCode()');
    assert.match(t.html(), /id="lic-resend-btn"/, reason);
    assert.match(t.field('lic-error').textContent, new RegExp(reason));
  }
});

test('"Send a new code" asks again, and Back returns to the email with the address kept', async () => {
  const t = await atCodeScreen();
  await t.run('licenseResendCode()');
  assert.equal(t.posts('/api/license/email-code').length, 2);
  t.run('licenseBack()');
  assert.match(t.html(), /id="lic-email"/);
  assert.match(t.html(), /value="pat@acme\.example\.test"/);
});

// ── Buy ───────────────────────────────────────────────────────────────────────

const FORM = { 'lic-org': 'Acme Example Ltd', 'lic-employees': '250', 'lic-buy-email': 'pat@acme.example.test', 'lic-contact-name': 'Pat Example' };
const fill = (t, values) => { for (const [id, v] of Object.entries(values)) t.field(id).value = v; };
const TOKEN = '1999999999999.' + 'e'.repeat(64);
const VERIFY = {
  '/api/license/purchase-code': { status: 200, body: { ok: true, sentTo: 'p***@acme.example.test' } },
  '/api/license/purchase-verify': { status: 200, body: { ok: true, verificationToken: TOKEN } },
};
// The person fills the form, asks for a code, types it and verifies: the state in which Submit may work.
async function verifyEmail(t) {
  fill(t, FORM);
  await t.run('licenseBuySendCode()');
  t.field('lic-buy-code').value = '123456';
  await t.run('licenseBuyVerify()');
}

test('Buy a licence asks for the organization, number of employees, email and contact name, and nothing more', async () => {
  const t = await ready();
  t.run('showLicenseView("buy")');
  for (const id of Object.keys(FORM)) assert.match(t.html(), new RegExp(`id="${id}"`), id);
  assert.match(t.html(), /<label for="lic-org">/);
  assert.match(t.html(), /id="lic-employees"[^>]*inputmode="numeric"/);
  assert.doesNotMatch(t.html(), /lic-phone|lic-requirement|Phone number|What do you need/, 'the phone and requirement boxes are gone');
  assert.match(t.html(), /id="lic-submit-btn"/);
  assert.match(t.html(), /id="lic-back-btn"/);
  assert.equal(t.field('lic-org').focused, true);
});

test('an incomplete form shows a message beside every missing field, and sends nothing', async () => {
  const t = await ready();
  t.run('showLicenseView("buy")');
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.posts('/api/license/purchase-request').length, 0);
  for (const f of ['org', 'employees', 'buy-email', 'contact-name']) {
    assert.ok(t.field(`lic-err-${f}`).textContent.length > 0, `${f} has a message`);
  }
});

test('after a failed submit the cursor goes to the first box that needs fixing', async () => {
  const t = await ready();
  t.run('showLicenseView("buy")');
  fill(t, { ...FORM, 'lic-employees': '', 'lic-contact-name': '' });
  t.field('lic-org').focused = false;
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.field('lic-employees').focused, true, 'the first empty box');
  assert.equal(t.field('lic-contact-name').focused, false);
  assert.equal(t.field('lic-employees').attrs['aria-invalid'], 'true', 'and it is marked as invalid for screen readers');
});

test('a complete form is sent, and the thank-you shows the reference', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 200, body: { ok: true, reference: 'PR-0007' } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  await t.run('licenseSubmitPurchase()');
  assert.deepEqual(t.posts('/api/license/purchase-request')[0].body,
    { organization: 'Acme Example Ltd', employees: '250', email: 'pat@acme.example.test', contactName: 'Pat Example', verificationToken: TOKEN });
  assert.match(t.html(), /support team/i);
  assert.match(t.html(), /PR-0007/);
});

const keyOf = t => t.posts('/api/license/purchase-request').map(p => p.headers['Idempotency-Key']);

test('every Buy submit carries an Idempotency-Key; a retry of the same details reuses it, edited details get a new one', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 503, body: { message: 'down' } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  await t.run('licenseSubmitPurchase()');
  await t.run('licenseSubmitPurchase()');                       // the connection dropped; the person tries again
  const [first, retry] = keyOf(t);
  assert.match(first, /^[A-Za-z0-9_-]{8,100}$/, 'a key the service will accept');
  assert.equal(retry, first, 'same details, same key, so the service can recognise the repeat');
  t.field('lic-org').value = 'Acme Example Holdings';
  await t.run('licenseSubmitPurchase()');
  assert.notEqual(keyOf(t)[2], first, 'changed details are a new request, not a repeat');
});

test('after a successful submit the next request gets a fresh key', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 200, body: { ok: true, reference: 'PR-0001' } } } });
  t.run('showLicenseView("buy")'); await verifyEmail(t); await t.run('licenseSubmitPurchase()');
  t.run('showLicenseView("buy")'); await verifyEmail(t); await t.run('licenseSubmitPurchase()');
  const [a, b] = keyOf(t);
  assert.notEqual(a, b);
});

test('field problems found by the server are shown beside the right fields', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 400, body: { error: 'rejected', message: 'Some details need fixing.', details: { reason: 'invalid', errors: { contactName: 'Enter a contact name.' } } } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.field('lic-err-contact-name').textContent, 'Enter a contact name.');
  assert.match(t.html(), /id="lic-submit-btn"/, 'still on the form, with their answers kept');
  assert.equal(t.field('lic-submit-btn').disabled, false);
});

test('a double click on Submit sends one request', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 200, body: { ok: true, reference: 'PR-0001' } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  await Promise.all([t.run('licenseSubmitPurchase()'), t.run('licenseSubmitPurchase()')]);
  assert.equal(t.posts('/api/license/purchase-request').length, 1);
});

test('Back from Buy returns to the first page, and "Buy a licence instead" opens the form from Activate', async () => {
  const t = await ready();
  t.run('showLicenseView("buy")');
  t.run('licenseBack()');
  assert.match(t.html(), /lic-activate-btn/);
  t.run('showLicenseView("activate")');
  t.run('showLicenseView("buy")');
  assert.match(t.html(), /id="lic-org"/);
});

test('the entered email is carried into the buy form so they do not type it twice', async () => {
  const t = await ready();
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  t.run('licenseBuyInstead()');
  assert.match(t.html(), /id="lic-buy-email"[^>]*value="pat@acme\.example\.test"/);
});

test('no screen of the licence page shows the machine id or the licence service address', async () => {
  const t = await ready({ status: { ...UNREGISTERED, machineId: '7606014e477f73c4e70073bdf70fafdb' }, answers: { '/api/license/email-code': { status: 200, body: { ok: true, sentTo: 'p***@acme.example.test' } }, '/api/license/purchase-request': { status: 200, body: { ok: true, reference: 'PR-0001' } } } });
  const seen = [];
  seen.push(t.html());
  t.run('showLicenseView("activate")'); seen.push(t.html());
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()'); seen.push(t.html());
  t.run('showLicenseView("buy")'); seen.push(t.html());
  t.run('showLicenseView("bought", { reference: "PR-0001" })'); seen.push(t.html());
  assert.equal(seen.length, 5);
  for (const html of seen) {
    assert.doesNotMatch(html, /Machine ID|7606014e477f|Licence service|localhost:4010|lic-footer-note/);
  }
});

test('the page for an expired licence has no footer either', async () => {
  const t = await ready({ status: { ...EXPIRED, machineId: '7606014e477f73c4e70073bdf70fafdb', serviceUrl: 'http://localhost:4010' } });
  assert.doesNotMatch(t.html(), /Machine ID|localhost:4010/);
});

test('when the licence service cannot be reached, the message still says which address was tried', async () => {
  const t = await ready({ answers: { '/api/license/email-code': { status: 503, body: { error: 'unreachable', message: 'Could not reach the licence service' } } } });
  t.run('showLicenseView("activate")');
  t.field('lic-email').value = 'pat@acme.example.test';
  await t.run('licenseSendCode()');
  assert.match(t.field('lic-error').textContent, /\(http:\/\/localhost:4010\)/, 'the address appears only when something has gone wrong');
});

// ── Buy: the work email is proved with a code before the request can be sent ──

test('the Buy form asks for a work email, with Send code, a code box that starts hidden, and Submit off until verified', async () => {
  const t = await ready();
  t.run('showLicenseView("buy")');
  assert.match(t.html(), /work email/i);
  assert.match(t.html(), /id="lic-buy-send-btn"/);
  assert.match(t.html(), /id="lic-buy-code"/);
  assert.match(t.html(), /id="lic-buy-verify-btn"/);
  assert.equal(t.field('lic-buy-code-row').hidden, true, 'no code box until a code has been sent');
  assert.equal(t.field('lic-submit-btn').disabled, true, 'Submit stays off until the email is verified');
});

test('Send code posts the address and then shows the code box', async () => {
  const t = await ready({ answers: VERIFY });
  t.run('showLicenseView("buy")');
  fill(t, FORM);
  await t.run('licenseBuySendCode()');
  assert.deepEqual(t.posts('/api/license/purchase-code')[0].body, { email: 'pat@acme.example.test' });
  assert.equal(t.field('lic-buy-code-row').hidden, false);
});

test('a personal address is refused beside the email box, and no code box appears', async () => {
  const t = await ready({ answers: { '/api/license/purchase-code': { status: 400, body: { error: 'rejected', message: 'Use your work email address.', details: { reason: 'not_corporate_email' } } } } });
  t.run('showLicenseView("buy")');
  fill(t, { ...FORM, 'lic-buy-email': 'pat@gmail.com' });
  await t.run('licenseBuySendCode()');
  assert.match(t.field('lic-err-buy-email').textContent, /work email/i);
  assert.equal(t.field('lic-buy-code-row').hidden, true);
});

test('Send code needs something that looks like an email address, and sends nothing otherwise', async () => {
  const t = await ready({ answers: VERIFY });
  t.run('showLicenseView("buy")');
  fill(t, { ...FORM, 'lic-buy-email': 'nope' });
  await t.run('licenseBuySendCode()');
  assert.equal(t.posts('/api/license/purchase-code').length, 0);
  assert.ok(t.field('lic-err-buy-email').textContent.length > 0);
});

test('a wrong code keeps Submit off; the right code turns it on', async () => {
  let n = 0;
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-verify': () => (++n === 1
    ? { status: 400, body: { error: 'rejected', message: 'That code is not right. 4 tries left.', details: { reason: 'wrong_code' } } }
    : { status: 200, body: { ok: true, verificationToken: TOKEN } }) } });
  t.run('showLicenseView("buy")');
  fill(t, FORM);
  await t.run('licenseBuySendCode()');
  t.field('lic-buy-code').value = '000000';
  await t.run('licenseBuyVerify()');
  assert.equal(t.field('lic-submit-btn').disabled, true);
  t.field('lic-buy-code').value = '123456';
  await t.run('licenseBuyVerify()');
  assert.equal(t.field('lic-submit-btn').disabled, false);
});

test('a code that is not six digits is not sent', async () => {
  const t = await ready({ answers: VERIFY });
  t.run('showLicenseView("buy")');
  fill(t, FORM);
  await t.run('licenseBuySendCode()');
  t.field('lic-buy-code').value = '12';
  await t.run('licenseBuyVerify()');
  assert.equal(t.posts('/api/license/purchase-verify').length, 0);
});

test('changing the email after it was verified takes the verification back', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 200, body: { ok: true, reference: 'PR-0001' } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  assert.equal(t.field('lic-submit-btn').disabled, false);
  t.field('lic-buy-email').value = 'sam@acme.example.test';
  t.run('licenseBuyEmailChanged()');
  assert.equal(t.field('lic-submit-btn').disabled, true);
  assert.equal(t.field('lic-buy-code-row').hidden, true);
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.posts('/api/license/purchase-request').length, 0, 'nothing is sent for an address that was not verified');
});

test('Submit without a verified email sends nothing and says what to do', async () => {
  const t = await ready({ answers: VERIFY });
  t.run('showLicenseView("buy")');
  fill(t, FORM);
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.posts('/api/license/purchase-request').length, 0);
  assert.match(t.field('lic-err-buy-email').textContent, /verify/i);
});

test('if the service says the verification ran out, the form goes back to needing a new code', async () => {
  const t = await ready({ answers: { ...VERIFY, '/api/license/purchase-request': { status: 400, body: { error: 'rejected', message: 'Verify your email address with the code we send you before submitting.', details: { reason: 'email_not_verified' } } } } });
  t.run('showLicenseView("buy")');
  await verifyEmail(t);
  await t.run('licenseSubmitPurchase()');
  assert.equal(t.field('lic-submit-btn').disabled, true);
  assert.match(t.field('lic-err-buy-email').textContent, /code/i);
});
