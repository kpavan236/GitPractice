// =============================================================================
// Notes — sticky-note tasks: create/edit/close/delete, due-date reminders.
// Always auto-grouped like a JIRA board: Overdue and In Progress stay visible;
// Completed is collapsed behind an expand toggle so it doesn't crowd out
// what's still open.
// =============================================================================

let _notesReminderStarted = false;
let _notesCompletedExpanded = false;
let _notesToastedIds = new Set();   // note ids already reminded this session

function todayStr() { return new Date().toISOString().slice(0, 10); }

function noteId() { return 'n_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8); }

function initNotesTab() {
  renderNotes();
  startNotesReminders();
}

// Runs once per session — due-date checks continue regardless of which tab
// is active, same as how Wellness reminders aren't tied to a specific tab.
function startNotesReminders() {
  if (_notesReminderStarted) return;
  _notesReminderStarted = true;
  checkNoteReminders();
  setInterval(checkNoteReminders, 5 * 60 * 1000);
}

function checkNoteReminders() {
  const today = todayStr();
  notes.forEach(n => {
    if (n.status !== 'open' || !n.dueDate || n.dueDate > today) return;
    if (_notesToastedIds.has(n.id)) return;
    _notesToastedIds.add(n.id);
    const overdue = n.dueDate < today;
    toast(`"${n.title}" ${overdue ? 'is overdue' : 'is due today'}`, overdue ? 'error' : 'info');
  });
}

function formatDate(iso) {
  return new Date(iso + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function dueBadgeInfo(dueDate) {
  if (!dueDate) return null;
  const today = todayStr();
  if (dueDate < today) return { cls: 'note-due-overdue', label: `Overdue · ${formatDate(dueDate)}` };
  if (dueDate === today) return { cls: 'note-due-today', label: 'Due today' };
  return { cls: 'note-due-upcoming', label: `Due ${formatDate(dueDate)}` };
}

function sortOpenNotes(a, b) {
  if (a.dueDate && b.dueDate) return a.dueDate < b.dueDate ? -1 : a.dueDate > b.dueDate ? 1 : 0;
  if (a.dueDate) return -1;
  if (b.dueDate) return 1;
  return new Date(a.createdAt) - new Date(b.createdAt);
}

function sortClosedNotes(a, b) {
  return new Date(b.closedAt || b.updatedAt) - new Date(a.closedAt || a.updatedAt);
}

function stickyNoteHtml(note, idx) {
  const closed  = note.status === 'closed';
  const overdue = !closed && note.dueDate && note.dueDate < todayStr();
  const statusClass = closed ? 'status-done' : overdue ? 'status-overdue' : 'status-progress';
  const due = !closed ? dueBadgeInfo(note.dueDate) : null;
  // Phase-offset so notes don't sway in unison — a fixed negative delay makes
  // each card start mid-cycle at a different point.
  const delay = -((idx * 0.9) % 6).toFixed(2);
  return `
    <div class="sticky-note ${statusClass}" style="animation-delay:${delay}s">
      <div class="sticky-actions">
        ${closed
          ? `<button class="sticky-act-btn" title="Reopen" onclick="setNoteStatus('${note.id}','open')">↺</button>`
          : `<button class="sticky-act-btn" title="Edit" onclick="openNoteModal('${note.id}')">✎</button>
             <button class="sticky-act-btn" title="Mark complete" onclick="setNoteStatus('${note.id}','closed')">✓</button>`}
        <button class="sticky-act-btn sticky-act-danger" title="Delete" onclick="deleteNoteConfirm('${note.id}')">🗑</button>
      </div>
      <div class="sticky-title">${escHtml(note.title)}</div>
      ${note.body ? `<div class="sticky-body">${escHtml(note.body)}</div>` : ''}
      ${due ? `<div class="sticky-due ${due.cls}">${escHtml(due.label)}</div>` : ''}
    </div>`;
}

function renderNotes() {
  const grid = document.getElementById('notes-grid');
  if (!grid) return;

  const today      = todayStr();
  const overdue    = notes.filter(n => n.status === 'open' && n.dueDate && n.dueDate < today).sort(sortOpenNotes);
  const inProgress = notes.filter(n => n.status === 'open' && !(n.dueDate && n.dueDate < today)).sort(sortOpenNotes);
  const closed     = notes.filter(n => n.status === 'closed').sort(sortClosedNotes);

  if (!overdue.length && !inProgress.length && !closed.length) {
    grid.innerHTML = `<div class="docker-empty" style="grid-column:1/-1">No notes yet — create one to get started.</div>`;
    return;
  }

  let html = '';
  let idx = 0;
  if (overdue.length) {
    html += `<div class="notes-group-title">Overdue <span class="existing-count-badge">${overdue.length}</span></div>`;
    html += overdue.map(n => stickyNoteHtml(n, idx++)).join('');
  }
  if (inProgress.length) {
    html += `<div class="notes-group-title">In Progress <span class="existing-count-badge">${inProgress.length}</span></div>`;
    html += inProgress.map(n => stickyNoteHtml(n, idx++)).join('');
  }
  if (closed.length) {
    html += `<div class="notes-group-title settings-section-header${_notesCompletedExpanded ? ' open' : ''}" id="notes-completed-hdr" onclick="toggleCompletedNotes()">
      <span class="settings-section-chevron">▸</span>Completed <span class="existing-count-badge">${closed.length}</span>
    </div>`;
    html += `<div class="notes-completed-body${_notesCompletedExpanded ? '' : ' hidden'}" id="notes-completed-body">`;
    html += closed.map(n => stickyNoteHtml(n, idx++)).join('');
    html += `</div>`;
  }
  grid.innerHTML = html;
}

function toggleCompletedNotes() {
  _notesCompletedExpanded = !_notesCompletedExpanded;
  document.getElementById('notes-completed-body')?.classList.toggle('hidden', !_notesCompletedExpanded);
  document.getElementById('notes-completed-hdr')?.classList.toggle('open', _notesCompletedExpanded);
}

// ── Modal ────────────────────────────────────────────────────────────────
function openNoteModal(id) {
  const note = id ? notes.find(n => n.id === id) : null;
  document.getElementById('note-modal-title').textContent = note ? 'Edit Note' : 'New Note';
  document.getElementById('note-id-input').value    = note ? note.id : '';
  document.getElementById('note-title-input').value = note ? note.title : '';
  document.getElementById('note-body-input').value  = note ? (note.body || '') : '';
  document.getElementById('note-due-input').value   = note ? (note.dueDate || '') : '';
  document.getElementById('note-modal')?.classList.remove('hidden');
  setTimeout(() => document.getElementById('note-title-input')?.focus(), 50);
}

function closeNoteModal() {
  document.getElementById('note-modal')?.classList.add('hidden');
}

async function saveNoteFromModal() {
  const id    = document.getElementById('note-id-input').value;
  const title = document.getElementById('note-title-input').value.trim();
  const body  = document.getElementById('note-body-input').value.trim();
  const due   = document.getElementById('note-due-input').value || null;
  if (!title) { toast('Give the note a title', 'error'); return; }

  const now = new Date().toISOString();
  if (id) {
    const note = notes.find(n => n.id === id);
    if (note) {
      note.title = title; note.body = body; note.dueDate = due; note.updatedAt = now;
      _notesToastedIds.delete(id); // due date changed — allow the reminder to fire again
    }
  } else {
    notes.push({ id: noteId(), title, body, dueDate: due, status: 'open', createdAt: now, updatedAt: now });
  }

  closeNoteModal();
  renderNotes();
  checkNoteReminders(); // catches a due date set to today/the past right away, not just on the next 5-min tick
  const ok = await persistNotes();
  if (ok) toast(id ? 'Note updated' : 'Note created', 'success');
}

// ── Status / delete ─────────────────────────────────────────────────────
async function setNoteStatus(id, status) {
  const note = notes.find(n => n.id === id);
  if (!note) return;
  note.status = status;
  note.updatedAt = new Date().toISOString();
  if (status === 'closed') note.closedAt = note.updatedAt;
  else { delete note.closedAt; _notesToastedIds.delete(id); }

  renderNotes();
  const ok = await persistNotes();
  if (ok) toast(status === 'closed' ? 'Note marked complete' : 'Note reopened', 'success');
}

async function deleteNoteConfirm(id) {
  const note = notes.find(n => n.id === id);
  if (!note) return;
  const ok = await uiConfirm({
    title: 'Delete note?',
    message: `Delete "${note.title}"? This can't be undone.`,
    confirmText: 'Delete', danger: true,
  });
  if (!ok) return;

  notes = notes.filter(n => n.id !== id);
  _notesToastedIds.delete(id);
  renderNotes();
  const saved = await persistNotes();
  if (saved) toast('Note deleted', 'success');
}

// ── Persistence — merge-written into the same ~/.oasis-prefs.json the rest
// of the app's durable state already uses, via the existing /api/prefs. ──
async function persistNotes() {
  try {
    const resp = await fetch(`${API}/api/prefs`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes: [...notes] }),
    });
    if (!resp.ok) throw new Error(`Server returned ${resp.status}`);
    return true;
  } catch (e) {
    toast('Failed to save note: ' + e.message, 'error');
    return false;
  }
}
