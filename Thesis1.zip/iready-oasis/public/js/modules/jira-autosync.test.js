'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Loads the real jira.js into a sandbox with a fake clock and a fake network, so the
// automatic sync can be watched without a browser.
function load({ switchOn }) {
  const requests = [];
  const timers = [];
  const el = () => ({ disabled: false, innerHTML: '', classList: { add() {}, remove() {}, toggle() {} }, style: {} });
  const sandbox = {
    API: 'http://app.test', sessionId: 'sess-1', console, alert() {},
    document: { getElementById: () => el(), querySelectorAll: () => [], addEventListener() {} },
    fetch: async (url, opts = {}) => {
      requests.push({ url: String(url), method: opts.method || 'GET', body: opts.body ? JSON.parse(opts.body) : null });
      return { ok: true, status: 200, json: async () => ({}) };
    },
    setInterval: (fn, ms) => { timers.push({ fn, ms }); return timers.length; },
    clearInterval() {},
    externalCallsOn: () => sandbox._on,
    _on: switchOn,
  };
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'jira.js'), 'utf8'), sandbox);
  return { sandbox, requests, timers };
}
const syncs = reqs => reqs.filter(r => r.url.endsWith('/api/jira/sync'));

test('the automatic JIRA sync does nothing while the switch is off, and starts again when it is turned on', async () => {
  const { sandbox, requests, timers } = load({ switchOn: false });
  vm.runInContext('startJiraAutoSync()', sandbox);
  assert.equal(timers.length, 1);
  assert.equal(timers[0].ms, 5 * 60 * 1000, 'still every five minutes');

  timers[0].fn();
  await new Promise(r => setImmediate(r));
  assert.equal(syncs(requests).length, 0, 'off: a tick makes no request at all');

  sandbox._on = true;                       // turned on in Settings, no restart
  timers[0].fn();
  await new Promise(r => setImmediate(r));
  assert.equal(syncs(requests).length, 1, 'on: the next tick syncs');
  assert.equal(syncs(requests)[0].body.auto, true, 'and marks the request as automatic');

  sandbox._on = false;                      // and off again
  timers[0].fn();
  await new Promise(r => setImmediate(r));
  assert.equal(syncs(requests).length, 1, 'off again: no further request');
});

test('pressing the Sync button always syncs, and is not marked automatic, whatever the switch says', async () => {
  const { sandbox, requests } = load({ switchOn: false });
  await vm.runInContext('syncJira()', sandbox);
  assert.equal(syncs(requests).length, 1);
  assert.equal(syncs(requests)[0].body.auto, false);
});
