// =============================================================================
// Shared mutable state — all module-level vars that are read/written across sections
// =============================================================================
let cfg = {};            // connection config
let sessionId = null;    // server session
let ws = null;           // WebSocket
let allRepos = [];       // all fetched repos
let filteredRepos = [];  // after search/filter
let selectedRepos = new Set();
let langFilters = new Set();
let jobs = {};           // { repoName: { status, progress, logs, elapsed, timer } }
let currentPage = 1;
let hasMorePages = false;
let _fetchGeneration = 0; // incremented on each new fetchAllRepos run to cancel stale ones

// Scheduled jobs state (keyed by repo name)
let scheduledJobs = {};

// Chat state
let chatRepo = null;
let chatMessages = [];  // [{role, content}]
let chatLogs = '';      // recent setup/launch console output for the chat repo (build-failure context)

// Notes-as-tasks state — [{id, title, body, status: 'open'|'closed', dueDate, createdAt, updatedAt, closedAt}]
let notes = [];

// ── Cache ──────────────────────────────────────────────────────────────────
function saveCache() {
  try {
    const data = { ...cfg };
    delete data.token;
    delete data.aiApiKey;   // secret — lives only in the AI_KEY_COOKIE cookie
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch(e) {}
  saveCacheToFile();
}

function loadCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) { cfg = JSON.parse(raw); return true; }
  } catch(e) {}
  return false;
}

async function loadCacheFromFile() {
  try {
    const resp = await fetch(`${API}/api/prefs`);
    if (!resp.ok) return false;
    const data = await resp.json();
    if (data.cfg) {
      cfg = { ...data.cfg, ...cfg }; // file as base, localStorage wins on conflict
      delete cfg.token;
    }
    if (Array.isArray(data.watchedRepos)) {
      data.watchedRepos.forEach(n => watchedRepos.add(n));
      saveWatched(watchedRepos);
    }
    if (Array.isArray(data.notes)) notes = data.notes;
    return true;
  } catch (e) { return false; }
}

function saveCacheToFile() {
  try {
    const data = { cfg: { ...cfg }, watchedRepos: [...watchedRepos], notes: [...notes] };
    delete data.cfg.token;
    delete data.cfg.aiApiKey;   // secret — lives only in the AI_KEY_COOKIE cookie
    fetch(`${API}/api/prefs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).catch(() => {});
  } catch (e) {}
}

