// =============================================================================
// Performance Diagnostics — AppDynamics/Datadog monitoring, load correlation,
// and slow query analysis. Read-only: suggests fixes, never applies them.
// =============================================================================

const PERF_SECRETS_COOKIE = 'iready_oasis_perfdiag_secrets';

function loadPerfSecrets() {
  const m = document.cookie.split('; ').find(r => r.startsWith(PERF_SECRETS_COOKIE + '='));
  if (!m) return {};
  try { return JSON.parse(decodeURIComponent(m.split('=')[1])) || {}; } catch (_) { return {}; }
}

function savePerfSecrets(map) {
  const exp = new Date(Date.now() + 90 * 24 * 3600 * 1000).toUTCString();
  document.cookie = `${PERF_SECRETS_COOKIE}=${encodeURIComponent(JSON.stringify(map))}; expires=${exp}; path=/; SameSite=Strict`;
}

// A `null` value means the user cleared that field, so the key is DELETED from
// the cookie rather than stored as null — otherwise a cleared token would live
// on in the cookie forever and get re-attached on the next restore.
function savePerfEnvSecrets(envId, secrets) {
  const map = loadPerfSecrets();
  const merged = { ...(map[envId] || {}) };
  Object.entries(secrets || {}).forEach(([key, value]) => {
    if (value === null || value === undefined || value === '') delete merged[key];
    else merged[key] = value;
  });
  if (Object.keys(merged).length) map[envId] = merged;
  else delete map[envId];
  savePerfSecrets(map);
}

function clearPerfEnvSecrets(envId) {
  const map = loadPerfSecrets();
  delete map[envId];
  savePerfSecrets(map);
}

let _perfEnvironments = [];
let _perfActiveEnvId = null;
let _perfActiveRange = '1h';
let _perfLastResult = null;
// The environment a diagnose has already been run for. Re-visiting the tab must
// NOT re-fetch (design spec §D.1: only Refresh does that) — only the first load
// after an environment is selected fires automatically.
let _perfDiagnosedEnvId = null;
// Monotonic request id. A response whose id is no longer current is discarded,
// so quickly switching environment/range cannot let a slow earlier response
// overwrite a newer one — which would leave _perfLastResult's row indices out
// of step with the table perfSuggestFix(i) reads from.
let _perfRequestGen = 0;

// Re-attach every configured environment's secrets to a freshly (re)created
// server session without re-validating over the network — mirrors JIRA's
// restore=true flow (see autoConnectJira in jira.js).
async function autoConnectPerfDiagnostics() {
  if (!sessionId) return;
  const secretsMap = loadPerfSecrets();
  try {
    const resp = await fetch(`${API}/api/perf/environments?session=${sessionId}`);
    const data = await resp.json();
    _perfEnvironments = data.environments || [];
  } catch (_) { return; }

  await Promise.all(_perfEnvironments.map(env => {
    const secrets = secretsMap[env.id];
    if (!secrets) return null;
    return fetch(`${API}/api/perf/environments`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, environment: env, secrets, restore: true }),
    }).catch(() => {});
  }));
}

// Self-sufficient: fetches the environment list itself rather than trusting the
// module-level cache that enterApp()'s un-awaited autoConnectPerfDiagnostics()
// may not have populated yet. Clicking the tab straight after launch used to
// show "No environments configured yet" while that call was still in flight.
async function initPerfDiagnosticsTab() {
  const root = document.getElementById('perf-diagnostics-content');
  if (root && !_perfEnvironments.length) {
    root.innerHTML = `<div class="perf-empty-state"><div class="spinner"></div></div>`;
  }
  if (sessionId) {
    try {
      const resp = await fetch(`${API}/api/perf/environments?session=${sessionId}`);
      const data = await resp.json();
      if (resp.ok) _perfEnvironments = data.environments || [];
    } catch (_) { /* fall through to whatever the cache holds */ }
  }
  renderPerfDiagnosticsShell();
}

function renderPerfDiagnosticsShell() {
  const root = document.getElementById('perf-diagnostics-content');
  if (!root) return;

  if (!_perfEnvironments.length) {
    root.innerHTML = `<div class="perf-empty-state">
      <p>No environments configured yet.</p>
      <button class="btn btn-primary btn-sm" onclick="openSettingsModal();toggleSettingsSection('sec-perfdiag')">Configure an environment in Settings</button>
    </div>`;
    return;
  }

  if (!_perfActiveEnvId || !_perfEnvironments.some(e => e.id === _perfActiveEnvId)) {
    _perfActiveEnvId = _perfEnvironments[0].id;
  }

  root.innerHTML = `
    <div class="perf-filter-bar">
      <select id="perf-env-select" onchange="perfOnEnvironmentChange()">
        ${_perfEnvironments.map(e => `<option value="${escHtml(e.id)}" ${e.id === _perfActiveEnvId ? 'selected' : ''}>${escHtml(e.name)}</option>`).join('')}
      </select>
      <select id="perf-service-select"><option value="">All services</option></select>
      <select id="perf-range-select">
        ${['15m', '1h', '4h', '24h', '7d'].map(r => `<option value="${r}" ${r === _perfActiveRange ? 'selected' : ''}>${r}</option>`).join('')}
      </select>
      <button class="btn btn-primary btn-sm" onclick="runPerfDiagnose()">Refresh</button>
    </div>
    <div id="perf-warnings"></div>
    <div id="perf-load-grid" class="perf-load-grid"></div>
    <div id="perf-query-table"></div>
  `;

  perfLoadServices();
  // Only the FIRST load for a given environment fetches automatically; every
  // later tab re-visit just re-renders whatever was last fetched. Explicit
  // Refresh always re-fetches.
  if (_perfDiagnosedEnvId !== _perfActiveEnvId) runPerfDiagnose();
  else if (_perfLastResult) {
    renderPerfWarnings(_perfLastResult.warnings || []);
    renderPerfLoadGrid(_perfLastResult.load);
    renderPerfQueryTable(_perfLastResult.queries || []);
  }
}

function perfOnEnvironmentChange() {
  const next = document.getElementById('perf-env-select')?.value || null;
  if (next === _perfActiveEnvId) return;
  _perfActiveEnvId = next;
  _perfLastResult = null;
  perfLoadServices();
  runPerfDiagnose(); // first load for a newly-picked environment
}

async function perfLoadServices() {
  const sel = document.getElementById('perf-service-select');
  if (!sel || !_perfActiveEnvId) return;
  try {
    const resp = await fetch(`${API}/api/perf/services?session=${sessionId}&environmentId=${encodeURIComponent(_perfActiveEnvId)}`);
    const data = await resp.json();
    sel.innerHTML = '<option value="">All services</option>' +
      (data.services || []).map(s => `<option value="${escHtml(s)}">${escHtml(s)}</option>`).join('');
  } catch (_) {}
}

async function runPerfDiagnose() {
  if (!_perfActiveEnvId) return;
  const service = document.getElementById('perf-service-select')?.value || '';
  const timeRange = document.getElementById('perf-range-select')?.value || _perfActiveRange;
  _perfActiveRange = timeRange;
  _perfDiagnosedEnvId = _perfActiveEnvId;
  const gen = ++_perfRequestGen;
  const gridEl = document.getElementById('perf-load-grid');
  const tableEl = document.getElementById('perf-query-table');
  const warnEl = document.getElementById('perf-warnings');
  if (gridEl) gridEl.innerHTML = `<div class="spinner"></div>`;
  if (tableEl) tableEl.innerHTML = '';
  if (warnEl) warnEl.innerHTML = '';

  try {
    const resp = await fetch(`${API}/api/perf/diagnose`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, environmentId: _perfActiveEnvId, service, timeRange }),
    });
    const data = await resp.json();
    if (gen !== _perfRequestGen) return; // superseded by a newer request
    if (!resp.ok) throw new Error(data.error || 'Diagnose failed');
    _perfLastResult = data;
    renderPerfWarnings(data.warnings || []);
    renderPerfLoadGrid(data.load);
    renderPerfQueryTable(data.queries || []);
  } catch (e) {
    if (gen !== _perfRequestGen) return;
    if (gridEl) gridEl.innerHTML = '';
    if (warnEl) warnEl.innerHTML = `<div class="perf-warning-banner">${escHtml(e.message)}</div>`;
  }
}

function renderPerfWarnings(warnings) {
  const el = document.getElementById('perf-warnings');
  if (!el) return;
  el.innerHTML = warnings.map(w => `<div class="perf-warning-banner">${escHtml(w.source)}: ${escHtml(w.message)}</div>`).join('');
}

const PERF_SOURCE_LABELS = { datadog: 'Datadog', appdynamics: 'AppDynamics' };

// The unit each platform's DEFAULT metric reports. These genuinely differ:
// Datadog's memory metric (system.mem.used) is bytes while AppDynamics' is a
// percentage, and Datadog throughput is requests/second against
// AppDynamics' calls/minute. perfTimeSeriesChart's contract is one unit per
// chart, so a metric whose sources disagree is split into one card per unit
// rather than drawing bytes and percent against a shared y-axis — which
// flattens the smaller series into a straight line along the floor.
// (A user's "Advanced: custom metric queries" override can change the real
// unit; these are the units of what the feature ships with.)
const PERF_METRICS = {
  cpu:         { label: 'CPU',            unitBySource: { datadog: '%',           appdynamics: '%' } },
  memory:      { label: 'Memory',         unitBySource: { datadog: 'bytes',       appdynamics: '%' } },
  throughput:  { label: 'Throughput',     unitBySource: { datadog: 'req/s',       appdynamics: 'calls/min' } },
  connections: { label: 'DB Connections', unitBySource: { datadog: 'connections', appdynamics: 'connections' } },
};

// One card per (metric, unit): sources that report the same unit share a chart
// and get a legend; sources with their own unit get their own card.
function perfLoadCards(load) {
  const sources = Object.keys(load.seriesBySource || {});
  const cards = [];
  Object.entries(PERF_METRICS).forEach(([metric, { label, unitBySource }]) => {
    const byUnit = new Map(); // unit -> { [sourceLabel]: points }
    sources.forEach(src => {
      const points = load.seriesBySource[src]?.[metric] || [];
      if (!points.length) return;
      const unit = unitBySource[src] || '';
      if (!byUnit.has(unit)) byUnit.set(unit, {});
      byUnit.get(unit)[PERF_SOURCE_LABELS[src] || src] = points;
    });
    // No data at all for this metric: show the placeholder card without naming
    // a unit, since which unit it *would* have been depends on the source.
    if (!byUnit.size) { cards.push({ title: label, seriesByLabel: {} }); return; }
    const split = byUnit.size > 1;
    byUnit.forEach((seriesByLabel, unit) => {
      const names = Object.keys(seriesByLabel);
      // When a metric had to be split, name the platform in the title so it is
      // obvious the two cards are not the same measurement.
      const title = split && names.length === 1 ? `${label} — ${names[0]} (${unit})` : `${label} (${unit})`;
      cards.push({ title, unit, seriesByLabel });
    });
  });
  return cards;
}

function renderPerfLoadGrid(load) {
  const el = document.getElementById('perf-load-grid');
  if (!el || !load) return;
  el.innerHTML = perfLoadCards(load).map(card => `<div class="perf-load-card">
      <div class="perf-load-card-title">${escHtml(card.title)}</div>
      ${perfTimeSeriesChart(card.seriesByLabel, {
        unit: card.unit || '',
        highLoadBuckets: load.highLoadBuckets,
        // The window bounds go to every chart so they all share one x-axis.
        // Without them each chart derives its own axis from whatever data it
        // happens to hold, and the shaded high-load bands land in different
        // places per chart — which defeats reading correlation across metrics
        // at a glance.
        from: load.from,
        to: load.to,
      })}
    </div>`).join('');
}

function renderPerfQueryTable(queries) {
  const el = document.getElementById('perf-query-table');
  if (!el) return;
  if (!queries.length) { el.innerHTML = `<div class="chart-empty">No slow queries found in this window</div>`; return; }

  el.innerHTML = `<table class="perf-query-table-el">
    <thead><tr><th>Source</th><th>Query</th><th>Database</th><th>Avg (ms)</th><th>Execs</th><th>Total (ms)</th><th>Load?</th><th></th></tr></thead>
    <tbody>${queries.map((q, i) => `
      <tr>
        <td><span class="perf-source-badge">${escHtml(q.source)}</span></td>
        <td class="perf-query-text" title="${escHtml(perfQueryTitle(q))}">${escHtml((q.queryText || '').slice(0, 80))}${q.queryTextIsHash ? ' <span class="perf-hash-note">(signature hash)</span>' : ''}</td>
        <td>${escHtml(q.database || '—')}</td>
        <td>${escHtml(perfNumber(q.avgDurationMs, 1))}</td>
        <td title="${escHtml(perfExecCountTitle(q))}">${escHtml(perfExecCountText(q))}</td>
        <td>${escHtml(perfNumber(q.totalTimeMs, 0))}</td>
        <td><span class="perf-load-badge ${q.loadCorrelated ? 'perf-load-yes' : 'perf-load-no'}"
              title="${q.loadCorrelated ? 'This slowness lines up with a period of elevated load' : 'This query is slow even when load is normal — likely a query problem'}">
              ${q.loadCorrelated ? 'Load-correlated' : 'Query-specific'}</span></td>
        <td>${q.queryTextIsHash
          ? `<button class="btn btn-ghost btn-sm" disabled title="Query text unavailable — Datadog Database Monitoring reports only a signature hash for this statement, so there is no SQL to analyse">Suggest Fix</button>`
          : `<button class="btn btn-ghost btn-sm" onclick="perfSuggestFix(${i})">Suggest Fix</button>`}</td>
      </tr>
      <tr class="hidden" id="perf-fix-row-${i}"><td colspan="8"><div id="perf-fix-panel-${i}"></div></td></tr>
    `).join('')}</tbody>
  </table>`;
}

// The query-text column is escaped everywhere, but a hash needs saying out loud
// so nobody reads "abc123" as a query they can go and look up.
function perfQueryTitle(q) {
  return q.queryTextIsHash
    ? `${q.queryText} — Datadog DBM query signature hash, not the SQL text`
    : (q.queryText || '');
}

// Every interpolated numeric goes through escHtml as a string: the AppDynamics
// paths in particular come from an unversioned API whose response shape is not
// guaranteed to be numeric, so nothing is trusted to be a safe number.
function perfNumber(value, digits) {
  return typeof value === 'number' && isFinite(value) ? value.toFixed(digits) : '—';
}

// `execCount` is not the same quantity in every source (see EXEC_COUNT_KIND in
// server/perf/diagnose.js) — label it rather than printing a rate and a count
// as if they were interchangeable.
function perfExecCountText(q) {
  if (q.execCountKind === 'rate-per-minute') return `${perfNumber(q.execCount, 0)}/min`;
  if (q.execCountKind === 'count') return perfNumber(q.execCount, 0);
  return '—';
}

function perfExecCountTitle(q) {
  if (q.execCountKind === 'rate-per-minute') return 'AppDynamics reports calls per minute, not a total count';
  if (q.execCountKind === 'count') return 'Executions observed in this window';
  return 'This source does not report an execution count, so impact is ranked on average duration alone';
}

async function perfSuggestFix(i) {
  const row = document.getElementById(`perf-fix-row-${i}`);
  const panel = document.getElementById(`perf-fix-panel-${i}`);
  if (!row || !panel || !_perfLastResult) return;
  const wasHidden = row.classList.contains('hidden');
  row.classList.toggle('hidden');
  if (!wasHidden) return; // second click just collapses it

  const query = _perfLastResult.queries[i];
  if (!query) { panel.innerHTML = `<div class="perf-warning-banner">This row is no longer available — refresh and try again</div>`; return; }
  if (query.queryTextIsHash) {
    panel.innerHTML = `<div class="perf-warning-banner">Query text unavailable — Datadog Database Monitoring reports only a signature hash for this statement, so there is no SQL to analyse.</div>`;
    return;
  }

  panel.innerHTML = `<div class="spinner"></div>`;
  try {
    const resp = await fetch(`${API}/api/perf/suggest-fix`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, query }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Fix suggestion failed');
    panel.innerHTML = `<div class="perf-fix-text" id="perf-fix-text-${i}">${escHtml(data.suggestion).replace(/\n/g, '<br>')}</div>
      <button class="btn btn-ghost btn-sm" onclick="perfCopyFix(${i})">Copy</button>`;
  } catch (e) {
    panel.innerHTML = `<div class="perf-warning-banner">${escHtml(e.message)}</div>`;
  }
}

async function perfCopyFix(i) {
  const el = document.getElementById(`perf-fix-text-${i}`);
  if (!el) return;
  try { await navigator.clipboard.writeText(el.innerText); toast('Copied', 'success'); }
  catch (e) { toast('Copy failed: ' + e.message, 'error'); }
}

// ── Settings: environment CRUD ──────────────────────────────────────────────

function openPerfEnvModal(envId) {
  const env = envId ? _perfEnvironments.find(e => e.id === envId) : null;
  document.getElementById('perf-env-modal-title').textContent = env ? 'Edit Environment' : 'New Environment';
  document.getElementById('perf-env-id-input').value = env?.id || '';
  document.getElementById('perf-env-name-input').value = env?.name || '';
  document.getElementById('perf-env-dd-site-input').value = env?.datadog?.site || 'datadoghq.com';
  document.getElementById('perf-env-dd-envtag-input').value = env?.datadog?.envTag || '';
  document.getElementById('perf-env-appd-url-input').value = env?.appdynamics?.controllerUrl || '';
  document.getElementById('perf-env-appd-account-input').value = env?.appdynamics?.accountName || '';
  document.getElementById('perf-env-appd-app-input').value = env?.appdynamics?.applicationName || '';

  const secrets = env ? (loadPerfSecrets()[env.id] || {}) : {};
  document.getElementById('perf-env-dd-apikey-wrap').innerHTML = tokenFieldHtml('perf-env-dd-apikey-input', 'perf-env-dd-apikey', secrets.ddApiKey || '', 'Datadog API key');
  document.getElementById('perf-env-dd-appkey-wrap').innerHTML = tokenFieldHtml('perf-env-dd-appkey-input', 'perf-env-dd-appkey', secrets.ddAppKey || '', 'Datadog application key');
  document.getElementById('perf-env-appd-clientid-wrap').innerHTML = tokenFieldHtml('perf-env-appd-clientid-input', 'perf-env-appd-clientid', secrets.appdClientId || '', 'OAuth client ID');
  document.getElementById('perf-env-appd-clientsecret-wrap').innerHTML = tokenFieldHtml('perf-env-appd-clientsecret-input', 'perf-env-appd-clientsecret', secrets.appdClientSecret || '', 'OAuth client secret');

  document.getElementById('perf-dd-test-msg').textContent = '';
  document.getElementById('perf-appd-test-msg').textContent = '';
  document.getElementById('perf-env-modal').classList.remove('hidden');
}

function closePerfEnvModal() {
  document.getElementById('perf-env-modal').classList.add('hidden');
}

function collectPerfEnvFromModal() {
  const id = document.getElementById('perf-env-id-input').value || undefined;
  const name = document.getElementById('perf-env-name-input').value.trim();
  const ddSite = document.getElementById('perf-env-dd-site-input').value;
  const ddEnvTag = document.getElementById('perf-env-dd-envtag-input').value.trim();
  const appdUrl = document.getElementById('perf-env-appd-url-input').value.trim().replace(/\/$/, '');
  const appdAccount = document.getElementById('perf-env-appd-account-input').value.trim();
  const appdApp = document.getElementById('perf-env-appd-app-input').value.trim();

  const environment = { id, name };
  if (ddEnvTag) environment.datadog = { site: ddSite, envTag: ddEnvTag };
  if (appdUrl && appdAccount && appdApp) environment.appdynamics = { controllerUrl: appdUrl, accountName: appdAccount, applicationName: appdApp };

  // These password fields are pre-filled with the saved value (see
  // tokenFieldHtml in openPerfEnvModal), so an empty field is a deliberate
  // "clear this" rather than "leave it alone". Send an explicit `null` for it:
  // the server and the cookie helper both treat null as "delete this key".
  // Omitting the key would silently keep the old secret alive forever.
  const secrets = {};
  const SECRET_INPUTS = {
    ddApiKey: 'perf-env-dd-apikey-input',
    ddAppKey: 'perf-env-dd-appkey-input',
    appdClientId: 'perf-env-appd-clientid-input',
    appdClientSecret: 'perf-env-appd-clientsecret-input',
  };
  Object.entries(SECRET_INPUTS).forEach(([key, inputId]) => {
    const input = document.getElementById(inputId);
    if (!input) return; // field not rendered — genuinely "unchanged"
    const value = input.value.trim();
    secrets[key] = value || null;
  });

  return { environment, secrets };
}

async function testPerfPlatform(platform) {
  const { environment, secrets } = collectPerfEnvFromModal();
  const msgEl = document.getElementById(platform === 'datadog' ? 'perf-dd-test-msg' : 'perf-appd-test-msg');
  let config;
  if (platform === 'datadog') {
    if (!environment.datadog || !secrets.ddApiKey || !secrets.ddAppKey) { msgEl.textContent = 'Site, env tag, API key, and application key are required'; return; }
    config = { ...environment.datadog, ddApiKey: secrets.ddApiKey, ddAppKey: secrets.ddAppKey };
  } else {
    if (!environment.appdynamics || !secrets.appdClientId || !secrets.appdClientSecret) { msgEl.textContent = 'Controller URL, account, application, client ID, and client secret are required'; return; }
    config = { ...environment.appdynamics, clientId: secrets.appdClientId, clientSecret: secrets.appdClientSecret };
  }
  msgEl.textContent = 'Testing…';
  try {
    const resp = await fetch(`${API}/api/perf/test`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, platform, config }),
    });
    const data = await resp.json();
    msgEl.textContent = resp.ok ? '✓ Connected' : (data.error || 'Failed');
  } catch (e) {
    msgEl.textContent = 'Network error: ' + e.message;
  }
}

async function savePerfEnvironment() {
  const { environment, secrets } = collectPerfEnvFromModal();
  if (!environment.name) { toast('Name is required', 'info'); return; }
  if (!environment.datadog && !environment.appdynamics) { toast('Configure at least one platform', 'info'); return; }

  const btn = document.getElementById('perf-env-save-btn');
  btn.disabled = true;
  try {
    const resp = await fetch(`${API}/api/perf/environments`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, environment, secrets }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Save failed');
    savePerfEnvSecrets(data.environment.id, secrets);
    closePerfEnvModal();
    // The saved environment's credentials/scope may have changed, so anything
    // already on screen for it is stale — drop it so the shell fetches once
    // more. (A plain tab re-visit still does not re-fetch.)
    if (data.environment.id === _perfActiveEnvId) {
      _perfDiagnosedEnvId = null;
      _perfLastResult = null;
    }
    // The environment is persisted even when one platform's credentials failed
    // validation, so say which half is broken rather than pretending the whole
    // save was lost (or that everything is fine).
    const warnings = data.warnings || [];
    if (warnings.length) {
      toast(`Saved, but ${warnings.map(w => w.message).join('; ')}`, 'info');
    } else {
      toast('Environment saved', 'success');
    }
    await refreshPerfEnvironmentsList();
    renderPerfDiagnosticsShell();
  } catch (e) {
    toast('Save failed: ' + e.message, 'error');
  } finally {
    btn.disabled = false;
  }
}

async function deletePerfEnvironment(envId) {
  if (!confirm('Remove this environment?')) return;
  try {
    await fetch(`${API}/api/perf/environments/${encodeURIComponent(envId)}?session=${sessionId}`, { method: 'DELETE' });
    clearPerfEnvSecrets(envId);
    if (_perfActiveEnvId === envId) _perfActiveEnvId = null;
    if (_perfDiagnosedEnvId === envId) {
      _perfDiagnosedEnvId = null;
      _perfLastResult = null; // its row indices no longer describe anything on screen
    }
    await refreshPerfEnvironmentsList();
    renderPerfDiagnosticsShell();
  } catch (e) {
    toast('Delete failed: ' + e.message, 'error');
  }
}

async function refreshPerfEnvironmentsList() {
  try {
    const resp = await fetch(`${API}/api/perf/environments?session=${sessionId}`);
    const data = await resp.json();
    _perfEnvironments = data.environments || [];
  } catch (_) {}
  renderPerfSettingsSection();
}

function renderPerfSettingsSection() {
  const el = document.getElementById('perf-env-list');
  if (!el) return;
  if (!_perfEnvironments.length) { el.innerHTML = `<div class="field-hint">No environments yet.</div>`; return; }
  el.innerHTML = _perfEnvironments.map(env => `
    <div class="perf-env-row">
      <span class="perf-env-name">${escHtml(env.name)}</span>
      <span class="perf-env-badges">
        ${env.datadog ? `<span class="perf-source-badge">Datadog${env.datadogConfigured ? ' ✓' : ''}</span>` : ''}
        ${env.appdynamics ? `<span class="perf-source-badge">AppDynamics${env.appdynamicsConfigured ? ' ✓' : ''}</span>` : ''}
      </span>
      <button class="btn btn-ghost btn-sm" onclick="openPerfEnvModal('${escHtml(env.id)}')">Edit</button>
      <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="deletePerfEnvironment('${escHtml(env.id)}')">Remove</button>
    </div>`).join('');
}
