// =============================================================================
// License — trial countdown, activation, and the lock screen
// =============================================================================
// This module is the *presentation* of licensing, not the enforcement of it.
// Enforcement lives in the Express gate (server/licensing/gate.js), which
// refuses API work no matter what this file does. Anything here can be deleted
// from devtools; nothing here is load-bearing for revenue.
//
// What it does own: showing the user where they stand, collecting a key, and
// reacting when the server says the licence has gone bad mid-session.
//
// There are two levels of refusal, and this file presents both:
//
//   locked        no licence and no live trial — the lock screen covers the
//                 app, because unlicensed OASIS runs only for the trial period and then stops.
//   feature gap   licensed, but this tier did not buy Version Watch or
//                 Security — that tab is dropped from the bar, nothing else.
//
// See FEATURES and the trial tier in server/licensing/tiers.js.

let _license = null;

// How often the countdown re-reads the licence. /api/license/status is served
// by our own local process and costs tens of microseconds, so a minute is cheap
// and keeps an hours-based countdown honest. It also means a trial that runs
// out while the window sits open locks on its own, rather than waiting for the
// user to click something that happens to hit the API.
const LICENSE_POLL_MS = 60 * 1000;

function licenseIsLocked() {
  return !_license || _license.locked === true;
}

function licenseHasFeature(feature) {
  return !!(_license && Array.isArray(_license.features) && _license.features.includes(feature));
}

async function fetchLicenseStatus() {
  try {
    const resp = await fetch(`${API}/api/license/status`);
    if (!resp.ok) return null;
    const data = await resp.json();
    // When enforcement is off the route is not mounted, and the server's
    // catch-all answers with index.html — a 200 that is not a status. Checking
    // the shape keeps "licensing is disabled" an explicit branch rather than
    // something we stumble into when JSON.parse happens to throw.
    if (!data || typeof data.status !== 'string') return null;
    _license = data;
    return _license;
  } catch (e) {
    // The licence API is served by our own local process, so a failure here
    // means the app itself is broken, not that the licence is bad. Leave the
    // last known status in place rather than locking the user out over it.
    return _license;
  }
}

function formatExpiry(ms) {
  if (!ms) return '';
  try {
    return new Date(ms).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  } catch (e) {
    return '';
  }
}

// ── Lock screen ────────────────────────────────────────────────────────────

// ── The licence page: its views ───────────────────────────────────────────────
//
// One overlay, five views, and a Back on each:
//
//   home      Start trial · Activate licence · Buy a licence
//   activate  the work email (a code is sent only if the company holds a licence)
//   code      the 6-digit code; then the licence's expiry and seats are checked
//   buy       organization, number of employees, email, contact name: for the support team
//   bought    a thank-you with a reference
//
// Everything the server says is shown as text, never as markup.

let _licenseView = { name: 'home' };
let _licenseBusy = false;                       // one request at a time: a double click sends one

function licEsc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const LIC_HEADINGS = (status) => ({
  unregistered: 'Activate i-Ready OASIS',
  trial: 'Your trial has ended',
  expired: status.reason === 'trial_expired' ? 'Your trial has ended' : 'Your licence has expired',
  revoked: 'Licence revoked',
  // The service refused us for a reason this build cannot name — including a released seat. The
  // heading stays neutral; status.message carries the detail in the service's own words.
  rejected: status.reason === 'seat_released' ? 'This machine is not activated' : 'Licence refused',
  clock_tampered: 'Cannot verify this licence',
}[status.status] || 'A licence is required');

function licenseHomeHtml(status) {
  const isFresh = status.status === 'unregistered' && !status.tokenError;
  const days = status.trialDays || 7;
  const damaged = status.tokenError
    ? `<div class="lic-alert">The stored licence file could not be verified (${licEsc(status.tokenError)}). Activate again to replace it.</div>`
    : '';
  const message = status.message ? `<p class="wiz-desc">${licEsc(status.message)}</p>` : '';

  const trial = isFresh
    ? `<div class="lic-trial-cta">
         <button class="btn btn-primary" id="lic-trial-btn" onclick="startLicenseTrial()">Start ${days}-day free trial</button>
         <div class="field-hint">
           Repositories, setup, dependency graph, Docker and JIRA for ${days} days. Version Watch
           and Security need a licence. Requires an internet connection to begin.
         </div>
       </div>
       <div class="lic-divider"><span>or</span></div>`
    : '';

  // Not locked means a licensed user opened this from the top bar to switch or extend.
  const dismiss = status.locked
    ? ''
    : `<button class="btn btn-ghost" id="lic-dismiss-btn" onclick="dismissLicenseDialog()">Continue without these tabs</button>`;

  return `
      ${damaged}
      ${message}
      ${trial}
      <div class="lic-buy-cta">
        <button class="btn ${isFresh ? 'btn-ghost' : 'btn-primary'}" id="lic-activate-btn" onclick="showLicenseView('activate')">Activate licence</button>
        <div class="field-hint">Does your organization already have a licence? Confirm your work email and we will send a code.</div>
      </div>
      <div class="lic-buy-cta">
        <button class="btn btn-ghost" id="lic-buy-btn" onclick="showLicenseView('buy')">Buy a licence</button>
        <div class="field-hint">Tell us about your organization and our support team will contact you.</div>
      </div>
      <div id="lic-error" class="lic-error" role="alert"></div>
      ${dismiss}`;
}

function licenseActivateHtml() {
  return `
      <p class="wiz-desc">Enter your work email. If your organization has a licence, we will email you a 6-digit code.</p>
      <form onsubmit="licenseSendCode(); return false" novalidate>
        <div class="field">
          <label for="lic-email">Work email</label>
          <input id="lic-email" type="email" inputmode="email" autocomplete="email" placeholder="you@yourcompany.com"
                 value="${licEsc(_licenseView.email || '')}" aria-describedby="lic-error"/>
        </div>
        <div id="lic-error" class="lic-error" role="alert"></div>
        <div class="lic-btn-row" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button class="btn btn-primary" id="lic-send-btn" type="submit">Send code</button>
          <button class="btn btn-ghost" id="lic-back-btn" type="button" onclick="licenseBack()">Back</button>
        </div>
      </form>
      <div class="lic-linkrow"><button type="button" class="lic-link" id="lic-buy-instead" onclick="licenseBuyInstead()">No licence yet? Buy a licence</button></div>`;
}

function licenseCodeHtml() {
  return `
      <p class="wiz-desc">We sent a 6-digit code to <strong>${licEsc(_licenseView.sentTo || _licenseView.email || '')}</strong>. It is valid for 10 minutes.</p>
      <form onsubmit="licenseVerifyCode(); return false" novalidate>
        <div class="field">
          <label for="lic-code">6-digit code</label>
          <input id="lic-code" type="text" inputmode="numeric" maxlength="6" autocomplete="one-time-code" pattern="[0-9]*" aria-describedby="lic-error"/>
        </div>
        <div id="lic-error" class="lic-error" role="alert"></div>
        <div id="lic-notice" class="lic-notice" role="status"></div>
        <div class="lic-btn-row" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button class="btn btn-primary" id="lic-verify-btn" type="submit">Verify and activate</button>
          <button class="btn btn-ghost" id="lic-back-btn" type="button" onclick="licenseBack()">Back</button>
        </div>
      </form>
      <div class="lic-linkrow">
        <button type="button" class="lic-link" id="lic-resend-btn" onclick="licenseResendCode()">Send a new code</button>
        &nbsp;·&nbsp;
        <button type="button" class="lic-link" id="lic-buy-instead" onclick="licenseBuyInstead()">Buy a licence instead</button>
      </div>`;
}

function licenseBuyHtml() {
  const field = (id, errId, label, control) => `
        <div class="field">
          <label for="${id}">${label}</label>
          ${control}
          <div class="lic-field-error" id="${errId}" role="alert"></div>
        </div>`;
  return `
      <p class="wiz-desc">Tell us about your organization. Our support team will contact you to talk it through and agree your licence.</p>
      <form onsubmit="licenseSubmitPurchase(); return false" novalidate>
        ${field('lic-org', 'lic-err-org', 'Organization name', '<input id="lic-org" type="text" autocomplete="organization" maxlength="200"/>')}
        ${field('lic-employees', 'lic-err-employees', 'Number of employees', '<input id="lic-employees" type="text" inputmode="numeric" maxlength="7"/>')}
        ${field('lic-buy-email', 'lic-err-buy-email', 'Work email', `<input id="lic-buy-email" type="email" inputmode="email" autocomplete="email" oninput="licenseBuyEmailChanged()" value="${licEsc(_licenseView.email || '')}"/>
          <div class="field-hint">Use your work email address. We send a code to confirm it; personal addresses such as Gmail or Yahoo cannot be used.</div>
          <button class="btn btn-ghost" id="lic-buy-send-btn" type="button" onclick="licenseBuySendCode()" style="margin-top:8px">Send code</button>`)}
        <div id="lic-buy-code-row" hidden>
          ${field('lic-buy-code', 'lic-err-buy-code', 'Code from the email', '<input id="lic-buy-code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6"/>')}
          <button class="btn btn-ghost" id="lic-buy-verify-btn" type="button" onclick="licenseBuyVerify()">Verify email</button>
        </div>
        <div id="lic-buy-verified" class="field-hint" role="status"></div>
        ${field('lic-contact-name', 'lic-err-contact-name', 'Contact name', '<input id="lic-contact-name" type="text" autocomplete="name" maxlength="150"/>')}
        <div id="lic-error" class="lic-error" role="alert"></div>
        <div class="lic-btn-row" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button class="btn btn-primary" id="lic-submit-btn" type="submit" disabled>Send to our team</button>
          <button class="btn btn-ghost" id="lic-back-btn" type="button" onclick="licenseBack()">Back</button>
        </div>
      </form>`;
}

function licenseBoughtHtml() {
  return `
      <p class="wiz-desc"><strong>Thank you.</strong> Our support team will contact you to talk about your licence.</p>
      <div class="field-hint">Your reference is <code>${licEsc(_licenseView.reference || '')}</code>. Keep it handy when they get in touch.</div>
      <button class="btn btn-primary" id="lic-done-btn" type="button" onclick="showLicenseView('home')" style="margin-top:14px">Back to start</button>`;
}

function lockScreenHtml(status) {
  const bodies = { home: licenseHomeHtml, activate: licenseActivateHtml, code: licenseCodeHtml, buy: licenseBuyHtml, bought: licenseBoughtHtml };
  const body = (bodies[_licenseView.name] || licenseHomeHtml)(status);
  return `
    <div class="wizard-card lic-card">
      <div class="wiz-brand">
        <div class="wiz-icon"><img src="img/iready-logo.png?v=3" alt="i-Ready"></div>
        <div>
          <div class="wiz-title">i-Ready <span>OASIS</span></div>
          <div class="wiz-sub">${licEsc(LIC_HEADINGS(status))}</div>
        </div>
      </div>
      ${body}
    </div>`;
}

// The first box worth typing in for the view on screen.
const LIC_FOCUS = { activate: 'lic-email', code: 'lic-code', buy: 'lic-org' };

function renderLockScreen(status, force = false) {
  let overlay = document.getElementById('license-overlay');

  // Already up: leave it exactly as it is. Several API calls can come back 402 in the same second
  // during boot, and re-rendering on each one would clear what the user is halfway through typing.
  // Only moving between views (force) redraws it.
  if (!force && overlay && !overlay.classList.contains('hidden')) return;

  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'license-overlay';
    overlay.className = 'wizard-overlay';
    document.body.appendChild(overlay);
  }
  overlay.innerHTML = lockScreenHtml(status);
  overlay.classList.remove('hidden');
  const first = document.getElementById(LIC_FOCUS[_licenseView.name]);
  if (first && first.focus) first.focus();
}

function showLicenseView(name, extra = {}) {
  _licenseView = { ..._licenseView, ...extra, name };
  _licenseBusy = false;
  if (_license) renderLockScreen(_license, true);
}

function licenseBack() {
  showLicenseView(_licenseView.name === 'code' ? 'activate' : 'home');
}

// "No licence yet?": carry the address across so it is not typed twice.
function licenseBuyInstead() {
  const typed = document.getElementById('lic-email');
  showLicenseView('buy', { email: (typed && typed.value.trim()) || _licenseView.email || '' });
}

// ── Actions ───────────────────────────────────────────────────────────────

async function licensePost(route, body, extraHeaders = {}) {
  try {
    const resp = await fetch(`${API}${route}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...extraHeaders }, body: JSON.stringify(body) });
    return { ok: resp.ok, status: resp.status, data: await resp.json().catch(() => ({})) };
  } catch (_) {
    return { ok: false, status: 0, data: { message: 'Could not reach the licence service. Check your connection and try again.' } };
  }
}

// What to tell the user. The page itself shows no machine id or service address; when the service
// cannot be reached the message names the address that was tried, because "could not reach" with no
// address reads the same whether the service is down or the build points somewhere else.
function licenseFailureText(r) {
  const base = (r.data && r.data.message) || 'Something went wrong. Please try again.';
  const where = r.status === 503 && _license && _license.serviceUrl ? ` (${_license.serviceUrl})` : '';
  return `${base}${where}`;
}

function setLicenseBusy(id, busy, idleLabel, busyLabel) {
  _licenseBusy = busy;
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.disabled = busy;
  btn.textContent = busy ? busyLabel : idleLabel;
}

function showLicenseNotice(message) {
  const box = document.getElementById('lic-notice');
  if (box) box.textContent = message;
}

const LIC_LOOKS_LIKE_EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/;

async function licenseSendCode(resend = false) {
  if (_licenseBusy) return;
  const typed = document.getElementById('lic-email');
  const email = resend ? (_licenseView.email || '') : ((typed && typed.value) || '').trim().toLowerCase();
  if (!LIC_LOOKS_LIKE_EMAIL.test(email)) { showLicenseError('Enter a valid email address.'); return; }

  showLicenseError('');
  setLicenseBusy(resend ? 'lic-resend-btn' : 'lic-send-btn', true, resend ? 'Send a new code' : 'Send code', 'Sending…');
  const r = await licensePost('/api/license/email-code', { email });
  if (!r.ok) {
    setLicenseBusy(resend ? 'lic-resend-btn' : 'lic-send-btn', false, resend ? 'Send a new code' : 'Send code');
    showLicenseError(licenseFailureText(r));
    return;
  }
  if (resend) {
    setLicenseBusy('lic-resend-btn', false, 'Send a new code');
    showLicenseNotice('A new code is on its way. The old one no longer works.');
    return;
  }
  showLicenseView('code', { email, sentTo: r.data.sentTo || email });
}

function licenseResendCode() {
  return licenseSendCode(true);
}

async function licenseVerifyCode() {
  if (_licenseBusy) return;
  const input = document.getElementById('lic-code');
  const code = ((input && input.value) || '').trim();
  if (!/^\d{6}$/.test(code)) { showLicenseError('Enter the 6-digit code from the email.'); return; }

  showLicenseError('');
  showLicenseNotice('');
  const wasLocked = licenseIsLocked();
  setLicenseBusy('lic-verify-btn', true, 'Verify and activate', 'Checking…');
  const r = await licensePost('/api/license/activate-email', { email: _licenseView.email, code });
  if (!r.ok) {
    setLicenseBusy('lic-verify-btn', false, 'Verify and activate');
    showLicenseError(licenseFailureText(r));
    if (input && r.data && r.data.details && r.data.details.reason === 'wrong_code') { input.value = ''; if (input.focus) input.focus(); }
    return;
  }
  // The licence is valid and a seat is taken. Out of the lock, the page reloads against it
  // (applyStatusChange), and the user carries on into setup.
  _licenseBusy = false;
  applyStatusChange(r.data, wasLocked);
}

const LIC_BUY_FIELDS = {
  organization: ['lic-org', 'lic-err-org', 'Enter your organization\'s name.'],
  employees: ['lic-employees', 'lic-err-employees', 'Enter the number of employees.'],
  email: ['lic-buy-email', 'lic-err-buy-email', 'Enter a valid email address.'],
  contactName: ['lic-contact-name', 'lic-err-contact-name', 'Enter a contact name.'],
};

function setLicenseFieldError(key, message) {
  const [inputId, errId] = LIC_BUY_FIELDS[key];
  const err = document.getElementById(errId);
  if (err) err.textContent = message || '';
  const input = document.getElementById(inputId);
  if (input && input.setAttribute) { if (message) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid'); }
}

// One key per submit, kept for a retry of the SAME details (a dropped connection, a double click) so the
// support team never gets two requests, and replaced when the details change so an edited request is
// never swallowed as a repeat of the old one. Dropped once the request is sent (see the end of
// licenseSubmitPurchase) so the next request is a new one.
let _purchaseAttempt = null;
function licensePurchaseKey(body) {
  const fingerprint = JSON.stringify(body);
  if (!_purchaseAttempt || _purchaseAttempt.fingerprint !== fingerprint) {
    const id = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
    _purchaseAttempt = { fingerprint, key: `buy-${id}` };
  }
  return _purchaseAttempt.key;
}

// The Buy form's work email is proved with a one-time code before Submit works. The proof belongs to ONE address: changing the
// address takes it back. The service checks the proof again, so this is the page's convenience, not the gate.
let _purchaseProof = null;

function licenseBuyEmailOf() {
  const el = document.getElementById('lic-buy-email');
  return ((el && typeof el.value === 'string' ? el.value : '') || '').trim().toLowerCase();
}

function licenseBuySetVerified(proof) {
  _purchaseProof = proof;
  const submit = document.getElementById('lic-submit-btn');
  if (submit) submit.disabled = !proof;
  const note = document.getElementById('lic-buy-verified');
  if (note) note.textContent = proof ? 'Email verified.' : '';
  const row = document.getElementById('lic-buy-code-row');
  if (row && !proof) row.hidden = true;
}

function licenseBuyEmailChanged() {
  if (_purchaseProof && _purchaseProof.email !== licenseBuyEmailOf()) licenseBuySetVerified(null);
  else if (!_purchaseProof) { const row = document.getElementById('lic-buy-code-row'); if (row) row.hidden = true; }
}

async function licenseBuySendCode() {
  if (_licenseBusy) return;
  const email = licenseBuyEmailOf();
  setLicenseFieldError('email', '');
  showLicenseError('');
  if (!LIC_LOOKS_LIKE_EMAIL.test(email)) { setLicenseFieldError('email', 'Enter a valid email address.'); return; }
  licenseBuySetVerified(null);
  setLicenseBusy('lic-buy-send-btn', true, 'Send code', 'Sending…');
  const r = await licensePost('/api/license/purchase-code', { email });
  setLicenseBusy('lic-buy-send-btn', false, 'Send code');
  if (!r.ok) { setLicenseFieldError('email', licenseFailureText(r)); return; }
  const row = document.getElementById('lic-buy-code-row');
  if (row) row.hidden = false;
  const code = document.getElementById('lic-buy-code');
  if (code && code.focus) code.focus();
}

async function licenseBuyVerify() {
  if (_licenseBusy) return;
  const email = licenseBuyEmailOf();
  const input = document.getElementById('lic-buy-code');
  const code = ((input && input.value) || '').trim();
  const err = document.getElementById('lic-err-buy-code');
  if (err) err.textContent = '';
  if (!/^\d{6}$/.test(code)) { if (err) err.textContent = 'Enter the 6-digit code from the email.'; return; }
  setLicenseBusy('lic-buy-verify-btn', true, 'Verify email', 'Checking…');
  const r = await licensePost('/api/license/purchase-verify', { email, code });
  setLicenseBusy('lic-buy-verify-btn', false, 'Verify email');
  if (!r.ok || !r.data || !r.data.verificationToken) {
    if (err) err.textContent = licenseFailureText(r);
    return;
  }
  licenseBuySetVerified({ email, token: r.data.verificationToken });
}

async function licenseSubmitPurchase() {
  if (_licenseBusy) return;
  const value = id => { const el = document.getElementById(id); return el && typeof el.value === 'string' ? el.value : ''; };
  const body = {};
  for (const [key, [inputId]] of Object.entries(LIC_BUY_FIELDS)) body[key] = value(inputId);

  showLicenseError('');
  let firstEmpty = null;
  for (const [key, [inputId, , message]] of Object.entries(LIC_BUY_FIELDS)) {
    const empty = !String(body[key]).trim();
    setLicenseFieldError(key, empty ? message : '');
    if (empty && !firstEmpty) firstEmpty = inputId;
  }
  if (firstEmpty) {
    showLicenseError('Please fill in every box.');
    const box = document.getElementById(firstEmpty);
    if (box && box.focus) box.focus();                     // the cursor goes where the work is
    return;
  }

  if (!_purchaseProof || _purchaseProof.email !== licenseBuyEmailOf()) {
    setLicenseFieldError('email', 'Verify your work email with the code we send you.');
    return;
  }
  body.verificationToken = _purchaseProof.token;

  setLicenseBusy('lic-submit-btn', true, 'Send to our team', 'Sending…');
  const r = await licensePost('/api/license/purchase-request', body, { 'Idempotency-Key': licensePurchaseKey(body) });
  setLicenseBusy('lic-submit-btn', false, 'Send to our team');
  if (!r.ok && r.data && r.data.details && r.data.details.reason === 'email_not_verified') {
    licenseBuySetVerified(null);
    setLicenseFieldError('email', 'Your email verification ran out. Send a new code and verify again.');
    return;
  }
  if (!r.ok) {
    const errors = (r.data && r.data.details && r.data.details.errors) || {};
    let firstBad = null;
    for (const [key, [inputId]] of Object.entries(LIC_BUY_FIELDS)) {
      setLicenseFieldError(key, errors[key] || '');
      if (errors[key] && !firstBad) firstBad = inputId;
    }
    showLicenseError(Object.keys(errors).length ? 'Some details need fixing.' : licenseFailureText(r));
    const box = firstBad && document.getElementById(firstBad);
    if (box && box.focus) box.focus();
    return;
  }
  _purchaseAttempt = null;
  _purchaseProof = null;
  showLicenseView('bought', { reference: r.data.reference });
}

function hideLockScreen() {
  _licenseView = { name: 'home', email: _licenseView.email };
  const overlay = document.getElementById('license-overlay');
  if (overlay) overlay.classList.add('hidden');
}

// Closes the dialog. Only ever reachable when the app is unlocked — the
// button is not rendered behind a lock — so this cannot strand the user on a
// working-looking app they have no licence for.
function dismissLicenseDialog() {
  hideLockScreen();
}

// The way back in for a licensed user missing a paid tab: the topbar chip.
// Without it the dialog would be reachable only by triggering a 402, which
// they cannot do once the tab is out of the bar.
function openLicenseDialog() {
  if (_license) renderLockScreen(_license);
}

function showLicenseError(message) {
  const box = document.getElementById('lic-error');
  if (box) box.textContent = message;
}

// ── Status chip in the topbar ──────────────────────────────────────────────

function renderLicenseChip(status) {
  const bar = document.querySelector('.topbar-right');
  if (!bar) return;

  let chip = document.getElementById('lic-chip');

  // A countdown outranks the upsell. A trial grants no features, so the "buy
  // something" branch below would otherwise match every trial and replace the
  // days-remaining chip — which is the one piece of information an evaluator
  // actually needs.
  const counting = status.status === 'trial' || status.status === 'grace' || status.warn;

  // Nothing paid is unlocked: offer the way in. Deliberately keyed on "none of
  // it" rather than "not all of it" — a Version Viewer customer who chose not
  // to buy Security must not be nagged about it on every launch.
  const nothingUnlocked = !counting && !(status.features || []).length;

  if (!counting && !nothingUnlocked) {
    if (chip) chip.remove();
    return;
  }

  if (!chip) {
    chip = document.createElement('span');
    chip.id = 'lic-chip';
    bar.prepend(chip);
  }
  chip.className = 'lic-chip';

  if (nothingUnlocked) {
    chip.classList.add('lic-chip-cta');
    chip.textContent = 'Unlock Version Watch + Security';
    chip.title = status.message || 'Activate a licence to enable these tabs.';
    chip.onclick = openLicenseDialog;
    return;
  }

  chip.onclick = null;
  chip.classList.toggle('lic-chip-warn', status.status === 'grace' || !!status.warn);
  // Days until the last one, hours inside it: days would read "1d left" from
  // the last morning to the last minute. The end date is on the chip itself,
  // not only in the tooltip, so "when does it stop?" never needs a hover.
  chip.textContent =
    status.status === 'grace'
      ? `Offline — locks in ${status.graceDaysRemaining}d`
      : status.hoursRemaining !== null && status.hoursRemaining <= 24
        ? `Trial — ${status.hoursRemaining}h left`
        : `Trial — ${status.daysRemaining}d left · ends ${formatExpiry(status.expiresAt)}`;
  chip.title = status.warn || `Expires ${formatExpiry(status.expiresAt)}`;
}

// ── Actions ────────────────────────────────────────────────────────────────

async function licenseAction(url, body, buttonId) {
  const btn = buttonId ? document.getElementById(buttonId) : null;
  const wasLocked = licenseIsLocked();
  if (btn) btn.disabled = true;
  showLicenseError('');
  try {
    const resp = await fetch(`${API}${url}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
    const data = await resp.json();
    if (!resp.ok) {
      // 503 is our outage, 400 is their key. Saying "invalid key" during our
      // own downtime sends a paying customer hunting for a problem that is not
      // theirs, so the server's message is shown as-is.
      // On an unreachable service, name the host we tried. "Could not reach the
      // licence service" with no address is unactionable — it looks the same
      // whether the service is down or this build points somewhere wrong.
      const where = resp.status === 503 && _license && _license.serviceUrl ? ` (${_license.serviceUrl})` : '';
      showLicenseError(`${data.message || 'Activation failed.'}${where}`);
      return null;
    }
    applyStatusChange(data, wasLocked);
    return data;
  } catch (e) {
    showLicenseError('Could not reach the licence service. Check your connection and try again.');
    return null;
  } finally {
    if (btn) btn.disabled = false;
  }
}

// Applies a new status. Shared by activation and by the poll below, so both
// handle the locked → unlocked transition the same way.
function applyStatusChange(status, wasLocked) {
  _license = status;

  // Coming out of a lock, reload rather than just hiding the overlay.
  //
  // While the app was locked every other module was still booting and still
  // fetching, and each of those calls came back 402. wizard.js turns a failed
  // response into `throw new Error(data.error)` and prints it under the PAT
  // field, so the wizard is sitting there displaying "license_required" by the
  // time the user activates. Hiding the overlay reveals that stale error on a
  // now perfectly licensed app. A reload re-runs every module against a valid
  // licence, which is both simpler and more thorough than trying to find and
  // reset each piece of state the lock left behind.
  if (wasLocked && !status.locked) {
    window.location.reload();
    return;
  }

  applyLicenseStatus(status);
}

// The trial has two steps. The licence page comes FIRST on a machine with no licence and no
// trial, and "Start trial" on it means "yes, set me up": it takes the user to the setup wizard
// (or straight on, if setup was saved). The trial itself starts when the customer's GitHub and
// Jenkins connect, so the machine and those addresses are logged together
// (see ensureLicenseReady). If starting then fails, the licence page comes back with the
// reason and this button retries for real.
let _trialChosen = false;

function startLicenseTrial() {
  if (!_trialChosen && _license && _license.status === 'unregistered') {
    _trialChosen = true;
    hideLockScreen();
    if (typeof autoResume === 'function') autoResume();     // saved setup goes straight on
    return Promise.resolve(null);
  }
  // The session lets the server tell the licence service which Jenkins and GitHub the
  // customer connected (addresses only, never a token).
  return licenseAction('/api/license/trial', { session: (typeof sessionId !== 'undefined' && sessionId) || '' }, 'lic-trial-btn');
}





// ── Wiring ─────────────────────────────────────────────────────────────────

// The paid tabs, and the only tabs this module touches. Everything else in the
// tab bar is core and is never hidden, whatever the licence says.
const PAID_TABS = ['version-watch', 'security'];

// Once the user has chosen "Start trial" on the licence page, the setup wizard takes over and
// the licence page must not cover it again while the machine is still waiting for its trial
// (it starts when GitHub and Jenkins connect). Before that choice, and for an expired trial,
// a revoked licence or a damaged licence file, the licence page is shown.
function setupIsShowing() {
  const app = document.getElementById('main-app');
  return !app || app.classList.contains('hidden');
}
function licenseDeferredForSetup(status) {
  return !!status && _trialChosen && status.status === 'unregistered' && !status.tokenError && setupIsShowing();
}

function applyLicenseStatus(status) {
  if (!status) return;

  if (status.locked && licenseDeferredForSetup(status)) {
    hideLockScreen();
    return;
  }

  if (status.locked) {
    renderLockScreen(status);
    // Drop the countdown chip too. It sits behind the overlay so nobody sees a
    // stale "1h left", but leaving it there means the number is wrong the
    // moment anything reveals the topbar again.
    const chip = document.getElementById('lic-chip');
    if (chip) chip.remove();
    return;
  }

  hideLockScreen();
  renderLicenseChip(status);

  // Tabs the licence did not buy are hidden. This is convenience, not
  // enforcement — the gate refuses the routes behind them either way. Toggled
  // rather than added, so buying Version Watch mid-session puts the tab back
  // without a reload.
  for (const feature of PAID_TABS) {
    const btn = document.getElementById(`tab-btn-${feature}`);
    if (btn) btn.classList.toggle('hidden', !licenseHasFeature(feature));
  }
}

// Catches a licence that goes bad while the app is already open: the next API
// call comes back 402 and the lock screen appears immediately, instead of the
// user staring at silently failing buttons until they restart.
function installLicenseFetchInterceptor() {
  const original = window.fetch;
  window.fetch = async function (...args) {
    const resp = await original.apply(this, args);
    if (resp.status === 402) {
      const clone = resp.clone();
      try {
        const data = await clone.json();
        if (data && data.status) {
          _license = data.status;
          // After the user chose "Start trial" the wizard is on screen and the trial does not exist
          // yet, so a few background calls are refused with 402. That is expected, not a licence
          // problem: the trial starts when setup connects. Do not cover the wizard for them.
          if (!licenseDeferredForSetup(data.status)) renderLockScreen(data.status);
        }
      } catch (e) {}
    }
    return resp;
  };
}

// Installed at script load, NOT after the first status fetch resolves.
//
// The other modules start fetching on DOMContentLoaded — wizard.js validates a
// remembered GitHub token straight away — and awaiting our own status call
// first would let those requests race past unwrapped. Their 402s would then be
// handled as ordinary API errors and printed into the UI, which is exactly how
// "license_required" ended up under the PAT field. This module is loaded before
// wizard.js in index.html so that this line runs first.
//
// Harmless when enforcement is off: nothing returns 402, so the wrapper only
// ever forwards.
installLicenseFetchInterceptor();

// Re-reads the licence and updates the countdown, the chip, and — if the trial
// ran out while nobody was clicking — the lock screen.
async function refreshLicenseStatus() {
  const wasLocked = licenseIsLocked();
  const status = await fetchLicenseStatus();
  if (!status) return;
  applyStatusChange(status, wasLocked);
}

function startLicensePolling() {
  setInterval(() => {
    // Nothing to update on a window nobody is looking at, and a backgrounded
    // tab throttles timers anyway.
    if (document.hidden) return;
    refreshLicenseStatus();
  }, LICENSE_POLL_MS);

  // Coming back to the app is the moment the countdown is most likely to be
  // wrong: a laptop that slept overnight wakes with a chip eight hours stale,
  // or a trial that has since expired. Refresh immediately rather than waiting
  // out the interval.
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshLicenseStatus();
  });
}

// Starts the trial when setup finishes: called once the customer's GitHub and Jenkins details
// are in and the session exists. On a machine that already has a licence or a trial it does
// nothing. If the trial cannot start (offline, say) the licence screen explains and offers a
// retry; setup stays where it is.
//
// Returns true when the app may carry on.
async function ensureLicenseReady() {
  const status = await fetchLicenseStatus();
  if (!status) return true;                       // licensing is off in this build
  _license = status;
  if (status.status !== 'unregistered') { applyLicenseStatus(status); return true; }

  // A trial is only ever started on the customer's say-so: show the licence page first.
  if (!_trialChosen) { renderLockScreen(status); return false; }

  let resp = null;
  let data = {};
  try {
    resp = await fetch(`${API}/api/license/trial`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: (typeof sessionId !== 'undefined' && sessionId) || '' }),
    });
    data = await resp.json().catch(() => ({}));
  } catch (_) { resp = null; }

  if (!resp || !resp.ok) {
    renderLockScreen(status);
    // Name the address that was tried: "could not reach the licence service" with no address is
    // unactionable (it reads the same whether the service is down or the build points elsewhere).
    const where = status.serviceUrl ? ` (${status.serviceUrl})` : '';
    showLicenseError(resp ? `${data.message || 'Your trial could not be started. Please try again.'}${resp.status === 503 ? where : ''}`
      : `Could not reach the licence service${where}. Check your connection and try again.`);
    return false;
  }
  // No page reload here (unlike applyStatusChange): setup is half-way through and the
  // wizard routes were open all along, so there is no stale error to clear.
  _license = data;
  applyLicenseStatus(data);
  return true;
}

async function initLicense() {
  const status = await fetchLicenseStatus();
  // A null status means the licence API is not mounted — enforcement is off
  // (the internal build). Leave the UI alone, and do not poll an endpoint that
  // is not there.
  if (!status) return;
  applyLicenseStatus(status);
  startLicensePolling();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initLicense);
} else {
  initLicense();
}