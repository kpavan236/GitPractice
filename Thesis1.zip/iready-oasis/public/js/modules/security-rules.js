// =============================================================================
// Security — the Rules section
// =============================================================================
// Browse every rule, see what a quality profile does with each, turn rules on and
// off and change their severity per profile, and write a new rule that has been
// proven to work before it can be saved.
//
// The rules live on the rule server. This talks to /api/security/rule-admin (a
// gateway), never to the server itself.
//
// Two ideas decide the shape of the screen, both borrowed from SonarQube:
//   - Built-in and vendored rules are READ-ONLY. A profile decides whether they run
//     and at what severity; nobody edits their text here.
//   - A custom rule cannot be saved until its samples have passed a test run with the
//     real analyzer. A rule that finds nothing looks exactly like a rule that is not there.
//
// Rule text comes from people and from upstream rule sets, so every value is escaped
// (secEscape) and nothing from a rule is ever placed in an inline script: rows and
// buttons carry data-* attributes and one delegated handler reads them.

// ── Pure helpers (unit-tested) ────────────────────────────────────────────────

const SR_SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
const SR_ENGINE_LABELS = { ast: 'Syntax tree', pattern: 'Line pattern', 'iac-policy': 'IaC policy', secret: 'Secret' };

function severityRank(severity) {
  const i = SR_SEVERITIES.indexOf(severity);
  return i === -1 ? 9 : i;
}

function ruleMatches(rule, query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return true;
  return [rule.id, rule.title, rule.description].some(v => v && String(v).toLowerCase().includes(q));
}

function facetCounts(rules, field) {
  const counts = new Map();
  for (const r of rules) if (r[field]) counts.set(r[field], (counts.get(r[field]) || 0) + 1);
  return [...counts].map(([value, count]) => ({ value, count }))
    .sort((a, b) => b.count - a.count || String(a.value).localeCompare(String(b.value)));
}

function sortRules(rules) {
  return [...rules].sort((a, b) => severityRank(a.severity) - severityRank(b.severity) || String(a.id).localeCompare(String(b.id)));
}

// Whether a rule runs in the chosen profile, and where that comes from.
function profileStateLabel(entry) {
  if (!entry) return { label: 'Not in this profile', tone: 'none' };
  const on = entry.enabled ? 'On' : 'Off';
  const tone = entry.enabled ? 'on' : 'off';
  if (entry.overridden) return { label: `${on} in this profile`, tone };
  if (entry.inherited) return { label: `${on} (inherited)`, tone };
  return { label: on, tone };
}

// Parent first, children indented, so inheritance reads as a tree. A profile whose
// parent has gone is shown as a root rather than hidden.
function profileOrder(profiles) {
  const ids = new Set(profiles.map(p => p.id));
  const children = new Map();
  for (const p of profiles) {
    const parent = p.parentId && ids.has(p.parentId) ? p.parentId : null;
    if (!children.has(parent)) children.set(parent, []);
    children.get(parent).push(p);
  }
  const out = [];
  const walk = (parent, depth) => {
    for (const p of children.get(parent) || []) {
      out.push({ profile: p, depth });
      walk(p.id, depth + 1);
    }
  };
  walk(null, 0);
  return out;
}

function emptyForm() {
  return {
    id: '', language: 'javascript', kind: 'pattern', pattern: '', query: '', files: '**/*.js', severity: 'MEDIUM',
    title: '', description: '', remediation: '', cwe: '', detect: '', clean: '',
  };
}

const splitList = text => String(text || '').split(/[\n,]/).map(s => s.trim()).filter(Boolean);

function formToRule(form) {
  const rule = {
    id: String(form.id || '').trim(),
    language: String(form.language || '').trim(),
    severity: form.severity,
    title: String(form.title || '').trim(),
  };
  if (form.kind === 'query') {
    rule.query = String(form.query || '').trim();
  } else {
    rule.pattern = String(form.pattern || '').trim();
    rule.files = splitList(form.files);
  }
  for (const key of ['description', 'remediation', 'cwe']) {
    const v = String(form[key] || '').trim();
    if (v) rule[key] = v;
  }
  rule.fixture = { detect: String(form.detect || ''), clean: String(form.clean || '') };
  return rule;
}

function ruleToForm(rule) {
  const form = emptyForm();
  form.id = rule.id || '';
  form.language = rule.language || '';
  form.severity = rule.severity || 'MEDIUM';
  form.title = rule.title || '';
  form.description = rule.description || '';
  form.remediation = rule.remediation || '';
  form.cwe = rule.cwe || '';
  if (rule.query) {
    form.kind = 'query';
    form.query = rule.query;
    form.files = '';
  } else {
    form.kind = 'pattern';
    form.pattern = rule.pattern || '';
    form.files = (Array.isArray(rule.files) ? rule.files : rule.files ? [rule.files] : []).join(', ');
  }
  form.detect = (rule.fixture && rule.fixture.detect) || '';
  form.clean = (rule.fixture && rule.fixture.clean) || '';
  return form;
}

function formProblems(form) {
  const problems = [];
  const need = (field, ok, message) => { if (!ok) problems.push({ field, message }); };
  const id = String(form.id || '').trim();
  need('id', id, 'Give the rule an id');
  need('id', !id || /^[A-Za-z0-9._\/:-]+$/.test(id), 'Use letters, digits and . _ - / : only (no spaces)');
  need('language', String(form.language || '').trim(), 'Choose the language the rule applies to');
  need('title', String(form.title || '').trim(), 'Give the rule a title');
  if (form.kind === 'query') {
    need('query', String(form.query || '').trim(), 'Write the syntax-tree query');
  } else {
    need('pattern', String(form.pattern || '').trim(), 'Write the line pattern (a regular expression)');
    need('files', splitList(form.files).length, 'Say which files it applies to (for example **/*.js)');
  }
  need('detect', String(form.detect || '').trim(), 'Add a sample the rule must flag');
  need('clean', String(form.clean || '').trim(), 'Add a sample the rule must leave alone');
  need('severity', SR_SEVERITIES.includes(form.severity), 'Choose a severity');
  return problems;
}

const signatureOf = form => JSON.stringify(formToRule(form));

// What to send when editing a saved rule. The server merges a patch into the stored
// rule, so a field the edit dropped (the pattern, when a rule becomes a query; a
// cleared description) must be sent as an explicit null or it would silently stay.
const SR_OPTIONAL_FIELDS = ['query', 'pattern', 'files', 'description', 'remediation', 'cwe'];

function editPatch(rule, original) {
  const { id, ...patch } = rule;
  for (const key of SR_OPTIONAL_FIELDS) {
    if (original[key] !== undefined && patch[key] === undefined) patch[key] = null;
  }
  return patch;
}

// Save is allowed only for the exact content that last passed its test. Any edit
// after the test, to any field, takes it away again.
function canSave(form, lastTest) {
  return formProblems(form).length === 0 && !!lastTest && lastTest.ok === true && lastTest.signature === signatureOf(form);
}

function explainTestReport(report) {
  const plural = n => `${n} finding${n === 1 ? '' : 's'}`;
  if (report.ok) {
    return {
      title: 'Passed',
      lines: [
        `Fired on the detect sample (${plural(report.detect.found)}, saved as ${report.file})`,
        'Stayed silent on the clean sample',
      ],
    };
  }
  return { title: 'Failed', lines: report.errors };
}

// What the detail view may offer for a rule, from where it came from.
function ruleDetailModel(row) {
  const body = row.body || {};
  const isUser = row.origin === 'user';
  const active = row.status === 'ACTIVE';
  return {
    id: row.id,
    title: body.title || row.id,
    origin: row.origin,
    status: row.status,
    version: row.version,
    editable: isUser && active,
    deprecatable: isUser && active,
    readOnlyReason: isUser ? null
      : 'This is a built-in rule from the rule set, so its content is read-only. You can turn it on or off and change its severity per profile.',
    source: (body.provenance && body.provenance.source) || null,
    license: (body.provenance && body.provenance.license) || null,
    body,
  };
}

// ── State ─────────────────────────────────────────────────────────────────────

const SR_SECTION_KEY = 'oasis.sec.section';
const SR_PROFILE_KEY = 'oasis.sec.rules.profile';

let _srRules = [];                 // summary rows (id, title, severity, origin, ...)
let _srProfiles = [];
let _srProfileId = null;
let _srEntries = new Map();        // ruleId -> this profile's view of the rule
let _srCounts = null;
let _srFilter = { search: '', language: '', engine: '', severity: '', origin: '', state: 'all', deprecated: false };
let _srLoaded = false;
let _srEditor = null;              // { mode: 'new'|'edit', form, lastTest, original }

const srFetch = (url, options) => secFetch(`/rule-admin${url}`, options);
const srJson = (method, body) => ({ method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

function srRemember(key, value) { try { localStorage.setItem(key, value); } catch (e) { /* private window: fine */ } }
function srRecall(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }

// Messages for this section. The findings notice (#sec-clear) sits inside the chrome
// that is hidden while Rules is showing, so Saved/failed/refused would be invisible.
function srNotice(message, isError = false) {
  const box = document.getElementById('sr-notice');
  if (!box) return;
  box.className = `sr-notice ${isError ? 'sr-notice-error' : 'sr-notice-ok'}`;
  box.innerHTML = `<span>${secEscape(message)}</span><button class="sec-link" data-act="dismiss-notice">Dismiss</button>`;
  clearTimeout(srNotice._timer);
  if (!isError) srNotice._timer = setTimeout(() => box.classList.add('hidden'), 7000);
}

// ── Section switch ────────────────────────────────────────────────────────────

function showSecuritySection(name) {
  const rules = name === 'rules';
  document.getElementById('sec-rules').classList.toggle('hidden', !rules);
  for (const el of document.querySelectorAll('#tab-security .sec-chrome, #tab-security #sec-scroll, #tab-security .sec-findings-only')) {
    el.classList.toggle('hidden', rules);
  }
  document.getElementById('sec-switch-findings').classList.toggle('active', !rules);
  document.getElementById('sec-switch-rules').classList.toggle('active', rules);
  srRemember(SR_SECTION_KEY, name);
  if (rules) openRulesSection();
}

// Installed-release mode shows the read-only view (rules-readonly.js); otherwise the rule-server editor loads as before.
async function openRulesSection() {
  let mode = 'legacy';
  if (typeof initRulesReadonly === 'function') mode = await initRulesReadonly();
  if (mode === 'legacy') initSecurityRules();
}

function restoreSecuritySection() {
  if (srRecall(SR_SECTION_KEY) === 'rules') showSecuritySection('rules');
}

// ── Loading ───────────────────────────────────────────────────────────────────

async function initSecurityRules() {
  const body = document.getElementById('sr-body');
  if (!_srLoaded) body.innerHTML = '<div class="sr-empty">Loading rules…</div>';
  try {
    _srProfiles = await srFetch('/profiles');
    const remembered = srRecall(SR_PROFILE_KEY);
    _srProfileId = _srProfiles.some(p => p.id === _srProfileId) ? _srProfileId
      : _srProfiles.some(p => p.id === remembered) ? remembered
      : (_srProfiles.find(p => p.isDefault) || _srProfiles[0] || {}).id;
    await Promise.all([loadSecurityRuleList(), loadSecurityProfileEntries()]);
    _srLoaded = true;
    renderSecurityRules();
  } catch (e) {
    body.innerHTML = `<div class="sr-empty sr-error">${secEscape(e.message)}<br><small>The rules live on the rule server. Start it with <code>bash start-rule-server.sh</code>.</small></div>`;
  }
}

async function loadSecurityRuleList() {
  const filter = _srFilter.deprecated ? '' : '?status=ACTIVE';
  _srRules = await srFetch(`/rules${filter}`);
}

async function loadSecurityProfileEntries() {
  if (!_srProfileId) { _srEntries = new Map(); _srCounts = null; return; }
  const view = await srFetch(`/profiles/${encodeURIComponent(_srProfileId)}/rules`);
  _srEntries = new Map(view.rules.map(r => [r.ruleId, r]));
  _srCounts = view.counts;
}

// ── Rendering ─────────────────────────────────────────────────────────────────

function srVisibleRules() {
  const f = _srFilter;
  return sortRules(_srRules.filter(r => {
    const entry = _srEntries.get(r.id);
    if (!ruleMatches(r, f.search)) return false;
    if (f.language && r.language !== f.language) return false;
    if (f.engine && r.engine !== f.engine) return false;
    if (f.severity && ((entry && entry.severity) || r.severity) !== f.severity) return false;
    if (f.origin && r.origin !== f.origin) return false;
    if (f.state === 'on' && !(entry && entry.enabled)) return false;
    if (f.state === 'off' && (entry && entry.enabled)) return false;
    if (f.state === 'overridden' && !(entry && entry.overridden)) return false;
    return true;
  }));
}

function srSelect(id, label, options, current) {
  return `<label class="sr-field"><span>${secEscape(label)}</span>
    <select id="${id}" class="sec-select" data-filter="${id.replace('sr-f-', '')}">
      <option value="">All</option>
      ${options.map(o => `<option value="${secEscape(o.value)}" ${o.value === current ? 'selected' : ''}>${secEscape(o.label || o.value)} (${o.count})</option>`).join('')}
    </select></label>`;
}

function renderSecurityRules() {
  const body = document.getElementById('sr-body');
  const profile = _srProfiles.find(p => p.id === _srProfileId);
  const ordered = profileOrder(_srProfiles);
  const visible = srVisibleRules();
  const stateBtn = (value, label) => `<button class="sec-seg ${_srFilter.state === value ? 'active' : ''}" data-state="${value}">${label}</button>`;

  body.innerHTML = `
    <div class="sr-bar">
      <label class="sr-field"><span>Quality profile</span>
        <select id="sr-profile" class="sec-select">
          ${ordered.map(({ profile: p, depth }) => `<option value="${secEscape(p.id)}" ${p.id === _srProfileId ? 'selected' : ''}>${' '.repeat(depth)}${secEscape(p.name)}${p.isDefault ? ' (default)' : ''}</option>`).join('')}
        </select></label>
      <button class="btn btn-ghost btn-sm" data-act="new-profile">New profile…</button>
      <button class="btn btn-ghost btn-sm" data-act="delete-profile" ${profile && profile.isDefault ? 'disabled title="The Default profile is the baseline and cannot be deleted"' : ''}>Delete profile</button>
      <button class="btn btn-ghost btn-sm" data-act="assignments">Repositories…</button>
      <span class="sr-spacer"></span>
      <button class="btn btn-primary btn-sm" data-act="add-rule">+ Add rule</button>
    </div>
    ${profile && profile.parentId ? `<div class="sr-note">Inherits <strong>${secEscape((_srProfiles.find(p => p.id === profile.parentId) || {}).name || profile.parentId)}</strong>. Only the rules you change here are overrides.</div>` : ''}
    <div class="sr-counts">
      ${_srCounts ? `<strong>${_srCounts.total}</strong> rules · <span class="sr-on">${_srCounts.enabled} on</span> · <span class="sr-off">${_srCounts.disabled} off</span>${_srCounts.overridden ? ` · ${_srCounts.overridden} overridden` : ''}` : ''}
      · showing <strong>${visible.length}</strong>
    </div>
    <div class="sr-filters">
      <div class="search-wrap sr-search"><span class="search-icon">⌕</span>
        <input id="sr-search" class="search-input" placeholder="Search rule id, title or description…" value="${secEscape(_srFilter.search)}"/></div>
      ${srSelect('sr-f-language', 'Language', facetCounts(_srRules, 'language'), _srFilter.language)}
      ${srSelect('sr-f-engine', 'Type', facetCounts(_srRules, 'engine').map(o => ({ ...o, label: SR_ENGINE_LABELS[o.value] || o.value })), _srFilter.engine)}
      ${srSelect('sr-f-origin', 'Origin', facetCounts(_srRules, 'origin'), _srFilter.origin)}
      <label class="sr-field"><span>Severity</span>
        <select id="sr-f-severity" class="sec-select" data-filter="severity"><option value="">All</option>
          ${SR_SEVERITIES.map(s => `<option value="${s}" ${s === _srFilter.severity ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
      <div class="sec-segmented" id="sr-state">${stateBtn('all', 'All')}${stateBtn('on', 'On')}${stateBtn('off', 'Off')}${stateBtn('overridden', 'Overridden')}</div>
      <label class="sr-check"><input type="checkbox" id="sr-f-deprecated" ${_srFilter.deprecated ? 'checked' : ''}/> deprecated</label>
    </div>
    <table class="sec-table sr-table">
      <thead><tr><th class="sr-col-rule">Rule</th><th class="sr-col-lang">Language</th><th class="sr-col-type">Type</th>
        <th class="sr-col-sev">Severity</th><th class="sr-col-origin">Origin</th><th class="sr-col-on">In profile</th></tr></thead>
      <tbody id="sr-rows">
        ${visible.length ? visible.map(srRow).join('') : '<tr><td colspan="6" class="sec-empty">No rules match.</td></tr>'}
      </tbody>
    </table>`;
}

function srRow(rule) {
  const entry = _srEntries.get(rule.id);
  const severity = (entry && entry.severity) || rule.severity;
  const state = profileStateLabel(entry);
  const deprecated = rule.status !== 'ACTIVE';
  return `<tr class="sr-row ${deprecated ? 'sr-deprecated' : ''}" data-id="${secEscape(rule.id)}" tabindex="0">
    <td class="sr-col-rule"><div class="sr-title">${secEscape(rule.title)}</div><div class="sr-id">${secEscape(rule.id)}</div></td>
    <td>${secEscape(rule.language)}</td>
    <td>${secEscape(SR_ENGINE_LABELS[rule.engine] || rule.engine)}</td>
    <td><span class="sec-sev sec-sev-${secEscape(severity)}">${secEscape(severity)}</span>${entry && entry.severity !== rule.severity ? `<span class="sr-was" title="Default severity">was ${secEscape(rule.severity)}</span>` : ''}</td>
    <td><span class="sr-origin sr-origin-${secEscape(rule.origin)}">${secEscape(rule.origin)}</span></td>
    <td class="sr-col-on">
      ${entry ? `<label class="sr-switch" title="${secEscape(state.label)}"><input type="checkbox" data-act="toggle" ${entry.enabled ? 'checked' : ''}/><span></span></label>` : '<span class="sr-none">—</span>'}
      <small class="sr-state sr-state-${state.tone}">${secEscape(state.label)}</small>
    </td>
  </tr>`;
}

// ── Detail drawer ─────────────────────────────────────────────────────────────

async function openSecurityRule(id) {
  let row;
  try {
    row = await srFetch(`/rules/${encodeURIComponent(id)}`);
  } catch (e) { return srNotice(e.message, true); }
  const m = ruleDetailModel(row);
  const b = m.body;
  const entry = _srEntries.get(id);
  const profile = _srProfiles.find(p => p.id === _srProfileId);
  const state = profileStateLabel(entry);
  const code = (label, text) => text ? `<div class="sec-drawer-section"><h4>${label}</h4><pre class="sr-code">${secEscape(text)}</pre></div>` : '';

  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head">
      <div>
        <div class="sec-drawer-title">${secEscape(m.title)}</div>
        <div class="sec-drawer-sub">
          <span class="sec-sev sec-sev-${secEscape(row.severity)}">${secEscape(row.severity)}</span>
          <span>${secEscape(SR_ENGINE_LABELS[row.engine] || row.engine)}</span> · <span>${secEscape(row.language)}</span>
          · <span class="sr-origin sr-origin-${secEscape(m.origin)}">${secEscape(m.origin)}</span>
          · <code>${secEscape(m.id)}</code> · v${secEscape(m.version)}${m.status !== 'ACTIVE' ? ` · <strong>${secEscape(m.status)}</strong>` : ''}
        </div>
      </div>
      <button class="sec-drawer-close" data-act="close-drawer">✕</button>
    </div>

    ${entry ? `<div class="sec-drawer-section sr-profile-box" data-rule="${secEscape(id)}">
      <h4>In “${secEscape(profile ? profile.name : '')}”</h4>
      <div class="sr-profile-row">
        <label class="sr-switch"><input type="checkbox" data-act="drawer-toggle" ${entry.enabled ? 'checked' : ''}/><span></span></label>
        <strong class="sr-state-${state.tone}">${secEscape(state.label)}</strong>
        <label class="sr-field sr-inline"><span>Severity here</span>
          <select data-act="drawer-severity" class="sec-select">${SR_SEVERITIES.map(s => `<option ${s === entry.severity ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        ${entry.overridden ? '<button class="sec-link" data-act="drawer-reset">Reset to inherited</button>' : ''}
      </div>
      <div class="sr-hint">Default severity is ${secEscape(entry.defaultSeverity)}. A change takes effect on the next scan.</div>
    </div>` : ''}

    ${m.readOnlyReason ? `<div class="sr-note">${secEscape(m.readOnlyReason)}</div>` : ''}
    ${b.description ? `<div class="sec-drawer-section"><h4>What it finds</h4><p class="sec-drawer-text">${secEscape(b.description)}</p></div>` : ''}
    ${b.remediation ? `<div class="sec-drawer-section"><h4>How to fix it</h4><p class="sec-drawer-text">${secEscape(b.remediation)}</p></div>` : ''}
    <div class="sec-drawer-section sr-facts">
      ${b.cwe ? `<span>${secEscape(b.cwe)}</span>` : ''}${b.owasp ? `<span>${secEscape(b.owasp)}</span>` : ''}${b.confidence ? `<span>confidence ${secEscape(b.confidence)}</span>` : ''}
      ${m.source ? `<span>from ${secEscape(m.source)}${m.license ? ` · ${secEscape(m.license)}` : ''}</span>` : ''}
    </div>
    ${b.example ? code('Vulnerable example', b.example.vulnerable) + code('Fixed example', b.example.fixed) : ''}
    <details class="sec-drawer-section"><summary><strong>Definition</strong></summary>
      ${b.query ? code('Query', b.query) : ''}${b.pattern ? code('Pattern', b.pattern) : ''}${b.files ? code('Applies to', [].concat(b.files).join('\n')) : ''}
    </details>

    <div class="sr-actions">
      ${m.editable ? '<button class="btn btn-primary btn-sm" data-act="edit-rule">Edit rule</button>' : ''}
      ${m.deprecatable ? '<button class="btn btn-ghost btn-sm" data-act="deprecate-rule">Deprecate</button>' : ''}
      <button class="btn btn-ghost btn-sm" data-act="close-drawer">Close</button>
    </div>`;
  document.getElementById('sec-drawer-panel').dataset.rule = id;
  document.getElementById('sec-drawer').classList.remove('hidden');
}

// ── Changing a rule in the profile ────────────────────────────────────────────

async function srSetProfileRule(ruleId, patch) {
  try {
    await srFetch(`/profiles/${encodeURIComponent(_srProfileId)}/rules/${encodeURIComponent(ruleId)}`, srJson('PUT', patch));
    await loadSecurityProfileEntries();
    renderSecurityRules();
    srNotice('Saved. It applies from the next scan.');
    return true;
  } catch (e) {
    srNotice(e.message, true);
    renderSecurityRules();         // put the switch back where the server has it
    return false;
  }
}

async function srResetProfileRule(ruleId) {
  try {
    await srFetch(`/profiles/${encodeURIComponent(_srProfileId)}/rules/${encodeURIComponent(ruleId)}`, { method: 'DELETE' });
    await loadSecurityProfileEntries();
    renderSecurityRules();
    srNotice('Back to what this profile inherits.');
  } catch (e) { srNotice(e.message, true); }
}

// ── Profiles and assignments ──────────────────────────────────────────────────

function srSlug(name) {
  return String(name || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function openProfileForm() {
  const options = profileOrder(_srProfiles).map(({ profile: p, depth }) =>
    `<option value="${secEscape(p.id)}" ${p.id === _srProfileId ? 'selected' : ''}>${' '.repeat(depth)}${secEscape(p.name)}</option>`).join('');
  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head"><div class="sec-drawer-title">New quality profile</div>
      <button class="sec-drawer-close" data-act="close-drawer">✕</button></div>
    <div class="sec-drawer-section">
      <p class="sec-drawer-text">A profile starts as a copy of what its parent runs. Only the rules you then change are overrides, so it keeps following the parent for everything else.</p>
      <label class="sr-field"><span>Name</span><input id="sr-new-name" class="sr-input" placeholder="e.g. Payments services"/></label>
      <label class="sr-field"><span>Inherits</span><select id="sr-new-parent" class="sec-select">${options}</select></label>
      <div class="sr-error" id="sr-new-error"></div>
    </div>
    <div class="sr-actions"><button class="btn btn-primary btn-sm" data-act="create-profile">Create profile</button>
      <button class="btn btn-ghost btn-sm" data-act="close-drawer">Cancel</button></div>`;
  document.getElementById('sec-drawer').classList.remove('hidden');
  document.getElementById('sr-new-name').focus();
}

async function createSecurityProfile() {
  const name = document.getElementById('sr-new-name').value.trim();
  const parentId = document.getElementById('sr-new-parent').value;
  const err = document.getElementById('sr-new-error');
  const id = srSlug(name);
  if (!id) { err.textContent = 'Give the profile a name.'; return; }
  try {
    await srFetch('/profiles', srJson('POST', { id, name, parentId }));
    _srProfileId = id;
    srRemember(SR_PROFILE_KEY, id);
    closeSecurityFinding();
    await initSecurityRules();
    srNotice(`Created “${name}”.`);
  } catch (e) { err.textContent = e.message; }
}

async function deleteSecurityProfile() {
  const profile = _srProfiles.find(p => p.id === _srProfileId);
  if (!profile || profile.isDefault) return;
  if (!window.confirm(`Delete the profile “${profile.name}”? Its overrides are lost. This cannot be undone.`)) return;
  try {
    await srFetch(`/profiles/${encodeURIComponent(profile.id)}`, { method: 'DELETE' });
    _srProfileId = null;
    await initSecurityRules();
    srNotice(`Deleted “${profile.name}”.`);
  } catch (e) {
    srNotice(e.message, true);      // the server says who still uses it
  }
}

async function openSecurityAssignments() {
  let data;
  try { data = await srFetch('/assignments'); } catch (e) { return srNotice(e.message, true); }
  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head"><div class="sec-drawer-title">Which profile each repository uses</div>
      <button class="sec-drawer-close" data-act="close-drawer">✕</button></div>
    <div class="sec-drawer-section">
      <p class="sec-drawer-text">A repository nobody has assigned uses the Default profile. A change applies from its next scan.</p>
      <div class="sr-assign">
        ${data.assignments.map(a => `<div class="sr-assign-row" data-repo="${secEscape(a.repository)}">
          <span class="sr-assign-name">${secEscape(a.repository)}</span>
          <select class="sec-select" data-act="assign">
            <option value="">Default${a.registered && !a.profileId ? '' : ''}</option>
            ${_srProfiles.filter(p => !p.isDefault).map(p => `<option value="${secEscape(p.id)}" ${p.id === a.profileId ? 'selected' : ''}>${secEscape(p.name)}</option>`).join('')}
          </select></div>`).join('') || '<div class="sec-empty">No local repositories found.</div>'}
      </div>
    </div>
    <div class="sr-actions"><button class="btn btn-ghost btn-sm" data-act="close-drawer">Close</button></div>`;
  document.getElementById('sec-drawer').classList.remove('hidden');
}

async function assignSecurityProfile(repository, profileId) {
  try {
    await srFetch(`/projects/${encodeURIComponent(repository)}`, srJson('PUT', { profileId: profileId || null }));
    srNotice(`${repository} will use ${profileId ? (_srProfiles.find(p => p.id === profileId) || {}).name : 'the Default profile'} from its next scan.`);
  } catch (e) { srNotice(e.message, true); }
}

// ── The rule editor ───────────────────────────────────────────────────────────

function openSecurityRuleEditor(mode, original) {
  const form = mode === 'edit' ? ruleToForm(original.body) : emptyForm();
  _srEditor = { mode, form, original: original || null, lastTest: null };
  renderSecurityRuleEditor();
  document.getElementById('sec-drawer').classList.remove('hidden');
}

function srField(label, name, type, extra = '') {
  const f = _srEditor.form;
  const value = secEscape(f[name]);
  const input = type === 'textarea'
    ? `<textarea class="sr-input sr-mono" data-form="${name}" rows="${extra || 3}" spellcheck="false">${value}</textarea>`
    : `<input class="sr-input" data-form="${name}" value="${value}" ${extra}/>`;
  return `<label class="sr-field sr-wide"><span>${secEscape(label)}</span>${input}<small class="sr-field-error" data-error="${name}"></small></label>`;
}

function renderSecurityRuleEditor() {
  const { mode, form } = _srEditor;
  const languages = ['javascript', 'typescript', 'java', 'python', 'dockerfile', 'kubernetes', 'terraform', 'text'];
  const choice = (name, options) => `<select class="sec-select" data-form="${name}">${options.map(([v, l]) => `<option value="${secEscape(v)}" ${form[name] === v ? 'selected' : ''}>${secEscape(l)}</option>`).join('')}</select>`;
  const activate = _srProfiles.map(p => `<label class="sr-check"><input type="checkbox" data-activate="${secEscape(p.id)}" ${p.id === _srProfileId ? 'checked' : ''}/> ${secEscape(p.name)}</label>`).join('');

  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head"><div class="sec-drawer-title">${mode === 'edit' ? 'Edit rule' : 'Add a rule'}</div>
      <button class="sec-drawer-close" data-act="close-drawer">✕</button></div>

    <div class="sec-drawer-section sr-form">
      <div class="sr-row2">
        ${srField('Rule id', 'id', 'input', mode === 'edit' ? 'readonly' : 'placeholder="my-team-no-eval"')}
        <label class="sr-field"><span>Severity</span>${choice('severity', SR_SEVERITIES.map(s => [s, s]))}</label>
      </div>
      ${srField('Title', 'title', 'input', 'placeholder="Avoid eval()"')}
      <div class="sr-row2">
        <label class="sr-field"><span>Language</span>
          <input class="sr-input" data-form="language" list="sr-languages" value="${secEscape(form.language)}"/>
          <datalist id="sr-languages">${languages.map(l => `<option value="${l}">`).join('')}</datalist>
          <small class="sr-field-error" data-error="language"></small></label>
        <label class="sr-field"><span>How it matches</span>
          ${choice('kind', [['pattern', 'Line pattern'], ['query', 'Syntax-tree query']])}
          <small class="sr-hint">${form.kind === 'query' ? 'Matches code structure (tree-sitter): precise for JavaScript, TypeScript, Java and Python.' : 'A regular expression matched line by line, for files with no grammar.'}</small></label>
      </div>
      <div id="sr-kind-pattern" class="${form.kind === 'pattern' ? '' : 'hidden'}">
        ${srField('Pattern', 'pattern', 'textarea', '2')}
        ${srField('Applies to files', 'files', 'input', 'placeholder="**/*.js, **/*.mjs"')}
      </div>
      <div id="sr-kind-query" class="${form.kind === 'query' ? '' : 'hidden'}">
        ${srField('Query', 'query', 'textarea', '4')}
        <div class="sr-hint">Capture the problem with <code>@sink</code>, for example <code>(call_expression function: (identifier) @f (#eq? @f "eval")) @sink</code>.</div>
      </div>
      <div class="sr-row2">
        ${srField('Vulnerable sample (must be flagged)', 'detect', 'textarea', '4')}
        ${srField('Clean sample (must stay silent)', 'clean', 'textarea', '4')}
      </div>
      ${srField('Description', 'description', 'textarea', '2')}
      ${srField('How to fix it', 'remediation', 'textarea', '2')}
      <div class="sr-row2">${srField('CWE', 'cwe', 'input', 'placeholder="CWE-95"')}<span></span></div>
      ${mode === 'new' ? `<div class="sr-field"><span>Turn it on in</span><div class="sr-checks">${activate}</div></div>` : ''}
    </div>

    <div class="sr-testbox" id="sr-testbox"></div>
    <div class="sr-actions">
      <button class="btn btn-ghost btn-sm" data-act="test-rule">Test rule</button>
      <button class="btn btn-primary btn-sm" data-act="save-rule" id="sr-save" disabled>Save rule</button>
      <button class="btn btn-ghost btn-sm" data-act="close-drawer">Cancel</button>
      <span class="sr-hint" id="sr-save-hint">Test the rule to unlock Save.</span>
    </div>`;
  srRefreshEditorState();
}

// Called on every edit: show/hide the matching half, and take Save away from any
// content that has changed since it last passed.
function srRefreshEditorState() {
  if (!_srEditor) return;
  const { form, lastTest } = _srEditor;
  document.getElementById('sr-kind-pattern').classList.toggle('hidden', form.kind !== 'pattern');
  const kindHint = document.querySelector('#sec-drawer-panel [data-form="kind"] + .sr-hint');
  if (kindHint) kindHint.textContent = form.kind === 'query'
    ? 'Matches code structure (tree-sitter): precise for JavaScript, TypeScript, Java and Python.'
    : 'A regular expression matched line by line, for files with no grammar.';
  document.getElementById('sr-kind-query').classList.toggle('hidden', form.kind !== 'query');
  const ok = canSave(form, lastTest);
  document.getElementById('sr-save').disabled = !ok;
  const hint = document.getElementById('sr-save-hint');
  hint.textContent = ok ? 'This exact rule passed its test.'
    : lastTest && lastTest.ok && lastTest.signature !== signatureOf(form) ? 'You changed the rule since it passed. Test it again.'
    : 'Test the rule to unlock Save.';
  const box = document.getElementById('sr-testbox');
  if (lastTest && lastTest.signature !== signatureOf(form)) box.classList.add('sr-stale'); else box.classList.remove('sr-stale');
}

function srShowFieldProblems() {
  for (const el of document.querySelectorAll('#sec-drawer-panel [data-error]')) el.textContent = '';
  for (const p of formProblems(_srEditor.form)) {
    const el = document.querySelector(`#sec-drawer-panel [data-error="${p.field}"]`);
    if (el && !el.textContent) el.textContent = p.message;
  }
}

async function testSecurityRule() {
  const { form } = _srEditor;
  const problems = formProblems(form);
  srShowFieldProblems();
  if (problems.length) return;
  const box = document.getElementById('sr-testbox');
  box.className = 'sr-testbox';
  box.innerHTML = '<div class="sr-hint">Running the rule through the analyzer…</div>';
  try {
    const report = await srFetch('/rules/test', srJson('POST', formToRule(form)));
    _srEditor.lastTest = { ok: report.ok, signature: signatureOf(form), report };
    const text = explainTestReport(report);
    box.className = `sr-testbox ${report.ok ? 'sr-pass' : 'sr-fail'}`;
    box.innerHTML = `<strong>${text.title}</strong><ul>${text.lines.map(l => `<li>${secEscape(l)}</li>`).join('')}</ul>`;
    box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });      // the result is the point of pressing the button
  } catch (e) {
    _srEditor.lastTest = null;
    box.className = 'sr-testbox sr-fail';
    box.innerHTML = `<strong>Could not run the test</strong><ul><li>${secEscape(e.message)}</li></ul>`;
  }
  srRefreshEditorState();
}

async function saveSecurityRule() {
  const { form, lastTest, mode } = _srEditor;
  if (!canSave(form, lastTest)) return;
  const rule = formToRule(form);
  const button = document.getElementById('sr-save');
  button.disabled = true;
  try {
    if (mode === 'new') {
      const activateIn = [...document.querySelectorAll('#sec-drawer-panel [data-activate]:checked')].map(el => el.dataset.activate);
      await srFetch('/rules', srJson('POST', { rule, activateIn }));
    } else {
      await srFetch(`/rules/${encodeURIComponent(rule.id)}`, srJson('PUT', editPatch(rule, _srEditor.original.body)));
    }
    _srEditor = null;
    closeSecurityFinding();
    await Promise.all([loadSecurityRuleList(), loadSecurityProfileEntries()]);
    renderSecurityRules();
    srNotice(`Saved ${rule.id}. It applies from the next scan.`);
  } catch (e) {
    button.disabled = false;
    const box = document.getElementById('sr-testbox');
    box.className = 'sr-testbox sr-fail';
    box.innerHTML = `<strong>Not saved</strong><ul><li>${secEscape(e.message)}</li></ul>`;
  }
}

async function deprecateSecurityRule(id) {
  if (!window.confirm(`Deprecate ${id}? It stops running in every profile. Findings it already produced keep pointing at it.`)) return;
  try {
    await srFetch(`/rules/${encodeURIComponent(id)}`, { method: 'DELETE' });
    closeSecurityFinding();
    await Promise.all([loadSecurityRuleList(), loadSecurityProfileEntries()]);
    renderSecurityRules();
    srNotice(`Deprecated ${id}.`);
  } catch (e) { srNotice(e.message, true); }
}

// ── Events (one delegated handler per container; rule text never reaches script) ─

function srDrawerRuleId() {
  return document.getElementById('sec-drawer-panel').dataset.rule || null;
}

function srWireEvents() {
  document.addEventListener('click', async (event) => {
    const rules = document.getElementById('sec-rules');
    const drawer = document.getElementById('sec-drawer-panel');
    const t = event.target;
    const act = t.closest && t.closest('[data-act]');

    if (rules && rules.contains(t)) {
      if (t.closest('[data-state]')) {
        _srFilter.state = t.closest('[data-state]').dataset.state;
        return renderSecurityRules();
      }
      if (act && act.dataset.act === 'toggle') {
        const id = t.closest('tr').dataset.id;
        return void srSetProfileRule(id, { enabled: act.checked });
      }
      if (act && act.dataset.act === 'dismiss-notice') return document.getElementById('sr-notice').classList.add('hidden');
    if (act && act.dataset.act === 'new-profile') return openProfileForm();
      if (act && act.dataset.act === 'delete-profile') return void deleteSecurityProfile();
      if (act && act.dataset.act === 'assignments') return void openSecurityAssignments();
      if (act && act.dataset.act === 'add-rule') return openSecurityRuleEditor('new');
      if (t.closest('.sr-switch')) return;
      const row = t.closest('tr.sr-row');
      if (row) return void openSecurityRule(row.dataset.id);
    }

    if (drawer && drawer.contains(t) && act) {
      const ruleId = srDrawerRuleId();
      switch (act.dataset.act) {
        case 'close-drawer': _srEditor = null; return closeSecurityFinding();
        case 'drawer-toggle': return void srSetProfileRule(t.closest('[data-rule]').dataset.rule, { enabled: act.checked }).then(() => openSecurityRule(ruleId));
        case 'drawer-reset': return void srResetProfileRule(ruleId).then(() => openSecurityRule(ruleId));
        case 'edit-rule': return void srFetch(`/rules/${encodeURIComponent(ruleId)}`).then(row => openSecurityRuleEditor('edit', row), e => srNotice(e.message, true));
        case 'deprecate-rule': return void deprecateSecurityRule(ruleId);
        case 'create-profile': return void createSecurityProfile();
        case 'test-rule': return void testSecurityRule();
        case 'save-rule': return void saveSecurityRule();
        default: break;
      }
    }
  });

  document.addEventListener('change', (event) => {
    const t = event.target;
    const rules = document.getElementById('sec-rules');
    const drawer = document.getElementById('sec-drawer-panel');
    if (rules && rules.contains(t)) {
      if (t.id === 'sr-profile') {
        _srProfileId = t.value;
        srRemember(SR_PROFILE_KEY, _srProfileId);
        return void loadSecurityProfileEntries().then(renderSecurityRules, e => srNotice(e.message, true));
      }
      if (t.dataset.filter) { _srFilter[t.dataset.filter] = t.value; return renderSecurityRules(); }
      if (t.id === 'sr-f-deprecated') {
        _srFilter.deprecated = t.checked;
        return void loadSecurityRuleList().then(renderSecurityRules, e => srNotice(e.message, true));
      }
    }
    if (drawer && drawer.contains(t)) {
      if (t.dataset.act === 'drawer-severity') {
        return void srSetProfileRule(t.closest('[data-rule]').dataset.rule, { severity: t.value }).then(() => openSecurityRule(srDrawerRuleId()));
      }
      if (t.dataset.act === 'assign') {
        return void assignSecurityProfile(t.closest('[data-repo]').dataset.repo, t.value);
      }
    }
  });

  document.addEventListener('keydown', (event) => {
    const t = event.target;
    // A rule row is a button in all but name: Enter or Space opens it.
    if ((event.key === 'Enter' || event.key === ' ') && t.classList && t.classList.contains('sr-row')) {
      event.preventDefault();
      return void openSecurityRule(t.dataset.id);
    }
    // Escape closes a drawer, but never an editor with work in it: that needs Cancel.
    if (event.key === 'Escape' && !_srEditor) {
      const drawer = document.getElementById('sec-drawer');
      if (drawer && !drawer.classList.contains('hidden') && document.getElementById('sec-drawer-panel').querySelector('.sec-drawer-head')) closeSecurityFinding();
    }
  });

  document.addEventListener('input', (event) => {
    const t = event.target;
    if (t.id === 'sr-search') { _srFilter.search = t.value; renderSecurityRulesRowsOnly(); return; }
    if (_srEditor && t.dataset && t.dataset.form) {
      _srEditor.form[t.dataset.form] = t.value;
      if (t.dataset.form === 'kind') { /* handled in refresh */ }
      srRefreshEditorState();
      const err = document.querySelector(`#sec-drawer-panel [data-error="${t.dataset.form}"]`);
      if (err) err.textContent = '';
    }
  });

  // Typing in the search box re-renders only the rows, so the box keeps focus.
  function renderSecurityRulesRowsOnly() {
    const visible = srVisibleRules();
    const rows = document.getElementById('sr-rows');
    if (rows) rows.innerHTML = visible.length ? visible.map(srRow).join('') : '<tr><td colspan="6" class="sec-empty">No rules match.</td></tr>';
  }

  // A select's change event is also how the "How it matches" choice arrives.
  document.addEventListener('change', (event) => {
    const t = event.target;
    if (_srEditor && t.dataset && t.dataset.form) {
      _srEditor.form[t.dataset.form] = t.value;
      srRefreshEditorState();
    }
  });
}

if (typeof document !== 'undefined') srWireEvents();

// Exported for tests only: the browser loads this as a plain script, where `module`
// is undefined.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ruleMatches, facetCounts, sortRules, severityRank, profileStateLabel, profileOrder,
    formToRule, ruleToForm, emptyForm, formProblems, signatureOf, canSave, explainTestReport, ruleDetailModel, editPatch,
  };
}
