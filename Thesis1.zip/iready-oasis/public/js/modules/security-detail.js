// =============================================================================
// Security — the finding detail drawer
// =============================================================================
// Where a reader finds out what is actually wrong: the code around the finding,
// why it matters, a worked example of the bug and its fix, and the risk
// breakdown. Split out because it is the largest single thing in the tab and
// changes for entirely different reasons than the table does.

function openSecurityFinding(id) {
  const f = _secFindings.find(x => x.id === id) || (_secDashboard?.topRisks || []).find(x => x.id === id);
  if (!f) return;

  const factorRow = fa => `<tr class="${fa.known ? '' : 'sec-factor-unknown'}">
      <td>${secEscape(fa.label)}</td>
      <td>${secEscape(fa.value)}</td>
      <td class="sec-factor-points">${fa.known ? `+${fa.points}` : '—'}<small>/${fa.max}</small></td>
    </tr>`;

  const risk = f.risk || { score: 0, priority: 'P4', factors: [], confidence: 0, unknownFactors: [] };

  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head">
      <div>
        <div class="sec-drawer-title">${secEscape(f.title)}</div>
        <div class="sec-drawer-sub">
          <span class="sec-sev sec-sev-${secEscape(f.severity)}">${secEscape(f.severity)}</span>
          ${secEscape(f.type)} · ${secEscape(f.repository)}
          ${f.cve ? ` · ${secEscape(f.cve)}` : ''}${f.cwe ? ` · ${secEscape(f.cwe)}` : ''}
          ${secKevBadge(f)}
        </div>
      </div>
      <button class="btn btn-ghost btn-sm" onclick="closeSecurityFinding()">Close</button>
    </div>

    <div class="sec-drawer-risk sec-prio-${secEscape(risk.priority)}">
      <div class="sec-drawer-score">${risk.score}<small>/100</small></div>
      <div>
        <div class="sec-drawer-prio">${secEscape(risk.priority)}</div>
        <div class="sec-hint">${risk.confidence}% of risk factors known</div>
      </div>
    </div>

    <table class="sec-factors">
      <tbody>${risk.factors.map(factorRow).join('')}</tbody>
    </table>
    ${
      risk.unknownFactors.length
        ? `<div class="sec-note">Unknown factors score nothing rather than being guessed.
             ${risk.unknownFactors.includes('reachability') ? 'Reachability analysis is not implemented, so no finding claims to be reachable or unreachable.' : ''}
             ${risk.unknownFactors.some(k => ['exposure', 'environment', 'assetCriticality', 'dataSensitivity'].includes(k)) ? 'Set this repository\'s criticality below to raise confidence.' : ''}
           </div>`
        : ''
    }

    ${f.file ? `
      <div class="sec-drawer-section">
        <h4>Where it is</h4>
        <code class="sec-loc-path">${secEscape(f.file)}${f.startLine ? `:${f.startLine}` : ''}</code>
        <!-- Filled in by loadSecuritySource. The panel renders immediately and
             the code arrives a moment later: reading the file is I/O, and
             blocking the whole drawer on it would make every finding feel slow
             for the sake of one section. -->
        <div class="sec-code" id="sec-code-frame"><div class="sec-code-loading">Loading source…</div></div>
      </div>` : ''}

    ${f.description ? `<div class="sec-drawer-section"><h4>Why it matters</h4><p>${secEscape(f.description)}</p></div>` : ''}

    <!-- The worked example, if the rule carries one. Placed between "why" and
         "how to fix" because that is the order the question gets asked in. -->
    <div id="sec-example-slot"></div>

    ${f.remediation ? `<div class="sec-drawer-section"><h4>How to fix it</h4><p>${secEscape(f.remediation)}</p></div>` : ''}
    ${f.evidence ? `<div class="sec-drawer-section"><h4>Evidence</h4><pre>${secEscape(f.evidence)}</pre></div>` : ''}

    <div class="sec-drawer-section">
      <h4>Detected by</h4>
      ${f.detections.map(d => `<span class="sec-source">${secEscape(d.source)}${d.ruleId ? ` · ${secEscape(d.ruleId)}` : ''}</span>`).join(' ')}
    </div>

    <div class="sec-drawer-section">
      <h4>Repository context</h4>
      <div class="sec-asset-form">
        <select id="sec-asset-criticality">
          <option value="">Criticality…</option>
          ${['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(v => `<option value="${v}">${v}</option>`).join('')}
        </select>
        <select id="sec-asset-environment">
          <option value="">Environment…</option>
          ${['production', 'staging', 'development'].map(v => `<option value="${v}">${v}</option>`).join('')}
        </select>
        <label><input type="checkbox" id="sec-asset-internet"> Internet facing</label>
        <label><input type="checkbox" id="sec-asset-data"> Handles sensitive data</label>
        <button class="btn btn-ghost btn-sm" onclick="saveSecurityAsset('${secEscape(f.repository)}')">Save &amp; rescore</button>
      </div>
    </div>

    <div class="sec-drawer-actions">
      <input id="sec-suppress-reason" class="search-input" placeholder="Reason (required to suppress)…"/>
      <button class="btn btn-ghost btn-sm" onclick="suppressSecurityFinding('${secEscape(f.id)}', false)">Accept risk</button>
      <button class="btn btn-ghost btn-sm" onclick="suppressSecurityFinding('${secEscape(f.id)}', true)">False positive</button>
    </div>
    <div class="lic-error" id="sec-drawer-error"></div>`;

  document.getElementById('sec-drawer').classList.remove('hidden');
  loadSecuritySource(f);
}

/**
 * Fetches the code around a finding and the rule's worked example.
 *
 * Deliberately after the drawer is already on screen. Both come from one
 * request, because a reader needs them together and two round trips would draw
 * the panel in two visible stages.
 */
async function loadSecuritySource(finding) {
  const frame = document.getElementById('sec-code-frame');
  const slot = document.getElementById('sec-example-slot');

  let data;
  try {
    data = await secFetch(`/findings/${encodeURIComponent(finding.id)}/source`);
  } catch (e) {
    if (frame) frame.innerHTML = `<div class="sec-code-error">${secEscape(e.message)}</div>`;
    return;
  }

  if (frame) frame.innerHTML = renderCodeFrame(data.source);
  if (slot) slot.innerHTML = renderExample(data.example);
}

// The code around the finding, with the offending line marked.
//
// A path and a line number make a reader go and open the file; the lines
// themselves let them judge it here, which is the difference between triaging a
// queue and working through one.
function renderCodeFrame(source) {
  if (!source || source.error) {
    // Why the code is missing, not just that it is. "The repository is not
    // cloned locally" and "the file no longer exists" call for different
    // actions.
    return `<div class="sec-code-error">${secEscape((source && source.error) || 'no source available')}</div>`;
  }

  const width = String(source.endLine).length;

  return `<pre class="sec-code-pre">${source.lines
    .map(l => `<div class="sec-code-line ${l.isFinding ? 'sec-code-hit' : ''}">`
      + `<span class="sec-code-num">${String(l.number).padStart(width, ' ')}</span>`
      + `<span class="sec-code-text">${secEscape(l.text)}</span></div>`)
    .join('')}</pre>`
    + (source.redacted
      // Said plainly, so nobody concludes the scanner mangled their file.
      ? '<div class="sec-code-note">The flagged line is redacted — it contains the credential.</div>'
      : '');
}

// The rule's worked example: the bug, and the same code fixed.
//
// These two strings are the SAME ones the rule corpus proves detect and stay
// silent, so an example shown here cannot drift out of date without the build
// failing. That is the whole reason they live on the rule rather than in a
// documentation page nobody runs.
function renderExample(example) {
  if (!example || !example.vulnerable || !example.fixed) {
    // Ingested rules arrive from upstream without hand-written examples.
    // Showing nothing beats inventing one nobody verified.
    return example && example.provenance
      ? `<div class="sec-drawer-section sec-example-none">
           This rule comes from ${secEscape(example.provenance.sourceName || example.provenance.source)}
           (${secEscape(example.provenance.upstreamId || '')}). See the upstream project for examples.
         </div>`
      : '';
  }

  return `<div class="sec-drawer-section">
    <h4>Example</h4>
    <div class="sec-example">
      <div class="sec-example-side sec-example-bad">
        <div class="sec-example-label">Vulnerable</div>
        <pre>${secEscape(example.vulnerable)}</pre>
      </div>
      <div class="sec-example-side sec-example-good">
        <div class="sec-example-label">Fixed</div>
        <pre>${secEscape(example.fixed)}</pre>
      </div>
    </div>
    <div class="sec-example-note">
      Both samples are executed by the rule's test suite on every build — the
      first must be detected, the second must not.
    </div>
  </div>`;
}

function closeSecurityFinding() {
  document.getElementById('sec-drawer').classList.add('hidden');
}

// The detail view for a grouped row: every advisory, each one still its own
// finding. Opening an individual CVE from here is what keeps suppression and
// triage per-CVE — the grouping never took that away, it only stopped the table
// showing fifty-five rows with the same answer.
function openSecurityGroup(id) {
  const group = _secGroups.get(id);
  if (!group) return;

  const g = summariseGroup(group);
  const ordered = [...group.findings].sort(
    (a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity)
  );

  const counts = SEVERITY_ORDER
    .map(sev => ({ sev, n: group.findings.filter(f => f.severity === sev).length }))
    .filter(x => x.n);

  document.getElementById('sec-drawer-panel').innerHTML = `
    <div class="sec-drawer-head">
      <div>
        <div class="sec-drawer-title">${secEscape(g.packageName)}${g.version ? ` ${secEscape(g.version)}` : ''}</div>
        <div class="sec-drawer-sub">
          ${counts.map(c => `<span class="sec-sev sec-sev-${c.sev}">${c.n} ${c.sev}</span>`).join(' ')}
          · ${secEscape(g.repository)}${g.transitive ? ' · transitive' : ''}
        </div>
      </div>
      <button class="sec-drawer-close" onclick="closeSecurityFinding()">✕</button>
    </div>

    <div class="sec-drawer-section">
      <h4>What to do</h4>
      <p class="sec-drawer-text">
        ${g.transitive
          ? `All ${g.count} advisories are fixed by updating whatever pulls in ${secEscape(g.packageName)}, or by pinning an override.`
          : `All ${g.count} advisories are fixed by upgrading ${secEscape(g.packageName)} past the affected range.`}
        Declared in <code>${secEscape(g.file || '')}</code>.
      </p>
    </div>

    <div class="sec-drawer-section">
      <h4>${g.count} advisories</h4>
      <div class="sec-group-list">
        ${ordered.map(f => `
          <button class="sec-group-item" onclick="openSecurityFinding('${secEscape(f.id)}')">
            <span class="sec-sev sec-sev-${secEscape(f.severity)}">${secEscape(f.severity)}</span>
            <span class="sec-group-item-id">${secEscape(f.cve || f.detections[0]?.ruleId || f.title)}</span>
            <span class="sec-group-item-summary">${secEscape((f.description || '').slice(0, 120))}</span>
            ${f.status !== 'OPEN' ? `<span class="sec-status-tag">${secEscape(f.status)}</span>` : ''}
            ${secKevBadge(f)}
          </button>`).join('')}
      </div>
    </div>`;

  document.getElementById('sec-drawer').classList.remove('hidden');
}

async function saveSecurityAsset(repository) {
  const body = {
    criticality: document.getElementById('sec-asset-criticality').value || undefined,
    environment: document.getElementById('sec-asset-environment').value || undefined,
    internetFacing: document.getElementById('sec-asset-internet').checked,
    sensitiveData: document.getElementById('sec-asset-data').checked,
  };
  try {
    await secFetch(`/assets/${encodeURIComponent(repository)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    // Saving context rescores every finding in the repository server-side, so
    // the whole view is refreshed rather than just this one row.
    closeSecurityFinding();
    await refreshSecurity();
  } catch (e) {
    document.getElementById('sec-drawer-error').textContent = e.message;
  }
}

async function suppressSecurityFinding(id, falsePositive) {
  const reason = document.getElementById('sec-suppress-reason').value.trim();
  if (!reason) {
    document.getElementById('sec-drawer-error').textContent =
      'A reason is required — suppression is a decision with an owner, not a way to hide a row.';
    return;
  }
  try {
    await secFetch(`/findings/${encodeURIComponent(id)}/suppress`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason, falsePositive, owner: cfg?.githubLogin || null }),
    });
    closeSecurityFinding();
    await refreshSecurity();
  } catch (e) {
    document.getElementById('sec-drawer-error').textContent = e.message;
  }
}
