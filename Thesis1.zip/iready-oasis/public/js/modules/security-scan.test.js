'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { summariseScan, formatScanDuration, formatFileCount, shortenPath } = require('./security-scan');

// What the scan panel is allowed to claim.
//
// While a scan runs, the panel is the only thing standing between a reader and
// force-quitting the app: a repository takes minutes, and a screen that shows a
// name and an unmoving bar looks exactly like a scan that has hung. These tests
// are about it reporting what is actually happening — the repository, the file,
// how many files are done — and about the bar never overstating it.

const running = extra => ({
  id: 'SCAN-1',
  status: 'RUNNING',
  repositories: ['repo-a', 'repo-b'],
  perRepository: [],
  progress: {
    total: 2,
    completed: 0,
    current: 'repo-a',
    running: ['repo-a'],
    active: [],
    filesScanned: 0,
    ...extra,
  },
});

test('reports the repository, the file, and the count for each repository in flight', () => {
  const s = summariseScan(running({
    active: [
      { repository: 'repo-a', stage: 'Scanning files', file: 'src/main/java/Foo.java', filesScanned: 120, filesTotal: 480 },
      { repository: 'repo-b', stage: 'Maven SCA + licences', file: null, filesScanned: 300, filesTotal: 300 },
    ],
    filesScanned: 420,
  }));

  assert.equal(s.active.length, 2);
  assert.equal(s.active[0].repository, 'repo-a');
  assert.equal(s.active[0].file, 'src/main/java/Foo.java');
  assert.equal(s.active[0].filesScanned, 120);
  assert.equal(s.active[0].filesTotal, 480);
  // The stage is what explains a counter that has stopped moving: nothing is
  // wrong, the file pass is over and dependency resolution is running.
  assert.equal(s.active[1].stage, 'Maven SCA + licences');
  assert.equal(s.filesScanned, 420, 'the run total, across every repository');
});

test('the bar advances inside a repository, not only between them', () => {
  // The single-repository scan is the common case, and repository-level progress
  // there is 0% for the whole run and then 100%. That is the bar this fixes.
  const idle = summariseScan(running({ active: [], completed: 0 }));
  const halfway = summariseScan(running({
    completed: 0,
    active: [{ repository: 'repo-a', stage: 'Scanning files', file: 'a.js', filesScanned: 240, filesTotal: 480 }],
  }));

  assert.equal(idle.percent, 0);
  assert.ok(halfway.percent > 0, 'a repository half-scanned must show something');
  assert.ok(halfway.percent < 100);
});

test('a repository still working never fills the bar', () => {
  // A file pass that finished is not a repository that finished: Maven
  // resolution and the git-history scanner run after it. A bar at 100% with the
  // scan still going is the same broken promise as a bar at 0%.
  const s = summariseScan(running({
    completed: 1,
    active: [{ repository: 'repo-b', stage: 'Maven SCA + licences', file: null, filesScanned: 480, filesTotal: 480 }],
  }));

  assert.ok(s.percent < 100, `bar reached ${s.percent}% while a repository was still being scanned`);
  assert.ok(s.percent >= 50, 'one of two repositories is genuinely done');
});

test('a finished scan is complete, whatever the last report said', () => {
  const s = summariseScan({
    status: 'COMPLETED',
    repositories: ['repo-a'],
    perRepository: [],
    counts: { HIGH: 2 },
    startedAt: 1000,
    finishedAt: 4000,
    progress: { total: 1, completed: 1, current: null, running: [], active: [], filesScanned: 480 },
  });

  assert.equal(s.done, true);
  assert.equal(s.percent, 100);
  assert.equal(s.active.length, 0, 'nothing is in flight once it is over');
  // Kept after the run: "how much was actually looked at" is a fact about the
  // scan, not a live counter.
  assert.equal(s.filesScanned, 480);
});

test('a scan record from before file progress existed still renders', () => {
  // Scan history is capped but long-lived, and the stored records were written
  // by an older version. A missing field must not throw in the panel.
  const s = summariseScan({ status: 'RUNNING', repositories: ['repo-a'], progress: { total: 1, completed: 0 } });

  assert.deepEqual(s.active, []);
  assert.equal(s.filesScanned, 0);
  assert.equal(typeof s.percent, 'number');
});

test('file counts are grouped so five figures can be read at a glance', () => {
  assert.equal(formatFileCount(0), '0');
  assert.equal(formatFileCount(940), '940');
  assert.equal(formatFileCount(12480), '12,480');
});

test('a long path keeps the end, which is the part that identifies the file', () => {
  const deep = 'src/main/java/com/cainc/activitycomponent/service/handler/ActivityHandler.java';
  const short = shortenPath(deep);

  assert.ok(short.length <= 56, `still ${short.length} characters long`);
  assert.match(short, /ActivityHandler\.java$/);
  assert.equal(shortenPath('pom.xml'), 'pom.xml', 'a short path is left alone');
});

test('durations are reported in the unit a reader thinks in', () => {
  assert.equal(formatScanDuration(400), '400ms');
  assert.equal(formatScanDuration(4200), '4.2s');
  assert.equal(formatScanDuration(125000), '2m 5s');
  assert.equal(formatScanDuration(0), null);
});