// =============================================================================
// Security — running a scan and reporting the result
// =============================================================================
// Everything between pressing Scan and having a result on screen: the poll
// loop, the progress panel, and the result card with its coverage report.
//
// These files are classic scripts, so in the browser the helpers below are
// already globals from the sibling modules. Under Node — where the tests import
// this file directly — each file is its own module scope and they are not.
// Resolved through accessors rather than a top-level `var`, because a `var` of
// the same name as another script's `const` is a SyntaxError in the shared
// global scope, and a duplicated constant is a constant that eventually
// disagrees with itself.
function _severityOrder() {
  // eslint-disable-next-line no-undef
  if (typeof SEVERITY_ORDER !== 'undefined') return SEVERITY_ORDER;
  return require('./security-scope').SEVERITY_ORDER;
}
function _scopeFindings(findings, filter, opts) {
  // eslint-disable-next-line no-undef
  if (typeof scopeFindings !== 'undefined') return scopeFindings(findings, filter, opts);
  return require('./security-scope').scopeFindings(findings, filter, opts);
}
function _countBy(findings, key) {
  // eslint-disable-next-line no-undef
  if (typeof countBy !== 'undefined') return countBy(findings, key);
  return require('./security-scope').countBy(findings, key);
}
function _mergeCoverage(perRepository) {
  // eslint-disable-next-line no-undef
  if (typeof mergeCoverage !== 'undefined') return mergeCoverage(perRepository);
  return require('./security').mergeCoverage(perRepository);
}

/**
 * Everything the result card states, derived from the scan record and — when
 * they are loaded — from the findings the rest of the page is showing.
 *
 * The second argument is the whole point. `scan.counts` is what the scan
 * PRODUCED: every finding in the repositories it covered, before triage. The
 * dashboard and the table show what is OPEN across the loaded set. Those are
 * different questions, and answering them with two unlabelled numbers on one
 * screen — "42 findings" over a table of 695 — reads as a bug in the tool. The
 * card now leads with the same number the table does, for the repositories the
 * scan actually covered, and states the difference instead of hiding it.
 *
 * Pure, and separate from the rendering, because these are the claims the panel
 * makes about a scan and claims are worth testing without a browser.
 */
function summariseScan(scan, findings = null) {
  const scanCounts = (scan && scan.counts) || {};
  const status = (scan && scan.status) || 'QUEUED';
  const progress = (scan && scan.progress) || {};
  const repositories = ((scan && scan.repositories) || []).filter(Boolean);

  const produced = _severityOrder().reduce((n, s) => n + (scanCounts[s] || 0), 0);
  const coverage = _mergeCoverage((scan && scan.perRepository) || []);

  // The open findings in the repositories this scan covered — the same set the
  // table shows once the dashboard scopes itself to those repositories.
  let open = null;
  if (Array.isArray(findings)) {
    const inScope = _scopeFindings(findings, { repositories });
    open = { counts: _countBy(inScope, 'severity'), total: inScope.length };
  }

  const counts = open ? open.counts : scanCounts;
  const total = open ? open.total : produced;

  // ── How far along, and inside what ──────────────────────────────────────
  //
  // Repository-level progress is 0% and then 100% for the single-repository
  // scan, which is the common case: minutes of work reported as nothing
  // happening. The file pass inside the repository being scanned is what fills
  // the gap, so it is folded into the same bar.
  //
  // A repository in flight is capped BELOW a full repository, deliberately. Its
  // file pass finishing does not mean the repository is finished — Maven
  // resolution and the git-history scan run after it — and a bar sitting at 100%
  // while the scan is still going is the same broken promise as one sitting at 0%.
  const done = ['COMPLETED', 'FAILED', 'CANCELLED'].includes(status);
  const active = (Array.isArray(progress.active) ? progress.active : []).map(a => ({
    repository: a.repository || null,
    stage: a.stage || null,
    file: a.file || null,
    filesScanned: a.filesScanned || 0,
    filesTotal: a.filesTotal || 0,
    fraction: a.filesTotal ? Math.min(1, a.filesScanned / a.filesTotal) : 0,
  }));
  const repositoryCount = progress.total || repositories.length;
  const inFlight = active.reduce((sum, a) => sum + Math.min(0.9, a.fraction), 0);
  const percent = done
    ? 100
    : repositoryCount
      ? Math.min(99, Math.round(((progress.completed || 0) + inFlight) / repositoryCount * 100))
      : 0;

  // Where the two numbers diverge, and why. Positive: the scan found things
  // that are suppressed or were already resolved. Negative: findings from an
  // earlier scan are still open in these repositories because this run did not
  // cover their type.
  const difference = open ? produced - open.total : 0;

  return {
    status,
    done,
    failed: status === 'FAILED',
    total,
    counts,
    produced,
    difference,
    // Whether `total` is the open set or the scan's own tally, so the label can
    // say which without the reader having to infer it.
    countsAreOpen: Boolean(open),
    // The worst thing found, which is the one fact that decides whether anyone
    // needs to act today.
    worst: _severityOrder().find(s => counts[s]) || null,
    repositories,
    repositoryCount,
    completed: progress.completed || 0,
    current: progress.current || null,
    // What each repository in flight is doing, and how much has been looked at
    // across the whole run.
    active,
    percent,
    filesScanned: progress.filesScanned || 0,
    durationMs: scan && scan.finishedAt && scan.startedAt ? scan.finishedAt - scan.startedAt : null,
    ignored: (scan && scan.ignored) || 0,
    coverage,
    gaps: coverage.filter(c => !c.analysed),
    limited: coverage.filter(c => c.analysed && c.truncated),
    partial: Boolean(scan && scan.partial),
  };
}

// Keeps the END of a path. `src/main/java/com/cainc/activity/.../Handler.java`
// is a deep tree, and the file name is the part that identifies it — truncating
// the tail would leave every row reading "src/main/java/com/…".
function shortenPath(relPath, max = 56) {
  const value = String(relPath || '');
  return value.length <= max ? value : `…${value.slice(-(max - 1))}`;
}

// Thousands separated, because "12480 files" and "1248 files" are the same
// shape at a glance and the reader is watching this number move.
function formatFileCount(n) {
  return String(n || 0).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function formatScanDuration(ms) {
  if (!ms || ms < 0) return null;
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  const minutes = Math.floor(ms / 60000);
  return `${minutes}m ${Math.round((ms % 60000) / 1000)}s`;
}

function toggleSecurityScanDetail() {
  _secScanExpanded = !_secScanExpanded;
  if (_secLastScanRecord) renderSecurityScanSummary(_secLastScanRecord);
}

function renderSecurityScanSummary(scan) {
  const box = document.getElementById('sec-scan-progress');
  if (!box) return;
  _secLastScanRecord = scan;

  // Counted against the findings the rest of the page is showing, so the card,
  // the tiles and the table cannot disagree.
  const s = summariseScan(scan, _secFindings.length ? _secFindings : null);
  const scanners = scan.scanners || [];
  const expanded = _secScanExpanded || !s.done;

  // The headline answers "what happened" in one line: outcome, how much, how
  // bad, over what, how long. Previously the first line was the raw status word
  // and a repository count, and the actual result — the number of findings and
  // the worst severity — was somewhere further down among the bars.
  const facts = [
    `${s.total} ${s.countsAreOpen ? 'open ' : ''}finding${s.total === 1 ? '' : 's'}`,
    s.worst ? `worst ${s.worst}` : null,
    s.repositoryCount ? `${s.repositoryCount} repositor${s.repositoryCount === 1 ? 'y' : 'ies'}` : null,
    formatScanDuration(s.durationMs),
    // How much was actually looked at. A clean result over 40 files and a clean
    // result over 4,000 are different claims.
    s.filesScanned ? `${formatFileCount(s.filesScanned)} files` : null,
    s.ignored ? `${s.ignored} ignored by rules` : null,
  ].filter(Boolean);

  // The gap between what the scan produced and what is open, said out loud.
  // Two different numbers on one screen with no explanation is the thing this
  // panel was reported for.
  const reconciliation =
    s.countsAreOpen && s.difference !== 0
      ? `<div class="sec-scan-reconcile">${
          s.difference > 0
            ? `${s.difference} more ${s.difference === 1 ? 'was' : 'were'} found and ${s.difference === 1 ? 'is' : 'are'} already suppressed or resolved.`
            : `${-s.difference} open ${-s.difference === 1 ? 'finding' : 'findings'} here ${-s.difference === 1 ? 'comes' : 'come'} from an earlier scan — this run did not cover ${-s.difference === 1 ? 'its' : 'their'} type.`
        }</div>`
      : '';

  const running = !s.done;

  const headline = running
    ? `<span class="sec-scan-pill sec-scan-pill-running">Scanning</span>
       <strong>${s.completed} of ${s.repositoryCount} repositor${s.repositoryCount === 1 ? 'y' : 'ies'}</strong>
       <span class="sec-scan-current">${s.filesScanned ? `${formatFileCount(s.filesScanned)} files scanned` : 'starting…'}</span>`
    : `<span class="sec-scan-pill ${s.failed ? 'sec-scan-pill-failed' : 'sec-scan-pill-done'}">
         ${s.failed ? 'Scan failed' : 'Scan complete'}
       </span>
       <strong>${secEscape(facts.join(' · '))}</strong>`;

  // Per repository in flight: which one, what it is doing, the file it is on,
  // and how far through that repository's tree it is. This is what tells someone
  // whether a scan is working or stuck — and on which file, when it is stuck.
  const activity = running && s.active.length
    ? `<div class="sec-scan-activity">${s.active
        .map(a => {
          const bar = a.filesTotal
            ? `<div class="sec-scan-bar sec-scan-bar-thin">
                 <span class="sec-scan-bar-fill" style="width:${Math.round(a.fraction * 100)}%"></span>
               </div>`
            : '';
          const count = a.filesTotal
            ? `${formatFileCount(a.filesScanned)} / ${formatFileCount(a.filesTotal)} files`
            : a.filesScanned
              ? `${formatFileCount(a.filesScanned)} files`
              : '';
          return `<div class="sec-scan-act">
              <div class="sec-scan-act-head">
                <span class="sec-scan-act-repo">${secEscape(a.repository || '')}</span>
                ${a.stage ? `<span class="sec-scan-act-stage">${secEscape(a.stage)}</span>` : ''}
                ${count ? `<span class="sec-scan-act-count">${count}</span>` : ''}
              </div>
              ${a.file ? `<div class="sec-scan-act-file" title="${secEscape(a.file)}">${secEscape(shortenPath(a.file))}</div>` : ''}
              ${bar}
            </div>`;
        })
        .join('')}</div>`
    : '';

  // What was FOUND: bars, because the numbers span two orders of magnitude
  // (217 against 5) and a column of digits makes the reader do the comparing
  // that a length does for free.
  const found = scanners
    .filter(x => x.findings > 0)
    .sort((a, b) => b.findings - a.findings)
    .map(x => ({ key: x.type, label: x.name, value: x.findings }));

  // What did NOT run, and whether that matters. An optional scanner whose
  // capability another scanner already covered is not a hole, and listing it
  // beside real gaps under one marker is what made every scan look compromised.
  const absent = scanners.filter(x => x.skipped > 0 || x.failed > 0);
  const redundant = absent.filter(x => !x.gaps && !x.failed);
  const gapScanners = absent.filter(x => x.gaps || x.failed);

  const section = (title, body) =>
    body ? `<div class="sec-scan-section"><h4 class="sec-scan-h">${secEscape(title)}</h4>${body}</div>` : '';

  // Severity of what this scan found, as a proportional strip. One glance
  // answers "is any of this urgent" without reading five numbers.
  const severityStrip = s.total
    ? `<div class="sec-scan-strip">${_severityOrder().filter(k => s.counts[k])
        .map(
          k => `<button class="sec-scan-strip-seg sec-scan-strip-${k}"
                   style="flex:${s.counts[k]}"
                   onclick="drillSecurity_severity('${k}')"
                   title="${s.counts[k]} ${k} — click to filter the findings below">
                   <span>${s.counts[k]}</span><small>${k}</small>
                 </button>`
        )
        .join('')}</div>`
    : '';

  // Per repository, so a sweep says WHERE. Across twelve repositories a single
  // total is not actionable — the reader's next question is always "which one".
  // Per-repository counts come from the same open set as the headline where it
  // exists. Taking them from the scan record instead would make the rows add up
  // to a different number than the line above them.
  const openInRepo = repository => {
    if (!s.countsAreOpen) return null;
    const rows = _scopeFindings(_secFindings, { repositories: [repository] });
    return { total: rows.length, counts: _countBy(rows, 'severity') };
  };

  const perRepo = (scan.perRepository || []).length > 1
    ? `<div class="sec-scan-repos">${(scan.perRepository || [])
        .map(r => {
          const live = openInRepo(r.repository);
          const counts = live ? live.counts : (r.counts || {});
          const worst = _severityOrder().find(k => counts[k]);
          const n = live ? live.total : _severityOrder().reduce((sum, k) => sum + (counts[k] || 0), 0);
          return `<button class="sec-scan-repo" onclick="drillSecurity_repository('${secEscape(r.repository)}')"
                    title="Show findings in ${secEscape(r.repository)}">
              <span class="sec-scan-repo-name">${secEscape(r.repository)}</span>
              ${worst ? `<span class="sec-sev sec-sev-${worst}">${worst}</span>` : '<span class="sec-scan-repo-clean">clean</span>'}
              <span class="sec-scan-repo-count">${n}</span>
              ${r.partial ? '<span class="sec-scan-repo-partial" title="Coverage was partial here">partial</span>' : ''}
            </button>`;
        })
        .join('')}</div>`
    : '';

  // Why coverage is partial, in the words of what actually happened. The old
  // text said to look for things "marked not analysed" — and when the cause was
  // a truncation limit there was nothing so marked anywhere on screen, leaving
  // the reader hunting for a mark that did not exist.
  const why = [];
  if (s.gaps.length) {
    why.push(`${s.gaps.map(c => c.type).join(', ')} ${s.gaps.length === 1 ? 'was' : 'were'} not checked at all`);
  }
  if (s.limited.length) {
    why.push(`${s.limited.map(c => c.type).join(', ')} hit a size limit, so ${s.limited.length === 1 ? 'it is' : 'they are'} incomplete`);
  }

  const warnings =
    (gapScanners.length
      ? `<div class="sec-progress-warn">Left a gap: ${gapScanners.map(x => secEscape(x.name)).join(' · ')}.</div>`
      : '') +
    (s.partial && why.length
      ? `<div class="sec-progress-warn">Coverage is partial — ${secEscape(why.join('; '))}. Nothing there has been cleared.</div>`
      : '');

  box.innerHTML =
    `<div class="sec-scan-headline">
       <div class="sec-scan-headline-main">${headline}</div>
       <div class="sec-scan-actions">
         ${s.done
           ? `<button class="sec-link" onclick="toggleSecurityScanDetail()">${expanded ? 'Hide details' : 'Details'}</button>
              <button class="sec-link" onclick="dismissSecurityScanSummary()">Dismiss</button>`
           : ''}
       </div>
     </div>` +
    (running
      ? `<div class="sec-scan-bar"><span class="sec-scan-bar-fill" style="width:${s.percent}%"></span></div>` + activity
      : severityStrip + reconciliation) +
    // Warnings sit outside the collapsible region on purpose. A coverage gap
    // must not be hidden behind a "Details" click.
    warnings +
    (expanded
      ? `<div class="sec-scan-detail">` +
        section('Findings by scanner',
          found.length
            ? secBarChart(found, { onClick: 'drillSecurity_type', unit: 'findings' })
            : (s.done ? '<div class="chart-empty">Nothing found — see what was checked below for what that covers.</div>' : '')) +
        section('By repository', perRepo) +
        section('What was checked', coverageStrip(s.coverage)) +
        (redundant.length
          ? `<div class="sec-scan-note">Not run: ${redundant.map(x => secEscape(x.name)).join(' · ')}
               — optional tools whose checks another scanner already performed.</div>`
          : '') +
        '</div>'
      : '');

  box.classList.remove('hidden');
}

function dismissSecurityScanSummary() {
  document.getElementById('sec-scan-progress')?.classList.add('hidden');
}

// Re-opens the last scan's coverage report from the stored record, so it
// survives a dismiss, a tab switch, and a page reload.
async function showLastSecurityScan() {
  const id = _secLastScanId || (_secDashboard && _secDashboard.lastScan && _secDashboard.lastScan.id);
  if (!id) return;
  try {
    const scan = await secFetch(`/scans/${encodeURIComponent(id)}`);
    // Asked for explicitly, so open it — the coverage report is what someone
    // reopening a finished scan came back for.
    _secScanExpanded = true;
    renderSecurityScanSummary(scan);
    document.getElementById('sec-scan-progress').classList.remove('hidden');
  } catch (e) {
    /* the record has aged out of the capped history */
  }
}

async function startSecurityScan() {
  const btn = document.getElementById('sec-scan-btn');
  const progress = document.getElementById('sec-scan-progress');
  const repositories = [..._secSelected];
  if (!repositories.length) return;

  // Quick scan only checks the scanners that can be scoped to changed files —
  // no dependency or git-history checks, so it needs saying up front rather
  // than surprising someone comparing counts against a Full scan.
  const mode = document.getElementById('sec-scan-mode')?.value === 'quick' ? 'quick' : 'full';

  document.getElementById('sec-repo-panel')?.classList.add('hidden');
  btn.disabled = true;
  // Open while it runs — progress is the whole point of the panel then — and
  // collapsed again the moment it finishes.
  _secScanExpanded = true;
  progress.classList.remove('hidden');
  const modeLabel = mode === 'quick' ? 'Quick scan (this branch\'s unpushed changes only) of' : 'Starting scan of';
  progress.textContent = `${modeLabel} ${repositories.length} repositor${repositories.length === 1 ? 'y' : 'ies'}…`;

  try {
    const scan = await secFetch('/scans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repositories, mode }),
    });
    if (scan.unavailable && scan.unavailable.length) {
      // Named, not dropped: a repository that could not be scanned has not come
      // back clean.
      progress.textContent = `Skipping ${scan.unavailable.length} repository(ies) with no local clone: ${scan.unavailable.join(', ')}`;
    }
    pollSecurityScan(scan.id);
  } catch (e) {
    progress.textContent = e.message;
    btn.disabled = false;
  }
}

// Scans run for minutes and the server does the work asynchronously, so the UI
// polls. Every scanner's state is shown while it runs — a scan that looks
// frozen is usually one slow scanner, and saying which one is the difference
// between waiting and force-quitting.
function pollSecurityScan(id) {
  clearInterval(_secScanPoll);
  _secScanPoll = setInterval(async () => {
    try {
      const scan = await secFetch(`/scans/${encodeURIComponent(id)}`);
      renderSecurityScanSummary(scan);

      if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(scan.status)) {
        clearInterval(_secScanPoll);
        document.getElementById('sec-scan-btn').disabled = false;
        // Collapse to the headline now the run is over. Expanded, this panel
        // sits in the fixed chrome and pushes the findings list — the thing the
        // reader just waited for — off the bottom of the window.
        _secScanExpanded = false;

        // Scope the dashboard to what was just scanned. Without this the card
        // reports one repository's scan and the tiles below it report the whole
        // estate, which is the same number problem in a different place.
        _secFilter.repositories = (scan.repositories || []).filter(Boolean);
        _secFilter.severity = null;
        _secFilter.type = null;

        // Refresh FIRST: the card counts against the loaded findings, so it has
        // to run after they are replaced or it reports the pre-scan set.
        await refreshSecurity();
        renderSecurityScanSummary(scan);
        // Deliberately NOT auto-hidden. This panel carries the coverage
        // report — which scanners could not analyse which repository, and why
        // — and that is the part a reader most needs to keep. It used to
        // vanish after eight seconds, taking the only record of partial
        // coverage with it. It now stays until dismissed or the next scan.
        _secLastScanId = scan.id;
      }
    } catch (e) {
      clearInterval(_secScanPoll);
      document.getElementById('sec-scan-btn').disabled = false;
    }
  }, 1500);
}


// Exported for tests only — see the note in security.js. The browser loads this
// as a plain script, where `module` is undefined.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { summariseScan, formatScanDuration, formatFileCount, shortenPath };
}
