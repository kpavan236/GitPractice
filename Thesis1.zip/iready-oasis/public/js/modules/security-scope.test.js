'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scopeFindings, securityScore, countBy, groupFindings, summariseGroup, scaGroupKey } = require('./security-scope');
const { summariseScan, formatScanDuration } = require('./security-scan');
const { mergeCoverage } = require('./security');

// The dashboard's numbers are derived, not fetched, so these are the tests that
// keep it honest. The failure this guards against is subtle and was live: the
// table filtered while the tiles above it kept reporting the whole estate, so
// one screen showed two different answers to "how bad is it" and the reader had
// no way to tell which one was about what they were looking at.

function finding(over = {}) {
  return {
    id: over.id || 'f1',
    type: 'SAST',
    severity: 'HIGH',
    repository: 'api',
    title: 'SQL injection',
    file: 'src/Dao.java',
    category: 'SQL_INJECTION',
    cve: null,
    ...over,
  };
}

const SET = [
  finding({ id: '1', severity: 'CRITICAL', repository: 'api', type: 'SAST' }),
  finding({ id: '2', severity: 'HIGH', repository: 'api', type: 'SCA' }),
  finding({ id: '3', severity: 'MEDIUM', repository: 'web', type: 'SAST' }),
  finding({ id: '4', severity: 'LOW', repository: 'web', type: 'SECRET', title: 'AWS key' }),
  finding({ id: '5', severity: 'MEDIUM', repository: 'infra', type: 'IAC', file: 'main.tf' }),
  finding({ id: '6', severity: 'LOW', repository: 'api', type: 'QUALITY', title: 'unused var' }),
];

test('an empty filter shows every security finding and hides QUALITY', () => {
  // QUALITY is out of scope until asked for by name: hundreds of lint findings
  // would otherwise bury a handful of vulnerabilities.
  const ids = scopeFindings(SET, {}).map(f => f.id);
  assert.deepEqual(ids, ['1', '2', '3', '4', '5']);
});

test('asking for QUALITY by name shows it, and only it', () => {
  assert.deepEqual(scopeFindings(SET, { type: 'QUALITY' }).map(f => f.id), ['6']);
});

test('filters compose', () => {
  assert.deepEqual(scopeFindings(SET, { repositories: ['api'] }).map(f => f.id), ['1', '2']);
  assert.deepEqual(scopeFindings(SET, { repositories: ['api'], severity: 'HIGH' }).map(f => f.id), ['2']);
  assert.deepEqual(scopeFindings(SET, { repositories: ['nope'] }), []);
});

test('search matches title, file, repository and category', () => {
  assert.deepEqual(scopeFindings(SET, { search: 'aws' }).map(f => f.id), ['4']);
  assert.deepEqual(scopeFindings(SET, { search: 'main.tf' }).map(f => f.id), ['5']);
  assert.deepEqual(scopeFindings(SET, { search: 'INFRA' }).map(f => f.id), ['5']);
});

test('`except` lifts one dimension so a facet stays clickable in both directions', () => {
  // The bug this prevents: counting the severity facet WITH the severity filter
  // applied leaves every tile but the selected one reading zero, and the reader
  // is stranded with no way back to the others.
  const filter = { severity: 'CRITICAL', repositories: ['api'] };
  assert.deepEqual(scopeFindings(SET, filter).map(f => f.id), ['1']);

  const facet = scopeFindings(SET, filter, { except: ['severity'] });
  assert.deepEqual(facet.map(f => f.id), ['1', '2']);
  assert.deepEqual(countBy(facet, 'severity'), { CRITICAL: 1, HIGH: 1 });
});

test('lifting the type dimension also lifts the QUALITY exclusion', () => {
  // Otherwise the type facet could never advertise how many quality findings
  // are waiting behind it, and the chip would read zero on a repository full of
  // them.
  const byType = countBy(scopeFindings(SET, {}, { except: ['type'] }), 'type');
  assert.equal(byType.QUALITY, 1);
});

test('the score is computed from whatever is in scope', () => {
  // "This repository scores 41" is a fact someone can act on. An estate-wide
  // average is not, and it was the only number the tile could show before.
  const all = countBy(scopeFindings(SET, {}), 'severity');
  const infra = countBy(scopeFindings(SET, { repositories: ['infra'] }), 'severity');
  assert.ok(securityScore(infra) > securityScore(all), 'one MEDIUM must score better than the whole estate');
});

test('scoping never invents findings', () => {
  for (const filter of [{}, { severity: 'HIGH' }, { repositories: ['web'] }, { type: 'IAC' }, { search: 'x' }]) {
    const scoped = scopeFindings(SET, filter);
    assert.ok(scoped.every(f => SET.includes(f)));
    assert.ok(scoped.length <= SET.length);
  }
});

test('tolerates a missing or malformed set', () => {
  assert.deepEqual(scopeFindings(null, {}), []);
  assert.deepEqual(scopeFindings(undefined, undefined), []);
  assert.deepEqual(scopeFindings([], { severity: 'HIGH' }), []);
});

// ── The scan result card ───────────────────────────────────────────────────

test('summarises a completed scan into what the headline states', () => {
  const summary = summariseScan({
    status: 'COMPLETED',
    counts: { CRITICAL: 2, HIGH: 4, MEDIUM: 5, LOW: 1, INFO: 0 },
    repositories: ['api', 'web', 'infra'],
    progress: { total: 3, completed: 3 },
    startedAt: 1000,
    finishedAt: 9400,
    ignored: 3,
    perRepository: [],
  });

  assert.equal(summary.done, true);
  assert.equal(summary.failed, false);
  assert.equal(summary.total, 12);
  // The one fact that decides whether anyone acts today.
  assert.equal(summary.worst, 'CRITICAL');
  assert.equal(summary.repositoryCount, 3);
  assert.equal(summary.durationMs, 8400);
  assert.equal(summary.ignored, 3);
});

test('a running scan is not done and has no duration', () => {
  const summary = summariseScan({
    status: 'RUNNING',
    progress: { total: 5, completed: 2, current: 'web' },
    startedAt: 1000,
    finishedAt: null,
  });
  assert.equal(summary.done, false);
  assert.equal(summary.completed, 2);
  assert.equal(summary.current, 'web');
  assert.equal(summary.durationMs, null);
});

test('a clean scan reports no worst severity rather than a false one', () => {
  const summary = summariseScan({ status: 'COMPLETED', counts: {}, perRepository: [] });
  assert.equal(summary.total, 0);
  assert.equal(summary.worst, null);
});

test('gaps and truncations are separated', () => {
  // Different problems with different answers: one capability was never
  // checked, the other was checked incompletely. Collapsing them into "partial"
  // loses the only part a reader can act on.
  const summary = summariseScan({
    status: 'COMPLETED',
    counts: { HIGH: 1 },
    partial: true,
    perRepository: [
      {
        repository: 'api',
        coverage: [
          { type: 'SAST', analysed: true, truncated: false, by: ['AST_SAST'] },
          { type: 'SECRET', analysed: true, truncated: true, by: ['SECRETS'], limits: [{ reason: 'hit 20000 files' }] },
          { type: 'DAST', analysed: false, reasons: [{ id: 'SARIF_IMPORT', reason: 'no SARIF files' }] },
        ],
      },
    ],
  });

  assert.deepEqual(summary.gaps.map(c => c.type), ['DAST']);
  assert.deepEqual(summary.limited.map(c => c.type), ['SECRET']);
});

test('coverage merges across repositories, and one gap is a gap', () => {
  // Averaging is how partial coverage reads as clean: a capability counts as
  // covered only if it was covered EVERYWHERE.
  const merged = mergeCoverage([
    { repository: 'api', coverage: [{ type: 'SAST', analysed: true, by: ['AST_SAST'] }] },
    { repository: 'web', coverage: [{ type: 'SAST', analysed: false, reasons: [{ reason: 'no grammar' }] }] },
  ]);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].analysed, false);
});

test('survives a scan record with nothing in it', () => {
  const summary = summariseScan({});
  assert.equal(summary.total, 0);
  assert.equal(summary.done, false);
  assert.deepEqual(summary.coverage, []);
  assert.deepEqual(summary.repositories, []);
  assert.doesNotThrow(() => summariseScan(null));
});

// ── The card and the table must not disagree ───────────────────────────────
//
// The bug this section exists for: the scan card reported `scan.counts` — every
// finding the run produced in the repositories it covered — while the tiles and
// table below reported open findings across the whole estate. Two unlabelled
// numbers on one screen, and the tool looks broken.

const SCAN = {
  status: 'COMPLETED',
  counts: { CRITICAL: 1, HIGH: 2, MEDIUM: 1, LOW: 0, INFO: 0 },
  repositories: ['api', 'web'],
  progress: { total: 2, completed: 2 },
  startedAt: 0,
  finishedAt: 5000,
  perRepository: [],
};

test('without the loaded findings the card falls back to the scan\'s own tally', () => {
  const summary = summariseScan(SCAN);
  assert.equal(summary.countsAreOpen, false);
  assert.equal(summary.total, 4);
  assert.equal(summary.difference, 0);
});

test('with the findings loaded the card counts what the table counts', () => {
  // SET has 4 open security findings in api+web (ids 1-4); QUALITY is excluded
  // exactly as the table excludes it.
  const summary = summariseScan(SCAN, SET);
  assert.equal(summary.countsAreOpen, true);
  assert.equal(summary.total, scopeFindings(SET, { repositories: ['api', 'web'] }).length);
  assert.equal(summary.total, 4);
});

test('the card ignores repositories the scan did not cover', () => {
  // The other half of the same bug: `infra` is in the loaded set and must not
  // be counted into a scan that never looked at it.
  const summary = summariseScan(SCAN, SET);
  assert.equal(summary.counts.MEDIUM, 1, 'only web\'s MEDIUM, not infra\'s');
});

test('a difference between produced and open is reported, not hidden', () => {
  // Produced 6, open 4: two were suppressed or already resolved. Silently
  // showing 4 would be as confusing as silently showing 6.
  const summary = summariseScan({ ...SCAN, counts: { CRITICAL: 2, HIGH: 3, MEDIUM: 1 } }, SET);
  assert.equal(summary.produced, 6);
  assert.equal(summary.total, 4);
  assert.equal(summary.difference, 2);
});

test('more open than produced is reported the other way round', () => {
  // Findings from an earlier scan still open because this run did not cover
  // their type. A negative difference, and a different sentence.
  const summary = summariseScan({ ...SCAN, counts: { HIGH: 1 } }, SET);
  assert.equal(summary.produced, 1);
  assert.equal(summary.total, 4);
  assert.equal(summary.difference, -3);
});

test('a scan of everything counts everything', () => {
  const summary = summariseScan({ ...SCAN, repositories: [] }, SET);
  assert.equal(summary.total, 5, 'empty repository list means no repository narrowing');
});

test('durations read as a human would say them', () => {
  assert.equal(formatScanDuration(840), '840ms');
  assert.equal(formatScanDuration(8400), '8.4s');
  assert.equal(formatScanDuration(125000), '2m 5s');
  assert.equal(formatScanDuration(null), null);
  assert.equal(formatScanDuration(0), null);
});

// ── Grouping dependency findings ───────────────────────────────────────────
//
// One Tomcat version carried 55 CVEs in a real repository, and 500 SCA findings
// collapsed to 115 rows. The tests that matter are the ones about what grouping
// must NOT do: lose a finding, merge two different upgrades, or touch anything
// other than SCA.


function sca(over = {}) {
  const { packageName = 'org.apache.tomcat:tomcat-catalina', version = '9.0.83', ...rest } = over;
  return {
    id: over.cve || 'x',
    type: 'SCA',
    severity: 'HIGH',
    status: 'OPEN',
    repository: 'api',
    file: 'presentation/pom.xml',
    title: `${over.cve || 'CVE-1'} in ${packageName} ${version}`,
    risk: { score: 23, priority: 'P2' },
    detections: [{ source: 'MAVEN_SCA', ruleId: over.cve || 'CVE-1' }],
    metadata: { packageName, versionInUse: version },
    ...rest,
  };
}

test('advisories against one package version collapse to a single row', () => {
  const rows = groupFindings([
    sca({ cve: 'CVE-2024-50379' }),
    sca({ cve: 'CVE-2026-43513' }),
    sca({ cve: 'CVE-2025-48988' }),
  ]);

  assert.equal(rows.length, 1);
  assert.equal(rows[0].kind, 'group');
  assert.equal(summariseGroup(rows[0]).count, 3);
});

test('grouping never loses a finding', () => {
  // The property that matters most. A row that quietly represents fewer
  // advisories than exist is worse than the noise it replaced.
  const findings = [
    sca({ cve: 'A' }), sca({ cve: 'B' }),
    sca({ cve: 'C', packageName: 'other' }),
    { id: 's', type: 'SAST', severity: 'HIGH', status: 'OPEN', repository: 'api', file: 'A.java', detections: [], metadata: {} },
  ];
  const rows = groupFindings(findings);
  const represented = rows.reduce((n, r) => n + (r.kind === 'group' ? r.findings.length : 1), 0);
  assert.equal(represented, findings.length);
});

test('a package with one advisory stays a plain row', () => {
  // Grouping should add no ceremony where there is nothing to collapse.
  const rows = groupFindings([sca({ cve: 'CVE-1' })]);
  assert.equal(rows[0].kind, 'finding');
});

test('different versions of the same package are different rows', () => {
  // Two versions are two upgrades. Merging them would describe work that does
  // not exist.
  const rows = groupFindings([
    sca({ cve: 'A', version: '9.0.83' }), sca({ cve: 'B', version: '9.0.83' }),
    sca({ cve: 'C', version: '10.1.0' }), sca({ cve: 'D', version: '10.1.0' }),
  ]);
  assert.equal(rows.length, 2);
});

test('the same package in two manifests stays two rows', () => {
  const rows = groupFindings([
    sca({ cve: 'A', file: 'a/pom.xml' }), sca({ cve: 'B', file: 'a/pom.xml' }),
    sca({ cve: 'C', file: 'b/pom.xml' }), sca({ cve: 'D', file: 'b/pom.xml' }),
  ]);
  assert.equal(rows.length, 2);
});

test('SAST findings are never grouped', () => {
  // Collapsing distinct bugs that share a file is the opposite of the problem
  // being solved.
  const sast = f => ({ type: 'SAST', severity: 'HIGH', status: 'OPEN', repository: 'api',
    file: 'A.java', detections: [], metadata: {}, ...f });
  const rows = groupFindings([sast({ id: '1' }), sast({ id: '2' }), sast({ id: '3' })]);
  assert.equal(rows.length, 3);
  assert.ok(rows.every(r => r.kind === 'finding'));
});

test('an SCA finding with no package metadata is not grouped', () => {
  assert.equal(scaGroupKey({ type: 'SCA', metadata: {} }), null);
  assert.equal(groupFindings([sca({ metadata: {} }), sca({ metadata: {} })]).length, 2);
});

test('a group reports the WORST severity and risk, not the first', () => {
  // The row stands in for its members; summarising six CVEs as the least severe
  // of them would be actively misleading.
  const rows = groupFindings([
    sca({ cve: 'A', severity: 'MEDIUM', risk: { score: 10, priority: 'P3' } }),
    sca({ cve: 'B', severity: 'CRITICAL', risk: { score: 88, priority: 'P1' } }),
    sca({ cve: 'C', severity: 'LOW', risk: { score: 4, priority: 'P4' } }),
  ]);
  const g = summariseGroup(rows[0]);
  assert.equal(g.severity, 'CRITICAL');
  assert.equal(g.risk.score, 88);
});

test('a group merges the scanners that reported it', () => {
  const rows = groupFindings([
    sca({ cve: 'A', detections: [{ source: 'MAVEN_SCA' }] }),
    sca({ cve: 'B', detections: [{ source: 'VERSION_WATCH' }, { source: 'MAVEN_SCA' }] }),
  ]);
  assert.deepEqual(summariseGroup(rows[0]).sources.sort(), ['MAVEN_SCA', 'VERSION_WATCH']);
});

test('order is preserved — a group takes its first member\'s position', () => {
  // The caller has already sorted by risk. Re-sorting here would silently
  // disagree with it.
  const sast = { id: 's', type: 'SAST', severity: 'CRITICAL', status: 'OPEN',
    repository: 'api', file: 'A.java', detections: [], metadata: {} };
  const rows = groupFindings([sast, sca({ cve: 'A' }), sca({ cve: 'B' })]);
  assert.equal(rows[0].kind, 'finding');
  assert.equal(rows[1].kind, 'group');
});

test('empty input is safe', () => {
  assert.deepEqual(groupFindings([]), []);
  assert.deepEqual(groupFindings(null), []);
});
