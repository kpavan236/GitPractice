// =============================================================================
// Appraisal Prep — the personal report
// =============================================================================
//
// Builds the HTML (and CSV) of the user's own appraisal pack. Pure: it takes the
// pack and the user's draft and returns strings, so it is tested without a
// browser and produces the same document for the screen preview, the print
// dialog, the PDF and the downloaded HTML file.
//
// It names no ticket, pull request or person other than the author: the pack it
// is given contains none, and nothing here adds one.

const _aprCharts = (typeof module !== 'undefined' && module.exports)
  ? require('./appraisal-charts')
  : { aprGroupedBars, aprHorizontalBars, aprHistogram, aprDataTable, aprEsc };

const APR_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// 'YYYY-MM-DD' -> 'Jan 05'. Fixed arrays, not toLocaleString, so the report reads
// the same on every machine.
function aprShortDate(day) {
  const [, m, d] = String(day).split('-');
  return `${APR_MONTHS[Number(m) - 1] || ''} ${d || ''}`.trim();
}

function aprDays(v) {
  if (v === null || v === undefined) return 'n/a';
  return `${v.toFixed(1)} day${v === 1 ? '' : 's'}`;
}

function aprHours(v) {
  if (v === null || v === undefined) return 'n/a';
  return `${v.toFixed(1)} h`;
}

function aprReportFileName(pack, ext) {
  return `appraisal-prep_${pack.period.key}.${ext}`;
}

// The notes lines are real bordered rows (not a CSS gradient): borders always print, even when a
// browser leaves out background graphics, and whole-pixel spacing (26px) never drops a line.
const APR_CSS = `
.apr-doc{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:#111;font-size:9.5pt;line-height:1.35;max-width:190mm;margin:0 auto;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.apr-doc .apr-top{display:flex;justify-content:space-between;align-items:flex-end;gap:10px;border-bottom:2px solid #1f3a6e;padding-bottom:6px;margin-bottom:8px}
.apr-doc h1{font-size:17pt;line-height:1.1;margin:0;color:#1f3a6e}
.apr-doc .apr-sub{font-size:10pt;color:#333;margin-top:2px}
.apr-doc .apr-right{text-align:right}
.apr-doc .apr-conf{display:inline-block;font-size:7pt;letter-spacing:.06em;text-transform:uppercase;color:#7a1f1f;border:1px solid #7a1f1f;border-radius:3px;padding:1px 6px}
.apr-doc .apr-meta{font-size:7.5pt;color:#555;margin-top:3px}
.apr-doc .apr-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(19mm,1fr));gap:5px;margin:6px 0}
.apr-doc .apr-tile{border:1px solid #c8ccd4;border-radius:4px;padding:3px 7px;background:#f6f7fa}
.apr-doc .apr-tile b{display:block;font-size:13pt;line-height:1.15;white-space:nowrap}
.apr-doc .apr-tile span{font-size:6.5pt;text-transform:uppercase;letter-spacing:.04em;color:#555}
.apr-doc .apr-lede{margin:5px 0 7px;font-size:9.5pt}
.apr-doc .apr-ai{font-size:6.5pt;border:1px solid #555;border-radius:2px;padding:0 3px;margin-left:4px;color:#333;white-space:nowrap}
.apr-doc .apr-note{font-size:7.5pt;color:#6b4a00;margin:0 0 6px}
.apr-doc .apr-two{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:6px}
.apr-doc .apr-three{display:grid;grid-template-columns:.85fr 1.2fr 1.25fr;gap:10px;margin-bottom:6px}
.apr-doc h2{font-size:7.5pt;text-transform:uppercase;letter-spacing:.07em;color:#1f3a6e;margin:0 0 3px;padding-bottom:2px;border-bottom:1px solid #c8ccd4}
.apr-doc .apr-box{break-inside:avoid;page-break-inside:avoid}
.apr-doc .apr-chart{display:block;width:100%;height:auto}
.apr-doc .apr-key{margin:1px 0 0;font-size:6.5pt;color:#555;text-align:right}
.apr-doc .apr-mini{width:100%;border-collapse:collapse;font-size:8.5pt}
.apr-doc .apr-mini th{font-weight:600;text-align:left;color:#555;font-size:7pt;text-transform:uppercase;letter-spacing:.03em}
.apr-doc .apr-mini td,.apr-doc .apr-mini th{padding:2px 3px;border-bottom:1px solid #e3e5ea}
.apr-doc .apr-mini td:nth-child(n+2),.apr-doc .apr-mini th:nth-child(n+2){text-align:right}
.apr-doc .apr-glance{display:grid;grid-template-columns:1fr auto;gap:0 6px;margin:0;font-size:8pt}
.apr-doc .apr-glance dt{color:#444;padding:2px 0;border-bottom:1px solid #e3e5ea}
.apr-doc .apr-glance dd{margin:0;padding:2px 0;font-weight:600;text-align:right;white-space:nowrap;border-bottom:1px solid #e3e5ea}
.apr-doc .apr-list{margin:0;padding-left:13px;font-size:8.5pt}
.apr-doc .apr-list li{margin:0 0 3px}
.apr-doc .apr-empty{color:#777;font-style:italic;font-size:8.5pt;margin:0}
.apr-doc .apr-q{margin-bottom:6px}
.apr-doc .apr-notes{position:relative;border:1px solid #9aa0ac;border-radius:4px;overflow:hidden}
.apr-doc .apr-rules{position:absolute;left:0;right:0;top:0}
.apr-doc .apr-rules i{display:block;height:26px;box-sizing:border-box;border-bottom:1px solid #cfd3da}
.apr-doc .apr-typed{position:relative;padding:0 8px;font-size:10pt;line-height:26px;white-space:pre-wrap}
.apr-doc .apr-foot{margin-top:7px;padding-top:3px;border-top:1px solid #c8ccd4;font-size:7pt;color:#555}
@page{size:portrait;margin:10mm}
@media print{.apr-doc{max-width:none}}`;

const _esc = (s) => _aprCharts.aprEsc(s);
const _sum = (arr, f) => arr.reduce((n, x) => n + f(x), 0);

function aprAiBadge(on) {
  return on ? '<span class="apr-ai" title="Drafted with AI assistance">AI</span>' : '';
}

/**
 * Weekly rows grouped into calendar months, each week counted in the month it starts, so a long
 * period reads as a handful of bars that can each carry their value. Short periods stay weekly.
 * @returns { monthly: boolean, labels: string[], opened: number[], closed: number[] }
 */
function aprMonthly(weekly) {
  if (weekly.length <= 10) {
    return { monthly: false, labels: weekly.map(w => aprShortDate(w.week)), opened: weekly.map(w => w.opened), closed: weekly.map(w => w.closed) };
  }
  const months = [];
  for (const w of weekly) {
    const key = String(w.week).slice(0, 7);
    let last = months[months.length - 1];
    if (!last || last.key !== key) { last = { key, opened: 0, closed: 0 }; months.push(last); }
    last.opened += w.opened;
    last.closed += w.closed;
  }
  const spansYears = new Set(months.map(m => m.key.slice(0, 4))).size > 1;
  return {
    monthly: true,
    labels: months.map(m => `${APR_MONTHS[Number(m.key.slice(5, 7)) - 1]}${spansYears ? ` ${m.key.slice(2, 4)}` : ''}`),
    opened: months.map(m => m.opened), closed: months.map(m => m.closed),
  };
}

const aprNum1 = v => (v === null || v === undefined ? 'n/a' : v.toFixed(1));

function aprTiles(stats, review) {
  const tiles = [
    ['Opened', stats.opened], ['Closed', stats.closed],
  ];
  if (stats.rolled.available) tiles.push(['Rolled over', stats.rolled.events]);
  tiles.push(['Median days', aprNum1(stats.leadTime.median)]);
  if (!stats.leadTime.tooFew) tiles.push(['90th pct days', aprNum1(stats.leadTime.p90)]);
  if (stats.points.available) tiles.push(['Story points', stats.points.completed]);
  if (review && review.available) tiles.push(['PRs merged', review.prsMerged], ['Reviews', review.reviews.total]);
  return `<div class="apr-tiles">${tiles.map(([l, v]) => `<div class="apr-tile"><b>${_esc(v)}</b><span>${_esc(l)}</span></div>`).join('')}</div>`;
}

// The few extra facts that are worth putting in front of a manager. Anything not
// available is left out rather than shown as n/a.
function aprGlance(pack) {
  const s = pack.stats;
  const review = pack.review && pack.review.available ? pack.review : null;
  const rows = [];
  if (s.closed > 0 && s.weekly.length) {
    const best = s.weekly.reduce((a, b) => (b.closed > a.closed ? b : a));
    rows.push(['Busiest week', `${best.closed} closed (${aprShortDate(best.week)})`]);
    if (s.weekly.length >= 4) {
      const half = Math.floor(s.weekly.length / 2);
      rows.push(['Closed: 1st → 2nd half', `${_sum(s.weekly.slice(0, half), w => w.closed)} → ${_sum(s.weekly.slice(half), w => w.closed)}`]);
    }
  }
  if (s.rolled.available && s.sprints.length) {
    const committed = _sum(s.sprints, x => x.committed);
    const completed = _sum(s.sprints, x => x.completed);
    if (committed > 0) rows.push(['Sprint work finished', `${Math.round((completed / committed) * 100)}%`]);
  }
  rows.push(['Still open', s.stillOpen]);
  if (s.leadTime.max !== null) rows.push(['Longest to close', aprDays(s.leadTime.max)]);
  if (s.workTime.n) rows.push(['Working time (median)', aprDays(s.workTime.median)]);
  if (review) {
    if (review.timeToMergeHours.n) rows.push(['PR time to merge', aprHours(review.timeToMergeHours.median)]);
    if (review.firstReviewHours.n) rows.push(['1st review (median)', aprHours(review.firstReviewHours.median)]);
  }
  return rows.slice(0, 8);
}

// Four fit beside the other two panels without pushing the notes onto a second page.
const APR_MAX_HIGHLIGHTS = 4;
const APR_MIN_NOTE_LINES = 8;

// How many ruled lines to draw: at least eight, or enough for what was typed (a
// generous guess at wrapping, so typed text never runs past the rules).
function aprNoteLines(typed) {
  const used = String(typed || '').split('\n').reduce((n, line) => n + Math.max(1, Math.ceil(line.length / 85)), 0);
  return Math.max(APR_MIN_NOTE_LINES, used + 2);
}

/**
 * The one-page report.
 *
 * Built to be read across a table: the figures that matter, two small graphs, the
 * detail that helps a conversation, your highlights, a few questions, and a large
 * ruled area for notes (your typed notes first, blank lines below for writing).
 * Long tables are deliberately NOT here; they live in the app and the CSV.
 *
 * @param {object} p { pack, draft, now?, theme? }
 */
function aprBuildReportHtml({ pack, draft = {}, now = new Date(), theme = 'print' }) {
  const stats = pack.stats;
  const review = pack.review && pack.review.available ? pack.review : null;
  const narrative = pack.narrative;
  const confirmed = Array.isArray(draft.confirmed) ? draft.confirmed : [];
  const shown = confirmed.slice(0, APR_MAX_HIGHLIGHTS);
  const usedAi = (narrative.source === 'ai' && narrative.summary.ai) || confirmed.some(k => k.ai);
  const grouped = aprMonthly(stats.weekly);
  const perWhat = grouped.monthly ? 'month' : 'week';

  const hasActivity = stats.opened + stats.closed > 0;
  const weekly = !hasActivity ? '' : _aprCharts.aprGroupedBars({
    id: 'apr-weekly', title: `Tickets opened and closed per ${perWhat}`, desc: `Grouped bars, one pair per ${perWhat}, each labelled with its value`, theme, width: 360, height: 170,
    categories: grouped.labels, series: [{ name: 'Opened', values: grouped.opened }, { name: 'Closed', values: grouped.closed }],
  });
  const hist = _aprCharts.aprHistogram({
    id: 'apr-hist', title: 'How long tickets took to close', desc: 'Histogram of days from created to resolved', theme, width: 360, height: 170,
    bins: stats.histogram, median: stats.leadTime.median, p90: stats.leadTime.p90,
  });
  const noWeekly = '<p class="apr-empty">No tickets were opened or closed in this period.</p>';
  const noHist = '<p class="apr-empty">No tickets were closed in this period.</p>';

  const byType = stats.byType.slice(0, 5);
  const glance = aprGlance(pack);
  const prompts = (narrative.prompts || []).slice(0, 3);
  const typed = String(draft.talkingPoints || '').trim();

  return `<div class="apr-doc"><style>${APR_CSS}</style>`
    + `<header class="apr-top"><div><h1>Appraisal Prep</h1>`
    + `<div class="apr-sub">${_esc(pack.user && pack.user.displayName ? pack.user.displayName : 'Your report')} · ${_esc(pack.period.label)}</div></div>`
    + `<div class="apr-right"><div class="apr-conf">Personal and confidential</div>`
    + `<div class="apr-meta">Prepared ${_esc(now.toISOString().slice(0, 10))} for your own reference</div></div></header>`
    + aprTiles(stats, review)
    + `<p class="apr-lede">${_esc(narrative.summary.text)}${aprAiBadge(narrative.summary.ai)}</p>`
    + (pack.notices.length ? `<p class="apr-note">${_esc(pack.notices.slice(0, 2).join(' '))}</p>` : '')
    + `<div class="apr-two"><section class="apr-box"><h2>Opened and closed per ${perWhat}</h2>${weekly || noWeekly}</section>`
    + `<section class="apr-box"><h2>Time to close</h2>${hist || noHist}</section></div>`
    + `<div class="apr-three">`
    + `<section class="apr-box"><h2>By ticket type</h2>${byType.length
      ? _aprCharts.aprHorizontalBars({ id: 'apr-type', title: 'Closed tickets and median days to close, by ticket type', desc: 'One bar per ticket type, labelled with tickets closed and median days',
        theme, width: 190, items: byType.map(r => ({ name: r.name, value: r.closed, label: `${r.closed} · ${r.median === null ? 'n/a' : `${r.median.toFixed(1)} d`}` })) })
        + '<p class="apr-key">Closed · median days</p>'
      : '<p class="apr-empty">Nothing closed.</p>'}</section>`
    + `<section class="apr-box"><h2>At a glance</h2><dl class="apr-glance">${glance.map(([k, v]) => `<dt>${_esc(k)}</dt><dd>${_esc(v)}</dd>`).join('')}</dl></section>`
    + `<section class="apr-box"><h2>Highlights</h2>${shown.length
      ? `<ul class="apr-list">${shown.map(k => `<li>${k.title ? `<strong>${_esc(k.title)}.</strong> ` : ''}${_esc(k.text)}${aprAiBadge(k.ai)}</li>`).join('')}</ul>${confirmed.length > shown.length ? `<p class="apr-empty">+${confirmed.length - shown.length} more not shown (no room on one page)</p>` : ''}`
      : '<p class="apr-empty">None added yet. Write them in your notes below.</p>'}</section>`
    + `</div>`
    + (prompts.length ? `<section class="apr-q apr-box"><h2>To think about</h2><ul class="apr-list">${prompts.map(p => `<li>${_esc(p.text)}${aprAiBadge(p.ai)}</li>`).join('')}</ul></section>` : '')
    + `<section><h2>My notes for the discussion</h2><div class="apr-notes" style="min-height:${aprNoteLines(typed) * 26}px">`
    + `<div class="apr-rules">${'<i></i>'.repeat(aprNoteLines(typed))}</div><div class="apr-typed">${_esc(typed)}</div></div></section>`
    + `<footer class="apr-foot">Context for a conversation, not a score. Time to close = created to resolved; the 90th percentile needs 5 or more closed tickets.${grouped.monthly ? ' Months group whole weeks by the month each week starts.' : ''} `
    + (usedAi ? `Parts were drafted with AI assistance${narrative.provider ? ` (${_esc(narrative.provider)}${narrative.model ? `, ${_esc(narrative.model)}` : ''}${narrative.local ? ', running on this machine' : ''})` : ''} and reviewed and edited by the author. ` : '')
    + 'Personal and confidential.</footer></div>';
}

function aprBuildStandaloneHtml(args) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">`
    + `<title>Appraisal Prep ${_esc(args.pack.period.label)}</title></head><body style="margin:20px">${aprBuildReportHtml(args)}</body></html>`;
}

// A cell that starts with = + - @ tab or CR can be run as a formula by a
// spreadsheet. Strings are prefixed so they are read as text; numbers are left.
function aprCsvCell(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number') return String(v);
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** The statistics and weekly series as CSV. Never ticket rows: there are none to give. */
function aprBuildCsv(pack, now = new Date()) {
  const s = pack.stats;
  const rows = [];
  const block = (head, lines) => { rows.push([], head, ...lines); };
  rows.push(['Appraisal Prep: personal and confidential'], ['Period', pack.period.label], ['Generated', now.toISOString().slice(0, 10)]);
  block(['Measure', 'Value'], [
    ['Opened', s.opened], ['Closed', s.closed], ['Still open', s.stillOpen],
    ['Rolled over (events)', s.rolled.available ? s.rolled.events : 'n/a'],
    ['Median days to close', s.leadTime.median], ['90th percentile days', s.leadTime.p90 === null ? 'too few tickets' : s.leadTime.p90],
    ['Longest days to close', s.leadTime.max], ['Story points completed', s.points.available ? s.points.completed : 'n/a'],
  ]);
  block(['Week of', 'Opened', 'Closed'], s.weekly.map(w => [w.week, w.opened, w.closed]));
  block(['Type', 'Closed', 'Median days'], s.byType.map(t => [t.name, t.closed, t.median]));
  block(['Priority', 'Closed', 'Median days'], s.byPriority.map(t => [t.name, t.closed, t.median]));
  block(['Sprint', 'Committed', 'Completed', 'Rolled over', 'Points'], s.sprints.map(x => [x.name, x.committed, x.completed, x.rolled, x.points]));
  if (pack.review && pack.review.available) {
    const r = pack.review;
    block(['Code review', 'Value'], [['PRs opened', r.prsOpened], ['PRs merged', r.prsMerged], ['PRs reviewed', r.prsReviewed],
      ['Reviews approved', r.reviews.approved], ['Reviews: changes requested', r.reviews.changesRequested], ['Reviews commented', r.reviews.commented]]);
    block(['Week of', 'PRs opened', 'PRs merged', 'Reviews given'], r.weekly.map(w => [w.week, w.opened, w.merged, w.reviews]));
  }
  return rows.map(r => r.map(aprCsvCell).join(',')).join('\r\n');
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { aprMonthly, aprBuildReportHtml, aprBuildStandaloneHtml, aprBuildCsv, aprReportFileName, aprShortDate, aprDays, aprHours, aprCsvCell, aprGlance, aprNoteLines, APR_CSS, APR_MAX_HIGHLIGHTS };
}
