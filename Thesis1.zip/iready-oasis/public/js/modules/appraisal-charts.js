// =============================================================================
// Appraisal Prep — charts
// =============================================================================
//
// Pure functions that return an SVG string. No DOM, no globals, so they run in
// the tab, in the printed report and in tests, and produce the same output for
// the same input.
//
// Two palettes: 'screen' uses the app's theme variables so the chart follows the
// light/dark theme; 'print' uses fixed colours and a hatched second series so a
// black-and-white printout still tells the series apart. Every chart is meant to
// be read together with its data table (aprDataTable), so nothing is carried by
// colour alone.

const APR_PALETTES = {
  screen: { a: 'var(--accent)', b: 'var(--green)', c: 'var(--amber)', text: 'var(--text2)', strong: 'var(--text)', grid: 'var(--border2)', mark: 'var(--purple)' },
  print:  { a: '#244fa8', b: '#1f6b3b', c: '#8a6d00', text: '#333333', strong: '#111111', grid: '#bbbbbb', mark: '#7a2e8a' },
};

function aprEsc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const aprNum = n => (Number.isFinite(n) ? Math.round(n * 100) / 100 : 0);

function aprNice(max) {
  if (max <= 0) return 1;
  const pow = 10 ** Math.floor(Math.log10(max));
  const f = max / pow;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * pow;
}

function aprSvg(id, w, h, title, desc, body, defs = '') {
  return `<svg id="${aprEsc(id)}" class="apr-chart" viewBox="0 0 ${w} ${h}" width="100%" role="img" aria-labelledby="${aprEsc(id)}-t ${aprEsc(id)}-d" preserveAspectRatio="xMidYMid meet">`
    + `<title id="${aprEsc(id)}-t">${aprEsc(title)}</title><desc id="${aprEsc(id)}-d">${aprEsc(desc)}</desc>${defs}${body}</svg>`;
}

// Series fills. The second series is hatched so it survives a black-and-white print.
function aprFills(id, p, theme) {
  const defs = theme !== 'print' ? '' : `<defs><pattern id="${aprEsc(id)}-hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">`
    + `<rect width="6" height="6" style="fill:${p.b}" fill-opacity="0.25"/><line x1="0" y1="0" x2="0" y2="6" style="stroke:${p.b}" stroke-width="3"/></pattern></defs>`;
  return { defs, fill: [`fill:${p.a}`, theme === 'print' ? `fill:url(#${aprEsc(id)}-hatch)` : `fill:${p.b}`, `fill:${p.c}`] };
}

/**
 * Grouped vertical bars.
 * @param {object} o { id, title, desc, categories: string[], series: [{ name, values: number[] }], theme, height? }
 */
function aprGroupedBars(o) {
  const { id, title, desc, categories, series, theme = 'screen', height = 240, width = 640 } = o;
  if (!categories.length || !series.length) return '';
  const p = APR_PALETTES[theme];
  const W = width; const H = height;
  const compact = W < 500;
  const m = compact ? { l: 28, r: 6, t: 22, b: 26 } : { l: 40, r: 12, t: 28, b: 46 };
  const innerW = W - m.l - m.r; const innerH = H - m.t - m.b;
  const max = aprNice(Math.max(1, ...series.flatMap(s => s.values)));
  const group = innerW / categories.length;
  const barW = Math.max(2, Math.min(28, (group * 0.8) / series.length));
  const { defs, fill } = aprFills(id, p, theme);
  const y = v => m.t + innerH - (v / max) * innerH;

  let body = '';
  for (let i = 0; i <= 4; i++) {
    const v = (max / 4) * i;
    body += `<line x1="${m.l}" x2="${W - m.r}" y1="${aprNum(y(v))}" y2="${aprNum(y(v))}" style="stroke:${p.grid}" stroke-width="0.5"/>`
      + `<text x="${m.l - 6}" y="${aprNum(y(v) + 3)}" text-anchor="end" font-size="9" style="fill:${p.text}">${aprNum(v)}</text>`;
  }
  const labelEvery = compact ? (categories.length <= 8 ? 1 : Math.ceil(categories.length / 5)) : Math.ceil(categories.length / 12);
  categories.forEach((cat, ci) => {
    const gx = m.l + ci * group + (group - barW * series.length) / 2;
    series.forEach((s, si) => {
      const v = s.values[ci] || 0;
      const bh = (v / max) * innerH;
      const x = gx + si * barW;
      body += `<rect x="${aprNum(x)}" y="${aprNum(y(v))}" width="${aprNum(barW - 1)}" height="${aprNum(bh)}" style="${fill[si % 3]}"><title>${aprEsc(s.name)}, ${aprEsc(cat)}: ${v}</title></rect>`;
      if (v > 0 && barW >= 8) body += `<text x="${aprNum(x + (barW - 1) / 2)}" y="${aprNum(y(v) - 3)}" text-anchor="middle" font-size="8" style="fill:${p.strong}">${v}</text>`;
    });
    if (ci % labelEvery === 0) {
      body += `<text x="${aprNum(m.l + ci * group + group / 2)}" y="${H - m.b + 14}" text-anchor="middle" font-size="9" style="fill:${p.text}">${aprEsc(cat)}</text>`;
    }
  });
  // Legend, with the series name written out (not colour alone).
  series.forEach((s, si) => {
    const lx = m.l + si * (compact ? 78 : 150);
    body += `<rect x="${lx}" y="${compact ? 4 : 6}" width="10" height="10" style="${fill[si % 3]}"/><text x="${lx + 14}" y="${compact ? 13 : 16}" font-size="${compact ? 9 : 10}" style="fill:${p.strong}">${aprEsc(s.name)}</text>`;
  });
  return aprSvg(id, W, H, title, desc, body, defs);
}

/**
 * Horizontal bars, one per item, labelled with the value.
 * @param {object} o { id, title, desc, items: [{ name, value, label }], theme, unit? }
 */
function aprHorizontalBars(o) {
  const { id, title, desc, items, theme = 'screen', width = 640 } = o;
  if (!items.length) return '';
  const p = APR_PALETTES[theme];
  const compact = width < 500;
  const narrow = width < 240;
  const rowH = compact ? 22 : 24; const W = width; const m = narrow ? { l: 38, r: 66, t: 4, b: 4 } : compact ? { l: 70, r: 92, t: 4, b: 4 } : { l: 150, r: 70, t: 8, b: 8 };
  const fs = narrow ? 9 : compact ? 10 : 11;
  const H = m.t + m.b + items.length * rowH;
  const max = Math.max(...items.map(i => i.value), 0.0001);
  const innerW = W - m.l - m.r;
  let body = '';
  items.forEach((it, i) => {
    const y = m.t + i * rowH;
    const bw = Math.max(1, (it.value / max) * innerW);
    body += `<text x="${m.l - 8}" y="${y + 14}" text-anchor="end" font-size="${fs}" style="fill:${p.strong}">${aprEsc(it.name)}</text>`
      + `<rect x="${m.l}" y="${y + 3}" width="${aprNum(bw)}" height="${rowH - 8}" rx="2" style="fill:${p.a}"><title>${aprEsc(it.name)}: ${aprEsc(it.label)}</title></rect>`
      + `<text x="${aprNum(m.l + bw + 6)}" y="${y + 14}" font-size="${fs}" style="fill:${p.strong}">${aprEsc(it.label)}</text>`;
  });
  return aprSvg(id, W, H, title, desc, body);
}

/**
 * Histogram of time to close, with the median and 90th percentile marked.
 * @param {object} o { id, title, desc, bins: [{ from, to, label, count }], median, p90, theme }
 */
function aprHistogram(o) {
  const { id, title, desc, bins, median, p90, theme = 'screen', height = 240, width = 640 } = o;
  if (!bins.length) return '';
  const p = APR_PALETTES[theme];
  const W = width; const H = height;
  const compact = W < 500;
  const m = compact ? { l: 28, r: 6, t: 26, b: 34 } : { l: 40, r: 12, t: 30, b: 50 };
  const innerW = W - m.l - m.r; const innerH = H - m.t - m.b;
  const max = aprNice(Math.max(1, ...bins.map(b => b.count)));
  const bw = innerW / bins.length;
  const y = v => m.t + innerH - (v / max) * innerH;
  // A value's x position is its bin's slot plus how far through that bin it is.
  const xFor = v => {
    if (v === null || v === undefined) return null;
    let i = bins.length - 1;
    while (i > 0 && v < bins[i].from) i -= 1;
    const bin = bins[i];
    const frac = bin.to === null ? 0.5 : Math.min(1, Math.max(0, (v - bin.from) / (bin.to - bin.from)));
    return m.l + (i + frac) * bw;
  };
  let body = '';
  for (let i = 0; i <= 4; i++) {
    const v = (max / 4) * i;
    body += `<line x1="${m.l}" x2="${W - m.r}" y1="${aprNum(y(v))}" y2="${aprNum(y(v))}" style="stroke:${p.grid}" stroke-width="0.5"/>`
      + `<text x="${m.l - 6}" y="${aprNum(y(v) + 3)}" text-anchor="end" font-size="9" style="fill:${p.text}">${aprNum(v)}</text>`;
  }
  bins.forEach((b, i) => {
    const bh = (b.count / max) * innerH;
    body += `<rect x="${aprNum(m.l + i * bw + 1)}" y="${aprNum(y(b.count))}" width="${aprNum(bw - 2)}" height="${aprNum(bh)}" style="fill:${p.a}"><title>${aprEsc(b.label)} days: ${b.count}</title></rect>`;
    if (b.count > 0) body += `<text x="${aprNum(m.l + i * bw + bw / 2)}" y="${aprNum(y(b.count) - 3)}" text-anchor="middle" font-size="9" style="fill:${p.strong}">${b.count}</text>`;
    body += `<text x="${aprNum(m.l + i * bw + bw / 2)}" y="${H - m.b + 14}" text-anchor="middle" font-size="9" style="fill:${p.text}">${aprEsc(b.label)}</text>`;
  });
  body += `<text x="${aprNum(m.l + innerW / 2)}" y="${H - (compact ? 3 : 8)}" text-anchor="middle" font-size="${compact ? 8.5 : 10}" style="fill:${p.text}">Days from created to resolved</text>`;
  // The two reference lines are named once, in a key above the plot, so their labels never sit on the bars.
  let keyX = m.l;
  const mark = (v, name) => {
    const x = xFor(v);
    if (x === null) return '';
    const text = `${name} ${aprNum(v)} d`;
    const out = `<line x1="${aprNum(x)}" x2="${aprNum(x)}" y1="${m.t}" y2="${m.t + innerH}" style="stroke:${p.mark}" stroke-width="1.5" stroke-dasharray="4 3"/>`
      + `<line x1="${keyX}" x2="${keyX + 14}" y1="9" y2="9" style="stroke:${p.mark}" stroke-width="1.5" stroke-dasharray="4 3"/>`
      + `<text x="${keyX + 18}" y="12" font-size="${compact ? 9 : 10}" style="fill:${p.mark}">${aprEsc(text)}</text>`;
    keyX += compact ? 96 : 120;
    return out;
  };
  body += mark(median, 'Median') + mark(p90, '90th pct');
  return aprSvg(id, W, H, title, desc, body);
}

/** An accessible table for a chart's numbers. */
function aprDataTable(columns, rows) {
  if (!rows.length) return '';
  return `<table class="apr-table"><thead><tr>${columns.map(c => `<th>${aprEsc(c)}</th>`).join('')}</tr></thead>`
    + `<tbody>${rows.map(r => `<tr>${r.map(c => `<td>${aprEsc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { aprGroupedBars, aprHorizontalBars, aprHistogram, aprDataTable, aprEsc, APR_PALETTES };
}
