'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { aprBuildReportHtml, aprBuildStandaloneHtml, aprBuildCsv, aprReportFileName, aprShortDate, aprDays, aprCsvCell, aprGlance, aprNoteLines, aprMonthly, APR_MAX_HIGHLIGHTS } = require('./appraisal-report');
const { computeStats } = require('../../../server/appraisal/metrics');
const { computeReview } = require('../../../server/appraisal/review-metrics');
const { parsePeriod } = require('../../../server/appraisal/period');

const d = s => new Date(s);
const PERIOD = parsePeriod({ mode: 'range', from: '2026-01-05T00:00:00.000Z', to: '2026-03-01T23:59:59.999Z', tz: 'UTC' }, d('2026-10-06T10:00:00Z'));
const t = (over = {}) => ({ type: 'Story', priority: 'High', points: 3, created: d('2026-01-05T00:00:00Z'), resolved: d('2026-01-09T00:00:00Z'),
  firstInProgress: null, owned: true, reassigned: false, sprints: [], components: [], ...over });
const NOW = d('2026-10-06T10:00:00Z');

function makePack({ review = null, source = 'rules', notices = [], name = 'Pat Example', tickets = null, meta = { sprintsAvailable: false } } = {}) {
  const stats = computeStats(tickets || [t(), t({ type: 'Bug' }), t({ resolved: d('2026-01-20T00:00:00Z') }), t(), t(), t({ resolved: null })], PERIOD, meta);
  return {
    period: { key: PERIOD.key, label: PERIOD.label }, generatedAt: '2026-10-06T10:00:00.000Z', user: { displayName: name }, partial: false,
    notices, stats, review: review || { available: false, reason: 'off' }, candidates: [],
    narrative: { source, reason: null, provider: source === 'ai' ? 'bedrock' : null, model: source === 'ai' ? 'm1' : null, local: false,
      summary: { text: 'You closed 5 tickets.', ai: source === 'ai' }, kudos: [],
      prompts: [{ text: 'What went well?', ai: false }, { text: 'What was hard?', ai: false }, { text: 'What next?', ai: false }, { text: 'A fourth question', ai: false }] },
  };
}
const reviewData = () => computeReview([{ created: d('2026-01-06T00:00:00Z'), merged: d('2026-01-08T00:00:00Z') }],
  [{ prCreated: d('2026-01-06T00:00:00Z'), reviews: [{ at: d('2026-01-06T05:00:00Z'), state: 'APPROVED' }] }], PERIOD);

test('it is one compact page: header, key figures, three graphs, detail, highlights, questions, notes, footer', () => {
  const html = aprBuildReportHtml({ pack: makePack(), now: NOW });
  for (const part of ['class="apr-top"', 'class="apr-tiles"', 'id="apr-weekly"', 'id="apr-hist"', 'By ticket type', 'At a glance', 'Highlights', 'To think about', 'My notes for the discussion', 'class="apr-foot"']) {
    assert.ok(html.includes(part), part);
  }
  assert.equal((html.match(/<svg /g) || []).length, 3, 'three graphs: over time, time to close, by type');
  assert.doesNotMatch(html, /Week of/, 'no long weekly table');
  assert.doesNotMatch(html, /<h2>Definitions/, 'no definitions page');
});

test('the header carries the author, the period and the confidentiality mark', () => {
  const html = aprBuildReportHtml({ pack: makePack(), now: NOW });
  assert.match(html, /Pat Example · 2026-01-05 to 2026-03-01/);
  assert.match(html, /Personal and confidential/);
  assert.match(html, /Prepared 2026-10-06 for your own reference/);
});

test('the figures are the real ones, and a tile with nothing to say is left out rather than shown as n/a', () => {
  const html = aprBuildReportHtml({ pack: makePack(), now: NOW });
  assert.match(html, /<b>6<\/b><span>Opened<\/span>/);
  assert.match(html, /<b>5<\/b><span>Closed<\/span>/);
  assert.doesNotMatch(html, /Rolled over<\/span>/, 'no sprint data, so no tile');
  assert.match(html, /<b>4\.0<\/b><span>Median days<\/span>/);
  assert.match(html, /<b>15\.0<\/b><span>90th pct days<\/span>/, '5 closed tickets is enough for a percentile');
  const few = aprBuildReportHtml({ pack: makePack({ tickets: [t(), t(), t()], meta: {} }), now: NOW });
  assert.doesNotMatch(few, /90th pct days<\/span>/, 'too few tickets for a percentile, so no tile');
  assert.doesNotMatch(html, /NaN|undefined|\[object|>null</);
});

test('code review adds tiles only when it was available', () => {
  assert.doesNotMatch(aprBuildReportHtml({ pack: makePack(), now: NOW }), /PRs merged/);
  const html = aprBuildReportHtml({ pack: makePack({ review: reviewData() }), now: NOW });
  assert.match(html, /<b>1<\/b><span>PRs merged<\/span>/);
  assert.match(html, /<b>1<\/b><span>Reviews<\/span>/);
  assert.match(html, /1st review \(median\)/);
});

test('"at a glance" shows only facts that exist, in a stable order, capped', () => {
  const sprint = (id, a, b) => ({ id, name: `Sprint ${id}`, state: 'closed', start: d(a), end: d(b) });
  const s1 = sprint(1, '2026-01-05T00:00:00Z', '2026-01-19T00:00:00Z');
  const s2 = sprint(2, '2026-01-19T00:00:00Z', '2026-02-02T00:00:00Z');
  const tickets = [t({ sprints: [s1, s2], resolved: d('2026-01-30T00:00:00Z') }), t({ sprints: [s1], resolved: d('2026-01-15T00:00:00Z') }),
    t({ sprints: [s2], resolved: d('2026-01-25T00:00:00Z') }), t({ resolved: d('2026-02-20T00:00:00Z') }), t({ resolved: d('2026-02-21T00:00:00Z') }), t({ resolved: null })];
  const rows = Object.fromEntries(aprGlance(makePack({ tickets, meta: {}, review: reviewData() })));
  assert.match(rows['Busiest week'], /closed \(/);
  assert.match(rows['Closed: 1st → 2nd half'], /^\d+ → \d+$/);
  assert.match(rows['Sprint work finished'], /^\d+%$/);
  assert.equal(rows['Still open'], 1);
  assert.match(rows['Longest to close'], /days/);
  assert.match(rows['PR time to merge'], / h$/);
  assert.ok(aprGlance(makePack({ tickets, meta: {}, review: reviewData() })).length <= 8);
  const none = Object.fromEntries(aprGlance(makePack({ tickets: [], meta: {} })));
  assert.deepEqual(Object.keys(none), ['Still open']);
});

test('the by-type graph lists at most five types, biggest first, each labelled with its values', () => {
  const types = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const tickets = types.flatMap((ty, i) => Array.from({ length: 7 - i }, () => t({ type: ty })));
  const html = aprBuildReportHtml({ pack: makePack({ tickets, meta: {} }), now: NOW });
  const rows = [...html.matchAll(/<title>([A-G]): (\d+) · /g)].map(m => [m[1], Number(m[2])]);
  assert.deepEqual(rows, [['A', 7], ['B', 6], ['C', 5], ['D', 4], ['E', 3]]);
});

test('highlights are the ones the user confirmed, escaped, capped for one page, with the overflow stated', () => {
  const many = Array.from({ length: APR_MAX_HIGHLIGHTS + 2 }, (_, i) => ({ id: `k${i}`, title: `T${i}`, text: i === 0 ? 'Fast <b>work</b> & care' : `Text ${i}`, ai: false }));
  const html = aprBuildReportHtml({ pack: makePack(), draft: { confirmed: many }, now: NOW });
  assert.match(html, /<strong>T0\.<\/strong> Fast &lt;b&gt;work&lt;\/b&gt; &amp; care/);
  assert.equal((html.match(/<li><strong>T\d+/g) || []).length, APR_MAX_HIGHLIGHTS);
  assert.match(html, /\+2 more not shown \(no room on one page\)/);
  assert.match(aprBuildReportHtml({ pack: makePack(), now: NOW }), /None added yet/);
});

test('at most three questions are shown', () => {
  const html = aprBuildReportHtml({ pack: makePack(), now: NOW });
  assert.match(html, /What went well\?/);
  assert.match(html, /What next\?/);
  assert.doesNotMatch(html, /A fourth question/);
});

test('the notes area holds the typed notes (escaped) over real ruled rows, with room to write more', () => {
  const html = aprBuildReportHtml({ pack: makePack(), draft: { talkingPoints: 'Raise: on-call load\n<script>alert(1)</script>' }, now: NOW });
  assert.match(html, /<div class="apr-typed">Raise: on-call load\n&lt;script&gt;/);
  assert.doesNotMatch(html, /<script>alert/);
  assert.equal((html.match(/<i><\/i>/g) || []).length, 8, 'eight ruled rows at minimum');
  assert.match(html, /\.apr-rules i\{[^}]*border-bottom:1px solid/, 'rules are borders, which always print');
  assert.doesNotMatch(html, /repeating-linear-gradient/, 'no background gradient that a printer may drop');
  assert.match(html, /\.apr-typed\{[^}]*line-height:26px/);
  assert.match(html, /<div class="apr-notes" style="min-height:208px">/);
  const blank = aprBuildReportHtml({ pack: makePack(), now: NOW });
  assert.match(blank, /<div class="apr-typed"><\/div>/, 'blank, ready to write on');
});

test('the number of ruled rows grows with what was typed, so text never runs past the rules', () => {
  assert.equal(aprNoteLines(''), 8);
  assert.equal(aprNoteLines('one short line'), 8);
  assert.equal(aprNoteLines(Array.from({ length: 20 }, (_, i) => `line ${i}`).join('\n')), 22);
  assert.equal(aprNoteLines('x'.repeat(300)), 8, '300 characters wrap to about 4 rows');
  assert.equal(aprNoteLines('x'.repeat(1000)), 14);
});

test('the author name is escaped', () => {
  const html = aprBuildReportHtml({ pack: makePack({ name: '<img src=x onerror=1>' }), now: NOW });
  assert.doesNotMatch(html, /<img src=x/);
  assert.match(html, /&lt;img src=x/);
});

test('AI marks and the footer disclosure appear only when AI-written text is in the report', () => {
  const plain = aprBuildReportHtml({ pack: makePack({ source: 'rules' }), now: NOW });
  assert.doesNotMatch(plain, /AI assistance|class="apr-ai"/);
  const ai = aprBuildReportHtml({ pack: makePack({ source: 'ai' }), now: NOW });
  assert.match(ai, /drafted with AI assistance \(bedrock, m1\) and reviewed and edited by the author/);
  assert.match(ai, /class="apr-ai"/);
  assert.match(aprBuildReportHtml({ pack: makePack(), draft: { confirmed: [{ id: 'a', text: 'x', ai: true }] }, now: NOW }), /AI assistance/);
});

test('it says plainly that the figures are not a score, and carries any notice', () => {
  const html = aprBuildReportHtml({ pack: makePack({ notices: ['Rolled-over work is not available.'] }), now: NOW });
  assert.match(html, /not a score/);
  assert.match(html, /Rolled-over work is not available\./);
});

test('it names no ticket, PR, link or person other than the author', () => {
  const html = aprBuildReportHtml({ pack: makePack({ review: reviewData() }), now: NOW });
  assert.doesNotMatch(html, /\b[A-Z][A-Z0-9]+-\d+\b/);
  assert.doesNotMatch(html, /pull\/\d+|https?:\/\//);
});

test('graphs use the print palette (fixed colours), never theme variables', () => {
  const html = aprBuildReportHtml({ pack: makePack({ review: reviewData() }), now: NOW });
  assert.doesNotMatch(html.replace(/<style>[\s\S]*?<\/style>/, ''), /var\(--/);
});

test('page rules: portrait, backgrounds kept, and every rule scoped to the report', () => {
  const html = aprBuildReportHtml({ pack: makePack(), now: NOW });
  assert.match(html, /@page\{size:portrait;margin:10mm\}/);
  assert.match(html, /print-color-adjust:exact/);
  assert.doesNotMatch(html, /position:fixed/);
  const rules = html.match(/<style>([\s\S]*?)<\/style>/)[1].replace(/@page\{[^}]*\}/, '').replace(/@media print\{/, '');
  for (const sel of rules.match(/[^{}]+(?=\{)/g)) assert.match(sel.trim(), /^\.apr-doc/, sel);
});

test('an empty period still gives a complete page with clear placeholders', () => {
  const html = aprBuildReportHtml({ pack: { ...makePack(), stats: computeStats([], PERIOD) }, now: NOW });
  assert.equal((html.match(/<svg /g) || []).length, 0);
  assert.match(html, /No tickets were opened or closed in this period\./);
  assert.match(html, /No tickets were closed in this period\./);
  assert.match(html, /Nothing closed\./);
  assert.doesNotMatch(html, /NaN|undefined/);
});

test('the standalone file is a complete document with its own styles', () => {
  const doc = aprBuildStandaloneHtml({ pack: makePack(), now: NOW });
  assert.match(doc, /^<!doctype html>/);
  assert.match(doc, /<title>Appraisal Prep 2026-01-05 to 2026-03-01<\/title>/);
  assert.match(doc, /<style>/);
});

test('the CSV holds statistics and weekly series only, with no ticket rows', () => {
  const csv = aprBuildCsv(makePack({ review: reviewData() }), NOW);
  const lines = csv.split('\r\n');
  assert.equal(lines[0], 'Appraisal Prep: personal and confidential');
  assert.ok(lines.includes('Opened,6'));
  assert.ok(lines.includes('Week of,Opened,Closed'));
  assert.ok(lines.includes('Week of,PRs opened,PRs merged,Reviews given'));
  assert.doesNotMatch(csv, /\b[A-Z][A-Z0-9]+-\d+\b/);
});

test('CSV cells are quoted when needed and cannot run as spreadsheet formulas', () => {
  assert.equal(aprCsvCell('a,b'), '"a,b"');
  assert.equal(aprCsvCell('say "hi"'), '"say ""hi"""');
  for (const lead of ['=1+1', '+1', '-1+2', '@SUM(A1)']) assert.ok(aprCsvCell(lead).startsWith("'"), lead);
  assert.equal(aprCsvCell(-3), '-3');
  assert.equal(aprCsvCell(null), '');
});

test('file names carry the period; helpers format consistently', () => {
  assert.equal(aprReportFileName(makePack(), 'pdf'), 'appraisal-prep_2026-01-05_2026-03-01.pdf');
  assert.equal(aprShortDate('2026-01-05'), 'Jan 05');
  assert.equal(aprDays(1), '1.0 day');
  assert.equal(aprDays(2.46), '2.5 days');
  assert.equal(aprDays(null), 'n/a');
});

test('a long period is shown by month so every bar can carry its value; a short one stays weekly', () => {
  const weekly = ['2026-01-05', '2026-01-12', '2026-01-19', '2026-01-26', '2026-02-02', '2026-02-09', '2026-02-16', '2026-02-23', '2026-03-02', '2026-03-09', '2026-03-16']
    .map((week, i) => ({ week, opened: i + 1, closed: 1 }));
  const m = aprMonthly(weekly);
  assert.equal(m.monthly, true);
  assert.deepEqual(m.labels, ['Jan', 'Feb', 'Mar']);
  assert.deepEqual(m.opened, [10, 26, 30]);
  assert.deepEqual(m.closed, [4, 4, 3]);
  assert.equal(m.opened.reduce((a, b) => a + b, 0), weekly.reduce((a, w) => a + w.opened, 0), 'nothing is lost in the grouping');
  const short = aprMonthly(weekly.slice(0, 4));
  assert.equal(short.monthly, false);
  assert.deepEqual(short.labels, ['Jan 05', 'Jan 12', 'Jan 19', 'Jan 26']);
  assert.match(aprMonthly(weekly.map((w, i) => ({ ...w, week: i < 3 ? `2025-12-${15 + i * 7}` : w.week }))).labels[0], /^Dec 25$/);
});
