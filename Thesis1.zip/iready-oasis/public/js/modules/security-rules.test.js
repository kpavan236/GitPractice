'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  ruleMatches, facetCounts, sortRules, profileStateLabel, profileOrder,
  formToRule, ruleToForm, emptyForm, formProblems, signatureOf, canSave, explainTestReport, ruleDetailModel,
} = require('./security-rules');

const R = (over = {}) => ({ id: 'java-sqli', title: 'SQL injection', description: 'Builds a query from user input', language: 'java', engine: 'ast', severity: 'HIGH', origin: 'builtin', ...over });

test('search matches id, title and description, ignoring case, and an empty search matches everything', () => {
  assert.equal(ruleMatches(R(), 'sqli'), true);
  assert.equal(ruleMatches(R(), 'SQL INJ'), true);
  assert.equal(ruleMatches(R(), 'user input'), true);
  assert.equal(ruleMatches(R(), 'xss'), false);
  assert.equal(ruleMatches(R(), ''), true);
  assert.equal(ruleMatches(R({ description: undefined, title: undefined }), 'sqli'), true, 'missing text does not throw');
});

test('facet counts are ordered by count then name, and skip empty values', () => {
  const rules = [R(), R({ id: 'b', language: 'python' }), R({ id: 'c', language: 'java' }), R({ id: 'd', language: null })];
  assert.deepEqual(facetCounts(rules, 'language'), [{ value: 'java', count: 2 }, { value: 'python', count: 1 }]);
});

test('rules sort by severity, then id', () => {
  const sorted = sortRules([R({ id: 'z', severity: 'LOW' }), R({ id: 'b', severity: 'CRITICAL' }), R({ id: 'a', severity: 'CRITICAL' }), R({ id: 'm', severity: 'INFO' })]);
  assert.deepEqual(sorted.map(r => r.id), ['a', 'b', 'z', 'm']);
});

test('a profile entry is labelled by whether it runs and where that comes from', () => {
  assert.deepEqual(profileStateLabel({ enabled: true, overridden: false, inherited: false }), { label: 'On', tone: 'on' });
  assert.deepEqual(profileStateLabel({ enabled: true, inherited: true }), { label: 'On (inherited)', tone: 'on' });
  assert.deepEqual(profileStateLabel({ enabled: false, inherited: true }), { label: 'Off (inherited)', tone: 'off' });
  assert.deepEqual(profileStateLabel({ enabled: false, overridden: true }), { label: 'Off in this profile', tone: 'off' });
  assert.deepEqual(profileStateLabel({ enabled: true, overridden: true }), { label: 'On in this profile', tone: 'on' });
  assert.deepEqual(profileStateLabel(null), { label: 'Not in this profile', tone: 'none' });
});

test('profiles are listed parent first with their depth, so inheritance reads as a tree', () => {
  const ps = [
    { id: 'stricter', name: 'Stricter', parentId: 'strict' },
    { id: 'default', name: 'Default', parentId: null },
    { id: 'strict', name: 'Strict', parentId: 'default' },
    { id: 'other', name: 'Other', parentId: null },
  ];
  assert.deepEqual(profileOrder(ps).map(x => [x.profile.id, x.depth]), [['default', 0], ['strict', 1], ['stricter', 2], ['other', 0]]);
  assert.deepEqual(profileOrder([{ id: 'orphan', name: 'O', parentId: 'gone' }]).map(x => x.depth), [0], 'a missing parent does not hide a profile');
});

const form = (over = {}) => ({
  ...emptyForm(), id: ' my-eval ', language: 'javascript', kind: 'pattern', pattern: 'eval\\(', files: '**/*.js, **/*.mjs\n  ', severity: 'HIGH',
  title: 'eval', description: '', remediation: ' Use JSON.parse ', cwe: 'CWE-95', detect: 'eval(x);', clean: 'run(x);', ...over,
});

test('the form becomes a rule: trimmed, files split, empty optional fields dropped', () => {
  assert.deepEqual(formToRule(form()), {
    id: 'my-eval', language: 'javascript', severity: 'HIGH', title: 'eval', pattern: 'eval\\(', files: ['**/*.js', '**/*.mjs'],
    remediation: 'Use JSON.parse', cwe: 'CWE-95', fixture: { detect: 'eval(x);', clean: 'run(x);' },
  });
});

test('a syntax-tree rule carries a query and no files', () => {
  const rule = formToRule(form({ kind: 'query', query: '(call_expression) @sink', pattern: 'ignored', files: '**/*.js' }));
  assert.equal(rule.query, '(call_expression) @sink');
  assert.equal(rule.pattern, undefined);
  assert.equal(rule.files, undefined);
});

test('a rule becomes a form and back without losing anything', () => {
  const rule = formToRule(form());
  assert.deepEqual(formToRule(ruleToForm(rule)), rule);
  const ast = formToRule(form({ kind: 'query', query: '(a) @sink' }));
  assert.deepEqual(formToRule(ruleToForm(ast)), ast);
  assert.equal(ruleToForm(ast).kind, 'query');
  assert.equal(ruleToForm({ ...rule, fixture: undefined }).detect, '', 'a rule saved without samples still opens');
});

test('the form is checked before the test button is worth pressing', () => {
  assert.deepEqual(formProblems(form()), []);
  const bad = formProblems(form({ id: '', language: '', pattern: '', detect: '', clean: '', title: '' }));
  for (const field of ['id', 'language', 'pattern', 'detect', 'clean', 'title']) assert.ok(bad.some(p => p.field === field), field);
  assert.ok(formProblems(form({ kind: 'query', query: '' })).some(p => p.field === 'query'));
  assert.ok(formProblems(form({ files: '' })).some(p => p.field === 'files'), 'a line pattern needs a file glob');
  assert.equal(formProblems(form({ kind: 'query', query: '(a) @sink', files: '' })).some(p => p.field === 'files'), false);
  assert.ok(formProblems(form({ id: 'has space' })).some(p => p.field === 'id'));
});

test('Save is allowed only for the exact content that last passed its test', () => {
  const f = form();
  const passed = { ok: true, signature: signatureOf(f) };
  assert.equal(canSave(f, passed), true);
  assert.equal(canSave(f, null), false, 'never tested');
  assert.equal(canSave(f, { ok: false, signature: signatureOf(f) }), false, 'tested and failed');
  assert.equal(canSave(form({ pattern: 'exec\\(' }), passed), false, 'edited since the test');
  assert.equal(canSave(form({ detect: 'eval(y);' }), passed), false, 'a sample was edited');
  assert.equal(canSave(form({ id: '' }), { ok: true, signature: signatureOf(form({ id: '' })) }), false, 'a form with problems never saves');
  assert.equal(canSave(form({ cwe: 'CWE-1' }), passed), false, 'any field counts');
});

test('a test report is explained in plain words', () => {
  const pass = explainTestReport({ ok: true, file: 'sample.js', detect: { found: 2 }, clean: { found: 0 }, errors: [] });
  assert.equal(pass.title, 'Passed');
  assert.deepEqual(pass.lines, ['Fired on the detect sample (2 findings, saved as sample.js)', 'Stayed silent on the clean sample']);
  const fail = explainTestReport({ ok: false, errors: ['the pattern does not compile: x', 'another'] });
  assert.equal(fail.title, 'Failed');
  assert.deepEqual(fail.lines, ['the pattern does not compile: x', 'another']);
  assert.equal(explainTestReport({ ok: true, file: 'a.js', detect: { found: 1 }, clean: { found: 0 }, errors: [] }).lines[0], 'Fired on the detect sample (1 finding, saved as a.js)');
});

test('the detail view decides what may be edited from the rule\'s origin', () => {
  const user = ruleDetailModel({ id: 'U1', origin: 'user', status: 'ACTIVE', version: 3, body: { id: 'U1', title: 't', pattern: 'x' } });
  assert.deepEqual([user.editable, user.deprecatable, user.readOnlyReason], [true, true, null]);
  const builtin = ruleDetailModel({ id: 'B1', origin: 'builtin', status: 'ACTIVE', body: { id: 'B1', title: 't', provenance: { source: 'gitleaks', license: 'MIT' } } });
  assert.deepEqual([builtin.editable, builtin.deprecatable], [false, false]);
  assert.match(builtin.readOnlyReason, /built-in/i);
  assert.equal(builtin.source, 'gitleaks');
  assert.equal(ruleDetailModel({ id: 'D', origin: 'user', status: 'DEPRECATED', body: {} }).deprecatable, false, 'already deprecated');
});

const { editPatch } = require('./security-rules');

test('an edit sends what changed shape as explicit removals, so switching how a rule matches drops the old half', () => {
  const original = { id: 'U1', language: 'javascript', severity: 'HIGH', title: 't', pattern: 'eval\\(', files: ['**/*.js'], cwe: 'CWE-95', description: 'd', fixture: { detect: 'a', clean: 'b' } };
  const toQuery = formToRule({ ...ruleToForm(original), kind: 'query', query: '(call_expression) @sink', cwe: '', description: '' });
  assert.deepEqual(editPatch(toQuery, original), {
    language: 'javascript', severity: 'HIGH', title: 't', query: '(call_expression) @sink',
    pattern: null, files: null, cwe: null, description: null,
    fixture: { detect: 'a', clean: 'b' },
  }, 'the id is not part of a patch, and every optional field the edit dropped is an explicit null');
  const same = editPatch(formToRule(ruleToForm(original)), original);
  assert.equal(same.pattern, 'eval\\(');
  assert.equal(same.query, undefined);
  assert.equal(same.cwe, 'CWE-95');
});
