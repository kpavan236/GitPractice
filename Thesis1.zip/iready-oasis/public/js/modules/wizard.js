// =============================================================================
// Wizard — onboarding steps, GitHub/Jenkins validation, session creation, enterApp()
// =============================================================================
// Stored in a COOKIE (like the PAT), not localStorage. The Electron app serves
// on a random port each launch; cookies are keyed by host (port-agnostic) so
// they survive, whereas localStorage is per-origin (host+port) and gets wiped.
function saveJenkinsCredentials(data) {
  const token = data && data.token;
  if (token) setCookie(JENKINS_COOKIE, token, TOKEN_COOKIE_DAYS);
  try { localStorage.removeItem(JENKINS_KEY); } catch (_) {}   // drop stale legacy copy
}
function loadJenkinsCredentials() {
  const cookieTok = getCookie(JENKINS_COOKIE);
  if (cookieTok) return { token: cookieTok };
  // One-time migration from the old localStorage location.
  try {
    const legacy = JSON.parse(localStorage.getItem(JENKINS_KEY) || 'null');
    if (legacy?.token) { setCookie(JENKINS_COOKIE, legacy.token, TOKEN_COOKIE_DAYS); return legacy; }
  } catch (_) {}
  return null;
}
function clearJenkinsCredentials() {
  deleteCookie(JENKINS_COOKIE);
  try { localStorage.removeItem(JENKINS_KEY); } catch (_) {}
}

// Opens the Jenkins page for managing your own API token. Not just
// "<base>/me/configure" — that 404s on this Jenkins instance. The path that
// actually works needs the user's own login: "<base>/user/<login>/security/".
// GitHub login usually IS the Jenkins login for this org, so it's used when
// already known (post-validation); otherwise /api/whoami's local machine
// username is the same fallback the Jenkins validation flow itself uses
// elsewhere. /me/configure is kept only as a last resort when neither is
// available, so the link still goes SOMEWHERE rather than nowhere.
async function openJenkinsSecurityPage(inputId) {
  const base = (document.getElementById(inputId)?.value || '').trim().replace(/\/$/, '');
  if (!base) return;
  let login = cfg.githubLogin || '';
  if (!login) {
    try { login = (await fetch(`${API}/api/whoami`).then(r => r.json())).username || ''; } catch (_) {}
  }
  const url = login ? `${base}/user/${encodeURIComponent(login)}/security/` : `${base}/me/configure`;
  window.open(url, '_blank');
}

function prefillWizard() {
  if (cfg.githubUrl)  document.getElementById('w-ghurl').value      = cfg.githubUrl;
  if (cfg.org)        document.getElementById('w-org').value        = cfg.org;
  if (cfg.jenkinsUrl) document.getElementById('w-jenkins-url').value = cfg.jenkinsUrl;

  // Prefill both tokens if previously remembered.
  const savedToken = getCookie(TOKEN_COOKIE);
  if (savedToken) {
    const tokenInput = document.getElementById('w-token');
    if (tokenInput) tokenInput.value = savedToken;
  }
  const jk = loadJenkinsCredentials();
  if (jk?.token) {
    const tokenEl = document.getElementById('w-jenkins-token');
    if (tokenEl) tokenEl.value = jk.token;
  }
  // If tokens were saved before, keep the single "remember" box checked.
  // (First run: the HTML default is already checked.)
  const rememberBox = document.getElementById('w-remember-tokens');
  if (rememberBox && (savedToken || jk?.token)) rememberBox.checked = true;

  // Auto-trigger validation if fields are pre-filled AND the wizard is still visible.
  // Skip if autoResume already logged in (wizard will be hidden by then).
  setTimeout(() => {
    if (document.getElementById('wizard')?.style.display === 'none') return;
    if (document.getElementById('main-app')?.classList.contains('hidden') === false) return;
    const url   = document.getElementById('w-ghurl')?.value.trim();
    const org   = document.getElementById('w-org')?.value.trim();
    const token = document.getElementById('w-token')?.value.trim();
    // Kick off GitHub (PAT) and Jenkins checks in parallel — neither waits for
    // the other. Jenkins falls back to /api/whoami for the username when the
    // GitHub login isn't known yet, so it validates independently.
    if (url && org && token) scheduleGhValidation();
    const jUrl = document.getElementById('w-jenkins-url')?.value.trim();
    const jTok = document.getElementById('w-jenkins-token')?.value.trim();
    if (jUrl && jTok) scheduleJkValidation();
  }, 500);  // wait 500ms so autoResume has time to complete first
}

// ── Wizard auto-validation ──────────────────────────────────────────────────
let _ghValidated = false;
let _jkValidated = false;
let _ghTimer = null;
let _jkTimer = null;

// The message can contain server text — a GitHub error, a proxy's HTML error
// page — and this writes innerHTML in order to hold the Retry button. Escaped
// here rather than at every call site, because the one call site that forgets
// turns an error path into an injection point.
function escapeWiz(text) {
  return String(text == null ? '' : text).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

/**
 * @param {string} elId
 * @param {string} state   'ok' | 'error' | 'checking' | ''
 * @param {string} msg
 * @param {string} retry   name of a global to call to try again; adds a button
 */
function setWizStatus(elId, state, msg, retry = null) {
  const el = document.getElementById(elId);
  if (!el) return;
  const colors = { ok: 'var(--green)', error: 'var(--red)', checking: 'var(--text3)', '': 'var(--text3)' };
  const icons  = { ok: '✓ ', error: '✗ ', checking: '⋯ ', '': '' };
  el.style.color = colors[state] || 'var(--text3)';

  // A failed check with no way to re-run it leaves the user editing a field
  // they did not get wrong — retyping the same token to make the debounce fire
  // again. The button is the difference between "try again" and "start over".
  el.innerHTML = escapeWiz((icons[state] || '') + msg)
    + (state === 'error' && retry
        ? ` <button type="button" class="wiz-retry" onclick="${retry}()">Retry</button>`
        : '');
}

// Re-runs a check immediately. The 700ms debounce exists to avoid validating on
// every keystroke; a retry is a deliberate act and should not wait for it.
async function retryWizCheck(elId, run) {
  setWizStatus(elId, 'checking', 'Checking…');
  await run();
}

function retryGitHubCheck() { return retryWizCheck('w-gh-status', validateGitHub); }
function retryJenkinsCheck() { return retryWizCheck('w-jenkins-status', validateJenkins); }

// A response that is not JSON is the normal shape of an infrastructure failure:
// a proxy or a load balancer answering with an HTML error page. Without this the
// user is shown `Unexpected token '<'`, which describes our parser rather than
// their problem.
async function readWizJson(resp) {
  const text = await resp.text();
  try {
    return JSON.parse(text);
  } catch (_) {
    throw new Error(
      resp.status >= 400
        ? `The server answered ${resp.status} ${resp.statusText || ''}`.trim()
        : 'The server sent a response that was not JSON — something is between OASIS and the service'
    );
  }
}

// `fetch` rejects with "Failed to fetch" when it cannot reach the host at all.
// That is our OWN local server, so it means OASIS's backend is not running —
// worth saying, because it is a different fix from a bad token.
function wizNetworkMessage(e) {
  return /failed to fetch|networkerror|load failed/i.test(e.message || '')
    ? 'Could not reach the OASIS backend — is the app still running?'
    : e.message;
}

function updateConnectBtn() {
  const btn = document.getElementById('wiz-connect-btn');
  if (!btn) return;
  // Both GitHub AND Jenkins must be verified before connecting
  const ready = _ghValidated && _jkValidated;
  btn.disabled = !ready;
}

function updateWizStatusRow() {
  const row = document.getElementById('wiz-status-row');
  if (!row) return;
  const chip = (label, ok) =>
    `<span style="font-size:11px;font-family:var(--mono);padding:2px 9px;border-radius:100px;border:1px solid;
      ${ok ? 'color:var(--green);border-color:rgba(34,197,94,.4);background:rgba(34,197,94,.08)'
           : 'color:var(--text3);border-color:var(--border)'}">${label} ${ok ? '✓' : '—'}</span>`;
  row.innerHTML = chip('GitHub', _ghValidated) + chip('Jenkins', _jkValidated);
}

// Debounced trigger — called on every input change
function scheduleGhValidation() {
  _ghValidated = false;
  updateConnectBtn();
  clearTimeout(_ghTimer);
  const url   = document.getElementById('w-ghurl')?.value.trim();
  const org   = document.getElementById('w-org')?.value.trim();
  const token = document.getElementById('w-token')?.value.trim();
  if (!url || !org || !token) { setWizStatus('w-gh-status', '', ''); updateWizStatusRow(); return; }
  setWizStatus('w-gh-status', 'checking', 'Checking…');
  _ghTimer = setTimeout(validateGitHub, 700);
}

function scheduleJkValidation() {
  _jkValidated = false;
  updateConnectBtn();
  clearTimeout(_jkTimer);
  const url   = document.getElementById('w-jenkins-url')?.value.trim();
  const token = document.getElementById('w-jenkins-token')?.value.trim();
  if (!url || !token) { setWizStatus('w-jenkins-status', '', ''); updateWizStatusRow(); return; }
  setWizStatus('w-jenkins-status', 'checking', 'Checking…');
  _jkTimer = setTimeout(validateJenkins, 700);
}

async function validateGitHub() {
  const url   = document.getElementById('w-ghurl')?.value.trim();
  const org   = document.getElementById('w-org')?.value.trim();
  const token = document.getElementById('w-token')?.value.trim();
  if (!url || !org || !token) return;
  try {
    const resp = await fetch(`${API}/api/validate-github`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ githubUrl: url, token }),
    });
    const data = await readWizJson(resp);
    if (!data.ok) throw new Error(data.error || 'Connection failed');
    cfg = { ...cfg, githubUrl: url, org, token, githubLogin: data.githubLogin || '' };
    _ghValidated = true;
    setWizStatus('w-gh-status', 'ok', `Connected as ${data.githubLogin || org}`);
    // Note: Jenkins validation runs independently (on prefill and on its own
    // input handler) — it is NOT chained off GitHub success, so the two checks
    // never wait for each other.
  } catch (e) {
    _ghValidated = false;
    setWizStatus('w-gh-status', 'error', wizNetworkMessage(e).replace(/^Invalid token — /, ''), 'retryGitHubCheck');
  }
  updateWizStatusRow();
  updateConnectBtn();
}

async function validateJenkins() {
  const url   = document.getElementById('w-jenkins-url')?.value.trim();
  const token = document.getElementById('w-jenkins-token')?.value.trim();
  if (!url || !token) return;
  // Use GitHub login if already known, else fall back to Mac username (same CA login)
  let user = cfg.githubLogin;
  if (!user) {
    try {
      const wd = await fetch(`${API}/api/whoami`).then(r => r.json());
      user = wd.username || '';
    } catch (_) {}
  }
  if (!user) {
    // Previously returned without updating the status row or the Connect
    // button, and with no way to try again — so a transient /api/whoami failure
    // left the wizard permanently stuck with no explanation.
    setWizStatus('w-jenkins-status', 'error', 'Could not determine your username', 'retryJenkinsCheck');
    _jkValidated = false;
    updateWizStatusRow();
    updateConnectBtn();
    return;
  }
  try {
    const resp = await fetch(`${API}/api/validate-jenkins`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jenkinsUrl: url, token, user }),
    });
    const data = await readWizJson(resp);
    if (!data.ok) throw new Error(data.error || 'Invalid token');
    _jkValidated = true;
    setWizStatus('w-jenkins-status', 'ok', 'Jenkins connected');
  } catch (e) {
    _jkValidated = false;
    setWizStatus('w-jenkins-status', 'error', wizNetworkMessage(e), 'retryJenkinsCheck');
  }
  updateWizStatusRow();
  updateConnectBtn();
}

// ── Wizard helpers — local config step ────────────────────────────────────

async function browseDirectory(inputId) {
  try {
    const resp = await fetch(`${API}/api/pick-directory`);
    const result = await resp.json();
    if (!result.canceled && result.filePaths && result.filePaths[0]) {
      document.getElementById(inputId).value = result.filePaths[0];
    } else if (result.canceled) {
      toast('Type the path manually — native picker only works in the desktop app', 'info');
    }
  } catch (e) {
    toast('Could not open directory picker', 'info');
  }
}

async function detectTools(ijId = 's-ij-input', javaId = 's-java-input') {
  const btn = document.getElementById('s-detect-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Detecting…'; }

  try {
    const resp = await fetch(`${API}/api/detect-tools`);
    if (!resp.ok) throw new Error('Detection failed');
    const tools = await resp.json();

    let found = [];
    const ijEl = document.getElementById(ijId);
    const javaEl = document.getElementById(javaId);
    if (tools.intellijPath && ijEl) { ijEl.value = tools.intellijPath; found.push('IntelliJ CLI'); }
    if (tools.javaHome && javaEl)   { javaEl.value = tools.javaHome;   found.push('Java Home'); }

    if (found.length) toast(`Auto-detected: ${found.join(', ')}`, 'success');
    else              toast('No tools auto-detected — enter paths manually', 'info');
  } catch (e) {
    toast('Auto-detect failed: ' + e.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '⚡ Auto-detect'; }
  }
}

// ── Wizard ─────────────────────────────────────────────────────────────────
let wizStep = 1;

async function wizNext(step) {
  if (step === 1) {
    const url   = document.getElementById('w-ghurl').value.trim();
    const org   = document.getElementById('w-org').value.trim();
    const token = document.getElementById('w-token').value.trim();
    const jenkinsUrl = document.getElementById('w-jenkins-url').value.trim();
    if (!url || !org || !token || !jenkinsUrl) { toast('All fields are required', 'error'); return; }
    if (!_ghValidated) { toast('GitHub PAT verification must succeed before connecting', 'error'); return; }
    if (!_jkValidated) { toast('Jenkins token verification must succeed before connecting', 'error'); return; }

    const btn = document.querySelector('#wpage-1 .btn-primary');
    btn.textContent = 'Connecting…'; btn.disabled = true;

    try {
      const cloneDir    = cfg.cloneDir    || '~/dev/projects';
      const intellijPath = cfg.intellijPath || '';
      const javaHome    = cfg.javaHome    || '';
      const mavenArgs   = cfg.mavenArgs   || '';
      const extraEnv    = cfg.extraEnv    || '';
      const jenkinsToken    = document.getElementById('w-jenkins-token')?.value.trim() || '';

      // Always create a fresh session on Connect so it has the latest Jenkins token.
      {
        const resp = await fetch(`${API}/api/session`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ githubUrl: url, org, token, cloneDir, intellijPath, mavenArgs, extraEnv, awsProfile: cfg.awsProfile || '', jenkinsUrl, jenkinsToken,
            aiEnabled: cfg.aiEnabled !== false, aiProvider: cfg.aiProvider || '', aiModel: cfg.aiModel || '', aiHost: cfg.aiHost || '', aiApiKey: loadAiApiKey() })
        });
        if (!resp.ok) throw new Error((await resp.json()).error);
        const data = await resp.json();
        sessionId = data.sessionId;
        cfg = { ...cfg, githubUrl: url, org, token, cloneDir, intellijPath, javaHome, mavenArgs, extraEnv,
          jenkinsUrl, jenkinsToken, githubLogin: data.githubLogin || cfg.githubLogin || '' };
      }

      // Single toggle controls BOTH tokens: remember & reuse, or clear both so
      // the user must re-enter them next launch.
      const rememberTokens = document.getElementById('w-remember-tokens')?.checked;
      if (rememberTokens) {
        setCookie(TOKEN_COOKIE, token, TOKEN_COOKIE_DAYS);
        if (jenkinsToken) saveJenkinsCredentials({ token: jenkinsToken });
      } else {
        deleteCookie(TOKEN_COOKIE);
        clearJenkinsCredentials();
      }
      saveCache();

      // The customer has just given us a working GitHub and Jenkins connection: this is the
      // moment the trial starts (and the machine and those addresses are logged). If it
      // cannot start, the licence screen says why and setup stays on this page.
      if (!(await ensureLicenseReady())) return;

      // Skip local config step — go straight to Ready
      wizGoTo(2);
      document.getElementById('ready-org-label').textContent = `${org} on ${url}`;

      const showOpenButton = () => {
        document.getElementById('ready-spinner').style.display = 'none';
        document.getElementById('ready-btn').style.display = 'inline-flex';
      };
      if (externalCallsOn()) {
        fetchAllRepos().then(showOpenButton);
      } else {
        // GitHub calls are switched off, so there is nothing to wait for.
        const desc = document.getElementById('ready-desc');
        if (desc) desc.innerHTML = `Connected to <strong>${escHtml(org)}</strong>. GitHub and Jenkins calls are switched off, so repositories are not loaded. You can turn them on in Settings.`;
        showOpenButton();
      }
    } catch(err) {
      toast('Connection failed: ' + err.message, 'error');
    } finally {
      btn.textContent = 'Connect →'; btn.disabled = false;
    }
  }
}

function wizBack(step) {
  wizGoTo(1);
}

function wizGoTo(n) {
  wizStep = n;
  document.querySelectorAll('.wiz-page').forEach((p, i) => {
    p.classList.toggle('active', i + 1 === n);
  });
  document.querySelectorAll('.wiz-step').forEach((s, i) => {
    s.classList.remove('active', 'done');
    if (i + 1 === n) s.classList.add('active');
    if (i + 1 < n)  s.classList.add('done');
  });
}

// Re-creates the server session using cached credentials. Returns true on success.
async function reconnectSession() {
  const jenkinsToken = cfg.jenkinsToken || loadJenkinsCredentials()?.token || '';
  if (!cfg.githubUrl || !cfg.org || !cfg.token || !cfg.cloneDir || !cfg.jenkinsUrl || !jenkinsToken) return false;
  try {
    const resp = await fetch(`${API}/api/session`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        githubUrl: cfg.githubUrl, org: cfg.org, token: cfg.token,
        cloneDir: cfg.cloneDir, intellijPath: cfg.intellijPath || '',
        mavenArgs: cfg.mavenArgs || '', extraEnv: cfg.extraEnv || '',
        awsProfile: cfg.awsProfile || '',
        jenkinsUrl: cfg.jenkinsUrl, jenkinsToken,
        aiEnabled: cfg.aiEnabled !== false, aiProvider: cfg.aiProvider || '', aiModel: cfg.aiModel || '',
        aiHost: cfg.aiHost || '', aiApiKey: loadAiApiKey(),
      }),
    });
    if (!resp.ok) return false;
    sessionId = (await resp.json()).sessionId;
    connectWebSocket();
    applySavedSudoPassword();
    // Re-creating the session above starts a fresh, JIRA-less session object
    // server-side — re-attach JIRA from the saved cookie/prefs so tabs that
    // depend on it don't intermittently see "Connect JIRA first".
    await autoConnectJira();
    await autoConnectPerfDiagnostics();
    return true;
  } catch { return false; }
}

function showSessionExpired() {
  toast('Session expired — reconnecting…', 'info');
  // Fall back to the wizard so the user can re-authenticate
  document.getElementById('main-app').classList.add('hidden');
  document.getElementById('wizard').style.display = '';
  wizGoTo(1);
}

async function enterApp() {
  // Safety net: the trial normally started when setup connected, so this is a no-op.
  if (typeof ensureLicenseReady === 'function' && !(await ensureLicenseReady())) return false;
  document.getElementById('wizard').style.display = 'none';
  document.getElementById('main-app').classList.remove('hidden');
  renderTopbar();
  connectWebSocket();
  applySavedSudoPassword();
  silentLoadEpRepos();
  autoConnectJira();          // also warms the JIRA history cache in the background
  autoConnectPerfDiagnostics();
  if (externalCallsOn()) prefetchDependencyGraph();  // warm the deps-tab cache (it reads GitHub, so only when calls are on)
  else showReposSwitchedOff();                        // say so, rather than leave a spinner that never finishes
  prefetchDockerServices();   // warm the docker-tab cache in the background
  renderExternalCallsChip();
  return true;
}

async function silentLoadEpRepos() {
  if (!sessionId) return;
  try {
    const resp = await fetch(`${API}/api/existing-repos?session=${sessionId}`);
    if (!resp.ok) return;
    const data = await resp.json();
    epRepos = data.repos || [];
    if (filteredRepos.length) renderRepoList();
  } catch (e) { /* silent */ }
}

// Silently apply the saved Mac password to the session so setup scripts
// never need to prompt. If the saved password is wrong (changed since saved),
// clear it so the user is prompted fresh next time.
async function applySavedSudoPassword() {
  const pw = loadSudoPassword();
  if (!pw || !sessionId) return;
  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (!data.ok) {
      clearSudoPassword();
    }
  } catch (e) { /* silent — non-critical */ }
}

// ── "How do I get a token?" accordion ───────────────────────────────────────
// Native <details> elements are independent by default. Enforce single-open:
// opening one collapses any other that was open. `toggle` doesn't bubble, so
// listen on each element directly (capture is unnecessary here).
(function initPatHelpAccordion() {
  const items = document.querySelectorAll('.pat-help');
  items.forEach(el => {
    el.addEventListener('toggle', () => {
      if (!el.open) return;
      items.forEach(other => { if (other !== el && other.open) other.open = false; });
    });
  });
})();
