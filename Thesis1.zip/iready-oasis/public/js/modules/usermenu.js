// =============================================================================
// User menu — the dropdown under the username in the topbar
// =============================================================================
// About / Feedback / Contact Support. Feedback and Contact Support are sent by
// the OASIS server to the support service (server/support-client.js). The page
// shows the reference the service gave back, or says plainly when the words were
// only kept on this computer because support could not be reached.

const MAX_SUPPORT_TITLE = 120;

// Fires once after an update lands (electron/main.js waits for this page to
// finish loading before sending it, so registering here at script-load time —
// well before that — never misses it). Not available outside the desktop
// app, same as the other window.electronAPI-gated features here. Guarded on
// `typeof window` because this file is also `require()`d directly by its own
// test (see the module.exports note below), where there is no DOM at all.
function renderWhatsNew({ version, previousVersion, notes }) {
  document.getElementById('whats-new-title').textContent = `What's new in ${version}`;
  document.getElementById('whats-new-subtitle').textContent = previousVersion ? `Updated from ${previousVersion}` : '';
  document.getElementById('whats-new-notes').textContent = notes || 'No release notes for this version.';
  document.getElementById('whats-new-modal')?.classList.remove('hidden');
}

if (typeof window !== 'undefined') {
  window.electronAPI?.onShowWhatsNew?.((data) => {
    // #whats-new-modal lives inside #main-app, which starts hidden and is
    // only revealed once the wizard's auto-resume (async — it validates
    // saved credentials over the network) succeeds. This event can arrive
    // before that swap happens, and unhiding the modal itself does nothing
    // while its ancestor still is hidden — the moment would be silently
    // lost. Wait for #main-app to actually be visible before rendering it.
    const mainApp = document.getElementById('main-app');
    if (mainApp && !mainApp.classList.contains('hidden')) {
      renderWhatsNew(data);
      return;
    }
    const poll = setInterval(() => {
      if (!document.getElementById('main-app')?.classList.contains('hidden')) {
        clearInterval(poll);
        renderWhatsNew(data);
      }
    }, 300);
  });
}

function toggleUserMenu() {
  const panel = document.getElementById('user-menu-panel');
  if (!panel) return;
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) {
    setTimeout(() => document.addEventListener('click', closeUserMenuOnce), 0);
  }
}

function closeUserMenuOnce(event) {
  if (event.target.closest('.user-menu')) return;
  document.getElementById('user-menu-panel')?.classList.add('hidden');
  document.removeEventListener('click', closeUserMenuOnce);
}

// Feedback is shown, if any, via the main process's own dialog/toast — this
// only closes the panel and fires the check; there is nothing to await here
// (checkForUpdates is only exposed as ipcRenderer.send, not invoke) and no
// separate outside-the-desktop-app fallback, same as getAppVersion above.
function checkForUpdatesFromMenu() {
  document.getElementById('user-menu-panel')?.classList.add('hidden');
  if (window.electronAPI?.checkForUpdates) window.electronAPI.checkForUpdates();
  else toast('Updates are only available in the desktop app.', 'info');
}

async function openAboutModal() {
  document.getElementById('user-menu-panel')?.classList.add('hidden');
  const version = (await window.electronAPI?.getAppVersion?.()) || null;
  const body = document.getElementById('about-modal-body');
  if (body) {
    body.querySelector('#about-version').textContent = version ? `Version ${version}` : 'Version unknown';
  }
  document.getElementById('about-modal')?.classList.remove('hidden');
}

// One key per time the dialog is opened: a double click, or a retry after a dropped
// connection, then reaches support once instead of twice.
let feedbackKey = null;
let supportKey = null;
const newSubmitKey = () => (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : `k-${Date.now()}-${Math.random().toString(36).slice(2)}`);

async function prefillContact(emailId, nameId) {
  try {
    const resp = await fetch(`${API}/api/support/prefill?session=${encodeURIComponent(sessionId || '')}`);
    if (!resp.ok) return;
    const who = await resp.json();
    const email = document.getElementById(emailId);
    const name = nameId && document.getElementById(nameId);
    if (email && !email.value) email.value = who.email || '';
    if (name && !name.value) name.value = who.name || '';
  } catch (_) { /* a blank form is fine */ }
}

function openFeedbackModal() {
  document.getElementById('user-menu-panel')?.classList.add('hidden');
  document.getElementById('feedback-message-input').value = '';
  document.getElementById('feedback-category-input').value = 'idea';
  document.getElementById('feedback-email-input').value = '';
  feedbackKey = newSubmitKey();
  document.getElementById('feedback-modal')?.classList.remove('hidden');
  prefillContact('feedback-email-input');
}

async function submitFeedback() {
  const message = document.getElementById('feedback-message-input')?.value;
  const category = document.getElementById('feedback-category-input')?.value;
  const email = document.getElementById('feedback-email-input')?.value;
  if (!String(message || '').trim()) {
    toast('Say something before submitting.', 'error');
    return;
  }
  const contact = validateContactDetails({ email }, { emailRequired: false, nameRequired: false });
  if (!contact.valid) {
    toast(contact.error, 'error');
    return;
  }
  try {
    const resp = await fetch(`${API}/api/feedback`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, message, category, email, idempotencyKey: feedbackKey }),
    });
    const result = describeSubmitResult(resp.status, await resp.json().catch(() => null));
    if (result.kind !== 'error') closeModal('feedback-modal');
    toast(result.message, result.kind);
  } catch (e) {
    toast(e.message, 'error');
  }
}

function openContactSupportModal() {
  document.getElementById('user-menu-panel')?.classList.add('hidden');
  document.getElementById('support-title-input').value = '';
  document.getElementById('support-description-input').value = '';
  document.getElementById('support-name-input').value = '';
  document.getElementById('support-email-input').value = '';
  supportKey = newSubmitKey();
  document.getElementById('support-modal')?.classList.remove('hidden');
  prefillContact('support-email-input', 'support-name-input');
}

/**
 * Whether a support ticket is complete enough to submit.
 *
 * Pulled out as its own pure function because it is the one piece of this
 * form with real logic — everything else is DOM wiring — and it is what the
 * eventual real submit call will run before making a network request.
 */
function validateSupportTicket({ title, description } = {}) {
  const t = String(title || '').trim();
  const d = String(description || '').trim();
  if (!t) return { valid: false, error: 'A title is required.' };
  if (t.length > MAX_SUPPORT_TITLE) return { valid: false, error: `Title must be ${MAX_SUPPORT_TITLE} characters or fewer.` };
  if (!d) return { valid: false, error: 'A description is required.' };
  return { valid: true, error: null };
}

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Whether the name and email on a form are good enough to send. Support replies by email, so Contact Support needs both; Feedback needs neither. */
function validateContactDetails({ contactName, email } = {}, { nameRequired = true, emailRequired = true } = {}) {
  const n = String(contactName || '').trim();
  const e = String(email || '').trim();
  if (nameRequired && !n) return { valid: false, error: 'Your name is required so support knows who to reply to.' };
  if (emailRequired && !e) return { valid: false, error: 'An email address is required so support can reply.' };
  if (e && !EMAIL_SHAPE.test(e)) return { valid: false, error: 'Enter a valid email address.' };
  return { valid: true, error: null };
}

/** The server's answer to a feedback or support submission, as the one message and style the person sees. */
function describeSubmitResult(status, body) {
  const b = body || {};
  if (status === 200 && b.reference) return { kind: 'success', message: `Thanks — received. Your reference is ${b.reference}.` };
  if (status === 202 && b.savedLocally) {
    return { kind: 'warning', message: 'Could not reach support just now, so this is saved on this computer. Please send it again later.' };
  }
  const field = b.errors && Object.values(b.errors)[0];
  return { kind: 'error', message: [b.error, field].filter(Boolean).join(' ') || 'Submission failed.' };
}

async function submitSupportTicket() {
  const title = document.getElementById('support-title-input')?.value;
  const description = document.getElementById('support-description-input')?.value;
  const contactName = document.getElementById('support-name-input')?.value;
  const email = document.getElementById('support-email-input')?.value;
  const result = validateSupportTicket({ title, description });
  if (!result.valid) {
    toast(result.error, 'error');
    return;
  }
  const contact = validateContactDetails({ contactName, email });
  if (!contact.valid) {
    toast(contact.error, 'error');
    return;
  }
  try {
    const resp = await fetch(`${API}/api/support`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, title, description, contactName, email, idempotencyKey: supportKey }),
    });
    const outcome = describeSubmitResult(resp.status, await resp.json().catch(() => null));
    if (outcome.kind !== 'error') closeModal('support-modal');
    toast(outcome.message, outcome.kind);
  } catch (e) {
    toast(e.message, 'error');
  }
}

// Exported for tests only — see the note in security-scan.js. The browser
// loads this as a plain script, where `module` is undefined.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { validateSupportTicket, validateContactDetails, describeSubmitResult };
}