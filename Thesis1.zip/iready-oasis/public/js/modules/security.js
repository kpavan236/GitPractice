// =============================================================================
// Security — scanner status, risk-ordered findings, and the finding detail view
// =============================================================================
// Findings are ordered by RISK, not severity. That is the argument the risk
// engine makes: a HIGH on an internet-facing production service outranks a
// CRITICAL in a scratch repository, and a queue sorted by severity puts them in
// the wrong order. The detail view always shows the factor breakdown, because a
// score nobody can interrogate gets ignored the first time it looks wrong.

let _secFindings = [];
let _secDashboard = null;
// Severity, type and repository filter client-side off the loaded list; status
// refetches, because the server decides what "active" means and the
// resolved/suppressed findings are not in the loaded set at all.
//
// Repository used to ride on the search box. That was one code path instead of
// two, but it meant the dashboard could not tell "the user is looking at one
// repository" from "the user typed some text", and a scoped view has to know
// the difference to label itself honestly.
//
// A LIST, not one name: a scan covers several repositories, and the dashboard
// scopes itself to exactly the ones a scan just covered. Empty means all.
// `newCodeOnly` is a filter like the others rather than a separate view,
// because Clean as You Code is a lens on the same findings — a second screen
// would immediately disagree with the first about the counts.
let _secFilter = { type: null, severity: null, repositories: [], newCodeOnly: false, status: 'active' };
let _secScanPoll = null;
// Grouped rows for the current render, so the detail view can find one by id.
let _secGroups = new Map();
let _secLastScanId = null;


function secEscape(text) {
  return String(text ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

async function secFetch(url, options) {
  const resp = await fetch(`${API}/api/security${url}`, options);
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `Request failed (${resp.status})`);
  return data;
}

// ── Entry point, called by tabs.js ─────────────────────────────────────────

async function initSecurityTab() {
  // Coming back to the tab reopens the section you were in.
  if (typeof restoreSecuritySection === 'function') restoreSecuritySection();
  await Promise.all([loadSecurityRepos(), refreshSecurity()]);
}

// The scanner availability strip lived here. Removed with its state and its
// /scanners fetch: it printed thirteen rows of largely static text above the
// results, and the scan's coverage report answers the same question better —
// which scanner analysed which capability, and why an absent optional tool did
// or did not leave a gap, stated about a real scan instead of in the abstract.

let _secRepos = [];
let _secSelected = new Set();

const SEC_REPO_STORAGE = 'oasis_security_selected_repos';

async function loadSecurityRepos() {
  try {
    const { repositories } = await secFetch('/repositories');
    _secRepos = repositories;

    // Restore the previous selection. A scan sweep is something people repeat,
    // and re-ticking twelve boxes every time is how a feature stops being used.
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem(SEC_REPO_STORAGE) || '[]'); } catch (e) {}
    const known = new Set(_secRepos.map(r => r.name));
    _secSelected = new Set(saved.filter(n => known.has(n)));

    // Nothing remembered: preselect what has been scanned before, falling back
    // to nothing rather than silently arming a scan of 250 repositories.
    if (!_secSelected.size) {
      for (const r of _secRepos) if (r.scanned) _secSelected.add(r.name);
    }
  } catch (e) {
    _secRepos = [];
  }
  renderSecurityRepoList();
  updateSecurityRepoLabel();
}

function persistSecuritySelection() {
  try { localStorage.setItem(SEC_REPO_STORAGE, JSON.stringify([..._secSelected])); } catch (e) {}
}

function updateSecurityRepoLabel() {
  const label = document.getElementById('sec-repo-label');
  const btn = document.getElementById('sec-scan-btn');
  if (!label) return;

  const n = _secSelected.size;
  const total = _secRepos.length;
  label.textContent =
    !total ? 'No local repositories'
    : n === 0 ? 'Select repositories'
    : n === total ? `All repositories (${total})`
    : n === 1 ? [..._secSelected][0]
    : `${n} repositories`;

  // Disabled rather than failing on submit — the reason is visible in the
  // label, so an error toast would only repeat it.
  if (btn) btn.disabled = n === 0;
}

function toggleSecurityRepoPicker() {
  const panel = document.getElementById('sec-repo-panel');
  if (!panel) return;
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) {
    document.getElementById('sec-repo-search')?.focus();
    // Close on the next outside click. Registered here rather than at load so
    // there is no listener running while the picker is shut.
    setTimeout(() => document.addEventListener('click', closeSecurityRepoPickerOnce), 0);
  }
}

function closeSecurityRepoPickerOnce(event) {
  if (event.target.closest('.sec-repo-picker')) return;
  document.getElementById('sec-repo-panel')?.classList.add('hidden');
  document.removeEventListener('click', closeSecurityRepoPickerOnce);
}

function renderSecurityRepoList() {
  const box = document.getElementById('sec-repo-list');
  if (!box) return;

  const query = (document.getElementById('sec-repo-search')?.value || '').toLowerCase();
  const shown = _secRepos.filter(r => !query || r.name.toLowerCase().includes(query));

  if (!shown.length) {
    box.innerHTML = `<div class="sec-repo-empty">${
      _secRepos.length ? 'No repository matches.' : 'No local clones found. Clone repositories from the Local Repos tab.'
    }</div>`;
    return;
  }

  box.innerHTML = shown
    .map(
      r => `<label class="sec-repo-item">
        <input type="checkbox" ${_secSelected.has(r.name) ? 'checked' : ''}
               onchange="toggleSecurityRepo('${secEscape(r.name)}', this.checked)">
        <span class="sec-repo-name">${secEscape(r.name)}</span>
        ${r.scanned ? '<span class="sec-repo-tag">scanned</span>' : ''}
      </label>`
    )
    .join('');
}

function toggleSecurityRepo(name, on) {
  if (on) _secSelected.add(name);
  else _secSelected.delete(name);
  persistSecuritySelection();
  updateSecurityRepoLabel();
}

function selectSecurityRepos(which) {
  // Applies to what the search is currently showing, so "All" after typing
  // "iready-" selects that set rather than every repository on disk.
  const query = (document.getElementById('sec-repo-search')?.value || '').toLowerCase();
  const shown = _secRepos.filter(r => !query || r.name.toLowerCase().includes(query));

  if (which === 'none') {
    for (const r of shown) _secSelected.delete(r.name);
  } else if (which === 'all') {
    for (const r of shown) _secSelected.add(r.name);
  } else if (which === 'scanned') {
    _secSelected = new Set(_secRepos.filter(r => r.scanned).map(r => r.name));
  }
  persistSecuritySelection();
  renderSecurityRepoList();
  updateSecurityRepoLabel();
}

// ── Dashboard ──────────────────────────────────────────────────────────────

async function refreshSecurity() {
  try {
    const [dashboard, findings] = await Promise.all([
      secFetch('/dashboard'),
      secFetch(`/findings?status=${encodeURIComponent(_secFilter.status)}`),
    ]);
    _secDashboard = dashboard;
    _secFindings = findings.findings;

    // A repository filter that survived a refresh but no longer matches
    // anything would leave the reader on an empty screen with no clue why.
    const known = new Set(_secFindings.map(f => f.repository));
    _secFilter.repositories = (_secFilter.repositories || []).filter(r => known.has(r));

    renderSecurityTopRisks();
    renderSecurityScoped();
  } catch (e) {
    document.getElementById('sec-table-body').innerHTML =
      `<tr><td colspan="6" class="docker-empty">${secEscape(e.message)}</td></tr>`;
  }
}




// A 60x18 sparkline of total open findings. Inline SVG rather than a chart
// library: it is nine lines of code and adds no dependency to a tool that must
// run offline.
function securitySparkline(history) {
  const points = (history || []).map(p => p.total);
  if (points.length < 2) return '';

  const max = Math.max(...points, 1);
  const step = 58 / (points.length - 1);
  const path = points.map((v, i) => `${(i * step + 1).toFixed(1)},${(17 - (v / max) * 15).toFixed(1)}`).join(' ');
  const rising = points[points.length - 1] > points[0];

  return `<svg class="sec-spark" viewBox="0 0 60 18" aria-hidden="true">
    <polyline points="${path}" fill="none" stroke="${rising ? 'var(--red)' : 'var(--green)'}" stroke-width="1.5"/>
  </svg>`;
}

// Down is good, so the arrow and colour are inverted relative to a normal
// metric — fewer open findings is an improvement.
function securityDelta(delta) {
  if (delta === null || delta === undefined || delta === 0) return '';
  const better = delta < 0;
  return `<span class="sec-delta ${better ? 'sec-delta-good' : 'sec-delta-bad'}">
    ${better ? '▼' : '▲'} ${Math.abs(delta)}
  </span>`;
}

function renderSecurityStats() {
  const box = document.getElementById('sec-stats');
  if (!box || !_secDashboard) return;

  // Counted from what the reader is looking at, not from the estate. A tile
  // reading 22 CRITICAL above a table showing three is the dashboard
  // contradicting itself, and the reader has no way to tell which half is
  // right.
  const base = scopeBase();
  const c = countBy(base, 'severity');
  for (const s of SEVERITY_ORDER) c[s] = c[s] || 0;
  const score = securityScore(c);
  const scoped = securityScopeChips().length > 0;

  document.getElementById('sec-summary').textContent = scoped
    ? `${base.length} open in scope · ${_secDashboard.total} total`
    : `${_secDashboard.total} open`;

  const tile = (label, value, cls = '') =>
    `<div class="sec-stat ${cls}"><div class="sec-stat-value">${value}</div><div class="sec-stat-label">${label}</div></div>`;

  // Marked, not hidden. Resolved, suppressed, the baseline and the trend are
  // server-side aggregates over every repository, and there is no way to
  // recompute them from the loaded set. Showing them unlabelled beside scoped
  // tiles would imply they were filtered too — quietly wrong in the direction
  // that flatters, which is the worst direction.
  const globalTile = (label, value, cls = '') =>
    tile(scoped ? `${label} · all repos` : label, value, `${cls} ${scoped ? 'sec-stat-global' : ''}`);

  const history = _secDashboard.history || [];
  const previous = history.length >= 2 ? history[history.length - 2] : null;
  const current = history[history.length - 1];
  const totalDelta = previous && current ? current.total - previous.total : null;

  const scanned = _secDashboard.lastScan
    ? `<button class="sec-link" onclick="showLastSecurityScan()">Last scan · ${
        secEscape(_secDashboard.lastScan.repositories ? _secDashboard.lastScan.repositories.length + ' repo(s)' : _secDashboard.lastScan.repository || '')
      }</button><br>${new Date(_secDashboard.lastScan.startedAt).toLocaleString()}${
        _secDashboard.lastScan.partial ? '<br><span class="sec-partial-note">partial coverage</span>' : ''
      }`
    : 'No scan has run yet';

  // Severity tiles are clickable: a number the reader is looking at is exactly
  // the number they want to see the rows for, and making them retype it in the
  // filter bar is work the dashboard could have done.
  const sevTile = (label, key, cls) =>
    `<button class="sec-stat sec-stat-click ${cls} ${_secFilter.severity === key ? 'sec-stat-active' : ''}"
       onclick="drillSecurity_severity('${key}')" title="Show ${label.toLowerCase()} findings">
       <div class="sec-stat-value">${c[key]}</div><div class="sec-stat-label">${label}</div>
     </button>`;

  box.innerHTML = `
    ${tile(
      `Security score · ${securityGrade(score)}${scoped ? ' · in scope' : ''}`,
      score,
      `sec-stat-score ${score >= 75 ? 'sec-stat-good' : score >= 45 ? 'sec-stat-warn' : 'sec-stat-bad'}`
    )}
    ${sevTile('Critical', 'CRITICAL', 'sec-stat-critical')}
    ${sevTile('High', 'HIGH', 'sec-stat-high')}
    ${sevTile('Medium', 'MEDIUM', 'sec-stat-medium')}
    ${sevTile('Low', 'LOW', 'sec-stat-low')}
    ${_secDashboard.baseline !== null && _secDashboard.newSinceBaseline !== null
        ? globalTile('New since baseline', _secDashboard.newSinceBaseline,
            _secDashboard.newSinceBaseline ? 'sec-stat-high' : 'sec-stat-good')
        : ''}
    ${globalTile('Resolved', _secDashboard.resolved, 'sec-stat-muted')}
    ${globalTile('Suppressed', _secDashboard.suppressed, 'sec-stat-muted')}
    ${history.length >= 2
        ? `<div class="sec-stat sec-stat-trend ${scoped ? 'sec-stat-global' : ''}">
             <div class="sec-stat-value">${securitySparkline(history)}${securityDelta(totalDelta)}</div>
             <div class="sec-stat-label">Open, last ${history.length} scans${scoped ? ' · all repos' : ''}</div>
           </div>`
        : ''}
    <div class="sec-stat-note">${scanned}</div>`;
}

// Four questions, four charts, each answering by filtering rather than by
// making the reader retype what the dashboard already knows.
function renderSecurityCharts() {
  const box = document.getElementById('sec-charts');
  if (!box || !_secDashboard) return;

  const d = _secDashboard;
  const filter = currentSecurityFilter();

  // Each chart is counted with its own dimension lifted, like the facets: a
  // repository chart that only ever shows the repository you already selected
  // is a chart you cannot navigate with.
  const base = scopeBase();
  const repoUniverse = scopeFindings(_secFindings, filter, { except: ['repository'] });
  const typeUniverse = scopeFindings(_secFindings, filter, { except: ['type'] });

  const repoCounts = countBy(repoUniverse, 'repository');
  const worstRiskByRepo = repoUniverse.reduce((acc, f) => {
    const score = (f.risk && f.risk.score) || 0;
    return { ...acc, [f.repository]: Math.max(acc[f.repository] || 0, score) };
  }, {});

  const repos = Object.entries(repoCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([repository, count]) => ({
      key: repository,
      label: repository,
      value: count,
      meta: `worst risk ${worstRiskByRepo[repository] || 0}`,
    }));

  const types = Object.entries(countBy(typeUniverse, 'type'))
    .sort((a, b) => b[1] - a[1])
    .map(([type, count]) => ({ key: type, label: type, value: count }));

  const panel = (title, hint, body, cls = '') => `<section class="sec-chart-panel ${cls}">
    <h3 class="sec-chart-title">${secEscape(title)}${hint ? `<span class="sec-hint">${secEscape(hint)}</span>` : ''}</h3>
    ${body}
  </section>`;

  box.innerHTML =
    panel('By severity', 'click to filter',
      secBarChart(severityRows(countBy(base, 'severity')), { onClick: 'drillSecurity_severity', unit: 'open findings' })) +
    // The trend is history across every repository and cannot be recomputed
    // from the loaded set, so it says so rather than appearing to have moved
    // with the scope.
    panel('Open findings over time', securityScopeChips().length ? 'all repositories' : 'lower is better',
      secLineChart(d.history || [])) +
    // This chart deliberately shows repositories OUTSIDE the current scope —
    // it is the way back out of one. Said plainly, because a chart listing
    // eight repositories under a "scoped to 2 repositories" bar otherwise reads
    // as the scope not having applied.
    panel('By repository',
      (filter.repositories || []).length ? 'top 8 · all repositories · click to switch' : 'top 8 · click to filter',
      secBarChart(repos, { onClick: 'drillSecurity_repository', emptyText: 'No findings in scope.' })) +
    panel('By scan type', 'click to filter',
      secBarChart(types, { onClick: 'drillSecurity_type', emptyText: 'No findings in scope.' })) +
    (d.lastScan && d.lastScan.perRepository
      ? panel('Coverage', 'what was actually checked · a gap is not a clean result',
          coverageStrip(mergeCoverage(d.lastScan.perRepository)), 'sec-chart-panel-wide')
      : '');
}

// Coverage across the repositories in the last scan. A capability counts as
// covered only if it was covered EVERYWHERE — one unanalysed repository is a
// gap, and averaging it away is how partial coverage reads as clean.
function mergeCoverage(perRepository) {
  const byType = new Map();
  for (const repo of perRepository) {
    for (const c of repo.coverage || []) {
      const current = byType.get(c.type) || { type: c.type, analysed: true, truncated: false, by: [], reasons: [], limits: [] };
      current.analysed = current.analysed && c.analysed;
      current.truncated = current.truncated || c.truncated;
      for (const id of c.by || []) if (!current.by.includes(id)) current.by.push(id);
      for (const r of c.reasons || []) current.reasons.push(r);
      for (const l of c.limits || []) if (!current.limits.some(x => x.reason === l.reason)) current.limits.push(l);
      byType.set(c.type, current);
    }
  }
  return [...byType.values()];
}

// ── Drill-down ─────────────────────────────────────────────────────────────
// Each sets the matching filter and scrolls the findings into view, so a click
// on a chart lands the reader on the rows it represents.

function drillSecurity_severity(severity) {
  _secFilter.severity = _secFilter.severity === severity ? null : severity;
  renderSecurityScoped();
  scrollToSecurityFindings();
}

function drillSecurity_type(type) {
  _secFilter.type = _secFilter.type === type ? null : type;
  renderSecurityScoped();
  scrollToSecurityFindings();
}

function drillSecurity_repository(repository) {
  // A real filter dimension now, not a value typed into the search box. The
  // search-box version could not be told apart from the user typing, so the
  // dashboard could not scope itself to a repository — and scoping to one
  // repository is the single most useful thing to scope to.
  const current = _secFilter.repositories || [];
  const only = current.length === 1 && current[0] === repository;
  _secFilter.repositories = only ? [] : [repository];
  renderSecurityScoped();
  scrollToSecurityFindings();
}

function scrollToSecurityFindings() {
  document.getElementById('sec-table')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderSecurityTopRisks() {
  const box = document.getElementById('sec-top-risks');
  if (!box || !_secDashboard) return;

  const risks = _secDashboard.topRisks.slice(0, 5);
  const head = document.getElementById('sec-top-risks-head');

  // With nothing open, an empty "Top risks" panel is just noise above the
  // table — the heading goes too, not only its contents.
  if (!risks.length) {
    box.innerHTML = '';
    if (head) head.classList.add('hidden');
    return;
  }
  if (head) head.classList.remove('hidden');

  box.innerHTML = risks
    .map(
      f => `<div class="sec-risk-card" onclick="openSecurityFinding('${secEscape(f.id)}')">
        <div class="sec-risk-score sec-prio-${secEscape(f.risk?.priority || 'P4')}">
          <span>${f.risk?.score ?? '—'}</span><small>${secEscape(f.risk?.priority || '')}</small>
        </div>
        <div class="sec-risk-body">
          <div class="sec-risk-title">${secEscape(f.title)} ${secKevBadge(f)}</div>
          <div class="sec-risk-meta">
            ${secEscape(f.repository)}${f.file ? ` · ${secEscape(f.file)}` : ''}
            ${f.startLine ? `:${f.startLine}` : ''}
          </div>
        </div>
        <span class="sec-sev sec-sev-${secEscape(f.severity)}">${secEscape(f.severity)}</span>
      </div>`
    )
    .join('');
}


// Confirmed in-the-wild exploitation is the most actionable fact the platform
// holds, so it gets a badge of its own rather than being buried in the risk
// breakdown. Ransomware use is separated out because it changes scheduling.
function secKevBadge(f) {
  const md = f.metadata || {};
  if (!md.knownExploited) return '';
  const ransomware = md.kev && md.kev.ransomware;
  return `<span class="sec-kev ${ransomware ? 'sec-kev-ransomware' : ''}"
    title="Listed in CISA's Known Exploited Vulnerabilities catalog${md.kev?.dateAdded ? `, added ${secEscape(md.kev.dateAdded)}` : ''}">
    ${ransomware ? 'KEV · RANSOMWARE' : 'KEV'}
  </span>`;
}

function segButton(label, count, active, onclick, extraClass = '', title = '') {
  return `<button class="sec-seg ${active ? 'active' : ''} ${extraClass}"
    ${title ? `title="${secEscape(title)}"` : ''} onclick="${onclick}">
    ${secEscape(label)}${count === null ? '' : `<span class="sec-seg-count">${count}</span>`}
  </button>`;
}

// ── Scope ──────────────────────────────────────────────────────────────────
//
// One function answers "what is the reader looking at right now", and every
// number on the page is derived from it. Before this, the table filtered and
// the dashboard did not: clicking CRITICAL narrowed the rows while the tiles
// above them kept reporting the whole estate. Two sets of numbers on one screen
// that disagree teaches people to trust neither.
//
// `except` is what makes a facet usable. The severity tiles are counted with
// the severity filter LIFTED, so selecting Critical does not zero the High tile
// and strand the reader with no way back. Same for type and repository: a facet
// that filters itself is a dead end.






// The scope bar. Present only when something is narrowing the view, because a
// permanent "showing everything" banner is chrome nobody reads — and then the
// one time it says something different, nobody reads that either.
function renderSecurityScopeBar() {
  const bar = document.getElementById('sec-scope');
  if (!bar) return;

  const chips = securityScopeChips();
  if (!chips.length) {
    bar.innerHTML = '';
    bar.classList.add('hidden');
    return;
  }

  const shown = scopedFindings().length;
  const total = _secFindings.filter(f => f.type !== 'QUALITY').length;

  bar.classList.remove('hidden');
  bar.innerHTML =
    '<span class="sec-scope-label">Scoped to</span>' +
    chips
      .map(
        c => `<button class="sec-scope-chip" onclick="clearSecurityScope('${c.dimension}')"
                title="Remove this filter">${secEscape(c.label)}<span class="sec-scope-x">✕</span></button>`
      )
      .join('') +
    `<span class="sec-scope-count">${shown} of ${total} findings</span>` +
    '<button class="sec-link sec-scope-clear" onclick="clearSecurityFilters()">Clear all</button>';
}

// Removing one chip rather than all of them. Narrowing by repository and then
// by severity is the normal path, and a bar whose only exit is "clear
// everything" makes the reader rebuild the half they wanted to keep.
function clearSecurityScope(dimension) {
  if (dimension === 'search') {
    const search = document.getElementById('sec-search');
    if (search) search.value = '';
  } else if (dimension === 'repository') {
    _secFilter.repositories = [];
  } else if (dimension === 'newCode') {
    _secFilter.newCodeOnly = false;
  } else {
    _secFilter[dimension] = null;
  }
  renderSecurityScoped();
}

// Everything that depends on the scope, in one call. Separate from
// refreshSecurity() because none of it needs the network: the findings are
// already loaded and re-fetching them to redraw a filter would put a spinner in
// front of an instant answer.
// The gate verdict, as the first thing on the page.
//
// Rendered from the last scan's stored result rather than recomputed, so it
// says exactly what the CI endpoint would say. Two sources of truth for "can
// this ship" is worse than none.
function renderSecurityGate() {
  const box = document.getElementById('sec-gate');
  if (!box) return;

  const scan = _secDashboard && _secDashboard.lastScan;
  const gate = scan && scan.gate;

  // No gate on the last scan means it predates the feature. Silence is right —
  // an alarming banner about a scan that ran before gates existed is noise.
  if (!gate) {
    box.classList.add('hidden');
    box.innerHTML = '';
    return;
  }

  const failedRepos = (scan.perRepository || []).filter(r => r.gate && r.gate.blocking);
  const newCode = (scan.perRepository || []).reduce((n, r) => n + ((r.newCode && r.newCode.count) || 0), 0);
  const noDiff = (scan.perRepository || []).filter(r => r.newCode && !r.newCode.available);

  const state = gate.status === 'PASSED' ? 'pass'
    : gate.status === 'WARN' ? 'warn'
    : 'fail';

  box.className = `sec-gate sec-gate-${state}`;
  box.innerHTML =
    `<span class="sec-gate-badge">${
      gate.status === 'PASSED' ? 'Gate passed'
        : gate.status === 'WARN' ? 'Gate passed with warnings'
        : gate.status === 'NOT_EVALUATED' ? 'Gate not evaluated'
        : 'Gate failed'
    }</span>` +
    `<span class="sec-gate-detail">${
      failedRepos.length
        ? secEscape(failedRepos.map(r => `${r.repository}: ${r.gate.reason || 'blocked'}`).join(' · '))
        : `${newCode} finding${newCode === 1 ? '' : 's'} in new code`
    }</span>` +
    // A gate that could not identify new code is stated, because that is the
    // condition under which it fails closed and a reader deserves to know why.
    (noDiff.length
      ? `<span class="sec-gate-note">no diff for ${secEscape(noDiff.map(r => r.repository).join(', '))}
           — a shallow clone or a missing base ref</span>`
      : '') +
    (newCode
      ? `<button class="sec-link sec-gate-action" onclick="showSecurityNewCode()">Show new code</button>`
      : '');
  box.classList.remove('hidden');
}

// Jump straight from the banner to the findings it is talking about.
function showSecurityNewCode() {
  _secFilter.newCodeOnly = true;
  renderSecurityScoped();
  scrollToSecurityFindings();
}

function renderSecurityScoped() {
  renderSecurityGate();
  renderSecurityScopeBar();
  renderSecurityStats();
  renderSecurityCharts();
  renderSecurityFilters();
  renderSecurityFindings();
}




function renderSecurityFilters() {
  if (!_secDashboard) return;

  const filter = currentSecurityFilter();
  // Each facet is counted with its OWN filter lifted and the others applied.
  // That is what keeps a facet clickable in both directions: counting severity
  // with the severity filter applied would leave every tile but the selected
  // one reading zero.
  const base = scopeBase();
  const bySeverity = countBy(base, 'severity');
  const typeUniverse = scopeFindings(_secFindings, filter, { except: ['type'] });
  const byType = countBy(typeUniverse, 'type');
  const securityTotal = typeUniverse.filter(f => f.type !== 'QUALITY').length;
  const scoped = scopedFindings();

  document.getElementById('sec-filter-severity').innerHTML =
    segButton('All', base.length, !_secFilter.severity, "setSecurityFilter('severity',null)") +
    SEVERITY_ORDER.filter(s => bySeverity[s])
      .map(s =>
        segButton(
          s.charAt(0) + s.slice(1).toLowerCase(),
          bySeverity[s],
          _secFilter.severity === s,
          `setSecurityFilter('severity','${s}')`,
          `sec-seg-${s}`
        )
      )
      .join('');

  document.getElementById('sec-filter-type').innerHTML =
    segButton('All', securityTotal, !_secFilter.type, "setSecurityFilter('type',null)") +
    Object.keys(byType)
      .sort()
      .map(t => segButton(t, byType[t], _secFilter.type === t, `setSecurityFilter('type','${t}')`))
      .join('');

  // Counted with the new-code filter LIFTED, like every other facet, so the
  // chip still shows how many there are while it is switched off.
  const newCodeCount = scopeFindings(_secFindings, filter, { except: ['newCode'] })
    .filter(f => f.isNewCode).length;

  const newCodeEl = document.getElementById('sec-filter-newcode');
  if (newCodeEl) {
    newCodeEl.innerHTML = segButton(
      'New code',
      newCodeCount,
      _secFilter.newCodeOnly,
      'toggleSecurityNewCode()',
      '',
      // Spelled out, because the aggregate spans repositories scanned at
      // different times: each repository's flag is relative to ITS last scan,
      // not to a single moment. Without this the number reads as "introduced
      // today", which it is not.
      'Findings introduced by the most recent change to each repository, '
      + 'measured against that repository\'s last scan'
    );
  }

  document.getElementById('sec-filter-status').innerHTML = [
    ['active', 'Open'],
    ['SUPPRESSED', 'Suppressed'],
    ['RESOLVED', 'Resolved'],
    ['all', 'All'],
  ]
    .map(([value, label]) =>
      segButton(label, null, _secFilter.status === value, `setSecurityFilter('status','${value}')`)
    )
    .join('');

  const dirty =
    _secFilter.severity || _secFilter.type || (_secFilter.repositories || []).length
    || _secFilter.newCodeOnly || _secFilter.status !== 'active';
  document.getElementById('sec-clear-filters').classList.toggle('hidden', !dirty);
}

function toggleSecurityNewCode() {
  _secFilter.newCodeOnly = !_secFilter.newCodeOnly;
  renderSecurityScoped();
}

function setSecurityFilter(dimension, value) {
  _secFilter[dimension] = value;

  // Status is server-side: resolved and suppressed findings are not in the
  // loaded set, so changing it needs a refetch rather than a re-render.
  if (dimension === 'status') {
    refreshSecurity();
    return;
  }
  renderSecurityScoped();
}

function clearSecurityFilters() {
  const needsRefetch = _secFilter.status !== 'active';
  _secFilter = { type: null, severity: null, repositories: [], newCodeOnly: false, status: 'active' };
  const search = document.getElementById('sec-search');
  if (search) search.value = '';
  if (needsRefetch) refreshSecurity();
  else renderSecurityScoped();
}

function renderSecurityFindings() {
  const body = document.getElementById('sec-table-body');
  if (!body) return;

  // Scope is decided in one place now — see scopeFindings. The table used to
  // re-apply severity and search itself, which is how the row count and the
  // chip counts drifted apart.
  const findings = scopedFindings();
  const inScopeWithoutSeverity = scopeBase().length;
  const rows = groupFindings(findings);

  // Groups are held for the detail view, keyed by a short id rather than the
  // composite key — the key contains a package name and a path, neither of
  // which is safe to interpolate into an onclick attribute.
  _secGroups = new Map(rows.filter(r => r.kind === 'group').map((r, i) => [`g${i}`, r]));
  const groupId = new Map([..._secGroups].map(([id, r]) => [r.key, id]));

  const countEl = document.getElementById('sec-result-count');
  if (countEl) {
    // Two numbers, stated separately, because grouping makes them genuinely
    // different: 115 rows over 500 findings is not a filter and must not read
    // like one.
    const scope = rows.length === findings.length
      ? (findings.length === inScopeWithoutSeverity ? `${findings.length}` : `${findings.length} of ${inScopeWithoutSeverity}`)
      : `${rows.length} rows · ${findings.length} findings`;
    countEl.textContent = scope;
  }

  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="6" class="sec-empty">
      ${_secFindings.length ? 'No findings match these filters.' : 'Nothing found yet — pick a repository and run a scan.'}
    </td></tr>`;
    return;
  }

  body.innerHTML = rows
    .map(row => (row.kind === 'group' ? groupRow(row, groupId.get(row.key)) : findingRow(row.finding)))
    .join('');
}

function findingRow(f) {
  const suppressed = f.status === 'SUPPRESSED' || f.status === 'FALSE_POSITIVE';
  return `<tr class="sec-row ${suppressed ? 'sec-row-muted' : ''}" onclick="openSecurityFinding('${secEscape(f.id)}')">
    <td><span class="sec-risk-pill sec-prio-${secEscape(f.risk?.priority || 'P4')}">${f.risk?.score ?? '—'}</span></td>
    <td><span class="sec-sev sec-sev-${secEscape(f.severity)}">${secEscape(f.severity)}</span></td>
    <td><span class="sec-type">${secEscape(f.type)}</span></td>
    <td>
      <div class="sec-cell-title">${secEscape(f.title)}</div>
      ${secKevBadge(f)}
      ${f.status !== 'OPEN' ? `<span class="sec-status-tag">${secEscape(f.status)}</span>` : ''}
    </td>
    <td class="sec-loc" title="${secEscape(f.file || '')}">
      ${secEscape(f.file || f.repository)}${f.startLine ? `<span class="sec-line">:${f.startLine}</span>` : ''}
    </td>
    <td>${f.detections.map(d => `<span class="sec-source">${secEscape(d.source)}</span>`).join('')}</td>
  </tr>`;
}

// One dependency, however many advisories. The title is the thing to upgrade,
// which is the actual unit of work — the CVE ids are detail, and they are one
// click away.
function groupRow(group, id) {
  const g = summariseGroup(group);
  const kev = group.findings.some(f => f.metadata && f.metadata.knownExploited);

  return `<tr class="sec-row sec-row-group" onclick="openSecurityGroup('${id}')">
    <td><span class="sec-risk-pill sec-prio-${secEscape(g.risk.priority || 'P4')}">${g.risk.score ?? '—'}</span></td>
    <td><span class="sec-sev sec-sev-${secEscape(g.severity)}">${secEscape(g.severity)}</span></td>
    <td><span class="sec-type">${secEscape(g.type)}</span></td>
    <td>
      <div class="sec-cell-title">
        ${secEscape(g.packageName)}${g.version ? ` <span class="sec-group-version">${secEscape(g.version)}</span>` : ''}
      </div>
      <span class="sec-group-badge">${g.count} vulnerabilities</span>
      ${g.transitive ? '<span class="sec-status-tag">transitive</span>' : ''}
      ${kev ? '<span class="sec-kev">KEV</span>' : ''}
    </td>
    <td class="sec-loc" title="${secEscape(g.file || '')}">${secEscape(g.file || g.repository)}</td>
    <td>${g.sources.map(src => `<span class="sec-source">${secEscape(src)}</span>`).join('')}</td>
  </tr>`;
}


// ── Finding detail ─────────────────────────────────────────────────────────





// Renders a scan's progress and coverage report. Shared by the live poll and
// by re-opening a stored scan, so both show exactly the same thing.
// Whether the detail below the headline is open. A completed scan collapses to
// its headline, because the panel lives in the fixed chrome above the findings
// list: left expanded it grew the chrome until the list it was reporting on was
// pushed off the bottom of the window, and the only way to read the results was
// to resize the window.
//
// Warnings are deliberately OUTSIDE the collapsible region. A gap in coverage
// is the one thing that must never be one click away from invisible.
let _secScanExpanded = true;


let _secLastScanRecord = null;






// ── Scanning ───────────────────────────────────────────────────────────────


// Exported for tests only. The browser loads this file as a plain script, where
// `module` is undefined; Node's test runner requires it and gets the pure
// helpers. The guard is what keeps the browser from a ReferenceError.
//
// Only the pure functions are exported. Anything that touches the DOM belongs
// in a browser, and a test that mocks enough DOM to run it would be testing the
// mock.
if (typeof module !== 'undefined' && module.exports) {
  // Only what still lives in THIS file. Scope, grouping and scan summarising
  // moved to their own modules and export themselves there — listing them here
  // as well would throw a ReferenceError the moment Node required this file.
  module.exports = { mergeCoverage };
}

// ── Clearing stored results ────────────────────────────────────────────────
//
// Destructive and irreversible, so the panel says what will go BEFORE it goes,
// and the counts come from the server rather than from whatever the table
// happens to be showing — a filtered view would otherwise understate what is
// about to be deleted.
//
// The three choices are deliberately separate rather than one action with
// options, because they differ in what they destroy and the difference is not
// recoverable. Repository settings survive all three; they are configuration,
// not results.

async function openSecurityClear() {
  const box = document.getElementById('sec-clear');
  if (!box) return;

  const only = (_secFilter.repositories || []).length === 1 ? _secFilter.repositories[0] : null;

  let preview;
  try {
    preview = await secFetch(`/clear/preview${only ? `?repository=${encodeURIComponent(only)}` : ''}`);
  } catch (e) {
    box.className = 'sec-clear';
    box.innerHTML = `<div class="sec-clear-error">Could not read what would be cleared: ${secEscape(e.message)}</div>`;
    return;
  }

  const scoped = only
    ? `<strong>${secEscape(only)}</strong>`
    : `<strong>${preview.repositories} repositor${preview.repositories === 1 ? 'y' : 'ies'}</strong>`;

  box.className = 'sec-clear';
  box.innerHTML = `
    <div class="sec-clear-head">
      <strong>Clear stored results</strong>
      <button class="sec-link" onclick="closeSecurityClear()">Cancel</button>
    </div>

    <div class="sec-clear-body">
      <p class="sec-clear-summary">
        ${preview.findings} finding${preview.findings === 1 ? '' : 's'} across ${scoped},
        ${preview.scans} scan record${preview.scans === 1 ? '' : 's'}
        and ${preview.sboms} SBOM${preview.sboms === 1 ? '' : 's'}.
        A rescan regenerates all of it.
      </p>

      ${preview.suppressed ? `
        <label class="sec-clear-keep">
          <input type="checkbox" id="sec-clear-triage">
          Also delete ${preview.suppressed} suppression decision${preview.suppressed === 1 ? '' : 's'}
          <span class="sec-clear-warn">— these cannot be recovered, and the next scan will report those findings again</span>
        </label>` : ''}

      <div class="sec-clear-actions">
        ${only
          ? `<button class="btn btn-ghost btn-sm" onclick="confirmSecurityClear('${secEscape(only)}')">
               Clear ${secEscape(only)}
             </button>`
          : ''}
        <button class="btn btn-ghost btn-sm" onclick="confirmSecurityClear(null)">
          Clear all findings
        </button>
        <button class="btn btn-ghost btn-sm sec-clear-danger" onclick="confirmSecurityReset()">
          Reset everything
        </button>
      </div>

      <p class="sec-clear-note">
        <strong>Reset everything</strong> also deletes ${preview.history} trend point${preview.history === 1 ? '' : 's'}
        and the baseline. Those cannot be rebuilt — you cannot rescan the past.
        Repository criticality and environment settings are kept by every option here.
      </p>
    </div>`;
}

function closeSecurityClear() {
  const box = document.getElementById('sec-clear');
  if (box) {
    box.classList.add('hidden');
    box.innerHTML = '';
  }
}

async function confirmSecurityClear(repository) {
  const keep = !document.getElementById('sec-clear-triage')?.checked;
  const query = new URLSearchParams();
  if (repository) query.set('repository', repository);
  if (!keep) query.set('keepSuppressed', 'false');

  try {
    const removed = await secFetch(`/findings?${query.toString()}`, { method: 'DELETE' });
    closeSecurityClear();
    // Reset the scope too: a repository filter pointing at findings that no
    // longer exist would leave the reader on an empty screen with no clue why.
    _secFilter = { type: null, severity: null, repositories: [], newCodeOnly: false, status: 'active' };
    await refreshSecurity();
    flashSecurityNotice(
      `Cleared ${removed.findings} finding${removed.findings === 1 ? '' : 's'}`
      + (removed.keptSuppressed ? ` · kept ${removed.keptSuppressed} suppression decision${removed.keptSuppressed === 1 ? '' : 's'}` : '')
    );
  } catch (e) {
    flashSecurityNotice(`Could not clear: ${e.message}`, true);
  }
}

async function confirmSecurityReset() {
  try {
    const removed = await secFetch('/reset', { method: 'POST' });
    closeSecurityClear();
    _secFilter = { type: null, severity: null, repositories: [], newCodeOnly: false, status: 'active' };
    _secLastScanId = null;
    await refreshSecurity();
    flashSecurityNotice(`Reset — removed ${removed.findings} findings, ${removed.scans} scans and ${removed.history} trend points`);
  } catch (e) {
    flashSecurityNotice(`Could not reset: ${e.message}`, true);
  }
}

// A short confirmation of what happened. Destructive actions that complete in
// silence leave the reader wondering whether they worked.
function flashSecurityNotice(message, isError = false) {
  const box = document.getElementById('sec-clear');
  if (!box) return;
  box.className = `sec-clear ${isError ? 'sec-clear-failed' : 'sec-clear-done'}`;
  box.innerHTML = `<div class="sec-clear-head"><strong>${secEscape(message)}</strong>
    <button class="sec-link" onclick="closeSecurityClear()">Dismiss</button></div>`;
}

// ── Reports ────────────────────────────────────────────────────────────────
//
// The report covers WHAT IS ON SCREEN — the same scoped, grouped set the table
// shows. A file whose numbers disagree with the view it was exported from is
// how people stop believing reports, so the scope is stated in the header
// rather than left to be inferred.

function securityReportSpec() {
  const filter = currentSecurityFilter();
  const findings = scopedFindings();
  const counts = countBy(scopeBase(), 'severity');

  const scope = [];
  const repos = filter.repositories || [];
  if (repos.length) scope.push({ label: 'Repository', value: repos.join(', ') });
  if (filter.type) scope.push({ label: 'Type', value: filter.type });
  if (filter.severity) scope.push({ label: 'Severity', value: filter.severity });
  if (filter.newCodeOnly) scope.push({ label: 'New code only', value: 'yes' });
  if (filter.search) scope.push({ label: 'Search', value: filter.search });
  scope.push({ label: 'Status', value: filter.status === 'active' ? 'Open' : filter.status });

  const scan = _secDashboard && _secDashboard.lastScan;
  const gate = scan && scan.gate;

  return {
    title: 'Security scan report',
    subtitle: repos.length === 1 ? repos[0] : `${_secDashboard?.byRepository?.length || 0} repositories`,
    scope,
    summary: [
      { label: 'Critical', value: counts.CRITICAL || 0, tone: 'critical' },
      { label: 'High', value: counts.HIGH || 0, tone: 'high' },
      { label: 'Medium', value: counts.MEDIUM || 0, tone: 'medium' },
      { label: 'Low', value: counts.LOW || 0, tone: 'neutral' },
      { label: 'Score', value: securityScore(counts), tone: 'good' },
      ...(gate ? [{ label: 'Gate', value: gate.status, tone: gate.blocking ? 'critical' : 'good' }] : []),
    ],
    // Coverage travels with the report for the same reason it is on the
    // dashboard: a short list of findings means nothing without knowing what
    // was actually examined to produce it.
    note: scan && scan.partial
      ? 'Coverage was PARTIAL for this scan — some capabilities were not checked, '
        + 'so this report is not a statement that nothing else is wrong.'
      : scan
        ? `Based on the scan of ${new Date(scan.startedAt).toLocaleString()}.`
        : 'No scan has run yet.',
    columns: [
      { key: 'risk', label: 'Risk', align: 'right' },
      { key: 'severity', label: 'Severity' },
      { key: 'type', label: 'Type' },
      // The two that hold unbreakable strings: advisory titles carry package
      // coordinates, and a location is a file path with no spaces in it.
      { key: 'title', label: 'Finding', wrap: 'anywhere' },
      { key: 'location', label: 'Location', wrap: 'anywhere' },
      { key: 'source', label: 'Detected by' },
    ],
    rows: findings.map(f => ({
      risk: f.risk?.score ?? '—',
      severity: f.severity,
      type: f.type,
      title: f.title,
      location: `${f.file || f.repository}${f.startLine ? `:${f.startLine}` : ''}`,
      source: f.detections.map(d => d.source).join(', '),
    })),
  };
}

function printSecurityReport() {
  return produceReport(securityReportSpec(), 'print');
}

async function exportSecurityReport() {
  const result = await produceReport(securityReportSpec(), 'pdf');
  if (result && result.ok && result.path) flashSecurityNotice(`Report saved to ${result.path}`);
  else if (result && result.error) flashSecurityNotice(`Could not export: ${result.error}`, true);
}
