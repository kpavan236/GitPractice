// =============================================================================
// Security charts — inline SVG, no dependencies
// =============================================================================
// Every chart here is click-to-filter: a bar is a question ("what are the 22
// criticals?") and clicking it answers by filtering the findings table below.
// A dashboard you can only look at makes you retype what it already knows.
//
// Colour follows the data's JOB. Severity is a STATUS scale, not a categorical
// one — reserved colours that mean the same thing everywhere in the product,
// always paired with the severity word so the meaning never rests on colour
// alone. Counts by repository or type are magnitude, so they take a single
// neutral accent and let length carry the comparison.
//
// The previous severity colours failed validation badly: HIGH #fb923c and
// MEDIUM #f59e0b measured ΔE 4.2 for normal vision and 2.3 under deuteranopia
// — indistinguishable, and they were already shipping on the severity chips.
// These steps measure 13.6 and 11.3 for the same pair.

const SEV_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];

// Small helper: SVG needs escaped text like HTML does.
function esc(text) {
  return String(text ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

/**
 * Horizontal bar chart.
 *
 * Horizontal because the categories are words of varying length — repository
 * names, severity names — and horizontal bars give labels room to be read
 * rather than rotated 45° or truncated.
 *
 * @param {Array}  items    [{ label, value, color?, meta? }]
 * @param {object} opts     { onClick, max, unit, emptyText }
 */
function secBarChart(items, { onClick = null, unit = 'findings', emptyText = 'Nothing to show' } = {}) {
  const rows = (items || []).filter(i => i.value > 0);
  if (!rows.length) return `<div class="chart-empty">${esc(emptyText)}</div>`;

  const max = Math.max(...rows.map(r => r.value));

  return `<div class="chart-bars">${rows
    .map(row => {
      // Length carries the comparison; the number is stated too, because a
      // reader should never have to measure a bar against an axis to learn a
      // count they could simply be told.
      const pct = Math.max(2, (row.value / max) * 100);
      const clickable = onClick ? `onclick="${onClick}('${esc(row.key ?? row.label)}')"` : '';
      return `<button class="chart-bar-row ${onClick ? 'chart-clickable' : ''}" ${clickable}
        title="${esc(row.label)}: ${row.value} ${esc(unit)}${row.meta ? ` · ${esc(row.meta)}` : ''}">
        <span class="chart-bar-label">${esc(row.label)}</span>
        <span class="chart-bar-track">
          <span class="chart-bar-fill" style="width:${pct}%;background:${row.color || 'var(--chart-accent)'}"></span>
        </span>
        <span class="chart-bar-value">${row.value}</span>
      </button>`;
    })
    .join('')}</div>`;
}

/**
 * Trend line.
 *
 * One series, so no legend — the heading names it. A crosshair and tooltip
 * rather than a label on every point: labelling all of them turns the line into
 * a wall of numbers and hides the shape, which is the only reason to draw a
 * line at all.
 */
function secLineChart(points, { height = 90, id = 'sec-trend' } = {}) {
  const series = (points || []).filter(p => p && typeof p.total === 'number');
  if (series.length < 2) {
    return `<div class="chart-empty">Not enough history yet — the trend appears after a second scan.</div>`;
  }

  // Positions are percentages, because the SVG stretches to the panel width and
  // the markers are HTML overlaid on top of it. The markers were originally
  // <circle>s inside a stretched viewBox, which rendered them as ellipses —
  // wider or narrower depending on the panel. A percentage-positioned span is
  // round at every width.
  const values = series.map(p => p.total);
  const lo = Math.min(...values);
  const hi = Math.max(...values);

  // The domain is the data's range with headroom, NOT zero-based. Anchored at
  // zero, 92 → 78 drew as a flat line: a 15% improvement rendered as "nothing
  // happened". A line may sit on a truncated axis where an area may not, which
  // is why the area fill is gone — a filled region reads as magnitude, and
  // magnitude from a non-zero floor is a lie. Both endpoint values are printed
  // below, so the axis is never the only source of the numbers.
  const span = hi - lo || Math.max(1, hi * 0.1);
  const floor = lo - span * 0.35;
  const ceil = hi + span * 0.35;

  // Inset, so the first and last markers sit inside the plot rather than half
  // outside it.
  const px = i => 2 + (i / (series.length - 1)) * 96;
  const py = v => ((ceil - v) / (ceil - floor)) * 100;

  const line = series.map((p, i) => `${px(i).toFixed(2)},${py(p.total).toFixed(2)}`).join(' ');

  // The first and last values are labelled on the axis rather than left to the
  // tooltip: a value a reader can only get by hovering is a value most readers
  // never get. The points in between stay unlabelled, because a number on every
  // point hides the shape that is the only reason to draw a line.
  //
  // Direction, coloured by whether it improved. Fewer open findings is good, so
  // the polarity is inverted relative to an ordinary metric.
  const improving = series[series.length - 1].total <= series[0].total;
  const stroke = improving ? 'var(--chart-good)' : 'var(--chart-critical)';

  return `<div class="chart-line-wrap">
    <div class="chart-line-plot" style="height:${height}px">
      <svg class="chart-line" viewBox="0 0 100 100" preserveAspectRatio="none" role="img"
           aria-label="Open findings over the last ${series.length} scans: ${values.join(', ')}">
        <polyline points="${line}" fill="none" stroke="${stroke}" stroke-width="2"
                  vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/>
      </svg>
      ${series
        .map((p, i) => {
          // The hit area is the marker's parent, padded well past the 8px dot,
          // so hovering never requires precision aiming.
          const date = new Date(p.at).toLocaleString();
          return `<span class="chart-point" style="left:${px(i).toFixed(2)}%;top:${py(p.total).toFixed(2)}%"
                        title="${esc(date)} — ${p.total} open">
            <span class="chart-point-dot" style="background:${stroke}"></span>
          </span>`;
        })
        .join('')}
    </div>
    <div class="chart-line-axis">
      <span>${esc(new Date(series[0].at).toLocaleDateString())} · ${series[0].total} open</span>
      <span>${series.length} scans</span>
      <span class="chart-line-now">now · ${series[series.length - 1].total} open</span>
    </div>
  </div>`;
}

/**
 * Coverage strip — what was checked, and what was not.
 *
 * Deliberately not a chart. It answers a yes/no question per capability, and a
 * bar chart of booleans would be decoration. This is the panel that stops a
 * clean dashboard being mistaken for a clean codebase.
 */
function coverageStrip(coverage) {
  if (!coverage || !coverage.length) return '';

  return `<div class="chart-coverage">${coverage
    .map(c => {
      const state = c.analysed ? (c.truncated ? 'partial' : 'ok') : 'gap';
      const reason = (c.reasons || [])[0];
      // A truncated capability was still analysed by someone, and saying only
      // "hit a limit" drops that — the reader loses both who checked it and
      // what the limit actually was.
      const by = (c.by || []).join(', ');
      const limit = (c.limits || [])[0];
      const detail = c.analysed
        ? (c.truncated
            ? `analysed by ${by} — ${limit ? limit.reason : 'incomplete, hit a limit'}`
            : `analysed by ${by}`)
        : (reason ? reason.reason : 'not analysed');
      // The word, not just the colour: a status colour never carries meaning
      // on its own.
      const mark = { ok: '✓', partial: '!', gap: '✗' }[state];
      return `<div class="chart-cov chart-cov-${state}" title="${esc(detail)}">
        <span class="chart-cov-mark">${mark}</span>
        <span class="chart-cov-type">${esc(c.type)}</span>
        <span class="chart-cov-detail">${esc(detail)}</span>
      </div>`;
    })
    .join('')}</div>`;
}

function severityColor(severity) {
  return `var(--chart-sev-${String(severity).toLowerCase()})`;
}

function severityRows(counts, { includeZero = false } = {}) {
  return SEV_ORDER
    .filter(s => includeZero || (counts && counts[s]))
    .map(s => ({
      key: s,
      label: s.charAt(0) + s.slice(1).toLowerCase(),
      value: (counts && counts[s]) || 0,
      color: severityColor(s),
    }));
}
