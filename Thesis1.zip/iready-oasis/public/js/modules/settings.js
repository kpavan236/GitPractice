// =============================================================================
// Settings — credentials/config modal, AI-powered setup-script generator
// =============================================================================
// Collapsible section header — only GitHub Connection / Clone Directory (the
// two required-on-every-launch fields) stay always-expanded; everything else
// is a "connect once, rarely revisit" setting and defaults to collapsed so
// the modal isn't an intimidating wall of fields every time it opens.
function settingsSectionHeader(id, title, extraHtml = '') {
  return `<div class="wiz-section-label settings-section-header" id="${id}-hdr" onclick="toggleSettingsSection('${id}')">
    <span class="settings-section-chevron">▸</span>${escHtml(title)}${extraHtml}
  </div>`;
}
function toggleSettingsSection(id) {
  const bodyEl = document.getElementById(id);
  const hdr    = document.getElementById(id + '-hdr');
  if (!bodyEl) return;
  const collapsed = bodyEl.classList.toggle('hidden');
  if (hdr) hdr.classList.toggle('open', !collapsed);
}

// A password field pre-filled with the actual saved secret (not masked dots),
// plus an eye toggle and a copy button — used for the GitHub/Jenkins/JIRA
// token fields so the user can verify or copy what's actually saved.
function tokenFieldHtml(id, cls, value, placeholder) {
  return `<div class="input-with-btn token-field">
      <input class="${cls}" id="${id}" type="password" value="${escHtml(value || '')}" placeholder="${escHtml(placeholder)}" autocomplete="off"/>
      <button class="btn btn-ghost btn-sm token-icon-btn" type="button" onclick="toggleTokenVisibility('${id}', this)" title="Show/hide">👁</button>
      <button class="btn btn-ghost btn-sm token-icon-btn" type="button" onclick="copyTokenValue('${id}', this)" title="Copy to clipboard">📋</button>
    </div>`;
}

function toggleTokenVisibility(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const showing = input.type === 'text';
  input.type = showing ? 'password' : 'text';
  btn.textContent = showing ? '👁' : '🙈';
}

async function copyTokenValue(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input || !input.value) { toast('Nothing to copy', 'info'); return; }
  try {
    await navigator.clipboard.writeText(input.value);
    const orig = btn.textContent;
    btn.textContent = '✓';
    setTimeout(() => { btn.textContent = orig; }, 1200);
  } catch (e) {
    toast('Copy failed: ' + e.message, 'error');
  }
}

function openSettingsModal() {
  initSettingsTab();
  document.getElementById('settings-modal')?.classList.remove('hidden');
}

function initSettingsTab() {
  const body = document.getElementById('settings-body');
  body.innerHTML = `
    <div class="wiz-section-label" style="margin-top:0">GitHub, Jenkins &amp; JIRA auto-sync</div>
    <div id="sec-extcalls">
      <label class="check-row" style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
        <input type="checkbox" id="s-external-calls" ${externalCallsOn() ? 'checked' : ''} onchange="setExternalCalls(this.checked)"/>
        Allow OASIS to contact GitHub and Jenkins, and to sync JIRA automatically
      </label>
      <div class="field-hint" style="margin-top:6px">
        Off: the only calls are the checks when you sign in during setup. Repositories, pulls, branches from
        GitHub, builds, the dependency graph, Version Watch scans and the badges in the JIRA tab all wait until
        you turn this on, as does the automatic JIRA sync every 5 minutes. Signing in, and pressing Sync in the
        JIRA tab, still work. Takes effect immediately. <span id="s-external-calls-source"></span>
      </div>
    </div>

    <div class="wiz-section-label">GitHub Connection</div>
    <div class="field">
      <label>GitHub Enterprise URL <span class="req">*</span></label>
      <input class="s-ghurl" type="text" value="${escHtml(cfg.githubUrl || '')}"/>
    </div>
    <div class="field">
      <label>Organization <span class="req">*</span></label>
      <input class="s-org" type="text" value="${escHtml(cfg.org || '')}"/>
    </div>
    <div class="field">
      <label>Personal Access Token</label>
      ${tokenFieldHtml('s-token-input', 's-token', getCookie(TOKEN_COOKIE), 'Leave blank to keep existing token')}
    </div>

    <div class="wiz-section-label">Clone Directory</div>
    <div class="field">
      <label>Base Directory <span class="req">*</span></label>
      <div class="input-with-btn">
        <input class="s-dir" id="s-dir-input" type="text" value="${escHtml(cfg.cloneDir || '~/dev/projects')}"/>
        <button class="btn btn-ghost btn-sm" type="button" onclick="browseDirectory('s-dir-input')" style="flex-shrink:0">Browse…</button>
      </div>
      <div class="field-hint">Each repo is cloned into a subdirectory here</div>
    </div>

    ${settingsSectionHeader('sec-devtools', 'Development Tools',
      `<button class="btn btn-ghost btn-sm" id="s-detect-btn" type="button"
        onclick="event.stopPropagation();detectTools('s-ij-input','s-java-input')"
        style="margin-left:auto;font-size:11px;padding:2px 10px">⚡ Auto-detect</button>`)}
    <div class="settings-section-body hidden" id="sec-devtools">
      <div class="field-row">
        <div class="field">
          <label>IntelliJ IDEA CLI <span class="opt">optional</span></label>
          <input class="s-ij" id="s-ij-input" type="text" value="${escHtml(cfg.intellijPath || '')}" placeholder="/usr/local/bin/idea"/>
          <div class="field-hint">Tools → Create Command-line Launcher in IDEA</div>
        </div>
        <div class="field">
          <label>Java Home <span class="opt">optional</span></label>
          <input class="s-java" id="s-java-input" type="text" value="${escHtml(cfg.javaHome || '')}" placeholder="auto-detected"/>
          <div class="field-hint"><code>/usr/libexec/java_home -V</code> lists installed JDKs</div>
        </div>
      </div>
    </div>

    ${settingsSectionHeader('sec-build', 'Build Config')}
    <div class="settings-section-body hidden" id="sec-build">
      <div class="field">
        <label>Maven Extra Arguments <span class="opt">optional</span></label>
        <input class="s-mvn" type="text" value="${escHtml(cfg.mavenArgs || '')}" placeholder="-DskipTests -Plocal-dev"/>
        <div class="field-hint">Appended to <code>mvn clean install</code> for Java projects</div>
      </div>
      <div class="field">
        <label>Extra Environment Variables <span class="opt">optional</span></label>
        <textarea class="s-env" rows="4">${escHtml(cfg.extraEnv || '')}</textarea>
        <div class="field-hint">KEY=VALUE one per line — written to <code>.env</code> in each project</div>
      </div>
    </div>

    ${settingsSectionHeader('sec-aws', 'AWS')}
    <div class="settings-section-body hidden" id="sec-aws">
      <div class="field">
        <label>AWS Profile <span class="opt">optional</span></label>
        <select class="s-aws" id="s-aws-select">
          <option value="${escHtml(cfg.awsProfile || '')}" selected>${escHtml(cfg.awsProfile || 'default')}</option>
        </select>
        <div class="field-hint">Profile used to load credentials when launching apps · <code>aws sso login</code> runs automatically if the session is expired</div>
      </div>
    </div>

    ${settingsSectionHeader('sec-ai', 'AI')}
    <div class="settings-section-body hidden" id="sec-ai">
      <label class="check-row" style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer;margin-bottom:14px">
        <input type="checkbox" id="s-ai-enabled" ${cfg.aiEnabled !== false ? 'checked' : ''} onchange="onAiEnabledChange()"/>
        Enable AI features (failure triage, project chat, script generation)
      </label>
      <div id="ai-config" class="${cfg.aiEnabled === false ? 'hidden' : ''}">
        <div class="field">
          <label>Provider</label>
          <select class="s-ai-provider" id="s-ai-provider-select" onchange="renderAiFields(this.value)">
            <option value="">Loading…</option>
          </select>
        </div>
        <div id="ai-fields"></div>
        <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
          <button class="btn btn-ghost btn-sm" type="button" id="s-ai-test-btn" onclick="testAiConnection()">Test connection</button>
          <span class="field-hint" id="s-ai-test-msg"></span>
        </div>
      </div>
      <div class="field-hint" style="margin-top:6px">Turning this off makes every AI feature fall back to its non-AI heuristic instead.</div>
    </div>

    ${settingsSectionHeader('sec-jenkins', 'Jenkins')}
    <div class="settings-section-body hidden" id="sec-jenkins">
      <div class="field">
        <label>Jenkins Base URL <span class="req">*</span></label>
        <div class="jira-field-url-row">
          <input class="s-jenkins-url jira-field-input" id="s-jenkins-url-input" type="url" value="${escHtml(cfg.jenkinsUrl || '')}" placeholder="https://jenkins.example.com" readonly/>
          <span class="jira-edit-icon" onclick="editJiraUrl('s-jenkins-url-input')" title="Edit Jenkins URL">✏️</span>
        </div>
      </div>
      <div class="field">
        <label>Jenkins API Token <span class="req">*</span></label>
        ${tokenFieldHtml('s-jenkins-token-input', 's-jenkins-token', loadJenkinsCredentials()?.token, 'Required — paste your Jenkins API token')}
        <div class="field-hint">Saved on this device and reused · <a href="#" onclick="event.preventDefault();openJenkinsSecurityPage('s-jenkins-url-input');" style="color:var(--accent)">↗ Generate token</a></div>
      </div>
    </div>

    ${settingsSectionHeader('sec-jira', 'JIRA')}
    <div class="settings-section-body hidden" id="sec-jira">
      <div class="jira-settings-status" id="jira-settings-status">
        ${_jiraConfigured
          ? `<span class="jira-status-connected">✓ Connected${_jiraData?.jiraEmail ? ' as <strong>' + escHtml(_jiraData.jiraEmail) + '</strong>' : ''}</span>`
          : `<span class="jira-status-none">Not connected</span>`}
      </div>
      <div class="field">
        <label>JIRA URL</label>
        <div class="jira-field-url-row">
          <input class="s-jira-url jira-field-input" id="s-jira-url-input" type="url" value="${escHtml(_jiraData?.jiraUrl || '')}" placeholder="https://jira.yourcompany.com" readonly/>
          <span class="jira-edit-icon" onclick="editJiraUrl('s-jira-url-input')" title="Edit JIRA URL">✏️</span>
        </div>
      </div>
      <div class="field">
        <label>API Token</label>
        ${tokenFieldHtml('s-jira-token-input', 's-jira-token', loadJiraCookie(), 'Paste Atlassian API token')}
        <div class="field-hint"><span class="link-text" onclick="openJiraTokenPage()">Generate token at id.atlassian.com ↗</span></div>
      </div>
      <div class="jira-settings-actions">
        <button class="btn btn-primary btn-sm" type="button" id="s-jira-connect-btn" onclick="settingsConnectJira()">Connect &amp; Verify</button>
        ${_jiraConfigured ? `<button class="btn btn-ghost btn-sm" type="button" onclick="disconnectJira()" style="color:var(--red)">Disconnect</button>` : ''}
      </div>
      <div id="s-jira-msg" class="field-hint" style="margin-top:6px;min-height:18px"></div>
    </div>

    ${settingsSectionHeader('sec-perfdiag', 'Performance Diagnostics',
      `<button class="btn btn-ghost btn-sm" type="button" onclick="event.stopPropagation();openPerfEnvModal()" style="margin-left:auto;font-size:11px;padding:2px 10px">+ Add Environment</button>`)}
    <div class="settings-section-body hidden" id="sec-perfdiag">
      <div id="perf-env-list"></div>
    </div>

    ${settingsSectionHeader('sec-diagnostics', 'Diagnostics')}
    <div class="settings-section-body hidden" id="sec-diagnostics">
      <label class="check-row" style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer">
        <input type="checkbox" id="s-error-reporting" ${cfg.errorReportingEnabled ? 'checked' : ''}/>
        Save crash/error details locally
      </label>
      <div class="field-hint" style="margin-top:6px">
        Off by default. When on, unexpected errors are appended to <code>~/oasis/error.txt</code> — nothing is sent anywhere automatically yet.
      </div>
    </div>

    ${settingsSectionHeader('sec-macpw', 'Mac Password')}
    <div class="settings-section-body hidden" id="sec-macpw">
      <div class="field">
        <label>Login Password <span class="opt">optional</span></label>
        <div class="input-with-btn">
          <input class="s-macpw" id="s-macpw-input" type="password" placeholder="${loadSudoPassword() ? '●●●●●●●● (saved)' : 'Enter to pre-authorize sudo for setup scripts'}"/>
          <button class="btn btn-ghost btn-sm" type="button" id="s-macpw-verify-btn" onclick="verifySudoPassword()" style="flex-shrink:0">Verify</button>
        </div>
        <label class="check-row" style="margin-top:8px;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer">
          <input type="checkbox" id="s-macpw-remember" ${loadSudoPassword() ? 'checked' : ''}/>
          Save password on this device
        </label>
        <div class="field-hint" id="s-macpw-hint" style="margin-top:6px">${loadSudoPassword() ? '✓ Password saved — will be applied automatically on next launch.' : 'Used locally for <code>sudo</code> during setup only.'}</div>
      </div>
    </div>`;
  syncExternalCallsControl();
  populateAwsProfiles(cfg.awsProfile);
  populateAiProviders();
  refreshPerfEnvironmentsList();
}

// Fill the AWS profile dropdown from the machine's configured profiles. Keeps
// the currently-selected value even if it isn't in the list, and falls back to
// just "default" when the AWS CLI isn't installed/configured.
async function populateAwsProfiles(selected) {
  const sel = document.getElementById('s-aws-select');
  if (!sel) return;
  const cur = (selected || 'default');
  try {
    const resp = await fetch(`${API}/api/aws-profiles`);
    const { profiles = [] } = await resp.json();
    const list = profiles.length ? profiles.slice() : [];
    if (!list.includes('default')) list.unshift('default');
    if (cur && !list.includes(cur)) list.unshift(cur);
    sel.innerHTML = list.map(p => `<option value="${escHtml(p)}" ${p === cur ? 'selected' : ''}>${escHtml(p)}</option>`).join('');
  } catch (_) { /* keep the single fallback option already rendered */ }
}

// The API key never lives in cfg/~/.oasis-prefs.json — same reasoning as the
// PAT/Jenkins token: a cookie survives Electron's per-launch random port,
// where localStorage/prefs would otherwise be an unencrypted-at-rest secret
// sitting in a plain JSON file.
function saveAiApiKey(key) {
  if (key) setCookie(AI_KEY_COOKIE, key, TOKEN_COOKIE_DAYS); else deleteCookie(AI_KEY_COOKIE);
}
function loadAiApiKey() { return getCookie(AI_KEY_COOKIE) || ''; }

let _aiProviders = [];   // catalog from /api/ai/providers: [{id,label,fields}]

// Fetch the provider catalog once, populate the Provider dropdown (keeping
// the saved choice selected even before the fetch lands), then render that
// provider's fields.
async function populateAiProviders() {
  const sel = document.getElementById('s-ai-provider-select');
  if (!sel) return;
  const cur = cfg.aiProvider || '';
  try {
    const resp = await fetch(`${API}/api/ai/providers?session=${sessionId}`);
    const { providers = [] } = await resp.json();
    _aiProviders = providers;
    sel.innerHTML = providers.map(p => `<option value="${escHtml(p.id)}" ${p.id === cur ? 'selected' : ''}>${escHtml(p.label)}</option>`).join('');
    renderAiFields(sel.value);
  } catch (_) {
    sel.innerHTML = '<option value="">Could not load providers</option>';
  }
}

function onAiEnabledChange() {
  const on = document.getElementById('s-ai-enabled')?.checked;
  document.getElementById('ai-config')?.classList.toggle('hidden', !on);
}

// Builds the field list for whichever provider is selected. Every field a
// provider needs comes from its own declared schema — nothing here is
// hardcoded per-provider, so a new provider adapter shows up correctly with
// zero frontend changes.
function renderAiFields(providerId) {
  const wrap = document.getElementById('ai-fields');
  if (!wrap) return;
  const provider = _aiProviders.find(p => p.id === providerId);
  if (!provider) { wrap.innerHTML = ''; return; }

  wrap.innerHTML = provider.fields.map(f => {
    if (f.type === 'password') {
      const val = f.key === 'apiKey' ? loadAiApiKey() : '';
      return `<div class="field">
        <label>${escHtml(f.label)}</label>
        ${tokenFieldHtml(`s-ai-${f.key}-input`, `s-ai-${f.key}`, val, `Enter your ${escHtml(f.label)}`)}
      </div>`;
    }
    if (f.type === 'model-select') {
      // Starts as a plain text field pre-filled with the saved model (if
      // any) — becomes a live dropdown once the credential field above is
      // filled in and the fetch succeeds (see fetchAiModels()).
      return `<div class="field">
        <label>${escHtml(f.label)}</label>
        <input class="s-ai-${f.key}" id="s-ai-${f.key}-input" type="text" value="${escHtml(cfg.aiProvider === providerId ? (cfg.aiModel || '') : '')}" placeholder="Fill in the field(s) above first, or type a model name directly"/>
      </div>`;
    }
    // Plain text field (Bedrock's model id/ARN, Ollama's host).
    const val = f.key === 'model' ? (cfg.aiProvider === providerId ? (cfg.aiModel || '') : '')
              : f.key === 'host'  ? (cfg.aiProvider === providerId ? (cfg.aiHost  || '') : '')
              : '';
    return `<div class="field">
      <label>${escHtml(f.label)}</label>
      <input class="s-ai-${f.key}" id="s-ai-${f.key}-input" type="text" value="${escHtml(val)}" placeholder="${escHtml(f.placeholder || '')}"/>
    </div>`;
  }).join('');

  // Wire up live model-fetching: any non-model field (apiKey/host) triggers
  // a fetch attempt on blur; the model field only reacts, it isn't a trigger.
  for (const f of provider.fields) {
    if (f.type === 'model-select') continue;
    const el = document.getElementById(`s-ai-${f.key}-input`);
    if (el) el.addEventListener('blur', () => fetchAiModels(providerId));
  }
}

// Called when a credential field (apiKey/host) loses focus. Fetches that
// provider's live model list and turns the model field into a <select> —
// on any failure (bad key, unreachable host, no listModels at all) the
// field is left as free text instead, so entering a model is never blocked.
async function fetchAiModels(providerId) {
  const provider = _aiProviders.find(p => p.id === providerId);
  const modelField = provider?.fields.find(f => f.type === 'model-select');
  if (!modelField) return;
  const input = document.getElementById(`s-ai-${modelField.key}-input`);
  if (!input) return;

  const apiKey = document.getElementById('s-ai-apiKey-input')?.value || '';
  const host   = document.getElementById('s-ai-host-input')?.value || '';
  if (!apiKey && !host) return;   // nothing to fetch with yet

  const prevValue = input.value;
  try {
    const resp = await fetch(`${API}/api/ai/models`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, provider: providerId, apiKey, host }),
    });
    const data = await resp.json();
    if (!resp.ok || !data.models?.length) return;   // leave the text field as-is

    const select = document.createElement('select');
    select.className = `s-ai-${modelField.key}`;
    select.id = `s-ai-${modelField.key}-input`;
    select.innerHTML = data.models.map(m =>
      `<option value="${escHtml(m)}" ${m === prevValue ? 'selected' : ''}>${escHtml(m)}</option>`
    ).join('') + `<option value="__manual__">Other (type manually)…</option>`;
    select.onchange = () => {
      if (select.value !== '__manual__') return;
      const replacement = document.createElement('input');
      replacement.type = 'text'; replacement.className = select.className; replacement.id = select.id;
      replacement.placeholder = 'Model name';
      select.replaceWith(replacement);
    };
    input.replaceWith(select);
  } catch (_) { /* leave the text field as-is */ }
}

// Sends a tiny completion request through whatever provider/apiKey/host/model
// are currently typed in — no need to Save first — so a bad key or wrong
// model shows up immediately instead of only after the next AI feature runs.
async function testAiConnection() {
  const btn = document.getElementById('s-ai-test-btn');
  const msg = document.getElementById('s-ai-test-msg');
  const providerId = document.getElementById('s-ai-provider-select')?.value;
  const model = document.getElementById('s-ai-model-input')?.value?.trim();
  if (!providerId || !model) {
    if (msg) { msg.textContent = 'Choose a provider and model first'; msg.style.color = 'var(--text2)'; }
    return;
  }
  const apiKey = document.getElementById('s-ai-apiKey-input')?.value || '';
  const host   = document.getElementById('s-ai-host-input')?.value || '';

  if (btn) { btn.disabled = true; btn.textContent = 'Testing…'; }
  if (msg) { msg.textContent = ''; }
  try {
    const resp = await fetch(`${API}/api/ai/test`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, provider: providerId, apiKey, host, model }),
    });
    const data = await resp.json();
    if (!resp.ok || !data.ok) throw new Error(data.error || 'Connection failed');
    if (msg) { msg.textContent = '✓ Connected'; msg.style.color = 'var(--green)'; }
  } catch (e) {
    if (msg) { msg.textContent = '✕ ' + e.message; msg.style.color = 'var(--red)'; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Test connection'; }
  }
}

async function saveSettings() {
  const body = document.getElementById('settings-body');
  const get = cls => body.querySelector('.' + cls)?.value?.trim() || '';
  cfg.githubUrl    = get('s-ghurl')  || cfg.githubUrl;
  cfg.org          = get('s-org')    || cfg.org;
  const tok        = get('s-token');
  if (tok) {
    cfg.token = tok;
    // If the PAT is being remembered, keep the cookie in sync with the new value
    if (getCookie(TOKEN_COOKIE)) setCookie(TOKEN_COOKIE, tok, TOKEN_COOKIE_DAYS);
  }
  cfg.cloneDir       = get('s-dir')  || cfg.cloneDir;
  cfg.intellijPath   = get('s-ij')   || '';
  cfg.javaHome       = get('s-java') || '';
  cfg.mavenArgs      = get('s-mvn')  || '';
  cfg.extraEnv       = get('s-env')  || '';
  cfg.awsProfile     = get('s-aws')    || '';
  cfg.jenkinsUrl     = get('s-jenkins-url') || cfg.jenkinsUrl;
  const jTok = get('s-jenkins-token');
  if (jTok) { cfg.jenkinsToken = jTok; saveJenkinsCredentials({ token: jTok }); }

  cfg.errorReportingEnabled = document.getElementById('s-error-reporting')?.checked === true;
  cfg.aiEnabled  = document.getElementById('s-ai-enabled')?.checked !== false;
  cfg.aiProvider = document.getElementById('s-ai-provider-select')?.value || '';
  cfg.aiModel    = get('s-ai-model');
  cfg.aiHost     = get('s-ai-host');
  cfg.aiApiKey   = get('s-ai-apiKey');   // in-memory only — stripped before any on-disk save, see state.js
  saveAiApiKey(cfg.aiApiKey);

  const saveBtn = document.getElementById('settings-save-btn');
  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

  try {
    // Re-create session
    const resp = await fetch(`${API}/api/session`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cfg)
    });
    if (!resp.ok) {
      const d = await resp.json().catch(() => ({}));
      throw new Error(d.error || `Server returned ${resp.status}`);
    }
    const d = await resp.json();
    sessionId = d.sessionId;
    connectWebSocket();
    // Re-creating the session above starts fresh with no JIRA and no sudo
    // password attached server-side — re-apply both from what's saved on this
    // device so saving an unrelated setting (e.g. Maven args) doesn't cause
    // "Connect JIRA first" or a surprise sudo-password prompt mid-setup later.
    await autoConnectJira();
    await autoConnectPerfDiagnostics();
    await applySavedSudoPassword();

    saveCache();
    renderTopbar();
    toast('Settings saved successfully', 'success');
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.textContent = '✓ Saved';
      setTimeout(() => { if (saveBtn.textContent === '✓ Saved') saveBtn.textContent = 'Save Changes'; }, 1800);
    }
  } catch (e) {
    toast('Failed to save settings: ' + e.message, 'error');
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Changes'; }
  }
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

// ── Script Generator ────────────────────────────────────────────────────────
function openScriptGenerator() {
  // Reset to initial state
  document.getElementById('scriptgen-progress').style.display = 'none';
  document.getElementById('scriptgen-done').style.display = 'none';
  document.getElementById('scriptgen-log').innerHTML = '';
  document.getElementById('scriptgen-status').textContent = '';
  document.getElementById('scriptgen-summary').innerHTML = '';
  document.getElementById('scriptgen-generated-list').innerHTML = '';
  const btn = document.getElementById('scriptgen-run-btn');
  btn.disabled = false; btn.textContent = '⚡ Generate Scripts';
  document.getElementById('scriptgen-footer').style.display = '';
  document.getElementById('scriptgen-modal').classList.remove('hidden');
}

async function runScriptGenerator() {
  const btn = document.getElementById('scriptgen-run-btn');
  btn.disabled = true; btn.textContent = 'Running…';
  document.getElementById('scriptgen-progress').style.display = 'block';
  document.getElementById('scriptgen-status').textContent = 'Starting…';

  try {
    const resp = await fetch(`${API}/api/generate-scripts`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Failed to start');
  } catch (e) {
    document.getElementById('scriptgen-status').textContent = '✗ ' + e.message;
    btn.disabled = false; btn.textContent = '⚡ Generate Scripts';
  }
}

function _scriptgenLog(msg, cls = '') {
  const log = document.getElementById('scriptgen-log');
  if (!log) return;
  const line = document.createElement('div');
  if (cls) line.style.color = cls === 'ok' ? '#34d399' : cls === 'err' ? 'var(--red)' : 'var(--text3)';
  line.textContent = msg;
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}

function onScriptGenProgress(msg) {
  const el = document.getElementById('scriptgen-status');
  if (el) el.textContent = msg.message || '';
  if (msg.total > 0) _scriptgenLog(msg.message);
}

function onScriptGenCreated(msg) {
  _scriptgenLog(`✓ ${msg.repo} — script generated`, 'ok');
}

function onScriptGenFailed(msg) {
  _scriptgenLog(`✗ ${msg.repo} — ${msg.error}`, 'err');
}

function onScriptGenDone(msg) {
  document.getElementById('scriptgen-progress').style.display = 'none';
  document.getElementById('scriptgen-done').style.display = 'block';
  document.getElementById('scriptgen-summary').textContent = msg.message;

  const list = document.getElementById('scriptgen-generated-list');
  if (msg.generated && msg.generated.length) {
    list.innerHTML = msg.generated.map(n => `<div style="color:#34d399">✓ scripts/${escHtml(n)}.sh</div>`).join('');
  } else {
    list.innerHTML = '<div style="color:var(--text3)">No scripts generated — all repos use the default setup.</div>';
  }

  const footer = document.getElementById('scriptgen-footer');
  footer.innerHTML = `<button class="btn btn-ghost" onclick="closeModal('scriptgen-modal')">Close</button>`;

  // Refresh repo list so new script badges appear
  if (msg.generated && msg.generated.length) filterRepos();
}

function onScriptGenError(msg) {
  const el = document.getElementById('scriptgen-status');
  if (el) { el.style.color = 'var(--red)'; el.textContent = '✗ ' + (msg.message || 'Generation failed'); }
  const btn = document.getElementById('scriptgen-run-btn');
  if (btn) { btn.disabled = false; btn.textContent = '⚡ Generate Scripts'; }
}

async function verifySudoPassword() {
  const input    = document.getElementById('s-macpw-input');
  const hint     = document.getElementById('s-macpw-hint');
  const btn      = document.getElementById('s-macpw-verify-btn');
  const remember = document.getElementById('s-macpw-remember')?.checked;
  const pw = input?.value || '';
  if (!pw) { if (hint) hint.textContent = 'Enter your Mac login password first.'; return; }

  if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }
  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (data.ok) {
      if (remember) saveSudoPassword(pw); else clearSudoPassword();
      if (hint) { hint.style.color = 'var(--green, #34d399)'; hint.textContent = '✓ Password verified' + (remember ? ' and saved for future sessions.' : ' for this session.'); }
      if (input) input.value = '';
    } else {
      if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + (data.error || 'Incorrect password — try again.'); }
    }
  } catch (e) {
    if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ Could not verify: ' + e.message; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Verify'; }
  }
}

// Called when the server signals that sudo failed mid-run (password expired).
const SUDO_PW_KEY = 'iready_oasis_sudopw';

function saveSudoPassword(pw) {
  try { localStorage.setItem(SUDO_PW_KEY, pw); } catch(e) {}
}
function loadSudoPassword() {
  try { return localStorage.getItem(SUDO_PW_KEY) || ''; } catch(e) { return ''; }
}
function clearSudoPassword() {
  try { localStorage.removeItem(SUDO_PW_KEY); } catch(e) {}
}

function showSudoPrompt(reason) {
  const existing = document.getElementById('sudo-prompt-modal');
  if (existing) existing.remove();

  const hasSaved = !!loadSudoPassword();
  const modal = document.createElement('div');
  modal.id = 'sudo-prompt-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal" style="max-width:400px">
      <div class="modal-header">
        <div class="modal-title">Mac Password Required</div>
        <button class="modal-close" onclick="document.getElementById('sudo-prompt-modal').remove()">✕</button>
      </div>
      <div class="modal-body">
        <p style="font-size:14px;color:var(--text2);margin:0 0 14px">${escHtml(reason || 'Enter your Mac login password to continue setup.')}</p>
        <div class="field">
          <label>Mac Login Password</label>
          <input id="sudo-prompt-pw" type="password" class="s-macpw" placeholder="Password" autofocus
            onkeydown="if(event.key==='Enter') submitSudoPrompt()"/>
        </div>
        <label class="check-row" style="margin-top:10px;display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2);cursor:pointer">
          <input type="checkbox" id="sudo-prompt-remember" ${hasSaved ? 'checked' : ''}/>
          Save password on this device for future sessions
        </label>
        <div id="sudo-prompt-hint" style="font-size:12px;color:var(--text3);margin-top:8px">
          ${hasSaved ? 'A password is already saved — enter a new one to replace it.' : 'Used locally for sudo during setup only.'}
        </div>
      </div>
      <div class="modal-footer">
        ${hasSaved ? `<button class="btn btn-ghost" onclick="clearSudoPassword();document.getElementById('sudo-prompt-modal').remove();toast('Saved password cleared','info')">Clear saved</button>` : `<button class="btn btn-ghost" onclick="document.getElementById('sudo-prompt-modal').remove()">Cancel</button>`}
        <button class="btn btn-primary" onclick="submitSudoPrompt()">Save Password</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
  setTimeout(() => document.getElementById('sudo-prompt-pw')?.focus(), 50);
}

async function submitSudoPrompt() {
  const input    = document.getElementById('sudo-prompt-pw');
  const hint     = document.getElementById('sudo-prompt-hint');
  const remember = document.getElementById('sudo-prompt-remember')?.checked;
  const pw = input?.value || '';
  if (!pw) return;

  try {
    const resp = await fetch(`${API}/api/sudo-password`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId, password: pw }),
    });
    const data = await resp.json();
    if (data.ok) {
      if (remember) saveSudoPassword(pw);
      else clearSudoPassword();
      document.getElementById('sudo-prompt-modal')?.remove();
      toast('Password accepted — continuing setup…', 'success');
    } else {
      if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + (data.error || 'Incorrect — try again.'); }
      if (input) input.value = '';
    }
  } catch (e) {
    if (hint) { hint.style.color = 'var(--red)'; hint.textContent = '✗ ' + e.message; }
  }
}
