'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { aprGroupedBars, aprHorizontalBars, aprHistogram, aprDataTable, aprEsc } = require('./appraisal-charts');

const weekly = {
  id: 'c1', title: 'Weekly throughput', desc: 'Tickets opened and closed per week',
  categories: ['05 Jan', '12 Jan', '19 Jan'],
  series: [{ name: 'Opened', values: [3, 0, 5] }, { name: 'Closed', values: [2, 4, 1] }],
};

test('grouped bars are an accessible, labelled SVG with a bar per value and a legend', () => {
  const svg = aprGroupedBars(weekly);
  assert.match(svg, /^<svg [^>]*role="img"/);
  assert.match(svg, /aria-labelledby="c1-t c1-d"/);
  assert.match(svg, /<title id="c1-t">Weekly throughput<\/title>/);
  assert.equal((svg.match(/<rect x=.*?<title>/g) || []).length, 6);
  assert.match(svg, />Opened<\/text>/);
  assert.match(svg, />Closed<\/text>/);
  assert.match(svg, /Opened, 05 Jan: 3/);
});

test('output is deterministic and never contains NaN or undefined', () => {
  assert.equal(aprGroupedBars(weekly), aprGroupedBars(weekly));
  for (const svg of [aprGroupedBars(weekly), aprGroupedBars({ ...weekly, series: [{ name: 'Z', values: [0, 0, 0] }] }),
    aprHorizontalBars({ id: 'h', title: 't', desc: 'd', items: [{ name: 'Bug', value: 0, label: '0' }] }),
    aprHistogram({ id: 'g', title: 't', desc: 'd', bins: [{ from: 0, to: 1, label: '0-1', count: 0 }], median: 0, p90: null })]) {
    assert.doesNotMatch(svg, /NaN|undefined|Infinity/);
  }
});

test('empty data gives an empty string so the caller can show its own message', () => {
  assert.equal(aprGroupedBars({ ...weekly, categories: [] }), '');
  assert.equal(aprGroupedBars({ ...weekly, series: [] }), '');
  assert.equal(aprHorizontalBars({ id: 'h', title: 't', desc: 'd', items: [] }), '');
  assert.equal(aprHistogram({ id: 'g', title: 't', desc: 'd', bins: [], median: 1, p90: 2 }), '');
  assert.equal(aprDataTable(['a'], []), '');
});

test('labels and titles are escaped, so a type or sprint name cannot inject markup', () => {
  const evil = '<script>alert(1)</script>"&';
  const svg = aprGroupedBars({ ...weekly, title: evil, categories: [evil, 'b', 'c'], series: [{ name: evil, values: [1, 2, 3] }] });
  assert.doesNotMatch(svg, /<script>/);
  assert.match(svg, /&lt;script&gt;/);
  const bars = aprHorizontalBars({ id: 'h"x', title: 't', desc: 'd', items: [{ name: evil, value: 2, label: evil }] });
  assert.doesNotMatch(bars, /<script>|id="h"x"/);
  assert.equal(aprEsc("a'b"), 'a&#39;b');
});

test('the print palette uses fixed colours and a hatched second series; the screen palette follows the theme', () => {
  const print = aprGroupedBars({ ...weekly, theme: 'print' });
  const screen = aprGroupedBars({ ...weekly, theme: 'screen' });
  assert.match(print, /<pattern id="c1-hatch"/);
  assert.match(print, /fill:url\(#c1-hatch\)/);
  assert.doesNotMatch(print, /var\(--/);
  assert.match(screen, /var\(--accent\)/);
  assert.doesNotMatch(screen, /<pattern/);
});

test('many categories thin out their axis labels but keep every bar', () => {
  const categories = Array.from({ length: 40 }, (_, i) => `W${i}`);
  const svg = aprGroupedBars({ ...weekly, categories, series: [{ name: 'Closed', values: categories.map((_, i) => i % 5) }] });
  assert.equal((svg.match(/<rect x=.*?<title>/g) || []).length, 40);
  assert.ok((svg.match(/text-anchor="middle" font-size="9" style="fill:#?[\w(--)]*">W\d+</g) || []).length <= 14);
});

test('horizontal bars scale to the largest value and print each label', () => {
  const svg = aprHorizontalBars({ id: 'h', title: 'Median by type', desc: 'd', items: [{ name: 'Bug', value: 2, label: '2 days' }, { name: 'Story', value: 8, label: '8 days' }] });
  assert.match(svg, />Bug<\/text>/);
  assert.match(svg, />8 days<\/text>/);
  const widths = [...svg.matchAll(/<rect x="150" y="\d+" width="([\d.]+)"/g)].map(m => Number(m[1]));
  assert.equal(widths.length, 2);
  assert.ok(widths[1] > widths[0] * 3.9 && widths[1] < widths[0] * 4.1);
});

test('the histogram marks the median and 90th percentile, and leaves out a marker with no value', () => {
  const bins = [{ from: 0, to: 1, label: '0-1', count: 1 }, { from: 1, to: 2, label: '1-2', count: 4 }, { from: 2, to: null, label: '2+', count: 2 }];
  const both = aprHistogram({ id: 'g', title: 't', desc: 'd', bins, median: 1.5, p90: 5 });
  assert.match(both, /Median 1\.5 d/);
  assert.match(both, /90th pct 5 d/);
  const few = aprHistogram({ id: 'g', title: 't', desc: 'd', bins, median: 1.5, p90: null });
  assert.match(few, /Median 1\.5 d/);
  assert.doesNotMatch(few, /90th pct/);
  const x = svg => Number(/<line x1="([\d.]+)"[^>]*stroke-dasharray/.exec(svg)[1]);
  const early = aprHistogram({ id: 'g', title: 't', desc: 'd', bins, median: 0.2, p90: null });
  assert.ok(x(early) < x(few), 'a smaller value sits further left');
});

test('a data table carries the same numbers, escaped', () => {
  const html = aprDataTable(['Week', 'Closed'], [['05 Jan', 2], ['<b>', 4]]);
  assert.match(html, /<th>Week<\/th>/);
  assert.match(html, /<td>05 Jan<\/td><td>2<\/td>/);
  assert.match(html, /&lt;b&gt;/);
});

test('a compact width gives a smaller canvas and sparser axis labels, still with every bar', () => {
  const categories = Array.from({ length: 26 }, (_, i) => `W${i}`);
  const compact = aprGroupedBars({ ...weekly, categories, series: [{ name: 'Closed', values: categories.map((_, i) => i % 4) }], width: 360, height: 170 });
  assert.match(compact, /viewBox="0 0 360 170"/);
  assert.equal((compact.match(/<rect x=.*?<title>/g) || []).length, 26);
  const labels = (compact.match(/text-anchor="middle" font-size="9" style="fill:[^"]*">W\d+</g) || []).length;
  assert.ok(labels <= 6, `${labels} axis labels`);
  const hist = aprHistogram({ id: 'g', title: 't', desc: 'd', width: 360, height: 170, bins: [{ from: 0, to: 1, label: '0-1', count: 2 }, { from: 1, to: null, label: '1+', count: 1 }], median: 0.5, p90: null });
  assert.match(hist, /viewBox="0 0 360 170"/);
  assert.doesNotMatch(compact + hist, /NaN|undefined/);
});
