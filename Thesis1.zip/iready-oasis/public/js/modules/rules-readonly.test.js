'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const R = require('./rules-readonly');

// A tiny DOM: enough to build the view with createElement and read it back.
class El {
  constructor(tag) { this.tagName = tag.toUpperCase(); this.children = []; this.attrs = {}; this.listeners = {}; this._text = ''; this.className = ''; this.value = ''; this.checked = false; this.disabled = false; }
  get textContent() { return this._text + this.children.map((c) => c.textContent).join(''); }
  set textContent(v) { this._text = String(v); this.children = []; }
  appendChild(c) { this.children.push(c); return c; }
  append(...cs) { for (const c of cs) this.children.push(typeof c === 'string' ? Object.assign(new El('#text'), { _text: c }) : c); }
  replaceChildren(...cs) { this.children = []; this._text = ''; this.append(...cs); }
  setAttribute(k, v) { this.attrs[k] = String(v); }
  addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); }
  fire(t) { for (const f of this.listeners[t] || []) f({ target: this }); }
  all(pred, out = []) { if (pred(this)) out.push(this); for (const c of this.children) c.all(pred, out); return out; }
}
const doc = { createElement: (t) => new El(t), createTextNode: (t) => Object.assign(new El('#text'), { _text: String(t) }) };

const VIEW = (over = {}) => ({
  mode: 'installed', release: { number: 7, installedAt: '2026-10-12T10:00:00.000Z' }, updateAvailable: false, updateError: null,
  rules: [
    { id: 'java-sqli', title: 'SQL injection', language: 'java', pillar: 'security', severity: 'HIGH', engine: 'ast' },
    { id: 'py-eval', title: 'eval of input', language: 'python', pillar: 'reliability', severity: 'MEDIUM', engine: 'pattern' },
  ], overrides: { disabled: [], severity: {} }, ...over,
});

test('banner names the release and when it was installed', () => {
  assert.match(R.rroBanner(VIEW(), 'en-US'), /^Using rules from release 7, updated /);
  assert.equal(R.rroBanner(VIEW({ release: null })), 'No rules release is installed yet.');
});

test('state: legacy, error, empty and ready are told apart', () => {
  assert.equal(R.rroState({ mode: 'legacy' }), 'legacy');
  assert.equal(R.rroState(VIEW()), 'ready');
  assert.equal(R.rroState(VIEW({ release: null, rules: [], updateError: { code: 'NO_PINNED_KEYS', message: 'm' } })), 'error');
  assert.equal(R.rroState(VIEW({ release: null, rules: [] })), 'empty');
  assert.equal(R.rroState(VIEW({ updateError: { code: 'OFFLINE', message: 'm' } })), 'ready', 'offline with rules installed still shows the rules');
});

test('draft/body: only changes are sent, and a severity equal to the release default is not an override', () => {
  const view = VIEW();
  const draft = R.rroDraftFrom(view.overrides);
  R.rroSetDisabled(draft, 'py-eval', true);
  R.rroSetSeverity(draft, view.rules[0], 'LOW');
  R.rroSetSeverity(draft, view.rules[1], 'MEDIUM');
  assert.deepEqual(R.rroBody(draft), { disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } });
  assert.equal(R.rroIsOverridden(draft, view.rules[0]), true);
  assert.equal(R.rroIsOverridden(draft, view.rules[1]), true);
  R.rroReset(draft);
  assert.deepEqual(R.rroBody(draft), { disabled: [], severity: {} });
});

test('ready view: one row per rule with language, pillar, severity, a toggle and a severity select', () => {
  const root = new El('div');
  R.rroRender(doc, root, VIEW(), { projects: ['shop'], project: 'shop', draft: R.rroDraftFrom({ disabled: ['py-eval'], severity: { 'java-sqli': 'LOW' } }), handlers: {} });
  const rows = root.all((e) => e.attrs['data-rule']);
  assert.equal(rows.length, 2);
  const first = rows[0];
  assert.match(first.textContent, /java-sqli/);
  assert.match(first.textContent, /java/);
  assert.match(first.textContent, /security/);
  assert.equal(first.all((e) => e.tagName === 'SELECT')[0].value, 'LOW');
  assert.match(first.textContent, /override/i, 'a changed severity is marked');
  assert.equal(rows[1].all((e) => e.tagName === 'INPUT' && e.attrs.type === 'checkbox')[0].checked, false, 'disabled rule: switch off');
  assert.match(root.textContent, /Using rules from release 7/);
});

test('no editing controls: no textarea, no "New rule" button, no text inputs for definitions', () => {
  const root = new El('div');
  R.rroRender(doc, root, VIEW({ updateAvailable: true }), { projects: ['shop'], project: 'shop', draft: R.rroDraftFrom({}), handlers: {} });
  assert.equal(root.all((e) => e.tagName === 'TEXTAREA').length, 0);
  assert.equal(root.all((e) => e.tagName === 'INPUT' && e.attrs.type === 'text').length, 0);
  assert.doesNotMatch(root.textContent, /new rule/i);
  assert.match(root.textContent, /Update available/);
  const buttons = root.all((e) => e.tagName === 'BUTTON').map((b) => b.textContent);
  assert.deepEqual(buttons.filter((t) => /save|reset/i.test(t)).sort(), ['Reset', 'Save']);
});

test('save and reset call the handlers; project select and toggle changes reach them', () => {
  const calls = [];
  const root = new El('div');
  const draft = R.rroDraftFrom({});
  R.rroRender(doc, root, VIEW(), { projects: ['a', 'b'], project: 'a', draft, handlers: { save: () => calls.push('save'), reset: () => calls.push('reset'), project: (p) => calls.push(`project:${p}`), change: () => calls.push('change') } });
  root.all((e) => e.tagName === 'BUTTON' && e.textContent === 'Save')[0].fire('click');
  root.all((e) => e.tagName === 'BUTTON' && e.textContent === 'Reset')[0].fire('click');
  const sel = root.all((e) => e.attrs.id === 'rro-project')[0];
  sel.value = 'b'; sel.fire('change');
  const toggle = root.all((e) => e.tagName === 'INPUT' && e.attrs.type === 'checkbox')[0];
  toggle.checked = false; toggle.fire('change');
  assert.deepEqual(calls, ['save', 'reset', 'project:b', 'change']);
  assert.deepEqual(draft.disabled, ['java-sqli']);
});

test('error and legacy states show the plain-language message', () => {
  const a = new El('div');
  R.rroRender(doc, a, VIEW({ release: null, rules: [], updateError: { code: 'NO_PINNED_KEYS', message: 'This build has no signing keys pinned.' } }), { projects: [], project: null, draft: R.rroDraftFrom({}), handlers: {} });
  assert.match(a.textContent, /no signing keys pinned/);
  const b = new El('div');
  R.rroRender(doc, b, { mode: 'legacy' }, { projects: [], project: null, draft: R.rroDraftFrom({}), handlers: {} });
  assert.match(b.textContent, /Rules come from the rule server; installed-release mode is not enabled \(set OASIS_ENGINE=installed\)/);
});

test('rule text is inserted as text, never parsed: a hostile title stays a string', () => {
  const root = new El('div');
  const evil = '<img src=x onerror=alert(1)>';
  R.rroRender(doc, root, VIEW({ rules: [{ id: 'x', title: evil, language: 'java', pillar: 'security', severity: 'HIGH', engine: 'ast' }] }), { projects: [], project: null, draft: R.rroDraftFrom({}), handlers: {} });
  assert.ok(root.textContent.includes(evil));
  assert.equal(root.all((e) => e.tagName === 'IMG').length, 0);
});

test('the module source never uses innerHTML, outerHTML or insertAdjacentHTML', () => {
  const src = fs.readFileSync(path.join(__dirname, 'rules-readonly.js'), 'utf8');
  assert.doesNotMatch(src, /innerHTML|outerHTML|insertAdjacentHTML|document\.write/);
});

test('index.html loads the module with a cache-busting version and has the container', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', '..', 'index.html'), 'utf8');
  assert.match(html, /<script src="js\/modules\/rules-readonly\.js\?v=\w+"><\/script>/);
  assert.match(html, /id="rro-root"/);
});

test('banner says "Development key" when the release was trusted through a dev signing key, and not otherwise', () => {
  assert.doesNotMatch(R.rroBanner(VIEW(), 'en-US'), /Development key/);
  assert.doesNotMatch(R.rroBanner(VIEW({ devKeys: [] }), 'en-US'), /Development key/);
  assert.match(R.rroBanner(VIEW({ devKeys: ['dev-1'] }), 'en-US'), /Development key \(dev-1\): this release is trusted from a local file, not the pinned production keys/);
  assert.match(R.rroBanner(VIEW({ release: null, devKeys: ['dev-1'] })), /^No rules release is installed yet\. Development key/);
});
