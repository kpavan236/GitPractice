// =============================================================================
// Version Watch — org-wide Maven/npm/pip dependency version + vulnerability tracker
// =============================================================================
let _vwData = { lastScanAt: null, rows: [], scanSummary: null };
let _vwSort = { key: null, dir: 1 };
let _vwEcosystemFilter = 'all';
let _vwNeedsUpgradeOnly = false;
let _vwLoaded = false;

// ── Stranded-scan watchdog ──────────────────────────────────────────────────
// A scan's terminal event (done/error) only ever arrives over the WebSocket,
// and the automatic background scan broadcasts with broadcastAll — which,
// unlike the manual path's broadcast(), keeps no queue and has no reconnect
// replay. An event sent while this tab's socket is momentarily closed is gone
// for good. Because the auto-scan is kicked off from inside /api/session, it
// always starts before the frontend has called connectWebSocket(), so this is
// not a rare race. The UI is then pinned to "Starting scan…" with Rescan
// disabled and no path back: nothing re-reads the server's state after the
// tab first loads.
//
// Rather than poll (the cache response is over a megabyte), watch for silence.
// A healthy scan emits a progress event per repo, so the timestamp keeps
// moving and no request is ever made. Only once events have stopped for
// VW_SCAN_STALL_MS do we ask the server whether a scan is genuinely still
// running — long enough to clear the repo-enumeration phase, which reports no
// progress while it pages through the org.
const VW_SCAN_STALL_MS = 90000;
const VW_SCAN_WATCHDOG_INTERVAL_MS = 30000;
let _vwLastScanEventAt = 0;
let _vwScanWatchdog = null;

function noteVwScanEvent() { _vwLastScanEventAt = Date.now(); }

function startVwScanWatchdog() {
  noteVwScanEvent();
  if (_vwScanWatchdog) return;
  _vwScanWatchdog = setInterval(checkForStrandedVwScan, VW_SCAN_WATCHDOG_INTERVAL_MS);
}

function stopVwScanWatchdog() {
  if (_vwScanWatchdog) { clearInterval(_vwScanWatchdog); _vwScanWatchdog = null; }
}

async function checkForStrandedVwScan() {
  if (Date.now() - _vwLastScanEventAt < VW_SCAN_STALL_MS) return;
  try {
    const resp = await fetch(`${API}/api/version-watch?session=${sessionId}`);
    if (!resp.ok) return;
    const data = await resp.json();
    // Still running — the scan is just in a quiet phase. Reset the clock so we
    // wait another full stall window before asking again.
    if (data.scanInFlight) { noteVwScanEvent(); return; }
    // The scan ended without this tab seeing its terminal event. Adopt the
    // server's cached result instead of stranding the UI.
    stopVwScanWatchdog();
    _vwData = { lastScanAt: null, rows: [], scanSummary: null, ...data };
    const btn = document.getElementById('vw-rescan-btn');
    const progressEl = document.getElementById('vw-scan-progress');
    if (btn) btn.disabled = false;
    if (progressEl) progressEl.classList.add('hidden');
    vwNormalizeEcosystemFilter();
    renderVersionWatchFilterChips();
    renderVersionWatchTable();
  } catch (_) { /* transient — retry on the next tick */ }
}

async function initVersionWatchTab() {
  if (_vwLoaded) { renderVersionWatchTable(); return; }
  const scanInFlight = await loadVersionWatchCache();
  _vwLoaded = true;
  renderVersionWatchFilterChips();
  renderVersionWatchTable();
  // A scan (manual or automatic) may already be running from before this
  // tab was opened/reloaded — reflect that immediately rather than showing
  // an enabled Rescan button that would just 409 if clicked.
  if (scanInFlight) onVersionScanStarted();
}

async function loadVersionWatchCache() {
  try {
    const resp = await fetch(`${API}/api/version-watch?session=${sessionId}`);
    if (!resp.ok) {
      const d = await resp.json().catch(() => ({}));
      throw new Error(d.error || 'failed to load');
    }
    const data = await resp.json();
    _vwData = { lastScanAt: null, rows: [], scanSummary: null, ...data };
    return !!data.scanInFlight;
  } catch (e) {
    toast('Failed to load Version Watch data: ' + e.message, 'error');
    return false;
  }
}

async function triggerVersionWatchScan() {
  const btn = document.getElementById('vw-rescan-btn');
  const progressEl = document.getElementById('vw-scan-progress');
  if (btn) btn.disabled = true;
  if (progressEl) { progressEl.classList.remove('hidden'); progressEl.textContent = 'Starting scan…'; }
  try {
    const resp = await fetch(`${API}/api/version-watch/scan`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: sessionId }),
    });
    if (!resp.ok) { const d = await resp.json(); throw new Error(d.error || 'failed to start scan'); }
    // Armed here as well as in onVersionScanStarted: if the server's
    // version_scan_started never reaches us, that handler never runs and the
    // watchdog would never be armed for the very case it exists to catch.
    startVwScanWatchdog();
  } catch (e) {
    stopVwScanWatchdog();
    if (btn) btn.disabled = false;
    if (progressEl) progressEl.classList.add('hidden');
    toast('Version Watch scan failed to start: ' + e.message, 'error');
  }
}

// Fired the moment ANY scan starts — including one triggered automatically
// in the background, or by a click in a different browser tab/window — so
// every open tab reflects the in-progress state and disables its own
// Rescan button, rather than only the tab that happened to click it.
function onVersionScanStarted() {
  const btn = document.getElementById('vw-rescan-btn');
  const progressEl = document.getElementById('vw-scan-progress');
  if (btn) btn.disabled = true;
  if (progressEl) { progressEl.classList.remove('hidden'); progressEl.textContent = 'Starting scan…'; }
  startVwScanWatchdog();
}

function onVersionScanProgress(msg) {
  const btn = document.getElementById('vw-rescan-btn');
  const progressEl = document.getElementById('vw-scan-progress');
  noteVwScanEvent();
  if (btn) btn.disabled = true;
  if (!progressEl) return;
  progressEl.classList.remove('hidden');
  if (msg.phase === 'enriching') {
    progressEl.textContent = `Looking up versions ${msg.current}/${msg.total}… (${msg.label})`;
  } else {
    progressEl.textContent = `Scanning repo ${msg.current}/${msg.total}… (${msg.label})`;
  }
}

function onVersionScanDone(msg) {
  stopVwScanWatchdog();
  _vwData = { lastScanAt: msg.lastScanAt, rows: msg.rows, scanSummary: msg.scanSummary };
  const btn = document.getElementById('vw-rescan-btn');
  const progressEl = document.getElementById('vw-scan-progress');
  if (btn) btn.disabled = false;
  if (progressEl) progressEl.classList.add('hidden');
  // Chips are derived from the scanned rows, so they have to be rebuilt on new
  // data — per-ecosystem counts change, and an ecosystem can appear or vanish.
  vwNormalizeEcosystemFilter();
  renderVersionWatchFilterChips();
  renderVersionWatchTable();
  toast(`Version Watch scan complete — ${_vwData.rows.length} tracked versions`, 'success');
}

function onVersionScanError(msg) {
  stopVwScanWatchdog();
  const btn = document.getElementById('vw-rescan-btn');
  const progressEl = document.getElementById('vw-scan-progress');
  if (btn) btn.disabled = false;
  if (progressEl) progressEl.classList.add('hidden');
  toast('Version Watch scan failed: ' + (msg.error || 'unknown error'), 'error');
}

function vwSetEcosystemFilter(eco) {
  _vwEcosystemFilter = eco;
  renderVersionWatchFilterChips();
  renderVersionWatchTable();
}

function vwToggleNeedsUpgradeOnly() {
  _vwNeedsUpgradeOnly = !_vwNeedsUpgradeOnly;
  renderVersionWatchFilterChips();
  renderVersionWatchTable();
}

function sortVersionWatchRows(key) {
  if (_vwSort.key === key) _vwSort.dir *= -1;
  else { _vwSort.key = key; _vwSort.dir = 1; }
  renderVersionWatchTable();
}

// Display labels mirroring server/version-watch/ecosystems.js. Duplicated
// rather than shared because this app has no build step between server and
// browser modules — the same reason vwCompareVersions is duplicated below. An
// ecosystem absent from this map falls back to its raw id, so a row from a
// newer scan than this bundle still renders as something readable.
const VW_ECOSYSTEM_LABELS = {
  maven: 'Maven', npm: 'npm', pip: 'Python', go: 'Go',
  cargo: 'Rust', nuget: '.NET', rubygems: 'Ruby', composer: 'PHP',
  swift: 'Swift', pub: 'Dart', hex: 'Elixir', hackage: 'Haskell',
  conan: 'C/C++', conda: 'Conda', cpan: 'Perl',
};

function vwEcosystemLabel(id) {
  return VW_ECOSYSTEM_LABELS[id] || id;
}

// Escapes a value for a single-quoted JS string inside a double-quoted HTML
// attribute. escHtml alone is not enough here: it leaves the single quote that
// would close the argument early, and these ids come from scan data rather than
// from a literal in this file.
function vwEscJsString(value) {
  return escHtml(String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'"));
}

// Ecosystems actually present in the scanned data, most rows first. Derived
// from the data rather than hardcoded so a newly supported ecosystem appears
// without a frontend change, and one with no rows doesn't clutter the filter.
function vwEcosystemCounts() {
  const counts = new Map();
  for (const row of _vwData.rows || []) {
    counts.set(row.ecosystem, (counts.get(row.ecosystem) || 0) + 1);
  }
  return [...counts].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
}

// Drops a filter that no longer matches anything. Without this, a rescan in
// which an ecosystem disappears (its last repo removed, say) leaves the table
// pinned to an empty view with no visible chip to click back out of.
function vwNormalizeEcosystemFilter() {
  if (_vwEcosystemFilter === 'all') return;
  if (!(_vwData.rows || []).some(row => row.ecosystem === _vwEcosystemFilter)) {
    _vwEcosystemFilter = 'all';
  }
}

function renderVersionWatchFilterChips() {
  const wrap = document.getElementById('vw-filter-chips');
  if (!wrap) return;
  const total = (_vwData.rows || []).length;
  const chips = [
    `<span class="dchip${_vwEcosystemFilter === 'all' ? ' active' : ''}" onclick="vwSetEcosystemFilter('all')">All <span class="dchip-count">${total}</span></span>`,
    ...vwEcosystemCounts().map(([id, count]) =>
      `<span class="dchip${_vwEcosystemFilter === id ? ' active' : ''}" onclick="vwSetEcosystemFilter('${vwEscJsString(id)}')">${escHtml(vwEcosystemLabel(id))} <span class="dchip-count">${count}</span></span>`
    ),
  ].join('');
  const upgradeChip = `<span class="dchip${_vwNeedsUpgradeOnly ? ' active' : ''}" onclick="vwToggleNeedsUpgradeOnly()">⚠️ Needs upgrade only</span>`;
  wrap.innerHTML = chips + upgradeChip;
}

// Critical is its own badge rather than sharing one with high. They are
// different decisions — a critical finding is the reason to stop and patch now —
// and folding them together made the worst rows in the table indistinguishable
// from merely-high ones.
function vwSeverityClass(sev) {
  if (!sev) return 'vw-sev-unknown'; // no severity data at all — distinct from an actual "low" finding
  const s = sev.toLowerCase();
  if (s === 'unknown') return 'vw-sev-unknown'; // a feed that spells it out, rather than omitting it
  if (s === 'critical') return 'vw-sev-critical';
  if (s === 'high') return 'vw-sev-high';
  if (s === 'moderate' || s === 'medium') return 'vw-sev-moderate';
  return 'vw-sev-low';
}

// Only http(s) links are rendered. Advisory URLs arrive from a third-party
// feed, and a javascript: URL turned into an <a href> would execute in this
// page's context.
function vwSafeUrl(url) {
  const value = String(url || '').trim();
  return /^https?:\/\//i.test(value) ? value : null;
}

// Priority: a known vulnerability outranks deprecated status, which
// outranks a plain up-to-date signal — matches the legend rendered above
// the table (red > amber > green).
function vwPackageClass(row) {
  if (row.status?.needsUpgrade) return 'vw-pkg-vulnerable';
  if (row.deprecated) return 'vw-pkg-deprecated';
  if (row.status?.upToDate) return 'vw-pkg-uptodate';
  return '';
}

// Text-based description of the same signal vwPackageClass colors — read by
// screen readers and shown as a tooltip, so the status isn't conveyed by
// color alone.
function vwPackageTitle(row) {
  if (row.status?.needsUpgrade) return 'Known vulnerability';
  if (row.deprecated) return 'Deprecated';
  if (row.status?.upToDate) return 'Up to date';
  return '';
}

// [dd/mm/yyyy], or '' when there's no date to show.
function vwFormatDateBracket(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  return `[${dd}/${mm}/${d.getFullYear()}]`;
}

// One "<symbol> <version>" / "[date]" row: symbol+version on the left, date
// right-aligned in the same row — two explicit flex children so
// justify-content:space-between pushes them to opposite ends regardless of
// version/date string length, rather than relying on wrapping (which
// previously let a "|" separator end up alone on its own line when the
// column was narrow).
function vwLatestVersionEntry(symbol, symbolTitle, version, dateIso) {
  const date = vwFormatDateBracket(dateIso);
  return `<span class="vw-lv-entry">` +
    `<span class="vw-lv-version"><span class="vw-lv-symbol" title="${escHtml(symbolTitle)}">${symbol}</span>${escHtml(version)}</span>` +
    (date ? `<span class="vw-cell-date">${escHtml(date)}</span>` : '') +
    `</span>`;
}

// The three upgrade targets a row can offer, smallest jump first. Each tier is
// distinguished by symbol SHAPE, never colour — colour in this table already
// means vulnerable/deprecated/up-to-date on the Package column, and reusing it
// here would make one red glyph mean two different things.
const VW_UPGRADE_TIERS = [
  { key: 'latestPatchVersion', dateKey: 'latestPatchReleaseDate', symbol: '●', title: 'Patch version (same major.minor)' },
  { key: 'latestMinorVersion', dateKey: 'latestMinorReleaseDate', symbol: '◆', title: 'Minor version (same major)' },
  { key: 'latestVersion',      dateKey: 'latestReleaseDate',      symbol: '■', title: 'Major version' },
];

// A single consolidated "Latest Version" cell listing each upgrade tier that
// actually offers something, as its own stacked row.
//
// Tiers are walked cheapest-first against a rising floor that starts at the
// version in use, so a tier appears only when it is strictly newer than both
// the version in use and every tier below it. That collapses the redundancy
// three overlapping tiers would otherwise produce — an artifact with no newer
// major resolves latestVersion and latestMinorVersion to the same string, and
// one with no newer minor collapses all three — while keeping every symbol
// that IS shown a genuine, distinct upgrade target.
//
// A row with nothing newer available (already current, or a locally-published
// version ahead of the registry) renders "—".
function vwLatestVersionCell(row) {
  // No registry can answer this for the row's ecosystem (Swift resolves
  // packages from git URLs rather than an index). Rendering the usual "—" would
  // read as "nothing newer exists", i.e. as up to date.
  if (row.latestUnavailable) {
    return '<span class="avg-muted vw-not-tracked" title="No registry publishes version information for '
      + escHtml(vwEcosystemLabel(row.ecosystem))
      + ' packages, so no upgrade target could be determined — this does not mean the version in use is current">not tracked</span>';
  }

  let floor = vwStripRangePrefix(row.versionInUse);
  const entries = [];
  for (const tier of VW_UPGRADE_TIERS) {
    const version = row[tier.key];
    if (!version || vwCompareVersions(version, floor) <= 0) continue;
    entries.push(vwLatestVersionEntry(tier.symbol, tier.title, version, row[tier.dateKey]));
    floor = version;
  }
  if (!entries.length) return '<span class="avg-muted">—</span>';
  return entries.join('');
}

// Orders findings worst-first. Mirrors vwSeverityClass's grouping but keeps
// critical above high, which that function collapses into one badge colour.
// An unrecognised or absent severity sorts last rather than being guessed at.
const VW_SEVERITY_ORDER = ['critical', 'high', 'moderate', 'medium', 'low'];
function vwSeverityRank(sev) {
  const i = VW_SEVERITY_ORDER.indexOf(String(sev || '').toLowerCase());
  return i === -1 ? VW_SEVERITY_ORDER.length : i;
}

// Every finding is listed. There used to be a ten-item cap with a "+59 more"
// line, which was dead text: the remaining findings were already in the browser
// (the cap was only ever a rendering decision) but there was no way to reach
// them. The list scrolls inside its own box instead, so a row matching ~70
// advisories stays readable without pushing the rest of the table down.
function vwCvesCell(row) {
  // "Could not check" is not "checked and found nothing". Without this branch
  // a failed lookup renders as an empty list, reporting a possibly-vulnerable
  // dependency as clean.
  if (row.cvesUnavailable) {
    // Two different reasons, and conflating them would misinform: a failed
    // lookup is worth retrying, whereas "no database covers this ecosystem"
    // never will be. Neither is a clean result, which is the point of showing
    // anything at all here.
    const unsupported = row.cvesUnavailableReason === 'unsupported';
    const label = unsupported ? 'not checked' : 'unknown';
    const title = unsupported
      ? `No vulnerability database covers ${vwEcosystemLabel(row.ecosystem)} packages — this row was never checked, which is not the same as being clean`
      : 'The vulnerability lookup failed for this row — this is not a clean result';
    return `<span class="vw-sev vw-sev-unknown" title="${escHtml(title)}">${label}</span>`;
  }
  if (!row.cves || !row.cves.length) return '<span class="avg-muted">none</span>';

  const sorted = row.cves.slice().sort((a, b) => vwSeverityRank(a.severity) - vwSeverityRank(b.severity));

  // Counts are collected off the already-sorted list, so the Map's insertion
  // order puts the breakdown in severity order too.
  const counts = new Map();
  for (const c of sorted) {
    const label = (c.severity || 'unknown').toLowerCase();
    counts.set(label, (counts.get(label) || 0) + 1);
  }
  const breakdown = [...counts].map(([label, n]) => `${n} ${label}`).join(', ');

  const items = sorted.map(c => {
    // The class is chosen from the RAW severity, not from the display label
    // below: defaulting to the string "unknown" first would send it down
    // vwSeverityClass's final branch and style a finding with no severity data
    // as though it had been assessed as low.
    const severityClass = vwSeverityClass(c.severity);
    const severity = c.severity || 'unknown';
    const id = c.id || 'unidentified advisory';
    const url = vwSafeUrl(c.url);
    // The advisory URL was already being fetched on every code path and then
    // discarded — linking the id is what makes a finding actionable.
    const idHtml = url
      ? `<a href="${escHtml(url)}" target="_blank" rel="noopener noreferrer">${escHtml(id)}</a>`
      : escHtml(id);
    const summary = (c.summary || '').slice(0, 120);
    return `<li><span class="vw-sev ${severityClass}">${escHtml(severity)}</span> ${idHtml}` +
      (summary ? ` — ${escHtml(summary)}` : '') + `</li>`;
  }).join('');

  return `<details class="vw-details"><summary>${sorted.length} vulnerabilit${sorted.length > 1 ? 'ies' : 'y'} · ${escHtml(breakdown)}</summary><ul class="vw-cve-list">${items}</ul></details>`;
}

// The version in use, marked when it came from a declared range rather than an
// exact pin. Not decoration: the vulnerability lookup and the up-to-date check
// both ran against this value as the range's FLOOR, so a finding here means
// "the oldest version this declaration allows is vulnerable" — a weaker claim
// than one about a resolved build, and one the reader should be able to see.
function vwVersionInUseCell(row) {
  const version = escHtml(row.versionInUse);
  if (!row.versionIsRange) return version;
  const explanation = 'Declared as a range — this is the lowest version it allows. '
    + 'Vulnerability findings and the up-to-date check apply to that floor, not to whatever the build resolves to.';
  return `${version} <span class="vw-range-marker" title="${escHtml(explanation)}" aria-hidden="true">≥</span>`
    + `<span class="sr-only"> (declared as a range; this is the lowest allowed version)</span>`;
}

function vwUsedByCell(row) {
  const repos = row.usedBy || [];
  if (repos.length <= 1) return escHtml(repos[0] || '—');
  const items = repos.map(r => `<li>${escHtml(r)}</li>`).join('');
  return `<details class="vw-details"><summary>${repos.length} repos</summary><ul>${items}</ul></details>`;
}

// Strips a leading range/comparison operator (npm's ^ ~ >= etc., PEP 440's
// ~= == !=), mirroring server/version-watch/compare-versions.js. Without this,
// an npm row's declared "^4.17.21" would compare as a non-numeric segment and
// every tier would read as an upgrade over it.
function vwStripRangePrefix(v) {
  return String(v || '').trim().replace(/^[\^~<>=!]+/, '').trim();
}

// Numeric (semver-lite) comparison, mirroring server/version-watch/compare-versions.js —
// duplicated here since this app has no build step to share code between
// server and browser modules. Orders "2.10.0" after "2.9.0" instead of
// before it, the way a plain string comparison would.
function vwCompareVersions(a, b) {
  const partsA = String(a || '').split('.');
  const partsB = String(b || '').split('.');
  const len = Math.max(partsA.length, partsB.length);
  for (let i = 0; i < len; i++) {
    const segA = partsA[i] ?? '', segB = partsB[i] ?? '';
    const numA = parseInt(segA, 10), numB = parseInt(segB, 10);
    if (!Number.isNaN(numA) && !Number.isNaN(numB) && numA !== numB) return numA - numB;
    if (segA !== segB) {
      // A bare numeric segment outranks the same number with a glued
      // pre-release suffix (e.g. "0" vs "0rc1") — a plain release is newer
      // than its own pre-release, not older.
      const isPlainA = /^\d+$/.test(segA), isPlainB = /^\d+$/.test(segB);
      if (isPlainA && !isPlainB) return 1;
      if (!isPlainA && isPlainB) return -1;
      return segA < segB ? -1 : 1;
    }
  }
  return 0;
}

const VW_VERSION_SORT_KEYS = new Set(['latestVersion', 'latestMinorVersion', 'versionInUse']);

function vwFilteredSortedRows() {
  const search = (document.getElementById('vw-search')?.value || '').trim().toLowerCase();
  let rows = (_vwData.rows || []).filter(row => {
    if (_vwEcosystemFilter !== 'all' && row.ecosystem !== _vwEcosystemFilter) return false;
    if (_vwNeedsUpgradeOnly && !row.status?.needsUpgrade) return false;
    if (search) {
      const hay = `${row.package} ${(row.usedBy || []).join(' ')}`.toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });
  if (_vwSort.key) {
    rows = [...rows].sort((a, b) => {
      if (_vwSort.key === 'cves') return ((a.cves?.length || 0) - (b.cves?.length || 0)) * _vwSort.dir;
      if (_vwSort.key === 'usedBy') return ((a.usedBy?.length || 0) - (b.usedBy?.length || 0)) * _vwSort.dir;
      if (VW_VERSION_SORT_KEYS.has(_vwSort.key)) {
        return vwCompareVersions(a[_vwSort.key], b[_vwSort.key]) * _vwSort.dir;
      }
      const va = a[_vwSort.key] || '', vb = b[_vwSort.key] || '';
      return va < vb ? -_vwSort.dir : va > vb ? _vwSort.dir : 0;
    });
  }
  return rows;
}

function renderVersionWatchTable() {
  const body = document.getElementById('vw-table-body');
  if (!body) return;
  vwNormalizeEcosystemFilter();
  const rows = vwFilteredSortedRows();

  const summaryEl = document.getElementById('vw-summary');
  if (summaryEl) {
    summaryEl.textContent = _vwData.lastScanAt
      ? `${_vwData.rows.length} tracked · last scan ${new Date(_vwData.lastScanAt).toLocaleString()}`
      : 'never scanned';
  }

  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="6" class="docker-empty">${_vwData.rows.length ? 'No rows match the current filters.' : 'No scan data yet — click Rescan.'}</td></tr>`;
  } else {
    body.innerHTML = rows.map(row => `
      <tr>
        <td class="${vwPackageClass(row)}" title="${escHtml(vwPackageTitle(row))}">${escHtml(row.package)}${vwPackageTitle(row) ? ` <span class="sr-only">(${escHtml(vwPackageTitle(row))})</span>` : ''}</td>
        <td>${escHtml(vwEcosystemLabel(row.ecosystem))}</td>
        <td class="avg-link">${vwVersionInUseCell(row)}</td>
        <td><div class="vw-lv-cell">${vwLatestVersionCell(row)}</div></td>
        <td>${vwCvesCell(row)}</td>
        <td>${vwUsedByCell(row)}</td>
      </tr>
    `).join('');
  }

  const summaryFooter = document.getElementById('vw-scan-summary');
  if (summaryFooter && _vwData.scanSummary) {
    const s = _vwData.scanSummary;
    summaryFooter.classList.remove('hidden');

    const parts = [
      `${s.reposScanned} repos scanned`,
      `${s.repoFetchErrors || 0} repos failed to fetch`,
      `${s.manifestParseErrors} manifests failed to parse`,
      `${s.unresolvedDependencyVersions} dependency versions unresolved`,
      `${s.lookupErrors} registry lookups failed`,
    ];
    // Only shown when non-zero — these are the two ways a scan can under-report
    // a repo, and they must never be silent, but a row of zeroes on every scan
    // would just be noise.
    if (s.reposWithTruncatedTree) parts.push(`${s.reposWithTruncatedTree} repos too large to list in full`);
    if (s.manifestsSkipped) parts.push(`${s.manifestsSkipped} manifests skipped (per-repo cap)`);

    let html = `📋 ${escHtml(parts.join(' · '))}`;

    // Ecosystems present in the org that this tool cannot parse. Reported so an
    // untracked stack reads as a known gap rather than as an empty table
    // indistinguishable from a repo that has no dependencies at all.
    const untracked = s.untrackedEcosystems || [];
    if (untracked.length) {
      const list = untracked
        .map(e => `${escHtml(e.label)} (${e.repos} repo${e.repos === 1 ? '' : 's'})`)
        .join(', ');
      html += `<div class="vw-untracked">⚠️ ${untracked.length} ecosystem${untracked.length === 1 ? '' : 's'} detected but not tracked: ${list}</div>`;
    }

    summaryFooter.innerHTML = html;
  } else if (summaryFooter) {
    summaryFooter.classList.add('hidden');
  }
}

// ── Reports ────────────────────────────────────────────────────────────────
//
// Same contract as the Security tab's: the report is what is on screen, with
// the ecosystem filter, the needs-upgrade toggle, the search and the sort all
// applied — and stated in the header, so a filtered export cannot be mistaken
// for the full dependency inventory.

function vwReportSpec() {
  const rows = vwFilteredSortedRows();

  const scope = [];
  if (_vwEcosystemFilter !== 'all') scope.push({ label: 'Ecosystem', value: _vwEcosystemFilter });
  if (_vwNeedsUpgradeOnly) scope.push({ label: 'Needs upgrade only', value: 'yes' });
  const search = (document.getElementById('vw-search')?.value || '').trim();
  if (search) scope.push({ label: 'Search', value: search });
  if (_vwSort.key) {
    scope.push({ label: 'Sorted by', value: `${_vwSort.key} ${_vwSort.dir > 0 ? 'ascending' : 'descending'}` });
  }

  const outdated = rows.filter(r => r.status?.needsUpgrade).length;
  const vulnerable = rows.filter(r => (r.cves || []).length).length;
  const deprecated = rows.filter(r => r.deprecated).length;
  // Counted and reported separately: a dependency whose advisories could not be
  // fetched is NOT a dependency with no advisories, and a report that blurs the
  // two is telling the reader something untrue.
  const unchecked = rows.filter(r => r.cvesUnavailable).length;

  return {
    title: 'Dependency version report',
    subtitle: _vwEcosystemFilter === 'all' ? 'All ecosystems' : _vwEcosystemFilter,
    scope,
    summary: [
      { label: 'Dependencies', value: rows.length },
      { label: 'Need upgrade', value: outdated, tone: outdated ? 'medium' : 'good' },
      { label: 'With CVEs', value: vulnerable, tone: vulnerable ? 'critical' : 'good' },
      { label: 'Deprecated', value: deprecated, tone: deprecated ? 'high' : 'good' },
    ],
    note: [
      _vwData.lastScanAt ? `Based on the scan of ${new Date(_vwData.lastScanAt).toLocaleString()}.` : 'No scan has run yet.',
      unchecked
        ? `${unchecked} dependenc${unchecked === 1 ? 'y' : 'ies'} could not be checked against the advisory database — `
          + 'those are unknown, not clean.'
        : '',
    ].filter(Boolean).join(' '),
    columns: [
      { key: 'ecosystem', label: 'Ecosystem' },
      // Coordinates like org.springframework.security:spring-security-web have
      // no break opportunity of their own.
      { key: 'package', label: 'Package', wrap: 'anywhere' },
      { key: 'versionInUse', label: 'In use' },
      { key: 'latest', label: 'Latest' },
      { key: 'cves', label: 'CVEs', align: 'right' },
      { key: 'usedBy', label: 'Used by', wrap: 'anywhere' },
      { key: 'flags', label: 'Notes' },
    ],
    rows: rows.map(r => ({
      ecosystem: r.ecosystem,
      package: r.package,
      versionInUse: r.versionInUse + (r.versionIsRange ? ' (range)' : ''),
      latest: r.latestUnavailable ? 'not tracked' : (r.latestVersion || '—'),
      cves: r.cvesUnavailable ? 'unknown' : ((r.cves || []).length || ''),
      usedBy: (r.usedBy || []).join(', '),
      flags: [
        r.status?.needsUpgrade ? 'needs upgrade' : '',
        r.deprecated ? 'deprecated' : '',
      ].filter(Boolean).join(', '),
    })),
  };
}

function printVwReport() {
  return produceReport(vwReportSpec(), 'print');
}

async function exportVwReport() {
  const result = await produceReport(vwReportSpec(), 'pdf');
  if (result && result.error) alert(`Could not export the report: ${result.error}`);
}
