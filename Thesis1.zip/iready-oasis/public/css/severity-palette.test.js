'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');

// Why a test for a stylesheet.
//
// Severity colour is a STATUS scale: the same four colours mean the same four
// things everywhere in the product. That makes it tempting to "fix" them per
// theme — darken them so they contrast better on white — and that is exactly
// the change that must not happen. Darkening a yellow walks it into orange, so
// re-stepping the light theme collapsed HIGH and MEDIUM to ΔE 2.5 under
// deuteranopia: worse than the pair the ramp was adopted to replace, and
// invisible to anyone reviewing the diff.
//
// The mitigation for the low contrast is not a different colour, it is that a
// severity colour never carries meaning alone — every bar, chip and row prints
// the severity word beside it.

const CSS = fs.readFileSync(path.join(__dirname, 'app.css'), 'utf8');

// The status steps, measured at ΔE 13.6 normal / 11.3 deuteranopia for the
// closest adjacent pair (HIGH vs MEDIUM).
const STATUS = {
  '--chart-sev-critical': '#d03b3b',
  '--chart-sev-high': '#ec835a',
  '--chart-sev-medium': '#fab219',
  '--chart-good': '#0ca30c',
};

function declarations(name) {
  return [...CSS.matchAll(new RegExp(`${name}\\s*:\\s*([^;]+);`, 'g'))].map(m => m[1].trim());
}

test('each status colour is declared exactly once, so no theme can re-step it', () => {
  for (const [name, hex] of Object.entries(STATUS)) {
    const found = declarations(name);
    assert.deepStrictEqual(found, [hex],
      `${name} must be declared once as ${hex}; a second declaration means a theme is re-stepping a status colour`);
  }
});

test('severity chips state the severity word, not colour alone', () => {
  // The relief the contrast WARN obligates. If the chips ever became bare
  // colour swatches, the palette choice above would stop being defensible.
  for (const sev of ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']) {
    assert.ok(CSS.includes(`.sec-sev-${sev}`), `missing chip style for ${sev}`);
  }
});
