#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# Runs OASIS with licence enforcement ON, against the real licence service.
#
# The cloud side is a separate project and starts separately:
#
#   ../oasis-support-portal/scripts/stack.sh init   (once)
#   ../oasis-support-portal/scripts/stack.sh up     (licence 4020, support 4040, portal 4030)
#
# This script starts nothing in the cloud. It finds the licence service, tells OASIS
# where it is (OASIS_LICENSE_URL, which carries the /v1 prefix) and which key to trust
# (OASIS_LICENSE_PUBLIC_KEY, the public half of the key the stack made), then starts
# OASIS. If the service is not answering it runs `stack.sh up` for you; it never runs
# `init`, because that writes .env files and creates databases.
#
# start-web.sh and start-desktop.sh set no licensing environment, so licensingEnabled()
# (server/licensing/keys.js) is true and the app looks for http://localhost:4020/v1 (config/services.json). Set
# OASIS_LICENSE_DISABLED=1 to run them as the unlicensed internal build.
#
# --legacy runs the old bundled dev service (tools/license-service-dev.js) instead.

REPOS=${OASIS_REPOS_DIR:-..}
STACK=${OASIS_STACK_SCRIPT:-$REPOS/oasis-support-portal/scripts/stack.sh}
STACK_HOME=${STACK_HOME:-$HOME/.oasis-local-stack}
LICENCE_PORT=${LICENCE_PORT:-4020}
LICENSE_PORT=${LICENSE_SERVICE_PORT:-4010}       # legacy service only
ADMIN_TOKEN=${ADMIN_TOKEN:-dev-admin}            # legacy service only

MODE="desktop"
STATE=""
KEEP=0
RESET=0
LEGACY=0
SERVICE_PID=""
APP_PID=""

usage() {
  cat <<'EOF'

  ./start-licensed.sh [options]

  Starts OASIS with enforcement on, against the licence service from the stack.

    --web               web server instead of Electron
    --state <name>      write a licence state directly and skip activation
    --keep              keep whatever licence is stored now
    --legacy            use the old bundled tools/license-service-dev.js instead
    --reset             (with --legacy) wipe the bundled service's database
    --states            list the licence states and exit
    -h, --help          this

  Environment: LICENCE_PORT (default 4020), OASIS_REPOS_DIR, OASIS_STACK_SCRIPT,
  STACK_HOME (default ~/.oasis-local-stack), OASIS_LICENSE_URL and
  OASIS_LICENSE_PUBLIC_KEY (set either to override what this script works out)

  First time:

    ../oasis-support-portal/scripts/stack.sh init
    ./start-licensed.sh --web

EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --web)     MODE="web"; shift ;;
    --desktop) MODE="desktop"; shift ;;
    --state)   STATE="${2:-}"; shift 2 ;;
    --keep)    KEEP=1; shift ;;
    --reset)   RESET=1; shift ;;
    --legacy)  LEGACY=1; shift ;;
    --issue|--shop)
      echo "$1 belonged to the old licence service and has no equivalent in the new one." >&2
      echo "Issue a key with: (cd ../oasis-licence-service && npm run issue-licence -- --help)" >&2
      exit 1 ;;
    --states)  node tools/license-dev.js states; exit 0 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1 — try --help" >&2; exit 1 ;;
  esac
done

if [ "$RESET" -eq 1 ] && [ "$LEGACY" -eq 0 ]; then
  echo "--reset only applies to the bundled service (--legacy). To rebuild the new service's" >&2
  echo "databases use the stack with a fresh prefix: STACK_DB_PREFIX=dev2_ …/stack.sh init" >&2
  exit 1
fi

# Only reap what this script started. The stack services are separate processes that
# other tools (the support portal) depend on, so they outlive this run.
cleanup() {
  if [ -n "$APP_PID" ]; then
    kill "$APP_PID" 2>/dev/null || true
    APP_PID=""
  fi
  if [ -n "$SERVICE_PID" ]; then
    echo ""
    echo "Stopping the bundled dev service (PID $SERVICE_PID)…"
    kill "$SERVICE_PID" 2>/dev/null || true
    SERVICE_PID=""
  fi
}
trap cleanup EXIT INT TERM

# ── The licence service ────────────────────────────────────────────────────
if [ "$LEGACY" -eq 1 ]; then
  LICENSE_URL="http://localhost:${LICENSE_PORT}"
  HEALTH="${LICENSE_URL}/admin/state"

  if [ "$RESET" -eq 1 ]; then
    if curl -sf -o /dev/null "$HEALTH" 2>/dev/null; then
      echo "Resetting the dev licence service…"
      curl -sf -X POST "${LICENSE_URL}/admin/reset" > /dev/null || true
    else
      rm -f "${LICENSE_SERVICE_DB:-/tmp/oasis-license-service-db.json}"
      rm -f "$HOME/.oasis-license-dev/service-db.json"
      echo "Cleared the dev licence service database."
    fi
  fi

  if curl -sf -o /dev/null "$HEALTH" 2>/dev/null; then
    echo "Licence service already running on ${LICENSE_URL} — using it."
  else
    echo "Starting the bundled dev service on ${LICENSE_URL}…"
    LICENSE_SERVICE_PORT="${LICENSE_PORT}" node tools/license-service-dev.js \
      > /tmp/oasis-license-service.log 2>&1 &
    SERVICE_PID=$!
    for _ in $(seq 1 40); do
      curl -sf -o /dev/null "$HEALTH" 2>/dev/null && break
      sleep 0.25
    done
    if ! curl -sf -o /dev/null "$HEALTH" 2>/dev/null; then
      echo "Licence service did not come up. Log: /tmp/oasis-license-service.log" >&2
      tail -5 /tmp/oasis-license-service.log >&2 || true
      exit 1
    fi
  fi
else
  # The service answers /readyz at its root; the API sits under /v1.
  SERVICE_ROOT="http://localhost:${LICENCE_PORT}"
  LICENSE_URL="${OASIS_LICENSE_URL:-${SERVICE_ROOT}/v1}"
  HEALTH="${SERVICE_ROOT}/readyz"

  if curl -sf -o /dev/null "$HEALTH" 2>/dev/null; then
    echo "Licence service already running on ${SERVICE_ROOT} — using it."
    echo "  ⚠  It is a separate process: code changes since it started are NOT loaded."
  else
    [ -f "$STACK" ] || {
      echo "No licence service is answering on ${SERVICE_ROOT}, and the stack script is not at $STACK." >&2
      echo "Start oasis-licence-service yourself, or set OASIS_STACK_SCRIPT / OASIS_REPOS_DIR." >&2
      exit 1
    }
    if [ ! -f "$STACK_HOME/licence-signing.pem" ]; then
      echo "The local stack has not been set up yet. Run once:" >&2
      echo "  $STACK init" >&2
      exit 1
    fi
    echo "No licence service on ${SERVICE_ROOT} — starting the stack…"
    "$STACK" up
  fi
fi

# ── What OASIS trusts ──────────────────────────────────────────────────────
# OASIS only accepts tokens signed by a key it was told about, otherwise only its built-in
# dev key. The stack's service signs with its own, so hand OASIS the public half. A kid-less
# key set is tried against every token, so the stack's key id does not matter here.
if [ "$LEGACY" -eq 0 ] && [ -z "${OASIS_LICENSE_PUBLIC_KEY:-}" ]; then
  if [ -f "$STACK_HOME/licence-signing.pem" ]; then
    openssl pkey -in "$STACK_HOME/licence-signing.pem" -pubout \
      -out "$STACK_HOME/licence-public.pem" 2>/dev/null
    export OASIS_LICENSE_PUBLIC_KEY="$STACK_HOME/licence-public.pem"
  else
    echo "  ⚠  No signing key at $STACK_HOME/licence-signing.pem, so OASIS will only trust its" >&2
    echo "     built-in dev key and will reject tokens from this service. Set OASIS_LICENSE_PUBLIC_KEY." >&2
  fi
fi

# ── The stored licence ─────────────────────────────────────────────────────
# Defaults to clearing, because the state people usually want to check is a
# fresh machine — and a leftover licence from last week's testing silently
# shows a different screen than the one they came to look at.
if [ "$KEEP" -eq 1 ]; then
  echo "Keeping the stored licence:"
elif [ -n "$STATE" ]; then
  echo "Installing licence state '${STATE}':"
  node tools/license-dev.js install "$STATE" > /dev/null
else
  echo "Clearing the stored licence (fresh machine). Use --keep or --state to change this."
  node tools/license-dev.js clear > /dev/null
fi
node tools/license-dev.js show || true

echo
if [ "$LEGACY" -eq 1 ]; then
  echo "Licence keys (bundled dev service):"
  echo "  OASIS-VIEW-0001-0001   Version Viewer"
  echo "  OASIS-VWSC-0001-0001   Version Viewer + Security"
  echo "  OASIS-ENTR-0001-0001   Enterprise"
else
  echo "Licence service: ${LICENSE_URL}"
  echo "Trial: \"Start 7-day free trial\" works against it. Activate by email: the one-time code is"
  echo "printed in the licence log (${STACK_HOME}/logs/licence.log). Buy form: lands in the support portal."
fi
echo

# ── The app ────────────────────────────────────────────────────────────────
# OASIS_LICENSE_URL both enables enforcement and names the service, so one
# variable does the whole job — OASIS_LICENSE_ENABLED is not needed here.
export OASIS_LICENSE_URL="${LICENSE_URL}"

# Feedback and Contact Support go to the support service from the stack (default port 4040).
export OASIS_SUPPORT_URL="${OASIS_SUPPORT_URL:-http://localhost:${SUPPORT_PORT:-4040}/v1}"

# Backgrounded and waited on, rather than run in the foreground.
#
# A foreground app leaves bash blocked inside it, so a SIGTERM aimed at this
# script sits unhandled until the app happens to exit. Waiting on a background
# PID means the trap fires immediately, whichever way the script is stopped.
if [ "$MODE" = "web" ]; then
  PORT=${PORT:-3000}
  existing=$(lsof -ti :${PORT} -sTCP:LISTEN 2>/dev/null || true)
  if [ -n "$existing" ]; then
    echo "Killing existing process on port ${PORT} (PID $existing)…"
    kill $existing
    sleep 1
  fi
  echo "Starting i-Ready OASIS (licensed) on http://localhost:${PORT}"
  node server/index.js &
else
  echo "Starting i-Ready OASIS desktop app (licensed)"
  npx electron . &
fi

APP_PID=$!
wait "$APP_PID" || true
