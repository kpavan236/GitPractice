#!/usr/bin/env bash
set -euo pipefail

# Starts oasis-rule-server, the process that holds the security rules, quality
# profiles, findings and their triage. Oasis cannot scan without it.
#
# Expects the sibling repository next to this one; OASIS_RULE_SERVER_DIR overrides.
# The first run installs its dependencies and seeds its database.

SERVER_DIR="${OASIS_RULE_SERVER_DIR:-$(cd "$(dirname "$0")/.." && pwd)/oasis-rule-server}"
if [ ! -d "$SERVER_DIR" ]; then
  echo "oasis-rule-server not found at $SERVER_DIR (set OASIS_RULE_SERVER_DIR)." >&2
  exit 1
fi

cd "$SERVER_DIR"
[ -d node_modules ] || npm install

export OASIS_RULE_SERVER_DB="${OASIS_RULE_SERVER_DB:-$SERVER_DIR/oasis-rules.db}"
if [ ! -f "$OASIS_RULE_SERVER_DB" ]; then
  echo "First run: seeding rules into $OASIS_RULE_SERVER_DB"
  node scripts/seed.js
fi

echo "Starting oasis-rule-server (OASIS_RULE_SERVER_PORT=${OASIS_RULE_SERVER_PORT:-5090})"
exec node src/server.js
