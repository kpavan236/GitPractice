#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# This script clones iready-core if it is not already found,
# then configures the env.properties and build.properties.
# This script can be run standalone from the main script to
# refresh your environment with the newest educator dashboard,
# capub, and student dashboard versions.

# Read github email
GH_EMAIL=$(git config user.email)

# If no email set, prompt for user input
if [ $? -eq 1 ]; then
    read -rp "Enter GitHub Username (without @cainc.com): " GH_USERNAME
    GH_EMAIL="${GH_USERNAME}@cainc.com"
    git config --global user.email "${GH_EMAIL}"
else
    GH_USERNAME=${GH_EMAIL%"@cainc.com"}
fi

# Manual steps involving cloning iready-core and setting up personal access token

echo "Perform manual steps to clone iready-core and set up the personal access token. See the top-level README.md for instructions."