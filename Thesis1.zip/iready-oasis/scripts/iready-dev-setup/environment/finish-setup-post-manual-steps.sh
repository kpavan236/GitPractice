#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# The remainder of this script is intended to be run after the manual steps in the README have been completed.

# Copies env.properties additions for iready-core
RESOURCES_FOLDER=/Users/"${USERNAME}"/dev/projects/iready/iready-core/IReadyPlatform/util/src/test/resources
cp "${RESOURCES_FOLDER}"/env.template.properties "${RESOURCES_FOLDER}"/env.properties
sudo bash -c "$(declare -f add_data_to_file); add_data_to_file ./additions/env.properties_additions.txt ${RESOURCES_FOLDER}/env.properties"

IREADYCORE_FOLDER=/Users/"${USERNAME}"/dev/projects/iready/iready-core

# Load node command from homebrew into current shell environment so that we can run the node command 
# (current shell env does not have node loaded yet in current shell, but will in a new shell... this fixes that)
eval "$(/opt/homebrew/bin/brew shellenv)"

# Get the most recent versions of educator dashboard, capub, and student dashboard
node "${IREADYCORE_FOLDER}/scripts/update-envs.js"

# Copies build.properties additions for iready-core
cp "${IREADYCORE_FOLDER}"/build.properties.template "${IREADYCORE_FOLDER}"/build.properties
sudo bash -c "$(declare -f add_data_to_file); add_data_to_file ./additions/build.properties_additions.txt ${IREADYCORE_FOLDER}/build.properties"

# Change the USERNAME indicator in build.properties to the specific username
replace_in_file "USERNAME" "$USERNAME" "$IREADYCORE_FOLDER/build.properties"

# Source the zshrc to access our new Paths
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true

# Start the iready build
echo 'Starting to build iready-core'

if (
    # shellcheck disable=SC2164
    cd /Users/"${USERNAME}"/dev/projects/iready/iready-core
    # Build iready-core with the necessary profiles to create the databases, users, and githooks. Add -U to fix occasional outdated snapshots
    mvn -U clean install -DskipTests=true -Pdrop-dbs,create-users,rc-unix,init-githooks
    # Run the verify phase to run the db tests and make sure everything is working correctly
    mvn verify
    ); then
    echo '[SUCCESS] Built iready-core' | tee -a setup.log
else
    echo '[FAILED] iready-core was unable to be built' | tee -a setup.log
fi

#######################################################################
#   _____   ____   _____ _______   ____  _    _ _____ _      _____    #
#  |  __ \ / __ \ / ____|__   __| |  _ \| |  | |_   _| |    |  __ \   #
#  | |__) | |  | | (___    | |    | |_) | |  | | | | | |    | |  | |  #
#  |  ___/| |  | |\___ \   | |    |  _ <| |  | | | | | |    | |  | |  #
#  | |    | |__| |____) |  | |    | |_) | |__| |_| |_| |____| |__| |  #
#  |_|     \____/|_____/   |_|    |____/ \____/|_____|______|_____/   #
#######################################################################


# Creates a run configuration folder for IntelliJ run configs, and copies our Tomcat and JUnit setups
mkdir -v "${IREADYCORE_FOLDER}"/.run
cp ./settings/Tomcat10-iready.run.xml "${IREADYCORE_FOLDER}"/.run/Tomcat10-iready.run.xml
cp ./settings/JUnit-iready.run.xml "${IREADYCORE_FOLDER}"/.run/JUnit-iready.run.xml
