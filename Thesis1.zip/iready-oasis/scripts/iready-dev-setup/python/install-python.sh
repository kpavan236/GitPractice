#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

PYTHON396_PKG="https://www.python.org/ftp/python/3.9.6/python-3.9.6-macos11.pkg"

# Installs python3 if not already installed
python3 --version >/dev/null 2>&1 # >/dev/null 2>&1 hides output
PYTHON3_IS_AVAILABLE=$?
if [ $PYTHON3_IS_AVAILABLE -ne 0 ]; then
    echo 'Installing Python'
    curl -L ${PYTHON396_PKG} --output /Users/"${USERNAME}"/Downloads/python3.9.6.pkg
    DOWNLOAD_SUCCESS=$?
    pkg_install /Users/"${USERNAME}"/Downloads/python3.9.6.pkg
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Python3' 'python3 --version' 'which python3'
