#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — non-interactive machine bootstrap
#
# Vendored, non-interactive replacement for the original interactive
# `iready-dev-setup.sh`. Installs the full i-Ready developer toolchain
# (AWS CLI + SSO, git, Homebrew, MySQL 8, OpenJDK 17, Maven, Tomcat, Ant,
# IntelliJ, Workbench, Node) and writes the shared shell/host config. It does
# NOT build iready-core — that lives in scripts/iready-core.sh.
#
# Every install step is idempotent (each sub-script checks "already installed?"
# and skips), so this is safe to run before any repo setup. The first run on a
# fresh machine is heavy; later runs are fast no-ops.
#
# Made non-interactive for OASIS (no terminal / no stdin):
#   • sudo  → one GUI password prompt, cached + kept warm (lib/oasis-common)
#   • Homebrew / JDK / Cursor prompts → auto-answered via env defaults
#   • AWS   → browser login + auto-select the development account
#
# Usage: bash bootstrap.sh
# ─────────────────────────────────────────────────────────────────────────────

BOOTSTRAP_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

# Shared OASIS helpers (notify / sudo priming / non-interactive defaults).
# shellcheck source=/dev/null
. "$BOOTSTRAP_DIR/../lib/oasis-common.sh"

# util/* defines USERNAME, ARCHITECTURE, INTEL, M1, S3_BUCKET_NAME, TOOLS_DIR
for script in "$BOOTSTRAP_DIR"/util/*.sh; do . "$script"; done

# Relative ./settings and ./additions paths in the install scripts resolve
# against the bootstrap dir.
cd "$BOOTSTRAP_DIR"

dl_log "Starting i-Ready toolchain bootstrap (non-interactive)…"

# Obtain admin rights up front via a single GUI password dialog, then keep the
# sudo timestamp warm for every later step. Hard-fail if we can't (the installs
# below need root for pkg/dmg installs and /etc edits).
if ! dl_prime_sudo; then
    dl_log "Administrator access is required to install the toolchain. Aborting."
    exit 1
fi

# ── Shell profile (.zshrc) ─────────────────────────────────────────────────
add_data_to_file ./settings/zshrc /Users/"${USERNAME}"/.zshrc
replace_in_file "USERNAME" "$USERNAME" "/Users/$USERNAME/.zshrc"
if [ ! -f ~/.zshrc.bak ]; then
    dl_log "Creating a backup of the old .zshrc"
    cp ~/.zshrc{,.bak}
fi
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true

# ── Directory structure ────────────────────────────────────────────────────
mkdir -pv /Users/"${USERNAME}"/dev/{ide,projects,tools,workspace}
mkdir -pv /Users/"${USERNAME}"/dev/projects/iready

# ── Rosetta 2 (Apple Silicon only) ─────────────────────────────────────────
if [[ $ARCHITECTURE = "$M1" ]]; then
    softwareupdate --install-rosetta --agree-to-license || true
    dl_log "Rosetta 2 ensured for Apple Silicon"
fi

# ── AWS CLI + SSO (needed to download tools from S3) ───────────────────────
. ./aws/install-aws-sso.sh

# AWS bucket access is required for the S3-hosted tool downloads below.
if ! aws s3 ls s3://"${S3_BUCKET_NAME}" >/dev/null 2>&1; then
    echo "Insufficient AWS bucket access permissions. Contact secops (https://cainc.service-now.com/esc?id=sc_cat_item&sys_id=709e57679f983250a9354c7f1524ab4f) to request access to the dev-iready-setup S3 bucket."
    exit 1
fi
dl_log "Sufficient AWS bucket access, proceeding"

# ── Toolchain ───────────────────────────────────────────────────────────────
. ./git/install-git.sh
. ./workbench/install-workbench.sh
. ./homebrew/install-homebrew.sh
. ./mysql/install-mysql.sh
. ./openjdk/install-openjdk.sh
. ./maven/install-maven.sh
. ./tomcat/install-tomcat.sh
. ./ant/install-ant.sh
. ./intellij/install-intellij.sh

# Optional Cursor IDE — auto-answered (default: skip). Set INSTALL_CURSOR=y to include.
if [[ "${INSTALL_CURSOR}" =~ ^[Yy]$ ]]; then
    dl_log "Installing optional Cursor IDE (INSTALL_CURSOR=${INSTALL_CURSOR})"
    . ./cursor/install-cursor.sh
else
    dl_log "Skipping optional Cursor IDE (INSTALL_CURSOR=${INSTALL_CURSOR})"
fi

. ./node/install-node.sh

# ── /etc/hosts additions (dev.i-ready.com) ─────────────────────────────────
sudo bash -c "$(declare -f add_data_to_file); add_data_to_file ./additions/hosts_additions.txt /private/etc/hosts"

dl_log "✓ Toolchain bootstrap complete"
