#!/bin/bash

# Mounts the given DMG file
# If the mounted image is a .app, move to Applications
# Else, it must be a .pkg, so we can install it with pkg_install
# Then, we detach the image
#
# @param:    file     file path for DMG file
function dmg_install(){
    listing=$(sudo hdiutil attach "$1" | grep Volumes)
    volume=$(echo "$listing" | cut -f 3)

    for file in "$volume"/*.app
    do
        if [ -e "$file" ]
        then
            sudo cp -rf "$file" /Applications
        fi
    done

    for file in "$volume"/*.pkg
    do
        if [ -e "$file" ]
        then
            sudo installer -pkg "$file" -target /
        fi
    done

    sudo hdiutil detach "$volume"
}
