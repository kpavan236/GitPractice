#!/bin/bash

# Installs the given PKG file
# Will prompt the user for root privilege
#
# @param:   file path for PKG file
function pkg_install() {
    sudo installer -pkg "$1" -target /
}
