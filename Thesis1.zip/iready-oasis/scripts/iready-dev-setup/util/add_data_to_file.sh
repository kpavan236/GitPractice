#!/bin/bash

# Appends the data in the first file (additions)
# To the given second file if the line does not exists

# @param:    additionsfile   data to be added
# @param:    file            file for data to be added into
function add_data_to_file() {
    additions_file="$1"
    while read -r line; do
        grep -qxF "$line" "$2" || echo "$line" >>"$2"
    done <"$additions_file"
}
