#!/bin/bash
# shellcheck disable=SC2034
S3_BUCKET_NAME='dev-iready-setup'
USERNAME=$(whoami)
ARCHITECTURE=$(uname -m)
INTEL='x86_64'
M1='arm64'
TOOLS_DIR=/Users/${USERNAME}/dev/tools

if [ ! -d "$TOOLS_DIR" ]; then
    mkdir -v -p "$TOOLS_DIR"
fi
