#!/bin/bash

repeat() {
    for _ in $(seq 1 "$1") ; do echo -n "$2"; done
}

# Performs a substitution in the file and prints the replacement
#
# @param:   text to replace
# @param:   replacement text
# @param:   file to do replacement in
function replace_in_file() {
    to_replace="$1"
    replace_with="$2"
    file_path="$3"

    SEPARATOR=" >>> "

    matched_line_numbers=$(grep -n "$to_replace" "$file_path" | cut -d : -f 1)

    for line_number in $matched_line_numbers
    do
        # Count the number of replacements for this line
        replacements=$(sed -n "${line_number}p" "$file_path" | grep -o "$to_replace" | wc -l)
        while [ "$replacements" -gt 0 ]; do

            # Print the difference and actually make the replacements
            before=$(sed -n "${line_number}p" "$file_path")
            sed -i ".bak" "${line_number}s#$to_replace#$replace_with#" "$file_path";
            after=$(sed -n "${line_number}p" "$file_path")
            printf "%s (modified):\n${line_number}:\t%s${SEPARATOR}%s\n" "$file_path" "$before" "$after";

            # Handle creating the underlines for differences
            before_len=${#before}
            before_minus_to_replace=${before/$to_replace*/}
            index=${#before_minus_to_replace}
            to_replace_len=${#to_replace}
            end_len=$((before_len - to_replace_len - index))

            printf "\t";
            repeat "$index" ' ';
            repeat "$to_replace_len" '~';
            repeat $((end_len + ${#SEPARATOR})) " ";
            repeat "$index" ' ';
            repeat ${#replace_with} '~';
            echo;
            replacements=$((replacements - 1))
        done

    done
}
