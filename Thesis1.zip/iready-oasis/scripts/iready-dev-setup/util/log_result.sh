#!/bin/bash
# Logs the result for the given tool installation
#
# @param: install error code
# @param: tool name
# @param: command to check the version
# @param: command to check where the version is installed

function log_result() {

    if [ "$3" != 'none' ]; then
        VERSION=$($3)
        VERSION="version ${VERSION}"
    else
        VERSION=''
    fi

    if [ "$1" -eq 0 ]; then
        TOOL_LOCATION=$($4)
        echo '[SUCCESS] ' "$2" "$VERSION" 'installed at ' "$TOOL_LOCATION" | tee -a setup.log
    elif [ "$1" -eq -1 ]; then
        echo '[SKIPPED] ' "$2" ' already installed, skipping...' | tee -a setup.log
    else
        echo '[FAILED] ' "$2" ' was unable to be installed' | tee -a setup.log
        exit 1
    fi

}
