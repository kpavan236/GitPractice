#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

GIT_DMG="git-2.32.0-intel-universal-mavericks.dmg"

git --version >/dev/null 2>&1
GIT_IS_AVAILABLE=$?
if [ $GIT_IS_AVAILABLE -ne 0 ]; then
    echo 'Setting up git'
    aws s3 cp s3://"${S3_BUCKET_NAME}"/${GIT_DMG} /Users/"${USERNAME}"/Downloads/git.dmg
    DOWNLOAD_SUCCESS=$?
    dmg_install /Users/"${USERNAME}"/Downloads/git.dmg
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Git' 'git --version' 'which git'
