## Prerequisites
1. Mac computer
2. Have been granted access to AWS by Helpdesk ([see Service Now](https://cainc.service-now.com/esc?id=sc_cat_item&sys_id=3f1dd0320a0a0b99000a53f7604a2ef9))
3. Have already run the AWS script and logged in to AWS
## Who should use this script?
Anyone interested in installing Git for their local machine
## What's included in this script?
Install Git
## Run Script
1. Download/Clone [this repo]( https://github.cainc.com/iready/iready-dev-setup)
2. Navigate to the iready-dev-setup folder
3. Execute the bash script with: `bash git/install-git.sh`

## __Git is now installed!__
