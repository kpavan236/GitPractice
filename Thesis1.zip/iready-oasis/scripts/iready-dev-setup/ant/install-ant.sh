#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

ANT_TAR="apache-ant-1.10.9-bin.tar.gz"

# Check if Ant is downloaded, if it isnt, download it
if ! [ -d "${TOOLS_DIR}"/apache-ant/bin ]; then
    echo 'Installing Ant...'

    aws s3 cp s3://"${S3_BUCKET_NAME}"/${ANT_TAR} "${TOOLS_DIR}"/ant.tar.gz
    DOWNLOAD_SUCCESS=$?
    mkdir -v "${TOOLS_DIR}"/apache-ant
    tar -xvzf "${TOOLS_DIR}"/ant.tar.gz -C "${TOOLS_DIR}"/apache-ant --strip-components 1
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Apache-Ant' 'none' 'echo ~/dev/tools/apache-ant'
