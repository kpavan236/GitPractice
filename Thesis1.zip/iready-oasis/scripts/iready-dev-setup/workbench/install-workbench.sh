#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

MYSQL_WORKBENCH_DMG="mysql-workbench-community-8.0.29-macos-x86_64.dmg"


# Check if MySQLWorkbench is installed, if it isnt, install it
if ! [ -d "/Applications/MySQLWorkbench.app" ]; then
    echo 'Installing MySQL Workbench...'

    aws s3 cp s3://"${S3_BUCKET_NAME}"/${MYSQL_WORKBENCH_DMG} "${TOOLS_DIR}"/mysqlworkbench.dmg
    DOWNLOAD_SUCCESS=$?
    dmg_install "${TOOLS_DIR}"/mysqlworkbench.dmg
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'MySQL Workbench' 'none' 'echo /Applications/MySQLWorkbench.app'
