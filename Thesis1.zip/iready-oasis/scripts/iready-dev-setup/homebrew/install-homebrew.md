## Prerequisites
1. Mac computer
## Who should use this script?
Anyone interested in installing Homebrew for their local machine
## What's included in this script?
Install Homebrew
## Run Script
1. Download/Clone [this repo]( https://github.cainc.com/iready/iready-dev-setup)
2. Navigate to the iready-dev-setup folder
3. Execute the bash script with: `bash homebrew/install-homebrew.sh`

## __Homebrew is now installed!__