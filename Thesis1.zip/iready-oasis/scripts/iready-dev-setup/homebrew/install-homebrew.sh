# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# Check if Homebrew is installed, if it isn't, install it
brew --version >/dev/null 2>&1
HOMEBREW_IS_AVAILABLE=$?
if [ $HOMEBREW_IS_AVAILABLE -ne 0 ]; then
    echo 'Installing Homebrew'
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    (echo; echo "eval \"$(/opt/homebrew/bin/brew shellenv)\"") >> /Users/"$USERNAME"/.zprofile
    eval "$(/opt/homebrew/bin/brew shellenv)"
    DOWNLOAD_SUCCESS=$?
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Homebrew' 'brew --version' 'which brew'