## Prerequisites
1. Mac computer
2. Have been granted access to AWS by Helpdesk ([see Service Now](https://cainc.service-now.com/esc?id=sc_cat_item&sys_id=3f1dd0320a0a0b99000a53f7604a2ef9))
3. Can have AWS CLI v1 or no version installed
## Who should use this script?
1. Anyone who wants to upgrade from AWS CLI v1 to v2
2. Anyone who wants to install AWS CLI v2 that doesn't have AWS installed
## What's included in this script?
1. Install AWS v2
2. Configure AWS credentials and settings
## Run Script (total running time for upgrade less than three minutes )
1. Download/Clone [this repo]( https://github.cainc.com/iready/iready-dev-setup)
2. Navigate to the iready-dev-setup folder
3. Execute the bash script with: `bash aws/install-aws-sso.sh`
4. Enter your Mac password when prompted to give the script root privilege
5. During the AWS CLI configuration, click enter to select the default values or enter your own
6. When prompted, go to the browser and enter your Okta credentials
7. Complete multifactor authentication
8. Click allow AWS access through Okta
9. Complete command line configuration
## __AWS CLI v2 is now installed!__
