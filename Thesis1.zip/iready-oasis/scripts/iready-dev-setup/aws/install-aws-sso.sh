#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# Target profile — honour the developer's choice (OASIS passes AWS_PROFILE);
# falls back to "default".
AWS_PROFILE="${AWS_PROFILE:-default}"

# Bootstrap defaults. These are only used to SEED a machine that has no AWS SSO
# config yet — if the chosen profile is already configured we leave it alone (see
# configure_aws_credentials). Every value is overridable via the environment so
# this isn't pinned to one org/account.
AWS_CLI_ZIP="${AWS_CLI_PKG_URL:-https://awscli.amazonaws.com/AWSCLIV2.pkg}"
AWS_SSO_START_URL="${AWS_SSO_START_URL:-https://d-90674a9f7e.awsapps.com/start}"
AWS_SSO_REGION="${AWS_SSO_REGION:-us-east-1}"
AWS_SETUP_REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}"
AWS_SSO_ACCOUNT_ID="${AWS_SSO_ACCOUNT_ID:-678467581510}"
AWS_REQUIRED_VERSION="aws-cli/2."
AWS_VERSION=''

# Logs the result for the given tool installation
#
# @param: install error code
# @param: tool name
# @param: command to check the version
# @param: command to check where the version is installed
log_aws_result() {
    if [ "$3" != 'none' ]; then
        VERSION=$($3)
        VERSION="version ${VERSION}"
    else
        VERSION=''
    fi

    if [ "$1" -eq 0 ]; then
        TOOL_LOCATION=$($4)
        AWS_VERSION=$(aws --version 2>&1)
        if [[ "$AWS_VERSION" != *"$AWS_REQUIRED_VERSION"* ]]; then
            echo 'AWS version installed is' "$AWS_VERSION" 'but required version is ' "$AWS_REQUIRED_VERSION"'x. Exiting...'
            exit 1
        fi
        echo '[SUCCESS] ' "$2" "$VERSION" 'installed at ' "$TOOL_LOCATION" | tee -a setup.log
    elif [ "$1" -eq -1 ]; then
        echo '[SKIPPED] ' "$2" ' already installed, skipping...' | tee -a setup.log
    else
        echo '[FAILED] ' "$2" ' was unable to be installed' | tee -a setup.log
        echo 'Reconfigure AWS credentials if needed using: aws configure'
        exit 1
    fi
}

# Configures AWS credentials for profile "$AWS_PROFILE".
#
# Respect an existing setup: if the profile is already configured for SSO (has an
# sso_start_url), we DON'T overwrite the developer's start URL / account / role —
# we just run `aws sso login`. Only a machine with no SSO config gets seeded with
# the bootstrap defaults above, after which we auto-select an account + role.
configure_aws_credentials() {
    local existing_start_url
    existing_start_url=$(aws configure get sso_start_url --profile "$AWS_PROFILE" 2>/dev/null || true)

    if [ -n "$existing_start_url" ]; then
        echo "Profile '$AWS_PROFILE' is already configured for SSO ($existing_start_url) — signing in without changing it."
        type dl_notify >/dev/null 2>&1 && dl_notify "AWS sign-in" "A browser will open for AWS SSO — approve the login in Okta."
        echo "Opening browser for AWS SSO login. Approve it in Okta, then return here."
        aws sso login --profile "$AWS_PROFILE"
        return $?
    fi

    echo "Profile '$AWS_PROFILE' has no SSO config — seeding bootstrap defaults (override with AWS_SSO_START_URL / AWS_SSO_REGION / AWS_REGION)."
    # followed according to specification in https://curriculumassociates.atlassian.net/wiki/spaces/OP/pages/160308352/AWS+SSO+via+Okta
    aws configure set sso_start_url "$AWS_SSO_START_URL" --profile "$AWS_PROFILE"
    aws configure set sso_region "$AWS_SSO_REGION" --profile "$AWS_PROFILE"
    aws configure set region "$AWS_SETUP_REGION" --profile "$AWS_PROFILE"
    aws configure set output json --profile "$AWS_PROFILE"

    # OASIS runs without a terminal, so `aws configure sso` (which prompts
    # to pick an account/role) can't be used. Instead we log in via the browser
    # and then auto-select the DEVELOPMENT account + its first role.
    type dl_notify >/dev/null 2>&1 && dl_notify "AWS sign-in" "A browser will open for AWS SSO — approve the login in Okta."
    echo "Opening browser for AWS SSO login. Approve it in Okta, then return here."
    aws sso login --profile "$AWS_PROFILE"

    # Pull the freshest cached SSO access token (the file that has accessToken).
    local cache_file token account_id role_name
    cache_file=$(grep -l accessToken "$HOME"/.aws/sso/cache/*.json 2>/dev/null | xargs ls -t 2>/dev/null | head -1)
    if [ -z "$cache_file" ]; then
        echo "Could not locate an SSO access token after login." >&2
        return 1
    fi
    token=$(sed -E 's/.*"accessToken" *: *"([^"]+)".*/\1/' <<<"$(tr -d '\n' <"$cache_file")")

    # Prefer the account whose name looks like "development"; fall back to the first.
    account_id=$(aws sso list-accounts --access-token "$token" --region "$AWS_SSO_REGION" \
        --query "accountList[?contains(accountName, 'evelop')].accountId | [0]" --output text 2>/dev/null)
    if [ -z "$account_id" ] || [ "$account_id" = "None" ]; then
        account_id=$(aws sso list-accounts --access-token "$token" --region "$AWS_SSO_REGION" \
            --query "accountList[0].accountId" --output text 2>/dev/null)
    fi
    # Take the first available role for that account (the default option).
    role_name=$(aws sso list-account-roles --account-id "$account_id" --access-token "$token" --region "$AWS_SSO_REGION" \
        --query "roleList[0].roleName" --output text 2>/dev/null)

    if [ -z "$account_id" ] || [ "$account_id" = "None" ] || [ -z "$role_name" ] || [ "$role_name" = "None" ]; then
        echo "Falling back to the default account id ${AWS_SSO_ACCOUNT_ID}." >&2
        account_id="$AWS_SSO_ACCOUNT_ID"
    fi

    echo "Using AWS development account: ${account_id} (role: ${role_name:-default})"
    aws configure set sso_account_id "$account_id" --profile "$AWS_PROFILE"
    [ -n "$role_name" ] && [ "$role_name" != "None" ] && aws configure set sso_role_name "$role_name" --profile "$AWS_PROFILE"
    echo "AWS configuration performed."
}

# Check if AWS is installed, if it isnt, install it
AWS_VERSION=$(aws --version 2>&1)
DOWNLOAD_AWSP=$?
# Check if AWS is installed, if it isnt, install it and set up
# IF AWS is installed and not the required version OR AWS is not installed
if [[ ( $DOWNLOAD_AWSP -eq 0 && "$AWS_VERSION" != *"$AWS_REQUIRED_VERSION"* ) || $DOWNLOAD_AWSP -ne 0 ]]; then
    echo 'Installing AWS Cli...'
    curl "$AWS_CLI_ZIP" -o "${TOOLS_DIR}"/AWSCLIV2.pkg
    DOWNLOAD_SUCCESS=$?
    sudo installer -pkg "${TOOLS_DIR}"/AWSCLIV2.pkg -target /
    mkdir -v /Users/"${USERNAME}"/.aws
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
else
    DOWNLOAD_SUCCESS=-1
fi
log_aws_result $DOWNLOAD_SUCCESS 'AWS Cli' 'aws --version' 'which aws'

# Bounded retries — there is no terminal to break an infinite loop in OASIS.
AWS_AUTH_ATTEMPTS=0
while ! aws sts get-caller-identity --profile "$AWS_PROFILE" >/dev/null 2>&1; do
    AWS_AUTH_ATTEMPTS=$((AWS_AUTH_ATTEMPTS + 1))
    if [ "$AWS_AUTH_ATTEMPTS" -gt 3 ]; then
        echo "Could not obtain valid AWS credentials for profile '$AWS_PROFILE' after ${AWS_AUTH_ATTEMPTS} attempts." >&2
        echo "Sign in with 'aws sso login --profile $AWS_PROFILE' and re-run setup." >&2
        exit 1
    fi
    echo "No valid AWS credentials found for profile '$AWS_PROFILE'. Please reconfigure or create them. If you are in a VM, check that your guest OS time is correct"
    configure_aws_credentials
done

echo "AWS Credentials are valid for profile '$AWS_PROFILE'"
echo "Done"
