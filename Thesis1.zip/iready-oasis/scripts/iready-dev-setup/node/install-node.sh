#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

############################################ MAIN SCRIPT START ############################################

NODE_VERSION=$(node --version 2>&1)
NODEL_IS_AVAILABLE=$?
if [[ NODEL_IS_AVAILABLE -ne 0 ]]; then
    echo 'Installing Node...'
    brew install node
    DOWNLOAD_SUCCESS=$?
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Node' 'node --version' 'which node'
echo "Done."