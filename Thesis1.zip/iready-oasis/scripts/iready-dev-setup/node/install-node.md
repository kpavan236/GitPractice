## Prerequisites
1. Mac computer
2. Homebrew installed
## Who should use this script?
1. Anyone who wants to install Node
## What's included in this script?
1. Install of Node
## Run script
1. Download/Clone [the iready dev setup repo]( https://github.cainc.com/iready/iready-dev-setup)
2. Navigate to the iready-dev-setup folder
3. Execute the bash script with: `bash node/install-node.sh`
   1. Enter root password when prompted to install Node
   2. Press enter to install Node
## __Node is now installed!__
