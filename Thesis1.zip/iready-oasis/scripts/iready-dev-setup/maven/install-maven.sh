#!/bin/bash
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

MAVEN_TAR="apache-maven-3.8.1-bin.tar.gz"

# Check if Maven is downloaded, if it isnt, download it
if ! [ -d "${TOOLS_DIR}"/apache-maven/bin ]; then
    echo 'Installing Maven...'

    aws s3 cp s3://"${S3_BUCKET_NAME}"/${MAVEN_TAR} "${TOOLS_DIR}"/maven.tar.gz
    DOWNLOAD_SUCCESS=$?
    mkdir -v "${TOOLS_DIR}"/apache-maven
    tar -xvzf "${TOOLS_DIR}"/maven.tar.gz -C "${TOOLS_DIR}"/apache-maven --strip-components 1
    cp ./settings/maven_settings.xml "${TOOLS_DIR}"/apache-maven/conf/settings.xml
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Apache-Maven' 'none' 'echo ~/dev/tools/apache-maven'
