#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

OPENJDK_REQURIED_VERSION='17'

# Check if OpenJDK is installed, if it isnt, install it
JAVA_VERSION=$(java --version 2>&1)
DOWNLOAD_JAVAP=$?
if [[ $DOWNLOAD_JAVAP -eq 0 && "$JAVA_VERSION" != *"$OPENJDK_REQURIED_VERSION"* ]]; then
    echo 'This setup requires java version ' "$OPENJDK_REQURIED_VERSION"', but you have ' "$JAVA_VERSION" '.'
    # Non-interactive: OASIS sets DOWNLOAD_JDK (default "y") instead of prompting.
    yesno="${DOWNLOAD_JDK:-y}"
    echo "Download required version? (auto: ${yesno})"
    [[ $yesno = 'y' ]] && DOWNLOAD_JAVAP=1 || DOWNLOAD_JAVAP=0
fi

PROFILE="jdk-bash-profile";

if [ $DOWNLOAD_JAVAP -ne 0 ]; then
    echo 'Installing OpenJDK...'
    brew install openjdk@$OPENJDK_REQURIED_VERSION

    echo "Moving JDK to Java directory..."
    
    if [[ $ARCHITECTURE = "$M1" ]]; then
        sudo ln -sfn /opt/homebrew/opt/openjdk\@17/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk.jdk
    elif [[ $ARCHITECTURE = "$INTEL" ]]; then
        sudo ln -sfn /usr/local/opt/openjdk\@17/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk.jdk
    fi

    # if there is not a zshrc backup, create a backup in case it is needed
    if [ ! -f ~/.zshrc.bak1 ]; then
        echo "Creating a backup of the old .zshrc and adding a new one"
        cp ~/.zshrc{,.bak1}
    fi

    echo "Updating .zshrc file"
    # Comment out the old JAVA_HOME and appending of JAVA_HOME to PATH
    sed -i '.bak' 's|^\(.*JAVA_HOME.*\)$|#\1|' "/Users/$USERNAME/.zshrc"
    # Add exporting of new JAVA_HOME
    add_data_to_file "$SCRIPT_DIR/$PROFILE" "/Users/$USERNAME/.zshrc"
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
    DOWNLOAD_SUCCESS=$?

else
    DOWNLOAD_SUCCESS=-1
fi

log_result $DOWNLOAD_SUCCESS 'OpenJDK' 'java --version' 'which java'
