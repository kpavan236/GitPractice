## Prerequisites
1. AWS Credentials
    1. Credentials are created using [this confluence doc](https://curriculumassociates.atlassian.net/wiki/spaces/OP/pages/160308352/AWS+SSO+via+Okta)
2. GitHub Enterprise Account
3. (Optional) IntelliJ License
4. (Optional) [Cursor IDE](https://www.cursor.com/) — recommended for developers transitioning from IntelliJ

## Initial Setup
1. Download the i-Ready Developer Setup Automation Repo: https://github.cainc.com/iready/iready-dev-setup
  1. Cloning will not work yet because you don't have a Personal Access Token setup yet. The script will tell you how to set that up later on.
  2. If you do not have git installed, the script will install it for you
3. For Mac:
    1. Open System Settings
    1. Privacy & Security
    1. Scroll down to Full Disk Access
    1. Make sure Terminal is toggled on
        1. If you do not see Terminal, click the +, navigate to Applications/Utility, select Terminal
    1. Authenticate with Touch ID / password if applicable

## Run Script (total running time will be less than an hour)
0. A backup of .zshrc is created
1. Navigate into the iready-dev-setup folder
2. Execute the bash script with:
        bash iready-dev-setup.sh
3. If there is a popup when installing git, click CANCEL
4. Enter your Mac password when prompted to give the script root privilege
5. If there is a popup when installing java, click OK
6. If there is a popup for IntelliJ, click OPEN
    1. Accept the JetBrains License Agreement and hit CONTINUE
    2. Select either Don't Send or Send Anonymous Statistics on Data Sharing
    3. Either activate your IntelliJ license or evaluate for free
7. When prompted, choose whether to install Cursor IDE (y/n)
8. Provide your github name/password when prompted
9. Follow the steps to clone i-Ready core repo and setup a personal access token here: https://curriculumassociates.atlassian.net/wiki/spaces/OP/pages/2523267348/Create+a+GitHub+Personal+Access+Token+PAT+for+use+with+HTTPS
10. Run part two of the bash script with `bash environment/finish-setup-post-manual-steps.sh`
11. Enter password if prompted.


## After Script
1. Request Docker business license
   1. Email helpdesk@cainc.com to request a Docker business license 
   2. Download Docker Desktop for Mac: https://www.docker.com/products/docker-desktop
   3. Install Docker Desktop and login with your Docker business account credentials
2. Choose if you need the ircli project or just Redis. Without Redis, you will not be able to run the full i-Ready application locally. The services (ircli) project is used for local development of i-Ready projects that rely on services like Redis, Localstack, and MySQL. `ircli` stands for i-Ready command line interface. If you are only working on i-Ready core, you can skip setting up this project and the `ircli` command and just use Docker to run Redis locally.
   1. To run Redis with Docker, use the command `docker run -d --name redis -p 6379:6379 redis` in your terminal to start a Redis container.
   2. To use `ircli`, clone [this](https://github.cainc.com/iready/services) repo and follow the instructions in the Docs link inside the README.md to set up ircli. Once the project is setup and `ircli` is installed, from iready-core run `ircli`, `start`, `start infrastructure`, select none, and then hit enter. This will start Redis.
3. Import iready-core into IntelliJ
    1. Click Open in IntelliJ
    2. Select pom.xml in iready-core project files to import as maven project
4. Open iready-core in IntelliJ
    1. Navigate to Run → Edit Configurations → Tomcat Server
        1. Application Server → Configure
        2. Select your Tomcat Folder (~/dev/tools/apache-tomcat)
        3. Click OK to finish configuring Tomcat

### Cursor IDE Setup (if installed)
See the [Cursor setup instructions](cursor/README.md) for details.

## __Your Developer Environment Is Now Complete!__
Start your Tomcat Server and check things out!

## Problems?
Check out the [wiki page](../../wiki/Troubleshooting)

## Before contributing code changes, follow the Contributing guide!
Check out the [wiki page](../../wiki/Contributing)

## Running in a virtual machine?
Check out the [wiki page](../../wiki/VM-Setup)
