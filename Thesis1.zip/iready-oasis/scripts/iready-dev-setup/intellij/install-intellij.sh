#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# When updating the versions, make sure the $INTELLIJ_PATH below matches up.
# The IntelliJ version dictates what the folder will be named
INTELLIJ_DMG="ideaIU-2023.2.3.dmg"
# m1 native installation: https://www.jetbrains.com/idea/download/#section=mac
M1_INTELLIJ_DMG="ideaIU-2023.2.3-aarch64.dmg"

INTELLIJ_ROOT_PATH=~/Library/Application\ Support/JetBrains
INTELLIJ_PATH=$INTELLIJ_ROOT_PATH/IntelliJIdea2023.2

if [[ $ARCHITECTURE = "$M1" ]]; then
    INTELLIJ_DMG=$M1_INTELLIJ_DMG
fi

# Check if IntelliJ is installed, if it isnt, install it
if ! [ -d "/Applications/IntelliJ IDEA.app" ]; then
    echo 'Installing IntelliJ...'

    aws s3 cp s3://"${S3_BUCKET_NAME}"/"${INTELLIJ_DMG}" "${TOOLS_DIR}"/intellij.dmg
    DOWNLOAD_SUCCESS=$?
    dmg_install "${TOOLS_DIR}"/intellij.dmg

    # Move IntelliJ config files to Jetbrains config location
    # Need to create folder since it's not created until intellij starts for the first time.
    # Doing this prior to "open idea" so user can use intellij once it starts, instead of waiting to copy files some time afterwards
    mkdir -pv "$INTELLIJ_PATH"
    cp -R "./settings/intellij_config/options" "$INTELLIJ_PATH"

    # Ensure the user owns the IntelliJ app folder so IntelliJ can perform version updates
    sudo chown -R "${USERNAME}" "/Applications/IntelliJ IDEA.app"

    open "/Applications/IntelliJ Idea.app"
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'IntelliJ' 'none' 'echo /Applications/IntelliJ IDEA.app'
