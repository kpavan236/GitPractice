## Prerequisites
1. Mac computer
## Who should use this script?
1. Anyone who wants to migrate from MySQL Server 5.x -> Homebrew's MySQL 8.0
2. Anyone who wants to install MySQL 8.0 without any prior MySQL installations
## What's included in this script?
1. Uninstall of MySQL 5.x (data will be lost)
   1. A backup of .zshrc is created
2. Install and configuration of Homebrew's MySQL 8.0
## Run script (total running time for upgrade less than three minutes )
1. Download/Clone [the iready dev setup repo]( https://github.cainc.com/iready/iready-dev-setup)
2. Navigate to the iready-dev-setup folder
3. Execute the bash script with: `bash mysql/install-mysql.sh`
   1. Enter root password when prompted to uninstall mysql 5.x
   2. Press enter to install Homebrew
   3. Enter root password when prompted to install mysql 8.0
   4. Enter root password a second time when prompted
## __Homebrew MySQL 8.0 is now installed!__
### Make sure to start new terminal to access mysql after the script has completed
