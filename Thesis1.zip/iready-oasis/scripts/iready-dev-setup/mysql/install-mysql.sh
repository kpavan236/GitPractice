#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# This mysql install script is used by the main dev setup script and can be used standalone to upgrade from mysql 5.x -> 8.0
MYSQL_REQUIRED_VERSION="8.0"
BREW_FORMULA="mysql@$MYSQL_REQUIRED_VERSION"


# Updates bash profile with new MySQL home path
configure_mysql_install() {

    if [[ $ARCHITECTURE = "$M1" ]]; then
        echo 'Install mysql for M1 chip' | tee -a setup.log
        PROFILE="mysql-bash-profile-m1";
        MY_CONF_PATH="/opt/homebrew/etc/my.cnf"
    elif [[ $ARCHITECTURE = "$INTEL" ]]; then
        echo 'Install mysql for Intel chip' | tee -a setup.log
        PROFILE="mysql-bash-profile";
        MY_CONF_PATH="/etc/my.cnf"
    fi

    sed -i '.bak' '/MYSQL_HOME/d' "/Users/$USERNAME/.zshrc" # Delete old MYSQL_HOME and appending of MYSQL_HOME to PATH
    add_data_to_file "$SCRIPT_DIR/$PROFILE" "/Users/$USERNAME/.zshrc" # Add exporting of new MYSQL_HOME

    # if there is not a zshrc backup, create a backup in case it is needed
    if [ ! -f ~/.zshrc.bak1 ]; then
        echo "Creating a backup of the old .zshrc and adding a new one"
        cp ~/.zshrc{,.bak1}
    fi

    sudo mkdir -v /usr/local/etc # Add local etc folder for case where systems don't have it by default. Needs sudo to make file in /usr/local
    sudo touch /usr/local/etc/my.cnf # Add local my.cnf file for case where systems don't have it by default.
    sudo bash -c "$(declare -f add_data_to_file); add_data_to_file $SCRIPT_DIR/../additions/mycnf_additions.txt /usr/local/etc/my.cnf" # Copy MySQL additions to my.cnf
    sudo cp /usr/local/etc/my.cnf "$MY_CONF_PATH" # Copy local MySQL configurations to global configurations
    echo 'Starting the mysql server'
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
}

# Removes all MySQL server files to uninstall it
uninstall_mysql() {
    # Followed according to uninstall guide from: https://community.jaspersoft.com/wiki/uninstall-mysql-mac-os-x
    echo "Removing all instances of MySQL"
    echo "Enter root password"

    # Uninstall old versions of SQL
    echo "Uninstalling old versions of SQL"
    versions=$(brew list | grep "^mysql@")

    for version in $versions; do
        brew remove $version
    done

    # Remove MySQL files
    [ -e /usr/local/mysql ] && sudo rm /usr/local/mysql
    sudo rm -rf /usr/local/var/mysql
    sudo rm -rf /usr/local/mysql*
    sudo rm -rf /Library/StartupItems/MySQLCOM
    sudo rm -rf /opt/homebrew/var/mysql/
    sudo rm -rf /opt/homebrew/etc/my.cnf
    sudo rm -rf /etc/my.cnf
    sudo rm -rf /usr/local/etc/my.cnf
    # Remove MySQL Preferences panel
    sudo rm -rf /Library/PreferencePanes/MySQL*
    sudo rm -rf ~/Library/PreferencePanes/MySQL*
    sudo rm -rf /Library/Receipts/mysql*
    sudo rm -rf /Library/Receipts/MySQL*
    sudo rm -rf /private/var/db/receipts/*mysql*

    sudo pkill -f "mysql" # Kill any remaining MySQL processes. This is done after, otherwise they will keep regenerating

    # remove legacy cnf if exists, as noted by homebrew:
    #     A "/etc/my.cnf" from another install may interfere with a Homebrew-built server starting up correctly.
    [ -e /etc/my.cnf ] && sudo rm /etc/my.cnf

    # remove homebrew installation.
    if brew ls --versions $BREW_FORMULA > /dev/null; then
        echo 'Detected previous homebrew installation of' $BREW_FORMULA
        brew remove $BREW_FORMULA
    fi
}

############################################ MAIN SCRIPT START ############################################

# IF MySQL is not installed OR MySQL is installed AND not at the required version, THEN
# 1. Uninstall other instances of MySQL
# 2. Install MySQL 8.0

# IF mysql is not installed OR mysql is NOT the correct version
MYSQL_VERSION=$(mysql --version 2>&1)
MYSQL_IS_AVAILABLE=$?
if [[ MYSQL_IS_AVAILABLE -ne 0 || MYSQL_IS_AVAILABLE -eq 0 && "$MYSQL_VERSION" != *"$MYSQL_REQUIRED_VERSION"* ]]; then
    uninstall_mysql
    echo 'Installing MYSQL...'
    brew install $BREW_FORMULA
    configure_mysql_install
    sudo rm -rf /opt/homebrew/var/mysql/
    sudo rm -rf /usr/local/var/mysql
    mysqld --initialize-insecure --lower_case_table_names=1 --user=mysql
    brew services restart $BREW_FORMULA
    DOWNLOAD_SUCCESS=$?
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'MySQL' 'mysql --version' 'which mysql'
echo "Done."
# add instructions for backup and restore. cd to new tab. mysql will not work in same tab without sourcing in zsh
