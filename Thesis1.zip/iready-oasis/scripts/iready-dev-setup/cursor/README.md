# Cursor IDE Setup

1. Open Cursor and log in with your CA Okta credentials when prompted
2. Accept the default settings during initial setup
3. Move the sidebar to the left: right-click the sidebar → Move Primary Side Bar Left
4. Open a project using File → Open Folder, or from the terminal: `cursor ~/dev/projects/iready/iready-core`
5. The Java Language Server will index the project — this may take several minutes on first open
6. Tomcat start/debug tasks and launch configs are already in the repo's `.vscode/` directory
7. Project-specific settings (JDT LS memory, test configs) can be overridden in each project's `.vscode/settings.json`
