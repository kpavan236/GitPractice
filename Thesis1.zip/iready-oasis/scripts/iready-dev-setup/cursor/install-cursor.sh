#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

CURSOR_APP="/Applications/Cursor.app"
CURSOR_CLI="$CURSOR_APP/Contents/Resources/app/bin/cursor"
CURSOR_SETTINGS_DIR=~/Library/Application\ Support/Cursor/User
CURSOR_SETTINGS_SRC="$SCRIPT_DIR/../settings/cursor_config/settings.json"
EXTENSIONS_FILE="$SCRIPT_DIR/extensions.txt"

# Check if Cursor is installed, if it isn't, install it
if ! [ -d "$CURSOR_APP" ]; then
    echo 'Installing Cursor...'
    brew install --cask cursor
    DOWNLOAD_SUCCESS=$?
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS 'Cursor' 'none' "echo $CURSOR_APP"

# Export system CA certs so the Cursor CLI trusts the corporate proxy (e.g. Zscaler)
CA_BUNDLE="/tmp/cursor_ca_bundle.pem"
security find-certificate -a -p /Library/Keychains/System.keychain > "$CA_BUNDLE" 2>/dev/null
security find-certificate -a -p /System/Library/Keychains/SystemRootCertificates.keychain >> "$CA_BUNDLE" 2>/dev/null
export NODE_EXTRA_CA_CERTS="$CA_BUNDLE"

# Install extensions
if [ -f "$EXTENSIONS_FILE" ]; then
    echo 'Installing Cursor extensions...'
    while IFS= read -r line || [[ -n "$line" ]]; do
        # Skip blank lines and comments
        line=$(echo "$line" | xargs)
        [[ -z "$line" || "$line" == \#* ]] && continue
        echo "  Installing extension: $line"
        "$CURSOR_CLI" --install-extension "$line"
    done < "$EXTENSIONS_FILE"
    echo '[SUCCESS] Cursor extensions installed' | tee -a setup.log
    rm -f "$CA_BUNDLE"
fi

# Copy global settings if not already present
if [ ! -f "$CURSOR_SETTINGS_DIR/settings.json" ]; then
    echo 'Copying Cursor global settings...'
    mkdir -p "$CURSOR_SETTINGS_DIR"
    cp "$CURSOR_SETTINGS_SRC" "$CURSOR_SETTINGS_DIR/settings.json"
    echo '[SUCCESS] Cursor global settings copied' | tee -a setup.log
else
    echo '[SKIPPED] Cursor global settings already exist, skipping...' | tee -a setup.log
fi
