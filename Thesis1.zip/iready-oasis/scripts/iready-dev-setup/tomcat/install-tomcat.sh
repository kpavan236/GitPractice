#!/bin/bash
# Allows direct usage of any functions in the 'util' folder
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
for script in "$SCRIPT_DIR"/../util/*.sh; do . "$script"; done

# Keeping historical versions listed here for reference during transitions
# TOMCAT_TAR="apache-tomcat-9.0.50.tar.gz"

# Note, when changing the version, also search the rest of the project for the version number
TOMCAT_VERSION="apache-tomcat-10.1.16"
TOMCAT_TAR="$TOMCAT_VERSION.tar.gz"

# Check if Tomcat is downloaded, if it isnt, download it
if ! [ -d "${TOOLS_DIR}"/"$TOMCAT_VERSION"/bin ]; then
    echo "Installing ${TOMCAT_VERSION}..."

    aws s3 cp s3://"${S3_BUCKET_NAME}"/"${TOMCAT_TAR}" "${TOOLS_DIR}"/"${TOMCAT_TAR}"
    DOWNLOAD_SUCCESS=$?
    mkdir -v "${TOOLS_DIR}"/"${TOMCAT_VERSION}"
    tar -xvzf "${TOOLS_DIR}"/"${TOMCAT_TAR}" -C "${TOOLS_DIR}"/"$TOMCAT_VERSION" --strip-components 1
    chmod +x "${TOOLS_DIR}"/"${TOMCAT_VERSION}"/bin/catalina.sh
else
    DOWNLOAD_SUCCESS=-1
fi
log_result $DOWNLOAD_SUCCESS $TOMCAT_VERSION 'none' "echo ~/dev/tools/$TOMCAT_VERSION"
