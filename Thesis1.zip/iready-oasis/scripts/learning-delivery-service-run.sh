#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — learning-delivery-service run script
#
# 1. Kills any existing Spring Boot + Vite instances
# 2. Starts LearningDeliveryApplication (Spring Boot, port 8787)
#      Active profiles : text-logs,local,local-content-fetcher
#      JVM args        : -Duser.timezone=UTC
#      Log file        : ~/Desktop/LDS_logs/logs.txt
# 3. Starts the Vite dev server (cd ui && npm run dev, port 18787)
#      Log file        : ~/Desktop/LDS_logs/ui-dev.log
# 4. Waits for both ports then prints the service URLs and exits.
#    The OASIS loader stops and the URLs appear as clickable links in the log.
#
# NOTE: background processes are started WITHOUT a subshell so they do not
# inherit the pipe file descriptors that the OASIS server reads from.
# A subshell holds those fds open while waiting for npm, which prevents
# proc.on('close') from ever firing (infinite loader).
#
# Requires the JAR to already exist at core/target/ (run Build first).
# Usage (called by server): bash scripts/learning-delivery-service-run.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CLONE_DIR="${1:?Usage: learning-delivery-service-run.sh <clone_dir>}"
cd "$CLONE_DIR"

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

log "Starting learning-delivery-service…"

command -v java >/dev/null || fail "Java not found. Set JAVA_HOME and ensure java is on PATH."
command -v npm  >/dev/null || fail "npm not found. Install Node.js to start the UI dev server."

# ── Kill any existing Spring Boot instance ────────────────────────────────
if pgrep -f "LearningDeliveryApplication" >/dev/null 2>&1; then
  log "Stopping existing Spring Boot instance…"
  pkill -f "LearningDeliveryApplication" 2>/dev/null || true
  for i in $(seq 1 10); do
    pgrep -f "LearningDeliveryApplication" >/dev/null 2>&1 || break
    sleep 1
  done
  ok "Previous Spring Boot instance stopped"
fi

# ── Kill any existing Vite dev server on port 18787 ───────────────────────
EXISTING_VITE=$(lsof -ti tcp:18787 2>/dev/null || true)
if [[ -n "$EXISTING_VITE" ]]; then
  log "Stopping existing Vite dev server (PID $EXISTING_VITE)…"
  kill "$EXISTING_VITE" 2>/dev/null || true
  sleep 1
  ok "Previous Vite instance stopped"
fi

# ── Resolve JAR ──────────────────────────────────────────────────────────
JAR=$(find core/target -maxdepth 1 \
  -name "learning-delivery-service-core*.jar" \
  ! -name "*-sources.jar" \
  ! -name "*-tests.jar" \
  2>/dev/null | sort | tail -1) || true

[[ -n "$JAR" ]] || fail "No JAR found in core/target — run Build first."

LOG_DIR="$HOME/Desktop/LDS_logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/logs.txt"

log "JAR:      $JAR"
log "Profiles: text-logs,local,local-content-fetcher"
log "Log file: $LOG_FILE"

> "$LOG_FILE"

# ── Start Spring Boot in background ──────────────────────────────────────
# NOTE: </dev/null closes stdin; >> and 2>&1 redirect stdout+stderr to the
# log file, closing their inherited references to the OASIS pipe.
java \
  -Duser.timezone=UTC \
  -Dspring.profiles.active=text-logs,local,local-content-fetcher \
  -jar "$JAR" </dev/null >> "$LOG_FILE" 2>&1 &
JAVA_PID=$!
log "JVM started (PID $JAVA_PID)"

# ── Wait until Spring Boot port 8787 is ready ────────────────────────────
STARTED=0
for i in $(seq 1 120); do
  if nc -z localhost 8787 2>/dev/null; then
    STARTED=1; break
  fi
  kill -0 "$JAVA_PID" 2>/dev/null || fail "JVM exited unexpectedly — check $LOG_FILE for details"
  sleep 1
done
[[ $STARTED -eq 1 ]] || fail "LearningDeliveryApplication did not start within 120 s — check $LOG_FILE"
ok "LearningDeliveryApplication is running (PID $JAVA_PID)"

# ── Start Vite UI dev server in background ────────────────────────────────
# Use plain `cd + command &` instead of a subshell `(cd ... && cmd) &`.
# A subshell inherits the OASIS pipe fds and holds them open while
# waiting for npm (which never exits), so proc.on('close') would never fire.
log "Starting Vite UI dev server (ui/npm run dev)…"
cd "$CLONE_DIR/ui"
npm run dev </dev/null >> "$LOG_DIR/ui-dev.log" 2>&1 &
VITE_PID=$!
cd "$CLONE_DIR"
log "Vite started (PID $VITE_PID)"

# ── Wait until Vite port 18787 is ready ──────────────────────────────────
UI_STARTED=0
for i in $(seq 1 60); do
  if nc -z localhost 18787 2>/dev/null; then
    UI_STARTED=1; break
  fi
  kill -0 "$VITE_PID" 2>/dev/null || fail "Vite dev server exited unexpectedly — check $LOG_DIR/ui-dev.log"
  sleep 1
done
[[ $UI_STARTED -eq 1 ]] || fail "Vite dev server did not start within 60 s — check $LOG_DIR/ui-dev.log"
ok "Vite UI dev server is running (PID $VITE_PID)"

ok "learning-delivery-service is fully up"
ok "UI:      http://localhost:8787/ui"
log "Swagger: http://localhost:8787/swagger-ui/index.html"

# Open the UI in the default browser
open "http://localhost:8787/ui" 2>/dev/null || true

# Close the inherited pipe fds so the OASIS server receives EOF on its
# stdout/stderr streams and the job is marked complete (loader stops).
exec 1>/dev/null 2>/dev/null
