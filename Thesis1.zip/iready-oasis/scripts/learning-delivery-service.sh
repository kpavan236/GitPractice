#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — learning-delivery-service setup script
#
# Steps executed when "Setup Workspace" is clicked:
#   1 — Clone git@github.cainc.com:iready/services.git  (or pull if already cloned,
#       auto-answering Y to hook prompts; skips pull when already up to date)
#   2 — Open ircli in a Terminal window inside the services repo; wait for user
#   3 — Open ircli in a Terminal window inside the learning-delivery-service repo; wait
#   4 — mvn clean install
#   (After setup succeeds OASIS automatically shows the "Launch Service" button)
#
# Usage (called by OASIS server): bash scripts/learning-delivery-service.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CLONE_DIR="${1:?Usage: learning-delivery-service.sh <clone_dir>}"
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$CLONE_DIR"

# Shared helpers (dl_log, dl_notify, dl_prime_sudo, …)
# shellcheck source=/dev/null
. "$SCRIPT_DIR/lib/oasis-common.sh"

ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
warn() { echo "[$(date '+%H:%M:%S')] ⚠ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

dl_log "Custom setup for: $(basename "$CLONE_DIR")"

command -v java >/dev/null || fail "Java not found — install JDK and set JAVA_HOME."
command -v mvn  >/dev/null || fail "Maven not found. Install Maven."
dl_log "Java:  $(java -version 2>&1 | head -1)"
dl_log "Maven: $(mvn --version | head -1)"

# ── Pull latest for learning-delivery-service (never re-clone) ────────────
# OASIS clones learning-delivery-service the first time you click
# "Setup Workspace". Every subsequent click just does a git pull on the default
# branch. The script exits early if the repo somehow isn't present rather than
# attempting a clone (which would require credentials only the server holds).
if [[ -d "$CLONE_DIR/.git" ]]; then
  _LDS_BRANCH="$(git -C "$CLONE_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo main)"
  dl_log "learning-delivery-service already cloned — pulling latest on branch '$_LDS_BRANCH'…"
  git -C "$CLONE_DIR" pull origin "$_LDS_BRANCH" 2>&1 \
    || warn "git pull returned non-zero — continuing with current checkout"
  ok "learning-delivery-service: branch '$_LDS_BRANCH' is up to date"
else
  fail "learning-delivery-service repo not found at $CLONE_DIR — run 'Setup Workspace' from the OASIS home tab to clone it first."
fi

# ── Step 1: Clone or pull the services repo ────────────────────────────────
SERVICES_DIR="$(dirname "$CLONE_DIR")/services"
dl_log "Services repo path: $SERVICES_DIR"

if [[ -d "$SERVICES_DIR/.git" ]]; then
  dl_log "services repo already cloned — checking for upstream changes…"
  _SERVICES_BRANCH="$(git -C "$SERVICES_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo main)"

  # Fetch silently so we can compare local vs remote without modifying the tree.
  git -C "$SERVICES_DIR" fetch origin "$_SERVICES_BRANCH" --quiet 2>&1 || true

  _LOCAL="$(git  -C "$SERVICES_DIR" rev-parse HEAD 2>/dev/null || echo '')"
  _REMOTE="$(git -C "$SERVICES_DIR" rev-parse "origin/$_SERVICES_BRANCH" 2>/dev/null || echo '')"

  if [[ -n "$_REMOTE" && "$_LOCAL" != "$_REMOTE" ]]; then
    dl_log "Pulling latest changes on branch '$_SERVICES_BRANCH'…"
    # Echo "Y" to auto-answer any interactive hook prompts (e.g. git-lfs).
    echo "Y" | git -C "$SERVICES_DIR" pull origin "$_SERVICES_BRANCH" 2>&1 \
      || warn "git pull returned non-zero — continuing anyway"
    ok "services repo updated (branch: $_SERVICES_BRANCH)"
  else
    ok "services repo is already up to date — skipping pull"
  fi
else
  dl_log "Cloning services repo…"
  git clone git@github.cainc.com:iready/services.git "$SERVICES_DIR"
  ok "services repo cloned to $SERVICES_DIR"
fi

# ── Locate ircli ───────────────────────────────────────────────────────────
dl_log "Locating ircli…"
IRCLI_BIN="$(command -v ircli 2>/dev/null || true)"
for _candidate in \
    "$HOME/.npm-global/bin/ircli" \
    "$HOME/.nvm/versions/node/$(ls "$HOME/.nvm/versions/node" 2>/dev/null | tail -1)/bin/ircli" \
    "/opt/homebrew/bin/ircli" \
    "/usr/local/bin/ircli" \
    "$SERVICES_DIR/node_modules/.bin/ircli"; do
  [[ -z "$IRCLI_BIN" && -x "$_candidate" ]] && IRCLI_BIN="$_candidate"
done
[[ -n "$IRCLI_BIN" ]] || fail "ircli not found — install it from the services repo README and re-run setup."
dl_log "Found ircli at: $IRCLI_BIN"

# ── Helper: open ircli in a new Terminal window; block until user confirms ──
# ircli reads from /dev/tty (a real terminal), not from stdin, so it cannot be
# driven by pipe redirection. We open a macOS Terminal window so the user can
# interact with the ircli menu, then show a dialog that pauses this script
# until the user clicks Continue (or Abort).
_run_ircli() {
  local dir="$1"
  local step_label="$2"
  local instructions="$3"

  # Escape single-quotes inside paths for AppleScript string literals.
  local esc_dir="${dir//\'/\'\\\'\'}"
  local esc_bin="${IRCLI_BIN//\'/\'\\\'\'}"

  dl_log "Opening Terminal for: $step_label"
  osascript <<OSA
tell application "Terminal"
  activate
  do script "cd '${esc_dir}' && '${esc_bin}'"
end tell
OSA

  dl_log "Waiting for user to finish: $step_label"
  local _resp
  _resp=$(osascript 2>/dev/null <<OSA
try
  set dlg to display dialog "${instructions}" ¬
    with title "i-Ready OASIS — learning-delivery-service" ¬
    buttons {"Abort", "Continue"} default button "Continue" with icon caution
  if button returned of dlg is "Abort" then
    return "abort"
  end if
  return "ok"
on error
  return "ok"
end try
OSA
  )
  [[ "$_resp" == "abort" ]] && fail "Setup aborted at step: $step_label"
  ok "$step_label — confirmed"
}

# ── Step 2: ircli in services repo ────────────────────────────────────────
dl_log "Step 2: ircli in services repo…"
_run_ircli "$SERVICES_DIR" \
  "ircli (services repo)" \
  "ircli is open in a Terminal window inside the services repo.

Complete the required ircli steps, then click Continue to proceed."

# ── Step 3: ircli in learning-delivery-service repo ────────────────────────
dl_log "Step 3: ircli in learning-delivery-service repo…"
_run_ircli "$CLONE_DIR" \
  "ircli (learning-delivery-service repo)" \
  "ircli is open in a Terminal window inside the learning-delivery-service repo.

Complete the required ircli steps, then click Continue to proceed."

# ── Step 4: npm registry (needed by pnpm bootstrap in Maven validate phase) ─
# The parent pom installs pnpm globally; global installs bypass the project
# .npmrc and use ~/.npmrc, which points at a Nexus group that lacks pnpm.
# Exporting npm_config_registry overrides every .npmrc and lets both the global
# install and the subsequent pnpm install find the right registry.
if [[ -z "${npm_config_registry:-}" && -f .npmrc ]]; then
  _npm_registry="$(sed -nE 's/^[[:space:]]*registry[[:space:]]*=[[:space:]]*//p' .npmrc | head -1)"
  if [[ -n "$_npm_registry" ]]; then
    export npm_config_registry="$_npm_registry"
    ok "Using npm registry from .npmrc: $_npm_registry"
  fi
fi

# ── Step 4 (Maven): build learning-delivery-service ───────────────────────
dl_log "Step 4: running mvn clean install…"
mvn clean install
ok "Maven build done"

# ── Copy local config templates if not already present ───────────────────
if [[ -f "src/main/resources/application-local.properties.example" \
   && ! -f "src/main/resources/application-local.properties" ]]; then
  cp src/main/resources/application-local.properties.example \
     src/main/resources/application-local.properties
  ok "application-local.properties created from example"
fi

if [[ -f "src/main/resources/application-local.yml.example" \
   && ! -f "src/main/resources/application-local.yml" ]]; then
  cp src/main/resources/application-local.yml.example \
     src/main/resources/application-local.yml
  ok "application-local.yml created from example"
fi

if [[ -n "${EXTRA_ENV:-}" ]]; then
  printf '%s\n' "$EXTRA_ENV" > .env
  ok ".env written"
fi

if [[ -n "${INTELLIJ_PATH:-}" && -x "${INTELLIJ_PATH}" ]]; then
  dl_log "Opening in IntelliJ IDEA…"
  "${INTELLIJ_PATH}" "$CLONE_DIR" &
  ok "IntelliJ launched"
fi

ok "Setup complete — the Launch Service button is now active in OASIS"