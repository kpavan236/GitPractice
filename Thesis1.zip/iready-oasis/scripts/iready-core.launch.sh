#!/usr/bin/env bash
# oasis-launch-label: Launch server
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — iready-core launch script
#
# Deploys the built i-Ready web app to the bundled Tomcat 10.1.16 and runs it in
# the foreground so logs stream to the OASIS UI. Mirrors the IntelliJ
# "Tomcat 10.1.16" run config: ROOT context ("/"), port 8080, dev log4j config
# and heap settings. Stopped from the UI (the server kills this process group).
#
# Usage (called by server): bash scripts/iready-core.launch.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
CLONE_DIR="${1:?Usage: iready-core.launch.sh <clone_dir>}"
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$CLONE_DIR"

# Make the dev toolchain visible to this shell (same env the setup build used).
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
export JAVA_HOME="${JAVA_HOME:-/Library/Java/JavaVirtualMachines/openjdk.jdk/Contents/Home}"
export PATH="$JAVA_HOME/bin:$HOME/dev/tools/apache-maven/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"


command -v java >/dev/null || { echo "✗ Java not found. Run setup first." >&2; exit 1; }

# ── AWS credentials ─────────────────────────────────────────────────────────
# iready-core's AWS SDK calls fail at startup without credentials. Resolve them
# via SSO and export them as env vars so the JVM picks them up.
# shellcheck source=/dev/null
. "$SCRIPT_DIR/lib/aws-creds.sh"
dl_ensure_aws_env "${AWS_PROFILE:-default}" || \
  echo "⚠ Continuing without AWS credentials — startup may fail if the app needs AWS." >&2

# ── Local DynamoDB tables (Demogorgon SSO role only) ────────────────────────
# Under the "Demogorgon" SSO role, iready-core talks to a local DynamoDB
# (LocalStack) endpoint on port 4566 — but the checked-in DBScripts default to
# port 8000. Never edit those scripts in place: copy create/list to a scratch
# dir, repoint the copies at 4566, and run create then list from there.
sso_role=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null \
  | sed -E 's#.*AWSReservedSSO_([^_]+)_.*#\1#')
if [[ "$sso_role" == "Demogorgon" ]]; then
  echo "SSO role is Demogorgon — refreshing local DynamoDB tables (port 4566)…"
  DYNAMO_SRC="$CLONE_DIR/DBScripts/dynamo"
  if [[ -f "$DYNAMO_SRC/create-dynamo-tables.sh" && -f "$DYNAMO_SRC/list-dynamo-tables.sh" ]]; then
    DYNAMO_TMP="$(mktemp -d "${TMPDIR:-/tmp}/iready-dynamo.XXXXXX")"
    cp "$DYNAMO_SRC/create-dynamo-tables.sh" "$DYNAMO_SRC/list-dynamo-tables.sh" "$DYNAMO_TMP/"
    # Both scripts default to port 8000 — repoint the copies at 4566 so they
    # actually hit the endpoint this SSO role's local Dynamo runs on.
    sed -i '' 's#http://localhost:8000#http://localhost:4566#g' \
      "$DYNAMO_TMP/create-dynamo-tables.sh" "$DYNAMO_TMP/list-dynamo-tables.sh"
    chmod +x "$DYNAMO_TMP"/*.sh
    ( bash "$DYNAMO_TMP/create-dynamo-tables.sh" && bash "$DYNAMO_TMP/list-dynamo-tables.sh" ) \
      || echo "⚠ DynamoDB table setup failed (tables may already exist) — continuing anyway." >&2
    rm -rf "$DYNAMO_TMP"
  else
    echo "⚠ DBScripts/dynamo scripts not found under $CLONE_DIR — skipping." >&2
  fi
fi

TOMCAT_HOME="${CATALINA_HOME:-$HOME/dev/tools/apache-tomcat-10.1.16}"
[[ -x "$TOMCAT_HOME/bin/catalina.sh" ]] || {
  echo "✗ Bundled Tomcat not found at $TOMCAT_HOME — run setup first." >&2; exit 1; }

# ── Locate the built web artifact ──────────────────────────────────────────
# Preferred: the packaged .war from the IReadyWeb module. Fall back to any war
# under a target/ dir, then to an exploded war directory (IntelliJ builds the
# "ireadyapp:war exploded" artifact). Adjust the IReadyWeb path here if the
# module/war name differs in your checkout.
echo "Locating built i-Ready web artifact…"
# Primary: the ireadyapp module produces the deployable WAR.
WAR=$(ls -1 IReadyPlatform/ireadyapp/target/ireadyapp.war 2>/dev/null | head -1 || true)
# Fallback: any WAR under a target/ dir (handles module renames / future restructuring).
[[ -z "$WAR" ]] && WAR=$(find . -path '*/target/*.war' ! -name '*-sources.war' ! -name '*-tests.war' 2>/dev/null | head -1 || true)

EXPLODED=""
if [[ -z "$WAR" ]]; then
  WEBINF=$(find . -type d -path '*/target/*/WEB-INF' 2>/dev/null | head -1 || true)
  [[ -n "$WEBINF" ]] && EXPLODED="${WEBINF%/WEB-INF}"
fi

if [[ -z "$WAR" && -z "$EXPLODED" ]]; then
  echo "✗ No built .war found. Build first (mvn clean install), then launch." >&2
  exit 1
fi

# ── Deploy to the ROOT context ─────────────────────────────────────────────
echo "Deploying to Tomcat ROOT context…"
rm -rf "$TOMCAT_HOME/webapps/ROOT" "$TOMCAT_HOME/webapps/ROOT.war"
if [[ -n "$WAR" ]]; then
  echo "  war: $WAR"
  cp "$WAR" "$TOMCAT_HOME/webapps/ROOT.war"
else
  echo "  exploded: $EXPLODED"
  mkdir -p "$TOMCAT_HOME/webapps/ROOT"
  cp -R "$EXPLODED"/. "$TOMCAT_HOME/webapps/ROOT/"
fi

# ── Fix lib permissions ────────────────────────────────────────────────────
# Tomcat may expand the WAR after this script exits the deploy step; wait briefly
# so the webapps/ROOT tree exists, then chmod. For an exploded copy the dir is
# already present. Best-effort: don't abort if the path isn't there yet.
LIB_DIR="$TOMCAT_HOME/webapps/ROOT/WEB-INF/lib"
if [[ ! -d "$LIB_DIR" ]]; then
  echo "Waiting for Tomcat to expand ROOT.war…"
  for _i in $(seq 1 10); do sleep 1; [[ -d "$LIB_DIR" ]] && break; done
fi
if [[ -d "$LIB_DIR" ]]; then
  chmod -R 777 "$LIB_DIR"
  echo "✓ Permissions set on $LIB_DIR"
else
  echo "⚠ $LIB_DIR not found yet — Tomcat will expand the WAR on first startup."
fi

# ── Run Tomcat in the foreground ───────────────────────────────────────────
# VM args mirror the IntelliJ run config. `catalina.sh run` keeps the JVM in the
# foreground and writes logs to stdout, so OASIS can stream them; `exec`
# means a SIGTERM to the process group shuts Tomcat down cleanly.
export CATALINA_HOME="$TOMCAT_HOME"
export CATALINA_BASE="$TOMCAT_HOME"
# VM args mirror the IntelliJ "Tomcat 10.1.16" run config.
# disable-parameterstore suppresses the ssm:GetParametersByPath call that the
# dev role is not authorized for; disable-htdc and
# disable-service-to-service-security match the other dev-only profile flags.
export CATALINA_OPTS="${CATALINA_OPTS:-} \
  -Xms2G -Xmx4G -XX:NewSize=256m -XX:MaxNewSize=256m -XX:+DisableExplicitGC \
  -Dlog4j.fileName=log4j2.dev.xml -Dformatting.skip \
  -Dspring.profiles.active=development,disable-parameterstore,disable-htdc,disable-service-to-service-security"

APP_URL="http://dev.i-ready.com:8080/login/ca"
echo "Starting Tomcat → $APP_URL"
echo "(Use Stop in the OASIS UI to shut it down.)"

# Open the browser once Tomcat is accepting connections (background probe).
# Uses the same URL as the IntelliJ run config. Runs entirely in the background
# and does not affect the foreground Tomcat process.
(
  for _i in $(seq 1 60); do
    sleep 3
    if curl -sf --max-time 2 "http://localhost:8080/" -o /dev/null 2>/dev/null; then
      open "$APP_URL" 2>/dev/null || true
      break
    fi
  done
) &

exec "$TOMCAT_HOME/bin/catalina.sh" run