#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — iready-core setup script
#
# Resolved automatically by the OASIS server for the repo "iready-core"
# (scripts/<repo-name>.sh takes priority over the shared scripts/setup.sh).
#
# Runs the full, non-interactive machine bootstrap (AWS, git, Homebrew, MySQL,
# JDK 17, Maven, Tomcat, Ant, IntelliJ, Workbench, Node, shell + host config),
# then configures and builds iready-core in the cloned working tree. This is the
# OASIS port of the original iready-dev-setup.sh + environment-setup.sh +
# finish-setup-post-manual-steps.sh, with the manual/interactive steps removed.
#
# Usage (called by server): bash scripts/iready-core.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

CLONE_DIR="${1:?Usage: iready-core.sh <clone_dir>}"
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
DEVSETUP_DIR="$SCRIPT_DIR/iready-dev-setup"

# Mirror all output to a tail-able log file while still streaming to the UI.
# stdout and stderr are tee'd separately so the server's bash -x xtrace (on
# stderr) is preserved for the live step labels.
DL_RUN_LOG="${OASIS_RUN_LOG:-$HOME/Library/Logs/iready-oasis/iready-core-setup.log}"
mkdir -p "$(dirname "$DL_RUN_LOG")" 2>/dev/null || true
: > "$DL_RUN_LOG" 2>/dev/null || true
exec >  >(tee -a "$DL_RUN_LOG")
exec 2> >(tee -a "$DL_RUN_LOG" >&2)

# Shared helpers (notify / sudo priming / util vars like USERNAME, ARCHITECTURE).
# shellcheck source=/dev/null
. "$SCRIPT_DIR/lib/oasis-common.sh"
for u in "$DEVSETUP_DIR"/util/*.sh; do . "$u"; done

ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
warn() { echo "[$(date '+%H:%M:%S')] ⚠ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

dl_log "iready-core setup starting — clone dir: $CLONE_DIR"

# Acquire admin rights once (GUI dialog) before the bootstrap needs them.
dl_prime_sudo || fail "Administrator access is required for iready-core setup."

# ── Step 1: Full machine toolchain bootstrap ───────────────────────────────
dl_notify "i-Ready setup" "Installing the developer toolchain — this can take a while."
bash "$DEVSETUP_DIR/bootstrap.sh" || fail "Toolchain bootstrap failed."
# Privileged install phase is done — drop the cached password from the env so it
# isn't inherited by the Maven build below. sudo's warm timestamp covers any
# remaining privileged calls.
unset OASIS_SUDO_PW
ok "Toolchain bootstrap complete"

# Make the freshly-installed tools available to this shell for the build.
_zsh_env=$(zsh -lc 'echo PATH="$PATH"; echo JAVA_HOME="${JAVA_HOME:-}"' 2>/dev/null) \
  && eval "$_zsh_env" 2>/dev/null || true
export JAVA_HOME="${JAVA_HOME:-/Library/Java/JavaVirtualMachines/openjdk.jdk/Contents/Home}"
MYSQL_BIN="/usr/local/opt/mysql@8.0/bin"
[[ "$ARCHITECTURE" = "$M1" ]] && MYSQL_BIN="/opt/homebrew/opt/mysql@8.0/bin"
export PATH="$JAVA_HOME/bin:$HOME/dev/tools/apache-maven/bin:$HOME/dev/tools/apache-tomcat-10.1.16/bin:$HOME/dev/tools/apache-ant/bin:$MYSQL_BIN:/opt/homebrew/bin:/usr/local/bin:$PATH"

# ── Step 2: GitHub identity (non-interactive) ──────────────────────────────
GH_EMAIL="$(git config user.email 2>/dev/null || true)"
if [ -z "$GH_EMAIL" ]; then
    GH_EMAIL="${OASIS_GH_EMAIL:-$(whoami)@cainc.com}"
    git config --global user.email "$GH_EMAIL"
    ok "Set git user.email to $GH_EMAIL"
fi
[ -z "$(git config user.name 2>/dev/null || true)" ] && git config --global user.name "${GH_EMAIL%@*}"

# ── Step 3: env.properties ─────────────────────────────────────────────────
RESOURCES_FOLDER="$CLONE_DIR/IReadyPlatform/util/src/test/resources"
if [ -f "$RESOURCES_FOLDER/env.template.properties" ]; then
    cp "$RESOURCES_FOLDER/env.template.properties" "$RESOURCES_FOLDER/env.properties"
    add_data_to_file "$DEVSETUP_DIR/additions/env.properties_additions.txt" "$RESOURCES_FOLDER/env.properties"
    ok "env.properties configured"
else
    warn "env.template.properties not found at $RESOURCES_FOLDER — skipping env.properties"
fi

# ── Step 4: Refresh dashboard/capub versions ───────────────────────────────
eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null)" || true
if [ -f "$CLONE_DIR/scripts/update-envs.js" ]; then
    node "$CLONE_DIR/scripts/update-envs.js" || warn "update-envs.js failed (continuing)"
fi

# ── Step 5: build.properties ───────────────────────────────────────────────
if [ -f "$CLONE_DIR/build.properties.template" ]; then
    cp "$CLONE_DIR/build.properties.template" "$CLONE_DIR/build.properties"
    add_data_to_file "$DEVSETUP_DIR/additions/build.properties_additions.txt" "$CLONE_DIR/build.properties"
    replace_in_file "USERNAME" "$USERNAME" "$CLONE_DIR/build.properties"
    ok "build.properties configured"
else
    warn "build.properties.template not found — skipping build.properties"
fi

# ── Step 6: Build iready-core (tests skipped) ──────────────────────────────
dl_notify "i-Ready setup" "Building iready-core (Maven, skipping tests)…"
dl_log "Starting to build iready-core"
if (
    cd "$CLONE_DIR" || exit 1
    # Create databases/users/githooks; -U avoids stale snapshots. Tests are
    # skipped (no `mvn verify` test phase) for a faster setup build.
    mvn -U clean install -DskipTests=true -Pdrop-dbs,create-users,rc-unix,init-githooks
); then
    ok "Built iready-core"
else
    fail "iready-core was unable to be built"
fi

# ── Step 7: IntelliJ run configurations ────────────────────────────────────
mkdir -pv "$CLONE_DIR/.run"
cp "$DEVSETUP_DIR/settings/Tomcat10-iready.run.xml" "$CLONE_DIR/.run/Tomcat10-iready.run.xml"
cp "$DEVSETUP_DIR/settings/JUnit-iready.run.xml"    "$CLONE_DIR/.run/JUnit-iready.run.xml"
ok "IntelliJ run configurations installed"

# ── Step 8: Open in IntelliJ ───────────────────────────────────────────────
if [[ -n "${INTELLIJ_PATH:-}" && -x "${INTELLIJ_PATH}" ]]; then
    dl_log "Opening in IntelliJ IDEA…"
    # Detach stdio + disown so the IDE doesn't hold the server's output pipe open
    # (which would stall the job at "complete" forever).
    "${INTELLIJ_PATH}" "$CLONE_DIR" >/dev/null 2>&1 &
    disown
fi

ok "iready-core setup complete"
