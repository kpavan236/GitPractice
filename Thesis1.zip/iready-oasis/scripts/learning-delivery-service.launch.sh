#!/usr/bin/env bash
# oasis-launch-label: Run
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — learning-delivery-service launch script
#
# 1. Kills any existing Spring Boot + Vite instances
# 2. Starts LearningDeliveryApplication (Spring Boot, port 8787)
#      Active profiles : text-logs,local,local-content-fetcher
#      JVM args        : -Duser.timezone=UTC
#      Log file        : ~/Desktop/LDS_logs/logs.txt
# 3. Starts the Vite dev server (BROWSER=none npm run dev, port 18787)
#      BROWSER=none suppresses Vite's auto-open so we control exactly one open.
#      Log file        : ~/Desktop/LDS_logs/ui-dev.log
# 4. Waits for both ports, opens the UI once, then waits for either process
#    to exit. While waiting the OASIS button shows "Stop" (red). Clicking
#    Stop sends SIGTERM to the whole process group, which kills Java + Vite and
#    returns the button to "Run" (green).
#
# NOTE: Java and Vite are started with explicit fd redirections (</dev/null >>)
# so they do NOT inherit the OASIS pipe fds. This means the pipe stays open
# only as long as this script itself is alive — proc.on('close') fires correctly
# when the script exits.
#
# Requires the JAR to already exist at core/target/ (run Setup first).
# Usage (called by server): bash scripts/learning-delivery-service.launch.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CLONE_DIR="${1:?Usage: learning-delivery-service.launch.sh <clone_dir>}"
cd "$CLONE_DIR"

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
fail() { echo "[$(date '+%H:%M:%S')] ✗ $*" >&2; exit 1; }

log "Starting learning-delivery-service…"

command -v java >/dev/null || fail "Java not found. Set JAVA_HOME and ensure java is on PATH."
command -v npm  >/dev/null || fail "npm not found. Install Node.js to start the UI dev server."

# ── Kill any existing Spring Boot instance ────────────────────────────────
if pgrep -f "LearningDeliveryApplication" >/dev/null 2>&1; then
  log "Stopping existing Spring Boot instance…"
  pkill -f "LearningDeliveryApplication" 2>/dev/null || true
  for i in $(seq 1 10); do
    pgrep -f "LearningDeliveryApplication" >/dev/null 2>&1 || break
    sleep 1
  done
  ok "Previous Spring Boot instance stopped"
fi

# ── Kill any existing Vite dev server on port 18787 ───────────────────────
EXISTING_VITE=$(lsof -ti tcp:18787 2>/dev/null || true)
if [[ -n "$EXISTING_VITE" ]]; then
  log "Stopping existing Vite dev server (PID $EXISTING_VITE)…"
  kill "$EXISTING_VITE" 2>/dev/null || true
  sleep 1
  ok "Previous Vite instance stopped"
fi

# ── Resolve JAR ───────────────────────────────────────────────────────────
JAR=$(find core/target -maxdepth 1 \
  -name "learning-delivery-service-core*.jar" \
  ! -name "*-sources.jar" \
  ! -name "*-tests.jar" \
  2>/dev/null | sort | tail -1) || true

[[ -n "$JAR" ]] || fail "No JAR found in core/target — run Setup first."

LOG_DIR="$HOME/Desktop/LDS_logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/logs.txt"

log "JAR:      $JAR"
log "Profiles: text-logs,local,local-content-fetcher"
log "Log file: $LOG_FILE"

> "$LOG_FILE"

# ── Start Spring Boot in background ──────────────────────────────────────
# </dev/null + >> redirection: stdin closed, stdout+stderr go to log file —
# Java never touches the OASIS pipe fds.
java \
  -Duser.timezone=UTC \
  -Dspring.profiles.active=text-logs,local,local-content-fetcher \
  -jar "$JAR" </dev/null >> "$LOG_FILE" 2>&1 &
JAVA_PID=$!
log "JVM started (PID $JAVA_PID)"

# ── Wait until Spring Boot port 8787 is ready ────────────────────────────
STARTED=0
for i in $(seq 1 120); do
  if nc -z localhost 8787 2>/dev/null; then
    STARTED=1; break
  fi
  kill -0 "$JAVA_PID" 2>/dev/null || fail "JVM exited unexpectedly — check $LOG_FILE for details"
  sleep 1
done
[[ $STARTED -eq 1 ]] || fail "LearningDeliveryApplication did not start within 120 s — check $LOG_FILE"
ok "LearningDeliveryApplication is running (PID $JAVA_PID)"

# ── Start Vite UI dev server in background ────────────────────────────────
# Vite ignores the BROWSER env var — it calls the macOS `open` binary directly
# when server.open:true is set in vite.config.js. We shadow `open` with a no-op
# script placed first on PATH so every internal `open` call becomes harmless.
# Our own single explicit open below uses the full path /usr/bin/open to bypass
# the shadow. The temp dir is cleaned up on script exit.
_FAKE_BIN="$(mktemp -d /tmp/oasis-XXXXXX)"
printf '#!/bin/bash\n' > "$_FAKE_BIN/open"
chmod +x "$_FAKE_BIN/open"
trap 'rm -rf "$_FAKE_BIN"' EXIT

log "Starting Vite UI dev server…"
cd "$CLONE_DIR/ui"
PATH="$_FAKE_BIN:$PATH" npm run dev </dev/null >> "$LOG_DIR/ui-dev.log" 2>&1 &
VITE_PID=$!
cd "$CLONE_DIR"
log "Vite started (PID $VITE_PID)"

# ── Wait until Vite port 18787 is ready ──────────────────────────────────
UI_STARTED=0
for i in $(seq 1 60); do
  if nc -z localhost 18787 2>/dev/null; then
    UI_STARTED=1; break
  fi
  kill -0 "$VITE_PID" 2>/dev/null || fail "Vite dev server exited unexpectedly — check $LOG_DIR/ui-dev.log"
  sleep 1
done
[[ $UI_STARTED -eq 1 ]] || fail "Vite dev server did not start within 60 s — check $LOG_DIR/ui-dev.log"
ok "Vite UI dev server is running (PID $VITE_PID)"

ok "learning-delivery-service is fully up"
ok "UI:      http://localhost:8787/ui"
ok "Swagger: http://localhost:8787/swagger-ui/index.html"

# Open the UI exactly once — full path bypasses the no-op 'open' shadow above.
/usr/bin/open "http://localhost:8787/ui" 2>/dev/null || true

# ── Stay alive so OASIS shows the Stop button ────────────────────────
# Blocking here keeps the OASIS process alive, which means:
#   • The button stays red ("Stop") for as long as the service is running.
#   • Clicking Stop sends SIGTERM to the process group, killing Java + Vite.
#   • When either service exits on its own, wait returns and the button resets.
# Java and Vite already redirect their own fds — the OASIS pipe is held
# open only by this script, so EOF arrives correctly when the script exits.
#
# macOS ships bash 3.2 (non-interactive). SIGTERM received during 'wait' does
# not automatically run the EXIT trap in that context. The TERM trap converts
# the signal into an explicit 'exit', which does fire EXIT. The EXIT trap then
# kills Java + Vite by PID so they don't linger after the Stop button is clicked.
trap 'kill "$JAVA_PID" "$VITE_PID" 2>/dev/null; rm -rf "$_FAKE_BIN"' EXIT
trap 'exit 143' TERM
wait $JAVA_PID $VITE_PID || true
log "learning-delivery-service has stopped"
