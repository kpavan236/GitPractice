#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# i-Ready OASIS — Example repo-specific setup script
#
# Place this file at:  scripts/<your-repo-name>.sh   (preferred, flat form)
#                 or:  scripts/<your-repo-name>/setup.sh   (legacy folder form)
# It will be called automatically by the OASIS server when setting up
# a repo with that name, taking priority over the shared/default setup scripts.
#
# Usage (called by server): bash scripts/<repo-name>.sh <clone_dir>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CLONE_DIR="${1:?Usage: setup.sh <clone_dir>}"
cd "$CLONE_DIR"

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
ok()   { echo "[$(date '+%H:%M:%S')] ✓ $*"; }
warn() { echo "[$(date '+%H:%M:%S')] ⚠ $*"; }

log "Custom setup for: $(basename $CLONE_DIR)"

# ── Step 1: Maven build ───────────────────────────────────────────────────
MVN_ARGS="${MAVEN_ARGS:--DskipTests}"
log "Running: mvn clean install $MVN_ARGS"
mvn clean install $MVN_ARGS
ok "Maven build done"

# ── Step 2: Copy config ───────────────────────────────────────────────────
if [[ -f "src/main/resources/application-local.properties.example" ]]; then
  cp src/main/resources/application-local.properties.example \
     src/main/resources/application-local.properties
  ok "Local properties configured"
fi

# ── Step 3: Write extra env vars to .env ─────────────────────────────────
if [[ -n "${EXTRA_ENV:-}" ]]; then
  printf '%s\n' "$EXTRA_ENV" > .env
  ok ".env written"
fi

# ── Step 4: Open in IntelliJ ──────────────────────────────────────────────
if [[ -n "${INTELLIJ_PATH:-}" && -x "${INTELLIJ_PATH}" ]]; then
  log "Opening in IntelliJ IDEA…"
  "${INTELLIJ_PATH}" "$CLONE_DIR" &
  ok "IntelliJ launched"
fi

ok "Setup complete"
