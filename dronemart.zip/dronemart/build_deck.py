"""
Generate DroneMart investor pitch deck (12 slides + appendix).
Produces dronemart_pitch.pptx in the project directory.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from copy import deepcopy

# ── Brand palette ──────────────────────────────────────────────
GREEN_DARK   = RGBColor(0x08, 0x50, 0x41)  # primary
GREEN        = RGBColor(0x1D, 0x9E, 0x75)  # accent
ORANGE       = RGBColor(0xEF, 0x9F, 0x27)
CREAM        = RGBColor(0xF5, 0xF5, 0xF0)
TEXT_DARK    = RGBColor(0x1A, 0x1A, 0x1A)
TEXT_MUTED   = RGBColor(0x66, 0x66, 0x66)
WHITE        = RGBColor(0xFF, 0xFF, 0xFF)
NAVY         = RGBColor(0x0C, 0x44, 0x7C)
RED_SOFT     = RGBColor(0xA3, 0x2D, 0x2D)

# ── Presentation setup (16:9) ──────────────────────────────────
prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
SW, SH = prs.slide_width, prs.slide_height

BLANK_LAYOUT = prs.slide_layouts[6]

# ── Helpers ────────────────────────────────────────────────────
def add_bg(slide, color=CREAM):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, SH)
    shape.fill.solid(); shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    shape.shadow.inherit = False
    return shape

def add_text(slide, text, x, y, w, h, *, size=18, bold=False, color=TEXT_DARK,
             font='Helvetica Neue', align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line_spacing=1.15):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Emu(0); tf.margin_top = tf.margin_bottom = Emu(0)
    lines = text.split('\n') if isinstance(text, str) else text
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align; p.line_spacing = line_spacing
        r = p.add_run(); r.text = line
        r.font.name = font; r.font.size = Pt(size); r.font.bold = bold
        r.font.color.rgb = color
    return tb

def add_bullets(slide, items, x, y, w, h, *, size=16, color=TEXT_DARK, font='Helvetica Neue',
                bullet_color=GREEN, line_spacing=1.4):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0); tf.margin_top = tf.margin_bottom = Emu(0)
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.line_spacing = line_spacing
        # bullet bullet character
        r1 = p.add_run(); r1.text = '●  '
        r1.font.name = font; r1.font.size = Pt(size); r1.font.color.rgb = bullet_color; r1.font.bold = True
        r2 = p.add_run(); r2.text = item
        r2.font.name = font; r2.font.size = Pt(size); r2.font.color.rgb = color
    return tb

def add_rect(slide, x, y, w, h, color, *, line=None, radius=False):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, x, y, w, h
    )
    shape.fill.solid(); shape.fill.fore_color.rgb = color
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line; shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    if radius:
        # tighter corner radius
        shape.adjustments[0] = 0.12
    return shape

def add_header(slide, num, total, title, subtitle=None):
    """Page-number chip + bold title."""
    label = f"{num:02d}" if isinstance(num, int) else str(num)
    add_rect(slide, Inches(0.5), Inches(0.45), Inches(0.5), Inches(0.28), GREEN_DARK, radius=True)
    add_text(slide, label, Inches(0.5), Inches(0.45), Inches(0.5), Inches(0.28),
             size=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    add_text(slide, f"{num} / {total}", Inches(1.05), Inches(0.5), Inches(1.0), Inches(0.25),
             size=10, color=TEXT_MUTED)
    add_text(slide, title, Inches(0.5), Inches(0.9), Inches(12), Inches(0.7),
             size=34, bold=True, color=GREEN_DARK)
    if subtitle:
        add_text(slide, subtitle, Inches(0.5), Inches(1.6), Inches(12), Inches(0.5),
                 size=15, color=TEXT_MUTED)

def add_footer(slide, text="DroneMart · Confidential"):
    add_text(slide, text, Inches(0.5), Inches(7.05), Inches(12), Inches(0.3),
             size=9, color=TEXT_MUTED)

def add_notes(slide, notes):
    slide.notes_slide.notes_text_frame.text = notes

def new_slide():
    s = prs.slides.add_slide(BLANK_LAYOUT)
    add_bg(s, CREAM)
    return s

TOTAL = 12

# ──────────────────────────────────────────────────────────────
# SLIDE 1 — Cover / Vision
# ──────────────────────────────────────────────────────────────
s = prs.slides.add_slide(BLANK_LAYOUT)
add_bg(s, GREEN_DARK)
# orange accent stripe
add_rect(s, 0, Inches(7.1), SW, Inches(0.4), ORANGE)

# Big logo emoji
add_text(s, "🚁", Inches(0.6), Inches(0.6), Inches(2), Inches(1.5),
         size=72, color=WHITE)
add_text(s, "DroneMart", Inches(0.6), Inches(1.9), Inches(8), Inches(1),
         size=64, bold=True, color=WHITE)
add_text(s, "15-minute drone-delivered groceries for urban India.",
         Inches(0.6), Inches(3.2), Inches(12), Inches(0.6),
         size=24, color=ORANGE)
add_text(s, "We're building a drone-powered last-mile platform that delivers groceries to\nbalconies and gated societies in under 15 minutes — at half the cost of 2-wheelers.",
         Inches(0.6), Inches(4.0), Inches(11), Inches(1.6),
         size=18, color=WHITE)
add_text(s, "Seed Round · ₹2-4 Cr · Bangalore",
         Inches(0.6), Inches(6.0), Inches(8), Inches(0.5),
         size=14, color=ORANGE, bold=True)
add_text(s, "[Founder Name] · [email] · [phone]",
         Inches(0.6), Inches(6.5), Inches(8), Inches(0.4),
         size=12, color=WHITE)
add_notes(s, "30-second opener. Don't read the slide — say something like: 'We're DroneMart. "
             "We deliver groceries by drone in 15 minutes. Today I'll show you a working "
             "system that already does this end-to-end in simulation, and explain how we get to "
             "real flights in 12 months and a defensible business in 24.' Then move to the demo "
             "video on slide 4 fast — don't get bogged down in the deck.")

# ──────────────────────────────────────────────────────────────
# SLIDE 2 — Problem
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 2, TOTAL, "The last meter is broken.",
           "Quick-commerce solved 15-minute delivery to your gate. Nobody solved the gate-to-door problem.")

# Three pain points as cards
cards = [
    ("₹40+", "per delivery cost", "Bike + rider + fuel + insurance + parking.\nUnit economics still negative at ₹10-30 AOV."),
    ("12 min", "lost at the gate", "Riders wait at apartment security, take lifts,\nfind unit numbers. The 'last 50 metres' is the bottleneck."),
    ("60% of orders", "are repetitive", "Same 8-10 households reorder daily.\nSame buildings, same items — perfectly batchable airspace, wasted on ground."),
]
y = Inches(2.6); cw = Inches(4.0); gap = Inches(0.2)
for i, (big, lbl, body) in enumerate(cards):
    x = Inches(0.5 + i * (cw.inches + gap.inches))
    add_rect(s, x, y, cw, Inches(3.6), WHITE, radius=True)
    add_text(s, big, x, y + Inches(0.4), cw, Inches(1.0),
             size=46, bold=True, color=GREEN, align=PP_ALIGN.CENTER)
    add_text(s, lbl, x, y + Inches(1.4), cw, Inches(0.4),
             size=14, color=TEXT_MUTED, align=PP_ALIGN.CENTER, bold=True)
    add_text(s, body, x + Inches(0.3), y + Inches(2.0), cw - Inches(0.6), Inches(1.4),
             size=12, color=TEXT_DARK, align=PP_ALIGN.CENTER, line_spacing=1.4)

add_text(s, "Quick-commerce is ₹30,000 Cr by 2026. Margins are still red.\nThe winning model needs different physics.",
         Inches(0.5), Inches(6.3), Inches(12), Inches(0.7),
         size=14, color=GREEN_DARK, bold=True, align=PP_ALIGN.CENTER)

add_footer(s)
add_notes(s, "Stay 60 seconds max. Don't recite the cards. Say: 'BlinkIt/Zepto/Instamart "
             "solved gate-to-customer in 15 minutes. But that 15 includes ~12 minutes of human "
             "labour at the gate and unit. That's where the unit economics die — and where drones "
             "win, because they go gate-to-balcony in 90 seconds.'")

# ──────────────────────────────────────────────────────────────
# SLIDE 3 — Solution
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 3, TOTAL, "Drone-delivered groceries to your balcony.",
           "From the partner supermarket's roof to your apartment in under 15 minutes.")

# Flow diagram: customer → cloud → supermarket → drone → balcony
labels = ["🛒 Customer\norders in-app", "☁️ DroneMart\ncloud platform",
          "🏪 Partner\nsupermarket", "🚁 Autonomous\ndrone flight",
          "🏠 Balcony /\nmarked drop zone"]
bw, gap = Inches(2.20), Inches(0.18)
total_w = bw.inches * 5 + gap.inches * 4
start_x = (13.333 - total_w) / 2
y = Inches(2.85)
for i, txt in enumerate(labels):
    x = Inches(start_x + i * (bw.inches + gap.inches))
    color = [GREEN, GREEN_DARK, GREEN, GREEN_DARK, ORANGE][i]
    add_rect(s, x, y, bw, Inches(1.6), color, radius=True)
    add_text(s, txt, x, y, bw, Inches(1.6),
             size=13, bold=True, color=WHITE, align=PP_ALIGN.CENTER,
             anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.25)
    # arrow between cards (skip after last)
    if i < 4:
        ax = Inches(start_x + (i + 1) * bw.inches + i * gap.inches)
        add_text(s, "▸", ax, y + Inches(0.5), gap, Inches(0.6),
                 size=20, bold=True, color=GREEN_DARK, align=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)

# Three sub-bullets
add_text(s, "What makes it work", Inches(0.5), Inches(5.0), Inches(12), Inches(0.4),
         size=14, bold=True, color=GREEN_DARK)
add_bullets(s, [
    "Customer app shows live drone POV + OSM map + ETA. Tap to unlock the box on landing.",
    "Supermarket portal sees every order, dispatches drones with one click, watches the live feed.",
    "Cloud platform handles routing, battery checks, return-to-base, fleet ops, and compliance logs.",
], Inches(0.5), Inches(5.5), Inches(12.3), Inches(1.6), size=14)

add_footer(s)
add_notes(s, "60 seconds. The simplicity here is the message — don't over-engineer the explanation. "
             "Investors don't care HOW the drone flies; they care that customer → supermarket → drone → "
             "balcony is one closed loop with software at every step. Lead them straight into the demo.")

# ──────────────────────────────────────────────────────────────
# SLIDE 4 — Demo (the killer slide)
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 4, TOTAL, "Live demo — already built.",
           "A working multi-actor system: customer + supermarket + admin + simulated drone.")

# Big "play" frame as the demo placeholder
add_rect(s, Inches(0.5), Inches(2.4), Inches(7.5), Inches(4.2), GREEN_DARK, radius=True)
add_text(s, "▶", Inches(0.5), Inches(2.4), Inches(7.5), Inches(4.2),
         size=120, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
add_text(s, "[Embed 90-second demo video here]", Inches(0.5), Inches(6.2), Inches(7.5), Inches(0.4),
         size=10, color=TEXT_MUTED, align=PP_ALIGN.CENTER)

# Bullet column on the right
add_text(s, "What you'll see", Inches(8.4), Inches(2.4), Inches(4.5), Inches(0.4),
         size=14, bold=True, color=GREEN_DARK)
add_bullets(s, [
    "Customer places order, lands on live tracking screen with real OSM map.",
    "Supermarket dispatches drone with one click. Order moves through 10 status states.",
    "Drone POV picture-in-picture with HUD: altitude, speed, battery, ETA.",
    "Tap to unlock the box. ✅ Delivered.",
    "Admin sees the whole platform live — every event, every status.",
], Inches(8.4), Inches(2.85), Inches(4.5), Inches(3.5), size=12, line_spacing=1.35)

add_text(s, "Built in 4 weeks · 3 working portals · 10-state order lifecycle · real WebSocket telemetry",
         Inches(0.5), Inches(6.7), Inches(12), Inches(0.4),
         size=12, color=ORANGE, bold=True, align=PP_ALIGN.CENTER)

add_footer(s)
add_notes(s, "THIS IS YOUR STRONGEST SLIDE. Don't talk over the video — play it. 90 seconds is enough. "
             "After the video, pause for 5 seconds. Let them absorb it. Most drone pitches show CGI; "
             "you just showed working software. That alone is rare enough to close the meeting.")

# ──────────────────────────────────────────────────────────────
# SLIDE 5 — Market size
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 5, TOTAL, "₹30,000 Cr market by 2026 — and the unit economics need to change.",
           "We don't need to win quick-commerce. We need to take the share that 2-wheelers can't profitably serve.")

# TAM / SAM / SOM cards
cards = [
    ("TAM", "₹30,000 Cr", "Quick-commerce in India\nby 2026 (RedSeer)"),
    ("SAM", "₹6,000 Cr", "High-rise gated societies\nin top-10 cities"),
    ("SOM", "₹150 Cr", "Bangalore, 2 years\n(50 societies × 200 orders/day)"),
]
y = Inches(2.6); cw = Inches(3.4); gap = Inches(0.3)
total_w = cw.inches * 3 + gap.inches * 2
start_x = (13.333 - total_w) / 2
for i, (tag, big, body) in enumerate(cards):
    x = Inches(start_x + i * (cw.inches + gap.inches))
    add_rect(s, x, y, cw, Inches(3.4), WHITE, radius=True)
    add_text(s, tag, x, y + Inches(0.3), cw, Inches(0.4),
             size=14, bold=True, color=ORANGE, align=PP_ALIGN.CENTER)
    add_text(s, big, x, y + Inches(0.9), cw, Inches(1.0),
             size=40, bold=True, color=GREEN_DARK, align=PP_ALIGN.CENTER)
    add_text(s, body, x, y + Inches(2.1), cw, Inches(1.2),
             size=13, color=TEXT_DARK, align=PP_ALIGN.CENTER, line_spacing=1.35)

add_text(s, "Capture 1% of SOM in Year 2 → ₹1.5 Cr ARR · profitable at 40 deliveries/drone/day",
         Inches(0.5), Inches(6.4), Inches(12), Inches(0.5),
         size=14, bold=True, color=GREEN_DARK, align=PP_ALIGN.CENTER)

add_footer(s)
add_notes(s, "Be honest about market sizing. Investors will do this math themselves. The TAM number is "
             "RedSeer/Bain — cite the source. SOM is what matters most: 'In our first city, in 2 years, "
             "with 50 society partnerships, we can do ₹150 Cr in GMV.' That's a number you have to defend.")

# ──────────────────────────────────────────────────────────────
# SLIDE 6 — Why now
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 6, TOTAL, "Why now — this didn't work in 2017.",
           "Four shifts in the last 36 months make consumer drone delivery economically and legally viable for the first time.")

shifts = [
    ("📜", "Regulation opened up",
     "DGCA Drone Rules 2021 + DigitalSky portal made BVLOS approvable.\n"
     "Drone Shakti scheme + ₹120 Cr PLI for drones (FY24)."),
    ("🔋", "Battery density doubled",
     "Li-ion energy density up ~2× since 2019 (300 → 600 Wh/kg).\n"
     "Round-trip range that was 4 km in 2017 is 10 km today."),
    ("📡", "5G covers Tier-1 India",
     "Sub-100ms uplink latency now reliable in 8 cities.\n"
     "Live HD video from drone to customer phone became possible."),
    ("📉", "Quick-commerce is at \"cost-cutting\" phase",
     "BlinkIt/Zepto/Instamart all chasing positive unit economics.\n"
     "First time they'll PAY for cheaper last-mile, not subsidise it."),
]
y = Inches(2.5); cw = Inches(6.0); ch = Inches(2.05)
for i, (icon, title, body) in enumerate(shifts):
    col = i % 2; row = i // 2
    x = Inches(0.5 + col * 6.4)
    yy = y + Inches(row * 2.3)
    add_rect(s, x, yy, cw, ch, WHITE, radius=True)
    add_text(s, icon, x + Inches(0.3), yy + Inches(0.3), Inches(0.7), Inches(0.7),
             size=28, color=GREEN_DARK)
    add_text(s, title, x + Inches(1.1), yy + Inches(0.3), cw - Inches(1.3), Inches(0.5),
             size=16, bold=True, color=GREEN_DARK)
    add_text(s, body, x + Inches(1.1), yy + Inches(0.9), cw - Inches(1.3), Inches(1.1),
             size=12, color=TEXT_DARK, line_spacing=1.35)

add_footer(s)
add_notes(s, "Be specific with dates. 'Drone Rules 2021', 'Drone Shakti scheme', 'DigitalSky portal'. "
             "If investors have seen 2017's drone hype crash, this slide tells them why this cycle is different. "
             "Don't hedge — be confident on the regulatory tailwind.")

# ──────────────────────────────────────────────────────────────
# SLIDE 7 — Business model
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 7, TOTAL, "Three revenue streams. Profitable per-flight by month 18.",
           None)

# Three revenue stream cards
revs = [
    ("Per-delivery fee",
     "₹15–20 / delivery",
     "Charged to the supermarket partner.\n"
     "Bundled into their fulfilment cost.\n"
     "Below their current ₹35-50 bike cost."),
    ("Platform SaaS",
     "₹25-50k / supermarket / month",
     "Fleet management, order routing,\n"
     "live ops dashboard, compliance logs,\n"
     "DigitalSky NPNT integration."),
    ("Drone-as-a-Service",
     "₹3-5L / drone / year",
     "We own + maintain + insure the fleet.\n"
     "Supermarket leases by usage.\n"
     "Captures most of the unit economics."),
]
y = Inches(2.4); cw = Inches(4.0); gap = Inches(0.2)
for i, (title, price, body) in enumerate(revs):
    x = Inches(0.5 + i * (cw.inches + gap.inches))
    add_rect(s, x, y, cw, Inches(3.4), GREEN_DARK, radius=True)
    add_text(s, title, x + Inches(0.3), y + Inches(0.3), cw - Inches(0.6), Inches(0.5),
             size=14, bold=True, color=ORANGE)
    add_text(s, price, x + Inches(0.3), y + Inches(0.85), cw - Inches(0.6), Inches(0.8),
             size=22, bold=True, color=WHITE)
    add_text(s, body, x + Inches(0.3), y + Inches(1.8), cw - Inches(0.6), Inches(1.5),
             size=12, color=WHITE, line_spacing=1.4)

# Unit economics box
add_rect(s, Inches(0.5), Inches(6.05), Inches(12.33), Inches(1.05), WHITE, radius=True)
add_text(s, "Unit economics target", Inches(0.7), Inches(6.15), Inches(4), Inches(0.4),
         size=12, bold=True, color=GREEN_DARK)
add_text(s, "Revenue: ₹20/delivery     Cost: ₹14    Gross margin: 30%    Break-even: 40 deliveries/drone/day",
         Inches(0.7), Inches(6.55), Inches(12), Inches(0.4),
         size=13, color=TEXT_DARK, bold=True)

add_footer(s)
add_notes(s, "If they don't believe the unit economics, nothing else matters. Be ready to defend every "
             "number. ₹14 cost = drone amortization (₹3) + battery cycles (₹2) + cellular (₹1) + "
             "maintenance (₹2) + insurance (₹2) + operator (₹2) + misc (₹2). Have this breakdown in your "
             "appendix.")

# ──────────────────────────────────────────────────────────────
# SLIDE 8 — Traction
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 8, TOTAL, "Where we are — and the next 12 milestones.",
           None)

# Timeline (4 columns: Done, 3 mo, 6 mo, 12 mo)
phases = [
    ("✅ DONE",
     "Working software stack",
     ["Customer + supermarket + admin portals",
      "Live OSM map + drone POV streaming",
      "10-state order lifecycle, WebSocket telemetry",
      "End-to-end COD flow with unlock-box logic"],
     GREEN),
    ("Q1 ── Pilot prep",
     "3 months",
     ["3-5 supermarket LOIs signed",
      "DJI M30T + custom payload box bench prototype",
      "MAVLink-to-MQTT bridge replacing simulator",
      "Pilot site identified (1 Bangalore society)"],
     ORANGE),
    ("Q2-Q3 ── First flights",
     "6 months",
     ["BVLOS corridor application filed",
      "100 supervised flights in closed airspace",
      "Insurance + operator partnership locked",
      "First paid customer delivery"],
     GREEN_DARK),
    ("Q4 ── Scale-out",
     "12 months",
     ["1 society live, 100 deliveries/day",
      "₹15 L MRR run-rate",
      "Unit economics validated",
      "Series A-ready"],
     NAVY),
]
y = Inches(2.5); cw = Inches(3.0); gap = Inches(0.15)
total_w = cw.inches * 4 + gap.inches * 3
start_x = (13.333 - total_w) / 2
for i, (label, sub, items, color) in enumerate(phases):
    x = Inches(start_x + i * (cw.inches + gap.inches))
    # Header band
    add_rect(s, x, y, cw, Inches(0.8), color, radius=True)
    add_text(s, label, x, y + Inches(0.05), cw, Inches(0.35),
             size=12, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(s, sub, x, y + Inches(0.4), cw, Inches(0.3),
             size=10, color=WHITE, align=PP_ALIGN.CENTER)
    # Body
    add_rect(s, x, y + Inches(0.85), cw, Inches(3.5), WHITE, radius=True)
    add_bullets(s, items, x + Inches(0.2), y + Inches(1.0), cw - Inches(0.4), Inches(3.3),
                size=10.5, line_spacing=1.4, bullet_color=color)

add_footer(s)
add_notes(s, "The 'DONE' column is your moat. Most pitching teams have slides. You have a working system. "
             "Lean on it. For the future columns: be HONEST. Don't promise '10 cities in year 1'. "
             "Investors trust founders who under-promise and over-deliver. The 100-deliveries/day in one "
             "society number is achievable and defendable.")

# ──────────────────────────────────────────────────────────────
# SLIDE 9 — Competition
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 9, TOTAL, "Competition — and where we differ.",
           "Eight funded drone players in India. None of them is consumer-grocery-first with B2B2C software.")

# Comparison table
headers = ["Player", "Focus", "Customer", "Software Stack", "Status"]
rows = [
    ["Skye Air",        "Medical / B2B logistics", "B2B",        "Custom UTM",      "Live in NCR"],
    ["Garuda Aerospace","Hardware-first",          "Govt + B2B", "Hardware mostly", "Listed"],
    ["TechEagle",       "BVLOS corridors",         "Govt",       "Hardware focus",  "Pilots only"],
    ["ANRA",            "UTM platform",            "Enterprise", "UTM",             "Live infrastructure"],
    ["DroneMart (us)",  "Consumer grocery",        "B2B2C",      "End-to-end SaaS", "Software live, hw in 3 mo"],
]
y = Inches(2.5); col_widths = [Inches(2.4), Inches(2.6), Inches(1.8), Inches(2.8), Inches(2.6)]
row_h = Inches(0.55)

# Header row
x = Inches(0.5)
for i, h in enumerate(headers):
    add_rect(s, x, y, col_widths[i], row_h, GREEN_DARK)
    add_text(s, h, x + Inches(0.15), y + Inches(0.1), col_widths[i] - Inches(0.3), Inches(0.4),
             size=12, bold=True, color=WHITE)
    x += col_widths[i]

# Body rows
for r_idx, row in enumerate(rows):
    yy = y + Inches(0.6 + r_idx * 0.6)
    is_us = "DroneMart" in row[0]
    bg = ORANGE if is_us else (WHITE if r_idx % 2 == 0 else RGBColor(0xFA, 0xFA, 0xF5))
    x = Inches(0.5)
    for i, cell in enumerate(row):
        add_rect(s, x, yy, col_widths[i], row_h, bg)
        fg = WHITE if is_us else TEXT_DARK
        bold = is_us
        add_text(s, cell, x + Inches(0.15), yy + Inches(0.13), col_widths[i] - Inches(0.3), Inches(0.4),
                 size=11.5, color=fg, bold=bold)
        x += col_widths[i]

add_text(s,
         "Defensible edge: we own the customer & supermarket software experience —\n"
         "the hardware layer is commodity (DJI/Skydio). Whoever wins the consumer interface wins the market.",
         Inches(0.5), Inches(6.3), Inches(12.33), Inches(0.85),
         size=13, color=GREEN_DARK, bold=True, align=PP_ALIGN.CENTER, line_spacing=1.4)

add_footer(s)
add_notes(s, "Don't bash competitors. Acknowledge they exist and they're well-funded. Then own ONE "
             "axis of difference: 'They sell hardware/logistics to enterprises. We're consumer-app-first "
             "with deep supermarket integration.' That's a real strategic difference. Investors fund "
             "differentiation, not 'we're better at everything.'")

# ──────────────────────────────────────────────────────────────
# SLIDE 10 — Tech & moat
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 10, TOTAL, "Our moat is the software stack — not the drone.",
           "DJI / Skydio give everyone the airframe. We own the 4 layers above it.")

# Vertical stack diagram
layers = [
    ("👤", "Customer experience",
     "Live tracking + drone POV + map + unlock UX", ORANGE),
    ("🏪", "Supermarket platform",
     "Order management + dispatch + fleet monitoring", GREEN),
    ("☁️", "Cloud platform",
     "Routing · battery · RTL · WebSocket telemetry · admin", GREEN_DARK),
    ("📡", "MQTT / MAVLink bridge",
     "Drone command + telemetry abstraction", NAVY),
    ("🚁", "Drone hardware (DJI/Skydio)",
     "Commodity. Buy don't build.", TEXT_MUTED),
]
y = Inches(2.5); lh = Inches(0.78)
for i, (icon, title, body, color) in enumerate(layers):
    yy = y + Inches(i * 0.85)
    cw = Inches(8.0)
    add_rect(s, Inches(0.5), yy, cw, lh, color, radius=True)
    add_text(s, icon, Inches(0.7), yy, Inches(0.7), lh,
             size=22, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, title, Inches(1.5), yy + Inches(0.08), Inches(6.2), Inches(0.35),
             size=14, bold=True, color=WHITE)
    add_text(s, body, Inches(1.5), yy + Inches(0.42), Inches(6.2), Inches(0.32),
             size=11, color=WHITE)

# Right column: what's defensible
add_text(s, "Why this stack is defensible", Inches(9.0), Inches(2.5), Inches(4), Inches(0.4),
         size=14, bold=True, color=GREEN_DARK)
add_bullets(s, [
    "18 months ahead of hardware-first competitors on customer UX.",
    "Per-supermarket integration is a network effect — first to onboard wins the corridor.",
    "Live POV + unlock-by-PIN + balcony delivery (V2) is genuinely novel UX.",
    "Compliance logging built in from day one — required for BVLOS approval.",
    "Drone-vendor-agnostic. Switch DJI → Skydio → custom without rewriting the platform.",
], Inches(9.0), Inches(3.0), Inches(4.0), Inches(4.0), size=11.5, line_spacing=1.4)

add_footer(s)
add_notes(s, "If they push 'why can't BlinkIt build this?': answer is (a) by the time it's a priority for "
             "them, you have 100 society partnerships and BVLOS approval, (b) they're optimizing for "
             "their existing 2-wheeler network — drones is a strategic discontinuity they'd rather buy "
             "than build. You're a future acquisition target. That's a feature, not a bug.")

# ──────────────────────────────────────────────────────────────
# SLIDE 11 — Team
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_header(s, 11, TOTAL, "Team", "Founders + advisors. Specific hires we'll make with this round.")

# Founder placeholder
add_rect(s, Inches(0.5), Inches(2.5), Inches(5.8), Inches(3.6), WHITE, radius=True)
add_rect(s, Inches(0.7), Inches(2.7), Inches(1.6), Inches(1.6), GREEN_DARK, radius=True)
add_text(s, "🚁", Inches(0.7), Inches(2.7), Inches(1.6), Inches(1.6),
         size=44, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
add_text(s, "[Founder Name]", Inches(2.5), Inches(2.8), Inches(3.7), Inches(0.5),
         size=18, bold=True, color=GREEN_DARK)
add_text(s, "Founder & CEO", Inches(2.5), Inches(3.25), Inches(3.7), Inches(0.4),
         size=12, color=ORANGE, bold=True)
add_text(s, "[Background: X years at Y company,\nbuilt Z. Or: ex-[brand], shipped P to Q users.]",
         Inches(2.5), Inches(3.65), Inches(3.7), Inches(1.0),
         size=11, color=TEXT_DARK, line_spacing=1.4)
add_text(s, "Built the DroneMart platform end-to-end in 4 weeks (you just saw it).",
         Inches(0.7), Inches(5.1), Inches(5.4), Inches(0.8),
         size=11, color=TEXT_DARK, bold=True, line_spacing=1.4)

# Key hires box
add_rect(s, Inches(6.6), Inches(2.5), Inches(6.2), Inches(3.6), CREAM, radius=True, line=GREEN_DARK)
add_text(s, "Hires with this round", Inches(6.8), Inches(2.65), Inches(6), Inches(0.4),
         size=14, bold=True, color=GREEN_DARK)
add_bullets(s, [
    "Drone hardware lead — ex-DJI / Garuda / TechEagle",
    "Flight ops & compliance head — DGCA-registered RPC, BVLOS experience",
    "Backend engineer #2 — to own MAVLink bridge + cloud ops",
    "Partnerships lead — supermarket BD + society onboarding",
], Inches(6.8), Inches(3.15), Inches(5.8), Inches(2.8), size=11.5, line_spacing=1.5)

# Advisors row
add_text(s, "Advisors (already engaged / target)", Inches(0.5), Inches(6.3), Inches(12), Inches(0.4),
         size=12, bold=True, color=GREEN_DARK)
add_text(s, "[Advisor 1 — drone ops]   ·   [Advisor 2 — quick commerce]   ·   [Advisor 3 — regulatory/legal]",
         Inches(0.5), Inches(6.7), Inches(12), Inches(0.4),
         size=12, color=TEXT_DARK)

add_footer(s)
add_notes(s, "Investors back drone startups for the team, hard. If you're solo, name the advisors and the "
             "first hire. If you don't have a hardware co-founder yet, say so explicitly: 'We're closing "
             "our drone-hardware lead in the next 60 days; here's our shortlist.' That's better than a "
             "fake team slide.")

# ──────────────────────────────────────────────────────────────
# SLIDE 12 — The Ask
# ──────────────────────────────────────────────────────────────
s = new_slide()
add_bg(s, GREEN_DARK)
add_rect(s, 0, Inches(7.1), SW, Inches(0.4), ORANGE)

add_text(s, "12 / 12", Inches(0.5), Inches(0.5), Inches(2), Inches(0.3),
         size=11, color=ORANGE)
add_text(s, "The ask", Inches(0.5), Inches(0.9), Inches(12), Inches(0.9),
         size=44, bold=True, color=WHITE)

# Big number
add_rect(s, Inches(0.5), Inches(2.3), Inches(6.5), Inches(4.0), ORANGE, radius=True)
add_text(s, "₹3 Cr", Inches(0.5), Inches(2.6), Inches(6.5), Inches(1.4),
         size=80, bold=True, color=GREEN_DARK, align=PP_ALIGN.CENTER)
add_text(s, "Seed Round", Inches(0.5), Inches(4.1), Inches(6.5), Inches(0.5),
         size=20, bold=True, color=GREEN_DARK, align=PP_ALIGN.CENTER)
add_text(s, "for 12 months of runway", Inches(0.5), Inches(4.6), Inches(6.5), Inches(0.4),
         size=14, color=GREEN_DARK, align=PP_ALIGN.CENTER)
add_text(s, "Lead: ₹1.5-2 Cr   ·   Open: pre-seed angels / strategic",
         Inches(0.5), Inches(5.4), Inches(6.5), Inches(0.4),
         size=12, color=GREEN_DARK, align=PP_ALIGN.CENTER, bold=True)

# Use of funds
add_text(s, "Use of funds", Inches(7.4), Inches(2.3), Inches(5.5), Inches(0.5),
         size=18, bold=True, color=WHITE)
items = [
    ("40%", "Hardware: drones, payload boxes, ground station, R&D"),
    ("25%", "Team: 4 key hires (drone, compliance, eng, BD)"),
    ("20%", "Pilot ops: insurance, BVLOS application, supermarket onboarding"),
    ("15%", "Working capital & runway buffer"),
]
yy = Inches(2.85)
for pct, label in items:
    add_text(s, pct, Inches(7.4), yy, Inches(1.2), Inches(0.5),
             size=22, bold=True, color=ORANGE)
    add_text(s, label, Inches(8.5), yy + Inches(0.08), Inches(4.5), Inches(0.5),
             size=12, color=WHITE, line_spacing=1.4)
    yy += Inches(0.65)

# Milestone box
add_text(s, "What ₹3 Cr buys",
         Inches(0.5), Inches(6.2), Inches(12), Inches(0.4),
         size=14, bold=True, color=ORANGE)
add_text(s, "1 society live · 100 deliveries/day · ₹15 L MRR · BVLOS-approved · Series A-ready",
         Inches(0.5), Inches(6.6), Inches(12), Inches(0.4),
         size=13, color=WHITE, bold=True)

add_notes(s, "Close with confidence. Don't hedge the ask. '₹3 Cr for 12 months to get to ₹15 L MRR and "
             "Series A readiness.' Have a clean follow-up: 'Lead is ₹1.5-2 Cr, we're open to syndicate. "
             "What's the next step from your side?' Don't ask 'so what do you think?' — propose the next "
             "meeting.")

# ──────────────────────────────────────────────────────────────
# APPENDIX
# ──────────────────────────────────────────────────────────────
# A1 — Unit economics
s = new_slide()
add_header(s, "A1", "A", "Unit economics — line by line.",
           "Per delivery, at steady-state operation (40 deliveries/drone/day).")

# Table
headers = ["Line item", "Per delivery (₹)", "Notes"]
rows = [
    ["Drone amortization",       "3.0",  "₹15 L drone ÷ 3 years × 40 deliveries/day"],
    ["Battery cycle cost",       "2.0",  "1000 cycles per pack, ₹40k/pack"],
    ["Cellular data",            "1.0",  "5G data plan ÷ deliveries"],
    ["Maintenance + parts",      "2.0",  "10% of capex annually"],
    ["Insurance",                "2.0",  "Higher for first 12 months"],
    ["Ground operator (shared)", "2.0",  "1 operator covers 5 drones"],
    ["Misc + overheads",         "2.0",  "Cloud infra, support, etc."],
    ["TOTAL COST",               "14.0", ""],
    ["Revenue (per delivery)",   "20.0", "Charged to supermarket"],
    ["GROSS MARGIN",             "₹6 / 30%", ""],
]
y = Inches(2.5); col_widths = [Inches(4.5), Inches(2.5), Inches(5.3)]; row_h = Inches(0.4)

x = Inches(0.5)
for i, h in enumerate(headers):
    add_rect(s, x, y, col_widths[i], Inches(0.5), GREEN_DARK)
    add_text(s, h, x + Inches(0.15), y + Inches(0.08), col_widths[i] - Inches(0.3), Inches(0.4),
             size=12, bold=True, color=WHITE)
    x += col_widths[i]

for r_idx, row in enumerate(rows):
    yy = y + Inches(0.55 + r_idx * 0.4)
    is_total = "TOTAL" in row[0] or "MARGIN" in row[0] or "Revenue" in row[0]
    bg = ORANGE if "MARGIN" in row[0] else (GREEN if is_total else (WHITE if r_idx % 2 == 0 else RGBColor(0xFA, 0xFA, 0xF5)))
    x = Inches(0.5)
    for i, cell in enumerate(row):
        add_rect(s, x, yy, col_widths[i], row_h, bg)
        fg = WHITE if is_total else TEXT_DARK
        add_text(s, cell, x + Inches(0.15), yy + Inches(0.08), col_widths[i] - Inches(0.3), Inches(0.3),
                 size=11, color=fg, bold=is_total)
        x += col_widths[i]

add_text(s, "All numbers conservative. Actual unit economics improve with scale (battery price ↓, deliveries/drone ↑).",
         Inches(0.5), Inches(6.9), Inches(12), Inches(0.4),
         size=11, color=TEXT_MUTED, align=PP_ALIGN.CENTER)
add_footer(s)
add_notes(s, "This is the appendix slide they'll ask for. Have a more detailed spreadsheet ready for "
             "diligence — sensitivities on payload weight, weather days, operator efficiency.")

# A2 — Regulatory path
s = new_slide()
add_header(s, "A2", "A", "Regulatory path",
           "Realistic timeline. 6-12 months to first paid flight; we partner for compliance until then.")

steps = [
    ("Month 1-2",  "Apply for Operator Permit + Remote Pilot Certificates (₹50k-2L)"),
    ("Month 2-4",  "Partner with already-certified operator (Skye Air / Garuda) for first flights"),
    ("Month 3-5",  "Submit BVLOS corridor application via DigitalSky for Bangalore society"),
    ("Month 5-8",  "Type-tested drone selection + NPNT-compliant configuration"),
    ("Month 6-9",  "First supervised flights in approved corridor with safety pilot"),
    ("Month 9-12", "BVLOS approval for delivery missions; insurance underwritten"),
    ("Month 12+",  "Independent commercial operations; first own-permit deliveries"),
]
y = Inches(2.5)
for i, (when, body) in enumerate(steps):
    yy = y + Inches(i * 0.55)
    add_rect(s, Inches(0.5), yy, Inches(2.2), Inches(0.45), GREEN_DARK, radius=True)
    add_text(s, when, Inches(0.5), yy + Inches(0.08), Inches(2.2), Inches(0.4),
             size=11.5, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(s, body, Inches(2.9), yy + Inches(0.08), Inches(10), Inches(0.4),
             size=12, color=TEXT_DARK)

add_text(s, "Key partnerships pre-engaged with: DGCA-registered ops partner · insurance broker · DigitalSky consultancy",
         Inches(0.5), Inches(6.5), Inches(12), Inches(0.4),
         size=11, color=GREEN_DARK, bold=True)
add_footer(s)
add_notes(s, "If they're a sophisticated drone investor, this is the slide that closes them. Show you've "
             "done the homework. Name the operator you're talking to. Name the insurance broker. Specifics "
             "beat generalities.")

# A3 — Thank you / contact
s = prs.slides.add_slide(BLANK_LAYOUT)
add_bg(s, GREEN_DARK)
add_rect(s, 0, Inches(7.1), SW, Inches(0.4), ORANGE)
add_text(s, "🚁", Inches(0), Inches(2.4), SW, Inches(2),
         size=140, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
add_text(s, "Let's make 15-minute drone delivery real.",
         Inches(0), Inches(4.5), SW, Inches(0.8),
         size=32, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_text(s, "[Founder Name]  ·  [email@dronemart.io]  ·  [+91 XXXXX XXXXX]",
         Inches(0), Inches(5.4), SW, Inches(0.5),
         size=16, color=ORANGE, align=PP_ALIGN.CENTER)
add_text(s, "Demo & full data room available on request.",
         Inches(0), Inches(6.2), SW, Inches(0.4),
         size=12, color=WHITE, align=PP_ALIGN.CENTER)
add_notes(s, "End strong. Don't ask 'questions?'. Ask 'what's the next step from your side?' or 'can we "
             "schedule a follow-up with your partner?'. Investors respond better to founders who close.")

# ── Save ──────────────────────────────────────────────────────
out_path = '/Users/pkamisetti/Downloads/dronemart/dronemart_pitch.pptx'
prs.save(out_path)
print(f'Saved: {out_path}')
print(f'Slides: {len(prs.slides)}')
