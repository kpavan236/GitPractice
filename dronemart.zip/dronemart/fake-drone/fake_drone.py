#!/usr/bin/env python3
"""
Fake MAVLink drone. Drop-in stand-in for PX4 SITL on Apple Silicon (where
Gazebo SITL builds hang under Rosetta emulation).

Speaks real MAVLink v2 over UDP, so the bridge's mavlink-drone.js driver
exercises exactly the same code path it would against PX4. The only thing
this doesn't do is real physics — arming, takeoff, reposition, land are
modelled as state transitions with sensible timing.

Behaviour:
  • Listens for inbound MAVLink commands on UDP :14540
  • Sends HEARTBEAT @ 1 Hz
  • Sends GLOBAL_POSITION_INT @ 5 Hz with interpolated position
  • Sends SYS_STATUS @ 1 Hz with battery
  • Sends EXTENDED_SYS_STATE @ 2 Hz (on-ground / in-air)
  • Responds to COMPONENT_ARM_DISARM, NAV_TAKEOFF, NAV_LAND,
    NAV_RETURN_TO_LAUNCH, DO_REPOSITION, DO_SET_MODE
"""
import os
import math
import time
import threading
from pymavlink import mavutil

LISTEN_PORT = int(os.environ.get('LISTEN_PORT', 14540))
HOME_LAT    = float(os.environ.get('HOME_LAT', 12.9352))     # FreshMart Koramangala
HOME_LON    = float(os.environ.get('HOME_LON', 77.6245))
HOME_ALT_M  = float(os.environ.get('HOME_ALT', 920))
SYS_ID      = 1
COMP_ID     = 1
CRUISE_MPS  = 12.0     # ground speed during cruise

# EXTENDED_SYS_STATE.landed_state values per MAVLink spec
LANDED_ON_GROUND  = 1
LANDED_IN_AIR     = 2
LANDED_TAKING_OFF = 3
LANDED_LANDING    = 4


def m_per_deg_lat(): return 111_320.0
def m_per_deg_lon(lat): return 111_320.0 * math.cos(math.radians(lat))


class FakeDrone:
    def __init__(self, port):
        # `udpin` makes pymavlink listen and respond to whoever sent us a packet.
        self.mav = mavutil.mavlink_connection(
            f'udpin:0.0.0.0:{port}',
            source_system=SYS_ID, source_component=COMP_ID,
        )
        print(f'[fake-drone] listening on UDP :{port}, home=({HOME_LAT}, {HOME_LON})')
        self.lock = threading.Lock()
        self.armed = False
        self.in_air = False
        self.landed_state = LANDED_ON_GROUND
        self.lat = HOME_LAT
        self.lon = HOME_LON
        self.alt_rel_m = 0.0       # relative altitude (above home)
        self.target_lat = HOME_LAT
        self.target_lon = HOME_LON
        self.target_alt = 0.0
        self.battery_pct = 100
        self.heading_deg = 0.0
        self.last_send_pos = 0.0
        self.last_send_state = 0.0
        self.last_send_hb = 0.0
        self.last_send_sys = 0.0
        self.boot_time = time.time()
        self.flight_t0 = None      # when current target movement started
        self.flight_origin = None  # (lat, lon, alt) at start of current movement

    # ── lifecycle commands ───────────────────────────────────────
    def arm(self, armed):
        with self.lock:
            self.armed = armed
            print(f'[fake-drone] armed={armed}')

    def takeoff(self, alt_m):
        with self.lock:
            if not self.armed:
                print('[fake-drone] takeoff refused — not armed')
                return
            self.landed_state = LANDED_TAKING_OFF
            self.flight_origin = (self.lat, self.lon, self.alt_rel_m)
            self.target_alt = alt_m
            self.flight_t0 = time.time()
            print(f'[fake-drone] takeoff to {alt_m} m')

    def land(self):
        with self.lock:
            if not self.in_air:
                print('[fake-drone] land called but already on ground')
                return
            self.landed_state = LANDED_LANDING
            self.flight_origin = (self.lat, self.lon, self.alt_rel_m)
            self.target_alt = 0.0
            self.flight_t0 = time.time()
            print(f'[fake-drone] landing')

    def reposition(self, lat, lon, alt_m):
        with self.lock:
            self.flight_origin = (self.lat, self.lon, self.alt_rel_m)
            self.target_lat = lat
            self.target_lon = lon
            if alt_m and not math.isnan(alt_m):
                self.target_alt = alt_m
            self.flight_t0 = time.time()
            print(f'[fake-drone] reposition → ({lat:.6f}, {lon:.6f}, {self.target_alt} m)')

    def rtl(self):
        with self.lock:
            self.flight_origin = (self.lat, self.lon, self.alt_rel_m)
            self.target_lat = HOME_LAT
            self.target_lon = HOME_LON
            self.target_alt = self.alt_rel_m if self.alt_rel_m > 0 else 30.0
            self.flight_t0 = time.time()
            print('[fake-drone] RTL → home')
            # After arrival at home, land automatically.
            threading.Thread(target=self._post_rtl_land, daemon=True).start()

    def _post_rtl_land(self):
        # Wait until we're roughly at home + altitude, then trigger landing.
        while True:
            time.sleep(0.5)
            with self.lock:
                if self.flight_t0 is None:
                    break
                d = self._dist_to_target_m()
            if d is not None and d < 5:
                self.land()
                break

    # ── physics-ish update tick ──────────────────────────────────
    def _step(self, dt):
        with self.lock:
            # Vertical movement (takeoff / land): 3 m/s
            if self.alt_rel_m < self.target_alt:
                self.alt_rel_m = min(self.target_alt, self.alt_rel_m + 3.0 * dt)
            elif self.alt_rel_m > self.target_alt:
                self.alt_rel_m = max(self.target_alt, self.alt_rel_m - 2.0 * dt)

            # Horizontal movement toward target at cruise speed.
            # dlat/dlon are in degrees; dx_m/dy_m converted to meters for
            # distance + step computation. The position update is then a
            # simple fraction of the total degree-distance.
            dlat = self.target_lat - self.lat
            dlon = self.target_lon - self.lon
            dx_m = dlat * m_per_deg_lat()
            dy_m = dlon * m_per_deg_lon(self.lat)
            dist_m = math.hypot(dx_m, dy_m)
            if dist_m > 0.5:
                step_m = min(dist_m, CRUISE_MPS * dt)
                frac = step_m / dist_m       # 0..1 fraction of remaining trip
                self.lat += dlat * frac
                self.lon += dlon * frac
                self.heading_deg = math.degrees(math.atan2(dy_m, dx_m)) % 360.0

            # State transitions
            on_ground = self.alt_rel_m < 0.5
            near_target_alt = abs(self.alt_rel_m - self.target_alt) < 0.5
            if self.landed_state == LANDED_TAKING_OFF and near_target_alt and self.alt_rel_m > 0.5:
                self.landed_state = LANDED_IN_AIR
                self.in_air = True
                print(f'[fake-drone] in-air at {self.alt_rel_m:.1f} m')
            elif self.landed_state == LANDED_LANDING and on_ground:
                self.landed_state = LANDED_ON_GROUND
                self.in_air = False
                self.target_alt = 0.0
                print('[fake-drone] on ground')

            # Battery model: drain only while in-air, slow recharge while disarmed on ground
            if self.in_air:
                self.battery_pct = max(0, self.battery_pct - 0.7 * dt)   # ~0.7 %/s drain
            elif not self.armed and self.battery_pct < 100:
                self.battery_pct = min(100, self.battery_pct + 1.0 * dt)  # 1 %/s recharge

    def _dist_to_target_m(self):
        dlat = self.target_lat - self.lat
        dlon = self.target_lon - self.lon
        return math.hypot(dlat * m_per_deg_lat(), dlon * m_per_deg_lon(self.lat))

    # ── outbound MAVLink messages ────────────────────────────────
    def _send_periodic(self, now):
        if now - self.last_send_hb > 1.0:
            self.mav.mav.heartbeat_send(
                type=mavutil.mavlink.MAV_TYPE_QUADROTOR,
                autopilot=mavutil.mavlink.MAV_AUTOPILOT_PX4,
                base_mode=0b10000000 if self.armed else 0,   # ARMED flag
                custom_mode=0,
                system_status=mavutil.mavlink.MAV_STATE_ACTIVE if self.armed else mavutil.mavlink.MAV_STATE_STANDBY,
            )
            self.last_send_hb = now

        if now - self.last_send_pos > 0.2:  # 5 Hz
            self.mav.mav.global_position_int_send(
                time_boot_ms=int((now - self.boot_time) * 1000),
                lat=int(self.lat * 1e7),
                lon=int(self.lon * 1e7),
                alt=int((HOME_ALT_M + self.alt_rel_m) * 1000),   # mm AMSL
                relative_alt=int(self.alt_rel_m * 1000),         # mm above home
                vx=0, vy=0, vz=0,
                hdg=int(self.heading_deg * 100),
            )
            self.last_send_pos = now

        if now - self.last_send_state > 0.5:
            self.mav.mav.extended_sys_state_send(
                vtol_state=0,
                landed_state=self.landed_state,
            )
            self.last_send_state = now

        if now - self.last_send_sys > 1.0:
            self.mav.mav.sys_status_send(
                onboard_control_sensors_present=0, onboard_control_sensors_enabled=0,
                onboard_control_sensors_health=0, load=200,
                voltage_battery=int(11.1 * 1000),   # mV
                current_battery=-1,
                battery_remaining=int(self.battery_pct),
                drop_rate_comm=0, errors_comm=0,
                errors_count1=0, errors_count2=0, errors_count3=0, errors_count4=0,
            )
            self.last_send_sys = now

    # ── inbound MAVLink handler ──────────────────────────────────
    def _handle(self, msg):
        t = msg.get_type()
        if t == 'COMMAND_LONG':
            cmd = msg.command
            if cmd == mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM:
                self.arm(msg.param1 > 0.5)
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_NAV_TAKEOFF:
                self.takeoff(msg.param7)
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_NAV_LAND:
                self.land()
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_NAV_RETURN_TO_LAUNCH:
                self.rtl()
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_DO_REPOSITION:
                lat = msg.param5 / 1e7
                lon = msg.param6 / 1e7
                alt = msg.param7
                self.reposition(lat, lon, alt)
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_DO_SET_MODE:
                # Accept any mode-set; we don't model PX4's mode tree.
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            elif cmd == mavutil.mavlink.MAV_CMD_DO_FLIGHTTERMINATION:
                print('[fake-drone] FLIGHT TERMINATION requested')
                with self.lock:
                    self.armed = False
                    self.alt_rel_m = 0
                    self.in_air = False
                    self.landed_state = LANDED_ON_GROUND
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_ACCEPTED)
            else:
                print(f'[fake-drone] unhandled COMMAND_LONG cmd={cmd}')
                self._ack(cmd, mavutil.mavlink.MAV_RESULT_UNSUPPORTED)

    def _ack(self, command, result):
        self.mav.mav.command_ack_send(command=command, result=result)

    # ── main loop ────────────────────────────────────────────────
    def run(self):
        last = time.time()
        while True:
            now = time.time()
            dt = now - last
            last = now
            self._step(dt)
            self._send_periodic(now)
            # Non-blocking recv (poll)
            msg = self.mav.recv_match(blocking=False)
            if msg is not None and msg.get_type() != 'BAD_DATA':
                self._handle(msg)
            time.sleep(0.02)  # 50 Hz loop


if __name__ == '__main__':
    drone = FakeDrone(LISTEN_PORT)
    try:
        drone.run()
    except KeyboardInterrupt:
        print('[fake-drone] shutting down')
