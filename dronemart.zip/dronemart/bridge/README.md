# DroneMart Bridge

Translates between the cloud's **MQTT** topics and an actual **drone source** —
either an in-process mock (default), PX4-SITL for development against the real
MAVLink protocol, or a real drone in the field.

## Topic contract

The MQTT topic shapes are the **only** thing the api ↔ drone boundary speaks.
They stay constant whether the source is mock, SITL, or hardware.

| Direction | Topic | Payload |
|---|---|---|
| api → drone | `drones/<droneId>/commands/mission` | Mission JSON (see below) |
| api → drone | `drones/<droneId>/commands/return`  | Return-to-home JSON (see below) |
| api → drone | `drones/<droneId>/commands/abort`   | `{ "reason": "..." }` |
| drone → api | `drones/<droneId>/telemetry`        | Position + battery snapshot |
| drone → api | `drones/<droneId>/events`           | State transitions |

### Mission JSON

```json
{
  "missionId":  "uuid",
  "orderId":    "uuid",
  "issuedAt":   "2026-05-25T10:00:00Z",
  "home":        { "lat": 12.9352, "lng": 77.6245 },
  "destination": { "lat": 12.9279, "lng": 77.6271 },
  "policy": {
    "cruise_alt_m":    30,
    "max_speed_kmh":   45,
    "rtl_battery_pct": 25
  }
}
```

### Return-to-home JSON

Published by `unlockBox` after the customer enters the PIN. Bridge flies the
drone from its current position back to `home`, optionally charges if battery
< threshold, then signals `idle`.

```json
{
  "orderId":     "uuid",
  "home":        { "lat": 12.9352, "lng": 77.6245 },
  "from":        { "lat": 12.9279, "lng": 77.6271 },
  "battery_pct": 22,
  "policy":      { "charge_threshold_pct": 80 }
}
```

### Telemetry payload

```json
{
  "ts":          "2026-05-25T10:00:01.500Z",
  "orderId":     "uuid",
  "droneId":     "uuid",
  "lat":         12.9315,
  "lng":         77.6260,
  "alt_m":       30,
  "speed_kmh":   45,
  "heading":     135,
  "battery_pct": 85,
  "progress":    0.42,
  "state":       "in_flight"
}
```

### Event payload

```json
{
  "ts":      "2026-05-25T10:00:15.000Z",
  "orderId": "uuid",
  "state":   "landed",
  "note":    "Touchdown at delivery point"
}
```

Recognized states: `armed`, `in_flight`, `near_destination`, `landed`,
`awaiting_pickup`, `returning`, `idle`, `charging`, `failed`, `aborted`.

## Modes

`DRONE_SOURCE=mock` *(default)* runs `src/mock-drone.js` — produces realistic
telemetry without any hardware. Use this for everything until you have a real
drone connection or want to test against PX4-SITL.

`DRONE_SOURCE=mavlink` *(stub)* — see `src/mavlink-drone.js`. Wire up when you
bring up the PX4-SITL container (commented out in `docker-compose.yml`) or
plug in a real drone over cellular MAVLink.

## How to enable bridge mode in the api

The api defaults to the in-process simulator (`DRONE_MODE=simulator`). To switch:

```bash
DRONE_MODE=mqtt docker compose up -d --build api bridge mqtt-broker
```

Or in `.env`:

```
DRONE_MODE=mqtt
```

`assignDrone` then publishes a mission to `drones/<droneId>/commands/mission`
instead of starting the in-process simulator. The bridge picks it up, runs the
mock flight, and publishes telemetry + events back through MQTT. The api's
MQTT subscriber translates those into the same WebSocket events the frontends
already consume — **no frontend change required**.

## Switching to PX4-SITL

The MAVLink driver is in `src/mavlink-drone.js` and wired into `src/index.js`.
PX4-SITL is an opt-in `sitl` compose profile to keep it out of the default
`docker compose up`.

```bash
# 1. Bring up PX4 (first boot ~2-3 min under amd64 emulation on Apple Silicon)
docker compose --profile sitl up -d px4-sitl
docker logs -f dronemart_px4_sitl     # wait for "Ready for takeoff!"

# 2. Switch the bridge over
DRONE_SOURCE=mavlink docker compose up -d --build bridge

# 3. Run a delivery as usual — assignDrone publishes an MQTT mission,
# bridge translates to MAVLink, PX4 arms + takes off + flies + lands.
docker logs -f dronemart_bridge
```

The bridge tries to connect to `px4-sitl:14540` (the docker-compose service
name). PX4-SITL streams MAVLink position/battery/state back; the bridge
translates each into the same MQTT telemetry/event shape the mock drone
produces, so the api + frontends are unchanged.

### Sequence the MAVLink driver executes

```
runMission(mission):
  DO_SET_MODE(AUTO|LOITER)         ← switch to autonomous control
  COMPONENT_ARM_DISARM(arm=1)      ← arm motors
  NAV_TAKEOFF(alt=cruise_alt_m)    ← climb to cruise altitude
  wait for EXTENDED_SYS_STATE=in_air
    → emit 'in_flight'
  DO_REPOSITION(destination)       ← fly to customer
    → emit 'near_destination'
  wait until <10 m from destination
  NAV_LAND                         ← descend + touchdown
  wait for EXTENDED_SYS_STATE=on_ground
    → emit 'landed' + 'awaiting_pickup'

returnHome(payload):
  NAV_RETURN_TO_LAUNCH             ← PX4 handles climb-fly-descend-land
  wait for on_ground
    → emit 'charging' (if battery < threshold) or 'idle'
  emit 'idle' (after sim charge delay)
  COMPONENT_ARM_DISARM(arm=0)

abort(reason):
  emit 'aborted'
  NAV_RETURN_TO_LAUNCH             ← bring it home rather than terminate mid-air
```

### Known caveats

- **Apple Silicon emulation**: PX4-SITL is amd64-only. Under Rosetta first boot
  is slow (~2–3 min). Functional but you wouldn't want this for many parallel
  sims.
- **SITL doesn't model battery drain** in default config. Battery stays at
  100% in telemetry; the `returnHome` path skips the `charging` event when
  battery isn't low, then fast-forwards to `idle` after a short delay so the
  drone is reusable. Real hardware will naturally drain.
- **Coordinate system**: PX4 SITL boots at the lat/lng you pass in `command`
  (currently FreshMart Koramangala — `12.9352, 77.6245`). The waypoints in the
  mission should be within a few km of that or PX4 might reject them.
- **`DO_REPOSITION` is a PX4-specific command**. ArduPilot uses
  `MAV_CMD_NAV_WAYPOINT` instead. If you swap autopilots, update one line.

## Switching to a real drone

Same MQTT contract. The bridge runs **on the drone's companion computer**
(Raspberry Pi CM4 or Jetson Nano) instead of in this docker-compose. It opens
a TLS connection to your hosted MQTT broker over the drone's cellular modem.
All the api code, all the frontends, the customer-side live map — they all
keep working because the bytes look identical on the broker.
