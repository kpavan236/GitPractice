// Mock drone source. Produces the same lifecycle the in-process simulator did,
// but emits telemetry/events through the publishers the bridge gave it. Same
// payload shapes whether the source is this mock, PX4-SITL via MAVLink, or a
// real drone — so the cloud-side (api) doesn't know the difference.
//
// Lifecycle:
//   runMission()       → armed → in_flight → near_destination → landed → awaiting_pickup
//   (waits for return command — the customer hasn't unlocked yet)
//   returnHome()       → returning → charging → idle
//   round-trip complete; bridge clears this drone from active

const TICKS = 20;                    // outbound telemetry ticks
const RETURN_TICKS = 10;
const RETURN_DURATION_MS = 10_000;
const CHARGE_DURATION_MS = 30_000;
const CHARGE_THRESHOLD = 80;         // battery_pct below this → charge before idle

function createMockDrone({ droneId, publishTelemetry, publishEvent, speedMult }) {
  let aborted = false;
  let timers = [];
  let resolveMission = null;
  let outbound = null;                // { orderId, home, destination, lastBattery }

  const after = (ms, fn) => { const t = setTimeout(fn, ms / speedMult); timers.push(t); return t; };
  const every = (ms, fn) => { const t = setInterval(fn, ms / speedMult); timers.push(t); return t; };
  const clearAll = () => { timers.forEach(t => { clearTimeout(t); clearInterval(t); }); timers = []; };
  const done = () => { if (resolveMission) { const r = resolveMission; resolveMission = null; r(); } };

  function abort(reason) {
    if (aborted) return;
    aborted = true;
    clearAll();
    publishEvent({ state: 'aborted', orderId: outbound?.orderId, note: reason });
    done();
  }

  function runMission(mission) {
    const { orderId, home, destination, policy = {} } = mission;
    if (!home || !destination) throw new Error('mission missing home or destination');
    outbound = { orderId, home, destination, lastBattery: 100 };

    const cruiseAlt   = policy.cruise_alt_m || 30;
    const cruiseSpeed = policy.max_speed_kmh || 45;
    const interp = (p) => ({
      lat: home.lat + (destination.lat - home.lat) * p,
      lng: home.lng + (destination.lng - home.lng) * p,
    });

    publishEvent({ state: 'armed', orderId, note: 'Mission accepted; arming motors' });

    // Paced to ~60 s outbound at speedMult=10. Schedule (real time):
    //   T+6s    in_flight + telemetry begins
    //   T+6s .. T+54s   20 telemetry ticks every ~2.4 s (visible glide)
    //   T+42s   near_destination
    //   T+54s   landed
    //   T+57s   awaiting_pickup
    after(60000, () => {
      if (aborted) return;
      publishEvent({ state: 'in_flight', orderId, note: 'Took off; cruising to destination' });
      let tick = 0;
      const iv = every(48000 / TICKS, () => {     // 48 s / 20 ticks = 2.4 s real
        if (aborted) return;
        tick++;
        const progress = tick / TICKS;
        outbound.lastBattery = Math.max(20, 100 - tick * 4);
        const pos = interp(progress);
        publishTelemetry({
          orderId, droneId, ...pos,
          alt_m: cruiseAlt, speed_kmh: cruiseSpeed, heading: 135,
          battery_pct: outbound.lastBattery, progress, state: 'in_flight',
        });
        if (tick >= TICKS) clearInterval(iv);
      });
    });

    after(420000, () => { if (!aborted) publishEvent({ state: 'near_destination', orderId, note: 'Within 100 m of destination' }); });
    after(540000, () => { if (!aborted) publishEvent({ state: 'landed',           orderId, note: 'Touchdown; awaiting customer' }); });
    after(570000, () => { if (!aborted) publishEvent({ state: 'awaiting_pickup',  orderId, note: 'Box ready for PIN unlock' }); });

    // Resolve only when the FULL round-trip is done (after returnHome + charge).
    // Until then this drone stays in the bridge's `active` map and is reachable
    // by subsequent `commands/return` / `commands/abort`.
    return new Promise(resolve => { resolveMission = resolve; });
  }

  function returnHome(payload = {}) {
    if (aborted) return;
    if (!outbound) {
      console.warn('[mock-drone] returnHome called without prior runMission — ignoring');
      return;
    }
    const orderId = outbound.orderId;
    const home    = payload.home || outbound.home;
    const from    = payload.from || outbound.destination;
    const battery = payload.battery_pct ?? outbound.lastBattery;
    const chargeThreshold = payload.policy?.charge_threshold_pct ?? CHARGE_THRESHOLD;

    publishEvent({ state: 'returning', orderId, note: 'Heading back to home' });

    // Interpolate position back to home so the supermarket Drones map can animate.
    let tick = 0;
    const iv = every(RETURN_DURATION_MS / RETURN_TICKS, () => {
      if (aborted) return;
      tick++;
      const p = tick / RETURN_TICKS;
      const lat = from.lat + (home.lat - from.lat) * p;
      const lng = from.lng + (home.lng - from.lng) * p;
      publishTelemetry({
        orderId, droneId, lat, lng,
        alt_m: 30, speed_kmh: 45, heading: 315,
        battery_pct: battery, state: 'returning',
      });
      if (tick >= RETURN_TICKS) clearInterval(iv);
    });

    after(RETURN_DURATION_MS, () => {
      if (aborted) return;
      const needsCharge = battery < chargeThreshold;
      publishEvent({
        state: needsCharge ? 'charging' : 'idle',
        orderId,
        lat: home.lat, lng: home.lng,
        battery_pct: battery,
        note: needsCharge ? 'Returned home; charging' : 'Returned home; ready',
      });
      if (!needsCharge) { done(); return; }
      after(CHARGE_DURATION_MS, () => {
        if (aborted) return;
        publishEvent({
          state: 'idle',
          orderId,
          lat: home.lat, lng: home.lng,
          battery_pct: 100,
          note: 'Charged; ready for next mission',
        });
        done();
      });
    });
  }

  return { runMission, returnHome, abort };
}

module.exports = { createMockDrone };
