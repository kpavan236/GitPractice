// DroneMart bridge — translates between MQTT (cloud) and the drone source.
// Two sources are pluggable behind the same internal interface:
//   - mock     : in-process simulator (default; produces realistic telemetry)
//   - mavlink  : connects to PX4-SITL or a real drone over MAVLink/UDP
//
// MQTT topic contract (same regardless of source):
//   IN  drones/<droneId>/commands/mission   — payload: Mission JSON (see ./mission-schema.md)
//   IN  drones/<droneId>/commands/abort     — payload: { reason }
//   OUT drones/<droneId>/telemetry          — { ts, lat, lng, alt_m, speed_kmh, heading, battery_pct, progress, state, orderId }
//   OUT drones/<droneId>/events             — { ts, state, orderId, note }

const mqtt = require('mqtt');
const { createMockDrone } = require('./mock-drone');
const { createMavlinkDrone } = require('./mavlink-drone');

const BROKER_URL    = process.env.MQTT_BROKER_URL || 'mqtt://mqtt-broker:1883';
const DRONE_SOURCE  = process.env.DRONE_SOURCE || 'mock';           // 'mock' | 'mavlink'
const SPEED_MULT    = parseInt(process.env.DRONE_SIMULATION_SPEED_MULTIPLIER || '10', 10);

console.log(`[bridge] starting — broker=${BROKER_URL} source=${DRONE_SOURCE} speedMult=${SPEED_MULT}×`);

const client = mqtt.connect(BROKER_URL, {
  clientId: `bridge-${Math.random().toString(16).slice(2)}`,
  reconnectPeriod: 2000,
});

client.on('connect', () => {
  console.log('[bridge] connected to MQTT');
  client.subscribe('drones/+/commands/mission', { qos: 1 });
  client.subscribe('drones/+/commands/return',  { qos: 1 });
  client.subscribe('drones/+/commands/abort',   { qos: 1 });
});

client.on('error', err => console.error('[bridge] mqtt error:', err.message));
client.on('reconnect', () => console.log('[bridge] reconnecting…'));

// Per-drone active source instances. One instance == one in-flight mission.
// When a new mission arrives for a drone with an active mission, the old one is aborted.
const active = new Map();   // droneId -> drone source instance

function buildSource(droneId, publishTelemetry, publishEvent) {
  if (DRONE_SOURCE === 'mavlink') {
    return createMavlinkDrone({ droneId, publishTelemetry, publishEvent });
  }
  return createMockDrone({ droneId, publishTelemetry, publishEvent, speedMult: SPEED_MULT });
}

client.on('message', (topic, payload) => {
  const m = topic.match(/^drones\/([^/]+)\/commands\/(.+)$/);
  if (!m) return;
  const [, droneId, command] = m;

  let body = {};
  try { body = JSON.parse(payload.toString()); } catch { /* command may be empty */ }

  const publishTelemetry = data => client.publish(
    `drones/${droneId}/telemetry`,
    JSON.stringify({ ts: new Date().toISOString(), ...data }),
    { qos: 0 },
  );
  const publishEvent = data => client.publish(
    `drones/${droneId}/events`,
    JSON.stringify({ ts: new Date().toISOString(), ...data }),
    { qos: 1 },
  );

  if (command === 'mission') {
    // Replace any in-flight mission for this drone
    const prev = active.get(droneId);
    if (prev) { console.log(`[bridge] drone ${droneId.slice(0,8)}: aborting previous mission`); prev.abort('replaced'); }
    console.log(`[bridge] drone ${droneId.slice(0,8)}: new mission ${body.missionId?.slice(0,8) || '?'} (order ${body.orderId?.slice(0,8) || '?'})`);
    try {
      const source = buildSource(droneId, publishTelemetry, publishEvent);
      active.set(droneId, source);
      source.runMission(body).finally(() => {
        if (active.get(droneId) === source) active.delete(droneId);
      });
    } catch (e) {
      console.error('[bridge] failed to start mission:', e.message);
      publishEvent({ state: 'failed', orderId: body.orderId, note: e.message });
    }
  } else if (command === 'return') {
    const inst = active.get(droneId);
    if (!inst) {
      console.warn(`[bridge] drone ${droneId.slice(0,8)}: return command but no active mission`);
      return;
    }
    console.log(`[bridge] drone ${droneId.slice(0,8)}: return-to-home (order ${body.orderId?.slice(0,8) || '?'})`);
    inst.returnHome(body);
  } else if (command === 'abort') {
    const inst = active.get(droneId);
    if (inst) { inst.abort(body.reason || 'manual abort'); active.delete(droneId); }
  }
});

// Graceful shutdown — abort any in-flight missions so we don't leak timers
const shutdown = (sig) => {
  console.log(`[bridge] ${sig} — aborting ${active.size} in-flight mission(s)`);
  for (const inst of active.values()) inst.abort('bridge shutdown');
  client.end(false, () => process.exit(0));
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
