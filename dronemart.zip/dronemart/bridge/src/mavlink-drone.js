// MAVLink drone source. Talks PX4 (SITL today, real autopilot tomorrow).
//
// Same interface as mock-drone.js so the bridge's index.js dispatcher doesn't
// care which one is in use:
//     { runMission(mission), returnHome(payload), abort(reason) }
//
// Connection model (PX4 SITL default):
//     PX4 sends MAVLink over UDP to whatever IP the bridge initiates from.
//     The bridge connects outbound to px4-sitl:14540, then PX4 starts streaming
//     telemetry back to our source address. Same pattern as MAVSDK / QGroundControl.

const dgram = require('node:dgram');
const { MavLinkPacketSplitter, MavLinkPacketParser, MavLinkProtocolV2,
        send, common, minimal } = require('node-mavlink');

const PX4_HOST = process.env.PX4_HOST || 'px4-sitl';
const PX4_PORT = parseInt(process.env.PX4_UDP_PORT || '14540', 10);

// PX4 custom-mode encoding (see PX4 commander.cpp / px4_custom_mode.h).
// MAV_CMD_DO_SET_MODE expects:  param1=base_mode, param2=main_mode, param3=sub_mode
const BASE_MODE_CUSTOM = 0b00000001;       // MAV_MODE_FLAG_CUSTOM_MODE_ENABLED
const PX4_MAIN_AUTO    = 4;
const PX4_SUB_TAKEOFF  = 2;
const PX4_SUB_LAND     = 6;
const PX4_SUB_RTL      = 5;
const PX4_SUB_LOITER   = 3;

function createMavlinkDrone({ droneId, publishTelemetry, publishEvent }) {
  let aborted = false;
  let resolveMission = null;
  let timers = [];

  // Telemetry we accumulate from PX4 so each outbound MQTT message is complete
  const live = {
    lat: null, lng: null, alt_m: null, speed_kmh: null, heading: null,
    battery_pct: null, landed: null /* 1=on-ground 2=in-air per EXTENDED_SYS_STATE */,
  };
  // PX4 SITL identifies itself with these in HEARTBEAT — we discover them at runtime.
  let targetSys = 1;
  let targetComp = 1;

  // ── UDP transport ────────────────────────────────────────────────────
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  const splitter = new MavLinkPacketSplitter();
  const parser   = new MavLinkPacketParser();
  splitter.pipe(parser);

  sock.on('message', (buf) => splitter.write(buf));
  sock.on('error', (e) => console.error('[mavlink] socket error:', e.message));
  sock.bind(0);   // ephemeral local port; PX4 replies to whatever we sent from

  // Registry of message classes we care to decode.
  const REGISTRY = {
    [common.GlobalPositionInt.MSG_ID]: common.GlobalPositionInt,
    [common.SysStatus.MSG_ID]:         common.SysStatus,
    [common.ExtendedSysState.MSG_ID]:  common.ExtendedSysState,
    [common.VfrHud.MSG_ID]:            common.VfrHud,
    [minimal.Heartbeat.MSG_ID]:        minimal.Heartbeat,
  };

  parser.on('data', (packet) => {
    const Clazz = REGISTRY[packet.header.msgid];
    if (!Clazz) return;
    let msg; try { msg = packet.protocol.data(packet.payload, Clazz); } catch { return; }

    if (msg instanceof minimal.Heartbeat) {
      // Capture sysid/compid for outbound commands; PX4 SITL = 1/1 by default.
      if (packet.header.sysid && packet.header.sysid !== targetSys) {
        targetSys = packet.header.sysid;
        targetComp = packet.header.compid;
        console.log(`[mavlink] heartbeat from sysid=${targetSys} compid=${targetComp}`);
      }
    } else if (msg instanceof common.GlobalPositionInt) {
      live.lat = msg.lat / 1e7;
      live.lng = msg.lon / 1e7;
      live.alt_m = msg.relativeAlt / 1000;
      live.heading = msg.hdg / 100;
      flushTelemetry();
    } else if (msg instanceof common.VfrHud) {
      live.speed_kmh = (msg.groundspeed || 0) * 3.6;
      live.alt_m = msg.alt;
    } else if (msg instanceof common.SysStatus) {
      // batteryRemaining is 0-100, or -1 if unknown
      if (msg.batteryRemaining >= 0) {
        live.battery_pct = msg.batteryRemaining;
        flushTelemetry();
      }
    } else if (msg instanceof common.ExtendedSysState) {
      const next = msg.landedState;       // 1 = on ground, 2 = in air, 3 = takeoff, 4 = landing
      if (next !== live.landed) {
        const prev = live.landed;
        live.landed = next;
        // Surface transitions as bridge events the api can map to order.status.
        if (prev === 1 && next === 2) publishEvent({ state: 'in_flight',  orderId: outboundOrderId(), note: 'Airborne (PX4)' });
        if (prev === 2 && next === 1) publishEvent({ state: 'landed',     orderId: outboundOrderId(), note: 'On ground (PX4)' });
      }
    }
  });

  let _orderId = null;
  function outboundOrderId() { return _orderId; }

  // Throttle telemetry — PX4 floods position at 50 Hz, we don't need that.
  let lastFlush = 0;
  function flushTelemetry() {
    const now = Date.now();
    if (now - lastFlush < 200) return;        // 5 Hz max
    lastFlush = now;
    publishTelemetry({
      orderId: _orderId, droneId,
      lat: live.lat, lng: live.lng,
      alt_m: live.alt_m, speed_kmh: live.speed_kmh, heading: live.heading,
      battery_pct: live.battery_pct,
      state: live.landed === 2 ? 'in_flight' : 'on_ground',
    });
  }

  // ── Outbound MAVLink helpers ─────────────────────────────────────────
  function sendUdp(buffer) {
    return new Promise((resolve, reject) =>
      sock.send(buffer, PX4_PORT, PX4_HOST, (err) => err ? reject(err) : resolve()));
  }
  // node-mavlink's send() writes to a stream — we adapt to UDP by using its
  // synchronous serializer and pushing the resulting buffer ourselves.
  const protocol = new MavLinkProtocolV2();

  async function sendCommand(commandId, params = {}) {
    const cmd = new common.CommandLong();
    cmd.targetSystem    = targetSys;
    cmd.targetComponent = targetComp;
    cmd.command         = commandId;
    cmd.confirmation    = 0;
    cmd._param1 = params.param1 ?? 0;
    cmd._param2 = params.param2 ?? 0;
    cmd._param3 = params.param3 ?? 0;
    cmd._param4 = params.param4 ?? 0;
    cmd._param5 = params.param5 ?? 0;
    cmd._param6 = params.param6 ?? 0;
    cmd._param7 = params.param7 ?? 0;
    const buf = await protocol.serialize(cmd, 1 /* sysid for OUR side */);
    await sendUdp(buf);
  }

  const armDisarm = (arm) => sendCommand(common.MavCmd.COMPONENT_ARM_DISARM, { param1: arm ? 1 : 0 });
  const setPx4Mode = (mainMode, subMode) => sendCommand(common.MavCmd.DO_SET_MODE, {
    param1: BASE_MODE_CUSTOM, param2: mainMode, param3: subMode,
  });
  const takeoff = (altMeters) => sendCommand(common.MavCmd.NAV_TAKEOFF, { param7: altMeters });
  const land    = ()            => sendCommand(common.MavCmd.NAV_LAND);
  const rtl     = ()            => sendCommand(common.MavCmd.NAV_RETURN_TO_LAUNCH);
  const terminate = ()          => sendCommand(common.MavCmd.DO_FLIGHTTERMINATION, { param1: 1 });
  // Aim at a specific lat/lng (param5/6 lat/lng *1e7, param7 alt meters)
  const reposition = (lat, lng, alt) => sendCommand(common.MavCmd.DO_REPOSITION, {
    param5: Math.round(lat * 1e7), param6: Math.round(lng * 1e7), param7: alt,
  });

  // ── Lifecycle: same contract as mock-drone.js ────────────────────────
  function abort(reason) {
    if (aborted) return;
    aborted = true;
    timers.forEach(t => { clearTimeout(t); clearInterval(t); });
    timers = [];
    publishEvent({ state: 'aborted', orderId: _orderId, note: reason });
    // Best-effort: bring the drone back. RTL is safer than terminate for routine aborts.
    rtl().catch(() => {});
    if (resolveMission) { const r = resolveMission; resolveMission = null; r(); }
  }

  async function runMission(mission) {
    const { orderId, home, destination, policy = {} } = mission;
    if (!home || !destination) throw new Error('mission missing home or destination');
    _orderId = orderId;
    const cruiseAlt = policy.cruise_alt_m || 30;

    try {
      publishEvent({ state: 'armed', orderId, note: 'PX4: switching to AUTO + arming' });

      await setPx4Mode(PX4_MAIN_AUTO, PX4_SUB_LOITER);
      await sleep(500);
      await armDisarm(true);
      await sleep(500);
      await sendCommand(common.MavCmd.NAV_TAKEOFF, { param4: NaN, param5: NaN, param6: NaN, param7: cruiseAlt });

      console.log(`[mavlink] waiting for airborne (current landed=${live.landed})`);
      await waitFor(() => live.landed === 2, 30_000);
      console.log('[mavlink] airborne; sending reposition');
      await reposition(destination.lat, destination.lng, cruiseAlt);
      publishEvent({ state: 'near_destination', orderId, note: 'Cruising toward delivery point' });

      console.log('[mavlink] waiting until within 15 m of destination');
      await waitFor(() => {
        if (live.lat == null) return false;
        const d = haversineMeters(live, destination);
        return d < 15;
      }, 180_000);
      console.log('[mavlink] arrived; issuing LAND');
      await land();

      console.log('[mavlink] waiting for on-ground');
      await waitFor(() => live.landed === 1, 60_000);
      publishEvent({ state: 'awaiting_pickup', orderId, note: 'Box ready for PIN unlock' });

      return await new Promise((resolve) => { resolveMission = resolve; });
    } catch (err) {
      // Don't let an uncaught timeout kill the bridge process.
      console.error('[mavlink] runMission failed:', err.message);
      publishEvent({ state: 'failed', orderId, note: err.message });
      rtl().catch(() => {});       // best-effort: bring it back if it's mid-air
      if (resolveMission) { const r = resolveMission; resolveMission = null; r(); }
    }
  }

  async function returnHome(payload = {}) {
    if (aborted) return;
    publishEvent({ state: 'returning', orderId: _orderId, note: 'PX4: RTL' });

    // PX4 RTL handles the climb-to-RTL-alt + fly-home + descend + land sequence.
    await armDisarm(true).catch(()=>{}); // RTL needs armed; harmless if already armed
    await rtl();

    // When PX4 reports on-ground after RTL, we publish charging/idle.
    await waitFor(() => live.landed === 1, 120_000);
    const battery = live.battery_pct ?? 50;
    const needsCharge = battery < (payload.policy?.charge_threshold_pct ?? 80);
    publishEvent({
      state: needsCharge ? 'charging' : 'idle',
      orderId: _orderId,
      lat: live.lat, lng: live.lng, battery_pct: battery,
      note: needsCharge ? 'Returned home; charging' : 'Returned home; ready',
    });

    if (needsCharge) {
      // SITL doesn't model charging; just fast-forward to "idle, 100%" after a delay.
      await sleep(3000);
      if (aborted) return;
      publishEvent({
        state: 'idle', orderId: _orderId,
        lat: live.lat, lng: live.lng, battery_pct: 100,
        note: 'Charged; ready for next mission',
      });
    }

    // Disarm so PX4 is back to a clean state.
    await armDisarm(false).catch(()=>{});
    if (resolveMission) { const r = resolveMission; resolveMission = null; r(); }
  }

  return { runMission, returnHome, abort };
}

// ── Small helpers ────────────────────────────────────────────────────
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
function waitFor(predicate, timeoutMs) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const iv = setInterval(() => {
      if (predicate()) { clearInterval(iv); resolve(); }
      else if (Date.now() - start > timeoutMs) { clearInterval(iv); reject(new Error('waitFor timeout')); }
    }, 200);
  });
}
function haversineMeters(a, b) {
  const toRad = d => d * Math.PI / 180;
  const R = 6371000;
  const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
  const x = Math.sin(dLat/2)**2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

module.exports = { createMavlinkDrone };
