-- ============================================================
-- DroneMart Platform — Full Database Schema
-- PostgreSQL 15+
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";  -- for geospatial queries
CREATE EXTENSION IF NOT EXISTS "cube";
CREATE EXTENSION IF NOT EXISTS "earthdistance";  -- for point <@> point distance

-- ============================================================
-- PLATFORM & LICENSING
-- ============================================================

CREATE TABLE license_plans (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(50) NOT NULL,          -- 'starter','growth','enterprise'
  price_monthly NUMERIC(10,2) NOT NULL,
  max_drones    INT NOT NULL DEFAULT 2,
  max_products  INT NOT NULL DEFAULT 100,
  max_orders_pm INT NOT NULL DEFAULT 500,
  features      JSONB DEFAULT '{}',
  is_active     BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO license_plans (name, price_monthly, max_drones, max_products, max_orders_pm, features) VALUES
  ('Starter',    999.00,   2,   100,   500,  '{"analytics":false,"priority_support":false,"custom_branding":false}'),
  ('Growth',    2999.00,   5,   500,  2000,  '{"analytics":true, "priority_support":false,"custom_branding":false}'),
  ('Enterprise',7999.00,  20,  9999, 99999,  '{"analytics":true, "priority_support":true, "custom_branding":true}');

CREATE TABLE supermarkets (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name             VARCHAR(100) NOT NULL,
  slug             VARCHAR(60)  UNIQUE NOT NULL,
  owner_name       VARCHAR(100) NOT NULL,
  email            VARCHAR(150) UNIQUE NOT NULL,
  phone            VARCHAR(20),
  password_hash    TEXT NOT NULL,
  license_plan_id  UUID REFERENCES license_plans(id),
  license_status   VARCHAR(20) DEFAULT 'trial',   -- trial|active|suspended|cancelled
  license_expires  TIMESTAMPTZ,
  trial_ends       TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
  address          TEXT,
  city             VARCHAR(80),
  state            VARCHAR(80),
  pincode          VARCHAR(10),
  lat              DOUBLE PRECISION,
  lng              DOUBLE PRECISION,
  location         GEOGRAPHY(POINT,4326),
  delivery_radius_km NUMERIC(5,2) DEFAULT 5.0,
  logo_url         TEXT,
  is_open          BOOLEAN DEFAULT TRUE,
  open_time        TIME DEFAULT '08:00',
  close_time       TIME DEFAULT '22:00',
  razorpay_key_id  TEXT,
  razorpay_secret  TEXT,
  stripe_key       TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE supermarket_payments (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supermarket_id   UUID REFERENCES supermarkets(id),
  plan_id          UUID REFERENCES license_plans(id),
  amount           NUMERIC(10,2) NOT NULL,
  currency         VARCHAR(5) DEFAULT 'INR',
  gateway          VARCHAR(20) DEFAULT 'razorpay',
  gateway_order_id TEXT,
  gateway_pay_id   TEXT,
  status           VARCHAR(20) DEFAULT 'pending',  -- pending|paid|failed|refunded
  period_start     TIMESTAMPTZ,
  period_end       TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- USERS (CUSTOMERS)
-- ============================================================

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  phone         VARCHAR(20) UNIQUE,
  password_hash TEXT NOT NULL,
  avatar_url    TEXT,
  is_verified   BOOLEAN DEFAULT FALSE,
  is_active     BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_addresses (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  label         VARCHAR(30) DEFAULT 'Home',       -- Home|Work|Other
  name          VARCHAR(100),
  phone         VARCHAR(20),
  line1         TEXT NOT NULL,
  line2         TEXT,
  city          VARCHAR(80),
  state         VARCHAR(80),
  pincode       VARCHAR(10),
  lat           DOUBLE PRECISION NOT NULL,
  lng           DOUBLE PRECISION NOT NULL,
  location      GEOGRAPHY(POINT,4326),
  is_default    BOOLEAN DEFAULT FALSE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE refresh_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID,
  user_type  VARCHAR(20),   -- 'customer'|'supermarket'|'admin'
  token      TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PRODUCTS & INVENTORY
-- ============================================================

CREATE TABLE categories (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supermarket_id UUID REFERENCES supermarkets(id) ON DELETE CASCADE,
  name           VARCHAR(80) NOT NULL,
  icon           VARCHAR(10),
  sort_order     INT DEFAULT 0
);

CREATE TABLE products (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supermarket_id UUID REFERENCES supermarkets(id) ON DELETE CASCADE,
  category_id    UUID REFERENCES categories(id),
  name           VARCHAR(150) NOT NULL,
  description    TEXT,
  sku            VARCHAR(50),
  barcode        VARCHAR(50),
  price          NUMERIC(10,2) NOT NULL,
  mrp            NUMERIC(10,2),
  unit           VARCHAR(30) DEFAULT 'piece',     -- piece|kg|g|ml|L
  weight_grams   NUMERIC(8,2),                    -- for drone payload calc
  images         TEXT[] DEFAULT '{}',
  is_organic     BOOLEAN DEFAULT FALSE,
  is_available   BOOLEAN DEFAULT TRUE,
  stock_qty      INT DEFAULT 0,
  low_stock_at   INT DEFAULT 10,
  expiry_date    DATE,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  updated_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_products_supermarket ON products(supermarket_id);
CREATE INDEX idx_products_category    ON products(category_id);

-- ============================================================
-- DRONES
-- ============================================================

CREATE TABLE drones (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supermarket_id  UUID REFERENCES supermarkets(id) ON DELETE CASCADE,
  name            VARCHAR(60) NOT NULL,           -- e.g. "Drone Alpha-1"
  serial_number   VARCHAR(60) UNIQUE NOT NULL,
  model           VARCHAR(80),
  max_payload_kg  NUMERIC(5,2) DEFAULT 2.0,
  max_range_km    NUMERIC(5,2) DEFAULT 5.0,
  battery_pct     INT DEFAULT 100,
  status          VARCHAR(20) DEFAULT 'idle',     -- idle|charging|assigned|in_flight|returning|maintenance
  current_lat     DOUBLE PRECISION,
  current_lng     DOUBLE PRECISION,
  current_location GEOGRAPHY(POINT,4326),
  home_lat        DOUBLE PRECISION,
  home_lng        DOUBLE PRECISION,
  last_ping       TIMESTAMPTZ DEFAULT NOW(),
  total_deliveries INT DEFAULT 0,
  total_km        NUMERIC(10,2) DEFAULT 0,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE drone_telemetry (
  id         BIGSERIAL PRIMARY KEY,
  drone_id   UUID REFERENCES drones(id),
  lat        DOUBLE PRECISION NOT NULL,
  lng        DOUBLE PRECISION NOT NULL,
  altitude_m NUMERIC(6,2),
  speed_kmh  NUMERIC(6,2),
  battery_pct INT,
  heading    NUMERIC(6,2),
  recorded_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_telemetry_drone_time ON drone_telemetry(drone_id, recorded_at DESC);

-- ============================================================
-- ORDERS
-- ============================================================

CREATE TABLE orders (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number      VARCHAR(20) UNIQUE NOT NULL,  -- ORD-20240523-0001
  supermarket_id    UUID REFERENCES supermarkets(id),
  user_id           UUID REFERENCES users(id),
  address_id        UUID REFERENCES user_addresses(id),
  delivery_lat      DOUBLE PRECISION NOT NULL,
  delivery_lng      DOUBLE PRECISION NOT NULL,
  delivery_location GEOGRAPHY(POINT,4326),

  -- pricing
  subtotal          NUMERIC(10,2) NOT NULL,
  delivery_fee      NUMERIC(10,2) DEFAULT 25,
  discount          NUMERIC(10,2) DEFAULT 0,
  tax               NUMERIC(10,2) DEFAULT 0,
  total             NUMERIC(10,2) NOT NULL,

  -- coupon
  coupon_code       VARCHAR(30),

  -- status
  status            VARCHAR(30) DEFAULT 'pending',
  -- pending|confirmed|packing|packed|drone_assigned|
  -- drone_picked|in_flight|near_destination|landed|
  -- awaiting_pickup|delivered|cancelled|failed

  -- delivery
  delivery_type     VARCHAR(20) DEFAULT 'drone',  -- drone|manual
  estimated_minutes INT,
  drone_id          UUID REFERENCES drones(id),

  -- secret unlock code (6-digit, shown to customer after dispatch)
  unlock_code       VARCHAR(10),
  unlock_code_used  BOOLEAN DEFAULT FALSE,
  unlock_code_used_at TIMESTAMPTZ,

  -- timestamps
  placed_at         TIMESTAMPTZ DEFAULT NOW(),
  confirmed_at      TIMESTAMPTZ,
  packed_at         TIMESTAMPTZ,
  dispatched_at     TIMESTAMPTZ,
  delivered_at      TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,

  notes             TEXT,
  cancellation_reason TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_orders_user       ON orders(user_id);
CREATE INDEX idx_orders_supermarket ON orders(supermarket_id);
CREATE INDEX idx_orders_drone      ON orders(drone_id);
CREATE INDEX idx_orders_status     ON orders(status);

CREATE TABLE order_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID REFERENCES orders(id) ON DELETE CASCADE,
  product_id  UUID REFERENCES products(id),
  name        VARCHAR(150) NOT NULL,
  price       NUMERIC(10,2) NOT NULL,
  quantity    INT NOT NULL,
  subtotal    NUMERIC(10,2) NOT NULL
);

CREATE TABLE order_status_history (
  id         BIGSERIAL PRIMARY KEY,
  order_id   UUID REFERENCES orders(id),
  status     VARCHAR(30) NOT NULL,
  note       TEXT,
  created_by VARCHAR(20),   -- 'system'|'supermarket'|'customer'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PAYMENTS (CUSTOMER ORDERS)
-- ============================================================

CREATE TABLE order_payments (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id         UUID REFERENCES orders(id),
  user_id          UUID REFERENCES users(id),
  amount           NUMERIC(10,2) NOT NULL,
  currency         VARCHAR(5) DEFAULT 'INR',
  method           VARCHAR(30),   -- upi|card|wallet|cod|netbanking
  gateway          VARCHAR(20),   -- razorpay|stripe|cod
  gateway_order_id TEXT,
  gateway_pay_id   TEXT,
  gateway_signature TEXT,
  status           VARCHAR(20) DEFAULT 'pending',  -- pending|paid|failed|refunded
  refund_id        TEXT,
  refund_amount    NUMERIC(10,2),
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- COUPONS
-- ============================================================

CREATE TABLE coupons (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supermarket_id UUID REFERENCES supermarkets(id) ON DELETE CASCADE,
  code           VARCHAR(30) UNIQUE NOT NULL,
  description    TEXT,
  discount_type  VARCHAR(10) DEFAULT 'flat',   -- flat|percent
  discount_value NUMERIC(8,2) NOT NULL,
  min_order      NUMERIC(8,2) DEFAULT 0,
  max_discount   NUMERIC(8,2),
  usage_limit    INT,
  used_count     INT DEFAULT 0,
  valid_from     TIMESTAMPTZ DEFAULT NOW(),
  valid_until    TIMESTAMPTZ,
  is_active      BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- PLATFORM ADMIN
-- ============================================================

CREATE TABLE admins (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          VARCHAR(20) DEFAULT 'admin',
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- VIEWS
-- ============================================================

CREATE OR REPLACE VIEW v_nearby_supermarkets AS
SELECT
  s.id, s.name, s.slug, s.lat, s.lng,
  s.delivery_radius_km, s.is_open, s.logo_url,
  lp.name AS plan_name,
  COUNT(DISTINCT p.id) AS product_count,
  COUNT(DISTINCT d.id) AS drone_count
FROM supermarkets s
LEFT JOIN license_plans lp ON lp.id = s.license_plan_id
LEFT JOIN products p ON p.supermarket_id = s.id AND p.is_available = TRUE
LEFT JOIN drones d ON d.supermarket_id = s.id AND d.is_active = TRUE AND d.status = 'idle'
WHERE s.license_status IN ('trial','active')
GROUP BY s.id, lp.name;

-- Per-day order-number counter. Claimed atomically via
-- INSERT ... ON CONFLICT DO UPDATE ... RETURNING to avoid the race
-- where parallel createOrder calls computed the same SELECT COUNT(*)+1.
CREATE TABLE IF NOT EXISTS order_number_seq (
  order_date DATE PRIMARY KEY,
  last_seq   INT NOT NULL DEFAULT 0
);

-- auto-update updated_at
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_supermarkets_updated BEFORE UPDATE ON supermarkets FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_products_updated     BEFORE UPDATE ON products     FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_orders_updated       BEFORE UPDATE ON orders       FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_drones_updated       BEFORE UPDATE ON drones       FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
