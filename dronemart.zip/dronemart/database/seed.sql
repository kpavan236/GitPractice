-- ============================================================
-- DroneMart — Seed Data
-- ============================================================

-- Platform admin
INSERT INTO admins (name, email, password_hash, role) VALUES
  ('Platform Admin', 'admin@dronemart.io', '$2a$12$MHIpcAwOVwth4/kD3O7W7.Xg0ZgYJGKXY0yCv6.k1mfgmvizbhHDW', 'superadmin');
-- default password: Admin@1234

-- Sample supermarket (Bangalore)
INSERT INTO supermarkets (name, slug, owner_name, email, phone, password_hash,
  license_plan_id, license_status, license_expires,
  address, city, state, pincode, lat, lng,
  delivery_radius_km, is_open)
VALUES (
  'FreshMart Koramangala', 'freshmart-koramangala',
  'Rajesh Kumar', 'rajesh@freshmart.in', '+91 98765 43210',
  '$2a$12$MHIpcAwOVwth4/kD3O7W7.Xg0ZgYJGKXY0yCv6.k1mfgmvizbhHDW',
  (SELECT id FROM license_plans WHERE name='Growth'),
  'active', NOW() + INTERVAL '1 year',
  '14, 5th Cross, Koramangala 4th Block', 'Bangalore', 'Karnataka', '560034',
  12.9352, 77.6245,
  5.0, TRUE
);

-- Categories for FreshMart
WITH sm AS (SELECT id FROM supermarkets WHERE slug='freshmart-koramangala')
INSERT INTO categories (supermarket_id, name, icon, sort_order) VALUES
  ((SELECT id FROM sm), 'Vegetables', '🥦', 1),
  ((SELECT id FROM sm), 'Fruits',     '🍎', 2),
  ((SELECT id FROM sm), 'Dairy',      '🥛', 3),
  ((SELECT id FROM sm), 'Bakery',     '🍞', 4),
  ((SELECT id FROM sm), 'Grains',     '🌾', 5),
  ((SELECT id FROM sm), 'Personal Care','🧴',6);

-- Products
WITH sm AS (SELECT id FROM supermarkets WHERE slug='freshmart-koramangala'),
     cat_veg AS (SELECT id FROM categories WHERE name='Vegetables' AND supermarket_id=(SELECT id FROM sm)),
     cat_frt AS (SELECT id FROM categories WHERE name='Fruits'     AND supermarket_id=(SELECT id FROM sm)),
     cat_dry AS (SELECT id FROM categories WHERE name='Dairy'      AND supermarket_id=(SELECT id FROM sm)),
     cat_bak AS (SELECT id FROM categories WHERE name='Bakery'     AND supermarket_id=(SELECT id FROM sm))
INSERT INTO products (supermarket_id, category_id, name, sku, price, mrp, unit, weight_grams, is_organic, stock_qty) VALUES
  ((SELECT id FROM sm),(SELECT id FROM cat_veg),'Broccoli',        'VEG-001', 45,  60, 'piece',  400, TRUE,  80),
  ((SELECT id FROM sm),(SELECT id FROM cat_veg),'Baby Carrots 250g','VEG-002', 38,  50, 'pack',   250, TRUE,  60),
  ((SELECT id FROM sm),(SELECT id FROM cat_veg),'Pearl Onions 500g','VEG-003', 35,  45, 'pack',   500, FALSE,145),
  ((SELECT id FROM sm),(SELECT id FROM cat_veg),'Tomatoes 500g',   'VEG-004', 42,  55, 'pack',   500, TRUE,  90),
  ((SELECT id FROM sm),(SELECT id FROM cat_frt),'Royal Gala Apples','FRT-001',120, 140, 'pack',   900, FALSE, 34),
  ((SELECT id FROM sm),(SELECT id FROM cat_frt),'Fresh Lemons 4pc','FRT-002', 28,  35, 'pack',   160, FALSE, 75),
  ((SELECT id FROM sm),(SELECT id FROM cat_dry),'Amul Milk 500ml', 'DRY-001', 29,  32, 'bottle', 500, FALSE,210),
  ((SELECT id FROM sm),(SELECT id FROM cat_dry),'Amul Cheese 200g','DRY-002', 85, 100, 'pack',   200, FALSE, 42),
  ((SELECT id FROM sm),(SELECT id FROM cat_dry),'Eggs 6pc',        'DRY-003', 68,  75, 'pack',   360, FALSE,120),
  ((SELECT id FROM sm),(SELECT id FROM cat_bak),'Brown Bread 400g','BAK-001', 45,  52, 'loaf',   400, FALSE, 56);

-- Drones
WITH sm AS (SELECT id FROM supermarkets WHERE slug='freshmart-koramangala')
INSERT INTO drones (supermarket_id, name, serial_number, model, max_payload_kg, max_range_km,
  battery_pct, status, current_lat, current_lng, home_lat, home_lng) VALUES
  ((SELECT id FROM sm),'Alpha-1','DRN-SM-001','DJI Agras T30', 2.0, 5.0, 100,'idle', 12.9352,77.6245, 12.9352,77.6245),
  ((SELECT id FROM sm),'Alpha-2','DRN-SM-002','DJI Agras T30', 2.0, 5.0,  87,'idle', 12.9352,77.6245, 12.9352,77.6245),
  ((SELECT id FROM sm),'Beta-1', 'DRN-SM-003','Skydio 2+',     1.5, 4.0,  65,'charging',12.9352,77.6245, 12.9352,77.6245);

-- Sample coupon
WITH sm AS (SELECT id FROM supermarkets WHERE slug='freshmart-koramangala')
INSERT INTO coupons (supermarket_id, code, description, discount_type, discount_value, min_order, valid_until) VALUES
  ((SELECT id FROM sm),'FRESH20','₹60 off on orders above ₹150','flat', 60, 150, NOW() + INTERVAL '30 days'),
  ((SELECT id FROM sm),'DRONE10','10% off on drone delivery',   'percent',10,  99, NOW() + INTERVAL '60 days');

-- Sample customer
INSERT INTO users (name, email, phone, password_hash, is_verified) VALUES
  ('Arjun Sharma', 'arjun@example.com', '+91 98765 43210',
   '$2a$12$MHIpcAwOVwth4/kD3O7W7.Xg0ZgYJGKXY0yCv6.k1mfgmvizbhHDW', TRUE);
-- password: Admin@1234

WITH u AS (SELECT id FROM users WHERE email='arjun@example.com')
INSERT INTO user_addresses (user_id, label, name, phone, line1, city, state, pincode, lat, lng, is_default) VALUES
  ((SELECT id FROM u), 'Home', 'Arjun Sharma', '+91 98765 43210',
   '14, 5th Cross Rd, Koramangala 4th Block', 'Bangalore', 'Karnataka', '560034',
   12.9279, 77.6271, TRUE);
