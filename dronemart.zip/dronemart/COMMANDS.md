# DroneMart — Commands Reference

Day-to-day reference for running, debugging, and demoing the DroneMart stack.

## Test credentials

| Role        | URL                                    | Email                     | Password   |
|-------------|----------------------------------------|---------------------------|------------|
| Customer    | http://localhost:3000/customer/        | `arjun@example.com`       | `Admin@1234` |
| Supermarket | http://localhost:3000/supermarket/     | `rajesh@freshmart.in`     | `Admin@1234` |
| Admin       | http://localhost:3000/admin/           | `admin@dronemart.io`      | `Admin@1234` |
| API health  | http://localhost:4000/health           | —                         | —          |
| MQTT broker | `localhost:1883` (no auth, dev only)   | —                         | —          |

---

## Stack lifecycle

```bash
# Start everything (first time / after code changes)
docker compose up -d --build

# Subsequent starts (uses cached images)
docker compose up -d

# What's running?
docker compose ps

# Stop everything (keeps DB volume)
docker compose down

# Stop + WIPE DB volume (forces re-seed; loses all orders/data)
docker compose down -v
```

---

## Rebuilding one service

The backend's `src/` and frontend's HTML are **baked into the image at build time**,
so plain `restart` doesn't pick up code edits. Use `--build`:

```bash
docker compose up -d --build api          # after backend code change
docker compose up -d --build frontend     # after customer/supermarket/admin HTML change
docker compose up -d --build bridge       # after bridge code change

docker compose restart api                # ONLY for env-var-only changes (no code change)
```

---

## Switching drone modes

```bash
# In-process simulator (default — everything self-contained in api)
DRONE_MODE=simulator docker compose up -d --build api

# MQTT mode (api ↔ broker ↔ bridge)
DRONE_MODE=mqtt docker compose up -d --build api bridge mqtt-broker

# Check current mode
docker exec dronemart_api sh -c 'echo $DRONE_MODE'

# Adjust simulator speed (default 10× faster than real time)
DRONE_SIMULATION_SPEED_MULTIPLIER=20 docker compose up -d --build api bridge
```

---

## Logs

```bash
docker logs dronemart_api      -f --tail 50     # API
docker logs dronemart_bridge   -f                # MQTT bridge
docker logs dronemart_mqtt     -f                # MQTT broker
docker logs dronemart_db       -f --tail 50     # PostgreSQL
docker logs dronemart_frontend -f                # nginx
docker compose logs -f                           # all services interleaved
```

---

## Database

```bash
# Open psql shell
docker exec -it dronemart_db psql -U dronemart -d dronemart

# One-off query
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "SELECT name, status, battery_pct FROM drones;"

# Reset all drones to idle/100% (recover from any stuck state)
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "UPDATE drones SET status='idle', battery_pct=100, current_lat=home_lat, current_lng=home_lng;"

# See recent orders + their statuses
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "SELECT order_number, status, placed_at FROM orders ORDER BY placed_at DESC LIMIT 10;"

# Full audit trail of one order
ORDER='ORD-20260525-0001'
docker exec dronemart_db psql -U dronemart -d dronemart -c "
  SELECT to_char(created_at,'HH24:MI:SS') AS t, status, created_by, note
  FROM order_status_history h JOIN orders o ON o.id=h.order_id
  WHERE o.order_number='$ORDER' ORDER BY created_at;"

# Daily order-number counter (after the race-fix)
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "SELECT * FROM order_number_seq ORDER BY order_date DESC;"
```

---

## MQTT debugging

```bash
# Watch every message that crosses the broker
docker exec -it dronemart_mqtt mosquitto_sub -t 'drones/#' -v -h localhost

# Only commands the api sends
docker exec -it dronemart_mqtt mosquitto_sub -t 'drones/+/commands/#' -v -h localhost

# Only events from drones (skip noisy telemetry)
docker exec -it dronemart_mqtt mosquitto_sub -t 'drones/+/events' -v -h localhost

# Manually publish (testing abort)
docker exec dronemart_mqtt mosquitto_pub \
  -t "drones/DRONE_ID/commands/abort" -m '{"reason":"manual"}' -h localhost

# Check broker is reachable from the api container
docker exec dronemart_api node -e "
  const m=require('mqtt');
  const c=m.connect('mqtt://mqtt-broker:1883');
  c.on('connect',()=>{console.log('OK');c.end();});"
```

---

## Browser portals — recovery moves

When state gets stale (after a long break, mid-flight stuck order, JWT expired
beyond the refresh window), open DevTools on the affected tab and run:

```js
// Wipe everything (customer / supermarket / admin — run on the affected tab)
localStorage.clear(); location.reload();

// Just clear the customer's stale order pointer
localStorage.removeItem('dm_active_order');
localStorage.removeItem('dm_tab');
location.reload();
```

---

## API smoke tests (curl)

```bash
# Customer login → save token
CUST=$(curl -s -X POST http://localhost:4000/api/auth/customer/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"arjun@example.com","password":"Admin@1234"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['access'])")

# Supermarket login
SM_TOKEN=$(curl -s -X POST http://localhost:4000/api/auth/supermarket/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"rajesh@freshmart.in","password":"Admin@1234"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['access'])")

# Admin login
ADMIN=$(curl -s -X POST http://localhost:4000/api/auth/admin/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@dronemart.io","password":"Admin@1234"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['access'])")

# Place an order (one-liner against the seeded store + customer)
ADDR=$(curl -s http://localhost:4000/api/customer/addresses \
  -H "Authorization: Bearer $CUST" \
  | python3 -c "import sys,json;print(json.load(sys.stdin)[0]['id'])")
SM=$(curl -s "http://localhost:4000/api/supermarkets/nearby?lat=12.9352&lng=77.6245&radius=20" \
  | python3 -c "import sys,json;print(json.load(sys.stdin)[0]['id'])")
PROD=$(curl -s "http://localhost:4000/api/supermarkets/$SM/products" \
  | python3 -c "import sys,json;print(json.load(sys.stdin)[0]['id'])")
curl -s -X POST http://localhost:4000/api/orders \
  -H "Authorization: Bearer $CUST" -H 'Content-Type: application/json' \
  -d "{\"supermarketId\":\"$SM\",\"addressId\":\"$ADDR\",\"items\":[{\"productId\":\"$PROD\",\"quantity\":1}],\"paymentMethod\":\"cod\"}"

# Advance an order (supermarket-side)
ORDER='ORDER_UUID_HERE'
curl -s -X PATCH http://localhost:4000/api/supermarket/orders/$ORDER/status \
  -H "Authorization: Bearer $SM_TOKEN" -H 'Content-Type: application/json' \
  -d '{"status":"packing"}'

# Get one order with full state (customer)
curl -s http://localhost:4000/api/orders/$ORDER -H "Authorization: Bearer $CUST" | python3 -m json.tool

# Drones list (supermarket)
curl -s http://localhost:4000/api/supermarket/drones -H "Authorization: Bearer $SM_TOKEN" | python3 -m json.tool

# All orders across platform (admin)
curl -s http://localhost:4000/api/admin/orders -H "Authorization: Bearer $ADMIN" | python3 -m json.tool
```

---

## Common recovery moves

```bash
# Drones stuck mid-flight (after API restart killed simulator timers)
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "UPDATE drones SET status='idle';"

# Order stuck for unclear reason — nuke it from orbit
ORDER='UUID'
docker exec dronemart_db psql -U dronemart -d dronemart -c "
  DELETE FROM order_status_history WHERE order_id='$ORDER';
  DELETE FROM order_items          WHERE order_id='$ORDER';
  DELETE FROM orders               WHERE id='$ORDER';"

# JWT errors after a long pause (1h access TTL, 7d refresh TTL)
# Easiest: log out + back in. Or in browser console:
#   localStorage.clear(); location.reload();

# Bridge / broker connection issues
docker compose restart bridge mqtt-broker
```

---

## Generated artefacts

```bash
# Investor pitch deck
open /Users/pkamisetti/Downloads/dronemart/dronemart_pitch.pptx

# Regenerate after editing build_deck.py
python3 build_deck.py && open dronemart_pitch.pptx
```

---

## TL;DR — most-used flows

```bash
# Day-to-day dev cycle after editing backend or frontend
docker compose up -d --build api frontend       # rebuilds + restarts only what's needed

# Reset before a clean demo
docker exec dronemart_db psql -U dronemart -d dronemart \
  -c "UPDATE drones SET status='idle', battery_pct=100, current_lat=home_lat, current_lng=home_lng;"
# + on each browser tab:  localStorage.clear(); location.reload();

# Watch the lifecycle live during a demo
docker logs -f dronemart_bridge
# or
docker exec -it dronemart_mqtt mosquitto_sub -t 'drones/#' -v -h localhost
```

---

## Architecture quick-reference

```
┌──────────────────────────────────────────────────────────────────────┐
│ docker-compose services                                              │
│                                                                       │
│   db          PostgreSQL + PostGIS + earthdistance/cube              │
│   api         Node.js Express + Socket.IO + MQTT client              │
│   frontend    nginx serving 3 SPAs: /customer/  /supermarket/  /admin│
│   bridge      Node.js — translates MQTT ↔ drone source               │
│   mqtt-broker eclipse-mosquitto                                      │
│   px4-sitl    (commented out) PX4 firmware in SITL, for MAVLink dev  │
│                                                                       │
└──────────────────────────────────────────────────────────────────────┘

  DRONE_MODE=simulator              DRONE_MODE=mqtt
  ──────────────────────            ────────────────────────────────
  api runs in-process               api ←→ mqtt-broker ←→ bridge
  simulateDroneFlight()                                      │
                                                             ├─ mock-drone (default)
                                                             └─ mavlink-drone (stub for PX4-SITL / real drone)
```
