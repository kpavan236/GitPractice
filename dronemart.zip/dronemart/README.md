# 🚁 DroneMart — Drone Delivery Supermarket Platform

Multi-tenant SaaS: supermarkets register with a license plan, manage drone fleets,
and customers order groceries for live drone delivery with secret box-unlock codes.

---

## 📦 Project structure

```
dronemart/
├── docker-compose.yml          ← main compose file (dev)
├── docker-compose.prod.yml     ← production overrides
├── .env.example                ← copy to .env
├── Makefile                    ← shortcut commands
│
├── backend/
│   ├── Dockerfile
│   └── src/                   controllers · middleware · routes · websocket
│
├── frontend/
│   ├── Dockerfile              nginx:alpine
│   ├── nginx.conf
│   ├── customer/index.html     customer React app
│   └── supermarket/index.html  admin portal React app
│
└── database/
    ├── schema.sql              auto-run on first boot
    └── seed.sql                demo data
```

---

## 🐳 Docker setup (3 steps)

### Prerequisites

| Tool | Min version |
|------|-------------|
| Docker | 24+ |
| Docker Compose | v2 (bundled with Docker Desktop) |

```bash
docker --version          # Docker version 24.x.x
docker compose version    # Docker Compose version v2.x.x
```

---

### Step 1 — Configure

```bash
unzip dronemart.zip && cd dronemart
cp .env.example .env
```

Edit `.env` — minimum required changes:

```dotenv
DB_PASSWORD=pick_a_strong_password
JWT_SECRET=any_64_character_random_string
JWT_REFRESH_SECRET=a_different_64_character_random_string
RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx      # optional for dev
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxx   # optional for dev
```

---

### Step 2 — Start

```bash
docker compose up --build -d
```

This starts 3 containers:

| Container | Image | Role |
|-----------|-------|------|
| `dronemart_db` | postgis/postgis:15-3.3-alpine | PostgreSQL + PostGIS |
| `dronemart_api` | node:18-alpine (built) | Express API + Socket.IO |
| `dronemart_frontend` | nginx:1.25-alpine (built) | Serves both React apps |

Schema + seed data load automatically on first boot.

---

### Step 3 — Open

| App | URL |
|-----|-----|
| Landing page | http://localhost:3000 |
| Customer app | http://localhost:3000/customer/ |
| Supermarket portal | http://localhost:3000/supermarket/ |
| REST API | http://localhost:4000 |
| Health check | http://localhost:4000/health |
| PostgreSQL | localhost:5432 |

---

## 🔑 Demo credentials

| Role | Email | Password |
|------|-------|----------|
| Customer | arjun@example.com | Admin@1234 |
| Supermarket | rajesh@freshmart.in | Admin@1234 |

---

## 🛠️ Makefile shortcuts

```bash
make up          # build and start everything
make down        # stop containers
make logs        # follow all logs
make api-logs    # API logs only
make ps          # list running containers
make db-shell    # psql inside DB container
make api-shell   # sh inside API container
make reset       # wipe DB volume and rebuild
make prod-up     # start with production overrides
```

---

## 🔄 Common operations

```bash
# View logs
docker compose logs -f
docker compose logs -f api

# Restart one service
docker compose restart api

# Open psql
docker exec -it dronemart_db psql -U dronemart -d dronemart

# Rebuild after code change
docker compose up --build -d api
docker compose up --build -d frontend

# Full reset (wipes all data)
docker compose down -v && docker compose up --build -d
```

---

## 🚀 Production

```bash
# Use production overrides
docker compose -f docker-compose.yml -f docker-compose.prod.yml up --build -d
```

Production overrides: hides DB port, disables drone simulation, maps port 80/443.

Add SSL certs to `ssl/` and update `frontend/nginx.conf` with HTTPS server block.

---

## 🌐 Container networking

```
Browser
  ├── :3000  →  dronemart_frontend (nginx)
  ├── :4000  →  dronemart_api  (Node.js + Socket.IO)
  └── :5432  →  dronemart_db   (PostgreSQL) — dev only

API connects to db using hostname "db" (internal Docker network).
```

---

## 🔐 Unlock code flow

```
Order placed → Supermarket packs → Assigns drone
  → 6-digit code generated + stored on order
  → Drone dispatched → GPS streamed via WebSocket
  → Drone lands → code revealed to customer
  → Customer enters code → POST /api/orders/:id/unlock
  → Box opens → order delivered → drone returns home
```
