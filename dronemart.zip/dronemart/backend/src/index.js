require('dotenv').config();
const express    = require('express');
const http       = require('http');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const { initSocket } = require('./websocket/socket');
const mqttClient = require('./mqtt/client');
const routes     = require('./routes');

const app    = express();
const server = http.createServer(app);

// ── WebSocket ───────────────────────────────────────────────
initSocket(server);

// ── MQTT (only when DRONE_MODE=mqtt) ────────────────────────
mqttClient.init();

// ── Security middleware ─────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: (process.env.CORS_ORIGINS || '').split(','),
  credentials: true,
}));
app.use(express.json({ limit: '2mb' }));

// Rate limiting. /api/auth stays tight to slow down credential-stuffing.
// /api is more permissive because the supermarket + admin polling backstops
// + per-order WebSocket re-fetches add up fast with multiple tabs open.
// Returns JSON so the frontend's response.json() doesn't blow up.
const jsonRateLimit = (opts) => rateLimit({
  ...opts,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res, next, options) => {
    res.status(options.statusCode).json({
      error: 'Too many requests — slow down a moment.',
      retryAfter: res.getHeader('Retry-After'),
    });
  },
});
app.use('/api/auth', jsonRateLimit({ windowMs: 15 * 60 * 1000, max: 50  }));
app.use('/api',      jsonRateLimit({ windowMs: 1  * 60 * 1000, max: 1200 }));

// ── Routes ──────────────────────────────────────────────────
app.use('/api', routes);

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok', ts: new Date() }));

// ── Error handler ───────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

// ── Start ───────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════╗
  ║   DroneMart API — running on :${PORT}   ║
  ║   WebSocket ready                    ║
  ╚══════════════════════════════════════╝`);
});
