const express = require('express');
const router  = express.Router();
const { requireAuth } = require('../middleware/auth');

const auth  = require('../controllers/auth.controller');
const sm    = require('../controllers/supermarket.controller');
const ord   = require('../controllers/order.controller');
const admin = require('../controllers/admin.controller');

// ── Auth ────────────────────────────────────────────────────
router.post('/auth/customer/register',      auth.customerRegister);
router.post('/auth/customer/login',         auth.customerLogin);
router.post('/auth/supermarket/register',   auth.supermarketRegister);
router.post('/auth/supermarket/login',      auth.supermarketLogin);
router.post('/auth/admin/login',            auth.adminLogin);
router.post('/auth/refresh',                auth.refreshToken);

// ── License plans (public) ──────────────────────────────────
router.get('/plans', async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query('SELECT * FROM license_plans WHERE is_active=TRUE ORDER BY price_monthly');
  res.json(rows);
});

// ── Public: nearby supermarkets, products ───────────────────
router.get('/supermarkets/nearby',              sm.getNearby);
router.get('/supermarkets/:id/products',        sm.getProducts);
router.get('/supermarkets/:id/categories',      sm.getCategories);

// ── Customer (authenticated) ────────────────────────────────
const cAuth = requireAuth('customer');

router.get('/customer/profile', cAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query('SELECT id,name,email,phone FROM users WHERE id=$1', [req.user.id]);
  res.json(rows[0]);
});
router.get('/customer/addresses', cAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query('SELECT * FROM user_addresses WHERE user_id=$1 ORDER BY is_default DESC', [req.user.id]);
  res.json(rows);
});
router.post('/customer/addresses', cAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { label, name, phone, line1, line2, city, state, pincode, lat, lng, isDefault } = req.body;
  if (isDefault) await query('UPDATE user_addresses SET is_default=FALSE WHERE user_id=$1', [req.user.id]);
  const { rows } = await query(
    `INSERT INTO user_addresses (user_id,label,name,phone,line1,line2,city,state,pincode,lat,lng,is_default)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [req.user.id, label, name, phone, line1, line2||null, city, state, pincode, lat, lng, isDefault||false]
  );
  res.status(201).json(rows[0]);
});
router.get('/customer/orders', cAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query(
    `SELECT o.*, json_agg(json_build_object('name',oi.name,'qty',oi.quantity)) AS items
     FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
     WHERE o.user_id=$1 GROUP BY o.id ORDER BY o.placed_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});
router.post('/orders',                  cAuth, ord.createOrder);
router.get ('/orders/:id',              cAuth, ord.getOrder);
router.post('/orders/:id/verify-payment', cAuth, ord.verifyPayment);
router.post('/orders/:id/unlock',       cAuth, ord.unlockBox);
router.get ('/orders/:id/livestream',   cAuth, ord.getLivestream);

// ── Supermarket Admin (authenticated) ───────────────────────
const smAuth = requireAuth('supermarket');

router.get ('/supermarket/profile',     smAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query(
    `SELECT s.*, lp.name AS plan_name, lp.max_drones, lp.max_products, lp.features
     FROM supermarkets s LEFT JOIN license_plans lp ON lp.id=s.license_plan_id
     WHERE s.id=$1`, [req.user.id]
  );
  res.json(rows[0]);
});
router.get ('/supermarket/orders',      smAuth, sm.getOrders);
router.patch('/supermarket/orders/:id/status', smAuth, sm.updateOrderStatus);
router.post('/supermarket/orders/:id/assign-drone', smAuth, ord.assignDrone);
router.get ('/supermarket/orders/:id/livestream', smAuth, ord.getSupermarketLivestream);
router.get ('/supermarket/drones',      smAuth, sm.getDrones);
router.post('/supermarket/drones',      smAuth, sm.addDrone);
router.patch('/supermarket/drones/:id', smAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { status, batteryPct } = req.body;
  const { rows } = await query(
    'UPDATE drones SET status=COALESCE($1,status), battery_pct=COALESCE($2,battery_pct) WHERE id=$3 AND supermarket_id=$4 RETURNING *',
    [status||null, batteryPct||null, req.params.id, req.user.id]
  );
  res.json(rows[0]);
});
router.get ('/supermarket/products',    smAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { rows } = await query(
    'SELECT p.*,c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.supermarket_id=$1 ORDER BY c.sort_order,p.name',
    [req.user.id]
  );
  res.json(rows);
});
router.post('/supermarket/products',    smAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const { categoryId, name, description, sku, price, mrp, unit, weightGrams, isOrganic, stockQty } = req.body;
  const { rows } = await query(
    `INSERT INTO products (supermarket_id,category_id,name,description,sku,price,mrp,unit,weight_grams,is_organic,stock_qty)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [req.user.id, categoryId, name, description, sku, price, mrp||null, unit||'piece', weightGrams||null, isOrganic||false, stockQty||0]
  );
  res.status(201).json(rows[0]);
});
router.patch('/supermarket/products/:id', smAuth, async (req, res) => {
  const { query } = require('../utils/db');
  const fields = ['name','price','mrp','stock_qty','is_available'];
  const updates = []; const vals = [];
  fields.forEach(f => { if (req.body[f] !== undefined) { vals.push(req.body[f]); updates.push(`${f}=$${vals.length}`); } });
  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  vals.push(req.params.id, req.user.id);
  const { rows } = await query(
    `UPDATE products SET ${updates.join(',')} WHERE id=$${vals.length-1} AND supermarket_id=$${vals.length} RETURNING *`, vals
  );
  res.json(rows[0]);
});
router.get('/supermarket/analytics',    smAuth, sm.getAnalytics);

// ── Platform Admin (authenticated) ──────────────────────────
const aAuth = requireAuth('admin');
router.get('/admin/supermarkets', aAuth, admin.listSupermarkets);
router.get('/admin/orders',       aAuth, admin.listOrders);

// ── Coupon validation (customer) ────────────────────────────
router.post('/coupons/validate', cAuth, async (req, res) => {
  const { code, supermarketId, orderTotal } = req.body;
  const { query } = require('../utils/db');
  const { rows } = await query(
    `SELECT * FROM coupons WHERE code=$1 AND supermarket_id=$2
     AND is_active=TRUE AND (valid_until IS NULL OR valid_until>NOW())
     AND (usage_limit IS NULL OR used_count<usage_limit)`,
    [code, supermarketId]
  );
  if (!rows.length) return res.status(404).json({ error: 'Invalid or expired coupon' });
  const cp = rows[0];
  if (parseFloat(orderTotal) < parseFloat(cp.min_order)) {
    return res.status(400).json({ error: `Minimum order ₹${cp.min_order} required` });
  }
  const discount = cp.discount_type === 'flat'
    ? parseFloat(cp.discount_value)
    : Math.min(orderTotal * cp.discount_value / 100, cp.max_discount || Infinity);
  res.json({ valid: true, discount: Math.round(discount), coupon: cp });
});

module.exports = router;
