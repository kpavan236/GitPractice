const bcrypt = require('bcryptjs');
const { query, withTransaction } = require('../utils/db');
const { createTokens, verifyRefresh } = require('../middleware/auth');

// ── Customer Auth ──────────────────────────────────────────

exports.customerRegister = async (req, res) => {
  const { name, email, phone, password } = req.body;
  try {
    const exists = await query('SELECT id FROM users WHERE email=$1 OR phone=$2', [email, phone]);
    if (exists.rows.length) return res.status(409).json({ error: 'Email or phone already registered' });

    const hash = await bcrypt.hash(password, 12);
    const { rows } = await query(
      `INSERT INTO users (name,email,phone,password_hash) VALUES ($1,$2,$3,$4) RETURNING id,name,email,phone`,
      [name, email, phone, hash]
    );
    const tokens = createTokens({ id: rows[0].id, type: 'customer' });
    res.status(201).json({ user: rows[0], ...tokens });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.customerLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const { rows } = await query('SELECT * FROM users WHERE email=$1 AND is_active=TRUE', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const user = rows[0];
    const tokens = createTokens({ id: user.id, type: 'customer' });
    res.json({ user: { id: user.id, name: user.name, email: user.email, phone: user.phone }, ...tokens });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Supermarket Auth ───────────────────────────────────────

exports.supermarketRegister = async (req, res) => {
  const { name, ownerName, email, phone, password, planId, address, city, state, pincode, lat, lng } = req.body;
  try {
    const exists = await query('SELECT id FROM supermarkets WHERE email=$1', [email]);
    if (exists.rows.length) return res.status(409).json({ error: 'Email already registered' });

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const hash = await bcrypt.hash(password, 12);

    const { rows } = await query(
      `INSERT INTO supermarkets
         (name,slug,owner_name,email,phone,password_hash,license_plan_id,license_status,
          address,city,state,pincode,lat,lng)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'trial',$8,$9,$10,$11,$12,$13)
       RETURNING id,name,slug,email,license_status,trial_ends`,
      [name, slug, ownerName, email, phone, hash, planId, address, city, state, pincode, lat, lng]
    );
    const tokens = createTokens({ id: rows[0].id, type: 'supermarket' });
    res.status(201).json({ supermarket: rows[0], ...tokens });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.supermarketLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const { rows } = await query('SELECT * FROM supermarkets WHERE email=$1', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const sm = rows[0];
    if (sm.license_status === 'suspended') {
      return res.status(403).json({ error: 'Account suspended. Contact support.' });
    }

    const tokens = createTokens({ id: sm.id, type: 'supermarket' });
    res.json({
      supermarket: { id: sm.id, name: sm.name, slug: sm.slug, email: sm.email, license_status: sm.license_status },
      ...tokens
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Admin Auth ─────────────────────────────────────────────

exports.adminLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const { rows } = await query('SELECT * FROM admins WHERE email=$1', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const a = rows[0];
    const tokens = createTokens({ id: a.id, type: 'admin' });
    res.json({ admin: { id: a.id, name: a.name, email: a.email, role: a.role }, ...tokens });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Shared refresh ─────────────────────────────────────────

exports.refreshToken = async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'Refresh token required' });
  try {
    const decoded = verifyRefresh(refreshToken);
    const tokens = createTokens({ id: decoded.id, type: decoded.type });
    res.json(tokens);
  } catch {
    res.status(401).json({ error: 'Invalid refresh token' });
  }
};
