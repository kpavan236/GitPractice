const { query } = require('../utils/db');

// GET /api/supermarkets/nearby?lat=&lng=&radius=
exports.getNearby = async (req, res) => {
  const { lat, lng, radius = 10 } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat and lng are required' });

  try {
    const { rows } = await query(
      `SELECT s.id, s.name, s.slug, s.lat, s.lng, s.logo_url,
              s.is_open, s.delivery_radius_km,
              s.open_time, s.close_time,
              COUNT(DISTINCT p.id) AS product_count,
              COUNT(DISTINCT d.id) FILTER (WHERE d.status='idle') AS available_drones,
              ROUND(
                (point($1,$2) <@> point(s.lng,s.lat))::numeric * 1.60934, 2
              ) AS distance_km
       FROM supermarkets s
       LEFT JOIN products p ON p.supermarket_id=s.id AND p.is_available=TRUE
       LEFT JOIN drones d ON d.supermarket_id=s.id AND d.is_active=TRUE
       WHERE s.license_status IN ('trial','active')
         AND (point($1,$2) <@> point(s.lng,s.lat)) * 1.60934 <= $3
       GROUP BY s.id
       ORDER BY distance_km ASC
       LIMIT 20`,
      [lng, lat, radius]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/supermarkets/:id/products
exports.getProducts = async (req, res) => {
  const { id } = req.params;
  const { category, search, page = 1, limit = 40 } = req.query;
  const offset = (page - 1) * limit;

  let whereExtra = '';
  const params = [id, limit, offset];
  if (category) { params.push(category); whereExtra += ` AND c.id=$${params.length}`; }
  if (search)   { params.push(`%${search}%`); whereExtra += ` AND p.name ILIKE $${params.length}`; }

  const { rows } = await query(
    `SELECT p.*, c.name AS category_name, c.icon AS category_icon
     FROM products p
     JOIN categories c ON c.id=p.category_id
     WHERE p.supermarket_id=$1 AND p.is_available=TRUE ${whereExtra}
     ORDER BY c.sort_order, p.name
     LIMIT $2 OFFSET $3`,
    params
  );
  res.json(rows);
};

// GET /api/supermarkets/:id/categories
exports.getCategories = async (req, res) => {
  const { rows } = await query(
    `SELECT c.*, COUNT(p.id) AS product_count
     FROM categories c
     LEFT JOIN products p ON p.category_id=c.id AND p.is_available=TRUE
     WHERE c.supermarket_id=$1
     GROUP BY c.id ORDER BY c.sort_order`,
    [req.params.id]
  );
  res.json(rows);
};

// GET /api/supermarkets/:id/drones  (supermarket admin)
exports.getDrones = async (req, res) => {
  const smId = req.user.id;
  const { rows } = await query(
    `SELECT * FROM drones WHERE supermarket_id=$1 ORDER BY name`, [smId]
  );
  res.json(rows);
};

// POST /api/supermarkets/drones  (add drone)
exports.addDrone = async (req, res) => {
  const smId = req.user.id;
  const { name, serialNumber, model, maxPayloadKg, maxRangeKm } = req.body;

  // Check plan limit
  const { rows: planRows } = await query(
    `SELECT lp.max_drones, COUNT(d.id) AS current
     FROM supermarkets sm
     JOIN license_plans lp ON lp.id=sm.license_plan_id
     LEFT JOIN drones d ON d.supermarket_id=sm.id AND d.is_active=TRUE
     WHERE sm.id=$1 GROUP BY lp.max_drones`,
    [smId]
  );
  if (planRows.length && parseInt(planRows[0].current) >= parseInt(planRows[0].max_drones)) {
    return res.status(403).json({ error: 'Drone limit reached for your plan. Upgrade to add more.' });
  }

  const sm = await query('SELECT lat,lng FROM supermarkets WHERE id=$1', [smId]);
  const { lat, lng } = sm.rows[0];

  const { rows } = await query(
    `INSERT INTO drones (supermarket_id,name,serial_number,model,max_payload_kg,max_range_km,
       current_lat,current_lng,home_lat,home_lng)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$7,$8) RETURNING *`,
    [smId, name, serialNumber, model || 'Custom', maxPayloadKg || 2.0, maxRangeKm || 5.0, lat, lng]
  );
  res.status(201).json(rows[0]);
};

// GET /api/supermarkets/orders (supermarket sees its orders)
exports.getOrders = async (req, res) => {
  const smId = req.user.id;
  const { status, page = 1 } = req.query;
  const offset = (page - 1) * 20;
  const params = [smId, 20, offset];
  let where = '';
  if (status) { params.push(status); where = `AND o.status=$${params.length}`; }

  const { rows } = await query(
    `SELECT o.*, u.name AS customer_name, u.phone AS customer_phone,
            ua.line1 AS addr_line1, ua.city AS addr_city,
            d.name AS drone_name,
            json_agg(json_build_object('name',oi.name,'qty',oi.quantity,'subtotal',oi.subtotal)) AS items
     FROM orders o
     JOIN users u ON u.id=o.user_id
     LEFT JOIN user_addresses ua ON ua.id=o.address_id
     LEFT JOIN drones d ON d.id=o.drone_id
     LEFT JOIN order_items oi ON oi.order_id=o.id
     WHERE o.supermarket_id=$1 ${where}
     GROUP BY o.id,u.name,u.phone,ua.line1,ua.city,d.name
     ORDER BY o.placed_at DESC
     LIMIT $2 OFFSET $3`,
    params
  );
  res.json(rows);
};

// PATCH /api/supermarkets/orders/:id/status
exports.updateOrderStatus = async (req, res) => {
  const { id } = req.params;
  const { status, note } = req.body;
  const smId = req.user.id;
  const allowed = ['confirmed','packing','packed','cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status transition' });

  const { rows } = await query(
    `UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2 AND supermarket_id=$3 RETURNING *`,
    [status, id, smId]
  );
  if (!rows.length) return res.status(404).json({ error: 'Order not found' });

  await query(
    `INSERT INTO order_status_history (order_id,status,note,created_by) VALUES ($1,$2,$3,'supermarket')`,
    [id, status, note || '']
  );

  const { emitToRoom } = require('../websocket/socket');
  emitToRoom(`order:${id}`, 'status_update', { orderId: id, status, note });
  emitToRoom('admin:platform', 'order_event', { orderId: id, status });
  emitToRoom(`sm:${smId}`, 'order_status_update', { orderId: id, status });
  res.json(rows[0]);
};

// GET /api/supermarkets/analytics
exports.getAnalytics = async (req, res) => {
  const smId = req.user.id;
  const { rows: summary } = await query(
    `SELECT
       COUNT(*) FILTER (WHERE DATE(placed_at)=CURRENT_DATE)        AS orders_today,
       SUM(total) FILTER (WHERE DATE(placed_at)=CURRENT_DATE)      AS revenue_today,
       COUNT(*) FILTER (WHERE status NOT IN ('delivered','cancelled'))::int AS active_orders,
       COUNT(*) FILTER (WHERE status='delivered' AND placed_at>=NOW()-INTERVAL '30 days') AS delivered_month
     FROM orders WHERE supermarket_id=$1`, [smId]
  );
  const { rows: topProducts } = await query(
    `SELECT p.name, SUM(oi.quantity) AS qty_sold, SUM(oi.subtotal) AS revenue
     FROM order_items oi JOIN products p ON p.id=oi.product_id
     JOIN orders o ON o.id=oi.order_id
     WHERE o.supermarket_id=$1 AND o.status='delivered'
       AND o.placed_at>=NOW()-INTERVAL '30 days'
     GROUP BY p.id ORDER BY revenue DESC LIMIT 5`, [smId]
  );
  res.json({ summary: summary[0], topProducts });
};
