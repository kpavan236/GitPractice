const { query, withTransaction } = require('../utils/db');
const { v4: uuidv4 } = require('uuid');
const { emitToRoom } = require('../websocket/socket');

// Generate cryptographically-safe 6-digit unlock code
const generateUnlockCode = () =>
  String(Math.floor(100000 + Math.random() * 900000));

const generateOrderNumber = async (client) => {
  // Atomic per-day sequence. INSERT...ON CONFLICT serializes on the PK,
  // so concurrent claims can't return the same seq.
  const { rows } = await client.query(
    `INSERT INTO order_number_seq (order_date, last_seq)
     VALUES (CURRENT_DATE, 1)
     ON CONFLICT (order_date) DO UPDATE
       SET last_seq = order_number_seq.last_seq + 1
     RETURNING last_seq AS seq, to_char(order_date, 'YYYYMMDD') AS d`
  );
  return `ORD-${rows[0].d}-${String(rows[0].seq).padStart(4, '0')}`;
};

// POST /api/orders
exports.createOrder = async (req, res) => {
  const { supermarketId, addressId, items, couponCode, paymentMethod, deliveryType = 'drone' } = req.body;
  const userId = req.user.id;

  try {
    const result = await withTransaction(async (client) => {
      // 1. Validate address belongs to user
      const addrQ = await client.query(
        'SELECT * FROM user_addresses WHERE id=$1 AND user_id=$2', [addressId, userId]
      );
      if (!addrQ.rows.length) throw new Error('Address not found');
      const addr = addrQ.rows[0];

      // 2. Validate & fetch products
      let subtotal = 0;
      const orderItems = [];
      for (const item of items) {
        const { rows } = await client.query(
          'SELECT * FROM products WHERE id=$1 AND supermarket_id=$2 AND is_available=TRUE',
          [item.productId, supermarketId]
        );
        if (!rows.length) throw new Error(`Product ${item.productId} not available`);
        const prod = rows[0];
        if (prod.stock_qty < item.quantity) throw new Error(`${prod.name} — insufficient stock`);
        const lineTotal = parseFloat(prod.price) * item.quantity;
        subtotal += lineTotal;
        orderItems.push({ product: prod, quantity: item.quantity, lineTotal });
      }

      // 3. Apply coupon
      let discount = 0;
      if (couponCode) {
        const { rows: cpRows } = await client.query(
          `SELECT * FROM coupons WHERE code=$1 AND supermarket_id=$2
           AND is_active=TRUE AND (valid_until IS NULL OR valid_until>NOW())
           AND (usage_limit IS NULL OR used_count<usage_limit)`,
          [couponCode, supermarketId]
        );
        if (cpRows.length) {
          const cp = cpRows[0];
          if (subtotal >= parseFloat(cp.min_order)) {
            discount = cp.discount_type === 'flat'
              ? parseFloat(cp.discount_value)
              : Math.min(subtotal * cp.discount_value / 100, cp.max_discount || Infinity);
            await client.query('UPDATE coupons SET used_count=used_count+1 WHERE id=$1', [cp.id]);
          }
        }
      }

      const deliveryFee = 25;
      const total = Math.max(0, subtotal - discount) + deliveryFee;
      const unlockCode = generateUnlockCode();
      const orderNum = await generateOrderNumber(client);

      // COD has no payment-gateway step, so confirm immediately;
      // online payments stay pending until verifyPayment.
      const isCOD = paymentMethod === 'cod';
      const initialStatus = isCOD ? 'confirmed' : 'pending';

      // 4. Create order
      const { rows: orderRows } = await client.query(
        `INSERT INTO orders
           (order_number, supermarket_id, user_id, address_id,
            delivery_lat, delivery_lng,
            subtotal, delivery_fee, discount, total,
            coupon_code, status, confirmed_at, delivery_type, unlock_code)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
         RETURNING *`,
        [orderNum, supermarketId, userId, addressId,
         addr.lat, addr.lng,
         subtotal, deliveryFee, discount, total,
         couponCode || null, initialStatus, isCOD ? new Date() : null, deliveryType, unlockCode]
      );
      const order = orderRows[0];

      // 5. Insert items + deduct stock
      for (const oi of orderItems) {
        await client.query(
          `INSERT INTO order_items (order_id,product_id,name,price,quantity,subtotal)
           VALUES ($1,$2,$3,$4,$5,$6)`,
          [order.id, oi.product.id, oi.product.name, oi.product.price, oi.quantity, oi.lineTotal]
        );
        await client.query(
          'UPDATE products SET stock_qty=stock_qty-$1 WHERE id=$2',
          [oi.quantity, oi.product.id]
        );
      }

      // 6. Log status
      await client.query(
        `INSERT INTO order_status_history (order_id,status,note,created_by)
         VALUES ($1,'pending','Order placed by customer','customer')`,
        [order.id]
      );
      if (isCOD) {
        await client.query(
          `INSERT INTO order_status_history (order_id,status,note,created_by)
           VALUES ($1,'confirmed','COD order auto-confirmed','system')`,
          [order.id]
        );
      }

      return order;
    });

    // 7. Create Razorpay order if online payment
    let razorpayOrder = null;
    if (paymentMethod !== 'cod') {
      try {
        const Razorpay = require('razorpay');
        const rz = new Razorpay({
          key_id: process.env.RAZORPAY_KEY_ID,
          key_secret: process.env.RAZORPAY_KEY_SECRET,
        });
        razorpayOrder = await rz.orders.create({
          amount: Math.round(result.total * 100),
          currency: 'INR',
          receipt: result.order_number,
        });
        await query(
          `INSERT INTO order_payments (order_id,user_id,amount,method,gateway,gateway_order_id)
           VALUES ($1,$2,$3,$4,'razorpay',$5)`,
          [result.id, result.user_id, result.total, paymentMethod, razorpayOrder.id]
        );
      } catch (e) {
        console.warn('Razorpay create order failed (check keys):', e.message);
      }
    }

    // 8. Notify supermarket via WebSocket
    emitToRoom(`sm:${result.supermarket_id}`, 'new_order', {
      orderId: result.id,
      orderNumber: result.order_number,
      total: result.total,
    });
    emitToRoom('admin:platform', 'order_event', { orderId: result.id, status: result.status });
    emitToRoom(`sm:${result.supermarket_id}`, 'order_status_update', { orderId: result.id, status: result.status });

    res.status(201).json({ order: result, razorpayOrder });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// POST /api/orders/:id/verify-payment
exports.verifyPayment = async (req, res) => {
  const { razorpayOrderId, razorpayPaymentId, razorpaySignature } = req.body;
  const crypto = require('crypto');
  const expectedSig = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpayOrderId}|${razorpayPaymentId}`)
    .digest('hex');

  if (expectedSig !== razorpaySignature) {
    return res.status(400).json({ error: 'Payment signature mismatch' });
  }

  await query(
    `UPDATE order_payments SET status='paid', gateway_pay_id=$1, gateway_signature=$2
     WHERE gateway_order_id=$3`,
    [razorpayPaymentId, razorpaySignature, razorpayOrderId]
  );

  // confirm order
  const { rows } = await query(
    `UPDATE orders SET status='confirmed', confirmed_at=NOW()
     WHERE id=(SELECT order_id FROM order_payments WHERE gateway_order_id=$1)
     RETURNING *`,
    [razorpayOrderId]
  );
  if (rows.length) {
    emitToRoom(`sm:${rows[0].supermarket_id}`, 'order_confirmed', { orderId: rows[0].id });
    emitToRoom('admin:platform', 'order_event', { orderId: rows[0].id, status: 'confirmed' });
    emitToRoom(`sm:${rows[0].supermarket_id}`, 'order_status_update', { orderId: rows[0].id, status: 'confirmed' });
  }
  res.json({ success: true, order: rows[0] });
};

// POST /api/orders/:id/assign-drone  (supermarket)
exports.assignDrone = async (req, res) => {
  const { id: orderId } = req.params;
  const { droneId } = req.body;
  const smId = req.user.id;

  try {
    await withTransaction(async (client) => {
      const { rows: orderRows } = await client.query(
        'SELECT * FROM orders WHERE id=$1 AND supermarket_id=$2', [orderId, smId]
      );
      if (!orderRows.length) throw new Error('Order not found');

      const { rows: droneRows } = await client.query(
        'SELECT * FROM drones WHERE id=$1 AND supermarket_id=$2 AND status=$3 AND is_active=TRUE',
        [droneId, smId, 'idle']
      );
      if (!droneRows.length) throw new Error('Drone not available');

      await client.query(
        `UPDATE orders SET drone_id=$1, status='drone_assigned', dispatched_at=NOW(), estimated_minutes=18
         WHERE id=$2`,
        [droneId, orderId]
      );
      await client.query(
        "UPDATE drones SET status='assigned' WHERE id=$1", [droneId]
      );
      await client.query(
        `INSERT INTO order_status_history (order_id,status,note,created_by)
         VALUES ($1,'drone_assigned','Drone assigned and ready for dispatch','supermarket')`,
        [orderId]
      );
    });

    emitToRoom('admin:platform', 'order_event', { orderId, status: 'drone_assigned' });
    emitToRoom(`sm:${smId}`, 'order_status_update', { orderId, status: 'drone_assigned' });
    emitToRoom(`sm:${smId}`, 'drone_telemetry', { droneId, status: 'assigned' });

    // Hand control to the configured drone source.
    //   DRONE_MODE=mqtt      → publish mission, bridge takes over
    //   DRONE_SIMULATION=true (default) → in-process simulator
    const mqttClient = require('../mqtt/client');
    if (mqttClient.isEnabled()) {
      const { rows: ord }   = await query('SELECT delivery_lat, delivery_lng FROM orders WHERE id=$1', [orderId]);
      const { rows: drone } = await query('SELECT home_lat, home_lng FROM drones WHERE id=$1', [droneId]);
      const { v4: uuidv4 } = require('uuid');
      const sent = mqttClient.publishMission(droneId, {
        missionId: uuidv4(),
        orderId,
        issuedAt: new Date().toISOString(),
        home:        { lat: +drone[0].home_lat, lng: +drone[0].home_lng },
        destination: { lat: +ord[0].delivery_lat, lng: +ord[0].delivery_lng },
        policy: { cruise_alt_m: 30, max_speed_kmh: 45, rtl_battery_pct: 25 },
      });
      if (!sent) console.warn('[assignDrone] mqtt publish failed; mission not handed off');
    } else if (process.env.DRONE_SIMULATION === 'true') {
      simulateDroneFlight(orderId, droneId, smId);
    }

    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// POST /api/orders/:id/unlock  (customer scans QR / enters code)
exports.unlockBox = async (req, res) => {
  const { id: orderId } = req.params;
  const { code } = req.body;
  const userId = req.user.id;

  const { rows } = await query(
    'SELECT * FROM orders WHERE id=$1 AND user_id=$2', [orderId, userId]
  );
  if (!rows.length) return res.status(404).json({ error: 'Order not found' });
  const order = rows[0];

  if (order.status !== 'landed' && order.status !== 'awaiting_pickup') {
    return res.status(400).json({ error: 'Drone not yet at your location' });
  }
  if (order.unlock_code_used) {
    return res.status(400).json({ error: 'Box already unlocked' });
  }
  if (order.unlock_code !== code) {
    return res.status(400).json({ error: 'Incorrect unlock code' });
  }

  await withTransaction(async (client) => {
    await client.query(
      `UPDATE orders SET unlock_code_used=TRUE, unlock_code_used_at=NOW(),
       status='delivered', delivered_at=NOW() WHERE id=$1`,
      [orderId]
    );
    await client.query(
      "UPDATE drones SET status='returning' WHERE id=$1", [order.drone_id]
    );
    await client.query(
      `INSERT INTO order_status_history (order_id,status,note,created_by)
       VALUES ($1,'delivered','Customer unlocked box — delivered!','customer')`,
      [orderId]
    );
  });

  emitToRoom(`order:${orderId}`, 'order_delivered', { orderId });
  emitToRoom(`sm:${order.supermarket_id}`, 'order_delivered', { orderId });
  emitToRoom(`sm:${order.supermarket_id}`, 'drone_telemetry', { droneId: order.drone_id, status: 'returning' });
  emitToRoom('admin:platform', 'order_event', { orderId, status: 'delivered' });
  emitToRoom(`sm:${order.supermarket_id}`, 'order_status_update', { orderId, status: 'delivered' });

  // Hand the return flight off to the same drone source that ran the outbound:
  //   DRONE_MODE=mqtt           → publish to drones/<id>/commands/return
  //   DRONE_SIMULATION=true     → in-process simulateDroneReturn
  const mqttClient = require('../mqtt/client');
  if (mqttClient.isEnabled()) {
    const { rows: drone } = await query(
      'SELECT home_lat, home_lng, battery_pct, current_lat, current_lng FROM drones WHERE id=$1',
      [order.drone_id],
    );
    if (drone.length) {
      mqttClient.publishReturn(order.drone_id, {
        orderId,
        home: { lat: +drone[0].home_lat, lng: +drone[0].home_lng },
        from: {
          lat: +(drone[0].current_lat ?? order.delivery_lat),
          lng: +(drone[0].current_lng ?? order.delivery_lng),
        },
        battery_pct: drone[0].battery_pct,
        policy: { charge_threshold_pct: 80 },
      });
    }
  } else if (process.env.DRONE_SIMULATION === 'true') {
    simulateDroneReturn(order.drone_id, order.supermarket_id);
  }

  res.json({ success: true, message: 'Box unlocked! Enjoy your order.' });
};

// GET /api/orders/:id/livestream  (customer)
// Returns enough metadata for the tracking UI to open a live drone feed.
// In production this becomes a LiveKit/Cloudflare-Realtime room URL + scoped JWT.
// In dev we return a flag so the frontend can render a canvas-based mock POV.
exports.getLivestream = async (req, res) => {
  const { id } = req.params;
  const userId = req.user.id;
  try {
    const { rows } = await query(
      `SELECT o.id, o.status, o.order_number,
              d.name AS drone_name, d.battery_pct,
              d.current_lat, d.current_lng,
              o.delivery_lat, o.delivery_lng
       FROM orders o LEFT JOIN drones d ON d.id=o.drone_id
       WHERE o.id=$1 AND o.user_id=$2`,
      [id, userId]
    );
    if (!rows.length) return res.status(404).json({ error: 'Order not found' });
    const o = rows[0];
    const STREAMING = new Set(['in_flight','near_destination','landed','awaiting_pickup']);
    res.json({
      enabled:    STREAMING.has(o.status) && !!o.drone_name,
      mode:       'mock',                       // production swaps to 'webrtc'
      roomName:   `order_${id}`,                // future: LiveKit room
      token:      null,                         // future: LiveKit JWT (5-min TTL, scoped to room)
      droneName:  o.drone_name,
      altitudeM:  30,                           // matches simulator's drone_telemetry insert
      speedKmh:   45,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/supermarket/orders/:id/livestream  (supermarket monitoring)
exports.getSupermarketLivestream = async (req, res) => {
  const { id } = req.params;
  const smId = req.user.id;
  try {
    const { rows } = await query(
      `SELECT o.id, o.status, o.order_number, o.delivery_lat, o.delivery_lng,
              u.name AS customer_name, ua.line1 AS addr_line1, ua.city AS addr_city,
              d.name AS drone_name, d.battery_pct
       FROM orders o
       LEFT JOIN drones d ON d.id=o.drone_id
       JOIN users u ON u.id=o.user_id
       LEFT JOIN user_addresses ua ON ua.id=o.address_id
       WHERE o.id=$1 AND o.supermarket_id=$2`,
      [id, smId]
    );
    if (!rows.length) return res.status(404).json({ error: 'Order not found' });
    const o = rows[0];
    const STREAMING = new Set(['in_flight','near_destination','landed','awaiting_pickup']);
    res.json({
      enabled:      STREAMING.has(o.status) && !!o.drone_name,
      mode:         'mock',
      roomName:     `order_${id}`,
      token:        null,
      droneName:    o.drone_name,
      orderNumber:  o.order_number,
      status:       o.status,
      customerName: o.customer_name,
      addressLine:  [o.addr_line1, o.addr_city].filter(Boolean).join(', '),
      deliveryLat:  o.delivery_lat,
      deliveryLng:  o.delivery_lng,
      altitudeM:    30,
      speedKmh:     45,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/orders/:id  (customer tracking)
exports.getOrder = async (req, res) => {
  const { id } = req.params;
  const userId = req.user.id;
  const { rows } = await query(
    `SELECT o.*,
       json_agg(json_build_object('name',oi.name,'qty',oi.quantity,'price',oi.price,'subtotal',oi.subtotal)) AS items,
       row_to_json(d.*) AS drone,
       json_build_object('id',s.id,'name',s.name,'lat',s.lat,'lng',s.lng) AS supermarket
     FROM orders o
     LEFT JOIN order_items oi ON oi.order_id=o.id
     LEFT JOIN drones d ON d.id=o.drone_id
     LEFT JOIN supermarkets s ON s.id=o.supermarket_id
     WHERE o.id=$1 AND o.user_id=$2
     GROUP BY o.id, d.id, s.id`,
    [id, userId]
  );
  if (!rows.length) return res.status(404).json({ error: 'Order not found' });

  // Only expose unlock code after drone has landed
  const order = rows[0];
  if (!['landed','awaiting_pickup','delivered'].includes(order.status)) {
    delete order.unlock_code;
  }
  res.json(order);
};

// ── Drone flight simulator (dev only) ─────────────────────
function simulateDroneFlight(orderId, droneId, supermarketId) {
  const speedMult = parseInt(process.env.DRONE_SIMULATION_SPEED_MULTIPLIER || '10');
  // Outbound flight is paced at ~60 seconds total (at default speedMult=10) so
  // the customer's tracking map shows a realistic-feeling drone delivery.
  // Cumulative (at speedMult=10):  in_flight T+6s → near_destination T+42s →
  //                                landed T+54s → awaiting_pickup T+57s
  const steps = [
    { status: 'in_flight',          note: 'Drone in flight',           delay: 60000  / speedMult },
    { status: 'near_destination',   note: 'Drone approaching destination', delay: 360000 / speedMult },
    { status: 'landed',             note: 'Drone landed — awaiting pickup', delay: 120000 / speedMult },
    { status: 'awaiting_pickup',    note: 'Awaiting customer to unlock box', delay: 30000  / speedMult },
  ];

  let cumulativeDelay = 0;
  for (const step of steps) {
    cumulativeDelay += step.delay;
    setTimeout(async () => {
      await query(
        `UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2`, [step.status, orderId]
      );
      if (step.status === 'in_flight') {
        await query("UPDATE drones SET status='in_flight' WHERE id=$1", [droneId]);
        emitToRoom(`sm:${supermarketId}`, 'drone_telemetry', { droneId, status: 'in_flight' });
      }
      await query(
        `INSERT INTO order_status_history (order_id,status,note,created_by) VALUES ($1,$2,$3,'system')`,
        [orderId, step.status, step.note]
      );

      // Broadcast to all listeners
      emitToRoom(`order:${orderId}`, 'status_update', {
        orderId, status: step.status, note: step.note, timestamp: new Date()
      });
      emitToRoom('admin:platform', 'order_event', { orderId, status: step.status });
      emitToRoom(`sm:${supermarketId}`, 'order_status_update', { orderId, status: step.status });

      // Simulate telemetry during flight
      if (step.status === 'in_flight') simulateTelemetry(droneId, orderId, speedMult);
    }, cumulativeDelay);
  }
}

// Drone flies back home after delivery; charges if battery is low; then idle.
const CHARGE_THRESHOLD = 80;

function simulateDroneReturn(droneId, supermarketId) {
  const speedMult = parseInt(process.env.DRONE_SIMULATION_SPEED_MULTIPLIER || '10');
  const returnDuration = 10000 / speedMult;

  setTimeout(async () => {
    // Guard with status='returning' so a manual override (maintenance, etc.) wins.
    const { rows } = await query(
      `UPDATE drones
         SET current_lat=home_lat, current_lng=home_lng,
             status=CASE WHEN battery_pct < $2 THEN 'charging' ELSE 'idle' END,
             last_ping=NOW()
       WHERE id=$1 AND status='returning'
       RETURNING current_lat, current_lng, battery_pct, status`,
      [droneId, CHARGE_THRESHOLD]
    );
    if (!rows.length) return;
    emitToRoom(`sm:${supermarketId}`, 'drone_telemetry', {
      droneId, lat: rows[0].current_lat, lng: rows[0].current_lng,
      battery: rows[0].battery_pct, status: rows[0].status,
    });
    if (rows[0].status === 'charging') simulateDroneCharge(droneId, supermarketId);
  }, returnDuration);
}

function simulateDroneCharge(droneId, supermarketId) {
  const speedMult = parseInt(process.env.DRONE_SIMULATION_SPEED_MULTIPLIER || '10');
  const chargeDuration = 30000 / speedMult;

  setTimeout(async () => {
    const { rows } = await query(
      `UPDATE drones
         SET battery_pct=100, status='idle', last_ping=NOW()
       WHERE id=$1 AND status='charging'
       RETURNING battery_pct, status`,
      [droneId]
    );
    if (!rows.length) return;
    emitToRoom(`sm:${supermarketId}`, 'drone_telemetry', {
      droneId, status: 'idle', battery: 100,
    });
  }, chargeDuration);
}

function simulateTelemetry(droneId, orderId, speedMult) {
  let tick = 0;
  const iv = setInterval(async () => {
    tick++;
    if (tick > 20) return clearInterval(iv);

    // generate fake lat/lng movement
    const { rows: dr } = await query('SELECT * FROM drones WHERE id=$1', [droneId]);
    const { rows: or } = await query('SELECT delivery_lat,delivery_lng FROM orders WHERE id=$1', [orderId]);
    if (!dr.length || !or.length) return clearInterval(iv);

    const drone = dr[0]; const dest = or[0];
    const progress = tick / 20;
    const lat = drone.home_lat + (dest.delivery_lat - drone.home_lat) * progress;
    const lng = drone.home_lng + (dest.delivery_lng - drone.home_lng) * progress;
    const battery = Math.max(20, drone.battery_pct - tick * 2);

    await query(
      `UPDATE drones SET current_lat=$1, current_lng=$2, battery_pct=$3, last_ping=NOW() WHERE id=$4`,
      [lat, lng, battery, droneId]
    );
    await query(
      `INSERT INTO drone_telemetry (drone_id,lat,lng,altitude_m,speed_kmh,battery_pct)
       VALUES ($1,$2,$3,30,45,$4)`,
      [droneId, lat, lng, battery]
    );

    emitToRoom(`order:${orderId}`, 'drone_location', { lat, lng, battery, progress });
    emitToRoom(`sm:${drone.supermarket_id}`, 'drone_telemetry', { droneId, lat, lng, battery });
    // Telemetry interval = 24000 ms base / speedMult = ~2.4 s real per tick
    // → 20 ticks (loop caps at tick=20) spread evenly across the ~48 s in-flight window.
  }, 24000 / speedMult);
}
