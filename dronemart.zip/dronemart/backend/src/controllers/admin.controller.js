const { query } = require('../utils/db');

// GET /api/admin/supermarkets
exports.listSupermarkets = async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT s.id, s.name, s.slug, s.owner_name, s.email, s.phone,
              s.city, s.state, s.pincode,
              s.license_status, s.trial_ends, s.license_expires,
              s.is_open, s.created_at,
              lp.name AS plan_name,
              COUNT(DISTINCT p.id)  AS product_count,
              COUNT(DISTINCT d.id)  AS drone_count,
              COUNT(DISTINCT o.id)  AS order_count
       FROM supermarkets s
       LEFT JOIN license_plans lp ON lp.id = s.license_plan_id
       LEFT JOIN products p      ON p.supermarket_id = s.id
       LEFT JOIN drones d        ON d.supermarket_id = s.id AND d.is_active = TRUE
       LEFT JOIN orders o        ON o.supermarket_id = s.id
       GROUP BY s.id, lp.name
       ORDER BY s.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/admin/orders?status=&supermarketId=&page=
exports.listOrders = async (req, res) => {
  try {
    const { status, supermarketId, page = 1 } = req.query;
    const limit = 50;
    const offset = (page - 1) * limit;

    const params = [limit, offset];
    const filters = [];
    if (status) { params.push(status); filters.push(`o.status = $${params.length}`); }
    if (supermarketId) { params.push(supermarketId); filters.push(`o.supermarket_id = $${params.length}`); }
    const where = filters.length ? `WHERE ${filters.join(' AND ')}` : '';

    const { rows } = await query(
      `SELECT o.id, o.order_number, o.status, o.total, o.delivery_type,
              o.placed_at, o.confirmed_at, o.dispatched_at, o.delivered_at,
              s.name AS supermarket_name, s.slug AS supermarket_slug,
              u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
              d.name AS drone_name
       FROM orders o
       JOIN supermarkets s ON s.id = o.supermarket_id
       JOIN users u        ON u.id = o.user_id
       LEFT JOIN drones d  ON d.id = o.drone_id
       ${where}
       ORDER BY o.placed_at DESC
       LIMIT $1 OFFSET $2`,
      params
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};