let _io = null;

const initSocket = (server) => {
  const { Server } = require('socket.io');
  const { verifyAccess } = require('../middleware/auth');

  _io = new Server(server, {
    cors: {
      origin: (process.env.CORS_ORIGINS || '').split(','),
      methods: ['GET', 'POST'],
    },
  });

  // Auth middleware for socket connections
  _io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error('Authentication required'));
    try {
      socket.user = verifyAccess(token);
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  _io.on('connection', (socket) => {
    const { id, type } = socket.user;
    console.log(`[WS] ${type} ${id} connected`);

    // Customer: subscribe to their orders
    socket.on('subscribe:order', (orderId) => {
      socket.join(`order:${orderId}`);
    });

    // Supermarket: subscribe to own room
    if (type === 'supermarket') {
      socket.join(`sm:${id}`);
    }

    // Admin: subscribe to platform-wide room
    if (type === 'admin') {
      socket.join('admin:platform');
    }

    // Customer: subscribe to supermarket (for availability changes)
    socket.on('subscribe:supermarket', (smId) => {
      socket.join(`sm:${smId}`);
    });

    socket.on('disconnect', () => {
      console.log(`[WS] ${type} ${id} disconnected`);
    });
  });

  return _io;
};

const emitToRoom = (room, event, data) => {
  if (_io) _io.to(room).emit(event, data);
};

const getIO = () => _io;

module.exports = { initSocket, emitToRoom, getIO };
