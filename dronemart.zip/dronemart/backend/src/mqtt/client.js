// API-side MQTT integration.
// - Subscribes to telemetry + events from the bridge.
// - Translates them into the same DB writes + WebSocket emits the in-process
//   simulator currently produces, so frontends don't need to change.
// - Exposes publishMission() for assignDrone to call.
//
// Activated only when DRONE_MODE === 'mqtt'. Otherwise this module is a no-op
// and the in-process simulator remains in charge.

const mqtt = require('mqtt');
const { query } = require('../utils/db');
const { emitToRoom } = require('../websocket/socket');

const BROKER_URL = process.env.MQTT_BROKER_URL || 'mqtt://mqtt-broker:1883';
const ENABLED    = process.env.DRONE_MODE === 'mqtt';

let client = null;

function init() {
  if (!ENABLED) return;
  client = mqtt.connect(BROKER_URL, {
    clientId: `api-${Math.random().toString(16).slice(2)}`,
    reconnectPeriod: 2000,
  });

  client.on('connect', () => {
    console.log('[api/mqtt] connected to', BROKER_URL);
    client.subscribe('drones/+/telemetry', { qos: 0 });
    client.subscribe('drones/+/events',    { qos: 1 });
  });
  client.on('error',     err => console.error('[api/mqtt]', err.message));
  client.on('reconnect', ()  => console.log('[api/mqtt] reconnecting…'));

  client.on('message', async (topic, payload) => {
    const m = topic.match(/^drones\/([^/]+)\/(telemetry|events)$/);
    if (!m) return;
    const [, droneId, kind] = m;
    let body; try { body = JSON.parse(payload.toString()); } catch { return; }

    if (kind === 'telemetry') return handleTelemetry(droneId, body);
    if (kind === 'events')    return handleEvent(droneId, body);
  });
}

async function handleTelemetry(droneId, t) {
  // Persist live position so /supermarket/drones returns current state.
  if (t.lat != null && t.lng != null) {
    await query(
      `UPDATE drones SET current_lat=$1, current_lng=$2, battery_pct=COALESCE($3,battery_pct), last_ping=NOW()
       WHERE id=$4`,
      [t.lat, t.lng, t.battery_pct ?? null, droneId],
    ).catch(() => { /* drone may not exist yet — telemetry from foreign drone */ });
  }
  if (!t.orderId) return;
  // Same event shape the in-process simulator emits — frontends are unchanged.
  emitToRoom(`order:${t.orderId}`, 'drone_location', {
    lat: t.lat, lng: t.lng, battery: t.battery_pct, progress: t.progress,
  });
  // Look up supermarket once per drone (cached) to fan telemetry to its room.
  const sm = await supermarketIdFor(droneId);
  if (sm) emitToRoom(`sm:${sm}`, 'drone_telemetry', { droneId, lat: t.lat, lng: t.lng, battery: t.battery_pct });
}

async function handleEvent(droneId, e) {
  console.log(`[api/mqtt] drone ${droneId.slice(0,8)} → ${e.state} (order ${e.orderId?.slice(0,8) || '—'})`);

  // ── Order-level states (touch orders.status + the order timeline) ─────────
  // 'awaiting_pickup' arrives BEFORE the customer unlocks; 'delivered' stays
  // driven by the customer's unlockBox endpoint, not the drone.
  const orderState = ['in_flight','near_destination','landed','awaiting_pickup'].includes(e.state)
    ? e.state : null;

  if (orderState && e.orderId) {
    await query(`UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2`, [orderState, e.orderId]);
    await query(
      `INSERT INTO order_status_history (order_id,status,note,created_by) VALUES ($1,$2,$3,'system')`,
      [e.orderId, orderState, e.note || `Drone → ${e.state}`],
    );

    // Same broadcast pattern the simulator uses.
    emitToRoom(`order:${e.orderId}`, 'status_update', { orderId: e.orderId, status: orderState, note: e.note });
    emitToRoom('admin:platform',     'order_event',   { orderId: e.orderId, status: orderState });
    const sm = await supermarketIdFor(droneId);
    if (sm) emitToRoom(`sm:${sm}`, 'order_status_update', { orderId: e.orderId, status: orderState });
  }

  // ── Drone-level states (touch drones row, not orders) ─────────────────────
  // Emitted during the return + charge phase after unlockBox.
  if (['in_flight','returning','charging','idle'].includes(e.state)) {
    const sets = ['status=$2', 'last_ping=NOW()'];
    const params = [droneId, e.state];
    if (e.battery_pct != null) { params.push(e.battery_pct); sets.push(`battery_pct=$${params.length}`); }
    if (e.lat != null) { params.push(e.lat); sets.push(`current_lat=$${params.length}`); }
    if (e.lng != null) { params.push(e.lng); sets.push(`current_lng=$${params.length}`); }
    await query(`UPDATE drones SET ${sets.join(', ')} WHERE id=$1`, params).catch(() => {});

    const sm = await supermarketIdFor(droneId);
    if (sm) emitToRoom(`sm:${sm}`, 'drone_telemetry', {
      droneId, status: e.state,
      battery: e.battery_pct, lat: e.lat, lng: e.lng,
    });
  }
}

// Tiny in-memory cache so we don't query supermarkets for every telemetry tick.
const _smCache = new Map();
async function supermarketIdFor(droneId) {
  if (_smCache.has(droneId)) return _smCache.get(droneId);
  try {
    const { rows } = await query('SELECT supermarket_id FROM drones WHERE id=$1', [droneId]);
    const id = rows[0]?.supermarket_id || null;
    _smCache.set(droneId, id);
    return id;
  } catch { return null; }
}

function publishMission(droneId, mission) {
  return _publish(droneId, 'mission', mission);
}
function publishReturn(droneId, returnCmd) {
  return _publish(droneId, 'return', returnCmd);
}
function publishAbort(droneId, reason) {
  return _publish(droneId, 'abort', { reason });
}
function _publish(droneId, command, body) {
  if (!ENABLED) return false;
  if (!client || !client.connected) {
    console.warn(`[api/mqtt] publish(${command}) called but client not connected`);
    return false;
  }
  client.publish(`drones/${droneId}/commands/${command}`, JSON.stringify(body), { qos: 1 });
  return true;
}

function isEnabled() { return ENABLED; }

module.exports = { init, publishMission, publishReturn, publishAbort, isEnabled };
