#!/usr/bin/env node
'use strict';
const path = require('path');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { createProfilesRepo } = require('../src/profiles');
const { seedFromDir } = require('../src/seed');
const { defaultDbFile } = require('../src/config');

// usage: node scripts/seed.js [rules-dir (default seed/rules)] [--db oasis-rules.db] [--allow gitleaks,checkov]
function flag(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const dir = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : path.join(__dirname, '..', 'seed', 'rules');

const db = openDb(path.resolve(flag('db', defaultDbFile())));
const rules = createRulesRepo(db);
// Only sources whose licence permits redistribution are imported unless the
// caller names the sources explicitly (the licence gate of the old bundle build).
const { redistributableIds } = require('../tools/ingest/sources');
const allow = flag('allow', null);
const result = seedFromDir(rules, path.resolve(dir), { allowSources: allow ? allow.split(',') : redistributableIds() });
const profile = createProfilesRepo(db, rules).ensureDefault();
console.log(`seeded: ${JSON.stringify(result)}; default profile "${profile.name}" v${profile.version}`);
