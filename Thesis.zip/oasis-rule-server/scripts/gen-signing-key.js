'use strict';
// Usage: node scripts/gen-signing-key.js <private-key-path>
// Writes the private key (mode 0600) to the path and prints only the PUBLIC key PEM.
const fs = require('node:fs');
const crypto = require('node:crypto');

const target = process.argv[2];
if (!target) {
  console.error('usage: node scripts/gen-signing-key.js <private-key-path>');
  process.exit(2);
}
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
try {
  fs.writeFileSync(target, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600, flag: 'wx' });
} catch (e) {
  console.error(e.code === 'EEXIST' ? `${target} already exists; refusing to overwrite it` : `cannot write ${target}: ${e.message}`);
  process.exit(1);
}
process.stdout.write(publicKey.export({ type: 'spki', format: 'pem' }));
