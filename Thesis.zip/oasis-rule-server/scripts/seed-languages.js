'use strict';
const path = require('node:path');
const { createPool } = require('../src/pg');
const { loadLanguages, seedLanguages } = require('../src/languages');

async function main() {
  const url = process.env.RULES_DATABASE_URL;
  if (!url) throw new Error('set RULES_DATABASE_URL to the central Postgres connection string');
  const list = loadLanguages(path.join(__dirname, '..', 'seed', 'languages.json'));
  const pool = createPool(url);
  try {
    await seedLanguages(pool, list);
    console.log(`seeded ${list.length} languages`);
  } finally { await pool.end(); }
}

main().catch((err) => { console.error(err.message); process.exit(1); });
