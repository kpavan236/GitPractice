#!/usr/bin/env node
'use strict';
// Loads the language registry and every seed rule into the central Postgres database as active rules.
// usage: RULES_DATABASE_URL=postgres://... node scripts/seed-central.js [rules-dir (default seed/rules)] [--allow gitleaks,checkov]
// Safe to run again: a rule whose content has not changed is reported as 'unchanged' and gets no new version.
//
// This is bootstrap-and-refresh from the files, not a sync that overrides Studio:
// - Before touching an existing rule it reads who wrote the rule's latest version (rule_version.changed_by, highest version).
//   If that is anything other than 'seed' the rule was edited in Studio, so it is left alone and reported in
//   `skippedEdited` (count) and `skippedEditedIds`.
// - Rules in the database with origin 'builtin' or 'vendor' whose file no longer exists are NOT deprecated or deleted;
//   they stay active and are reported in `orphaned` (count) and `orphanedIds`. Retire them in Studio.
const fs = require('node:fs');
const path = require('node:path');
const { createPool } = require('../src/pg');
const { loadLanguages, seedLanguages } = require('../src/languages');
const { createRulesRepo } = require('../src/rules/repo');
const { redistributableIds } = require('../tools/ingest/sources');

const ROOT = path.join(__dirname, '..');
const ACTOR = 'seed';
const SECURITY_TYPES = ['IAC', 'SECRET', 'SAST'];

function* jsonFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* jsonFiles(full);
    else if (entry.name.endsWith('.json')) yield full;
  }
}

// Existing rule files predate pillars; every one of them is a security rule, so the pillar follows the rule's type.
// A category is never touched. A rule that already names a pillar keeps it.
function withPillar(rule) {
  if (rule.pillar || !SECURITY_TYPES.includes(rule.type)) return rule;
  return { ...rule, pillar: 'security' };
}

/** Only sources whose licence permits redistribution are imported unless the caller names the sources (the same gate as scripts/seed.js). */
async function seedCentral({ pool, rulesDir = path.join(ROOT, 'seed', 'rules'), languagesFile = path.join(ROOT, 'seed', 'languages.json'), allowSources = redistributableIds() } = {}) {
  await seedLanguages(pool, loadLanguages(languagesFile));
  const repo = createRulesRepo({ pool, languages: async () => (await pool.query('SELECT id FROM language')).rows.map(r => r.id) });
  const result = { created: 0, updated: 0, unchanged: 0, excluded: 0, skippedEdited: 0, skippedEditedIds: [], orphaned: 0, orphanedIds: [] };
  const inFiles = new Set();
  const lastWriter = async (id) => (await pool.query('SELECT changed_by FROM rule_version WHERE rule_id = $1 ORDER BY version DESC LIMIT 1', [id])).rows[0];
  for (const file of jsonFiles(rulesDir)) {
    let rule;
    try { rule = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { throw new Error(`${path.relative(rulesDir, file)}: ${e.message}`); }
    if (rule && typeof rule.id === 'string') inFiles.add(rule.id);
    const source = rule.provenance && rule.provenance.source;
    if (source && Array.isArray(allowSources) && !allowSources.includes(source)) { result.excluded += 1; continue; }
    const writer = await lastWriter(rule.id);
    if (writer && writer.changed_by !== ACTOR) { result.skippedEdited += 1; result.skippedEditedIds.push(rule.id); continue; }
    result[await repo.upsertSeeded(withPillar(rule), { origin: rule.provenance ? 'vendor' : 'builtin', actor: ACTOR })] += 1;
  }
  const stored = await pool.query("SELECT rule_id FROM rule WHERE origin IN ('builtin','vendor') ORDER BY rule_id");
  result.orphanedIds = stored.rows.map(r => r.rule_id).filter(id => !inFiles.has(id));
  result.orphaned = result.orphanedIds.length;
  return result;
}

module.exports = { seedCentral, withPillar };

if (require.main === module) {
  (async () => {
    const url = process.env.RULES_DATABASE_URL;
    if (!url) throw new Error('set RULES_DATABASE_URL to the central Postgres connection string');
    const arg = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : undefined;
    const i = process.argv.indexOf('--allow');
    const allow = i !== -1 && process.argv[i + 1] ? process.argv[i + 1].split(',') : undefined;
    const pool = createPool(url);
    try {
      const result = await seedCentral({ pool, rulesDir: arg && path.resolve(arg), allowSources: allow });
      console.log(`seeded: ${JSON.stringify(result)}`);
    } finally { await pool.end(); }
  })().catch((err) => { console.error(err.message); process.exit(1); });
}
