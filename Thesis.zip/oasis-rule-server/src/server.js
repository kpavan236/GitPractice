'use strict';
const { openDb } = require('./db');
const { createApp } = require('./api');

const { defaultDbFile, defaultPort } = require('./config');

const port = defaultPort();
const file = defaultDbFile();

// Loopback only: this server edits what the scanner reports.
createApp({ db: openDb(file) }).listen(port, '127.0.0.1', () => {
  console.log(`oasis-rule-server on http://127.0.0.1:${port}/api/v1 (db: ${file})`);
});
