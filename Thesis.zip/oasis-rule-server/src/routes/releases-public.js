'use strict';
const express = require('express');

const SHA256 = /^[0-9a-f]{64}$/;
const CHANNELS = ['beta', 'stable'];

/** The read-only surface the Oasis loader uses: the signed manifest for a channel, and pack blobs by hash. */
function releasesPublicRouter({ releases, blobs }) {
  const router = express.Router();

  router.get('/releases/latest', async (req, res, next) => {
    try {
      const { channel, since } = req.query;
      if (typeof channel !== 'string' || !CHANNELS.includes(channel)) return res.status(400).json({ error: 'INVALID_CHANNEL' });
      if (since !== undefined && !(typeof since === 'string' && /^\d{1,12}$/.test(since))) return res.status(400).json({ error: 'INVALID_SINCE' });
      let out;
      try { out = await releases.latest(channel, since); } catch (e) {
        if (e.code === 'NOT_FOUND') return res.status(404).json({ error: 'NO_RELEASE' });
        throw e;
      }
      res.set('Cache-Control', 'no-store').json(out);
    } catch (e) { next(e); }
  });

  router.get('/blobs/:sha256', async (req, res, next) => {
    try {
      if (!SHA256.test(req.params.sha256)) return res.status(400).json({ error: 'INVALID_HASH' });
      let buf;
      try { buf = await blobs.get(req.params.sha256); } catch (e) {
        if (e.code === 'NOT_FOUND') return res.status(404).json({ error: 'NOT_FOUND' });
        throw e;   // CORRUPT or an I/O failure: never serve the bytes
      }
      res.set({ 'Content-Type': 'application/octet-stream', 'Cache-Control': 'public, max-age=31536000, immutable' }).send(buf);
    } catch (e) { next(e); }
  });

  // A path that is not a single hash segment (for example ../../etc/passwd) is a bad hash, not an unknown route.
  router.get('/blobs/*', (_req, res) => res.status(400).json({ error: 'INVALID_HASH' }));

  return router;
}

module.exports = { releasesPublicRouter };
