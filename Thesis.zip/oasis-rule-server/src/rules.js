'use strict';
const { engineOf, ENGINE_SCHEMA } = require('./engines');

const SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];

function fail(code, message) {
  return Object.assign(new Error(message), { code });
}

function toRow(r) {
  if (!r) return null;
  return {
    id: r.id, version: r.version, language: r.language, engine: r.engine,
    schemaVersion: r.schema_version, severity: r.severity, status: r.status,
    origin: r.origin, body: JSON.parse(r.body), updatedAt: r.updated_at,
  };
}

// Mirrors oasis rule-bundle.validateUserRule, plus what build-rules.js enforces
// for patterns. AST queries cannot be compiled here (no tree-sitter on the
// server), so create() flags them for validation by the scanner.
function validateUserRule(rule) {
  if (!rule || !rule.id) return 'a rule has no id';
  if (!rule.language) return `${rule.id}: no language`;
  if (!rule.query && !rule.pattern && !rule.definition) return `${rule.id}: no query, pattern or definition`;
  if (!SEVERITIES.includes(rule.severity)) return `${rule.id}: severity must be one of ${SEVERITIES.join(', ')}`;
  if (!rule.fixture || typeof rule.fixture.detect !== 'string' || typeof rule.fixture.clean !== 'string') {
    return `${rule.id}: fixture with detect and clean strings is required`;
  }
  if (rule.pattern && rule.engine !== 'secret') {
    if (!Array.isArray(rule.files) || !rule.files.length) return `${rule.id}: pattern rules need a files glob`;
    let re;
    try { re = new RegExp(rule.pattern); } catch (e) { return `${rule.id}: pattern does not compile (${e.message})`; }
    if (re.test('')) return `${rule.id}: pattern matches the empty string`;
  }
  if (!engineOf(rule)) return `${rule.id}: cannot determine engine`;
  return null;
}

// What a list needs to show a rule, without its (large) definition.
function summarise(row) {
  const b = row.body;
  return {
    id: row.id, version: row.version, language: row.language, engine: row.engine, severity: row.severity,
    status: row.status, origin: row.origin,
    title: b.title || row.id,
    description: String(b.description || '').slice(0, 200),
    category: b.category || null, cwe: b.cwe || null,
    hasExample: !!(b.example && (b.example.vulnerable || b.example.fixed)),
    source: (b.provenance && b.provenance.source) || null,
  };
}

function createRulesRepo(db) {
  const now = () => new Date().toISOString();
  const byId = db.prepare('SELECT * FROM rules WHERE id = ?');

  function insert(rule, origin) {
    db.prepare(`INSERT INTO rules (id, version, language, engine, schema_version, severity, status, origin, body, updated_at)
                VALUES (?, 1, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?)`)
      .run(rule.id, rule.language, engineOf(rule), ENGINE_SCHEMA[engineOf(rule)], rule.severity, origin, JSON.stringify(rule), now());
  }

  function get(id) { return toRow(byId.get(id)); }

  // Scanners cache per-file results by profile version, so any change to a
  // rule's content must move every profile (children inherit from parents).
  const bumpProfiles = () => db.prepare('UPDATE profiles SET version = version + 1').run();

  function create(rule) {
    const problem = validateUserRule(rule);
    if (problem) throw fail('INVALID', problem);
    if (byId.get(rule.id)) throw fail('CONFLICT', `rule ${rule.id} already exists`);
    insert(rule, 'user');
    return { rule: get(rule.id), needsScannerValidation: engineOf(rule) === 'ast' };
  }

  function update(id, patch) {
    const current = get(id);
    if (!current) throw fail('NOT_FOUND', `rule ${id} not found`);
    // Built-in and vendored rules are read-only: what changes about them is whether
    // a profile runs them and at what severity. Their default severity is the one
    // exception, so an operator can recalibrate a rule that is noisy for everyone.
    if (current.origin !== 'user') {
      const content = Object.keys(patch || {}).filter(k => k !== 'severity' && k !== 'id');
      if (content.length) throw fail('INVALID', `${id} is a built-in rule and read-only (only its default severity can be changed); cannot change ${content.join(', ')}`);
    }
    // A null in the patch removes that field (switching a rule from a pattern to a
    // query has to drop the pattern), and nulls are never stored.
    const body = Object.fromEntries(Object.entries({ ...current.body, ...patch, id }).filter(([, v]) => v !== null && v !== undefined));
    const problem = current.origin === 'user'
      ? validateUserRule(body)
      : (!SEVERITIES.includes(body.severity) && `${id}: severity must be one of ${SEVERITIES.join(', ')}`)
        || (!engineOf(body) && `${id}: cannot determine engine`)
        || null;
    if (problem) throw fail('INVALID', problem);
    db.prepare(`UPDATE rules SET version = version + 1, language = ?, engine = ?, schema_version = ?, severity = ?, body = ?, updated_at = ? WHERE id = ?`)
      .run(body.language, engineOf(body), ENGINE_SCHEMA[engineOf(body)], body.severity, JSON.stringify(body), now(), id);
    bumpProfiles();
    return get(id);
  }

  function deprecate(id) {
    if (!get(id)) throw fail('NOT_FOUND', `rule ${id} not found`);
    db.prepare("UPDATE rules SET status = 'DEPRECATED', updated_at = ? WHERE id = ?").run(now(), id);
    bumpProfiles();
    return get(id);
  }

  // Seeded rules come from trusted, already-built sources (oasis rules/), so
  // they skip the user-rule fixture requirement. Re-seeding identical content
  // changes nothing, which keeps profile versions stable.
  function upsertSeeded(rule, origin) {
    const current = get(rule.id);
    if (!current) { insert(rule, origin); return 'created'; }
    if (JSON.stringify(current.body) === JSON.stringify(rule)) return 'unchanged';
    db.prepare(`UPDATE rules SET version = version + 1, language = ?, engine = ?, schema_version = ?, severity = ?, body = ?, updated_at = ? WHERE id = ?`)
      .run(rule.language, engineOf(rule), ENGINE_SCHEMA[engineOf(rule)], rule.severity, JSON.stringify(rule), now(), rule.id);
    bumpProfiles();
    return 'updated';
  }

  function list({ language, engine, origin, status } = {}) {
    const where = []; const args = [];
    for (const [col, val] of [['language', language], ['engine', engine], ['origin', origin], ['status', status]]) {
      if (val) { where.push(`${col} = ?`); args.push(val); }
    }
    const sql = `SELECT * FROM rules ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id`;
    return db.prepare(sql).all(...args).map(toRow);
  }

  // The list screen's view: light rows, searchable by id, title and description.
  function listSummary({ language, engine, origin, status, search } = {}) {
    const rows = list({ language, engine, origin, status }).map(summarise);
    if (!search) return rows;
    const q = String(search).toLowerCase();
    return rows.filter(r => [r.id, r.title, r.description].some(v => String(v).toLowerCase().includes(q)));
  }

  return { db, validateUserRule, create, update, deprecate, upsertSeeded, get, list, listSummary };
}

module.exports = { createRulesRepo, SEVERITIES };
