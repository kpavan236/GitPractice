'use strict';
const crypto = require('crypto');
const { tx } = require('./db');

// Same vocabulary as the oasis finding model.
const STATUSES = ['OPEN', 'FIXED_PENDING_VERIFICATION', 'RESOLVED', 'REOPENED', 'SUPPRESSED', 'FALSE_POSITIVE'];
const ACTIVE_STATUSES = ['OPEN', 'REOPENED', 'FIXED_PENDING_VERIFICATION'];
const SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
const isActive = finding => ACTIVE_STATUSES.includes(finding.status);

function fail(code, message) {
  return Object.assign(new Error(message), { code });
}

/**
 * Folds one analysis' findings into what is already stored for a project.
 * Port of iready-oasis server/security/store.js mergeFindings, so the server
 * and the scanner's local store make identical decisions.
 *
 * The hard part is not adding new findings; it is deciding what happened to the
 * ones that did not come back.
 */
function mergeFindings(stored, incoming, { coveredTypes, now }) {
  const incomingByFp = new Map(incoming.map(f => [f.fingerprint, f]));
  const result = [];
  const seen = new Set();

  for (const existing of stored) {
    const match = incomingByFp.get(existing.fingerprint);

    if (match) {
      seen.add(existing.fingerprint);
      // A triage decision outlives a rescan. Someone who marked a finding a
      // false positive should not have to do it again every scan; only the
      // facts are refreshed.
      const keepStatus =
        existing.status === 'SUPPRESSED' || existing.status === 'FALSE_POSITIVE'
          ? existing.status
          : existing.status === 'RESOLVED'
            ? 'REOPENED' // it came back
            : existing.status;

      result.push({
        ...existing,
        ...match,
        id: existing.id,
        status: keepStatus,
        firstSeenAt: existing.firstSeenAt || now,
        lastSeenAt: now,
        // Triage metadata belongs to the finding, not to any one scan.
        suppression: existing.suppression || null,
        notes: existing.notes || null,
      });
      continue;
    }

    // Not reported this time. Only conclude something if this analysis could
    // actually have found it: a scanner for its type completed. Without that
    // check, a scan where Semgrep was missing would silently mark every SAST
    // finding resolved.
    if (coveredTypes.includes(existing.type) && ACTIVE_STATUSES.includes(existing.status)) {
      result.push({
        ...existing,
        status: 'RESOLVED',
        resolvedAt: now,
        // Named precisely: no build, no test run, no verification beyond "the
        // scanner stopped reporting it".
        resolvedBy: 'NOT_DETECTED',
      });
    } else {
      result.push(existing);
    }
  }

  for (const finding of incoming) {
    if (seen.has(finding.fingerprint)) continue;
    result.push({ ...finding, firstSeenAt: now, lastSeenAt: now });
  }

  return result;
}

// What an uploading scanner is allowed to say about a finding: the facts. The
// triage state belongs to the server (and the people using it), so a payload
// cannot arrive pre-suppressed, pre-resolved or with notes of its own, and cannot
// use that to hide a finding from the quality gate. A new finding is OPEN.
function sanitizeIncoming(finding) {
  const { suppression, notes, resolvedAt, resolvedBy, ...facts } = finding;
  return { ...facts, status: ACTIVE_STATUSES.includes(facts.status) ? facts.status : 'OPEN' };
}

function createFindingsRepo(db) {
  const rows = projectKey => db.prepare('SELECT body FROM findings WHERE project_key = ?').all(projectKey).map(r => JSON.parse(r.body));
  const upsert = db.prepare(`INSERT INTO findings (project_key, fingerprint, id, status, severity, type, body, first_seen_at, last_seen_at)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                             ON CONFLICT(project_key, fingerprint) DO UPDATE SET
                               id = excluded.id, status = excluded.status, severity = excluded.severity, type = excluded.type,
                               body = excluded.body, first_seen_at = excluded.first_seen_at, last_seen_at = excluded.last_seen_at`);
  const save = (projectKey, finding) =>
    upsert.run(projectKey, finding.fingerprint, finding.id || null, finding.status, finding.severity ?? null, finding.type ?? null,
      JSON.stringify(finding), finding.firstSeenAt ?? null, finding.lastSeenAt ?? null);

  function merge(projectKey, incoming, { coveredTypes, now }) {
    return tx(db, () => {
      const merged = mergeFindings(rows(projectKey), incoming.map(sanitizeIncoming), { coveredTypes, now });
      for (const finding of merged) save(projectKey, finding);
      return merged;
    });
  }

  function list(projectKey, { status = 'active' } = {}) {
    const all = rows(projectKey);
    const wanted = status === 'all' ? all : status === 'active' ? all.filter(isActive) : all.filter(f => f.status === status);
    return wanted.sort((a, b) =>
      (SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity)) || String(a.fingerprint).localeCompare(String(b.fingerprint)));
  }

  function setStatus(projectKey, fingerprint, { status, suppression, notes } = {}) {
    if (!STATUSES.includes(status)) throw fail('INVALID', `status must be one of ${STATUSES.join(', ')}`);
    const row = db.prepare('SELECT body FROM findings WHERE project_key = ? AND fingerprint = ?').get(projectKey, fingerprint);
    if (!row) throw fail('NOT_FOUND', `finding ${fingerprint} not found in ${projectKey}`);
    const finding = { ...JSON.parse(row.body), status };
    if (status === 'REOPENED') finding.suppression = null;
    else if (suppression !== undefined) finding.suppression = suppression;
    if (notes !== undefined) finding.notes = notes;
    save(projectKey, finding);
    return finding;
  }

  // Cross-project listing for the Security tab. Same filters and the same order
  // as the scanner's own listFindings: highest risk score first, because that is
  // the argument of the risk engine (a HIGH on a production service outranks a
  // CRITICAL in a scratch repository). `new` is "active and not in the baseline".
  function listAll({ repository, type, severity, status = 'active', search } = {}, baseline = null) {
    const where = []; const args = [];
    if (repository) { where.push('project_key = ?'); args.push(repository); }
    if (type) { where.push('type = ?'); args.push(type); }
    if (severity) { where.push('severity = ?'); args.push(severity); }
    // Resolved findings are kept forever, so narrow by status in SQL before parsing.
    if (status === 'active' || status === 'new') { where.push(`status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})`); args.push(...ACTIVE_STATUSES); }
    else if (status && status !== 'all') { where.push('status = ?'); args.push(status); }
    const sql = `SELECT body FROM findings ${where.length ? 'WHERE ' + where.join(' AND ') : ''}`;
    let found = db.prepare(sql).all(...args).map(r => JSON.parse(r.body));

    if (status === 'active') found = found.filter(isActive);
    else if (status === 'new') {
      const known = baseline && Array.isArray(baseline.fingerprints) ? new Set(baseline.fingerprints) : null;
      found = found.filter(f => isActive(f) && (!known || !known.has(f.fingerprint)));
    } else if (status && status !== 'all') found = found.filter(f => f.status === status);

    if (search) {
      const q = String(search).toLowerCase();
      found = found.filter(f => [f.title, f.file, f.cve, f.category, f.repository].some(v => v && String(v).toLowerCase().includes(q)));
    }
    return found.sort((a, b) => ((b.risk && b.risk.score) || 0) - ((a.risk && a.risk.score) || 0) || String(a.fingerprint).localeCompare(String(b.fingerprint)));
  }

  function located(id) {
    return db.prepare('SELECT project_key, fingerprint, body FROM findings WHERE id = ?').get(id);
  }
  function getById(id) {
    const row = located(id);
    return row ? JSON.parse(row.body) : null;
  }
  function setStatusById(id, patch) {
    const row = located(id);
    if (!row) throw fail('NOT_FOUND', `finding ${id} not found`);
    return setStatus(row.project_key, row.fingerprint, patch);
  }

  // Restores previously exported state verbatim (migration from the scanner's
  // local store). Not a merge: triage, timestamps and resolutions are kept as
  // they were, so the next analysis merges against what the user last saw.
  // A finding the UI can open needs an id; one exported without it gets a stable
  // one derived from what identifies it.
  const withId = f => (f.id ? f : { ...f, id: `F-imp-${crypto.createHash('sha1').update(`${f.repository}\0${f.fingerprint}`).digest('hex').slice(0, 12)}` });

  function importBulk(items) {
    return tx(db, () => { for (const f of items) save(f.repository, withId(f)); return items.length; });
  }

  // Import on top of a server that has already scanned (a first scan before
  // migrating): add what is missing, and where the scanner's old store has a triage
  // decision for a finding the server now reports as active, adopt that decision.
  // The server's own facts, ids and decisions are never overwritten.
  function importMerge(items) {
    return tx(db, () => {
      const out = { inserted: 0, adopted: 0, skipped: 0 };
      const find = db.prepare('SELECT body FROM findings WHERE project_key = ? AND fingerprint = ?');
      for (const imported of items) {
        const row = find.get(imported.repository, imported.fingerprint);
        if (!row) { save(imported.repository, withId(imported)); out.inserted += 1; continue; }
        const current = JSON.parse(row.body);
        if (isActive(current) && (imported.status === 'SUPPRESSED' || imported.status === 'FALSE_POSITIVE')) {
          save(imported.repository, { ...current, status: imported.status, suppression: imported.suppression || null, notes: imported.notes || current.notes || null });
          out.adopted += 1;
        } else {
          out.skipped += 1;
        }
      }
      return out;
    });
  }

  // Which repositories have findings, and how many, without sending the findings.
  function repositories() {
    const marks = ACTIVE_STATUSES.map(() => '?').join(',');
    return db.prepare(`SELECT project_key AS repository, COUNT(*) AS findings, SUM(status IN (${marks})) AS active
                       FROM findings GROUP BY project_key ORDER BY project_key`).all(...ACTIVE_STATUSES)
      .map(r => ({ repository: r.repository, findings: r.findings, active: r.active }));
  }

  // Re-scoring (a repository's asset context changed) touches only `risk`: triage
  // and every other fact stay as they were.
  function setRisk(updates) {
    return tx(db, () => {
      let updated = 0;
      for (const { id, risk } of updates) {
        const row = located(id);
        if (!row) continue;
        save(row.project_key, { ...JSON.parse(row.body), risk });
        updated += 1;
      }
      return updated;
    });
  }

  return { merge, list, listAll, getById, setStatus, setStatusById, setRisk, importBulk, importMerge, repositories, isActive, ACTIVE_STATUSES };
}

module.exports = { mergeFindings, sanitizeIncoming, createFindingsRepo, STATUSES, ACTIVE_STATUSES, isActive, SEVERITY_ORDER };
