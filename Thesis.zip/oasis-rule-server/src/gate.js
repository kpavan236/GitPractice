'use strict';
const { isActive } = require('./findings');

// Quality gate: "does this analysis satisfy the project's requirements?".
// Rules answer what problems exist; the gate answers whether that is acceptable.
// Port of iready-oasis server/security/gate.js evaluateGate, so the server and
// the scanner reach the same verdict on the same findings.

const DEFAULT_GATE = {
  name: 'default',
  conditions: [
    { metric: 'critical_issues', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    { metric: 'secrets', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    { metric: 'high_severity_cves', scope: 'NEW_CODE', operator: 'GT', threshold: 0 },
    { metric: 'coverage_gaps', scope: 'OVERALL', operator: 'GT', threshold: 0, level: 'WARN' },
  ],
};

const OPERATORS = {
  GT: (actual, threshold) => actual > threshold,
  GTE: (actual, threshold) => actual >= threshold,
  LT: (actual, threshold) => actual < threshold,
  LTE: (actual, threshold) => actual <= threshold,
  EQ: (actual, threshold) => actual === threshold,
};
const OPERATOR_WORDS = { GT: '>', GTE: '>=', LT: '<', LTE: '<=', EQ: '=' };

const METRICS = {
  vulnerabilities: findings => findings.filter(f => ['SAST', 'SCA', 'IAC', 'CONTAINER', 'DAST'].includes(f.type)).length,
  secrets: findings => findings.filter(f => f.type === 'SECRET').length,
  iac_misconfigurations: findings => findings.filter(f => f.type === 'IAC').length,
  license_violations: findings => findings.filter(f => f.type === 'LICENSE').length,
  critical_issues: findings => findings.filter(f => f.severity === 'CRITICAL').length,
  blocker_issues: findings => findings.filter(f => ['CRITICAL', 'HIGH'].includes(f.severity)).length,
  high_severity_cves: findings => findings.filter(f => f.type === 'SCA' && ['CRITICAL', 'HIGH'].includes(f.severity)).length,
  risk_score: findings => findings.reduce((worst, f) => Math.max(worst, (f.risk && f.risk.score) || 0), 0),
};

const coverageGaps = coverage => (coverage || []).filter(c => !c.analysed).length;

// Same messages as the scanner's loadGate, so a bad gate reads the same wherever
// it was written.
function validateGate(gate) {
  if (!gate || !Array.isArray(gate.conditions) || !gate.conditions.length) return 'no conditions defined';
  for (const condition of gate.conditions) {
    if (!METRICS[condition.metric] && condition.metric !== 'coverage_gaps') return `unknown metric "${condition.metric}"`;
    if (!OPERATORS[condition.operator]) return `unknown operator "${condition.operator}"`;
    if (typeof condition.threshold !== 'number') return `${condition.metric}: threshold must be a number`;
  }
  return null;
}

function scopeFindings(findings, scope) {
  const active = (findings || []).filter(isActive);
  return scope === 'NEW_CODE' ? active.filter(f => f.isNewCode) : active;
}

function evaluateGate({ findings = [], coverage = [], gate = DEFAULT_GATE, newCodeAvailable = true, gateError = null } = {}) {
  if (gateError || !gate) {
    return { status: 'NOT_EVALUATED', gate: null, conditions: [], reason: gateError || 'no gate definition', blocking: true };
  }

  const results = [];
  for (const condition of gate.conditions) {
    const scope = condition.scope || 'NEW_CODE';
    const level = condition.level === 'WARN' ? 'WARN' : 'ERROR';

    if (scope === 'NEW_CODE' && !newCodeAvailable) {
      results.push({
        ...condition, scope, level, actual: null, passed: false, status: 'NOT_EVALUATED',
        explanation: 'no diff available, so new code could not be identified',
      });
      continue;
    }

    const scoped = scopeFindings(findings, scope);
    const actual = condition.metric === 'coverage_gaps'
      ? coverageGaps(coverage)
      : METRICS[condition.metric](condition.severity ? scoped.filter(f => f.severity === condition.severity) : scoped);
    const breached = OPERATORS[condition.operator](actual, condition.threshold);

    results.push({
      ...condition, scope, level, actual, passed: !breached, status: breached ? level : 'PASSED',
      explanation: `${condition.metric}${condition.severity ? ` (${condition.severity})` : ''} `
        + `in ${scope === 'NEW_CODE' ? 'new code' : 'overall code'} is ${actual}, `
        + `${breached ? 'which breaches' : 'within'} ${OPERATOR_WORDS[condition.operator]} ${condition.threshold}`,
    });
  }

  const failed = results.filter(r => r.status === 'ERROR' || r.status === 'NOT_EVALUATED');
  const warned = results.filter(r => r.status === 'WARN');
  return {
    status: failed.length ? 'FAILED' : warned.length ? 'WARN' : 'PASSED',
    gate: gate.name,
    conditions: results,
    blocking: failed.length > 0,
    failedCount: failed.length,
    warnCount: warned.length,
    reason: failed.length ? failed.map(r => r.explanation).join('; ') : null,
  };
}

function createGatesRepo(db) {
  function get(projectKey) {
    const row = db.prepare('SELECT body FROM gates WHERE project_key = ?').get(projectKey);
    if (!row) return { gate: DEFAULT_GATE, source: 'default', error: null };
    const stored = JSON.parse(row.body);
    const error = validateGate(stored);
    // A bad stored gate is a failure, not a silent fallback to the default:
    // running different thresholds than the ones configured is how a build
    // passes for reasons nobody can reconstruct.
    if (error) return { gate: null, source: 'project', error };
    return { gate: { name: stored.name || 'project', conditions: stored.conditions }, source: 'project', error: null };
  }
  function set(projectKey, gate) {
    const error = validateGate(gate);
    if (error) throw Object.assign(new Error(error), { code: 'INVALID' });
    db.prepare('INSERT INTO gates (project_key, body) VALUES (?, ?) ON CONFLICT(project_key) DO UPDATE SET body = excluded.body')
      .run(projectKey, JSON.stringify(gate));
    return get(projectKey);
  }
  function clear(projectKey) {
    db.prepare('DELETE FROM gates WHERE project_key = ?').run(projectKey);
  }
  return { get, set, clear };
}

module.exports = { evaluateGate, validateGate, createGatesRepo, DEFAULT_GATE, METRICS, OPERATORS };
