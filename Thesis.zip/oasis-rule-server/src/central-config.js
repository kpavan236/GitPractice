'use strict';

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Reads and checks the settings once, at start-up. A missing or malformed setting stops the service with a message naming it. */
function loadCentralConfig(env = process.env) {
  const need = name => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  const databaseUrl = need('RULES_DATABASE_URL');
  const packDir = need('PACK_DIR');
  if (env.NODE_ENV === 'production' && (env.TRUST_PROXY === undefined || env.TRUST_PROXY === '')) throw new Error('TRUST_PROXY must be set in production (the number of proxies in front of the service; 0 if none), or every caller appears to come from the proxy\'s address.');
  const tlsCertFile = env.TLS_CERT_FILE || '';
  const tlsKeyFile = env.TLS_KEY_FILE || '';
  if (Boolean(tlsCertFile) !== Boolean(tlsKeyFile)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together.');
  const allowPlainHttp = env.ALLOW_PLAIN_HTTP === '1';
  if (env.NODE_ENV === 'production' && !tlsCertFile && !allowPlainHttp) throw new Error('Production needs TLS_CERT_FILE and TLS_KEY_FILE. Set ALLOW_PLAIN_HTTP=1 only when your platform terminates TLS before this service.');
  return {
    tlsCertFile, tlsKeyFile, allowPlainHttp,
    shutdownTimeoutMs: whole(env, 'SHUTDOWN_TIMEOUT_MS', { min: 100, max: 600000, fallback: 10000 }),
    port: whole(env, 'PORT', { min: 1, max: 65535, fallback: 5091 }),
    trustProxy: whole(env, 'TRUST_PROXY', { min: 0, max: 10, fallback: 0 }),
    databaseUrl, packDir,
  };
}

module.exports = { loadCentralConfig };
