'use strict';
const PILLARS = ['security', 'reliability', 'maintainability', 'code-quality'];
const SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
const STATUSES = ['draft', 'proposed', 'active', 'deprecated'];
const ENGINE_SCHEMA = { ast: 1, pattern: 1, 'iac-policy': 1, secret: 1 };
const MAX_PATTERN = 500;

function engineOf(rule) {
  if (rule.query) return 'ast';
  if (rule.engine === 'secret') return 'secret';
  if (rule.engine === 'iac-policy') return 'iac-policy';
  if (rule.pattern) return 'pattern';
  return null;
}

function isEmptyMatching(rule) {
  try { return new RegExp(rule.pattern, rule.patternFlags || '').test(''); } catch (_) { return false; }
}

const isText = (v) => typeof v === 'string' && v.length > 0;

function validatePattern(rule, id) {
  if (!isText(rule.pattern)) return `${id}: pattern must be a non-empty string`;
  if (rule.patternFlags !== undefined && typeof rule.patternFlags !== 'string') return `${id}: patternFlags must be a string`;
  if (rule.pattern.length > MAX_PATTERN) return `${id}: pattern is longer than ${MAX_PATTERN} characters`;
  try { new RegExp(rule.pattern, rule.patternFlags || ''); } catch (e) { return `${id}: pattern does not compile (${e.message})`; }
  if (isEmptyMatching(rule)) return `${id}: pattern matches the empty string`;
  return null;
}

function validateRule(rule, { languages = [] } = {}) {
  if (!rule || typeof rule !== 'object') return 'a rule is required';
  if (typeof rule.id !== 'string' || !/^[a-z0-9][a-z0-9-]*$/.test(rule.id)) return 'id must be lowercase letters, digits and hyphens';
  const id = rule.id;
  if (!languages.includes(rule.language)) return `${id}: language "${rule.language}" is not in the language registry`;
  if (!PILLARS.includes(rule.pillar)) return `${id}: pillar must be one of ${PILLARS.join(', ')}`;
  if (!SEVERITIES.includes(rule.severity)) return `${id}: severity must be one of ${SEVERITIES.join(', ')}`;
  if (rule.status !== undefined && !STATUSES.includes(rule.status)) return `${id}: status must be one of ${STATUSES.join(', ')}`;
  if (!isText(rule.title) || !isText(rule.description)) return `${id}: title and description are required`;
  const ex = rule.example;
  if (!ex || !isText(ex.file) || !isText(ex.vulnerable) || !isText(ex.fixed)) {
    return `${id}: example needs file, vulnerable and fixed (these are the detect and clean fixtures)`;
  }
  if (rule.engine !== undefined && rule.engine !== null && !Object.keys(ENGINE_SCHEMA).includes(rule.engine)) {
    return `${id}: engine must be one of ${Object.keys(ENGINE_SCHEMA).join(', ')}`;
  }
  const engine = engineOf(rule);
  if (!engine) return `${id}: cannot determine engine (needs a query, a pattern, or an engine)`;
  if (rule.pattern !== undefined && rule.pattern !== null) {
    const problem = validatePattern(rule, id);
    if (problem) return problem;
  }
  if (engine === 'pattern') {
    if (!Array.isArray(rule.files) || !rule.files.length || !rule.files.every(isText)) {
      return `${id}: pattern rules need a files glob array of non-empty strings`;
    }
  }
  return null;
}

module.exports = { PILLARS, SEVERITIES, STATUSES, ENGINE_SCHEMA, engineOf, validateRule, isEmptyMatching };
