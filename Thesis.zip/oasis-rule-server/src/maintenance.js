'use strict';
const { tx } = require('./db');

const TRIAGED = "('SUPPRESSED','FALSE_POSITIVE')";

// Clearing and resetting, with a preview so the confirm step can say what it is
// about to destroy. Scans, SBOMs and settings are the scanner's; this reports
// only what the server holds.
function createMaintenance(db) {
  const count = (sql, ...args) => db.prepare(sql).get(...args).n;

  function preview({ repository = null } = {}) {
    const scope = repository ? 'WHERE project_key = ?' : '';
    const a = repository ? [repository] : [];
    return {
      repository,
      findings: count(`SELECT COUNT(*) AS n FROM findings ${scope}`, ...a),
      suppressed: count(`SELECT COUNT(*) AS n FROM findings ${scope ? scope + ' AND' : 'WHERE'} status IN ${TRIAGED}`, ...a),
      history: count('SELECT COUNT(*) AS n FROM history'),
      repositories: count('SELECT COUNT(DISTINCT project_key) AS n FROM findings'),
    };
  }

  // keepSuppressed (default) keeps triage decisions: someone who marked a finding
  // a false positive should not lose that by clearing a repository. History and
  // the baseline are untouched; only reset removes them.
  function clear({ repository = null, keepSuppressed = true } = {}) {
    const before = preview({ repository });
    return tx(db, () => {
      const scope = repository ? 'project_key = ?' : '1 = 1';
      const a = repository ? [repository] : [];
      db.prepare(`DELETE FROM findings WHERE ${scope}${keepSuppressed ? ` AND status NOT IN ${TRIAGED}` : ''}`).run(...a);
      db.prepare(`DELETE FROM analyses WHERE ${repository ? 'project_key = ?' : '1 = 1'}`).run(...a);
      return { ...before, keptSuppressed: keepSuppressed ? before.suppressed : 0, findings: before.findings - (keepSuppressed ? before.suppressed : 0) };
    });
  }

  // Everything above plus the trend history and the baseline, the two things
  // that cannot be rebuilt by scanning again. The user's settings (gates,
  // projects, profiles, rules) are not findings and survive.
  function reset() {
    const before = preview({});
    return tx(db, () => {
      for (const table of ['findings', 'analyses', 'history', 'baseline']) db.prepare(`DELETE FROM ${table}`).run();
      return { ...before, reset: true };
    });
  }

  return { preview, clear, reset };
}

module.exports = { createMaintenance };
