'use strict';
// Runs one rule against its own fixture with the real analyzer engine. It lives
// in a worker thread so the parent can kill it: a pathological regex cannot be
// interrupted from inside the thread that is running it.
const { parentPort, workerData: rule } = require('worker_threads');
const engine = require('oasis-analyzer/src/ast/engine');
const { scanSource } = require('oasis-analyzer/src/scanners/sast-ast');
const { scanContent, compileRule } = require('oasis-analyzer/src/scanners/pattern-sast');

const hitsFor = findings => findings.filter(f => f.detections[0].ruleId === rule.id);

async function run() {
  const engineName = rule.engine || (rule.query ? 'ast' : rule.pattern ? 'pattern' : null);
  if (engineName !== 'ast' && engineName !== 'pattern') {
    return { problems: [`engine ${engineName} has no fixture tester`] };
  }
  const example = rule.example;
  if (!example || typeof example.vulnerable !== 'string' || typeof example.fixed !== 'string' || !example.file) {
    return { problems: ['rule needs an example with file, vulnerable and fixed'] };
  }

  let scan;
  if (engineName === 'ast') {
    if (!rule.query || !(await engine.compileQuery(rule.language, rule.query))) {
      return { problems: [`query does not compile for ${rule.language}`] };
    }
    scan = source => scanSource(source, example.file, 'repo', [rule]);
  } else {
    const compiled = compileRule(rule);
    if (!compiled) return { problems: ['pattern does not compile, or the files glob is missing'] };
    scan = source => scanContent(source, example.file, 'repo', [compiled]);
  }

  const detectHits = hitsFor(await scan(example.vulnerable));
  const cleanHits = hitsFor(await scan(example.fixed));
  const problems = [];
  if (!detectHits.length) problems.push('missed its vulnerable example');
  if (cleanHits.length) problems.push('fired on its own fix');
  return {
    detect: { matched: detectHits.length > 0, lines: detectHits.map(f => f.startLine) },
    clean: { matched: cleanHits.length > 0 },
    problems,
  };
}

run().then(
  result => parentPort.postMessage(result),
  err => parentPort.postMessage({ problems: [`tester failed: ${err && err.message ? err.message : err}`] }),
);
