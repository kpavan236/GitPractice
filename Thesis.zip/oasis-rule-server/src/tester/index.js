'use strict';
const path = require('path');
const { Worker } = require('worker_threads');

function testRule(rule, { timeoutMs = 5000 } = {}) {
  return new Promise(resolve => {
    let settled = false;
    let worker;
    let timer;

    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (worker) worker.terminate().catch(() => {});
      resolve({
        detect: { matched: false, lines: [] },
        clean: { matched: false },
        ...result,
        ok: !result.problems.length && !!result.detect && result.detect.matched && !result.clean.matched,
      });
    };

    try {
      worker = new Worker(path.join(__dirname, 'worker.js'), { workerData: rule });
    } catch (err) {
      return finish({ problems: [`tester failed: ${err.message}`] });
    }
    timer = setTimeout(() => finish({ problems: [`timed out after ${timeoutMs} ms`] }), timeoutMs);
    worker.once('message', finish);
    worker.once('error', err => finish({ problems: [`tester failed: ${err && err.message ? err.message : err}`] }));
    worker.once('exit', code => finish({ problems: [`tester exited with code ${code} before answering`] }));
  });
}

module.exports = { testRule };
