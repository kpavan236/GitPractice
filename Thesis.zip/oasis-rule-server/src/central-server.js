'use strict';
const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const { loadCentralConfig } = require('./central-config');
const { createPool } = require('./pg');
const { createBlobStore } = require('./packs/blobs');
const { createReleases } = require('./releases');
const { createCentralApp } = require('./central-app');

/** The public service only answers "latest" and serves blobs: it needs no signer, tester or analyzer. */
function createCentralServices(config, pool) {
  const blobs = createBlobStore(config.packDir);
  const releases = createReleases({ pool, blobs });
  return { blobs, releases };
}

/**
 * Stops accepting connections, closes idle ones, waits for in-flight requests, ends the pool, then calls exit(0).
 * If draining takes longer than timeoutMs, open connections are cut and exit(1) is called. Safe to call twice.
 */
function createShutdown({ server, pool, timeoutMs, exit = process.exit, log = () => {} }) {
  let started = false;
  return function shutdown(signal) {
    if (started) return Promise.resolve();
    started = true;
    log({ level: 'info', msg: 'shutdown', signal });
    return new Promise((resolve) => {
      let forced = false;
      const timer = setTimeout(() => { forced = true; server.closeAllConnections(); }, timeoutMs);
      server.close(async () => {
        clearTimeout(timer);
        try { if (pool) await pool.end(); } catch { /* exiting anyway */ }
        exit(forced ? 1 : 0);
        resolve();
      });
      server.closeIdleConnections();
    });
  };
}

function start(env = process.env) {
  const config = loadCentralConfig(env);
  const tls = Boolean(config.tlsCertFile);
  const pool = createPool(config.databaseUrl);
  const { blobs, releases } = createCentralServices(config, pool);
  const log = (entry) => (entry.level === 'error' ? console.error : console.log)(JSON.stringify(entry));
  const app = createCentralApp({ pool, blobs, releases, packDir: config.packDir, tls, trustProxy: config.trustProxy, log });
  const server = tls
    ? https.createServer({ cert: fs.readFileSync(config.tlsCertFile), key: fs.readFileSync(config.tlsKeyFile) }, app)
    : http.createServer(app);
  const shutdown = createShutdown({ server, pool, timeoutMs: config.shutdownTimeoutMs, log });
  for (const sig of ['SIGTERM', 'SIGINT']) process.once(sig, () => shutdown(sig));
  return server.listen(config.port, () => log({ level: 'info', msg: 'listening', port: config.port, tls }));
}

module.exports = { start, createCentralServices, createShutdown };

if (require.main === module) {
  try { start(); } catch (err) { console.error(JSON.stringify({ level: 'error', msg: 'startup failed', error: err.message })); process.exit(1); }
}
