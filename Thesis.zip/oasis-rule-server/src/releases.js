'use strict';
// Storage design. One `release` row per release number. buildCandidate stores the UNSIGNED content in release.manifest:
//   { packs, minLoader, ruleVersions: {ruleId: version}, deprecated: [ruleId], signed: {} }
// with signature '' and key_id ''. A manifest carries its channel, so it is signed at PUBLISH time, once per channel:
//   signed: { beta: {manifest, keyId, signature}, stable: {...} }
// where manifest = {release, channel, createdAt, minLoader, packs}. Promoting beta -> stable re-signs with channel
// 'stable', so latest(channel) always returns a manifest whose `channel` is the one asked for. The row's own
// signature/key_id columns hold the most recent signature. verifyManifest never looks at this layout.
const { tx } = require('./pg');
const { createAudit } = require('./audit');
const { buildPacks } = require('./packs/build');
const { signManifest, MIN_LOADER } = require('./manifest');

const fail = (code, message, extra) => Object.assign(new Error(message), { code }, extra);
const need = (reason) => { if (!reason || !String(reason).trim()) throw fail('INVALID', 'a reason is required'); };
const CHANNELS = ['beta', 'stable'];
const toPackEntry = (p) => ({ packId: p.packId, kind: p.kind, language: p.language, version: p.version, sha256: p.sha256, size: p.size });

function createReleases({ pool, blobs, rules, tester, sign, analyzerDir, grammarDir }) {
  const audit = createAudit({ pool });

  async function gate(active) {
    const withFixture = active.filter((r) => r.body && r.body.example);
    const failures = [];
    let next = 0;
    const worker = async () => {
      while (next < withFixture.length) {
        const r = withFixture[next++];
        const res = await tester.testRule(r.body);
        if (!res.ok) failures.push({ ruleId: r.rule_id, problems: res.problems || [] });
      }
    };
    await Promise.all(Array.from({ length: Math.min(8, withFixture.length) }, worker));
    if (failures.length) {
      failures.sort((a, b) => (a.ruleId < b.ruleId ? -1 : 1));
      throw fail('FIXTURE_FAILED', `${failures.length} rule(s) fail their fixtures: ${failures.map((f) => f.ruleId).join(', ')}`, { failures });
    }
    return active.length - withFixture.length;
  }

  async function row(client, releaseNo, lock = false) {
    const n = Number(releaseNo);
    const { rows } = Number.isInteger(n)
      ? await client.query(`SELECT * FROM release WHERE release_no = $1${lock ? ' FOR UPDATE' : ''}`, [n])
      : { rows: [] };
    if (!rows[0]) throw fail('NOT_FOUND', `release ${releaseNo} does not exist`);
    return rows[0];
  }

  function signFor(r, channel) {
    const { packs, minLoader } = r.manifest;
    const manifest = { release: Number(r.release_no), channel, createdAt: new Date().toISOString(), minLoader, packs };
    return signManifest(manifest, sign.privateKeyPem, sign.keyId);
  }

  function checkChannel(channel) {
    if (!CHANNELS.includes(channel)) throw fail('INVALID', `channel must be one of ${CHANNELS.join(', ')}`);
  }

  async function writeSigned(client, r, channel, state) {
    const signed = signFor(r, channel);
    const manifest = { ...r.manifest, signed: { ...r.manifest.signed, [channel]: signed } };
    await client.query(
      'UPDATE release SET manifest=$2, signature=$3, key_id=$4, state=$5 WHERE release_no=$1',
      [r.release_no, JSON.stringify(manifest), signed.signature, signed.keyId, state],
    );
    return { ...r, manifest, state };
  }

  return {
    async buildCandidate({ actor, reason } = {}) {
      const active = await rules.list({ status: 'active' });
      const skippedNoFixture = await gate(active);
      const deprecated = (await rules.list({ status: 'deprecated' })).map((r) => r.rule_id);
      const { rows: langRows } = await pool.query('SELECT id, extensions, grammar FROM language ORDER BY id');
      const languages = langRows.map((l) => ({ id: l.id, extensions: l.extensions, grammar: l.grammar }));
      const built = await buildPacks({ rules: active.map((r) => r.body), languages, analyzerDir, grammarDir, blobs });
      const packs = built.map(toPackEntry);
      const ruleVersions = Object.fromEntries(active.map((r) => [r.rule_id, r.version]));
      const content = { packs, minLoader: MIN_LOADER, ruleVersions, deprecated, signed: {} };
      const releaseNo = await tx(pool, async (client) => {
        for (const p of built) {
          await client.query(
            'INSERT INTO pack (sha256, kind, pack_id, language, version, size) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (sha256) DO NOTHING',
            [p.sha256, p.kind, p.packId, p.language, p.version, p.size],
          );
        }
        const { rows } = await client.query(
          "INSERT INTO release (state, manifest, signature, key_id, created_by) VALUES ('candidate',$1,'','',$2) RETURNING release_no",
          [JSON.stringify(content), actor],
        );
        const no = Number(rows[0].release_no);
        await audit.record({ actor, action: 'release.build', subject: String(no), reason: reason || null, detail: { packs: packs.length, rules: active.length, skippedNoFixture } }, client);
        return no;
      });
      return { releaseNo, manifest: content, skippedNoFixture };
    },

    // Read-only listing for the Studio: newest first, no signatures and no blob bytes.
    async list() {
      const { rows } = await pool.query('SELECT release_no, state, created_at, created_by, manifest FROM release ORDER BY release_no DESC');
      const heads = Object.fromEntries((await pool.query('SELECT name, release_no FROM channel')).rows.map((c) => [c.name, c.release_no === null ? null : Number(c.release_no)]));
      return {
        releases: rows.map((r) => ({
          releaseNo: Number(r.release_no), state: r.state, createdAt: r.created_at, createdBy: r.created_by,
          ruleCount: Object.keys(r.manifest.ruleVersions || {}).length, packCount: (r.manifest.packs || []).length,
        })),
        channels: { beta: heads.beta === undefined ? null : heads.beta, stable: heads.stable === undefined ? null : heads.stable },
      };
    },

    async diff(releaseNo) {
      const r = await row(pool, releaseNo);
      const { rows } = await pool.query('SELECT r.* FROM channel c JOIN release r ON r.release_no = c.release_no WHERE c.name = $1', ['stable']);
      const base = rows[0] ? rows[0].manifest : { packs: [], ruleVersions: {}, deprecated: [] };
      const cur = r.manifest;
      const ids = Object.keys(cur.ruleVersions || {}).sort();
      const baseShas = new Set(base.packs.map((p) => p.sha256));
      return {
        added: ids.filter((id) => !(id in base.ruleVersions)),
        changed: ids.filter((id) => id in base.ruleVersions && base.ruleVersions[id] !== cur.ruleVersions[id]),
        deprecated: (cur.deprecated || []).filter((id) => id in base.ruleVersions).sort(),
        packsChanged: cur.packs.filter((p) => !baseShas.has(p.sha256)).map((p) => p.packId),
      };
    },

    async publish(releaseNo, channel, { actor, reason } = {}) {
      checkChannel(channel);
      need(reason);
      return tx(pool, async (client) => {
        const r = await row(client, releaseNo, true);
        if (r.state === 'retired') throw fail('INVALID', `release ${r.release_no} is retired`);
        if (channel === 'stable' && !(r.manifest.signed && r.manifest.signed.beta)) {
          throw fail('INVALID', `release ${r.release_no} must be on beta before it can go to stable`);
        }
        const state = channel === 'stable' ? 'stable' : (r.state === 'candidate' ? 'beta' : r.state);
        const updated = await writeSigned(client, r, channel, state);
        await client.query('UPDATE channel SET release_no = $2 WHERE name = $1', [channel, r.release_no]);
        await audit.record({ actor, action: 'release.publish', subject: String(r.release_no), reason, detail: { channel, from: r.state, to: state } }, client);
        return { releaseNo: Number(r.release_no), channel, state: updated.state };
      });
    },

    async rollback(channel, toReleaseNo, { actor, reason } = {}) {
      checkChannel(channel);
      need(reason);
      return tx(pool, async (client) => {
        const r = await row(client, toReleaseNo, true);
        if (r.state !== 'beta' && r.state !== 'stable') throw fail('INVALID', `release ${r.release_no} is ${r.state}; only a published release can be rolled back to`);
        const prev = (await client.query('SELECT release_no FROM channel WHERE name = $1 FOR UPDATE', [channel])).rows[0];
        if (!(r.manifest.signed && r.manifest.signed[channel])) await writeSigned(client, r, channel, r.state);
        await client.query('UPDATE channel SET release_no = $2 WHERE name = $1', [channel, r.release_no]);
        await audit.record({ actor, action: 'release.rollback', subject: String(r.release_no), reason, detail: { channel, from: prev && prev.release_no !== null ? Number(prev.release_no) : null } }, client);
        return { releaseNo: Number(r.release_no), channel };
      });
    },

    async latest(channel, sinceRelease) {
      checkChannel(channel);
      const { rows } = await pool.query(
        'SELECT r.* FROM channel c JOIN release r ON r.release_no = c.release_no WHERE c.name = $1', [channel]);
      if (!rows[0]) throw fail('NOT_FOUND', `nothing is published on ${channel}`);
      const s = rows[0].manifest.signed[channel];
      const known = new Set();
      if (sinceRelease !== undefined && sinceRelease !== null) {
        const n = Number(sinceRelease);
        if (Number.isInteger(n)) {
          const old = (await pool.query('SELECT manifest FROM release WHERE release_no = $1', [n])).rows[0];
          if (old) old.manifest.packs.forEach((p) => known.add(p.sha256));
        }
      }
      return {
        manifest: s.manifest, keyId: s.keyId, signature: s.signature,
        changedPackIds: s.manifest.packs.filter((p) => !known.has(p.sha256)).map((p) => p.packId),
      };
    },
  };
}

module.exports = { createReleases };
