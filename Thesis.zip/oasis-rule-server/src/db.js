'use strict';
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS rules (
  id TEXT PRIMARY KEY,
  version INTEGER NOT NULL DEFAULT 1,
  language TEXT NOT NULL,
  engine TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1,
  severity TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  origin TEXT NOT NULL,
  body TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  is_default INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  parent_id TEXT
);
CREATE TABLE IF NOT EXISTS profile_rules (
  profile_id TEXT NOT NULL,
  rule_id TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  severity TEXT,
  params TEXT NOT NULL DEFAULT '{}',
  PRIMARY KEY (profile_id, rule_id)
);
CREATE TABLE IF NOT EXISTS findings (
  project_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  id TEXT,
  status TEXT NOT NULL,
  severity TEXT,
  type TEXT,
  body TEXT NOT NULL,
  first_seen_at INTEGER,
  last_seen_at INTEGER,
  PRIMARY KEY (project_key, fingerprint)
);
CREATE INDEX IF NOT EXISTS findings_by_id ON findings (id);
CREATE TABLE IF NOT EXISTS baseline (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  body TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS analyses (
  id TEXT PRIMARY KEY,
  project_key TEXT NOT NULL,
  profile_id TEXT,
  profile_version INTEGER,
  rule_set_version TEXT,
  scanner_version TEXT,
  analyzer_version TEXT,
  used_cache INTEGER NOT NULL DEFAULT 0,
  mode TEXT,
  started_at TEXT,
  completed_at TEXT,
  status TEXT NOT NULL,
  gate_status TEXT,
  gate TEXT,
  counts TEXT
);
CREATE TABLE IF NOT EXISTS history (
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  analysis_id TEXT,
  scan_id TEXT,
  total INTEGER NOT NULL,
  counts TEXT NOT NULL,
  by_type TEXT NOT NULL,
  projects INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS gates (
  project_key TEXT PRIMARY KEY,
  body TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  profile_id TEXT
);
`;

// Columns added after a table first shipped. CREATE TABLE IF NOT EXISTS leaves an
// older database without them, so each is added (and backfilled) here.
function columns(db, table) {
  return db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
}

function migrate(db) {
  db.exec(SCHEMA);
  if (!columns(db, 'findings').includes('severity')) {
    db.exec('ALTER TABLE findings ADD COLUMN severity TEXT');
    db.exec('ALTER TABLE findings ADD COLUMN type TEXT');
    const set = db.prepare('UPDATE findings SET severity = ?, type = ? WHERE project_key = ? AND fingerprint = ?');
    for (const r of db.prepare('SELECT project_key, fingerprint, body FROM findings').all()) {
      const body = JSON.parse(r.body);
      set.run(body.severity ?? null, body.type ?? null, r.project_key, r.fingerprint);
    }
  }
  if (!columns(db, 'history').includes('scan_id')) db.exec('ALTER TABLE history ADD COLUMN scan_id TEXT');
  db.exec('CREATE INDEX IF NOT EXISTS history_by_scan ON history (scan_id)');
}

function openDb(file = ':memory:') {
  const db = new DatabaseSync(file);
  migrate(db);
  return db;
}

// Runs fn inside one transaction; any throw rolls everything back. Re-entrant:
// a call made while a transaction is open joins it, so a caller that wraps
// several repositories' writes gets all-or-nothing across them.
const open = new WeakSet();
function tx(db, fn) {
  if (open.has(db)) return fn();
  db.exec('BEGIN');
  open.add(db);
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    open.delete(db);
  }
}

module.exports = { openDb, migrate, tx };
