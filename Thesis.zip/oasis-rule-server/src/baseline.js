'use strict';
const { ACTIVE_STATUSES } = require('./findings');

// "Everything here today is known; tell me what arrives next": the mechanism
// that lets a 27-finding backlog stop failing every build while the 28th still
// does. Same shape as the scanner's baseline: { createdAt, fingerprints }.
function createBaselineRepo(db) {
  const get = () => {
    const row = db.prepare('SELECT body FROM baseline WHERE id = 1').get();
    return row ? JSON.parse(row.body) : null;
  };
  function set(now = Date.now()) {
    const marks = ACTIVE_STATUSES.map(() => '?').join(',');
    const fingerprints = [...new Set(db.prepare(`SELECT fingerprint FROM findings WHERE status IN (${marks})`).all(...ACTIVE_STATUSES).map(r => r.fingerprint))];
    const baseline = { createdAt: now, fingerprints };
    db.prepare('INSERT INTO baseline (id, body) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET body = excluded.body').run(JSON.stringify(baseline));
    return baseline;
  }
  const clear = () => { db.prepare('DELETE FROM baseline').run(); };
  // Puts back a baseline exactly as it was (migration from the scanner's store).
  function restore(b) {
    const baseline = { createdAt: b.createdAt ?? Date.now(), fingerprints: [...new Set(b.fingerprints)] };
    db.prepare('INSERT INTO baseline (id, body) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET body = excluded.body').run(JSON.stringify(baseline));
    return baseline;
  }
  return { get, set, clear, restore };
}

module.exports = { createBaselineRepo };
