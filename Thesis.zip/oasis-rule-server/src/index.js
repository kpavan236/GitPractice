'use strict';
// The rules core, as a library. oasis-rule-studio depends on this file and on ./testing only; package.json "exports" blocks every
// other path, so renaming an internal file cannot break the Studio, and renaming an export here fails test/library-exports.test.js.
module.exports = {
  ...require('./pg'),
  ...require('./migrate'),
  ...require('./languages'),
  ...require('./audit'),
  ...require('./manifest'),
  ...require('./rate-limit'),
  ...require('./model/rule'),
  ...require('./rules/repo'),
  ...require('./tester'),
  ...require('./releases'),
  ...require('./packs/blobs'),
  ...require('./packs/build'),
};
