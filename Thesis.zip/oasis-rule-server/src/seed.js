'use strict';
const fs = require('fs');
const path = require('path');
const { tx } = require('./db');

function* jsonFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* jsonFiles(full);
    else if (entry.name.endsWith('.json')) yield full;
  }
}

// Imports oasis-style rule files (one rule per file, any depth). The oasis
// build refuses to redistribute rule sets whose licence forbids it; that
// decision stays with the caller through `allowSources`.
function seedFromDir(rulesRepo, dir, { allowSources = null } = {}) {
  return tx(rulesRepo.db, () => importAll(rulesRepo, dir, allowSources));
}

function importAll(rulesRepo, dir, allowSources) {
  const result = { created: 0, updated: 0, unchanged: 0, excluded: 0 };
  for (const file of jsonFiles(dir)) {
    let rule;
    try { rule = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { throw new Error(`${path.relative(dir, file)}: ${e.message}`); }

    const source = rule.provenance && rule.provenance.source;
    if (source && Array.isArray(allowSources) && !allowSources.includes(source)) {
      result.excluded += 1;
      continue;
    }
    result[rulesRepo.upsertSeeded(rule, rule.provenance ? 'vendor' : 'builtin')] += 1;
  }
  return result;
}

module.exports = { seedFromDir };
