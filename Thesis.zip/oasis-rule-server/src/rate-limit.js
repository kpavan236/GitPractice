'use strict';

// A fixed-window limit per caller, in this process; a first line of defence, the gateway in front is the real one.
// The caller is the proxy-aware req.ip, so the app's `trust proxy` must equal the number of proxies in front of the
// service. An IPv6 address is counted by its /64 (one subscriber holds a whole /64). Memory is bounded: expired
// entries are swept on a timer tick of the request clock, and past `maxKeys` the oldest are dropped.
function callerKey(ip) {
  if (!ip) return 'unknown';
  const v4 = ip.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/i);
  if (v4) return v4[1];
  if (!ip.includes(':')) return ip;
  const groups = ip.toLowerCase().split('::');
  const head = groups[0] ? groups[0].split(':') : [];
  const tail = groups.length > 1 && groups[1] ? groups[1].split(':') : [];
  const full = [...head, ...Array(Math.max(0, 8 - head.length - tail.length)).fill('0'), ...tail];
  return `${full.slice(0, 4).map((g) => g.padStart(4, '0')).join(':')}::/64`;
}

// `key(req)` names the caller; the default is the address. A signed-in route can key by user instead.
function rateLimit({ windowMs = 60_000, max = 60, maxKeys = 50_000, now = Date.now, key: keyOf = (req) => callerKey(req.ip) } = {}) {
  const hits = new Map();
  let nextSweep = now() + windowMs;
  const sweep = (t) => {
    nextSweep = t + windowMs;
    for (const [k, v] of hits) if (t - v.start >= windowMs) hits.delete(k);
    while (hits.size > maxKeys) hits.delete(hits.keys().next().value);   // a Map iterates oldest first
  };
  return (req, res, next) => {
    const t = now();
    if (t >= nextSweep || hits.size > maxKeys * 2) sweep(t);
    const key = String(keyOf(req));
    const entry = hits.get(key);
    if (!entry || t - entry.start >= windowMs) { hits.set(key, { start: t, count: 1 }); return next(); }
    if (++entry.count > max) {
      res.set('Retry-After', String(Math.max(1, Math.ceil((entry.start + windowMs - t) / 1000))));
      return res.status(429).json({ error: 'TOO_MANY_REQUESTS' });
    }
    next();
  };
}

module.exports = { rateLimit, callerKey };
