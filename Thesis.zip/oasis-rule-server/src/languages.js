'use strict';
const fs = require('node:fs');

const ENGINE_FALLBACKS = ['pattern', 'iac-policy', 'ast'];

function loadLanguages(file) {
  const list = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(list)) throw new Error(`${file}: expected an array of languages`);
  return list;
}

async function seedLanguages(pool, list) {
  for (const l of list) {
    await pool.query(
      `INSERT INTO language (id, name, extensions, engine_fallback, grammar, licence_note)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, extensions = EXCLUDED.extensions,
         engine_fallback = EXCLUDED.engine_fallback, grammar = EXCLUDED.grammar, licence_note = EXCLUDED.licence_note`,
      [l.id, l.name, l.extensions, l.engineFallback || 'pattern', l.grammar ? JSON.stringify(l.grammar) : null, l.licenceNote || null]);
  }
}

/** Per-language count of active rules by pillar; meetsMinimum = at least one active rule. */
async function coverage(pool) {
  const { rows } = await pool.query(
    `SELECT l.id, l.name, l.grammar IS NOT NULL AS grammar,
            count(r.rule_id) AS total,
            count(r.rule_id) FILTER (WHERE r.pillar = 'security') AS security,
            count(r.rule_id) FILTER (WHERE r.pillar = 'reliability') AS reliability,
            count(r.rule_id) FILTER (WHERE r.pillar = 'maintainability') AS maintainability,
            count(r.rule_id) FILTER (WHERE r.pillar = 'code-quality') AS code_quality
       FROM language l LEFT JOIN rule r ON r.language = l.id AND r.status = 'active'
      GROUP BY l.id, l.name, l.grammar
      ORDER BY l.id`);
  return rows.map((r) => ({
    language: r.id, name: r.name, ruleCount: Number(r.total),
    pillars: {
      security: Number(r.security), reliability: Number(r.reliability),
      maintainability: Number(r.maintainability), 'code-quality': Number(r.code_quality),
    },
    grammar: r.grammar, meetsMinimum: Number(r.total) >= 1,
  }));
}

module.exports = { loadLanguages, seedLanguages, coverage, ENGINE_FALLBACKS };
