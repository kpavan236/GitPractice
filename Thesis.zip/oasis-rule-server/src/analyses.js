'use strict';
const { tx } = require('./db');
const { evaluateGate } = require('./gate');
const { sanitizeIncoming, ACTIVE_STATUSES, SEVERITY_ORDER } = require('./findings');

function fail(code, message) {
  return Object.assign(new Error(message), { code });
}

const countBySeverity = findings => Object.fromEntries(SEVERITY_ORDER.map(s => [s, findings.filter(f => f.severity === s).length]));

function validate(p) {
  if (!p || typeof p !== 'object') return 'payload must be an object';
  if (typeof p.analysisId !== 'string' || !p.analysisId) return 'analysisId is required';
  if (typeof p.projectKey !== 'string' || !p.projectKey) return 'projectKey is required';
  if (!Array.isArray(p.findings)) return 'findings must be an array';
  if (p.findings.some(f => !f || typeof f.fingerprint !== 'string' || !f.fingerprint)) return 'every finding needs a fingerprint';
  if (p.coverage !== undefined && !Array.isArray(p.coverage)) return 'coverage must be an array';
  return null;
}

function toRun(r) {
  return r && {
    id: r.id, projectKey: r.project_key, profileId: r.profile_id, profileVersion: r.profile_version,
    ruleSetVersion: r.rule_set_version, scannerVersion: r.scanner_version, analyzerVersion: r.analyzer_version,
    usedCache: !!r.used_cache, mode: r.mode, startedAt: r.started_at, completedAt: r.completed_at,
    status: r.status, gateStatus: r.gate_status, gate: JSON.parse(r.gate), counts: JSON.parse(r.counts),
  };
}

// One analysis = one scanner run over one project. Recording it merges the
// findings, evaluates the quality gate and appends a trend point, all or nothing.
function createAnalysesRepo({ db, findings, gates, now = Date.now }) {
  function record(payload) {
    const problem = validate(payload);
    if (problem) throw fail('INVALID', problem);

    return tx(db, () => {
      if (db.prepare('SELECT 1 FROM analyses WHERE id = ?').get(payload.analysisId)) {
        throw fail('CONFLICT', `analysis ${payload.analysisId} was already recorded`);
      }
      const at = now();
      const coverage = payload.coverage || [];
      // Facts only: see sanitizeIncoming. The gate must judge the same findings
      // that get stored.
      const incoming = payload.findings.map(sanitizeIncoming);
      findings.merge(payload.projectKey, incoming, {
        coveredTypes: coverage.filter(c => c.analysed).map(c => c.type),
        now: at,
      });

      // The verdict is about THIS analysis' findings, as the scanner computes it,
      // not about the stored backlog.
      const configured = gates.get(payload.projectKey);
      const gate = evaluateGate({
        findings: incoming, coverage, gate: configured.gate, gateError: configured.error,
        newCodeAvailable: payload.newCodeAvailable !== false,
      });
      const counts = countBySeverity(incoming);

      db.prepare(`INSERT INTO analyses (id, project_key, profile_id, profile_version, rule_set_version, scanner_version,
                    analyzer_version, used_cache, mode, started_at, completed_at, status, gate_status, gate, counts)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMPLETED', ?, ?, ?)`)
        .run(payload.analysisId, payload.projectKey, payload.profile?.id ?? null, payload.profile?.version ?? null,
          payload.ruleSetVersion ?? null, payload.scannerVersion ?? null, payload.analyzerVersion ?? null,
          payload.usedCache ? 1 : 0, payload.mode ?? null, payload.startedAt ?? null, payload.completedAt ?? null,
          gate.status, JSON.stringify(gate), JSON.stringify(counts));

      // Snapshot AFTER the merge so the point reflects what is open now,
      // including findings this analysis resolved: that movement is the trend.
      // Aggregated in SQL on indexed-width columns: this runs inside the write
      // transaction of every analysis, and parsing every stored finding of every
      // project here would grow without bound (resolved findings are kept).
      const activeIn = ACTIVE_STATUSES.map(s => `'${s}'`).join(',');
      const bySeverity = Object.fromEntries(db.prepare(`SELECT severity, COUNT(*) AS n FROM findings WHERE status IN (${activeIn}) GROUP BY severity`).all().map(r => [r.severity, r.n]));
      const byType = Object.fromEntries(db.prepare(`SELECT type, COUNT(*) AS n FROM findings WHERE status IN (${activeIn}) GROUP BY type`).all().map(r => [r.type, r.n]));
      const total = Object.values(bySeverity).reduce((a, b) => a + b, 0);
      const projects = db.prepare('SELECT COUNT(DISTINCT project_key) AS n FROM findings').get().n;
      // One trend point per SCAN, as the scanner has always kept it: the analyses of
      // a multi-repository scan land one at a time, and each updates the scan's point
      // instead of adding another (otherwise "since last scan" would compare
      // repositories, not scans).
      const scanTime = payload.completedAt && Number.isFinite(Date.parse(payload.completedAt)) ? Date.parse(payload.completedAt) : at;
      const point = [scanTime, payload.analysisId, total,
        JSON.stringify(Object.fromEntries(SEVERITY_ORDER.map(s => [s, bySeverity[s] || 0]))),
        JSON.stringify(byType), projects];
      const existing = payload.scanId && db.prepare('SELECT seq FROM history WHERE scan_id = ?').get(payload.scanId);
      if (existing) {
        db.prepare('UPDATE history SET at = ?, analysis_id = ?, total = ?, counts = ?, by_type = ?, projects = ? WHERE seq = ?').run(...point, existing.seq);
      } else {
        db.prepare('INSERT INTO history (at, analysis_id, total, counts, by_type, projects, scan_id) VALUES (?, ?, ?, ?, ?, ?, ?)').run(...point, payload.scanId ?? null);
      }

      return { analysisId: payload.analysisId, gate, gateSource: configured.source, counts };
    });
  }

  const get = id => toRun(db.prepare('SELECT * FROM analyses WHERE id = ?').get(id));
  const listForProject = (key, { limit = 50 } = {}) =>
    db.prepare('SELECT * FROM analyses WHERE project_key = ? ORDER BY rowid DESC LIMIT ?').all(key, limit).map(toRun);

  // Shaped like the scanner's trends(): the series plus the two deltas people read.
  function history({ points = 30 } = {}) {
    const series = db.prepare('SELECT * FROM history ORDER BY at DESC, seq DESC LIMIT ?').all(points).reverse()
      .map(r => ({ at: r.at, analysisId: r.analysis_id, total: r.total, counts: JSON.parse(r.counts), byType: JSON.parse(r.by_type), projects: r.projects }));
    const first = series[0];
    const last = series[series.length - 1];
    const prev = series[series.length - 2];
    const delta = (a, b) => (a === undefined || b === undefined ? null : b - a);
    return {
      points: series,
      sinceLastScan: series.length >= 2
        ? { total: delta(prev.total, last.total), critical: delta(prev.counts.CRITICAL, last.counts.CRITICAL), high: delta(prev.counts.HIGH, last.counts.HIGH) }
        : null,
      sinceFirst: series.length >= 2 ? { total: delta(first.total, last.total), from: first.at, to: last.at } : null,
    };
  }

  return { record, get, listForProject, history };
}

module.exports = { createAnalysesRepo };
