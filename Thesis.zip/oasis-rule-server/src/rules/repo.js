'use strict';
const { tx } = require('../pg');
const { createAudit } = require('../audit');
const { validateRule, engineOf, ENGINE_SCHEMA, PILLARS, SEVERITIES } = require('../model/rule');

const fail = (code, message) => Object.assign(new Error(message), { code });
const need = (reason) => { if (!reason || !String(reason).trim()) throw fail('INVALID', 'a reason is required'); };

const MOVES = {
  draft: ['proposed'],
  proposed: ['draft', 'active'],
  active: ['deprecated'],
  deprecated: ['active'],
};

// jsonb does not keep key order, so equality is decided on a key-sorted form.
function canonical(v) {
  if (Array.isArray(v)) return v.map(canonical);
  if (v && typeof v === 'object') return Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])]));
  return v;
}
const same = (a, b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));

// Lifecycle lives in the status column, not in the stored body.
function bodyOf(rule) {
  const { status, ...body } = rule;
  return body;
}

function columnsOf(body) {
  const engine = engineOf(body);
  return { language: body.language, engine, schema_version: ENGINE_SCHEMA[engine], pillar: body.pillar, severity: body.severity };
}

function createRulesRepo({ pool, languages }) {
  const audit = createAudit({ pool });

  async function lockRow(client, id) {
    const { rows } = await client.query('SELECT * FROM rule WHERE rule_id = $1 FOR UPDATE', [id]);
    if (!rows[0]) throw fail('NOT_FOUND', `rule "${id}" does not exist`);
    return rows[0];
  }

  async function checkBody(body) {
    const problem = validateRule(body, { languages: await languages() });
    if (problem) throw fail('INVALID', problem);
  }

  // Writes a new body as the next version of an existing rule (shared by update, revert and updateMetadata).
  // `demote` sends an active or proposed rule back to draft in the same UPDATE, so changed logic has to be proposed and approved again.
  async function writeVersion(client, current, body, { actor, reason }, action, detail, { demote = false } = {}) {
    const version = current.version + 1;
    const c = columnsOf(body);
    const { rows } = await client.query(
      `UPDATE rule SET language=$2, engine=$3, schema_version=$4, pillar=$5, severity=$6, body=$7, version=$8, updated_at=now(),
              status = CASE WHEN $9 THEN 'draft' ELSE status END, proposed_by = CASE WHEN $9 THEN NULL ELSE proposed_by END
       WHERE rule_id=$1 RETURNING *`,
      [current.rule_id, c.language, c.engine, c.schema_version, c.pillar, c.severity, JSON.stringify(body), version, demote],
    );
    await client.query(
      'INSERT INTO rule_version (rule_id, version, body, changed_by, reason) VALUES ($1,$2,$3,$4,$5)',
      [current.rule_id, version, JSON.stringify(body), actor, reason],
    );
    await audit.record({ actor, action, subject: current.rule_id, reason, detail: { version, ...detail, ...(demote ? { demotedFrom: current.status } : {}) } }, client);
    return rows[0];
  }

  function editable(current, { allowProposed = false } = {}) {
    if (current.status !== 'draft' && current.status !== 'active' && !(allowProposed && current.status === 'proposed')) {
      throw fail('INVALID', `a ${current.status} rule cannot be edited`);
    }
  }

  return {
    async create(rule, { actor, reason } = {}) {
      need(reason);
      await checkBody(rule);
      const body = bodyOf(rule);
      const c = columnsOf(body);
      try {
        return await tx(pool, async (client) => {
          const { rows } = await client.query(
            `INSERT INTO rule (rule_id, language, engine, schema_version, pillar, severity, status, version, body)
             VALUES ($1,$2,$3,$4,$5,$6,'draft',1,$7) RETURNING *`,
            [body.id, c.language, c.engine, c.schema_version, c.pillar, c.severity, JSON.stringify(body)],
          );
          await client.query(
            'INSERT INTO rule_version (rule_id, version, body, changed_by, reason) VALUES ($1,1,$2,$3,$4)',
            [body.id, JSON.stringify(body), actor, reason],
          );
          await audit.record({ actor, action: 'rule.create', subject: body.id, reason, detail: { version: 1 } }, client);
          return rows[0];
        });
      } catch (err) {
        if (err.code === '23505') throw fail('CONFLICT', `rule "${body.id}" already exists`);
        throw err;
      }
    },

    async update(id, patch, { actor, reason } = {}) {
      need(reason);
      return tx(pool, async (client) => {
        const current = await lockRow(client, id);
        editable(current, { allowProposed: true });
        const merged = { ...current.body };
        for (const [k, v] of Object.entries(patch || {})) {
          if (v === null) delete merged[k]; else merged[k] = v;
        }
        merged.id = id;
        const body = bodyOf(merged);
        await checkBody(body);
        return writeVersion(client, current, body, { actor, reason }, 'rule.update', { fields: Object.keys(patch || {}) }, { demote: current.status !== 'draft' });
      });
    },

    // Severity, pillar and tags only, under a relaxed check: seeded vendor rules may lack a title or example, so update() would reject them.
    async updateMetadata(id, meta, { actor, reason } = {}) {
      need(reason);
      const entries = Object.entries(meta || {});
      if (!entries.length) throw fail('INVALID', 'nothing to change');
      for (const [k, v] of entries) {
        if (k === 'severity' && !SEVERITIES.includes(v)) throw fail('INVALID', `severity must be one of ${SEVERITIES.join(', ')}`);
        else if (k === 'pillar' && !PILLARS.includes(v)) throw fail('INVALID', `pillar must be one of ${PILLARS.join(', ')}`);
        else if (k === 'tags' && !(Array.isArray(v) && v.length <= 50 && v.every((t) => typeof t === 'string' && t.trim() && t.length <= 64))) throw fail('INVALID', 'tags must be a list of up to 50 non-empty strings of at most 64 characters');
        else if (!['severity', 'pillar', 'tags'].includes(k)) throw fail('INVALID', `only severity, pillar and tags can be changed here, not "${k}"`);
      }
      return tx(pool, async (client) => {
        const current = await lockRow(client, id);
        editable(current);
        const body = { ...current.body, ...Object.fromEntries(entries) };
        if (same(body, current.body)) return current;
        return writeVersion(client, current, body, { actor, reason }, 'rule.metadata', { fields: entries.map(([k]) => k) });
      });
    },

    async setStatus(id, next, { actor, reason } = {}) {
      need(reason);
      return tx(pool, async (client) => {
        const current = await lockRow(client, id);
        if (!(MOVES[current.status] || []).includes(next)) {
          throw fail('INVALID', `a rule cannot move from ${current.status} to ${next}`);
        }
        if (current.status === 'proposed' && next === 'active' && actor === current.proposed_by) {
          throw fail('FORBIDDEN', 'the person who proposed a rule cannot approve it');
        }
        const proposedBy = next === 'proposed' ? actor : current.proposed_by;
        const { rows } = await client.query(
          'UPDATE rule SET status=$2, proposed_by=$3, updated_at=now() WHERE rule_id=$1 RETURNING *',
          [id, next, proposedBy],
        );
        await audit.record({ actor, action: 'rule.status', subject: id, reason, detail: { from: current.status, to: next } }, client);
        return rows[0];
      });
    },

    async get(id) {
      const { rows } = await pool.query('SELECT * FROM rule WHERE rule_id = $1', [id]);
      if (!rows[0]) throw fail('NOT_FOUND', `rule "${id}" does not exist`);
      return rows[0];
    },

    async list({ language, pillar, severity, engine, status, search } = {}) {
      const where = [];
      const args = [];
      const add = (sql, value) => { args.push(value); where.push(sql.replace('?', `$${args.length}`)); };
      if (language) add('language = ?', language);
      if (pillar) add('pillar = ?', pillar);
      if (severity) add('severity = ?', severity);
      if (engine) add('engine = ?', engine);
      if (status) add('status = ?', status);
      if (search) {
        args.push(`%${String(search).replace(/[\\%_]/g, '\\$&')}%`);
        const p = `$${args.length}`;
        where.push(`(rule_id ILIKE ${p} OR body->>'title' ILIKE ${p} OR body->>'description' ILIKE ${p})`);
      }
      const sql = `SELECT * FROM rule${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY rule_id`;
      return (await pool.query(sql, args)).rows;
    },

    async history(id) {
      const { rows } = await pool.query('SELECT * FROM rule_version WHERE rule_id = $1 ORDER BY version', [id]);
      if (!rows.length) throw fail('NOT_FOUND', `rule "${id}" does not exist`);
      return rows;
    },

    async revert(id, version, { actor, reason } = {}) {
      need(reason);
      return tx(pool, async (client) => {
        const current = await lockRow(client, id);
        editable(current, { allowProposed: true });
        const { rows } = await client.query('SELECT body FROM rule_version WHERE rule_id=$1 AND version=$2', [id, version]);
        if (!rows[0]) throw fail('NOT_FOUND', `rule "${id}" has no version ${version}`);
        await checkBody(rows[0].body);
        return writeVersion(client, current, rows[0].body, { actor, reason }, 'rule.revert', { revertedTo: version }, { demote: current.status !== 'draft' });
      });
    },

    // Seeding from the analyzer's existing rule files: a relaxed check, active status, a new version only when the content changed.
    async upsertSeeded(rule, { origin, actor } = {}) {
      if (!rule || typeof rule.id !== 'string' || !rule.id.trim()) throw fail('INVALID', 'a rule needs an id');
      const id = rule.id;
      if (!(await languages()).includes(rule.language)) throw fail('INVALID', `${id}: language "${rule.language}" is not in the language registry`);
      if (!SEVERITIES.includes(rule.severity)) throw fail('INVALID', `${id}: severity must be one of ${SEVERITIES.join(', ')}`);
      if (rule.pillar !== undefined && !PILLARS.includes(rule.pillar)) throw fail('INVALID', `${id}: pillar must be one of ${PILLARS.join(', ')}`);
      if (!engineOf(rule)) throw fail('INVALID', `${id}: cannot determine engine (needs a query, a pattern, or an engine)`);
      const body = bodyOf({ ...rule, pillar: rule.pillar || 'security' });
      const reason = 'seeded from the analyzer rule files';
      return tx(pool, async (client) => {
        const found = await client.query('SELECT * FROM rule WHERE rule_id = $1 FOR UPDATE', [id]);
        if (found.rows[0]) {
          if (same(found.rows[0].body, body)) return 'unchanged';
          await writeVersion(client, found.rows[0], body, { actor, reason }, 'rule.seed', { outcome: 'updated', origin });
          return 'updated';
        }
        const c = columnsOf(body);
        await client.query(
          `INSERT INTO rule (rule_id, language, engine, schema_version, pillar, severity, origin, status, version, body)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'active',1,$8)`,
          [id, c.language, c.engine, c.schema_version, c.pillar, c.severity, origin || 'seed', JSON.stringify(body)],
        );
        await client.query(
          'INSERT INTO rule_version (rule_id, version, body, changed_by, reason) VALUES ($1,1,$2,$3,$4)',
          [id, JSON.stringify(body), actor, reason],
        );
        await audit.record({ actor, action: 'rule.seed', subject: id, reason, detail: { version: 1, outcome: 'created', origin } }, client);
        return 'created';
      });
    },
  };
}

module.exports = { createRulesRepo };
