'use strict';

function createProjectsRepo(db) {
  const toProject = p => (p ? { key: p.key, name: p.name, profileId: p.profile_id } : null);
  const get = key => toProject(db.prepare('SELECT * FROM projects WHERE key = ?').get(key));
  function upsert({ key, name, profileId = null }) {
    db.prepare(`INSERT INTO projects (key, name, profile_id) VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET name = excluded.name, profile_id = excluded.profile_id`)
      .run(key, name, profileId);
    return get(key);
  }
  // Every registered project with the profile name it will really use (Default when
  // none is assigned), for the assignment screen.
  function list() {
    return db.prepare(`SELECT p.key, p.name, p.profile_id, COALESCE(pr.name, 'Default') AS profile_name
                       FROM projects p LEFT JOIN profiles pr ON pr.id = p.profile_id ORDER BY p.key`).all()
      .map(r => ({ key: r.key, name: r.name, profileId: r.profile_id, profileName: r.profile_name }));
  }
  return { get, upsert, list };
}

module.exports = { createProjectsRepo };
