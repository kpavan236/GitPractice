'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

function coded(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

/** Content-addressed store: the file name is the sha256 of the bytes, and every read re-checks it. */
function createBlobStore(dir) {
  const file = (hash) => {
    if (!/^[0-9a-f]{64}$/.test(hash)) throw coded('BAD_HASH', `not a sha256: ${hash}`);
    return path.join(dir, hash);
  };
  return {
    async put(buf) {
      const hash = sha256(buf);
      await fs.promises.mkdir(dir, { recursive: true });
      const target = file(hash);
      const tmp = `${target}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
      try {
        await fs.promises.writeFile(tmp, buf);
        await fs.promises.rename(tmp, target);
      } catch (e) {
        await fs.promises.rm(tmp, { force: true });
        throw e;
      }
      return hash;
    },
    async get(hash) {
      let buf;
      try { buf = await fs.promises.readFile(file(hash)); } catch (e) {
        if (e.code === 'ENOENT') throw coded('NOT_FOUND', `blob ${hash} not found`);
        throw e;
      }
      if (sha256(buf) !== hash) throw coded('CORRUPT', `blob ${hash} does not match its hash`);
      return buf;
    },
    async has(hash) {
      try { await fs.promises.access(file(hash)); return true; } catch { return false; }
    },
  };
}

/** JSON with object keys sorted at every level, so equal content gives equal bytes. */
function stable(value) {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().filter((k) => value[k] !== undefined)
      .map((k) => `${JSON.stringify(k)}:${stable(value[k])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

// Packs are extracted on client machines, so a path must stay inside the extraction directory.
function assertSafePath(p) {
  const bad = typeof p !== 'string' || p === '' || p.startsWith('/') || /^[A-Za-z]:/.test(p)
    || p.includes('\\') || p.includes('\0') || p.split('/').some((s) => s === '..' || s === '' || s === '.');
  if (bad) throw coded('UNSAFE_PATH', `unsafe pack path: ${JSON.stringify(p)}`);
}

// Two entries for one path would silently overwrite on extraction; names differing only in case are the
// same file on macOS and Windows.
function assertNoCollisions(sortedPaths) {
  const seen = new Map();
  for (const p of sortedPaths) {
    const key = p.toLowerCase();
    if (seen.has(key)) throw coded('DUPLICATE_PATH', `duplicate pack path: ${JSON.stringify(seen.get(key))} and ${JSON.stringify(p)}`);
    seen.set(key, p);
  }
}

function encodePack({ id, kind, language, version, files }) {
  const sorted = [...files].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  sorted.forEach((f) => assertSafePath(f.path));
  assertNoCollisions(sorted.map((f) => f.path));
  const json = stable({
    id, kind, language: language === undefined ? null : language, version,
    files: sorted.map((f) => ({ path: f.path, b64: Buffer.from(f.data).toString('base64') })),
  });
  const gz = zlib.gzipSync(json, { level: 9 });
  gz.writeUInt32LE(0, 4); // gzip MTIME: already zero in Node, pinned so a runtime change cannot break determinism
  return gz;
}

function decodePack(buf) {
  const p = JSON.parse(zlib.gunzipSync(buf).toString('utf8'));
  const files = p.files.map((f) => {
    assertSafePath(f.path);
    return { path: f.path, data: Buffer.from(f.b64, 'base64') };
  });
  assertNoCollisions(files.map((f) => f.path).sort());
  return { id: p.id, kind: p.kind, language: p.language, version: p.version, files };
}

module.exports = { createBlobStore, encodePack, decodePack, stable, sha256 };
