'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { encodePack, stable, sha256 } = require('./blobs');

const SKIP_FILES = new Set(['.DS_Store']);

function listFiles(root, { skipDir = () => false, skipFile = () => false } = {}) {
  const out = [];
  (function walk(rel) {
    const entries = fs.readdirSync(path.join(root, rel), { withFileTypes: true })
      .sort((a, b) => (a.name < b.name ? -1 : 1));
    for (const e of entries) {
      const r = rel ? `${rel}/${e.name}` : e.name;
      const isDir = e.isDirectory() || (e.isSymbolicLink() && fs.statSync(path.join(root, r)).isDirectory());
      if (isDir) { if (!skipDir(r)) walk(r); } else if (!SKIP_FILES.has(e.name) && !skipFile(r)) out.push(r);
    }
  })('');
  return out;
}

const readFiles = (root, rels, prefix) => rels.map((r) => ({ path: `${prefix}${r}`, data: fs.readFileSync(path.join(root, r)) }));

// Find <name> the way Node would from fromDir; the pack keeps the on-disk location when it is inside the analyzer.
function resolveDep(name, fromDir, analyzerDir) {
  for (let dir = fromDir; ; dir = path.dirname(dir)) {
    const candidate = path.join(dir, 'node_modules', name);
    if (fs.existsSync(path.join(candidate, 'package.json'))) return candidate;
    if (path.dirname(dir) === dir) break;
  }
  try {
    return path.dirname(require.resolve(`${name}/package.json`, { paths: [analyzerDir] }));
  } catch (e) {
    throw new Error(`cannot resolve production dependency "${name}" from ${analyzerDir}`);
  }
}

/** Production dependencies only: walk package.json "dependencies" recursively. */
function collectDependencyFiles(analyzerDir) {
  const seen = new Map(); // pack dir -> absolute dir
  const files = [];
  const visit = (pkgDir, fromDir) => {
    const deps = Object.keys(JSON.parse(fs.readFileSync(path.join(pkgDir, 'package.json'), 'utf8')).dependencies || {});
    for (const name of deps) {
      const dir = resolveDep(name, fromDir, analyzerDir);
      const rel = path.relative(analyzerDir, dir);
      const dest = rel.startsWith('..') || path.isAbsolute(rel) ? `node_modules/${name}` : rel.split(path.sep).join('/');
      if (seen.has(dest)) {
        if (seen.get(dest) !== dir) throw new Error(`two different copies of "${name}" map to ${dest}`);
        continue;
      }
      seen.set(dest, dir);
      const rels = listFiles(dir, { skipDir: (r) => r === 'node_modules' || r.endsWith('/node_modules'), skipFile: (r) => r.endsWith('.map') });
      files.push(...readFiles(dir, rels, `${dest}/`));
      visit(dir, dir);
    }
  };
  visit(analyzerDir, analyzerDir);
  return files;
}

// version = first 12 hex of sha256 over the sorted (path, content sha) list, plus any identity fields.
function versionOf(files, meta) {
  const list = [...files].sort((a, b) => (a.path < b.path ? -1 : 1)).map((f) => [f.path, sha256(f.data)]);
  return sha256(Buffer.from(stable(meta ? { files: list, meta } : list))).slice(0, 12);
}

async function storePack(blobs, pack) {
  const buf = encodePack(pack);
  const sha = await blobs.put(buf);
  return { packId: pack.id, kind: pack.kind, language: pack.language, version: pack.version, sha256: sha, size: buf.length };
}

async function buildPacks({ rules, languages, analyzerDir, grammarDir, blobs }) {
  const known = new Set(languages.map((l) => l.id));
  for (const r of rules) {
    if (!known.has(r.language)) throw new Error(`rule "${r.id}" has language "${r.language}", which is not in the language registry`);
  }
  const results = [];

  const srcRels = listFiles(path.join(analyzerDir, 'src'), {
    skipFile: (r) => r.startsWith('ast/grammars/'),
  });
  const coreFiles = [
    ...readFiles(path.join(analyzerDir, 'src'), srcRels, 'src/'),
    { path: 'package.json', data: fs.readFileSync(path.join(analyzerDir, 'package.json')) },
    ...collectDependencyFiles(analyzerDir),
  ];
  results.push(await storePack(blobs, { id: 'core', kind: 'core', language: null, version: versionOf(coreFiles), files: coreFiles }));

  for (const lang of [...languages].sort((a, b) => (a.id < b.id ? -1 : 1))) {
    const own = rules.filter((r) => r.language === lang.id).sort((a, b) => (a.id < b.id ? -1 : 1));
    if (!own.length) continue;
    const files = [{ path: 'rules.json', data: Buffer.from(stable(own)) }];
    if (lang.grammar) {
      const wasm = lang.grammar.wasm || `tree-sitter-${lang.id}.wasm`;
      const file = path.join(grammarDir, wasm);
      if (!fs.existsSync(file)) throw new Error(`grammar for language "${lang.id}" not found: ${file}`);
      files.push({ path: `grammar/${wasm}`, data: fs.readFileSync(file) });
    }
    const id = `lang-${lang.id}`;
    const identity = { id, language: lang.id, extensions: lang.extensions };
    // The version must not depend on pack.json (it contains the version), so hash the other files plus the identity first.
    const version = versionOf(files, identity);
    files.push({ path: 'pack.json', data: Buffer.from(stable({ ...identity, version })) });
    results.push(await storePack(blobs, { id, kind: 'language', language: lang.id, version, files }));
  }
  return results;
}

module.exports = { buildPacks };
