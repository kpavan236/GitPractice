'use strict';
const { SEVERITIES } = require('./rules');

function fail(code, message) {
  return Object.assign(new Error(message), { code });
}

function toProfile(p) {
  if (!p) return null;
  return { id: p.id, name: p.name, isDefault: !!p.is_default, version: p.version, parentId: p.parent_id };
}

function createProfilesRepo(db, rulesRepo) {
  const getRow = db.prepare('SELECT * FROM profiles WHERE id = ?');
  const get = id => toProfile(getRow.get(id));
  // A child inherits its parent's rules, so an edit moves every descendant's
  // version too: scanners key their per-file cache on it.
  function bump(id) {
    const ids = [id];
    for (let i = 0; i < ids.length; i++) {
      for (const c of db.prepare('SELECT id FROM profiles WHERE parent_id = ?').all(ids[i])) ids.push(c.id);
    }
    const mark = db.prepare('UPDATE profiles SET version = version + 1 WHERE id = ?');
    for (const x of ids) mark.run(x);
  }

  function create({ id, name, parentId = null } = {}) {
    if (typeof id !== 'string' || !id || typeof name !== 'string' || !name) {
      throw fail('INVALID', 'a profile needs a non-empty string id and name');
    }
    if (get(id) || db.prepare('SELECT 1 FROM profiles WHERE name = ?').get(name)) {
      throw fail('CONFLICT', `profile "${name}" already exists`);
    }
    if (parentId && !get(parentId)) throw fail('NOT_FOUND', `parent profile ${parentId} not found`);
    db.prepare('INSERT INTO profiles (id, name, is_default, version, parent_id) VALUES (?, ?, 0, 1, ?)').run(id, name, parentId);
    return get(id);
  }

  function ensureDefault() {
    if (!get('default')) {
      db.prepare("INSERT INTO profiles (id, name, is_default, version) VALUES ('default', 'Default', 1, 1)").run();
    }
    const have = new Set(db.prepare("SELECT rule_id FROM profile_rules WHERE profile_id = 'default'").all().map(r => r.rule_id));
    const add = db.prepare("INSERT INTO profile_rules (profile_id, rule_id, enabled, severity, params) VALUES ('default', ?, 1, NULL, '{}')");
    let added = 0;
    // Severity stays NULL so Default follows each rule's own severity. User
    // rules are never auto-activated: they join a profile only on request.
    for (const rule of rulesRepo.list({ status: 'ACTIVE' })) {
      if (rule.origin !== 'user' && !have.has(rule.id)) { add.run(rule.id); added += 1; }
    }
    // First population stays at version 1; later additions bump it.
    if (added && have.size) bump('default');
    return get('default');
  }

  function setRule(profileId, ruleId, { enabled, severity, params } = {}) {
    if (!get(profileId)) throw fail('NOT_FOUND', `profile ${profileId} not found`);
    if (!rulesRepo.get(ruleId)) throw fail('NOT_FOUND', `rule ${ruleId} not found`);
    if (severity !== undefined && !SEVERITIES.includes(severity)) {
      throw fail('INVALID', `severity must be one of ${SEVERITIES.join(', ')}`);
    }
    const existing = db.prepare('SELECT * FROM profile_rules WHERE profile_id = ? AND rule_id = ?').get(profileId, ruleId);
    const next = {
      enabled: enabled === undefined ? (existing ? existing.enabled : inheritedEnabled(profileId, ruleId)) : (enabled ? 1 : 0),
      severity: severity === undefined ? (existing ? existing.severity : null) : severity,
      params: params === undefined ? (existing ? existing.params : '{}') : JSON.stringify(params),
    };
    db.prepare(`INSERT INTO profile_rules (profile_id, rule_id, enabled, severity, params) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(profile_id, rule_id) DO UPDATE SET enabled = excluded.enabled, severity = excluded.severity, params = excluded.params`)
      .run(profileId, ruleId, next.enabled, next.severity, next.params);
    bump(profileId);
    return get(profileId);
  }

  // Child entries override parent entries; a rule absent from the whole chain
  // is inactive. Walk root first so later (more specific) profiles win.
  function chain(profileId) {
    const out = [];
    for (let p = get(profileId); p; p = p.parentId ? get(p.parentId) : null) out.unshift(p.id);
    return out;
  }

  // A new override row starts from what the parent chain already says, so a
  // severity-only change cannot silently re-enable a rule an ancestor disabled.
  function inheritedEnabled(profileId, ruleId) {
    // A rule no profile in the chain has an entry for is not running anywhere. Giving
    // it an entry to record a severity must not be what switches it on.
    let enabled = 0;
    for (const id of chain(profileId).slice(0, -1)) {
      const e = db.prepare('SELECT enabled FROM profile_rules WHERE profile_id = ? AND rule_id = ?').get(id, ruleId);
      if (e) enabled = e.enabled;
    }
    return enabled;
  }

  // What a profile does with every rule it (or an ancestor) has an entry for,
  // disabled ones included. Child entries override parent entries.
  function effectiveEntries(profileId) {
    const effective = new Map();
    for (const id of chain(profileId)) {
      for (const e of db.prepare('SELECT * FROM profile_rules WHERE profile_id = ?').all(id)) {
        const prev = effective.get(e.rule_id) || {};
        effective.set(e.rule_id, {
          enabled: !!e.enabled,
          severity: e.severity || prev.severity || null,
          params: { ...(prev.params || {}), ...JSON.parse(e.params) },
        });
      }
    }
    return effective;
  }

  function activeRules(profileId) {
    const effective = effectiveEntries(profileId);
    const out = [];
    for (const [ruleId, cfg] of [...effective].sort((a, b) => a[0].localeCompare(b[0]))) {
      const rule = rulesRepo.get(ruleId);
      if (!cfg.enabled || !rule || rule.status !== 'ACTIVE') continue;
      out.push({
        ruleId, severity: cfg.severity || rule.severity, params: cfg.params,
        engine: rule.engine, schemaVersion: rule.schemaVersion, definition: rule.body,
      });
    }
    return out;
  }

  // One row per active rule with what THIS profile does with it, for the rules screen.
  // `overridden`: the profile has its own entry. `inherited`: the effective state comes
  // from an ancestor. In a profile with no parent (the baseline) neither applies.
  function rulesView(profileId, { search, language, engine, state } = {}) {
    const profile = get(profileId);
    if (!profile) throw fail('NOT_FOUND', `profile ${profileId} not found`);
    const own = new Set(db.prepare('SELECT rule_id FROM profile_rules WHERE profile_id = ?').all(profileId).map(r => r.rule_id));
    const effectiveMap = effectiveEntries(profileId);
    const hasParent = !!profile.parentId;

    const all = rulesRepo.list({ status: 'ACTIVE' }).map(rule => {
      const effective = effectiveMap.get(rule.id);       // present even when disabled
      const isOwn = own.has(rule.id);
      return {
        ruleId: rule.id, title: rule.body.title || rule.id, language: rule.language, engine: rule.engine,
        defaultSeverity: rule.severity,
        enabled: !!(effective && effective.enabled),
        severity: (effective && effective.severity) || rule.severity,
        params: effective ? effective.params : {},
        overridden: hasParent && isOwn,
        // Inherited only if an ancestor actually has something to inherit.
        inherited: hasParent && !isOwn && !!effective,
      };
    });
    const counts = {
      total: all.length, enabled: all.filter(r => r.enabled).length,
      disabled: all.filter(r => !r.enabled).length, overridden: all.filter(r => r.overridden).length,
    };
    const q = search ? String(search).toLowerCase() : null;
    const rules = all.filter(r =>
      (!language || r.language === language) && (!engine || r.engine === engine)
      && (!q || r.ruleId.toLowerCase().includes(q) || r.title.toLowerCase().includes(q))
      && (!state || (state === 'enabled' ? r.enabled : state === 'disabled' ? !r.enabled : state === 'overridden' ? r.overridden : true)));
    return { profile, rules, counts };
  }

  // Drops this profile's own entry for a rule, so it falls back to what it inherits.
  function clearRule(profileId, ruleId) {
    if (!get(profileId)) throw fail('NOT_FOUND', `profile ${profileId} not found`);
    if (!rulesRepo.get(ruleId)) throw fail('NOT_FOUND', `rule ${ruleId} not found`);
    const removed = db.prepare('DELETE FROM profile_rules WHERE profile_id = ? AND rule_id = ?').run(profileId, ruleId).changes;
    if (!removed) throw fail('NOT_FOUND', `profile ${profileId} has no override for ${ruleId}`);
    bump(profileId);
    return get(profileId);
  }

  // A profile others rely on cannot go, and the refusal says who relies on it.
  function remove(profileId) {
    const profile = get(profileId);
    if (!profile) throw fail('NOT_FOUND', `profile ${profileId} not found`);
    if (profile.isDefault) throw fail('CONFLICT', 'the Default profile is the baseline and cannot be deleted');
    const children = db.prepare('SELECT name FROM profiles WHERE parent_id = ? ORDER BY name').all(profileId).map(r => r.name);
    if (children.length) throw fail('CONFLICT', `"${profile.name}" is the parent of ${children.map(c => `"${c}"`).join(', ')}; delete or re-parent those first`);
    const assigned = db.prepare('SELECT key FROM projects WHERE profile_id = ? ORDER BY key').all(profileId).map(r => r.key);
    if (assigned.length) throw fail('CONFLICT', `"${profile.name}" is assigned to ${assigned.join(', ')}; assign another profile first`);
    db.prepare('DELETE FROM profile_rules WHERE profile_id = ?').run(profileId);
    db.prepare('DELETE FROM profiles WHERE id = ?').run(profileId);
    return { deleted: profileId };
  }

  return { rulesView, clearRule, remove, create, get, list: () => db.prepare('SELECT * FROM profiles ORDER BY name').all().map(toProfile), ensureDefault, setRule, activeRules };
}

module.exports = { createProfilesRepo };
