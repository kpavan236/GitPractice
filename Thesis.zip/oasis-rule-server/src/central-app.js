'use strict';
const express = require('express');
const fs = require('node:fs');
const { rateLimit } = require('./rate-limit');
const { releasesPublicRouter } = require('./routes/releases-public');

/** The public, unauthenticated, read-only HTTP surface. trustProxy is the number of proxies in front of the service (0 if none). */
/** One JSON line per event, written to stdout/stderr. Callers pass only fixed fields: never bodies, query strings or addresses. */
function defaultLog(entry) { (entry.level === 'error' ? console.error : console.log)(JSON.stringify(entry)); }

function createCentralApp({ pool, blobs, releases, packDir, tls = false, trustProxy = 0, limiter = rateLimit({ max: 60 }), log = defaultLog }) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);
  app.use((req, res, next) => {
    const started = process.hrtime.bigint();
    res.on('finish', () => log({ level: 'info', msg: 'request', method: req.method, path: req.path, status: res.statusCode, ms: Math.round(Number(process.hrtime.bigint() - started) / 1e6) }));
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Referrer-Policy', 'no-referrer');
    if (tls) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });
  app.use(limiter);

  // Liveness only: the process is up. Dependencies are checked by /v1/ready.
  app.get('/v1/health', (_req, res) => res.json({ status: 'ok' }));
  app.get('/v1/ready', async (_req, res) => {
    const checks = { database: false, packDir: false };
    try { if (pool) await pool.query('SELECT 1'); checks.database = true; } catch { /* reported as not ready */ }
    try { if (packDir) await fs.promises.access(packDir, fs.constants.R_OK); checks.packDir = Boolean(packDir); } catch { /* reported as not ready */ }
    const ready = checks.database && checks.packDir;
    res.status(ready ? 200 : 503).json({ status: ready ? 'ready' : 'not_ready', checks });
  });
  app.use('/v1', releasesPublicRouter({ releases, blobs }));

  app.use((_req, res) => res.status(404).json({ error: 'NOT_FOUND' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    log({ level: 'error', msg: 'unhandled', code: err && err.code ? String(err.code) : 'error' });
    res.status(500).json({ error: 'INTERNAL' });
  });
  return app;
}

module.exports = { createCentralApp };
