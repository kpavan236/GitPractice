'use strict';

const ENGINE_SCHEMA = { ast: 1, pattern: 1, 'iac-policy': 1, secret: 1 };

// Same classification the oasis build-rules tool uses implicitly: a tree-sitter
// query is AST, engine:'secret' is the secrets engine, engine:'iac-policy' is a
// structured policy, and a bare regex pattern is a line rule.
function engineOf(rule) {
  if (rule.query) return 'ast';
  if (rule.engine === 'secret') return 'secret';
  if (rule.engine === 'iac-policy') return 'iac-policy';
  if (rule.pattern) return 'pattern';
  return null;
}

module.exports = { engineOf, ENGINE_SCHEMA };
