'use strict';
const path = require('path');

// One place for the defaults the server and the seed script must agree on. They
// used to resolve the database path separately (one against the working
// directory, one against the repository), so seeding from another directory
// filled a database the server never opened.

// Ports the fetch standard refuses to connect to. A default on one of these makes
// the server look unreachable even while it runs (5060 is SIP).
const FETCH_BLOCKED_PORTS = [
  1, 7, 9, 11, 13, 15, 17, 19, 20, 21, 22, 23, 25, 37, 42, 43, 53, 69, 77, 79, 87, 95, 101, 102, 103, 104, 109, 110, 111, 113, 115, 117, 119,
  123, 135, 137, 139, 143, 161, 179, 389, 427, 465, 512, 513, 514, 515, 526, 530, 531, 532, 540, 548, 554, 556, 563, 587, 601, 636, 989, 990,
  993, 995, 1719, 1720, 1723, 2049, 3659, 4045, 5060, 5061, 6000, 6566, 6665, 6666, 6667, 6668, 6669, 6697, 10080,
];

const defaultDbFile = (env = process.env) => env.OASIS_RULE_SERVER_DB || path.join(__dirname, '..', 'oasis-rules.db');
const defaultPort = (env = process.env) => Number(env.OASIS_RULE_SERVER_PORT || 5090);

module.exports = { defaultDbFile, defaultPort, FETCH_BLOCKED_PORTS };
