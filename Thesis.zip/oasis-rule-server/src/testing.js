'use strict';
// For other projects' tests only (never required by production code): a throwaway, migrated rules database.
module.exports = require('../test/helpers/db');
