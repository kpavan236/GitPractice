'use strict';
const express = require('express');
const crypto = require('crypto');
const { createRulesRepo } = require('./rules');
const { createProfilesRepo } = require('./profiles');
const { createProjectsRepo } = require('./projects');
const { ENGINE_SCHEMA } = require('./engines');
const { createFindingsRepo } = require('./findings');
const { createGatesRepo } = require('./gate');
const { createAnalysesRepo } = require('./analyses');
const { createBaselineRepo } = require('./baseline');
const { createMaintenance } = require('./maintenance');
const { tx } = require('./db');

const STATUS = { INVALID: 400, NOT_FOUND: 404, CONFLICT: 409 };
const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);

function safeEqual(a, b) {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// The server holds rules that decide what the scanner reports, so writes are
// guarded even on loopback: a web page open in the user's browser can reach
// 127.0.0.1, and must not be able to edit rules.
function writeGuard(token) {
  return (req, res, next) => {
    if (req.method === 'GET' || req.method === 'HEAD') return next();
    const origin = req.get('origin');
    if (origin) {
      let host;
      try { host = new URL(origin).hostname; } catch (_) { host = null; }
      if (!host || !LOOPBACK.has(host)) return res.status(403).json({ error: 'FORBIDDEN_ORIGIN' });
    }
    if (token && !safeEqual(req.get('x-oasis-token') || '', token)) {
      return res.status(401).json({ error: 'UNAUTHORIZED' });
    }
    next();
  };
}

function parseEngines(value) {
  if (!value) return null;
  return Object.fromEntries(String(value).split(',').filter(Boolean).map(p => {
    const [name, v] = p.split(':');
    return [name, Number(v)];
  }));
}

function createApp({ db, token = process.env.OASIS_RULE_SERVER_TOKEN } = {}) {
  const rules = createRulesRepo(db);
  const profiles = createProfilesRepo(db, rules);
  const projects = createProjectsRepo(db);
  const findings = createFindingsRepo(db);
  const gates = createGatesRepo(db);
  const analyses = createAnalysesRepo({ db, findings, gates });
  const baseline = createBaselineRepo(db);
  const maintenance = createMaintenance(db);
  profiles.ensureDefault();

  const app = express();
  // An analysis carries every finding of a repository; the global 2 MB limit would
  // silently drop the biggest repositories. Parsed first so this limit applies.
  app.use('/api/v1/analyses', express.json({ limit: '64mb' }));
  app.use('/api/v1/import', express.json({ limit: '256mb' }));
  app.use(express.json({ limit: '2mb' }));
  const api = express.Router();
  api.use(writeGuard(token));
  api.use((req, res, next) => {
    const b = req.body;
    if ((req.method === 'POST' || req.method === 'PUT') && (b === null || typeof b !== 'object' || Array.isArray(b))) {
      return res.status(400).json({ error: 'INVALID', message: 'request body must be a JSON object' });
    }
    next();
  });

  const wrap = fn => (req, res) => {
    try { fn(req, res); }
    catch (e) {
      if (STATUS[e.code]) return res.status(STATUS[e.code]).json({ error: e.code, message: e.message });
      console.error(e);
      res.status(500).json({ error: 'INTERNAL' });
    }
  };

  api.get('/health', (_req, res) => res.json({ status: 'ok' }));
  api.get('/analyzers/compat', (_req, res) => res.json({ ruleSchemaVersions: ENGINE_SCHEMA }));

  api.get('/rules', wrap((req, res) => res.json(req.query.fields === 'summary' ? rules.listSummary(req.query) : rules.list(req.query))));
  api.get('/rules/:id', wrap((req, res) => {
    const r = rules.get(req.params.id);
    return r ? res.json(r) : res.status(404).json({ error: 'NOT_FOUND', message: `rule ${req.params.id} not found` });
  }));
  api.post('/rules', wrap((req, res) => {
    const { activateIn = [], ...rule } = req.body || {};
    if (!Array.isArray(activateIn) || activateIn.some(id => typeof id !== 'string')) {
      return res.status(400).json({ error: 'INVALID', message: 'activateIn must be an array of profile ids' });
    }
    const targets = [...new Set(activateIn)];
    for (const id of targets) {
      if (!profiles.get(id)) return res.status(404).json({ error: 'NOT_FOUND', message: `profile ${id} not found` });
    }
    const created = tx(db, () => {
      const out = rules.create(rule);
      for (const id of targets) profiles.setRule(id, rule.id, { enabled: true });
      return out;
    });
    res.status(201).json(created);
  }));
  api.put('/rules/:id', wrap((req, res) => res.json(rules.update(req.params.id, req.body || {}))));
  api.delete('/rules/:id', wrap((req, res) => res.json(rules.deprecate(req.params.id))));

  api.get('/profiles', wrap((_req, res) => res.json(profiles.list())));
  api.get('/profiles/:id', wrap((req, res) => {
    const p = profiles.get(req.params.id);
    return p ? res.json(p) : res.status(404).json({ error: 'NOT_FOUND', message: `profile ${req.params.id} not found` });
  }));
  api.get('/profiles/:id/rules', wrap((req, res) => res.json(profiles.rulesView(req.params.id, req.query))));
  api.delete('/profiles/:id/rules/:ruleId', wrap((req, res) => res.json(profiles.clearRule(req.params.id, req.params.ruleId))));
  api.delete('/profiles/:id', wrap((req, res) => res.json(profiles.remove(req.params.id))));
  api.get('/projects', wrap((_req, res) => res.json(projects.list())));
  api.post('/profiles', wrap((req, res) => res.status(201).json(profiles.create(req.body || {}))));
  api.put('/profiles/:id/rules/:ruleId', wrap((req, res) => {
    res.json(profiles.setRule(req.params.id, req.params.ruleId, req.body || {}));
  }));

  api.put('/projects/:key', wrap((req, res) => {
    const { name = req.params.key, profileId = null } = req.body || {};
    if (profileId && !profiles.get(profileId)) {
      return res.status(404).json({ error: 'NOT_FOUND', message: `profile ${profileId} not found` });
    }
    res.json(projects.upsert({ key: req.params.key, name, profileId }));
  }));

  api.get('/projects/:key/profile', wrap((req, res) => {
    const project = projects.get(req.params.key);
    const profile = profiles.get((project && project.profileId) || 'default');
    const active = profiles.activeRules(profile.id);

    const scanner = parseEngines(req.query.engines);
    if (scanner) {
      const unsupported = active.filter(r => !(scanner[r.engine] >= r.schemaVersion));
      if (unsupported.length) {
        const message = unsupported.map(r =>
          `Rule ${r.ruleId} is active in profile "${profile.name}" but the installed scanner does not support it (engine ${r.engine} v${r.schemaVersion}).`).join('\n');
        return res.status(422).json({
          error: 'UNSUPPORTED_RULES', message,
          rules: unsupported.map(r => ({ ruleId: r.ruleId, engine: r.engine, schemaVersion: r.schemaVersion })),
        });
      }
    }
    // projectKnown lets the scanner say so when a project was never registered
    // and silently got the Default profile (e.g. a key typo or a renamed clone).
    res.json({ profile, rules: active, projectKnown: !!project });
  }));

  api.post('/analyses', wrap((req, res) => res.status(201).json(analyses.record(req.body))));
  api.get('/analyses/:id', wrap((req, res) => {
    const run = analyses.get(req.params.id);
    return run ? res.json(run) : res.status(404).json({ error: 'NOT_FOUND', message: `analysis ${req.params.id} not found` });
  }));
  api.get('/projects/:key/analyses', wrap((req, res) => res.json(analyses.listForProject(req.params.key, { limit: Number(req.query.limit) || 50 }))));
  api.get('/projects/:key/findings', wrap((req, res) => res.json(findings.list(req.params.key, { status: String(req.query.status || 'active') }))));
  // Suppressing is a decision someone has to be able to explain later.
  const statusPatch = (body, res) => {
    const { status, reason, notes, owner, expiresAt } = body || {};
    if (status === 'SUPPRESSED' && !(typeof reason === 'string' && reason.trim())) {
      res.status(400).json({ error: 'INVALID', message: 'A reason is required to suppress a finding' });
      return null;
    }
    const decided = (status === 'SUPPRESSED' || status === 'FALSE_POSITIVE') && typeof reason === 'string' && reason.trim();
    return {
      status, notes,
      ...(decided ? { suppression: { reason: reason.trim(), owner: owner || null, expiresAt: expiresAt || null, decidedAt: Date.now() } } : {}),
    };
  };
  api.post('/projects/:key/findings/:fingerprint/status', wrap((req, res) => {
    const patch = statusPatch(req.body, res);
    if (patch) res.json(findings.setStatus(req.params.key, req.params.fingerprint, patch));
  }));

  // The Security tab addresses findings by id and lists across repositories.
  api.get('/findings', wrap((req, res) => {
    const q = req.query;
    res.json(findings.listAll({
      repository: q.repository || undefined, type: q.type || undefined, severity: q.severity || undefined,
      status: q.status || 'active', search: q.search || undefined,
    }, q.status === 'new' ? baseline.get() : null));
  }));
  api.get('/findings/repositories', wrap((_req, res) => res.json(findings.repositories())));
  api.get('/findings/:id', wrap((req, res) => {
    const found = findings.getById(req.params.id);
    return found ? res.json(found) : res.status(404).json({ error: 'NOT_FOUND', message: `finding ${req.params.id} not found` });
  }));
  api.post('/findings/:id/status', wrap((req, res) => {
    const patch = statusPatch(req.body, res);
    if (patch) res.json(findings.setStatusById(req.params.id, patch));
  }));
  api.post('/findings/risk', wrap((req, res) => {
    const updates = req.body && req.body.updates;
    if (!Array.isArray(updates) || updates.some(u => !u || typeof u.id !== 'string' || !u.risk || typeof u.risk !== 'object')) {
      return res.status(400).json({ error: 'INVALID', message: 'risk updates need { updates: [{ id, risk: {...} }] }' });
    }
    res.json({ updated: findings.setRisk(updates) });
  }));
  api.delete('/findings', wrap((req, res) => {
    res.json(maintenance.clear({ repository: req.query.repository || null, keepSuppressed: req.query.keepSuppressed !== 'false' }));
  }));

  api.get('/baseline', wrap((_req, res) => res.json(baseline.get())));
  api.post('/baseline', wrap((_req, res) => res.json(baseline.set())));
  api.delete('/baseline', wrap((_req, res) => { baseline.clear(); res.json(null); }));

  api.get('/maintenance/preview', wrap((req, res) => res.json(maintenance.preview({ repository: req.query.repository || null }))));
  api.post('/maintenance/reset', wrap((_req, res) => res.json(maintenance.reset())));

  api.post('/import', wrap((req, res) => {
    const { findings: items, history: points, baseline: importedBaseline } = req.body || {};
    const badFinding = f => !f || typeof f.fingerprint !== 'string' || !f.fingerprint || typeof f.repository !== 'string' || !f.repository;
    if (!Array.isArray(items) || !Array.isArray(points)) {
      return res.status(400).json({ error: 'INVALID', message: 'import needs { findings: [...], history: [...] }' });
    }
    if (items.some(badFinding)) {
      return res.status(400).json({ error: 'INVALID', message: 'every imported finding needs a fingerprint and a repository' });
    }
    if (importedBaseline !== undefined && importedBaseline !== null
        && (typeof importedBaseline !== 'object' || !Array.isArray(importedBaseline.fingerprints))) {
      return res.status(400).json({ error: 'INVALID', message: 'baseline needs { createdAt, fingerprints: [...] }' });
    }
    const merging = req.query.mode === 'merge';
    const imported = tx(db, () => {
      const counts = merging ? findings.importMerge(items) : { findings: findings.importBulk(items) };
      // Merging never replaces a baseline the server already has.
      if (importedBaseline && !(merging && baseline.get())) baseline.restore(importedBaseline);
      const add = db.prepare('INSERT INTO history (at, analysis_id, total, counts, by_type, projects) VALUES (?, NULL, ?, ?, ?, ?)');
      for (const p of points) add.run(p.at ?? Date.now(), p.total ?? 0, JSON.stringify(p.counts || {}), JSON.stringify(p.byType || {}), p.repositories ?? p.projects ?? 0);
      return { ...counts, history: points.length, baseline: !!importedBaseline };
    });
    res.json(imported);
  }));
  api.get('/projects/:key/gate', wrap((req, res) => res.json(gates.get(req.params.key))));
  api.put('/projects/:key/gate', wrap((req, res) => res.json(gates.set(req.params.key, req.body))));
  api.delete('/projects/:key/gate', wrap((req, res) => { gates.clear(req.params.key); res.json(gates.get(req.params.key)); }));
  api.get('/history', wrap((req, res) => res.json(analyses.history({ points: Number(req.query.points) || 30 }))));

  app.use('/api/v1', api);
  return app;
}

module.exports = { createApp };
