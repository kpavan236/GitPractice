'use strict';

/** Writes audit rows. Pass a transaction client as the second argument so the row commits or rolls back with the change it describes. */
function createAudit({ pool }) {
  return {
    async record({ actor, action, subject = null, reason = null, outcome = 'done', detail = {} }, client = pool) {
      await client.query(
        'INSERT INTO audit (actor, action, subject, reason, outcome, detail) VALUES ($1,$2,$3,$4,$5,$6)',
        [actor, action, subject, reason, outcome, JSON.stringify(detail)],
      );
    },
  };
}

module.exports = { createAudit };
