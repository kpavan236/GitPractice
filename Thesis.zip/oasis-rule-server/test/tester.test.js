'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { testRule } = require('../src/tester');

const goPatternRule = {
  id: 'go-insecure-skip-verify', language: 'go', pillar: 'security', severity: 'HIGH', type: 'SAST',
  title: 'TLS verification disabled', description: 'InsecureSkipVerify turns off certificate checks.',
  files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
  example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
};

test('a pattern rule passes when it detects the vulnerable sample and is silent on the fix', async () => {
  const r = await testRule(goPatternRule);
  assert.equal(r.ok, true);
  assert.equal(r.detect.matched, true);
  assert.deepEqual(r.detect.lines, [1]);
  assert.equal(r.clean.matched, false);
  assert.deepEqual(r.problems, []);
});

test('a rule that fires on its own fix fails with a clear problem', async () => {
  const r = await testRule({ ...goPatternRule, example: { ...goPatternRule.example, fixed: goPatternRule.example.vulnerable } });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /fired on its own fix/);
});

test('a rule that misses its vulnerable sample fails with a clear problem', async () => {
  const r = await testRule({ ...goPatternRule, example: { ...goPatternRule.example, vulnerable: 'nothing to see' } });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /missed its vulnerable example/);
});

test('an empty vulnerable sample is reported as a miss, not a crash', async () => {
  const r = await testRule({ ...goPatternRule, example: { ...goPatternRule.example, vulnerable: '' } });
  assert.equal(r.ok, false);
  assert.equal(r.detect.matched, false);
  assert.match(r.problems.join(' '), /missed its vulnerable example/);
});

test('a catastrophic regex is stopped by the time limit', async () => {
  const started = Date.now();
  const r = await testRule({ ...goPatternRule, pattern: '(a+)+$', example: { file: 'a.go', vulnerable: 'a'.repeat(40) + '!', fixed: 'b' } }, { timeoutMs: 500 });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /timed out after 500 ms/);
  assert.ok(Date.now() - started < 3000, 'the worker must be stopped promptly');
});

test('an AST rule is tested with the tree-sitter engine', async () => {
  const rule = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'seed', 'rules', 'java', 'weak-hash.json'), 'utf8'));
  const r = await testRule(rule);
  assert.equal(r.ok, true);
  assert.equal(r.detect.matched, true);
  assert.ok(r.detect.lines.length >= 1);
  assert.equal(r.clean.matched, false);
});

test('an AST rule with a broken query fails with a problem instead of throwing', async () => {
  const rule = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'seed', 'rules', 'java', 'weak-hash.json'), 'utf8'));
  const r = await testRule({ ...rule, query: '(method_invocation name: (' });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /query does not compile/);
});

test('a pattern that does not compile fails with a problem', async () => {
  const r = await testRule({ ...goPatternRule, pattern: '(' });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /pattern does not compile/);
});

test('secret and iac-policy rules have no fixture tester', async () => {
  for (const engine of ['secret', 'iac-policy']) {
    const r = await testRule({ ...goPatternRule, engine });
    assert.equal(r.ok, false);
    assert.deepEqual(r.problems, [`engine ${engine} has no fixture tester`]);
  }
});

test('a rule with no example is a problem, not a crash', async () => {
  const r = await testRule({ ...goPatternRule, example: undefined });
  assert.equal(r.ok, false);
  assert.match(r.problems.join(' '), /example/);
});
