'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');

const good = () => ({
  id: 'USER-001', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'],
  title: 'eval', fixture: { detect: 'eval(x)', clean: 'run(x)' },
});
const setup = () => createRulesRepo(openDb());

test('create stores a valid user rule and flags AST rules for scanner validation', () => {
  const repo = setup();
  const { rule, needsScannerValidation } = repo.create(good());
  assert.equal(rule.id, 'USER-001');
  assert.equal(rule.origin, 'user');
  assert.equal(rule.engine, 'pattern');
  assert.equal(needsScannerValidation, false);
  const ast = repo.create({ ...good(), id: 'USER-002', pattern: undefined, query: '(call_expression) @sink' });
  assert.equal(ast.needsScannerValidation, true);
});

test('create rejects invalid rules with code INVALID', () => {
  const repo = setup();
  const bad = [
    [{ ...good(), id: undefined }, /no id/],
    [{ ...good(), language: undefined }, /language/],
    [{ ...good(), pattern: undefined }, /query, pattern or definition/],
    [{ ...good(), severity: 'SEVERE' }, /severity/],
    [{ ...good(), fixture: undefined }, /fixture/],
    [{ ...good(), pattern: '(' }, /does not compile/],
    [{ ...good(), pattern: 'a*' }, /empty string/],
    [{ ...good(), files: undefined }, /files/],
  ];
  for (const [rule, re] of bad) {
    assert.throws(() => repo.create(rule), e => e.code === 'INVALID' && re.test(e.message), JSON.stringify(rule));
  }
});

test('create rejects a duplicate id with code CONFLICT', () => {
  const repo = setup();
  repo.create(good());
  assert.throws(() => repo.create(good()), e => e.code === 'CONFLICT');
});

test('update bumps the rule version and keeps the other fields', () => {
  const repo = setup();
  repo.create(good());
  const updated = repo.update('USER-001', { severity: 'LOW' });
  assert.equal(updated.version, 2);
  assert.equal(updated.severity, 'LOW');
  assert.equal(updated.body.pattern, 'eval\\(');
  assert.throws(() => repo.update('NOPE', {}), e => e.code === 'NOT_FOUND');
});

test('deprecate keeps the rule readable but drops it from active listings', () => {
  const repo = setup();
  repo.create(good());
  repo.deprecate('USER-001');
  assert.equal(repo.get('USER-001').status, 'DEPRECATED');
  assert.equal(repo.list({ status: 'ACTIVE' }).length, 0);
  assert.equal(repo.list({}).length, 1);
});

test('upsertSeeded is idempotent and only bumps the version when the body changes', () => {
  const repo = setup();
  const rule = { id: 'S-1', language: 'java', severity: 'LOW', pattern: 'x', files: ['**/*.java'] };
  assert.equal(repo.upsertSeeded(rule, 'builtin'), 'created');
  assert.equal(repo.upsertSeeded(rule, 'builtin'), 'unchanged');
  assert.equal(repo.get('S-1').version, 1);
  assert.equal(repo.upsertSeeded({ ...rule, severity: 'HIGH' }, 'builtin'), 'updated');
  assert.equal(repo.get('S-1').version, 2);
});

test('list filters by language, engine and origin', () => {
  const repo = setup();
  repo.create(good());
  repo.upsertSeeded({ id: 'J-1', language: 'java', severity: 'LOW', query: '(x)' }, 'builtin');
  assert.deepEqual(repo.list({ language: 'java' }).map(r => r.id), ['J-1']);
  assert.deepEqual(repo.list({ engine: 'pattern' }).map(r => r.id), ['USER-001']);
  assert.deepEqual(repo.list({ origin: 'builtin' }).map(r => r.id), ['J-1']);
});
