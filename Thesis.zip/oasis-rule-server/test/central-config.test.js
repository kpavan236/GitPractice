'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCentralConfig } = require('../src/central-config');

const base = { RULES_DATABASE_URL: 'postgres://synthetic/db', PACK_DIR: '/tmp/packs' };

test('trustProxy defaults to 0 outside production and accepts 0 to 10', () => {
  assert.equal(loadCentralConfig(base).trustProxy, 0);
  assert.equal(loadCentralConfig({ ...base, TRUST_PROXY: '2' }).trustProxy, 2);
  assert.equal(loadCentralConfig({ ...base, TRUST_PROXY: '10' }).trustProxy, 10);
});

test('trustProxy outside 0 to 10 or not a whole number is refused', () => {
  for (const v of ['11', '-1', 'abc', '1.5']) {
    assert.throws(() => loadCentralConfig({ ...base, TRUST_PROXY: v }), /TRUST_PROXY must be a whole number from 0 to 10/);
  }
});

test('production refuses to start without an explicit TRUST_PROXY, and accepts 0', () => {
  for (const env of [{ NODE_ENV: 'production' }, { NODE_ENV: 'production', TRUST_PROXY: '' }]) {
    assert.throws(() => loadCentralConfig({ ...base, ...env }), /TRUST_PROXY must be set in production/);
  }
  assert.equal(loadCentralConfig({ ...base, NODE_ENV: 'production', TRUST_PROXY: '0', ALLOW_PLAIN_HTTP: '1' }).trustProxy, 0);
});

test('TLS files must be set together; production needs TLS or an explicit ALLOW_PLAIN_HTTP=1', () => {
  assert.throws(() => loadCentralConfig({ ...base, TLS_CERT_FILE: '/x/c.pem' }), /must be set together/);
  assert.throws(() => loadCentralConfig({ ...base, TLS_KEY_FILE: '/x/k.pem' }), /must be set together/);
  const prod = { ...base, NODE_ENV: 'production', TRUST_PROXY: '0' };
  assert.throws(() => loadCentralConfig(prod), /Production needs TLS_CERT_FILE/);
  assert.equal(loadCentralConfig({ ...prod, ALLOW_PLAIN_HTTP: '1' }).allowPlainHttp, true);
  assert.equal(loadCentralConfig({ ...prod, TLS_CERT_FILE: '/x/c.pem', TLS_KEY_FILE: '/x/k.pem' }).tlsCertFile, '/x/c.pem');
});

test('shutdownTimeoutMs defaults to 10000 and is validated', () => {
  assert.equal(loadCentralConfig(base).shutdownTimeoutMs, 10000);
  assert.equal(loadCentralConfig({ ...base, SHUTDOWN_TIMEOUT_MS: '500' }).shutdownTimeoutMs, 500);
  assert.throws(() => loadCentralConfig({ ...base, SHUTDOWN_TIMEOUT_MS: 'x' }), /SHUTDOWN_TIMEOUT_MS/);
});
