'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// The client installs only the language packs a repository's file extensions select (pack.json carries the registry's
// extensions). A rule whose own example file has an extension its language does not list would be skipped there but run
// by an engine that is handed every rule, so the two would report different findings.
const ROOT = path.join(__dirname, '..', 'seed');
const NAMED = [/^dockerfile/i, /^jenkinsfile/i, /^\.env/i];   // chosen by file name, not extension (client: BASENAMES)
const ALWAYS = new Set(['secrets', 'iac']);                   // the client always loads these packs

function* ruleFiles(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) yield* ruleFiles(full);
    else if (e.name.endsWith('.json')) yield full;
  }
}

test("every seeded rule's example file has an extension (or name) that selects its language's pack", () => {
  const langs = new Map(JSON.parse(fs.readFileSync(path.join(ROOT, 'languages.json'), 'utf8')).map((l) => [l.id, l]));
  const bad = [];
  for (const file of ruleFiles(path.join(ROOT, 'rules'))) {
    const rule = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!rule.example || typeof rule.example.file !== 'string' || ALWAYS.has(rule.language)) continue;
    const name = path.basename(rule.example.file);
    if (NAMED.some((re) => re.test(name))) continue;
    const lang = langs.get(rule.language);
    const ext = path.extname(name).toLowerCase();
    if (!lang || !lang.extensions.map((x) => x.toLowerCase()).includes(ext)) bad.push(`${rule.id}: ${rule.example.file} is not ${lang ? lang.extensions.join('/') : `a known language (${rule.language})`}`);
  }
  assert.deepEqual(bad, []);
});
