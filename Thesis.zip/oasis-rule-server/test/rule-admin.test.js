'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { createProfilesRepo } = require('../src/profiles');
const { createApp } = require('../src/api');

async function start() {
  const db = openDb();
  const rules = createRulesRepo(db);
  const seed = (id, extra = {}) => rules.upsertSeeded({ id, language: 'java', severity: 'HIGH', query: '(a)', title: `Title ${id}`, description: `Description of ${id}. `.repeat(30), category: 'INJECTION', cwe: 'CWE-89', example: { file: 'A.java', vulnerable: 'x', fixed: 'y' }, ...extra }, 'builtin');
  seed('R1'); seed('R2', { severity: 'LOW', language: 'python', title: 'Weak hash', cwe: 'CWE-327', example: undefined });
  seed('R3', { engine: 'secret', pattern: 'abc', query: undefined, language: 'secrets', title: 'Token', provenance: { source: 'gitleaks', license: 'MIT' } });
  createProfilesRepo(db, rules).ensureDefault();
  const server = createApp({ db }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}
const withServer = fn => async () => { const s = await start(); try { await fn(s); } finally { s.close(); } };
const userRule = (id = 'U1') => ({ id, language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'], title: 'eval', fixture: { detect: 'eval(x)', clean: 'run(x)' } });

test('the rule list can be a light summary: no bodies, a short description, the facts a list shows', withServer(async s => {
  const r = await s.call('GET', '/rules?fields=summary');
  assert.equal(r.status, 200);
  assert.ok(r.body.every(x => x.body === undefined));
  const r1 = r.body.find(x => x.id === 'R1');
  assert.deepEqual([r1.title, r1.category, r1.cwe, r1.hasExample, r1.origin, r1.engine], ['Title R1', 'INJECTION', 'CWE-89', true, 'builtin', 'ast']);
  assert.ok(r1.description.length <= 200);
  assert.equal(r.body.find(x => x.id === 'R2').hasExample, false);
  assert.equal(r.body.find(x => x.id === 'R3').source, 'gitleaks');
}));

test('summary search matches id, title and description, ignoring case, and combines with filters', withServer(async s => {
  const ids = async q => (await s.call('GET', `/rules?fields=summary&${q}`)).body.map(x => x.id);
  assert.deepEqual(await ids('search=weak'), ['R2']);
  assert.deepEqual(await ids('search=R3'), ['R3']);
  assert.deepEqual(await ids('search=description of r1'), ['R1']);
  assert.deepEqual(await ids('search=description&language=python'), ['R2']);
  assert.deepEqual(await ids('search=title&language=python'), []);
  assert.deepEqual(await ids('engine=secret'), ['R3']);
}));

test('a profile lists every active rule with its effective state, and says what it inherits or overrides', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('PUT', '/profiles/strict/rules/R1', { enabled: false });
  await s.call('PUT', '/profiles/strict/rules/R2', { severity: 'CRITICAL' });

  const r = (await s.call('GET', '/profiles/strict/rules')).body;
  const by = Object.fromEntries(r.rules.map(x => [x.ruleId, x]));
  assert.deepEqual([by.R1.enabled, by.R1.overridden, by.R1.inherited], [false, true, false]);
  assert.deepEqual([by.R2.enabled, by.R2.severity, by.R2.defaultSeverity, by.R2.overridden], [true, 'CRITICAL', 'LOW', true]);
  assert.deepEqual([by.R3.enabled, by.R3.overridden, by.R3.inherited], [true, false, true]);
  assert.deepEqual(r.counts, { total: 3, enabled: 2, disabled: 1, overridden: 2 });
  assert.equal(by.R1.title, 'Title R1');

  const def = (await s.call('GET', '/profiles/default/rules')).body;
  assert.deepEqual(def.counts, { total: 3, enabled: 3, disabled: 0, overridden: 0 }, 'the default profile is the baseline: nothing is an override there');
  assert.ok(def.rules.every(x => x.inherited === false));
}));

test('profile rule filters: search, language, engine and state', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('PUT', '/profiles/strict/rules/R1', { enabled: false });
  const ids = async q => (await s.call('GET', `/profiles/strict/rules?${q}`)).body.rules.map(x => x.ruleId);
  assert.deepEqual(await ids('state=disabled'), ['R1']);
  assert.deepEqual(await ids('state=overridden'), ['R1']);
  assert.deepEqual(await ids('state=enabled'), ['R2', 'R3']);
  assert.deepEqual(await ids('language=python'), ['R2']);
  assert.deepEqual(await ids('engine=secret'), ['R3']);
  assert.deepEqual(await ids('search=weak'), ['R2']);
  assert.equal((await s.call('GET', '/profiles/nope/rules')).status, 404);
}));

test('removing a profile\'s own entry hands the rule back to what it inherits', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  const v0 = (await s.call('GET', '/profiles/strict')).body.version;
  await s.call('PUT', '/profiles/strict/rules/R1', { enabled: false });
  const r = await s.call('DELETE', '/profiles/strict/rules/R1');
  assert.equal(r.status, 200);
  const e = (await s.call('GET', '/profiles/strict/rules')).body.rules.find(x => x.ruleId === 'R1');
  assert.deepEqual([e.enabled, e.overridden, e.inherited], [true, false, true]);
  assert.ok((await s.call('GET', '/profiles/strict')).body.version > v0, 'the next scan must see the change');
  assert.equal((await s.call('DELETE', '/profiles/strict/rules/NOPE')).status, 404);
}));

test('projects can be listed with their profile names', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('PUT', '/projects/org-a', { name: 'Org A', profileId: 'strict' });
  await s.call('PUT', '/projects/org-b', { name: 'Org B' });
  const r = (await s.call('GET', '/projects')).body;
  assert.deepEqual(r.map(p => [p.key, p.profileId, p.profileName]), [['org-a', 'strict', 'Strict'], ['org-b', null, 'Default']]);
}));

test('a profile cannot be deleted while it is the default, a parent or assigned, and the reason is given', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('POST', '/profiles', { id: 'stricter', name: 'Stricter', parentId: 'strict' });
  await s.call('PUT', '/projects/org-a', { name: 'A', profileId: 'stricter' });

  let r = await s.call('DELETE', '/profiles/default');
  assert.deepEqual([r.status, /default/i.test(r.body.message)], [409, true]);
  r = await s.call('DELETE', '/profiles/strict');
  assert.deepEqual([r.status, /Stricter/.test(r.body.message)], [409, true]);
  r = await s.call('DELETE', '/profiles/stricter');
  assert.deepEqual([r.status, /org-a/.test(r.body.message)], [409, true]);

  await s.call('PUT', '/projects/org-a', { name: 'A', profileId: null });
  assert.equal((await s.call('DELETE', '/profiles/stricter')).status, 200);
  assert.equal((await s.call('DELETE', '/profiles/strict')).status, 200);
  assert.equal((await s.call('GET', '/profiles/strict')).status, 404);
  assert.equal((await s.call('DELETE', '/profiles/strict')).status, 404);
}));

test('built-in rules accept only a new default severity; custom rules accept content edits', withServer(async s => {
  let r = await s.call('PUT', '/rules/R1', { query: '(different)' });
  assert.equal(r.status, 400);
  assert.match(r.body.message, /built-in|read-only/i);
  r = await s.call('PUT', '/rules/R1', { description: 'changed' });
  assert.equal(r.status, 400);
  r = await s.call('PUT', '/rules/R1', { severity: 'LOW' });
  assert.equal(r.status, 200);
  assert.equal(r.body.severity, 'LOW');

  await s.call('POST', '/rules', userRule());
  r = await s.call('PUT', '/rules/U1', { pattern: 'exec\\(', description: 'now exec' });
  assert.equal(r.status, 200);
  assert.equal(r.body.body.pattern, 'exec\\(');
}));

// ── Review fixes ───────────────────────────────────────────────────────────────

test('null in an edit removes the field, so a rule can switch from a pattern to a query', withServer(async s => {
  await s.call('POST', '/rules', { ...userRule('U9'), description: 'old text', cwe: 'CWE-95' });
  const r = await s.call('PUT', '/rules/U9', { query: '(call_expression) @sink', pattern: null, files: null, cwe: null });
  assert.equal(r.status, 200);
  assert.equal(r.body.engine, 'ast');
  assert.deepEqual([r.body.body.query, r.body.body.pattern, r.body.body.files, r.body.body.cwe, r.body.body.description],
    ['(call_expression) @sink', undefined, undefined, undefined, 'old text']);
  assert.equal(Object.keys(r.body.body).some(k => r.body.body[k] === null), false, 'no nulls are stored');
}));

test('changing the severity of a rule a profile does not run does not start running it', withServer(async s => {
  await s.call('POST', '/rules', userRule('U7'));                       // created, not activated anywhere
  let view = (await s.call('GET', '/profiles/default/rules')).body.rules.find(r => r.ruleId === 'U7');
  assert.deepEqual([view.enabled, view.inherited, view.overridden], [false, false, false]);

  await s.call('PUT', '/profiles/default/rules/U7', { severity: 'LOW' });
  view = (await s.call('GET', '/profiles/default/rules')).body.rules.find(r => r.ruleId === 'U7');
  assert.deepEqual([view.enabled, view.severity], [false, 'LOW'], 'still off, and the chosen severity is kept');

  await s.call('PUT', '/profiles/default/rules/U7', { enabled: true });
  view = (await s.call('GET', '/profiles/default/rules')).body.rules.find(r => r.ruleId === 'U7');
  assert.deepEqual([view.enabled, view.severity], [true, 'LOW']);
}));

test('a disabled rule keeps the severity its profile chose, and inherits nothing it never had', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('PUT', '/profiles/strict/rules/R1', { enabled: false, severity: 'CRITICAL' });
  const view = (await s.call('GET', '/profiles/strict/rules')).body.rules;
  const r1 = view.find(r => r.ruleId === 'R1');
  assert.deepEqual([r1.enabled, r1.severity, r1.overridden], [false, 'CRITICAL', true]);

  await s.call('POST', '/rules', userRule('U5'));
  const u5 = (await s.call('GET', '/profiles/strict/rules')).body.rules.find(r => r.ruleId === 'U5');
  assert.deepEqual([u5.enabled, u5.inherited, u5.overridden], [false, false, false], 'nothing in the chain has it, so there is nothing to inherit');
}));

test('a rule an ancestor runs is inherited by a child that never touched it', withServer(async s => {
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  const r2 = (await s.call('GET', '/profiles/strict/rules')).body.rules.find(r => r.ruleId === 'R2');
  assert.deepEqual([r2.enabled, r2.inherited, r2.overridden], [true, true, false]);
}));
