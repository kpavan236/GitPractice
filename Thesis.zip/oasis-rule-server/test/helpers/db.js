'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { createPool } = require('../../src/pg');
const { migrate } = require('../../src/migrate');

// Local development container (docker run -p 5433:5432 postgres:16); the password is the throw-away local one, not a secret.
const ADMIN_URL = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';

async function freshDb({ migrate: run = true } = {}) {
  const name = `rules_test_${crypto.randomBytes(6).toString('hex')}`;
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  admin.on('error', () => {});
  await admin.query(`CREATE DATABASE ${name}`);
  const u = new URL(ADMIN_URL); u.pathname = `/${name}`;
  const url = u.toString();
  if (run) await migrate(url, path.join(__dirname, '..', '..', 'db', 'rules'));
  const pool = createPool(url);
  return {
    pool, url,
    async close() { await pool.end(); await admin.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`); await admin.end(); },
  };
}
module.exports = { freshDb };
