'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { freshDb } = require('./helpers/db');
const { createRulesRepo } = require('../src/rules/repo');
const { createBlobStore } = require('../src/packs/blobs');
const { createReleases } = require('../src/releases');
const { verifyManifest } = require('../src/manifest');
const { testRule } = require('../src/tester');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'rel-'));
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const keys = { k1: publicKey.export({ type: 'spki', format: 'pem' }) };
const sign = { privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), keyId: 'k1' };

function fakeAnalyzer() {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, 'src'));
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'fake', version: '1.0.0' }));
  fs.writeFileSync(path.join(dir, 'src', 'index.js'), "'use strict';\n");
  return dir;
}

const mk = (id, language, extra = {}) => ({
  id, language, pillar: 'security', severity: 'HIGH', title: id, description: 'd',
  files: ['**/*'], pattern: 'bad', example: { file: 'a.txt', vulnerable: 'bad', fixed: 'good' }, ...extra,
});
const passing = async () => ({ ok: true, problems: [] });

async function setup(fn, { tester = { testRule: passing } } = {}) {
  const db = await freshDb();
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go']),('rust','Rust',ARRAY['.rs'])");
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go', 'rust'] });
    const rel = createReleases({ pool: db.pool, blobs: createBlobStore(tmp()), rules: repo, tester, sign, analyzerDir: fakeAnalyzer(), grammarDir: tmp() });
    const activate = async (rule) => {
      await repo.create(rule, { actor: 'ann', reason: 'new' });
      await repo.setStatus(rule.id, 'proposed', { actor: 'ann', reason: 'ready' });
      await repo.setStatus(rule.id, 'active', { actor: 'bob', reason: 'ok' });
    };
    await fn({ rel, repo, activate, pool: db.pool });
  } finally { await db.close(); }
}
const count = async (pool, t) => Number((await pool.query(`SELECT count(*) FROM ${t}`)).rows[0].count);
const who = { actor: 'bob', reason: 'because' };

test('a candidate with failing rules is refused, names them, and stores nothing', () => setup(async ({ rel, activate, pool }) => {
  await activate(mk('go-a', 'go'));
  await activate(mk('go-b', 'go'));
  await activate(mk('rust-a', 'rust'));
  await assert.rejects(() => rel.buildCandidate(who), (e) => {
    assert.equal(e.code, 'FIXTURE_FAILED');
    assert.deepEqual(e.failures.map((f) => f.ruleId), ['go-b', 'rust-a']);
    assert.deepEqual(e.failures[0].problems, ['nope']);
    return true;
  });
  assert.equal(await count(pool, 'release'), 0);
  assert.equal(await count(pool, 'pack'), 0);
}, { tester: { testRule: async (r) => (r.id === 'go-a' ? { ok: true, problems: [] } : { ok: false, problems: ['nope'] }) } }));

test('rules without an example are skipped by the gate and counted', () => setup(async ({ repo, pool }) => {
  let seen = [];
  await repo.upsertSeeded({ id: 'sec-1', language: 'go', severity: 'HIGH', pattern: 'x' }, { origin: 'seed', actor: 'seed' });
  const r2 = createReleases({ pool, blobs: createBlobStore(tmp()), rules: repo, tester: { testRule: async (r) => { seen.push(r.id); return { ok: true, problems: [] }; } }, sign, analyzerDir: fakeAnalyzer(), grammarDir: tmp() });
  const out = await r2.buildCandidate(who);
  assert.deepEqual(seen, []);
  assert.equal(out.skippedNoFixture, 1);
}));

test('buildCandidate stores packs and an unsigned candidate row, and audits', () => setup(async ({ rel, activate, pool }) => {
  await activate(mk('go-a', 'go'));
  const { releaseNo, manifest } = await rel.buildCandidate(who);
  assert.deepEqual(manifest.packs.map((p) => p.packId), ['core', 'lang-go']);
  assert.deepEqual(manifest.ruleVersions, { 'go-a': 1 });
  const row = (await pool.query('SELECT * FROM release WHERE release_no=$1', [releaseNo])).rows[0];
  assert.equal(row.state, 'candidate');
  assert.equal(row.signature, '');
  assert.equal(await count(pool, 'pack'), 2);
  assert.equal((await pool.query("SELECT count(*) FROM audit WHERE action='release.build'")).rows[0].count, '1');
}));

test('stable before beta is INVALID; a reason is required', () => setup(async ({ rel, activate }) => {
  await activate(mk('go-a', 'go'));
  const { releaseNo } = await rel.buildCandidate(who);
  await assert.rejects(() => rel.publish(releaseNo, 'stable', who), { code: 'INVALID' });
  await assert.rejects(() => rel.publish(releaseNo, 'beta', { actor: 'bob' }), { code: 'INVALID' });
  await assert.rejects(() => rel.latest('beta'), { code: 'NOT_FOUND' });
}));

test('publish to beta then promote to stable re-signs with the right channel', () => setup(async ({ rel, activate, pool }) => {
  await activate(mk('go-a', 'go'));
  const { releaseNo } = await rel.buildCandidate(who);
  await rel.publish(releaseNo, 'beta', who);
  const beta = await rel.latest('beta');
  assert.equal(verifyManifest(beta, keys).channel, 'beta');
  await rel.publish(releaseNo, 'stable', who);
  const stable = await rel.latest('stable');
  assert.equal(verifyManifest(stable, keys).channel, 'stable');
  assert.equal((await rel.latest('beta')).manifest.channel, 'beta');
  assert.equal((await pool.query('SELECT state FROM release WHERE release_no=$1', [releaseNo])).rows[0].state, 'stable');
  assert.equal((await pool.query("SELECT count(*) FROM audit WHERE action='release.publish'")).rows[0].count, '2');
}));

test('latest(stable, since) lists exactly the changed language pack', () => setup(async ({ rel, repo, activate }) => {
  await activate(mk('go-a', 'go'));
  await activate(mk('rust-a', 'rust'));
  const one = (await rel.buildCandidate(who)).releaseNo;
  await rel.publish(one, 'beta', who); await rel.publish(one, 'stable', who);
  assert.deepEqual((await rel.latest('stable')).changedPackIds, ['core', 'lang-go', 'lang-rust']);
  await repo.updateMetadata('go-a', { severity: 'LOW' }, { actor: 'ann', reason: 'noisy' });
  const two = (await rel.buildCandidate(who)).releaseNo;
  assert.deepEqual(await rel.diff(two), { added: [], changed: ['go-a'], deprecated: [], packsChanged: ['lang-go'] });
  await rel.publish(two, 'beta', who); await rel.publish(two, 'stable', who);
  const got = await rel.latest('stable', one);
  assert.equal(got.manifest.release, two);
  assert.deepEqual(got.changedPackIds, ['lang-go']);
  assert.deepEqual((await rel.latest('stable', 9999)).changedPackIds, ['core', 'lang-go', 'lang-rust']);
}));

test('diff against no stable lists everything as added, and reports deprecated rules', () => setup(async ({ rel, repo, activate }) => {
  await activate(mk('go-a', 'go'));
  await activate(mk('go-b', 'go'));
  const one = (await rel.buildCandidate(who)).releaseNo;
  assert.deepEqual((await rel.diff(one)).added, ['go-a', 'go-b']);
  await rel.publish(one, 'beta', who); await rel.publish(one, 'stable', who);
  await repo.setStatus('go-b', 'deprecated', { actor: 'bob', reason: 'old' });
  const two = (await rel.buildCandidate(who)).releaseNo;
  assert.deepEqual(await rel.diff(two), { added: [], changed: [], deprecated: ['go-b'], packsChanged: ['lang-go'] });
}));

test('rollback re-points the channel; candidates are refused', () => setup(async ({ rel, repo, activate, pool }) => {
  await activate(mk('go-a', 'go'));
  const one = (await rel.buildCandidate(who)).releaseNo;
  await rel.publish(one, 'beta', who); await rel.publish(one, 'stable', who);
  await repo.update('go-a', { severity: 'LOW' }, { actor: 'ann', reason: 'noisy' });
  const two = (await rel.buildCandidate(who)).releaseNo;
  await assert.rejects(() => rel.rollback('stable', two, who), { code: 'INVALID' });
  await rel.publish(two, 'beta', who); await rel.publish(two, 'stable', who);
  assert.equal((await rel.latest('stable')).manifest.release, two);
  await assert.rejects(() => rel.rollback('stable', one, { actor: 'bob' }), { code: 'INVALID' });
  await rel.rollback('stable', one, who);
  const back = await rel.latest('stable');
  assert.equal(back.manifest.release, one);
  assert.equal(verifyManifest(back, keys).channel, 'stable');
  assert.equal((await pool.query("SELECT count(*) FROM audit WHERE action='release.rollback'")).rows[0].count, '1');
}));

test('a tampered stored signature fails verification', () => setup(async ({ rel, activate, pool }) => {
  await activate(mk('go-a', 'go'));
  const one = (await rel.buildCandidate(who)).releaseNo;
  await rel.publish(one, 'beta', who);
  await pool.query(
    `UPDATE release SET manifest = jsonb_set(manifest, '{signed,beta,manifest,packs,0,sha256}', to_jsonb($2::text)) WHERE release_no=$1`,
    [one, 'f'.repeat(64)]);
  const got = await rel.latest('beta');
  assert.throws(() => verifyManifest(got, keys), { code: 'BAD_SIGNATURE' });
}));

test('real tester: a passing rule builds and publishes', () => setup(async ({ rel, activate }) => {
  await activate(mk('go-skip', 'go', { pattern: 'InsecureSkipVerify:\\s*true', example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{}' } }));
  const { releaseNo } = await rel.buildCandidate(who);
  await rel.publish(releaseNo, 'beta', who);
  assert.equal(verifyManifest(await rel.latest('beta'), keys).release, releaseNo);
}, { tester: { testRule } }));
