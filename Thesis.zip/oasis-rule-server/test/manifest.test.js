'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { canonical, signManifest, verifyManifest, MIN_LOADER } = require('../src/manifest');

const pair = () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  return { pub: publicKey.export({ type: 'spki', format: 'pem' }), priv: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
};
const manifest = () => ({
  release: 3, channel: 'stable', createdAt: '2026-10-12T00:00:00.000Z', minLoader: MIN_LOADER,
  packs: [{ packId: 'core', kind: 'core', language: null, version: 'v1', sha256: 'a'.repeat(64), size: 10 }],
});

test('sign then verify returns the manifest', () => {
  const k = pair();
  const signed = signManifest(manifest(), k.priv, 'k1');
  assert.equal(signed.keyId, 'k1');
  assert.deepEqual(verifyManifest(signed, { k1: k.pub }), manifest());
});

test('changing one byte of a sha256 throws BAD_SIGNATURE', () => {
  const k = pair();
  const signed = signManifest(manifest(), k.priv, 'k1');
  signed.manifest.packs[0].sha256 = 'b' + 'a'.repeat(63);
  assert.throws(() => verifyManifest(signed, { k1: k.pub }), { code: 'BAD_SIGNATURE' });
});

test('a signature from a different key, or garbage, is BAD_SIGNATURE', () => {
  const a = pair(); const b = pair();
  const signed = signManifest(manifest(), a.priv, 'k1');
  assert.throws(() => verifyManifest(signed, { k1: b.pub }), { code: 'BAD_SIGNATURE' });
  assert.throws(() => verifyManifest({ ...signed, signature: '!!' }, { k1: a.pub }), { code: 'BAD_SIGNATURE' });
});

test('an unknown keyId throws UNKNOWN_KEY', () => {
  const k = pair();
  const signed = signManifest(manifest(), k.priv, 'k1');
  assert.throws(() => verifyManifest(signed, { other: k.pub }), { code: 'UNKNOWN_KEY' });
  assert.throws(() => verifyManifest(signed, {}), { code: 'UNKNOWN_KEY' });
});

test('canonical sorts keys recursively with no whitespace', () => {
  assert.equal(canonical({ b: 1, a: { d: 1, c: 2 } }), '{"a":{"c":2,"d":1},"b":1}');
  assert.equal(canonical({ z: [{ b: 1, a: 2 }, 'x'], n: null }), '{"n":null,"z":[{"a":2,"b":1},"x"]}');
});

test('canonical drops undefined keys like JSON.stringify, so the Oasis copy agrees', () => {
  assert.equal(canonical({ a: 1, b: undefined }), '{"a":1}');
  assert.equal(canonical({ a: [undefined, NaN] }), '{"a":[null,null]}');
  assert.equal(canonical({ a: 1, b: undefined }), canonical({ a: 1 }));
});
