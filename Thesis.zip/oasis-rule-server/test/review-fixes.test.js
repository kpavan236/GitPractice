'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { createProfilesRepo } = require('../src/profiles');
const { seedFromDir } = require('../src/seed');
const { createApp } = require('../src/api');

const seeded = (id, severity = 'HIGH') => ({ id, language: 'java', severity, query: '(a)' });
function setup() {
  const db = openDb();
  const rules = createRulesRepo(db);
  const profiles = createProfilesRepo(db, rules);
  return { db, rules, profiles };
}
async function http(db) {
  const server = createApp({ db }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}

test('Default follows a rule severity change instead of freezing the seeded value', () => {
  const { rules, profiles } = setup();
  rules.upsertSeeded(seeded('b1', 'HIGH'), 'builtin');
  profiles.ensureDefault();
  rules.upsertSeeded(seeded('b1', 'LOW'), 'builtin');
  assert.equal(profiles.activeRules('default')[0].severity, 'LOW');
});

test('editing, re-seeding or deprecating a rule bumps every profile version', () => {
  const { rules, profiles } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  profiles.ensureDefault();
  profiles.create({ id: 'kid', name: 'Kid', parentId: 'default' });
  const v = id => profiles.get(id).version;
  const [d0, k0] = [v('default'), v('kid')];
  rules.update('b1', { severity: 'LOW' });
  assert.equal(v('default'), d0 + 1);
  assert.equal(v('kid'), k0 + 1);
  rules.upsertSeeded(seeded('b1', 'MEDIUM'), 'builtin');
  assert.equal(v('default'), d0 + 2);
  rules.deprecate('b1');
  assert.equal(v('default'), d0 + 3);
});

test('a user rule that was not activated stays inactive after ensureDefault runs again', () => {
  const { rules, profiles } = setup();
  profiles.ensureDefault();
  rules.create({ id: 'U1', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'], fixture: { detect: 'a', clean: 'b' } });
  profiles.ensureDefault();
  assert.deepEqual(profiles.activeRules('default'), []);
});

test('updating a seeded rule validates severity and engine', () => {
  const { rules } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  assert.throws(() => rules.update('b1', { severity: 'BOGUS' }), e => e.code === 'INVALID');
  assert.throws(() => rules.update('b1', { query: null }), e => e.code === 'INVALID');
  assert.equal(rules.get('b1').severity, 'HIGH');
});

test('profiles need a non-empty string id and name', () => {
  const { profiles } = setup();
  for (const bad of [{ name: 'x' }, { id: null, name: 'x' }, { id: 'p', name: '' }, { id: 5, name: 'x' }]) {
    assert.throws(() => profiles.create(bad), e => e.code === 'INVALID', JSON.stringify(bad));
  }
});

test('a severity-only override on a child does not re-enable a rule the parent disabled', () => {
  const { rules, profiles } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  profiles.ensureDefault();
  profiles.setRule('default', 'b1', { enabled: false });
  profiles.create({ id: 'c', name: 'C', parentId: 'default' });
  profiles.setRule('c', 'b1', { severity: 'INFO' });
  assert.deepEqual(profiles.activeRules('c'), []);
});

test('a malformed rule file leaves nothing half-imported', () => {
  const { rules } = setup();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'atomic-'));
  fs.writeFileSync(path.join(dir, 'a.json'), JSON.stringify(seeded('A')));
  fs.writeFileSync(path.join(dir, 'z.json'), '{nope');
  assert.throws(() => seedFromDir(rules, dir, {}), /z\.json/);
  assert.equal(rules.get('A'), null);
});

test('API rejects non-object bodies and bad activateIn without side effects', async () => {
  const { db, rules } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  const s = await http(db);
  try {
    assert.equal((await s.call('PUT', '/rules/b1', [1, 2])).status, 400);
    assert.equal((await s.call('PUT', '/rules/b1', { severity: 'BOGUS' })).status, 400);
    assert.equal((await s.call('PUT', '/rules/b1', { query: null })).status, 400);
    assert.equal((await s.call('POST', '/profiles', { name: 'x' })).status, 400);
    const user = { id: 'U9', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'], fixture: { detect: 'a', clean: 'b' } };
    assert.equal((await s.call('POST', '/rules', { ...user, activateIn: 5 })).status, 400);
    assert.equal((await s.call('POST', '/rules', { ...user, activateIn: 'default' })).status, 400);
    assert.equal((await s.call('POST', '/rules', { ...user, activateIn: ['default', 'ghost'] })).status, 404);
    assert.equal((await s.call('GET', '/rules/U9')).status, 404);
  } finally {
    s.close();
  }
});

test('profile payload says whether the project is registered', async () => {
  const { db, rules, profiles } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  profiles.ensureDefault();
  const s = await http(db);
  try {
    assert.equal((await s.call('GET', '/projects/ghost/profile')).body.projectKnown, false);
    await s.call('PUT', '/projects/real', { name: 'Real' });
    assert.equal((await s.call('GET', '/projects/real/profile')).body.projectKnown, true);
  } finally {
    s.close();
  }
});

test('editing a parent profile bumps the version of every descendant', () => {
  const { rules, profiles } = setup();
  rules.upsertSeeded(seeded('b1'), 'builtin');
  profiles.ensureDefault();
  profiles.create({ id: 'kid', name: 'Kid', parentId: 'default' });
  profiles.create({ id: 'grandkid', name: 'Grandkid', parentId: 'kid' });
  profiles.create({ id: 'other', name: 'Other' });
  const before = id => profiles.get(id).version;
  const [k, g, o] = [before('kid'), before('grandkid'), before('other')];
  profiles.setRule('default', 'b1', { enabled: false });
  assert.equal(before('kid'), k + 1);
  assert.equal(before('grandkid'), g + 1);
  assert.equal(before('other'), o);
});
