'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { defaultDbFile, defaultPort, FETCH_BLOCKED_PORTS } = require('../src/config');

test('the database defaults to one absolute file inside this repository, regardless of the working directory', () => {
  const file = defaultDbFile({});
  assert.ok(path.isAbsolute(file));
  assert.equal(file, path.join(__dirname, '..', 'oasis-rules.db'));
  assert.equal(defaultDbFile({ OASIS_RULE_SERVER_DB: '/tmp/x.db' }), '/tmp/x.db');
});

test('the server and the seed script resolve the same default database', () => {
  const seed = require('fs').readFileSync(path.join(__dirname, '..', 'scripts', 'seed.js'), 'utf8');
  const server = require('fs').readFileSync(path.join(__dirname, '..', 'src', 'server.js'), 'utf8');
  assert.match(seed, /defaultDbFile/);
  assert.match(server, /defaultDbFile/);
});

test('the default port is one fetch will connect to (5060 is blocked as SIP)', () => {
  assert.equal(defaultPort({}), 5090);
  assert.equal(defaultPort({ OASIS_RULE_SERVER_PORT: '5111' }), 5111);
  assert.ok(FETCH_BLOCKED_PORTS.includes(5060));
  assert.ok(!FETCH_BLOCKED_PORTS.includes(defaultPort({})));
});
