'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const http = require('node:http');
const { freshDb } = require('./helpers/db');
const { createRulesRepo } = require('../src/rules/repo');
const { createBlobStore } = require('../src/packs/blobs');
const { createReleases } = require('../src/releases');
const { createCentralApp } = require('../src/central-app');
const { rateLimit } = require('../src/rate-limit');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'rapi-'));
const { privateKey } = crypto.generateKeyPairSync('ed25519');
const sign = { privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), keyId: 'k1' };
const who = { actor: 'bob', reason: 'because' };

function fakeAnalyzer() {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, 'src'));
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'fake', version: '1.0.0' }));
  fs.writeFileSync(path.join(dir, 'src', 'index.js'), "'use strict';\n");
  return dir;
}
const rule = (id) => ({
  id, language: 'go', pillar: 'security', severity: 'HIGH', title: id, description: 'd',
  files: ['**/*'], pattern: 'bad', example: { file: 'a.txt', vulnerable: 'bad', fixed: 'good' },
});

async function setup(fn, appOpts = {}) {
  const db = await freshDb();
  const blobs = createBlobStore(tmp());
  let server;
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go'])");
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go'] });
    const releases = createReleases({ pool: db.pool, blobs, rules: repo, tester: { testRule: async () => ({ ok: true, problems: [] }) }, sign, analyzerDir: fakeAnalyzer(), grammarDir: tmp() });
    const app = createCentralApp({ pool: db.pool, blobs, releases, ...appOpts });
    server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    const base = `http://127.0.0.1:${server.address().port}`;
    const publish = async () => {
      const r = rule('go-a');
      await repo.create(r, { actor: 'ann', reason: 'new' });
      await repo.setStatus(r.id, 'proposed', { actor: 'ann', reason: 'ready' });
      await repo.setStatus(r.id, 'active', { actor: 'bob', reason: 'ok' });
      const { releaseNo } = await releases.buildCandidate(who);
      await releases.publish(releaseNo, 'beta', who);
      await releases.publish(releaseNo, 'stable', who);
      return releaseNo;
    };
    await fn({ base, publish, blobs });
  } finally {
    if (server) await new Promise((r) => { server.closeAllConnections(); server.close(r); });
    await db.close();
  }
}
const get = async (url) => {
  const res = await fetch(url);
  const buf = Buffer.from(await res.arrayBuffer());
  return { res, buf, json: () => JSON.parse(buf.toString('utf8')) };
};
// fetch and URL strings normalise ../ away; an options object sends the path as written
const raw = (base, p) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port: new URL(base).port, path: p }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); }).on('error', reject);
});

test('an empty channel answers 404 NO_RELEASE; a bad or missing channel answers 400', () => setup(async ({ base }) => {
  const a = await get(`${base}/v1/releases/latest?channel=stable`);
  assert.equal(a.res.status, 404);
  assert.deepEqual(a.json(), { error: 'NO_RELEASE' });
  assert.equal((await get(`${base}/v1/releases/latest?channel=nightly`)).res.status, 400);
  assert.equal((await get(`${base}/v1/releases/latest`)).res.status, 400);
  assert.equal((await get(`${base}/v1/releases/latest?channel=stable&since=abc`)).res.status, 400);
}));

test('latest returns the signed manifest and every pack as changed; since the current release changes none', () => setup(async ({ base, publish }) => {
  const no = await publish();
  const a = await get(`${base}/v1/releases/latest?channel=stable`);
  assert.equal(a.res.status, 200);
  const body = a.json();
  assert.equal(body.manifest.release, no);
  assert.equal(body.manifest.channel, 'stable');
  assert.equal(body.keyId, 'k1');
  assert.ok(body.signature);
  assert.deepEqual(body.changedPackIds, ['core', 'lang-go']);
  const b = await get(`${base}/v1/releases/latest?channel=stable&since=${no}`);
  assert.deepEqual(b.json().changedPackIds, []);
  assert.equal(a.res.headers.get('x-content-type-options'), 'nosniff');
}));

test('a blob is served as immutable bytes whose sha256 is the path', () => setup(async ({ base, publish }) => {
  await publish();
  const { manifest } = (await get(`${base}/v1/releases/latest?channel=stable`)).json();
  const sha = manifest.packs[0].sha256;
  const { res, buf } = await get(`${base}/v1/blobs/${sha}`);
  assert.equal(res.status, 200);
  assert.equal(crypto.createHash('sha256').update(buf).digest('hex'), sha);
  assert.equal(res.headers.get('content-type'), 'application/octet-stream');
  assert.equal(res.headers.get('cache-control'), 'public, max-age=31536000, immutable');
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
}));

test('a bad blob name is 400, and a missing blob is 404', () => setup(async ({ base, blobs }) => {
  assert.equal(await raw(base, '/v1/blobs/../../etc/passwd'), 400);
  assert.equal(await raw(base, '/v1/blobs/%2e%2e%2f%2e%2e%2fetc%2fpasswd'), 400);
  assert.equal((await get(`${base}/v1/blobs/${'a'.repeat(63)}`)).res.status, 400);
  assert.equal((await get(`${base}/v1/blobs/${'A'.repeat(64)}`)).res.status, 400);
  const missing = await get(`${base}/v1/blobs/${'a'.repeat(64)}`);
  assert.equal(missing.res.status, 404);
  assert.deepEqual(missing.json(), { error: 'NOT_FOUND' });
  const sha = await blobs.put(Buffer.from('payload'));
  assert.equal((await get(`${base}/v1/blobs/${sha}`)).res.status, 200);
}));

test('a corrupt blob is a 500 and its bytes are not served', async () => {
  const blobs = { get: async () => { throw Object.assign(new Error('mismatch'), { code: 'CORRUPT' }); } };
  const app = createCentralApp({ blobs, releases: {} });
  const server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const quiet = console.error; console.error = () => {};
  try {
    const r = await get(`http://127.0.0.1:${server.address().port}/v1/blobs/${'b'.repeat(64)}`);
    assert.equal(r.res.status, 500);
    assert.deepEqual(r.json(), { error: 'INTERNAL' });
  } finally { console.error = quiet; await new Promise((res) => { server.closeAllConnections(); server.close(res); }); }
});

test('health answers ok, and only GET is served', () => setup(async ({ base }) => {
  const h = await get(`${base}/v1/health`);
  assert.deepEqual(h.json(), { status: 'ok' });
  const post = await fetch(`${base}/v1/health`, { method: 'POST' });
  assert.equal(post.status, 404);
}));

test('the 61st request in a minute from one address is 429 with Retry-After; health is counted too', () => setup(async ({ base }) => {
  for (let i = 0; i < 60; i++) assert.equal((await get(`${base}/v1/health`)).res.status, 200);
  const over = await get(`${base}/v1/health`);
  assert.equal(over.res.status, 429);
  assert.ok(Number(over.res.headers.get('retry-after')) >= 1);
  assert.equal(over.json().error, 'TOO_MANY_REQUESTS');
}));

test('the limiter counts each address on its own, groups an IPv6 /64, and starts a new window', () => {
  let t = 0;
  const lim = rateLimit({ max: 2, now: () => t });
  const hit = (ip) => {
    const out = { status: 200 };
    const res = { set() { return res; }, status(n) { out.status = n; return res; }, json() { out.blocked = true; } };
    lim({ ip }, res, () => { out.passed = true; });
    return out.blocked ? out : undefined;
  };
  assert.equal(hit('10.0.0.1'), undefined);
  assert.equal(hit('10.0.0.1'), undefined);
  assert.equal(hit('10.0.0.1').status, 429);
  assert.equal(hit('10.0.0.2'), undefined);
  assert.equal(hit('2001:db8:1:2::1'), undefined);
  assert.equal(hit('2001:db8:1:2::ffff'), undefined);
  assert.equal(hit('2001:db8:1:2:9::1').status, 429);
  t = 60_000;
  assert.equal(hit('10.0.0.1'), undefined);
});
