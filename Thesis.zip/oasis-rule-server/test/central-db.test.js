'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDb } = require('./helpers/db');
const { tx } = require('../src/pg');

test('migrations create the rule, release and audit tables', async () => {
  const db = await freshDb();
  try {
    const { rows } = await db.pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    const names = rows.map(r => r.table_name);
    for (const t of ['rule', 'rule_version', 'pack', 'release', 'channel', 'audit', 'language']) {
      assert.ok(names.includes(t), `${t} table`);
    }
  } finally { await db.close(); }
});

test('tx rolls back when the callback throws', async () => {
  const db = await freshDb();
  try {
    await assert.rejects(() => tx(db.pool, async c => {
      await c.query("INSERT INTO language (id, name, extensions) VALUES ('x', 'X', ARRAY['.x'])");
      throw new Error('boom');
    }), /boom/);
    const { rowCount } = await db.pool.query("SELECT 1 FROM language WHERE id = 'x'");
    assert.equal(rowCount, 0);
  } finally { await db.close(); }
});

test('migrate refuses an applied file that has since changed', async () => {
  const fs = require('node:fs'); const os = require('node:os'); const path = require('node:path');
  const { migrate } = require('../src/migrate');
  const db = await freshDb({ migrate: false });
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mig-'));
  try {
    fs.writeFileSync(path.join(dir, '001_a.up.sql'), 'CREATE TABLE a (x int);');
    await migrate(db.url, dir);
    fs.writeFileSync(path.join(dir, '001_a.up.sql'), 'CREATE TABLE a (x int, y int);');
    await assert.rejects(() => migrate(db.url, dir), /has since changed/);
  } finally { await db.close(); }
});
