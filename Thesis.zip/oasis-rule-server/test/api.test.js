'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { createProfilesRepo } = require('../src/profiles');
const { createApp } = require('../src/api');

async function start({ token } = {}) {
  const db = openDb();
  const rules = createRulesRepo(db);
  rules.upsertSeeded({ id: 'A1', language: 'java', severity: 'HIGH', query: '(a)' }, 'builtin');
  rules.upsertSeeded({ id: 'P1', language: 'java', severity: 'LOW', pattern: 'x', files: ['**/*.java'] }, 'builtin');
  createProfilesRepo(db, rules).ensureDefault();
  const server = createApp({ db, token }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, path, body, headers = {}) => {
    const res = await fetch(base + path, {
      method, headers: { 'content-type': 'application/json', ...headers }, body: body ? JSON.stringify(body) : undefined,
    });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}

const userRule = () => ({
  id: 'U1', language: 'javascript', severity: 'HIGH', pattern: 'eval\\(', files: ['**/*.js'],
  fixture: { detect: 'eval(x)', clean: 'run(x)' },
});

test('health and compat', async () => {
  const s = await start();
  assert.deepEqual((await s.call('GET', '/health')).body, { status: 'ok' });
  assert.deepEqual((await s.call('GET', '/analyzers/compat')).body.ruleSchemaVersions, { ast: 1, pattern: 1, 'iac-policy': 1, secret: 1 });
  s.close();
});

test('rule CRUD lifecycle through HTTP', async () => {
  const s = await start();
  let r = await s.call('POST', '/rules', userRule());
  assert.equal(r.status, 201);
  assert.equal(r.body.needsScannerValidation, false);
  assert.equal((await s.call('POST', '/rules', userRule())).status, 409);
  assert.equal((await s.call('POST', '/rules', { ...userRule(), id: 'U2', severity: 'NOPE' })).status, 400);
  assert.equal((await s.call('PUT', '/rules/U1', { severity: 'LOW' })).body.version, 2);
  assert.equal((await s.call('DELETE', '/rules/U1')).body.status, 'DEPRECATED');
  assert.equal((await s.call('GET', '/rules/U1')).status, 200);
  assert.equal((await s.call('GET', '/rules/NOPE')).status, 404);
  assert.deepEqual((await s.call('GET', '/rules?language=java')).body.map(x => x.id), ['A1', 'P1']);
  s.close();
});

test('activateIn adds a new rule to the named profiles', async () => {
  const s = await start();
  await s.call('POST', '/rules', { ...userRule(), activateIn: ['default'] });
  const p = await s.call('GET', '/projects/anything/profile');
  assert.ok(p.body.rules.some(x => x.ruleId === 'U1'));
  s.close();
});

test('profile rule overrides flow into the project profile payload', async () => {
  const s = await start();
  await s.call('POST', '/profiles', { id: 'strict', name: 'Strict', parentId: 'default' });
  await s.call('PUT', '/profiles/strict/rules/P1', { enabled: false });
  await s.call('PUT', '/profiles/strict/rules/A1', { severity: 'CRITICAL' });
  assert.equal((await s.call('PUT', '/projects/student-api', { name: 'Student API', profileId: 'strict' })).status, 200);
  const res = await s.call('GET', '/projects/student-api/profile');
  assert.equal(res.body.profile.id, 'strict');
  assert.deepEqual(res.body.rules.map(r => [r.ruleId, r.severity]), [['A1', 'CRITICAL']]);
  assert.equal((await s.call('PUT', '/projects/x', { name: 'x', profileId: 'ghost' })).status, 404);
  s.close();
});

test('unknown project gets the Default profile', async () => {
  const s = await start();
  const res = await s.call('GET', '/projects/never-seen/profile');
  assert.equal(res.status, 200);
  assert.equal(res.body.profile.id, 'default');
  assert.equal(res.body.rules.length, 2);
  s.close();
});

test('422 names every rule the scanner cannot run, never a partial list', async () => {
  const s = await start();
  const res = await s.call('GET', '/projects/p/profile?engines=pattern:1');
  assert.equal(res.status, 422);
  assert.equal(res.body.error, 'UNSUPPORTED_RULES');
  assert.deepEqual(res.body.rules.map(r => r.ruleId), ['A1']);
  assert.match(res.body.message, /Rule A1 is active in profile "Default" but the installed scanner does not support it/);
  assert.equal((await s.call('GET', '/projects/p/profile?engines=ast:1,pattern:1')).status, 200);
  assert.equal((await s.call('GET', '/projects/p/profile?engines=ast:0,pattern:1')).status, 422);
  s.close();
});

test('mutations reject a non-loopback browser Origin; reads and loopback origins pass', async () => {
  const s = await start();
  const evil = { origin: 'https://evil.example' };
  assert.equal((await s.call('POST', '/rules', userRule(), evil)).status, 403);
  assert.equal((await s.call('GET', '/rules', null, evil)).status, 200);
  assert.equal((await s.call('POST', '/rules', userRule(), { origin: 'http://localhost:5051' })).status, 201);
  s.close();
});

test('mutations require the token when one is configured', async () => {
  const s = await start({ token: 'secret' });
  assert.equal((await s.call('POST', '/rules', userRule())).status, 401);
  assert.equal((await s.call('POST', '/rules', userRule(), { 'x-oasis-token': 'wrong' })).status, 401);
  assert.equal((await s.call('POST', '/rules', userRule(), { 'x-oasis-token': 'secret' })).status, 201);
  assert.equal((await s.call('GET', '/rules')).status, 200);
  s.close();
});
