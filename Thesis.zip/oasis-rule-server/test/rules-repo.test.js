'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDb } = require('./helpers/db');
const { createRulesRepo } = require('../src/rules/repo');

const goodRule = {
  id: 'go-insecure-skip-verify', language: 'go', pillar: 'security', severity: 'HIGH', type: 'SAST',
  title: 'TLS verification disabled', description: 'InsecureSkipVerify turns off certificate checks.',
  files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
  example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
};

async function withRepo(fn) {
  const db = await freshDb();
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go'])");
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go'] });
    await fn(repo, db.pool);
  } finally { await db.close(); }
}
const count = async (pool, table) => Number((await pool.query(`SELECT count(*) FROM ${table}`)).rows[0].count);

test('create then get returns version 1 as a draft', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  const row = await repo.get(goodRule.id);
  assert.equal(row.version, 1);
  assert.equal(row.status, 'draft');
  assert.equal(row.engine, 'pattern');
  assert.equal(row.body.title, goodRule.title);
}));

test('creating an invalid rule throws INVALID and writes nothing', () => withRepo(async (repo, pool) => {
  await assert.rejects(() => repo.create({ ...goodRule, severity: 'SEVERE' }, { actor: 'ann', reason: 'x' }), { code: 'INVALID' });
  assert.equal(await count(pool, 'rule'), 0);
  assert.equal(await count(pool, 'rule_version'), 0);
  assert.equal(await count(pool, 'audit'), 0);
}));

test('a duplicate id throws CONFLICT and leaves one version', () => withRepo(async (repo, pool) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await assert.rejects(() => repo.create(goodRule, { actor: 'ann', reason: 'again' }), { code: 'CONFLICT' });
  assert.equal(await count(pool, 'rule_version'), 1);
  assert.equal(await count(pool, 'audit'), 1);
}));

test('update bumps the version and history lists both', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  const row = await repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann', reason: 'too noisy' });
  assert.equal(row.version, 2);
  assert.equal(row.severity, 'LOW');
  const history = await repo.history(goodRule.id);
  assert.deepEqual(history.map((h) => h.version), [1, 2]);
  assert.equal(history[0].body.severity, 'HIGH');
  assert.equal(history[1].body.severity, 'LOW');
}));

test('a null in the patch removes that field', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  const row = await repo.update(goodRule.id, { type: null }, { actor: 'ann', reason: 'drop type' });
  assert.equal('type' in row.body, false);
  assert.equal(row.version, 2);
}));

test('an update that makes the rule invalid is refused and changes nothing', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await assert.rejects(() => repo.update(goodRule.id, { pattern: null }, { actor: 'ann', reason: 'x' }), { code: 'INVALID' });
  assert.equal((await repo.get(goodRule.id)).version, 1);
}));

test('a draft moves to proposed to active by a different actor', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  assert.equal((await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'ready' })).status, 'proposed');
  assert.equal((await repo.setStatus(goodRule.id, 'active', { actor: 'bob', reason: 'reviewed' })).status, 'active');
}));

test('the proposer cannot approve their own rule', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'ready' });
  await assert.rejects(() => repo.setStatus(goodRule.id, 'active', { actor: 'ann', reason: 'approve' }), { code: 'FORBIDDEN' });
  const row = await repo.setStatus(goodRule.id, 'active', { actor: 'bob', reason: 'reviewed' });
  assert.equal(row.status, 'active');
}));

test('active to draft is INVALID, and editing an active rule returns it to draft with proposed_by cleared (Ruling 15)', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'ready' });
  await repo.setStatus(goodRule.id, 'active', { actor: 'bob', reason: 'reviewed' });
  await assert.rejects(() => repo.setStatus(goodRule.id, 'draft', { actor: 'bob', reason: 'back' }), { code: 'INVALID' });
  const row = await repo.update(goodRule.id, { severity: 'MEDIUM' }, { actor: 'bob', reason: 'tune' });
  assert.equal(row.status, 'draft');
  assert.equal(row.proposed_by, null);
  assert.equal(row.version, 2);
}));

test('editing a proposed rule returns it to draft with proposed_by cleared (Ruling 15); a deprecated rule cannot be edited', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'ready' });
  const row = await repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann', reason: 'x' });
  assert.equal(row.status, 'draft');
  assert.equal(row.proposed_by, null);
  await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'again' });
  await repo.setStatus(goodRule.id, 'active', { actor: 'bob', reason: 'ok' });
  await repo.setStatus(goodRule.id, 'deprecated', { actor: 'bob', reason: 'old' });
  await assert.rejects(() => repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann', reason: 'x' }), { code: 'INVALID' });
}));

test('revert to version 1 creates version 3 equal to version 1', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'new rule' });
  await repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann', reason: 'tune' });
  const row = await repo.revert(goodRule.id, 1, { actor: 'ann', reason: 'tuning was wrong' });
  assert.equal(row.version, 3);
  const history = await repo.history(goodRule.id);
  assert.deepEqual(history[2].body, history[0].body);
  assert.equal(row.severity, 'HIGH');
  await assert.rejects(() => repo.revert(goodRule.id, 9, { actor: 'ann', reason: 'x' }), { code: 'NOT_FOUND' });
}));

test('missing rule is NOT_FOUND', () => withRepo(async (repo) => {
  await assert.rejects(() => repo.get('nope'), { code: 'NOT_FOUND' });
  await assert.rejects(() => repo.update('nope', {}, { actor: 'a', reason: 'r' }), { code: 'NOT_FOUND' });
  await assert.rejects(() => repo.setStatus('nope', 'proposed', { actor: 'a', reason: 'r' }), { code: 'NOT_FOUND' });
}));

test('every mutation writes an audit row carrying the reason', () => withRepo(async (repo, pool) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'reason-create' });
  await repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann', reason: 'reason-update' });
  await repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: 'reason-status' });
  await repo.setStatus(goodRule.id, 'draft', { actor: 'ann', reason: 'reason-back' });
  await repo.revert(goodRule.id, 1, { actor: 'ann', reason: 'reason-revert' });
  const { rows } = await pool.query('SELECT actor, action, subject, reason, outcome FROM audit ORDER BY audit_id');
  assert.deepEqual(rows.map((r) => r.reason), ['reason-create', 'reason-update', 'reason-status', 'reason-back', 'reason-revert']);
  assert.deepEqual(rows.map((r) => r.action), ['rule.create', 'rule.update', 'rule.status', 'rule.status', 'rule.revert']);
  assert.ok(rows.every((r) => r.actor === 'ann' && r.subject === goodRule.id && r.outcome === 'done'));
}));

test('a missing or blank reason throws INVALID on every mutation', () => withRepo(async (repo, pool) => {
  await assert.rejects(() => repo.create(goodRule, { actor: 'ann' }), { code: 'INVALID', message: 'a reason is required' });
  await assert.rejects(() => repo.create(goodRule, { actor: 'ann', reason: '   ' }), { code: 'INVALID' });
  assert.equal(await count(pool, 'rule'), 0);
  await repo.create(goodRule, { actor: 'ann', reason: 'ok' });
  await assert.rejects(() => repo.update(goodRule.id, { severity: 'LOW' }, { actor: 'ann' }), { code: 'INVALID' });
  await assert.rejects(() => repo.setStatus(goodRule.id, 'proposed', { actor: 'ann', reason: '' }), { code: 'INVALID' });
  await assert.rejects(() => repo.revert(goodRule.id, 1, { actor: 'ann' }), { code: 'INVALID' });
}));

test('list filters by language, severity, status and search', () => withRepo(async (repo) => {
  await repo.create(goodRule, { actor: 'ann', reason: 'r' });
  await repo.create({ ...goodRule, id: 'go-other', severity: 'LOW', title: 'Something else', description: 'Other 100% thing' }, { actor: 'ann', reason: 'r' });
  assert.equal((await repo.list()).length, 2);
  assert.deepEqual((await repo.list({ severity: 'LOW' })).map((r) => r.rule_id), ['go-other']);
  assert.equal((await repo.list({ language: 'go', status: 'draft', engine: 'pattern', pillar: 'security' })).length, 2);
  assert.equal((await repo.list({ status: 'active' })).length, 0);
  assert.deepEqual((await repo.list({ search: 'TLS' })).map((r) => r.rule_id), [goodRule.id]);
  assert.deepEqual((await repo.list({ search: '100%' })).map((r) => r.rule_id), ['go-other']);
  assert.equal((await repo.list({ search: '%' })).length, 1);
}));

const seeded = { id: 'GO_Legacy_Rule', language: 'go', severity: 'HIGH', pattern: 'foo\\(', files: ['**/*.go'] };
const seedOpts = { origin: 'seed', actor: 'seeder' };

test('upsertSeeded creates, is unchanged on identical re-seed, and updates with a bump', () => withRepo(async (repo, pool) => {
  assert.equal(await repo.upsertSeeded(seeded, seedOpts), 'created');
  const row = await repo.get(seeded.id);
  assert.equal(row.version, 1);
  assert.equal(row.status, 'active');
  assert.equal(row.origin, 'seed');
  assert.equal(row.pillar, 'security');
  assert.equal(row.body.pillar, 'security');

  assert.equal(await repo.upsertSeeded({ ...seeded }, seedOpts), 'unchanged');
  assert.equal((await repo.get(seeded.id)).version, 1);
  assert.equal(await count(pool, 'rule_version'), 1);
  assert.equal(await count(pool, 'audit'), 1);

  assert.equal(await repo.upsertSeeded({ ...seeded, severity: 'LOW' }, seedOpts), 'updated');
  const after = await repo.get(seeded.id);
  assert.equal(after.version, 2);
  assert.equal(after.severity, 'LOW');
  assert.equal(after.status, 'active');
  assert.deepEqual((await repo.history(seeded.id)).map((h) => h.version), [1, 2]);
}));

test('upsertSeeded writes rule_version and audit rows', () => withRepo(async (repo, pool) => {
  await repo.upsertSeeded(seeded, seedOpts);
  const v = (await pool.query('SELECT changed_by, reason FROM rule_version')).rows;
  assert.equal(v.length, 1);
  assert.equal(v[0].changed_by, 'seeder');
  const a = (await pool.query('SELECT actor, action, subject, reason, outcome FROM audit')).rows;
  assert.equal(a.length, 1);
  assert.equal(a[0].actor, 'seeder');
  assert.equal(a[0].action, 'rule.seed');
  assert.equal(a[0].subject, seeded.id);
  assert.ok(a[0].reason);
}));

test('upsertSeeded refuses an unknown language, a bad severity, a bad pillar, no engine, no id', () => withRepo(async (repo, pool) => {
  for (const bad of [
    { ...seeded, language: 'cobol' }, { ...seeded, severity: 'SEVERE' }, { ...seeded, pillar: 'style' },
    { ...seeded, pattern: undefined }, { ...seeded, id: '' },
  ]) {
    await assert.rejects(() => repo.upsertSeeded(bad, seedOpts), { code: 'INVALID' });
  }
  assert.equal(await count(pool, 'rule'), 0);
}));
