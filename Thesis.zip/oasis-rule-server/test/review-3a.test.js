'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createApp } = require('../src/api');

async function start() {
  const server = createApp({ db: openDb() }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}
const withServer = fn => async () => { const s = await start(); try { await fn(s); } finally { s.close(); } };
const fnd = (fp, extra = {}) => ({ fingerprint: fp, id: `F-${fp}`, type: 'SAST', severity: 'HIGH', status: 'OPEN', isNewCode: false, ...extra });
const run = (id, findings, extra = {}) => ({ analysisId: id, projectKey: 'p', coverage: [{ type: 'SAST', analysed: true }], newCodeAvailable: true, findings, ...extra });

test('an upload cannot choose its findings\' triage state, and cannot hide a finding from the gate', withServer(async s => {
  const sneaky = fnd('x', { severity: 'CRITICAL', isNewCode: true, status: 'SUPPRESSED', suppression: { reason: 'trust me' }, notes: 'n', resolvedAt: 1, resolvedBy: 'X' });
  const r = await s.call('POST', '/analyses', run('A1', [sneaky]));
  assert.equal(r.status, 201);
  assert.equal(r.body.gate.status, 'FAILED', 'a self-declared SUPPRESSED finding must still count');
  const [stored] = (await s.call('GET', '/projects/p/findings?status=all')).body;
  assert.equal(stored.status, 'OPEN');
  assert.equal(stored.suppression, undefined);
  assert.equal(stored.notes, undefined);
  assert.equal(stored.resolvedAt, undefined);
}));

test('a finding without a status is stored as OPEN instead of failing the whole upload', withServer(async s => {
  const { status: _drop, ...noStatus } = fnd('y');
  assert.equal((await s.call('POST', '/analyses', run('A1', [noStatus]))).status, 201);
  assert.equal((await s.call('GET', '/projects/p/findings')).body[0].status, 'OPEN');
}));

test('the response says which gate was used', withServer(async s => {
  assert.equal((await s.call('POST', '/analyses', run('A1', []))).body.gateSource, 'default');
  await s.call('PUT', '/projects/p/gate', { conditions: [{ metric: 'secrets', scope: 'OVERALL', operator: 'GT', threshold: 0 }] });
  assert.equal((await s.call('POST', '/analyses', run('A2', []))).body.gateSource, 'project');
}));

test('a large analysis (several MB) is accepted', withServer(async s => {
  const big = Array.from({ length: 2500 }, (_, i) => fnd(`f${i}`, { description: 'x'.repeat(1500) }));
  const r = await s.call('POST', '/analyses', run('BIG', big));
  assert.equal(r.status, 201);
  assert.equal((await s.call('GET', '/projects/p/findings')).body.length, 2500);
}));

test('trend points count only active findings, and projects with only resolved findings still count', withServer(async s => {
  await s.call('POST', '/analyses', run('A1', [fnd('a', { severity: 'CRITICAL' }), fnd('b', { severity: 'LOW' })]));
  await s.call('POST', '/analyses', run('B1', [fnd('a')], { projectKey: 'q' }));
  await s.call('POST', '/analyses', run('A2', [fnd('a', { severity: 'CRITICAL' })]));
  const last = (await s.call('GET', '/history')).body.points.pop();
  assert.equal(last.total, 2);
  assert.deepEqual(last.counts, { CRITICAL: 1, HIGH: 1, MEDIUM: 0, LOW: 0, INFO: 0 });
  assert.deepEqual(last.byType, { SAST: 2 });
  assert.equal(last.projects, 2);
}));
