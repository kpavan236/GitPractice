'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

// The Studio project depends on exactly these names. A rename or removal here must fail this test, not the Studio at 2 a.m.
const EXPECTED = [
  'ENGINE_FALLBACKS', 'ENGINE_SCHEMA', 'MIN_LOADER', 'PILLARS', 'SEVERITIES', 'STATUSES',
  'buildPacks', 'callerKey', 'canonical', 'coverage', 'createAudit', 'createBlobStore', 'createPool', 'createReleases',
  'createRulesRepo', 'decodePack', 'encodePack', 'engineOf', 'isEmptyMatching', 'loadLanguages', 'migrate', 'rateLimit',
  'seedLanguages', 'sha256', 'signManifest', 'stable', 'testRule', 'tx', 'validateRule', 'verifyManifest',
];

test('the library entry exports exactly the names the Studio uses', () => {
  const lib = require('../src/index');
  assert.deepEqual(Object.keys(lib).sort(), EXPECTED);
  for (const name of EXPECTED) assert.notEqual(lib[name], undefined, name);
});

test('the package exposes only the library and testing entries', () => {
  const pkg = require('../package.json');
  assert.equal(pkg.main, 'src/index.js');
  assert.deepEqual(Object.keys(pkg.exports).sort(), ['.', './package.json', './testing']);
  assert.equal(pkg.exports['.'], './src/index.js');
  assert.equal(pkg.exports['./testing'], './src/testing.js');
});

test('the testing entry exports the fresh-database helper', () => {
  assert.equal(typeof require('../src/testing').freshDb, 'function');
});
