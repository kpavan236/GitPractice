'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createApp } = require('../src/api');

async function start() {
  const db = openDb();
  const server = createApp({ db }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}
const fnd = (fp, extra = {}) => ({ fingerprint: fp, id: `F-${fp}`, type: 'SAST', severity: 'HIGH', status: 'OPEN', isNewCode: false, file: 'a.js', startLine: 1, ...extra });
const analysis = (id, findings, extra = {}) => ({
  analysisId: id, projectKey: 'p', profile: { id: 'default', version: 1 }, ruleSetVersion: 'default@1',
  scannerVersion: '2.0.1', analyzerVersion: '0.1.0', usedCache: false, mode: 'full',
  startedAt: '2026-10-01T00:00:00Z', completedAt: '2026-10-01T00:00:05Z',
  coverage: [{ type: 'SAST', analysed: true }], newCodeAvailable: true, findings, ...extra,
});
const withServer = fn => async () => { const s = await start(); try { await fn(s); } finally { s.close(); } };

test('record stores the run, merges findings and returns the gate verdict', withServer(async s => {
  const r = await s.call('POST', '/analyses', analysis('S1:p', [fnd('a'), fnd('b', { severity: 'LOW' })]));
  assert.equal(r.status, 201);
  assert.equal(r.body.analysisId, 'S1:p');
  assert.equal(r.body.gate.status, 'PASSED');
  assert.deepEqual(r.body.counts, { CRITICAL: 0, HIGH: 1, MEDIUM: 0, LOW: 1, INFO: 0 });

  const run = (await s.call('GET', '/analyses/S1:p')).body;
  assert.equal(run.status, 'COMPLETED');
  assert.equal(run.ruleSetVersion, 'default@1');
  assert.equal(run.gateStatus, 'PASSED');
  assert.equal((await s.call('GET', '/projects/p/findings')).body.length, 2);
  assert.equal((await s.call('GET', '/projects/p/analyses')).body.length, 1);
}));

test('a new critical finding fails the default gate; a project gate changes the verdict', withServer(async s => {
  const crit = [fnd('c', { severity: 'CRITICAL', isNewCode: true })];
  assert.equal((await s.call('POST', '/analyses', analysis('S1:p', crit))).body.gate.status, 'FAILED');
  assert.equal((await s.call('PUT', '/projects/p/gate', { name: 'lenient', conditions: [{ metric: 'secrets', scope: 'OVERALL', operator: 'GT', threshold: 0 }] })).status, 200);
  assert.equal((await s.call('POST', '/analyses', analysis('S2:p', crit))).body.gate.status, 'PASSED');
  assert.equal((await s.call('PUT', '/projects/p/gate', { conditions: [] })).status, 400);
  assert.equal((await s.call('GET', '/projects/p/gate')).body.source, 'project');
  await s.call('DELETE', '/projects/p/gate');
  assert.equal((await s.call('GET', '/projects/p/gate')).body.source, 'default');
}));

test('suppression survives the next analysis; a resolved finding that returns is REOPENED', withServer(async s => {
  await s.call('POST', '/analyses', analysis('S1:p', [fnd('a'), fnd('b')]));
  assert.equal((await s.call('POST', '/projects/p/findings/a/status', { status: 'SUPPRESSED', reason: 'accepted' })).status, 200);
  await s.call('POST', '/analyses', analysis('S2:p', [fnd('a')]));
  const by = Object.fromEntries((await s.call('GET', '/projects/p/findings?status=all')).body.map(x => [x.fingerprint, x.status]));
  assert.deepEqual(by, { a: 'SUPPRESSED', b: 'RESOLVED' });
  await s.call('POST', '/analyses', analysis('S3:p', [fnd('a'), fnd('b')]));
  const again = Object.fromEntries((await s.call('GET', '/projects/p/findings?status=all')).body.map(x => [x.fingerprint, x.status]));
  assert.deepEqual(again, { a: 'SUPPRESSED', b: 'REOPENED' });
}));

test('uncovered types are not resolved by an analysis that did not cover them', withServer(async s => {
  await s.call('POST', '/analyses', analysis('S1:p', [fnd('a')]));
  await s.call('POST', '/analyses', analysis('S2:p', [], { coverage: [{ type: 'SAST', analysed: false }] }));
  assert.equal((await s.call('GET', '/projects/p/findings')).body.length, 1);
}));

test('suppress needs a reason; unknown findings and bad statuses are rejected', withServer(async s => {
  await s.call('POST', '/analyses', analysis('S1:p', [fnd('a')]));
  assert.equal((await s.call('POST', '/projects/p/findings/a/status', { status: 'SUPPRESSED' })).status, 400);
  assert.equal((await s.call('POST', '/projects/p/findings/a/status', { status: 'WEIRD' })).status, 400);
  assert.equal((await s.call('POST', '/projects/p/findings/zzz/status', { status: 'OPEN' })).status, 404);
}));

test('the same analysis id twice is a 409 and is not double counted', withServer(async s => {
  const body = analysis('S1:p', [fnd('a')]);
  assert.equal((await s.call('POST', '/analyses', body)).status, 201);
  assert.equal((await s.call('POST', '/analyses', body)).status, 409);
  assert.equal((await s.call('GET', '/history')).body.points.length, 1);
}));

test('a malformed payload is a 400 and writes nothing', withServer(async s => {
  for (const bad of [{}, { ...analysis('X', []), analysisId: undefined }, { ...analysis('X', []), findings: 'nope' }, { ...analysis('X', [fnd(undefined)]) }]) {
    assert.equal((await s.call('POST', '/analyses', bad)).status, 400, JSON.stringify(bad).slice(0, 60));
  }
  assert.equal((await s.call('GET', '/projects/p/analyses')).body.length, 0);
  assert.equal((await s.call('GET', '/history')).body.points.length, 0);
}));

test('history has a point per analysis and reports the deltas', withServer(async s => {
  await s.call('POST', '/analyses', analysis('S1:p', [fnd('a'), fnd('b')]));
  await s.call('POST', '/analyses', analysis('S2:p', [fnd('a')]));
  const h = (await s.call('GET', '/history')).body;
  assert.equal(h.points.length, 2);
  assert.deepEqual(h.points.map(p => p.total), [2, 1]);
  assert.equal(h.sinceLastScan.total, -1);
  assert.equal(h.sinceFirst.total, -1);
}));

test('projects do not see each other\'s findings', withServer(async s => {
  await s.call('POST', '/analyses', analysis('S1:p', [fnd('a')]));
  await s.call('POST', '/analyses', analysis('S1:q', [fnd('a')], { projectKey: 'q' }));
  await s.call('POST', '/analyses', analysis('S2:p', [], {}));
  assert.equal((await s.call('GET', '/projects/q/findings')).body.length, 1);
  assert.equal((await s.call('GET', '/projects/p/findings')).body.length, 0);
}));
