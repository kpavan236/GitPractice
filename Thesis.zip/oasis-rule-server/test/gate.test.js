'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { evaluateGate, validateGate, createGatesRepo, DEFAULT_GATE } = require('../src/gate');

const fnd = (extra = {}) => ({ type: 'SAST', severity: 'LOW', status: 'OPEN', isNewCode: false, ...extra });
const covered = [{ type: 'SAST', analysed: true }];

test('the default gate passes when nothing new is critical', () => {
  const r = evaluateGate({ findings: [fnd(), fnd({ severity: 'HIGH' })], coverage: covered });
  assert.equal(r.status, 'PASSED');
  assert.equal(r.blocking, false);
});

test('a new CRITICAL finding fails the default gate and names why', () => {
  const r = evaluateGate({ findings: [fnd({ severity: 'CRITICAL', isNewCode: true })], coverage: covered });
  assert.equal(r.status, 'FAILED');
  assert.equal(r.blocking, true);
  assert.match(r.reason, /critical_issues in new code is 1, which breaches > 0/);
});

test('an old critical finding does not fail a NEW_CODE condition but does fail OVERALL', () => {
  const old = [fnd({ severity: 'CRITICAL' })];
  assert.equal(evaluateGate({ findings: old, coverage: covered }).status, 'PASSED');
  const gate = { name: 'g', conditions: [{ metric: 'critical_issues', scope: 'OVERALL', operator: 'GT', threshold: 0 }] };
  assert.equal(evaluateGate({ findings: old, coverage: covered, gate }).status, 'FAILED');
});

test('inactive findings are ignored', () => {
  const r = evaluateGate({ findings: [fnd({ severity: 'CRITICAL', isNewCode: true, status: 'SUPPRESSED' })], coverage: covered });
  assert.equal(r.status, 'PASSED');
});

test('a WARN-level coverage gap warns instead of failing', () => {
  const r = evaluateGate({ findings: [], coverage: [{ type: 'SAST', analysed: false }] });
  assert.equal(r.status, 'WARN');
  assert.equal(r.blocking, false);
  assert.equal(r.warnCount, 1);
});

test('NEW_CODE conditions without a diff are NOT_EVALUATED and fail the gate', () => {
  const r = evaluateGate({ findings: [], coverage: covered, newCodeAvailable: false });
  assert.equal(r.status, 'FAILED');
  assert.ok(r.conditions.some(c => c.status === 'NOT_EVALUATED'));
});

test('a gate error is never papered over with the default', () => {
  const r = evaluateGate({ findings: [], gate: null, gateError: 'unknown metric "x"' });
  assert.equal(r.status, 'NOT_EVALUATED');
  assert.equal(r.reason, 'unknown metric "x"');
  assert.equal(r.blocking, true);
});

test('a condition can filter by severity and use any operator', () => {
  const gate = { name: 'g', conditions: [{ metric: 'vulnerabilities', scope: 'OVERALL', operator: 'GTE', threshold: 2, severity: 'HIGH' }] };
  const two = [fnd({ severity: 'HIGH' }), fnd({ severity: 'HIGH' }), fnd({ severity: 'LOW' })];
  assert.equal(evaluateGate({ findings: two, coverage: covered, gate }).status, 'FAILED');
  assert.equal(evaluateGate({ findings: two.slice(1), coverage: covered, gate }).status, 'PASSED');
});

test('validateGate rejects each malformed shape with a specific message', () => {
  assert.equal(validateGate(DEFAULT_GATE), null);
  assert.equal(validateGate({}), 'no conditions defined');
  assert.equal(validateGate({ conditions: [] }), 'no conditions defined');
  assert.equal(validateGate({ conditions: [{ metric: 'nope', operator: 'GT', threshold: 0 }] }), 'unknown metric "nope"');
  assert.equal(validateGate({ conditions: [{ metric: 'secrets', operator: 'XX', threshold: 0 }] }), 'unknown operator "XX"');
  assert.equal(validateGate({ conditions: [{ metric: 'secrets', operator: 'GT', threshold: '0' }] }), 'secrets: threshold must be a number');
});

test('gates repo: default until set, validated on set, clearable', () => {
  const gates = createGatesRepo(openDb());
  assert.deepEqual(gates.get('p'), { gate: DEFAULT_GATE, source: 'default', error: null });
  const mine = { name: 'strict', conditions: [{ metric: 'secrets', scope: 'OVERALL', operator: 'GT', threshold: 0 }] };
  gates.set('p', mine);
  assert.deepEqual(gates.get('p'), { gate: mine, source: 'project', error: null });
  assert.throws(() => gates.set('p', { conditions: [] }), e => e.code === 'INVALID');
  gates.clear('p');
  assert.equal(gates.get('p').source, 'default');
});
