'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { engineOf, ENGINE_SCHEMA } = require('../src/engines');

test('engineOf classifies the four rule shapes', () => {
  assert.equal(engineOf({ query: '(x)' }), 'ast');
  assert.equal(engineOf({ pattern: 'a', engine: 'secret' }), 'secret');
  assert.equal(engineOf({ engine: 'iac-policy', definition: {} }), 'iac-policy');
  assert.equal(engineOf({ pattern: 'a' }), 'pattern');
  assert.equal(engineOf({}), null);
});

test('every engine has schema version 1', () => {
  assert.deepEqual(ENGINE_SCHEMA, { ast: 1, pattern: 1, 'iac-policy': 1, secret: 1 });
});
