'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');

test('openDb creates the schema', () => {
  const db = openDb();
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name);
  for (const t of ['profile_rules', 'profiles', 'projects', 'rules']) assert.ok(tables.includes(t), t);
});

test('openDb is safe to call on an existing database file', () => {
  const db = openDb();
  assert.doesNotThrow(() => require('../src/db').migrate(db));
});

test('migrate upgrades a database created before the findings and history columns existed', () => {
  const { DatabaseSync } = require('node:sqlite');
  const { migrate } = require('../src/db');
  const old = new DatabaseSync(':memory:');
  old.exec(`CREATE TABLE findings (project_key TEXT NOT NULL, fingerprint TEXT NOT NULL, id TEXT, status TEXT NOT NULL,
            body TEXT NOT NULL, first_seen_at INTEGER, last_seen_at INTEGER, PRIMARY KEY (project_key, fingerprint));
            CREATE TABLE history (seq INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL, analysis_id TEXT, total INTEGER NOT NULL,
            counts TEXT NOT NULL, by_type TEXT NOT NULL, projects INTEGER NOT NULL);`);
  old.prepare('INSERT INTO findings (project_key, fingerprint, id, status, body) VALUES (?, ?, ?, ?, ?)')
    .run('p', 'fp', 'F-1', 'OPEN', JSON.stringify({ fingerprint: 'fp', severity: 'HIGH', type: 'SAST' }));
  migrate(old);
  const row = old.prepare('SELECT severity, type FROM findings').get();
  assert.deepEqual([row.severity, row.type], ['HIGH', 'SAST'], 'existing rows are backfilled from their stored body');
  assert.ok(old.prepare('PRAGMA table_info(history)').all().some(c => c.name === 'scan_id'));
  assert.doesNotThrow(() => migrate(old), 'running it again is harmless');
});
