'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { freshDb } = require('./helpers/db');
const { loadLanguages, seedLanguages, coverage } = require('../src/languages');

const FILE = path.join(__dirname, '..', 'seed', 'languages.json');
const go = { id: 'go', name: 'Go', extensions: ['.go'], engineFallback: 'pattern', grammar: null, licenceNote: 'x' };
const java = { id: 'java', name: 'Java', extensions: ['.java'], engineFallback: 'pattern', grammar: { wasm: 'tree-sitter-java.wasm' }, licenceNote: 'x' };

test('the registry lists every language in the target table, once each', () => {
  const ids = loadLanguages(FILE).map(l => l.id);
  const target = ['abap','ansible','apex','azure-pipelines','arm','c','cpp','cloudformation','cobol','csharp','css','dart','dockerfile','flex','github-actions','go','gosu','groovy','html','iac','java','javascript','jcl','json','kotlin','kubernetes','dataweave','objectivec','php','pli','plsql','powershell','python','r','rpg','ruby','rust','scala','secrets','shell','swift','terraform','typescript','tsql','vbnet','vb6','xml','yaml'];
  assert.deepEqual([...ids].sort(), [...target].sort());
});

test('registry entries are well formed', () => {
  const list = loadLanguages(FILE);
  assert.equal(new Set(list.map(l => l.id)).size, list.length);
  for (const l of list) {
    assert.ok(l.name, `${l.id}: name`);
    assert.ok(l.extensions.length > 0, `${l.id}: extensions`);
    for (const e of l.extensions) assert.ok(e.startsWith('.'), `${l.id}: extension ${e} must start with '.'`);
    assert.ok(['pattern', 'iac-policy', 'ast'].includes(l.engineFallback), `${l.id}: engineFallback`);
    assert.ok(l.grammar === null || (typeof l.grammar.wasm === 'string' && l.grammar.wasm.endsWith('.wasm')), `${l.id}: grammar`);
    assert.ok(l.licenceNote, `${l.id}: licenceNote`);
  }
  const withGrammar = list.filter(l => l.grammar).map(l => l.id).sort();
  assert.deepEqual(withGrammar, ['java', 'javascript', 'python', 'typescript']);
  assert.equal(list.find(l => l.id === 'iac').engineFallback, 'iac-policy');
});

test('every language used by the seed rules is in the registry', () => {
  const fs = require('node:fs');
  const ids = new Set(loadLanguages(FILE).map(l => l.id));
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith('.json') ? [path.join(d, e.name)] : []);
  for (const f of walk(path.join(__dirname, '..', 'seed', 'rules'))) {
    const rule = JSON.parse(fs.readFileSync(f, 'utf8'));
    if (rule.language) assert.ok(ids.has(rule.language), `${f}: ${rule.language} is not in the registry`);
  }
});

test('coverage flags a language with no active rule', async () => {
  const db = await freshDb();
  try {
    await seedLanguages(db.pool, [go]);
    const [row] = await coverage(db.pool);
    assert.equal(row.ruleCount, 0);
    assert.equal(row.meetsMinimum, false);
  } finally { await db.close(); }
});

test('coverage counts active rules by pillar and ignores drafts', async () => {
  const db = await freshDb();
  try {
    await seedLanguages(db.pool, [go, java]);
    const ins = (id, lang, pillar, status) => db.pool.query(
      `INSERT INTO rule (rule_id, language, engine, pillar, severity, status, body) VALUES ($1,$2,'pattern',$3,'HIGH',$4,'{}')`, [id, lang, pillar, status]);
    await ins('go-a', 'go', 'security', 'active');
    await ins('go-b', 'go', 'code-quality', 'active');
    await ins('go-c', 'go', 'security', 'draft');
    const rows = await coverage(db.pool);
    const g = rows.find(r => r.language === 'go');
    assert.equal(g.ruleCount, 2);
    assert.equal(g.meetsMinimum, true);
    assert.deepEqual(g.pillars, { security: 1, reliability: 0, maintainability: 0, 'code-quality': 1 });
    assert.equal(g.grammar, false);
    const j = rows.find(r => r.language === 'java');
    assert.equal(j.ruleCount, 0);
    assert.equal(j.grammar, true);
  } finally { await db.close(); }
});

test('seedLanguages is idempotent and updates a changed entry', async () => {
  const db = await freshDb();
  try {
    const n = async () => Number((await db.pool.query('SELECT count(*) FROM language')).rows[0].count);
    await seedLanguages(db.pool, [go, java]);
    await seedLanguages(db.pool, [go, java]);
    assert.equal(await n(), 2);
    await seedLanguages(db.pool, [{ ...go, name: 'Golang', extensions: ['.go', '.mod'] }]);
    assert.equal(await n(), 2);
    const { rows } = await db.pool.query("SELECT name, extensions, grammar FROM language WHERE id = 'go'");
    assert.equal(rows[0].name, 'Golang');
    assert.deepEqual(rows[0].extensions, ['.go', '.mod']);
    assert.equal(rows[0].grammar, null);
    const j = (await db.pool.query("SELECT grammar FROM language WHERE id = 'java'")).rows[0];
    assert.deepEqual(j.grammar, { wasm: 'tree-sitter-java.wasm' });
  } finally { await db.close(); }
});
