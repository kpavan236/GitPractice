'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { freshDb } = require('./helpers/db');
const { loadCentralConfig } = require('../src/central-config');
const { createCentralServices } = require('../src/central-server');
const { createCentralApp } = require('../src/central-app');

test('the public service starts with only its settings and no signing key, and has no Studio surface', async () => {
  const db = await freshDb();
  let server;
  try {
    const config = loadCentralConfig({ RULES_DATABASE_URL: db.url, PACK_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pub-')), PORT: '5999' });
    assert.deepEqual(Object.keys(config).sort(), ['allowPlainHttp', 'databaseUrl', 'packDir', 'port', 'shutdownTimeoutMs', 'tlsCertFile', 'tlsKeyFile', 'trustProxy']);
    const { blobs, releases } = createCentralServices(config, db.pool);
    const app = createCentralApp({ pool: db.pool, blobs, releases, limiter: (_q, _s, n) => n() });
    server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
    const base = `http://127.0.0.1:${server.address().port}`;
    const health = await fetch(`${base}/v1/health`);
    assert.equal(health.status, 200);
    assert.equal(health.headers.get('content-security-policy'), null, 'the public service never sent a Content-Security-Policy header');
    assert.equal((await fetch(`${base}/v1/releases/latest?channel=stable`)).status, 404);   // NO_RELEASE: the channel is empty
    for (const p of ['/', '/index.html', '/v1/studio/auth/me', '/v1/studio/rules', '/js/main.js']) {
      assert.equal((await fetch(`${base}${p}`)).status, 404, `${p} must not exist on the public service`);
    }
  } finally {
    if (server) await new Promise((r) => { server.closeAllConnections(); server.close(r); });
    await db.close();
  }
});

test('the rules database no longer carries the identity tables', async () => {
  const db = await freshDb();
  try {
    const tables = (await db.pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")).rows.map((r) => r.table_name);
    for (const gone of ['staff', 'session', 'role_permission']) assert.equal(tables.includes(gone), false, gone);
    assert.equal(tables.includes('audit'), true);
  } finally { await db.close(); }
});
