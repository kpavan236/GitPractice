'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { SOURCES } = require('../tools/ingest/sources');
const { writeAttribution } = require('../tools/ingest/attribution');

test('the licence index lists every redistributable source even when a run ingested only one', async (t) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'attr-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const gitleaks = SOURCES.find(s => s.id === 'gitleaks');
  const redistributable = SOURCES.filter(s => s.redistributable);
  const dir = await writeAttribution([gitleaks], { root, fetch: async () => 'LICENCE TEXT', all: redistributable });
  const index = fs.readFileSync(path.join(dir, 'README.md'), 'utf8');
  for (const s of redistributable) assert.match(index, new RegExp(s.name), `${s.name} is missing from the index`);
  assert.deepEqual(fs.readdirSync(dir).filter(f => /LICENSE/.test(f)), ['gitleaks-LICENSE.txt'], 'only the ingested source is re-fetched');
});
