'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDb } = require('./helpers/db');
const { createRulesRepo } = require('../src/rules/repo');

async function withRepo(fn) {
  const db = await freshDb();
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go'])");
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go'] });
    await repo.upsertSeeded({ id: 'Seeded_One', language: 'go', severity: 'HIGH', pattern: 'danger', files: ['**/*.go'] }, { origin: 'seed', actor: 'seed' });
    await fn(repo, db.pool);
  } finally { await db.close(); }
}
const who = { actor: 'ann@example.test', reason: 'tuning' };

test('updateMetadata changes severity, pillar and tags of a seeded rule that strict validation would reject', () => withRepo(async (repo, pool) => {
  await assert.rejects(() => repo.update('Seeded_One', { severity: 'LOW' }, who), { code: 'INVALID' });
  const row = await repo.updateMetadata('Seeded_One', { severity: 'LOW', pillar: 'reliability', tags: ['a', 'b'] }, who);
  assert.equal(row.version, 2);
  assert.equal(row.severity, 'LOW');
  assert.equal(row.pillar, 'reliability');
  assert.deepEqual(row.body.tags, ['a', 'b']);
  assert.equal(row.body.pattern, 'danger');
  assert.equal(row.origin, 'seed');
  const v = await pool.query('SELECT changed_by, reason FROM rule_version WHERE rule_id = $1 AND version = 2', ['Seeded_One']);
  assert.deepEqual(v.rows[0], { changed_by: who.actor, reason: who.reason });
  const a = await pool.query("SELECT actor, reason FROM audit WHERE action = 'rule.metadata'");
  assert.deepEqual(a.rows, [{ actor: who.actor, reason: who.reason }]);
}));

test('updateMetadata refuses other fields, bad values, a missing reason and a missing rule, and writes nothing', () => withRepo(async (repo, pool) => {
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { title: 'x' }, who), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { severity: 'SEVERE' }, who), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { pillar: 'speed' }, who), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { tags: 'a' }, who), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { tags: [''] }, who), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { severity: 'LOW' }, { actor: 'a', reason: ' ' }), { code: 'INVALID' });
  await assert.rejects(() => repo.updateMetadata('nope', { severity: 'LOW' }, who), { code: 'NOT_FOUND' });
  assert.equal((await repo.get('Seeded_One')).version, 1);
  assert.equal((await pool.query("SELECT count(*) FROM audit WHERE action = 'rule.metadata'")).rows[0].count, '0');
}));

test('updateMetadata with no actual change writes no new version', () => withRepo(async (repo) => {
  const row = await repo.updateMetadata('Seeded_One', { severity: 'HIGH' }, who);
  assert.equal(row.version, 1);
}));

test('updateMetadata refuses a deprecated rule', () => withRepo(async (repo) => {
  await repo.setStatus('Seeded_One', 'deprecated', who);
  await assert.rejects(() => repo.updateMetadata('Seeded_One', { severity: 'LOW' }, who), { code: 'INVALID' });
}));

test('updateMetadata leaves an active rule active (Ruling 15: metadata edits do not demote)', () => withRepo(async (repo) => {
  const row = await repo.updateMetadata('Seeded_One', { severity: 'LOW' }, who);
  assert.equal(row.status, 'active');
}));
