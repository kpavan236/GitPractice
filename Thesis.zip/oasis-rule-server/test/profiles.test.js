'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { createProfilesRepo } = require('../src/profiles');

function setup() {
  const db = openDb();
  const rules = createRulesRepo(db);
  rules.upsertSeeded({ id: 'R1', language: 'java', severity: 'HIGH', query: '(a)' }, 'builtin');
  rules.upsertSeeded({ id: 'R2', language: 'java', severity: 'LOW', pattern: 'x', files: ['**/*.java'] }, 'builtin');
  return { rules, profiles: createProfilesRepo(db, rules) };
}

test('ensureDefault activates every active rule at its authored severity', () => {
  const { profiles } = setup();
  const def = profiles.ensureDefault();
  assert.equal(def.id, 'default');
  const active = profiles.activeRules('default');
  assert.deepEqual(active.map(r => [r.ruleId, r.severity, r.engine]), [['R1', 'HIGH', 'ast'], ['R2', 'LOW', 'pattern']]);
  assert.equal(active[0].definition.query, '(a)');
});

test('ensureDefault is idempotent and keeps its version', () => {
  const { profiles } = setup();
  const v1 = profiles.ensureDefault().version;
  assert.equal(profiles.ensureDefault().version, v1);
});

test('ensureDefault picks up rules added later without touching existing overrides', () => {
  const { rules, profiles } = setup();
  profiles.ensureDefault();
  profiles.setRule('default', 'R1', { enabled: false });
  rules.upsertSeeded({ id: 'R3', language: 'java', severity: 'MEDIUM', query: '(b)' }, 'builtin');
  profiles.ensureDefault();
  assert.deepEqual(profiles.activeRules('default').map(r => r.ruleId), ['R2', 'R3']);
});

test('setRule changes enabled, severity and params and bumps the profile version', () => {
  const { profiles } = setup();
  profiles.ensureDefault();
  const before = profiles.get('default').version;
  const after = profiles.setRule('default', 'R2', { severity: 'CRITICAL', params: { max: 3 } });
  assert.equal(after.version, before + 1);
  const r2 = profiles.activeRules('default').find(r => r.ruleId === 'R2');
  assert.equal(r2.severity, 'CRITICAL');
  assert.deepEqual(r2.params, { max: 3 });
});

test('setRule validates the profile, rule and severity', () => {
  const { profiles } = setup();
  profiles.ensureDefault();
  assert.throws(() => profiles.setRule('nope', 'R1', {}), e => e.code === 'NOT_FOUND');
  assert.throws(() => profiles.setRule('default', 'ZZ', {}), e => e.code === 'NOT_FOUND');
  assert.throws(() => profiles.setRule('default', 'R1', { severity: 'SEVERE' }), e => e.code === 'INVALID');
});

test('deprecated rules are dropped from the active list', () => {
  const { rules, profiles } = setup();
  profiles.ensureDefault();
  rules.deprecate('R1');
  assert.deepEqual(profiles.activeRules('default').map(r => r.ruleId), ['R2']);
});

test('a child profile inherits and overrides its parent', () => {
  const { profiles } = setup();
  profiles.ensureDefault();
  profiles.create({ id: 'strict', name: 'Strict', parentId: 'default' });
  profiles.setRule('strict', 'R2', { enabled: false });
  profiles.setRule('strict', 'R1', { severity: 'CRITICAL' });
  const active = profiles.activeRules('strict');
  assert.deepEqual(active.map(r => [r.ruleId, r.severity]), [['R1', 'CRITICAL']]);
});

test('create rejects a duplicate name and an unknown parent', () => {
  const { profiles } = setup();
  profiles.ensureDefault();
  assert.throws(() => profiles.create({ id: 'x', name: 'Default' }), e => e.code === 'CONFLICT');
  assert.throws(() => profiles.create({ id: 'y', name: 'Y', parentId: 'ghost' }), e => e.code === 'NOT_FOUND');
});
