'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createFindingsRepo, mergeFindings } = require('../src/findings');

const f = (fp, extra = {}) => ({ fingerprint: fp, id: `F-${fp}`, type: 'SAST', severity: 'HIGH', status: 'OPEN', file: 'a.js', startLine: 1, title: 't', ...extra });
const repo = () => createFindingsRepo(openDb());
const covered = { coveredTypes: ['SAST'] };

test('new findings are inserted with first/last seen set to now', () => {
  const r = repo();
  r.merge('p', [f('a')], { ...covered, now: 100 });
  const [row] = r.list('p', { status: 'all' });
  assert.equal(row.firstSeenAt, 100);
  assert.equal(row.lastSeenAt, 100);
  assert.equal(row.status, 'OPEN');
});

test('a rescan refreshes facts but keeps id and first seen', () => {
  const r = repo();
  r.merge('p', [f('a')], { ...covered, now: 100 });
  r.merge('p', [f('a', { id: 'NEW', startLine: 9 })], { ...covered, now: 200 });
  const [row] = r.list('p', { status: 'all' });
  assert.equal(row.id, 'F-a');
  assert.equal(row.startLine, 9);
  assert.equal(row.firstSeenAt, 100);
  assert.equal(row.lastSeenAt, 200);
});

test('a triage decision outlives a rescan that still reports the finding', () => {
  const r = repo();
  r.merge('p', [f('a'), f('b')], { ...covered, now: 1 });
  r.setStatus('p', 'a', { status: 'SUPPRESSED', suppression: { reason: 'known' } });
  r.setStatus('p', 'b', { status: 'FALSE_POSITIVE', notes: 'n' });
  r.merge('p', [f('a'), f('b')], { ...covered, now: 2 });
  const rows = Object.fromEntries(r.list('p', { status: 'all' }).map(x => [x.fingerprint, x]));
  assert.equal(rows.a.status, 'SUPPRESSED');
  assert.deepEqual(rows.a.suppression, { reason: 'known' });
  assert.equal(rows.b.status, 'FALSE_POSITIVE');
  assert.equal(rows.b.notes, 'n');
});

test('absent from a covered scan means RESOLVED; coming back means REOPENED', () => {
  const r = repo();
  r.merge('p', [f('a')], { ...covered, now: 1 });
  r.merge('p', [], { ...covered, now: 2 });
  let [row] = r.list('p', { status: 'all' });
  assert.equal(row.status, 'RESOLVED');
  assert.equal(row.resolvedAt, 2);
  assert.equal(row.resolvedBy, 'NOT_DETECTED');
  r.merge('p', [f('a')], { ...covered, now: 3 });
  [row] = r.list('p', { status: 'all' });
  assert.equal(row.status, 'REOPENED');
});

test('a type no scanner covered is left alone; suppressed findings are never auto-resolved', () => {
  const r = repo();
  r.merge('p', [f('a'), f('s', { type: 'SECRET' }), f('x')], { coveredTypes: ['SAST', 'SECRET'], now: 1 });
  r.setStatus('p', 'x', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  r.merge('p', [], { coveredTypes: ['SAST'], now: 2 });
  const by = Object.fromEntries(r.list('p', { status: 'all' }).map(x => [x.fingerprint, x.status]));
  assert.deepEqual(by, { a: 'RESOLVED', s: 'OPEN', x: 'SUPPRESSED' });
});

test('projects are isolated even with the same fingerprint', () => {
  const r = repo();
  r.merge('p1', [f('a')], { ...covered, now: 1 });
  r.merge('p2', [f('a')], { ...covered, now: 1 });
  r.merge('p1', [], { ...covered, now: 2 });
  assert.equal(r.list('p1', { status: 'all' })[0].status, 'RESOLVED');
  assert.equal(r.list('p2', { status: 'all' })[0].status, 'OPEN');
});

test('setStatus validates and REOPENED clears the suppression', () => {
  const r = repo();
  r.merge('p', [f('a')], { ...covered, now: 1 });
  assert.throws(() => r.setStatus('p', 'a', { status: 'WEIRD' }), e => e.code === 'INVALID');
  assert.throws(() => r.setStatus('p', 'zzz', { status: 'OPEN' }), e => e.code === 'NOT_FOUND');
  r.setStatus('p', 'a', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  const back = r.setStatus('p', 'a', { status: 'REOPENED' });
  assert.equal(back.status, 'REOPENED');
  assert.equal(back.suppression, null);
});

test('list(active) returns only active findings, most severe first', () => {
  const r = repo();
  r.merge('p', [f('a', { severity: 'LOW' }), f('b', { severity: 'CRITICAL' }), f('c', { severity: 'HIGH' })], { ...covered, now: 1 });
  r.setStatus('p', 'c', { status: 'SUPPRESSED', suppression: { reason: 'r' } });
  assert.deepEqual(r.list('p', { status: 'active' }).map(x => x.fingerprint), ['b', 'a']);
});

test('mergeFindings is a pure function of stored, incoming and options', () => {
  const out = mergeFindings([f('a')], [f('a')], { coveredTypes: ['SAST'], now: 5 });
  assert.equal(out[0].lastSeenAt, 5);
});
