'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const engine = require('oasis-analyzer/src/ast/engine');
const { scanSource } = require('oasis-analyzer/src/scanners/sast-ast');
const { scanContent, compileRule } = require('oasis-analyzer/src/scanners/pattern-sast');

// The quality bar for every rule this server hands to scanners. It replaces what
// iready-oasis checked at build time (tools/build-rules.js refused to sign a bundle
// containing a rule that does not compile) and in its rule-corpus test (a rule must
// detect its own example and stay silent on the fix). A rule that fails here would
// otherwise be inert on a developer's laptop: it looks present and finds nothing.

const SEED = path.join(__dirname, '..', 'seed', 'rules');

function* jsonFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* jsonFiles(full);
    else if (entry.name.endsWith('.json')) yield full;
  }
}

const RULES = [...jsonFiles(SEED)].map(file => ({ ...JSON.parse(fs.readFileSync(file, 'utf8')), _file: path.relative(SEED, file) }));
const AUTHORED = RULES.filter(r => (r.query || r.pattern) && !r.provenance && r.example);
const PATTERN_RULES = RULES.filter(r => r.pattern).map(compileRule).filter(Boolean);

test('there are rules, with unique ids and the required fields', () => {
  assert.ok(RULES.length >= 296, `expected at least the 296 shipped rules, got ${RULES.length}`);
  assert.equal(new Set(RULES.map(r => r.id)).size, RULES.length, 'rule ids must be unique');
  for (const r of RULES) {
    assert.ok(r.id && r.language && r.severity, `${r._file}: id, language and severity are required`);
    assert.ok(r.query || r.pattern || r.definition, `${r.id}: needs a query, pattern or definition`);
  }
});

test('every rule compiles (the check that used to gate signing the bundle)', async () => {
  const problems = [];
  for (const r of RULES) {
    if (r.query) {
      if (!(await engine.compileQuery(r.language, r.query))) problems.push(`${r.id}: query does not compile for ${r.language}`);
    } else if (r.pattern && r.engine === 'secret') {
      try { new RegExp(r.pattern, r.patternFlags || ''); } catch (e) { problems.push(`${r.id}: secret pattern does not compile - ${e.message}`); }
    } else if (r.pattern) {
      if (!compileRule(r)) problems.push(`${r.id}: pattern does not compile, or the files glob is missing`);
      else if (new RegExp(r.pattern).test('')) problems.push(`${r.id}: pattern matches the empty string`);
    }
  }
  assert.deepEqual(problems, []);
});

test('every authored rule detects its own vulnerable example and is silent on the fix', async () => {
  const problems = [];
  for (const r of AUTHORED) {
    for (const [label, source, expected] of [['vulnerable', r.example.vulnerable, true], ['fixed', r.example.fixed, false]]) {
      const findings = r.query
        ? await scanSource(source, r.example.file, 'repo', RULES)
        : scanContent(source, r.example.file, 'repo', PATTERN_RULES);
      const hit = findings.some(f => f.detections[0].ruleId === r.id);
      if (hit !== expected) problems.push(`${r.id}: ${expected ? 'missed its vulnerable example' : 'fired on its own fix'} (${label})`);
    }
  }
  assert.deepEqual(problems, []);
  assert.ok(AUTHORED.length >= 29, `expected the authored rules, got ${AUTHORED.length}`);
});

test('every language in the registry has at least one rule', () => {
  const registry = JSON.parse(fs.readFileSync(path.join(SEED, '..', 'languages.json'), 'utf8')).map(l => l.id);
  const covered = new Set(RULES.map(r => r.language));
  assert.deepEqual(registry.filter(l => !covered.has(l)), []);
  assert.deepEqual([...covered].filter(l => !registry.includes(l)), [], 'rules use a language that is not in the registry');
});

test('vendored rules name their source and licence', () => {
  for (const r of RULES.filter(x => x.provenance)) {
    assert.ok(r.provenance.source, `${r.id}: provenance.source`);
    assert.ok(r.provenance.license, `${r.id}: provenance.license`);
  }
});
