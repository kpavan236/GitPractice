'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { validateRule, engineOf } = require('../src/model/rule');

const languages = ['go', 'dockerfile'];
const good = {
  id: 'go-insecure-skip-verify', language: 'go', pillar: 'security', severity: 'HIGH', type: 'SAST',
  title: 'TLS verification disabled', description: 'InsecureSkipVerify turns off certificate checks.',
  files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
  example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
};

test('a complete pattern rule is valid and classified as pattern', () => {
  assert.equal(validateRule(good, { languages }), null);
  assert.equal(engineOf(good), 'pattern');
});

for (const [name, patch, message] of [
  ['unknown language', { language: 'cobolt' }, /language/],
  ['bad pillar', { pillar: 'style' }, /pillar/],
  ['bad severity', { severity: 'SEVERE' }, /severity/],
  ['no fixture', { example: undefined }, /example/],
  ['empty fixed', { example: { file: 'a.go', vulnerable: 'x', fixed: '' } }, /example/],
  ['no files glob', { files: undefined }, /files/],
  ['regex does not compile', { pattern: '(' }, /compile/],
  ['matches the empty string', { pattern: 'a*' }, /empty string/],
  ['regex too long', { pattern: 'a'.repeat(501) }, /500/],
  ['bad id', { id: 'Go Rule' }, /lowercase/],
  ['missing title', { title: '' }, /title/],
  ['missing description', { description: undefined }, /description/],
  ['engine that cannot be determined', { pattern: undefined }, /cannot determine engine/],
  ['empty files array', { files: [] }, /files/],
  ['secret engine with an empty-matching pattern', { engine: 'secret', pattern: 'a*' }, /empty string/],
  ['secret engine with a 900-char pattern', { engine: 'secret', pattern: 'a'.repeat(900) }, /500/],
  ['iac-policy engine with an empty-matching pattern', { engine: 'iac-policy', pattern: 'a*' }, /empty string/],
  ['a query and an empty-matching pattern', { query: '(x) @y', pattern: 'a*' }, /empty string/],
  ['empty-matching pattern under flags', { pattern: '^', patternFlags: 'm' }, /empty string/],
  ['bad pattern flags', { patternFlags: 'zz' }, /compile/],
  ['unknown engine', { engine: 'foo' }, /engine/],
  ['array id', { id: ['ok-id'] }, /id/],
  ['numeric id', { id: 5 }, /id/],
  ['object pattern', { pattern: {} }, /pattern/],
  ['numeric pattern', { pattern: 5 }, /pattern/],
  ['numeric file entry', { files: [1] }, /files/],
  ['empty-string file entry', { files: [''] }, /files/],
  ['non-array files', { files: '**/*.go' }, /files/],
  ['object title', { title: {} }, /title/],
  ['numeric example.file', { example: { file: 5, vulnerable: 'x', fixed: 'y' } }, /example/],
  ['unknown status', { status: 'live' }, /status/],
]) {
  test(`refuses a rule with ${name}`, () => {
    assert.match(validateRule({ ...good, ...patch }, { languages }), message);
  });
}

test('a pattern of exactly 500 characters is valid, 501 is refused', () => {
  assert.equal(validateRule({ ...good, pattern: 'a'.repeat(500) }, { languages }), null);
  assert.match(validateRule({ ...good, pattern: 'a'.repeat(501) }, { languages }), /500/);
});

test('a known status is accepted', () => {
  assert.equal(validateRule({ ...good, status: 'draft' }, { languages }), null);
});

test('calling without options does not throw', () => {
  assert.doesNotThrow(() => validateRule(good));
  assert.match(validateRule(good), /language/);
});
