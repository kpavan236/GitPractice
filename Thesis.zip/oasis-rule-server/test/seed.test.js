'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDb } = require('../src/db');
const { createRulesRepo } = require('../src/rules');
const { seedFromDir } = require('../src/seed');

function fixtureDir() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'seed-'));
  fs.mkdirSync(path.join(dir, 'java'));
  fs.mkdirSync(path.join(dir, 'vendor', 'gitleaks'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'vendor', 'banned'), { recursive: true });
  const w = (p, o) => fs.writeFileSync(path.join(dir, p), JSON.stringify(o));
  w('java/a.json', { id: 'J-1', language: 'java', severity: 'LOW', query: '(x)' });
  w('vendor/gitleaks/g.json', { id: 'G-1', language: 'secrets', severity: 'HIGH', engine: 'secret', pattern: 'abc', provenance: { source: 'gitleaks' } });
  w('vendor/banned/b.json', { id: 'B-1', language: 'iac', severity: 'LOW', pattern: 'q', provenance: { source: 'banned' } });
  return dir;
}

test('seedFromDir imports recursively, tags origin, and excludes non-allowed sources', () => {
  const repo = createRulesRepo(openDb());
  const res = seedFromDir(repo, fixtureDir(), { allowSources: ['gitleaks'] });
  assert.deepEqual(res, { created: 2, updated: 0, unchanged: 0, excluded: 1 });
  assert.equal(repo.get('J-1').origin, 'builtin');
  assert.equal(repo.get('G-1').origin, 'vendor');
  assert.equal(repo.get('B-1'), null);
});

test('seeding twice is idempotent', () => {
  const repo = createRulesRepo(openDb());
  const dir = fixtureDir();
  seedFromDir(repo, dir, { allowSources: ['gitleaks'] });
  const res = seedFromDir(repo, dir, { allowSources: ['gitleaks'] });
  assert.deepEqual(res, { created: 0, updated: 0, unchanged: 2, excluded: 1 });
  assert.equal(repo.get('J-1').version, 1);
});

test('a malformed rule file aborts the seed with the file name', () => {
  const dir = fixtureDir();
  fs.writeFileSync(path.join(dir, 'java', 'broken.json'), '{nope');
  assert.throws(() => seedFromDir(createRulesRepo(openDb()), dir, {}), /broken\.json/);
});
