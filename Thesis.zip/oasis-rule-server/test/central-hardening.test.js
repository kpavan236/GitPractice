'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createCentralApp } = require('../src/central-app');
const { createShutdown } = require('../src/central-server');

const pass = (_q, _s, n) => n();
const okPool = { query: async () => ({ rows: [] }) };

async function serve(opts) {
  const logs = [];
  const app = createCentralApp({ limiter: pass, releases: {}, blobs: {}, log: (e) => logs.push(e), ...opts });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  return { logs, base: `http://127.0.0.1:${server.address().port}`, close: () => new Promise((r) => { server.closeAllConnections(); server.close(r); }) };
}

test('responses carry Referrer-Policy, and HSTS only when TLS is on', async () => {
  const plain = await serve({ pool: okPool });
  const secure = await serve({ pool: okPool, tls: true });
  try {
    const a = await fetch(`${plain.base}/v1/health`);
    const b = await fetch(`${secure.base}/v1/health`);
    assert.equal(a.headers.get('referrer-policy'), 'no-referrer');
    assert.equal(a.headers.get('strict-transport-security'), null);
    assert.match(b.headers.get('strict-transport-security'), /max-age=/);
  } finally { await plain.close(); await secure.close(); }
});

test('/v1/ready is 200 when the database and PACK_DIR work, 503 otherwise', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ready-'));
  const good = await serve({ pool: okPool, packDir: dir });
  const noDb = await serve({ pool: { query: async () => { throw new Error('down'); } }, packDir: dir });
  const noDir = await serve({ pool: okPool, packDir: path.join(dir, 'missing') });
  try {
    const g = await fetch(`${good.base}/v1/ready`);
    assert.equal(g.status, 200);
    assert.deepEqual((await g.json()).checks, { database: true, packDir: true });
    assert.equal((await fetch(`${noDb.base}/v1/ready`)).status, 503);
    const d = await fetch(`${noDir.base}/v1/ready`);
    assert.equal(d.status, 503);
    assert.deepEqual((await d.json()).checks, { database: true, packDir: false });
  } finally { await good.close(); await noDb.close(); await noDir.close(); }
});

test('request logs are one-line JSON with method, path, status, ms and nothing else sensitive', async () => {
  const s = await serve({ pool: okPool });
  try {
    await fetch(`${s.base}/v1/health?token=secret-value`);
    await new Promise((r) => setImmediate(r));
    const line = s.logs.find((e) => e.msg === 'request');
    assert.deepEqual(Object.keys(line).sort(), ['level', 'method', 'ms', 'msg', 'path', 'status']);
    assert.equal(line.path, '/v1/health');
    assert.equal(line.status, 200);
    assert.equal(JSON.stringify(s.logs).includes('secret-value'), false);
    assert.equal(JSON.stringify(s.logs).includes('127.0.0.1'), false);
  } finally { await s.close(); }
});

test('shutdown drains, ends the pool and exits 0', async () => {
  const server = http.createServer((_q, r) => r.end('ok'));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  let ended = 0; let code;
  const shutdown = createShutdown({ server, pool: { end: async () => { ended++; } }, timeoutMs: 1000, exit: (c) => { code = c; } });
  await shutdown('SIGTERM');
  await shutdown('SIGTERM');
  assert.equal(ended, 1);
  assert.equal(code, 0);
});

test('shutdown force-closes a stuck connection after the timeout and exits 1', async () => {
  const server = http.createServer(() => { /* never answers */ });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const req = http.get({ host: '127.0.0.1', port: server.address().port }).on('error', () => {});
  await new Promise((r) => server.once('connection', r));
  await new Promise((r) => setTimeout(r, 50));
  let code;
  await createShutdown({ server, pool: null, timeoutMs: 100, exit: (c) => { code = c; } })('SIGINT');
  req.destroy();
  assert.equal(code, 1);
});

test('/v1/health is liveness only: 200 even when the database is down', async () => {
  const badPool = { query: async () => { throw Object.assign(new Error('down'), { code: 'ECONNREFUSED' }); } };
  const s = await serve({ pool: badPool });
  try {
    const r = await fetch(`${s.base}/v1/health`);
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { status: 'ok' });
  } finally { await s.close(); }
});
