'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { freshDb } = require('./helpers/db');
const { seedCentral, withPillar } = require('../scripts/seed-central');
const { createRulesRepo } = require('../src/rules/repo');
const { coverage } = require('../src/languages');
const { SOURCES, redistributableIds } = require('../tools/ingest/sources');

const baseRule = {
  id: 'go-temp-rule', language: 'go', type: 'SAST', pillar: 'reliability', severity: 'LOW', files: ['**/*.go'],
  title: 'Temp', category: 'TEMP', pattern: 'tempcall\\(', description: 'Temp rule.',
  example: { file: 'a.go', vulnerable: 'tempcall(1)', fixed: 'other(1)' },
};

function tempRules(...rules) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'seed-central-'));
  rules.forEach((r, i) => fs.writeFileSync(path.join(dir, `r${i}.json`), JSON.stringify(r)));
  return dir;
}
const write = (dir, rule, i = 0) => fs.writeFileSync(path.join(dir, `r${i}.json`), JSON.stringify(rule));
const one = async (pool, sql, args = []) => (await pool.query(sql, args)).rows[0];

test('withPillar gives existing security-typed rules the security pillar and leaves everything else alone', () => {
  assert.equal(withPillar({ id: 'a', type: 'IAC' }).pillar, 'security');
  assert.equal(withPillar({ id: 'a', type: 'SECRET' }).pillar, 'security');
  assert.equal(withPillar({ id: 'a', type: 'SAST', category: 'X' }).category, 'X');
  assert.equal(withPillar({ id: 'a', type: 'SAST', pillar: 'reliability' }).pillar, 'reliability');
  assert.equal(withPillar({ id: 'a' }).pillar, undefined);
});

test('seeding twice creates then reports unchanged; pillars, origins and coverage are right', async () => {
  const db = await freshDb();
  try {
    const first = await seedCentral({ pool: db.pool });
    assert.ok(first.created >= 296 + 39, JSON.stringify(first));
    assert.equal(first.updated, 0);
    assert.equal(first.skippedEdited, 0);
    assert.equal(first.orphaned, 0);
    const second = await seedCentral({ pool: db.pool });
    assert.deepEqual(second, { created: 0, updated: 0, unchanged: first.created, excluded: 0, skippedEdited: 0, skippedEditedIds: [], orphaned: 0, orphanedIds: [] });
    const cov = await coverage(db.pool);
    assert.equal(cov.length, 48);
    assert.deepEqual(cov.filter(l => !l.meetsMinimum).map(l => l.language), []);
    assert.equal((await one(db.pool, "SELECT count(*)::int AS n FROM rule WHERE status <> 'active' OR version <> 1")).n, 0);
    assert.deepEqual((await db.pool.query("SELECT DISTINCT actor FROM audit WHERE action = 'rule.seed'")).rows.map(r => r.actor), ['seed']);

    // pillars come from the rule file (first rules) or from the type backfill (existing rules), and categories are untouched
    assert.equal((await one(db.pool, "SELECT pillar FROM rule WHERE rule_id = 'abap-select-star'")).pillar, 'code-quality');
    assert.equal((await one(db.pool, "SELECT pillar FROM rule WHERE rule_id = 'rust-unwrap'")).pillar, 'reliability');
    assert.equal((await one(db.pool, "SELECT pillar FROM rule WHERE rule_id = 'css-important'")).pillar, 'maintainability');
    const iac = await one(db.pool, "SELECT pillar, body FROM rule WHERE rule_id = 'docker-run-as-root'");
    assert.equal(iac.pillar, 'security');
    assert.equal(iac.body.category, 'CONTAINER_ROOT_USER');
    const secret = await one(db.pool, "SELECT pillar, body FROM rule WHERE engine = 'secret' LIMIT 1");
    assert.equal(secret.pillar, 'security');
    assert.ok(secret.body.category);

    // origin: vendor when the file has provenance, builtin otherwise
    const origins = Object.fromEntries((await db.pool.query('SELECT origin, count(*)::int AS n FROM rule GROUP BY origin')).rows.map(r => [r.origin, r.n]));
    const fileCount = (dir) => fs.readdirSync(dir, { withFileTypes: true }).reduce((n, e) => n + (e.isDirectory() ? fileCount(path.join(dir, e.name)) : e.name.endsWith('.json') ? 1 : 0), 0);
    const vendor = fileCount(path.join(__dirname, '..', 'seed', 'rules', 'vendor'));
    assert.equal(origins.vendor, vendor);
    assert.equal(origins.builtin, first.created - vendor);
  } finally { await db.close(); }
});

test('the default allow list drops a source that may not be redistributed', async () => {
  const db = await freshDb();
  try {
    const blocked = SOURCES.find(s => s.id === 'semgrep');
    assert.equal(blocked.redistributable, false);
    assert.ok(!redistributableIds().includes('semgrep'));
    const dir = tempRules(baseRule, { ...baseRule, id: 'go-semgrep-rule', provenance: { source: 'semgrep', license: 'Semgrep Rules License v1.0' } });
    const result = await seedCentral({ pool: db.pool, rulesDir: dir });
    assert.equal(result.excluded, 1);
    assert.equal(result.created, 1);
    assert.equal((await one(db.pool, "SELECT count(*)::int AS n FROM rule WHERE rule_id = 'go-semgrep-rule'")).n, 0);
    const named = await seedCentral({ pool: db.pool, rulesDir: dir, allowSources: ['semgrep'] });
    assert.equal(named.excluded, 0);
    assert.equal((await one(db.pool, "SELECT origin FROM rule WHERE rule_id = 'go-semgrep-rule'")).origin, 'vendor');
  } finally { await db.close(); }
});

test('a changed file body is an update to version 2', async () => {
  const db = await freshDb();
  try {
    const dir = tempRules(baseRule);
    assert.equal((await seedCentral({ pool: db.pool, rulesDir: dir })).created, 1);
    write(dir, { ...baseRule, severity: 'HIGH' });
    const result = await seedCentral({ pool: db.pool, rulesDir: dir });
    assert.equal(result.updated, 1);
    const row = await one(db.pool, "SELECT version, severity FROM rule WHERE rule_id = 'go-temp-rule'");
    assert.deepEqual(row, { version: 2, severity: 'HIGH' });
  } finally { await db.close(); }
});

test('a rule last written by someone other than the seed is left alone and listed', async () => {
  const db = await freshDb();
  try {
    const dir = tempRules(baseRule);
    await seedCentral({ pool: db.pool, rulesDir: dir });
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go'] });
    await repo.update('go-temp-rule', { severity: 'MEDIUM' }, { actor: 'ann@example.test', reason: 'tuned in Studio' });
    write(dir, { ...baseRule, severity: 'CRITICAL' });
    const result = await seedCentral({ pool: db.pool, rulesDir: dir });
    assert.equal(result.skippedEdited, 1);
    assert.deepEqual(result.skippedEditedIds, ['go-temp-rule']);
    assert.equal(result.updated, 0);
    const row = await one(db.pool, "SELECT version, severity, body FROM rule WHERE rule_id = 'go-temp-rule'");
    assert.equal(row.severity, 'MEDIUM');
    assert.equal(row.body.severity, 'MEDIUM');
    assert.equal(row.version, 2);
  } finally { await db.close(); }
});

test('a rule whose file was removed is reported as orphaned and stays active', async () => {
  const db = await freshDb();
  try {
    const dir = tempRules(baseRule, { ...baseRule, id: 'go-other-rule' });
    await seedCentral({ pool: db.pool, rulesDir: dir });
    fs.rmSync(path.join(dir, 'r1.json'));
    const result = await seedCentral({ pool: db.pool, rulesDir: dir });
    assert.equal(result.orphaned, 1);
    assert.deepEqual(result.orphanedIds, ['go-other-rule']);
    assert.equal((await one(db.pool, "SELECT status FROM rule WHERE rule_id = 'go-other-rule'")).status, 'active');
  } finally { await db.close(); }
});
