'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { execFileSync } = require('node:child_process');
const { createBlobStore, encodePack, decodePack } = require('../src/packs/blobs');
const { buildPacks } = require('../src/packs/build');
const { loadLanguages } = require('../src/languages');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'packs-'));
const write = (root, rel, content) => {
  fs.mkdirSync(path.dirname(path.join(root, rel)), { recursive: true });
  fs.writeFileSync(path.join(root, rel), content);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function fakeAnalyzer() {
  const dir = tmp();
  write(dir, 'package.json', JSON.stringify({ name: 'fake', version: '1.0.0', dependencies: { 'fake-dep': '^1.0.0' }, devDependencies: { 'dev-only': '^1.0.0' } }));
  write(dir, 'src/index.js', "'use strict';\nmodule.exports = { ENGINES: 'x:1', dep: require('fake-dep') };\n");
  write(dir, 'src/ast/engine.js', '// engine\n');
  write(dir, 'src/ast/grammars/tree-sitter-java.wasm', 'WASM-JAVA');
  write(dir, 'src/.DS_Store', 'junk');
  write(dir, 'node_modules/fake-dep/package.json', JSON.stringify({ name: 'fake-dep', version: '1.0.0', dependencies: { 'inner-dep': '^1.0.0' } }));
  write(dir, 'node_modules/fake-dep/x.js.map', '{}');
  write(dir, 'src/ast/grammars/README.txt', 'not for the core pack');
  write(dir, 'node_modules/fake-dep/index.js', "module.exports = 'fake-dep';\n");
  write(dir, 'node_modules/inner-dep/package.json', JSON.stringify({ name: 'inner-dep', version: '1.0.0' }));
  write(dir, 'node_modules/dev-only/package.json', JSON.stringify({ name: 'dev-only', version: '1.0.0' }));
  const grammars = tmp();
  write(grammars, 'tree-sitter-java.wasm', 'WASM-JAVA');
  return { dir, grammars };
}

const languages = [
  { id: 'java', extensions: ['.java'], grammar: { wasm: 'tree-sitter-java.wasm' } },
  { id: 'go', extensions: ['.go'], grammar: null },
  { id: 'rust', extensions: ['.rs'], grammar: null },
];
const rule = (id, language, extra = {}) => ({ id, language, severity: 'HIGH', pattern: 'x', ...extra });
const baseRules = () => [rule('java-a', 'java'), rule('go-a', 'go'), rule('go-b', 'go')];
const bySha = (list) => Object.fromEntries(list.map((p) => [p.packId, p.sha256]));

test('blob store: put then get round-trips, has reflects presence', async () => {
  const store = createBlobStore(tmp());
  const hash = await store.put(Buffer.from('hello'));
  assert.match(hash, /^[0-9a-f]{64}$/);
  assert.equal((await store.get(hash)).toString(), 'hello');
  assert.equal(await store.has(hash), true);
  assert.equal(await store.has('0'.repeat(64)), false);
});

test('blob store: a tampered file is reported as CORRUPT', async () => {
  const dir = tmp();
  const store = createBlobStore(dir);
  const hash = await store.put(Buffer.from('hello'));
  fs.writeFileSync(path.join(dir, hash), 'tampered');
  await assert.rejects(store.get(hash), { code: 'CORRUPT' });
});

test('blob store: has() and get() never touch paths outside the store', async () => {
  const store = createBlobStore(tmp());
  assert.equal(await store.has('../../etc/passwd'), false);
  assert.equal(await store.has('x'), false);
  await assert.rejects(store.get('../x'), { code: 'BAD_HASH' });
});

test('blob store: put leaves no temp file behind when the write fails', async () => {
  const dir = tmp();
  const store = createBlobStore(dir);
  const hash = await store.put(Buffer.from('hello'));
  fs.rmSync(path.join(dir, hash));
  fs.mkdirSync(path.join(dir, hash)); // rename onto a directory fails
  await assert.rejects(store.put(Buffer.from('hello')));
  assert.deepEqual(fs.readdirSync(dir).filter((n) => n.endsWith('.tmp')), []);
});

test('encodePack/decodePack round-trip exact bytes', () => {
  const data = Buffer.from([0, 1, 2, 255, 254, 10, 13]);
  const pack = { id: 'lang-x', kind: 'language', language: 'x', version: 'abc', files: [{ path: 'b/two.bin', data }, { path: 'a.txt', data: Buffer.from('hi') }] };
  const out = decodePack(encodePack(pack));
  assert.deepEqual(out.files.map((f) => f.path), ['a.txt', 'b/two.bin']);
  assert.ok(out.files[1].data.equals(data));
  assert.equal(out.id, 'lang-x');
  assert.equal(out.version, 'abc');
});

test('encodePack is byte-identical across a clock tick and has a zero gzip MTIME', async () => {
  const pack = { id: 'core', kind: 'core', language: null, version: 'v', files: [{ path: 'a', data: Buffer.from('x') }] };
  const a = encodePack(pack);
  await sleep(1100);
  const b = encodePack(pack);
  assert.ok(a.equals(b));
  assert.equal(a.readUInt32LE(4), 0);
  assert.equal(zlib.gunzipSync(a).toString().includes('"id":"core"'), true);
});

test('decodePack refuses absolute paths and ..', () => {
  const forge = (p) => zlib.gzipSync(JSON.stringify({ id: 'x', kind: 'core', language: null, version: 'v', files: [{ path: p, b64: '' }] }));
  for (const p of ['/etc/passwd', '../x', 'a/../../x', 'a/..', 'C:/x', 'a\\b', '']) {
    assert.throws(() => decodePack(forge(p)), { code: 'UNSAFE_PATH' }, p);
  }
  assert.doesNotThrow(() => decodePack(forge('a..b/c.txt')));
  assert.throws(() => encodePack({ id: 'x', kind: 'core', language: null, version: 'v', files: [{ path: '../x', data: Buffer.alloc(0) }] }), { code: 'UNSAFE_PATH' });
});

test('duplicate and case-colliding pack paths are refused by decodePack and encodePack', () => {
  const forge = (paths) => zlib.gzipSync(JSON.stringify({ id: 'x', kind: 'core', language: null, version: 'v', files: paths.map((p) => ({ path: p, b64: '' })) }));
  assert.throws(() => decodePack(forge(['rules.json', 'a', 'rules.json'])), { code: 'DUPLICATE_PATH' });
  assert.throws(() => decodePack(forge(['Rules.json', 'rules.json'])), { code: 'DUPLICATE_PATH' });
  const enc = (paths) => encodePack({ id: 'x', kind: 'core', language: null, version: 'v', files: paths.map((p) => ({ path: p, data: Buffer.alloc(0) })) });
  assert.throws(() => enc(['a', 'a']), { code: 'DUPLICATE_PATH' });
  assert.throws(() => enc(['Rules.json', 'rules.json']), { code: 'DUPLICATE_PATH' });
  assert.doesNotThrow(() => enc(['a', 'b']));
});

test('buildPacks refuses a rule whose language is not in the registry', async () => {
  const { dir, grammars } = fakeAnalyzer();
  await assert.rejects(
    buildPacks({ rules: [rule('x-a', 'cobol')], languages, analyzerDir: dir, grammarDir: grammars, blobs: createBlobStore(tmp()) }),
    /"cobol"/);
});

test('buildPacks twice gives identical sha256 for every pack, and packs only languages with active rules', async () => {
  const { dir, grammars } = fakeAnalyzer();
  const args = { rules: baseRules(), languages, analyzerDir: dir, grammarDir: grammars, blobs: createBlobStore(tmp()) };
  const one = await buildPacks(args);
  await sleep(1100);
  const two = await buildPacks(args);
  assert.deepEqual(one, two);
  assert.deepEqual(one.map((p) => p.packId), ['core', 'lang-go', 'lang-java']);
  assert.equal(one.find((p) => p.packId === 'lang-rust'), undefined);
  assert.equal(one[0].kind, 'core');
  assert.equal(one[0].language, null);
  assert.match(one[1].version, /^[0-9a-f]{12}$/);
});

test('editing one Go rule changes only lang-go', async () => {
  const { dir, grammars } = fakeAnalyzer();
  const mk = (rules) => buildPacks({ rules, languages, analyzerDir: dir, grammarDir: grammars, blobs: createBlobStore(tmp()) });
  const before = bySha(await mk(baseRules()));
  const edited = baseRules();
  edited[1] = rule('go-a', 'go', { pattern: 'changed' });
  const after = bySha(await mk(edited));
  assert.notEqual(after['lang-go'], before['lang-go']);
  assert.equal(after.core, before.core);
  assert.equal(after['lang-java'], before['lang-java']);
});

test('language pack contents: rules sorted by id, grammar, pack.json whose version matches the pack', async () => {
  const { dir, grammars } = fakeAnalyzer();
  const blobs = createBlobStore(tmp());
  const built = await buildPacks({ rules: [rule('java-b', 'java'), rule('java-a', 'java')], languages, analyzerDir: dir, grammarDir: grammars, blobs });
  const java = built.find((p) => p.packId === 'lang-java');
  const pack = decodePack(await blobs.get(java.sha256));
  assert.deepEqual(pack.files.map((f) => f.path), ['grammar/tree-sitter-java.wasm', 'pack.json', 'rules.json']);
  const meta = JSON.parse(pack.files.find((f) => f.path === 'pack.json').data);
  assert.deepEqual(meta, { id: 'lang-java', language: 'java', extensions: ['.java'], version: java.version });
  assert.deepEqual(JSON.parse(pack.files.find((f) => f.path === 'rules.json').data).map((r) => r.id), ['java-a', 'java-b']);
  assert.equal(pack.files.find((f) => f.path.endsWith('.wasm')).data.toString(), 'WASM-JAVA');
});

test('buildPacks throws naming the language when its grammar file is missing', async () => {
  const { dir } = fakeAnalyzer();
  await assert.rejects(
    buildPacks({ rules: [rule('java-a', 'java')], languages, analyzerDir: dir, grammarDir: tmp(), blobs: createBlobStore(tmp()) }),
    /"java"/);
});

test('core pack holds src (minus grammars), package.json, production deps only', async () => {
  const { dir, grammars } = fakeAnalyzer();
  const blobs = createBlobStore(tmp());
  const [core] = await buildPacks({ rules: [], languages, analyzerDir: dir, grammarDir: grammars, blobs });
  const paths = decodePack(await blobs.get(core.sha256)).files.map((f) => f.path);
  assert.deepEqual(paths, [
    'node_modules/fake-dep/index.js', 'node_modules/fake-dep/package.json', 'node_modules/inner-dep/package.json',
    'package.json', 'src/ast/engine.js', 'src/index.js']);
});

test('engine loads from the core pack alone (real analyzer, clean env, no analyzer node_modules)', async () => {
  const analyzerDir = path.resolve(__dirname, '../../oasis-analyzer');
  const blobs = createBlobStore(tmp());
  const languagesReal = loadLanguages(path.join(__dirname, '../seed/languages.json'));
  const [core] = await buildPacks({ rules: [], languages: languagesReal, analyzerDir, grammarDir: path.join(analyzerDir, 'src/ast/grammars'), blobs });
  const pack = decodePack(await blobs.get(core.sha256));
  const paths = pack.files.map((f) => f.path);
  assert.ok(paths.includes('node_modules/web-tree-sitter/web-tree-sitter.wasm'));
  assert.ok(paths.includes('node_modules/js-yaml/package.json'));
  assert.ok(paths.includes('node_modules/argparse/package.json'));
  assert.ok(!paths.some((p) => p.endsWith('.wasm') && p.startsWith('src/')));

  const out = tmp();
  for (const f of pack.files) write(out, f.path, f.data);
  const script = "const e=require(require('path').join(process.cwd(),'src','index.js'));"
    + "const wts=require.resolve('web-tree-sitter');const y=require.resolve('js-yaml');"
    + "console.log(JSON.stringify({engines:e.ENGINES,wts,y,paths:Object.keys(e.scanners)}))";
  const stdout = execFileSync(process.execPath, ['-e', script], { cwd: out, env: { PATH: process.env.PATH }, encoding: 'utf8' });
  const got = JSON.parse(stdout);
  assert.equal(got.engines, 'ast:1,pattern:1,iac-policy:1,secret:1');
  assert.ok(fs.realpathSync(got.wts).startsWith(fs.realpathSync(out)), got.wts);
  assert.ok(fs.realpathSync(got.y).startsWith(fs.realpathSync(out)), got.y);
});
