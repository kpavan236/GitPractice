'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createApp } = require('../src/api');

async function start() {
  const server = createApp({ db: openDb() }).listen(0, '127.0.0.1');
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  return { call, close: () => server.close() };
}
const withServer = fn => async () => { const s = await start(); try { await fn(s); } finally { s.close(); } };
const fnd = (fp, repo, extra = {}) => ({ fingerprint: fp, id: `F-${repo.replace('/', '_')}-${fp}`, repository: repo, type: 'SAST', severity: 'HIGH', status: 'OPEN', title: `title ${fp}`, file: 'a.js', startLine: 1, risk: { score: 10 }, ...extra });
const analysis = (id, repo, findings, extra = {}) => ({ analysisId: id, projectKey: repo, coverage: [{ type: 'SAST', analysed: true }], newCodeAvailable: true, findings, ...extra });
async function seed(s) {
  await s.call('POST', '/analyses', analysis('A1', 'org/a', [fnd('f1', 'org/a', { risk: { score: 30 } }), fnd('f2', 'org/a', { severity: 'LOW', type: 'SECRET', cve: 'CVE-1', risk: { score: 5 } })]));
  await s.call('POST', '/analyses', analysis('B1', 'org/b', [fnd('f1', 'org/b', { title: 'SQL injection', risk: { score: 50 } })]));
}

test('list across projects: filters, search fields and risk-score order match the scanner', withServer(async s => {
  await seed(s);
  const all = (await s.call('GET', '/findings')).body;
  assert.deepEqual(all.map(f => f.id), ['F-org_b-f1', 'F-org_a-f1', 'F-org_a-f2'], 'highest risk score first');
  assert.deepEqual((await s.call('GET', '/findings?repository=org/a')).body.map(f => f.fingerprint), ['f1', 'f2']);
  assert.deepEqual((await s.call('GET', '/findings?type=SECRET')).body.map(f => f.id), ['F-org_a-f2']);
  assert.deepEqual((await s.call('GET', '/findings?severity=LOW')).body.map(f => f.id), ['F-org_a-f2']);
  assert.deepEqual((await s.call('GET', '/findings?search=sql')).body.map(f => f.id), ['F-org_b-f1']);
  assert.deepEqual((await s.call('GET', '/findings?search=cve-1')).body.map(f => f.id), ['F-org_a-f2']);
  assert.deepEqual((await s.call('GET', '/findings?search=org/b')).body.map(f => f.id), ['F-org_b-f1'], 'repository is searchable');
}));

test('status filters: active by default, all, a specific status, and new-since-baseline', withServer(async s => {
  await seed(s);
  await s.call('POST', '/findings/F-org_a-f2/status', { status: 'SUPPRESSED', reason: 'r' });
  assert.equal((await s.call('GET', '/findings')).body.length, 2);
  assert.equal((await s.call('GET', '/findings?status=all')).body.length, 3);
  assert.deepEqual((await s.call('GET', '/findings?status=SUPPRESSED')).body.map(f => f.id), ['F-org_a-f2']);
  assert.equal((await s.call('GET', '/findings?status=new')).body.length, 2, 'no baseline: everything active is new');
  assert.equal((await s.call('POST', '/baseline')).status, 200);
  assert.equal((await s.call('GET', '/findings?status=new')).body.length, 0);
  await s.call('POST', '/analyses', analysis('A2', 'org/a', [fnd('f1', 'org/a'), fnd('f9', 'org/a')]));
  assert.deepEqual((await s.call('GET', '/findings?status=new')).body.map(f => f.fingerprint), ['f9']);
}));

test('a finding is addressed by id, across projects, and triage by id survives the next analysis', withServer(async s => {
  await seed(s);
  assert.equal((await s.call('GET', '/findings/F-org_b-f1')).body.repository, 'org/b');
  assert.equal((await s.call('GET', '/findings/nope')).status, 404);
  assert.equal((await s.call('POST', '/findings/F-org_a-f1/status', { status: 'SUPPRESSED' })).status, 400);
  assert.equal((await s.call('POST', '/findings/F-org_a-f1/status', { status: 'WEIRD' })).status, 400);
  assert.equal((await s.call('POST', '/findings/nope/status', { status: 'OPEN' })).status, 404);
  const r = await s.call('POST', '/findings/F-org_a-f1/status', { status: 'SUPPRESSED', reason: 'accepted' });
  assert.equal(r.body.suppression.reason, 'accepted');
  await s.call('POST', '/analyses', analysis('A2', 'org/a', [fnd('f1', 'org/a', { id: 'NEW-ID' })]));
  const f = (await s.call('GET', '/findings/F-org_a-f1')).body;
  assert.equal(f.status, 'SUPPRESSED');
  assert.equal(f.id, 'F-org_a-f1', 'the id the UI listed does not change');
  assert.equal((await s.call('GET', '/findings?status=all&repository=org/b')).body[0].status, 'OPEN', 'the other project is untouched');
  await s.call('POST', '/findings/F-org_a-f1/status', { status: 'REOPENED' });
  assert.equal((await s.call('GET', '/findings/F-org_a-f1')).body.suppression, null);
}));

test('baseline: none, set from active findings only, cleared', withServer(async s => {
  assert.equal((await s.call('GET', '/baseline')).body, null);
  await seed(s);
  await s.call('POST', '/findings/F-org_a-f2/status', { status: 'FALSE_POSITIVE' });
  const b = (await s.call('POST', '/baseline')).body;
  assert.deepEqual(b.fingerprints.sort(), ['f1']);
  assert.ok(b.createdAt);
  assert.equal((await s.call('GET', '/baseline')).body.fingerprints.length, 1);
  await s.call('DELETE', '/baseline');
  assert.equal((await s.call('GET', '/baseline')).body, null);
}));

test('clear preview, clear (keeping triage), and reset', withServer(async s => {
  await seed(s);
  await s.call('POST', '/findings/F-org_a-f2/status', { status: 'SUPPRESSED', reason: 'r' });
  const p = (await s.call('GET', '/maintenance/preview')).body;
  assert.deepEqual([p.findings, p.suppressed, p.repositories, p.history], [3, 1, 2, 2]);
  assert.equal((await s.call('GET', '/maintenance/preview?repository=org/a')).body.findings, 2);

  const kept = (await s.call('DELETE', '/findings?repository=org/a&keepSuppressed=true')).body;
  assert.deepEqual([kept.findings, kept.keptSuppressed], [1, 1]);
  assert.deepEqual((await s.call('GET', '/findings?status=all')).body.map(f => f.id).sort(), ['F-org_a-f2', 'F-org_b-f1']);

  await s.call('DELETE', '/findings?keepSuppressed=false');
  assert.equal((await s.call('GET', '/findings?status=all')).body.length, 0);
  assert.equal((await s.call('GET', '/history')).body.points.length, 2, 'clear never touches history');

  await s.call('POST', '/baseline');
  await s.call('PUT', '/projects/org/gate', { conditions: [{ metric: 'secrets', scope: 'OVERALL', operator: 'GT', threshold: 0 }] });
  const reset = (await s.call('POST', '/maintenance/reset')).body;
  assert.equal(reset.reset, true);
  assert.equal((await s.call('GET', '/history')).body.points.length, 0);
  assert.equal((await s.call('GET', '/baseline')).body, null);
  assert.equal((await s.call('GET', '/projects/org%2Fa/analyses')).body.length, 0);
  assert.equal((await s.call('GET', '/projects/org/gate')).body.source, 'project', 'reset keeps the user\'s settings');
}));

test('import restores findings and history verbatim, atomically, and later analyses merge against them', withServer(async s => {
  const imported = {
    findings: [
      fnd('f1', 'org/a', { status: 'SUPPRESSED', suppression: { reason: 'old' }, firstSeenAt: 111, lastSeenAt: 222 }),
      fnd('f2', 'org/a', { status: 'RESOLVED', resolvedAt: 5, resolvedBy: 'NOT_DETECTED', firstSeenAt: 1, lastSeenAt: 2 }),
    ],
    history: [{ at: 1, total: 2, counts: { CRITICAL: 0, HIGH: 2, MEDIUM: 0, LOW: 0, INFO: 0 }, byType: { SAST: 2 }, repositories: 1 }],
  };
  const r = await s.call('POST', '/import', imported);
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.findings, r.body.history], [2, 1]);
  const f1 = (await s.call('GET', '/findings/F-org_a-f1')).body;
  assert.deepEqual([f1.status, f1.firstSeenAt, f1.suppression.reason], ['SUPPRESSED', 111, 'old']);
  assert.equal((await s.call('GET', '/history')).body.points.length, 1);

  await s.call('POST', '/analyses', analysis('A9', 'org/a', [fnd('f1', 'org/a')]));
  assert.equal((await s.call('GET', '/findings/F-org_a-f1')).body.status, 'SUPPRESSED', 'imported triage survives a new analysis');

  assert.equal((await s.call('POST', '/import', { findings: 'nope' })).status, 400);
  assert.equal((await s.call('POST', '/import', { findings: [fnd('x', 'org/z'), { id: 'no-fingerprint' }], history: [] })).status, 400);
  assert.equal((await s.call('GET', '/findings?repository=org/z&status=all')).body.length, 0, 'a bad payload writes nothing');
}));

test('analyses of one scan share one trend point, updated as each repository lands', withServer(async s => {
  const a = (id, repo, fp) => analysis(id, repo, [fnd(fp, repo)], { scanId: 'SCAN-1' });
  await s.call('POST', '/analyses', a('SCAN-1:org/a', 'org/a', 'f1'));
  await s.call('POST', '/analyses', a('SCAN-1:org/b', 'org/b', 'f1'));
  let h = (await s.call('GET', '/history')).body;
  assert.equal(h.points.length, 1, 'two repositories of one scan are one point');
  assert.equal(h.points[0].total, 2);
  assert.equal(h.points[0].projects, 2);
  await s.call('POST', '/analyses', analysis('SCAN-2:org/a', 'org/a', [], { scanId: 'SCAN-2' }));
  h = (await s.call('GET', '/history')).body;
  assert.deepEqual(h.points.map(p => p.total), [2, 1]);
  assert.equal(h.sinceLastScan.total, -1);
}));

test('risk updates re-score findings without touching their triage', withServer(async s => {
  await seed(s);
  await s.call('POST', '/findings/F-org_a-f1/status', { status: 'SUPPRESSED', reason: 'r' });
  const r = await s.call('POST', '/findings/risk', { updates: [{ id: 'F-org_a-f1', risk: { score: 99 } }, { id: 'F-org_b-f1', risk: { score: 1 } }] });
  assert.equal(r.status, 200);
  assert.equal(r.body.updated, 2);
  const f = (await s.call('GET', '/findings/F-org_a-f1')).body;
  assert.deepEqual([f.risk.score, f.status], [99, 'SUPPRESSED']);
  assert.equal((await s.call('POST', '/findings/risk', { updates: [{ id: 'nope', risk: { score: 1 } }] })).body.updated, 0);
  assert.equal((await s.call('POST', '/findings/risk', { updates: 'x' })).status, 400);
  assert.equal((await s.call('POST', '/findings/risk', { updates: [{ id: 'F-org_a-f1', risk: 'bad' }] })).status, 400);
}));

test('suppression keeps who decided, until when and why, for suppressed and false-positive findings', withServer(async s => {
  await seed(s);
  const a = await s.call('POST', '/findings/F-org_a-f1/status', { status: 'SUPPRESSED', reason: ' accepted risk ', owner: 'alice', expiresAt: 1999999999999 });
  assert.deepEqual([a.body.suppression.reason, a.body.suppression.owner, a.body.suppression.expiresAt], ['accepted risk', 'alice', 1999999999999]);
  assert.ok(a.body.suppression.decidedAt > 0);
  const b = await s.call('POST', '/findings/F-org_a-f2/status', { status: 'FALSE_POSITIVE', reason: 'test fixture' });
  assert.equal(b.body.status, 'FALSE_POSITIVE');
  assert.equal(b.body.suppression.reason, 'test fixture');
  assert.equal(b.body.suppression.owner, null);
  assert.equal((await s.call('POST', '/findings/F-org_b-f1/status', { status: 'OPEN', reason: 'ignored for open' })).body.suppression, undefined);
}));

test('import can restore the baseline verbatim; a malformed baseline writes nothing', withServer(async s => {
  const payload = { findings: [fnd('f1', 'org/a')], history: [], baseline: { createdAt: 77, fingerprints: ['f1', 'gone'] } };
  assert.equal((await s.call('POST', '/import', payload)).status, 200);
  assert.deepEqual((await s.call('GET', '/baseline')).body, { createdAt: 77, fingerprints: ['f1', 'gone'] });
  await s.call('DELETE', '/baseline');
  const bad = await s.call('POST', '/import', { findings: [fnd('f2', 'org/b')], history: [], baseline: { fingerprints: 'x' } });
  assert.equal(bad.status, 400);
  assert.equal((await s.call('GET', '/findings?repository=org/b&status=all')).body.length, 0);
  assert.equal((await s.call('GET', '/baseline')).body, null);
}));

// ── Review fixes: reads, history order, migration safety ──────────────────────

test('GET /findings/repositories lists the repositories that have findings, with counts, without sending the findings', withServer(async s => {
  await seed(s);
  await s.call('POST', '/findings/F-org_a-f2/status', { status: 'SUPPRESSED', reason: 'r' });
  const r = await s.call('GET', '/findings/repositories');
  assert.deepEqual(r.body, [{ repository: 'org/a', findings: 2, active: 1 }, { repository: 'org/b', findings: 1, active: 1 }]);
}));

test('history is ordered by when the scan happened, not by when it reached the server', withServer(async s => {
  await s.call('POST', '/analyses', analysis('NEW', 'org/a', [fnd('f1', 'org/a')], { scanId: 'S-NEW', completedAt: '2026-06-02T00:00:00.000Z' }));
  await s.call('POST', '/analyses', analysis('OLD', 'org/b', [fnd('f1', 'org/b')], { scanId: 'S-OLD', completedAt: '2026-06-01T00:00:00.000Z' }));
  const h = (await s.call('GET', '/history')).body;
  assert.deepEqual(h.points.map(p => p.at), [Date.parse('2026-06-01T00:00:00.000Z'), Date.parse('2026-06-02T00:00:00.000Z')]);
}));

test('merge-mode import adds what is missing and adopts local triage, without overwriting what the server knows', withServer(async s => {
  // The server already scanned (a first scan before migrating): everything is OPEN with server ids.
  await s.call('POST', '/analyses', analysis('A1', 'org/a', [fnd('f1', 'org/a'), fnd('f2', 'org/a', { severity: 'LOW' }), fnd('f3', 'org/a')]));
  await s.call('POST', '/findings/F-org_a-f3/status', { status: 'FALSE_POSITIVE', reason: 'server decision' });
  const imported = {
    findings: [
      fnd('f1', 'org/a', { id: 'F-OLD-1', status: 'SUPPRESSED', suppression: { reason: 'old decision', owner: 'al' }, severity: 'CRITICAL' }),
      fnd('f3', 'org/a', { id: 'F-OLD-3', status: 'OPEN' }),
      fnd('f9', 'org/a', { id: 'F-OLD-9', status: 'RESOLVED', resolvedAt: 5 }),
    ],
    history: [{ at: 5, total: 9, counts: {}, byType: {}, repositories: 1 }],
  };
  const r = await s.call('POST', '/import?mode=merge', imported);
  assert.deepEqual([r.body.inserted, r.body.adopted, r.body.skipped], [1, 1, 1]);

  const f1 = (await s.call('GET', '/findings/F-org_a-f1')).body;
  assert.deepEqual([f1.status, f1.suppression.reason, f1.severity, f1.id], ['SUPPRESSED', 'old decision', 'HIGH', 'F-org_a-f1'], 'triage adopted; the server\'s facts and id kept');
  assert.equal((await s.call('GET', '/findings/F-org_a-f3')).body.suppression.reason, 'server decision', 'the server\'s own decision wins');
  assert.equal((await s.call('GET', '/findings/F-OLD-9')).body.status, 'RESOLVED');
  assert.equal((await s.call('GET', '/history')).body.points[0].total, 9, 'older history lands first');
}));

test('import gives an id to a finding that has none, so the UI can open it', withServer(async s => {
  const { id: _drop, ...noId } = fnd('f1', 'org/a');
  await s.call('POST', '/import', { findings: [noId], history: [] });
  const [f] = (await s.call('GET', '/findings?status=all')).body;
  assert.match(f.id, /^F-/);
  assert.equal((await s.call('GET', `/findings/${f.id}`)).status, 200);
}));
