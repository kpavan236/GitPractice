'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { SOURCES, redistributableIds } = require('../tools/ingest/sources');

// The licence gate, asserted against the bundle that actually ships.
//
// Handing rules to scanners is a REDISTRIBUTION (formerly: a signed bundle packaged
// into the .pkg and the .exe). Some excellent rule sets may be
// read but not redistributed — the Semgrep Rules License permits use "only for
// your own internal business purposes" and states it "does not allow you to
// distribute the rules, or to make them available to others as a service".
//
// scripts/seed.js filters those out by default. This test is the second gate, because
// a licence violation that depends on one function being called correctly is a
// licence violation waiting to ship. It fails loudly on the artifact itself.

function* jsonFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* jsonFiles(full);
    else if (entry.name.endsWith('.json')) yield full;
  }
}

// Every rule this server can hand out: everything under seed/rules.
const BUNDLE = { rules: [...jsonFiles(path.join(__dirname, '..', 'seed', 'rules'))].map(f => JSON.parse(fs.readFileSync(f, 'utf8'))) };

test('no rule from a non-redistributable source is in the rule set', () => {
  const allowed = new Set(redistributableIds());
  const offending = BUNDLE.rules
    .filter(r => r.provenance && !allowed.has(r.provenance.source))
    .map(r => `${r.id} (${r.provenance.source}, ${r.provenance.license})`);

  assert.deepEqual(
    offending,
    [],
    'these rules may not be redistributed and must not be served'
  );
});

test('every source declares a licence, a URL and an attribution', () => {
  // The attribution directory is generated from this registry, so a source
  // missing any of these produces an incomplete NOTICE — which is the
  // compliance failure, not a cosmetic one.
  for (const source of SOURCES) {
    assert.ok(source.license, `${source.id} has no licence`);
    assert.ok(source.licenseUrl, `${source.id} has no licence URL`);
    assert.ok(source.homepage, `${source.id} has no homepage`);
    assert.ok(source.attribution && source.attribution.length > 20, `${source.id} has no attribution text`);
  }
});

test('a source that is not redistributable says why', () => {
  for (const source of SOURCES.filter(s => !s.redistributable)) {
    assert.ok(
      source.licenseWarning && source.licenseWarning.length > 20,
      `${source.id} is barred from the bundle but does not say why`
    );
  }
});

test('semgrep is registered and barred from redistribution', () => {
  // Named explicitly rather than left to the generic checks: if someone flips
  // this flag, the diff should be impossible to miss in review.
  const semgrep = SOURCES.find(s => s.id === 'semgrep');
  assert.ok(semgrep, 'the semgrep source row was removed');
  assert.equal(semgrep.redistributable, false);
  assert.match(semgrep.license, /Semgrep Rules License/);
});

test('every ingested rule in the bundle names a registered source', () => {
  const known = new Set(SOURCES.map(s => s.id));
  const orphans = BUNDLE.rules
    .filter(r => r.provenance && !known.has(r.provenance.source))
    .map(r => r.id);
  assert.deepEqual(orphans, [], 'rules whose source is not in the registry cannot be attributed');
});
