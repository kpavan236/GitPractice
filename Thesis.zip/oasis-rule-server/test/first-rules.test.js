'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { loadLanguages } = require('../src/languages');
const { validateRule } = require('../src/model/rule');
const { testRule } = require('../src/tester');
const { FIRST, TABLE, toRule } = require('../scripts/gen-first-rules');

const ROOT = path.join(__dirname, '..');

// The brief's fixed list of 39, written out so a change to the generator's table cannot silently change what is checked.
const BRIEF_IDS = [
  'abap-select-star', 'ansible-validate-certs-off', 'apex-dynamic-soql', 'azp-latest-vm-image', 'arm-https-only-off', 'c-gets', 'cpp-strcpy',
  'cfn-publicly-accessible', 'cobol-go-to', 'cs-new-random', 'css-important', 'dart-print', 'flex-allow-domain-wildcard', 'gha-unpinned-action',
  'go-insecure-skip-verify', 'gosu-print', 'groovy-string-execute', 'html-blank-no-rel', 'jcl-job-password', 'json-hardcoded-password',
  'kt-not-null-assertion', 'dw-leftover-log', 'objc-nslog', 'php-eval', 'pli-go-to', 'plsql-when-others-null', 'ps-invoke-expression', 'r-eval-parse',
  'rpg-dsply', 'ruby-system-interpolation', 'rust-unwrap', 'scala-as-instance-of', 'sh-curl-pipe-shell', 'swift-try-bang', 'tsql-xp-cmdshell',
  'vbnet-option-strict-off', 'vb6-resume-next', 'xml-external-entity', 'yaml-plaintext-password',
];

function* jsonFiles(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* jsonFiles(full);
    else if (entry.name.endsWith('.json')) yield full;
  }
}

const langs = loadLanguages(path.join(ROOT, 'seed', 'languages.json')).map(l => l.id);
const rules = [...jsonFiles(path.join(ROOT, 'seed', 'rules'))].map(f => JSON.parse(fs.readFileSync(f, 'utf8')));

test('every registry language has at least one seeded rule', () => {
  const byLang = new Map();
  for (const r of rules) byLang.set(r.language, (byLang.get(r.language) || 0) + 1);
  const missing = langs.filter(l => !byLang.get(l));
  assert.deepEqual(missing, [], `languages with no rule: ${missing.join(', ')}`);
});

test('the generator table is the list of 39, and each file on disk is exactly what the generator produces', () => {
  assert.equal(BRIEF_IDS.length, 39);
  assert.equal(new Set(BRIEF_IDS).size, 39);
  assert.deepEqual([...FIRST].sort(), [...BRIEF_IDS].sort());
  for (const row of TABLE) {
    const file = path.join(ROOT, 'seed', 'rules', row.lang, `${row.id}.json`);
    assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')), toRule(row), `${row.id}: file differs from the generator; rerun node scripts/gen-first-rules.js`);
  }
});

test('each generated first rule is valid and passes the real engine', async () => {
  const generated = rules.filter(r => r.precision === 'pattern' && r.provenance === undefined && BRIEF_IDS.includes(r.id));
  assert.equal(generated.length, 39);
  assert.equal(new Set(generated.map(r => r.language)).size, 39, 'one first rule per language');
  for (const r of generated) {
    assert.equal(validateRule(r, { languages: langs }), null, r.id);
    const res = await testRule(r);
    assert.equal(res.ok, true, `${r.id}: ${res.problems.join('; ')}`);
  }
});

test('first rules carry plain copy and only the two synthetic secret values', () => {
  const generated = rules.filter(r => BRIEF_IDS.includes(r.id));
  for (const r of generated) {
    assert.match(r.description, /\S/, r.id);
    assert.match(r.remediation, /\S/, r.id);
    const text = JSON.stringify(r.example);
    assert.ok(!/(AKIA|ghp_|sk-|BEGIN [A-Z ]*PRIVATE KEY)/.test(text), `${r.id}: sample looks like a real credential`);
  }
});
