# oasis-rule-server

Rules repository, quality profiles and projects for the iready-oasis security scanner.
It stores rule definitions and which rules are active; it never parses source code.
The scanner (iready-oasis) fetches a project's profile and runs the rules locally.

> **Legacy.** The loopback SQLite server described from here to "Central release service" (profiles, projects, scan results, `src/server.js`) is the legacy path, used by iready-oasis unless `OASIS_ENGINE=installed` is set. The central release service below is the direction of travel. The `db/setup/01_schema.sql` and `02_seed_data.sql` files are the SQLite setup for the legacy server.

## Overview

A small Express service backed by a single SQLite file. It serves, over a JSON HTTP API on loopback:

- **Rules**: security rule definitions (AST queries, line patterns, IaC policies, secret detectors).
- **Profiles**: named sets of rules (with per-profile enabled flag, severity override and params, and optional parent inheritance). A `Default` profile always exists.
- **Projects**: a project key mapped to a profile. Unknown projects get the Default profile.
- **Scan results** posted by the scanner: analyses, findings (with status changes such as suppress or false positive), quality gates, a baseline and a history series.

Its consumers are the iready-oasis scanner and its security UI (the code mentions a "Security tab"). The server is intended for a developer machine: it listens on `127.0.0.1` only.

## Tech stack

- Node.js >= 22.5 (uses the built-in `node:sqlite`; `engines` in `package.json`). Verified with v26.10.0.
- Express 4 (`express`), `js-yaml`.
- SQLite file database via `node:sqlite` (no separate sqlite dependency).
- Tests: the built-in `node:test` runner.
- Dev dependency `oasis-analyzer` from `file:../oasis-analyzer` (used by the rule corpus test).

## Prerequisites

- Node.js 22.5 or newer and npm.
- A sibling checkout of `oasis-analyzer` at `../oasis-analyzer` (`npm install` resolves `file:../oasis-analyzer`).
- Optional: the `sqlite3` CLI, only for the SQL setup files in `db/setup/`.

## Install

    npm install

## Running

    node scripts/seed.js        # or: npm run seed. Imports seed/rules, creates the Default profile
    npm start                   # http://127.0.0.1:5090/api/v1

`npm start` runs `node src/server.js`, which opens (and migrates) the database and listens on `127.0.0.1`. The startup line shows the port and database file. Check it:

    curl http://127.0.0.1:5090/api/v1/health      # {"status":"ok"}

You can instead create the database from SQL, without Node: see [db/setup/README.md](db/setup/README.md).

## Configuration

| Setting | Where read | Default | Meaning |
|---|---|---|---|
| `OASIS_RULE_SERVER_PORT` | `src/config.js` | `5090` | Listen port (host is fixed to `127.0.0.1`). |
| `OASIS_RULE_SERVER_DB` | `src/config.js` | `<repo>/oasis-rules.db` | SQLite file path, shared by the server and the seed script. |
| `OASIS_RULE_SERVER_TOKEN` | `src/api.js` | unset | When set, every non-GET/HEAD request needs header `x-oasis-token: <value>`, else 401 `UNAUTHORIZED`. |

Seed script flags (`scripts/seed.js`): optional first argument `rules-dir` (default `seed/rules`), `--db <file>`, `--allow gitleaks,checkov`.
By default only rule sources whose licence permits redistribution are imported (`redistributableIds()` in `tools/ingest/sources.js`). `--allow` replaces that filter with exactly the sources you name, so it can include a source that is not redistributable: use it deliberately.

Write requests that carry an `Origin` header must come from `localhost`, `127.0.0.1` or `[::1]`, otherwise 403 `FORBIDDEN_ORIGIN`. The server sets no PRAGMAs.

## API

Prefix `/api/v1`. All routes are defined in `src/api.js`. Errors are `{ "error": CODE, "message": ... }` with 400 `INVALID`, 404 `NOT_FOUND`, 409 `CONFLICT`, 422 `UNSUPPORTED_RULES`, 500 `INTERNAL`. POST/PUT bodies must be JSON objects. Body limits: 2 MB generally, 64 MB for `/analyses`, 256 MB for `/import`.

| Method and path | Purpose |
|---|---|
| `GET /health` | Liveness: `{"status":"ok"}` |
| `GET /analyzers/compat` | Engine schema versions: `{"ruleSchemaVersions":{"ast":1,"pattern":1,"iac-policy":1,"secret":1}}` |
| `GET /rules` | List rules; filters `language`, `engine`, `origin`, `status`; `fields=summary` gives light rows and `search` |
| `GET /rules/:id`, `PUT /rules/:id`, `DELETE /rules/:id` | Get, update, deprecate (sets status `DEPRECATED`) |
| `POST /rules` | Create a user rule (needs `fixture {detect, clean}`); `activateIn: ["default"]` activates it immediately |
| `GET /profiles`, `POST /profiles`, `GET /profiles/:id`, `DELETE /profiles/:id` | Profiles |
| `GET /profiles/:id/rules` | A profile's effective rules |
| `PUT /profiles/:id/rules/:ruleId` | Set `enabled`, `severity`, `params` |
| `DELETE /profiles/:id/rules/:ruleId` | Clear that override |
| `GET /projects`, `PUT /projects/:key` | List projects; create or assign a profile (`{name, profileId}`) |
| `GET /projects/:key/profile?engines=ast:1,pattern:1,iac-policy:1,secret:1` | Active rules for the project; 422 `UNSUPPORTED_RULES` names every rule the scanner cannot run |
| `GET`/`PUT`/`DELETE /projects/:key/gate` | Quality gate |
| `POST /analyses`, `GET /analyses/:id`, `GET /projects/:key/analyses` | Record and read analyses |
| `GET /projects/:key/findings`, `POST /projects/:key/findings/:fingerprint/status` | Project findings and status changes (suppressing needs a `reason`) |
| `GET /findings`, `GET /findings/repositories`, `GET /findings/:id`, `POST /findings/:id/status`, `POST /findings/risk`, `DELETE /findings` | Cross-project findings |
| `GET`/`POST`/`DELETE /baseline` | Baseline |
| `GET /maintenance/preview`, `POST /maintenance/reset` | Maintenance |
| `POST /import` | Bulk import of findings and history (`?mode=merge`) |
| `GET /history` | History series |

Examples (verified against a database built from `db/setup/`):

    curl -s "http://127.0.0.1:5090/api/v1/rules?fields=summary&language=java"
    curl -s "http://127.0.0.1:5090/api/v1/projects/demo/profile?engines=ast:1,pattern:1,iac-policy:1,secret:1"
    curl -s -X PUT -H 'content-type: application/json' \
         -d '{"name":"Demo","profileId":"default"}' \
         http://127.0.0.1:5090/api/v1/projects/demo
    # with OASIS_RULE_SERVER_TOKEN set, add: -H "x-oasis-token: $OASIS_RULE_SERVER_TOKEN"

A profile request without an `engines` parameter returns the rules without the scanner-compatibility check.

## Rules data model and how rules get into the database

Table `rules` (one row per rule): `id`, `version`, `language`, `engine` (`ast`, `pattern`, `iac-policy`, `secret`), `schema_version`, `severity` (`CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, `INFO`), `status` (`ACTIVE` or `DEPRECATED`), `origin`, `body` (the full rule JSON), `updated_at`. `origin` is `builtin` (authored here), `vendor` (ingested from an upstream source, carries `provenance`) or `user` (created through the API). Built-in and vendor rules are read-only apart from default severity.
Table `profiles` and `profile_rules` hold profiles and their per-rule overrides. Runtime tables: `findings`, `analyses`, `history`, `gates`, `baseline`, `projects`. The schema is created by `src/db.js` (`CREATE TABLE IF NOT EXISTS` plus small column migrations).

How rules arrive:

1. `seed/rules/<language>/*.json`: rules authored in this repo (one rule per file; 31 files: terraform, python, dockerfile, java, javascript, kubernetes).
2. `seed/rules/vendor/<source>/*.json`: generated by `node tools/ingest-rules.js [source] [--all] [--offline FILE]` from Gitleaks and Checkov (network access needed; do not edit by hand). The script deletes and rewrites each ingested source's directory, and has no `--help`: any run ingests. It also writes `THIRD_PARTY_LICENSES/`.
3. `node scripts/seed.js` imports those files (`src/seed.js`) and ensures the Default profile enables every non-user active rule. Re-seeding identical content changes nothing.
4. `POST /rules` adds user rules at runtime.

Shipped seed content: 296 rules (20 builtin AST, 11 builtin pattern, 44 vendor `iac-policy`, 221 vendor `secret`).

## Project structure

    src/            server code: server.js, api.js, db.js, config.js, rules.js, profiles.js, projects.js,
                    findings.js, analyses.js, gate.js, baseline.js, maintenance.js, engines.js, seed.js
    scripts/        seed.js (import rules), build-db-setup.js (regenerate db/setup SQL)
    tools/          ingest-rules.js and ingest/ (sources, adapters, TOML parser, attribution) plus tests
    seed/rules/     rule JSON (authored by language; vendor/ is generated)
    db/setup/       generated SQL to create and seed the database with sqlite3
    test/           node:test suites
    THIRD_PARTY_LICENSES/   licence texts and attribution for ingested rule sources
    oasis-rules.db  local SQLite database (git-ignored: *.db)

## Scripts

| Script | Command | Purpose |
|---|---|---|
| `npm start` | `node src/server.js` | Run the server |
| `npm run seed` | `node scripts/seed.js` | Import rules and create the Default profile |
| `npm test` | `node --test "test/**/*.test.js" "tools/**/*.test.js"` | Run all tests |
| `npm run db:setup:build` | `node scripts/build-db-setup.js` | Regenerate `db/setup/01_schema.sql` and `02_seed_data.sql` (`--check` verifies they are current) |

## Testing

    npm test

Last run: 295 tests, 295 pass, 0 fail. Tests use in-memory databases. `test/rule-corpus.test.js` checks every rule compiles and every authored rule detects its own example and stays silent on the fix; it needs `../oasis-analyzer`.

## Relationship to iready-oasis and oasis-analyzer

- iready-oasis is the scanner that fetches a project's profile from this server and runs the rules locally. `src/findings.js` and `src/gate.js` are ports of iready-oasis `server/security/store.js` (`mergeFindings`) and `gate.js` (`evaluateGate`) so both reach the same verdicts.
- oasis-analyzer is a dependency (`file:../oasis-analyzer`); the rule corpus test uses its AST and pattern engines to run the rules.

## Central release service

Besides the loopback SQLite server described above, this project holds the public, PostgreSQL-backed release API (`src/central-server.js`). It serves signed rule releases and their pack blobs; the Rule Studio (`oasis-rule-studio`) is what builds and signs them. It reads these settings (names only; values come from the environment), once, at start-up (`src/central-config.js`):

| Setting | Required | Default | Meaning |
|---|---|---|---|
| `RULES_DATABASE_URL` | yes | none | Rules database connection string. |
| `PACK_DIR` | yes | none | Folder of pack blobs; must be the same folder the Studio writes to. |
| `PORT` | no | `5091` | Listen port. |
| `TRUST_PROXY` | production | `0` | Number of proxies in front of the service; required when `NODE_ENV=production`. |
| `TLS_CERT_FILE`, `TLS_KEY_FILE` | together | none | Paths to a PEM certificate and key. When both are set the service serves HTTPS itself and sends HSTS; setting only one stops start-up. |
| `ALLOW_PLAIN_HTTP` | production without TLS | unset | Set to `1` only when your hosting platform terminates TLS before this service. With `NODE_ENV=production` and no TLS files, start-up fails without it. |
| `SHUTDOWN_TIMEOUT_MS` | no | `10000` | On SIGTERM or SIGINT the service stops accepting, drains in-flight requests, ends the database pool and exits; after this many milliseconds it cuts remaining connections and exits 1. |

`GET /v1/health` is liveness only (200 while the process is up, no database query); `GET /v1/ready` returns 503 unless a trivial database query succeeds and `PACK_DIR` is readable. Requests are logged as one JSON line (`method`, `path`, `status`, `ms`), never bodies, query strings or client addresses. Keep `.env` and `*.pem` files out of the repository (both are in `.gitignore`).

### How a release reaches the client

1. Staff write and test rules in the Rule Studio (`oasis-rule-studio`, port 4050; `npm run create-staff -- you@example.test admin` there creates the first staff member).
2. The Studio builds packs (one core engine pack and one pack per language) and signs the release manifest with an Ed25519 private key (`RELEASE_SIGNING_KEY_FILE`, `RELEASE_SIGNING_KEY_ID` in the Studio). Generate a key pair with `node scripts/gen-signing-key.js <private-key-path>`: it writes the private key (mode 0600) and prints only the public PEM. Keep the private key out of the repository.
3. This service publishes releases and blobs (`/v1/releases/latest`, `/v1/blobs/<sha256>`).
4. The OASIS client (opt-in `OASIS_ENGINE=installed`) checks on launch and every six hours, verifies the manifest signature against the public keys pinned in the app (`server/security/engine-loader/keys.js`, empty until the owner supplies them), checks each blob's hash and size, installs the release atomically and scans on that copy. Offline, it keeps using the installed release.
5. Findings stay on the client's machine. This service never receives findings, only serves rules.

### Database setup (PostgreSQL)

`db/setup/10_rules_schema.sql` is the rules database in one file, generated from `db/rules/*.sql` by `npm run db:setup:rules` (`node scripts/build-rules-db-setup.js --check` fails when it is stale). It also records the migration bookkeeping, so `npm run migrate:central` treats the files as applied. Run it on an empty database with `psql "$RULES_DATABASE_URL" -v ON_ERROR_STOP=1 -f db/setup/10_rules_schema.sql`, then `npm run seed:central`.

Scripts: `npm run migrate:central` (apply `db/rules/*.sql` to the rules database), `npm run seed:central` (load the language registry and the seed rules as active rules), `npm run start:central` (run the service). Nothing loads a `.env` file for these scripts: set the variables in the environment.

## Library entry

The rules core is also a library: `require('oasis-rule-server')` loads `src/index.js`, and `oasis-rule-server/testing` gives the fresh-database helper for tests. Rule Studio (staff sign-in, Studio API and UI) lives in the sibling project `oasis-rule-studio` and depends only on these entries. The 30 exported names:

`ENGINE_FALLBACKS`, `ENGINE_SCHEMA`, `MIN_LOADER`, `PILLARS`, `SEVERITIES`, `STATUSES`, `buildPacks`, `callerKey`, `canonical`, `coverage`, `createAudit`, `createBlobStore`, `createPool`, `createReleases`, `createRulesRepo`, `decodePack`, `encodePack`, `engineOf`, `isEmptyMatching`, `loadLanguages`, `migrate`, `rateLimit`, `seedLanguages`, `sha256`, `signManifest`, `stable`, `testRule`, `tx`, `validateRule`, `verifyManifest`.

Do not require internal paths (for example `oasis-rule-server/src/pg`): `package.json` `exports` blocks them, so internal files can be renamed freely. `test/library-exports.test.js` fails if an exported name is renamed or removed.

## Migration note

The identity tables (staff, session, role_permission) moved to the Studio. Any rules database that applied the old `001` or `002` migration must be rebuilt: the migrator refuses a changed applied file.

## Third-party licences

Vendor rules are derived from Gitleaks (MIT) and Checkov (Apache-2.0). Attribution and licence texts are in [THIRD_PARTY_LICENSES/](THIRD_PARTY_LICENSES/README.md). Rules from a source carry it in their `provenance` field. The SQL in `db/setup/02_seed_data.sql` contains those rules, so the same attribution applies to it.

## Troubleshooting

- Server unreachable on a different machine: it binds `127.0.0.1` by design.
- Seeded one database, server shows another: both use `OASIS_RULE_SERVER_DB` or `<repo>/oasis-rules.db`; check the path in the startup line.
- 401 `UNAUTHORIZED` on writes: `OASIS_RULE_SERVER_TOKEN` is set; send `x-oasis-token`.
- 403 `FORBIDDEN_ORIGIN`: a write came from a non-loopback browser origin.
- 422 `UNSUPPORTED_RULES`: the `engines` list is older than the active rules' engine versions; update the scanner or the profile.
- `npm install` fails on `oasis-analyzer`: clone it next to this repo.
- `Cannot find module 'node:sqlite'`: Node is older than 22.5.
- Running `tools/ingest-rules.js` for any reason rewrites `seed/rules/vendor/`; review the diff (upstream rule sets change).
