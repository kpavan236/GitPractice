CREATE TABLE language (
  id text PRIMARY KEY, name text NOT NULL, extensions text[] NOT NULL,
  engine_fallback text NOT NULL DEFAULT 'pattern', grammar jsonb, licence_note text
);
CREATE TABLE rule (
  rule_id text PRIMARY KEY, language text NOT NULL REFERENCES language(id),
  engine text NOT NULL, schema_version int NOT NULL DEFAULT 1,
  pillar text NOT NULL CHECK (pillar IN ('security','reliability','maintainability','code-quality')),
  severity text NOT NULL, origin text NOT NULL DEFAULT 'user',
  status text NOT NULL CHECK (status IN ('draft','proposed','active','deprecated')),
  version int NOT NULL DEFAULT 1, proposed_by text, body jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rule_by_language ON rule (language, status);
CREATE TABLE rule_version (
  rule_id text NOT NULL REFERENCES rule(rule_id), version int NOT NULL, body jsonb NOT NULL,
  changed_by text NOT NULL, reason text NOT NULL, changed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (rule_id, version)
);
CREATE TABLE pack (
  sha256 text PRIMARY KEY, kind text NOT NULL CHECK (kind IN ('core','language')),
  pack_id text NOT NULL, language text, version text NOT NULL, size int NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE release (
  release_no bigserial PRIMARY KEY, state text NOT NULL CHECK (state IN ('candidate','beta','stable','retired')),
  manifest jsonb NOT NULL, signature text NOT NULL, key_id text NOT NULL,
  created_by text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE channel (name text PRIMARY KEY CHECK (name IN ('beta','stable')), release_no bigint REFERENCES release(release_no));
INSERT INTO channel (name) VALUES ('beta'), ('stable');
CREATE TABLE audit (
  audit_id bigserial PRIMARY KEY, actor text NOT NULL, action text NOT NULL, subject text,
  reason text, outcome text NOT NULL, detail jsonb NOT NULL DEFAULT '{}', at timestamptz NOT NULL DEFAULT now()
);
