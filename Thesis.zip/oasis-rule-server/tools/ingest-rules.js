#!/usr/bin/env node
'use strict';
const fs = require('fs');
const https = require('https');
const path = require('path');
const { SOURCES, bySource } = require('./ingest/sources');
const { writeAttribution } = require('./ingest/attribution');

// Fetches upstream rule sets and converts them into OASIS rules.
//
//   node tools/ingest-rules.js                 → every redistributable source
//   node tools/ingest-rules.js gitleaks        → one source
//   node tools/ingest-rules.js --all           → include non-redistributable
//   node tools/ingest-rules.js --offline FILE  → convert a local file, no network
//
// Output goes to seed/rules/vendor/<source>/, which is REGENERATED and must not be
// hand-edited — anything written there is lost on the next run. Rules we author
// live in seed/rules/<language>/ and are never touched by this script.
//
// The separation matters for review as much as for tidiness: a diff under
// seed/rules/vendor is "upstream changed", a diff under seed/rules/java is "we decided
// something", and mixing them makes both unreviewable.

const ROOT = path.join(__dirname, '..');
const VENDOR_DIR = path.join(ROOT, 'seed', 'rules', 'vendor');
const TIMEOUT_MS = 30000;
const MAX_BYTES = 32 * 1024 * 1024;

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i !== -1 ? (process.argv[i + 1] || true) : null;
}

function get(url, { headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'i-Ready-OASIS-rule-ingest', ...headers } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(get(res.headers.location, { headers }));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', chunk => {
        body += chunk;
        if (body.length > MAX_BYTES) {
          req.destroy();
          reject(new Error('response too large'));
        }
      });
      res.on('end', () => resolve(body));
    });
    req.setTimeout(TIMEOUT_MS, () => req.destroy(new Error(`timed out fetching ${url}`)));
    req.on('error', reject);
  });
}

// A source whose rules are one-file-per-policy in a repository directory.
//
// Two hops: the contents API lists the directory, then each file is read from
// raw.githubusercontent. The listing endpoint is rate-limited to 60 requests an
// hour unauthenticated, so it is used once per DIRECTORY and never per file —
// fetching two hundred policies through it would exhaust the limit a third of
// the way in and leave a partial rule set that looked complete.
async function expandGithubDirs(urls) {
  const files = [];

  for (const url of urls) {
    let listing;
    try {
      listing = JSON.parse(await get(url, { headers: { Accept: 'application/vnd.github+json' } }));
    } catch (e) {
      throw new Error(`${url}: ${e.message}`);
    }
    if (!Array.isArray(listing)) throw new Error(`${url}: not a directory listing`);

    for (const entry of listing) {
      if (!entry || entry.type !== 'file' || !/\.ya?ml$/i.test(entry.name) || !entry.download_url) continue;
      const text = await get(entry.download_url);
      files.push({ name: entry.name, content: Buffer.from(text, 'utf8').toString('base64') });
    }
  }
  return files;
}

function loadAdapter(name) {
  try {
    return require(`./ingest/adapters/${name}`);
  } catch (e) {
    return null;
  }
}

// One file per rule, mirroring how authored rules are stored, so a reviewer
// reads the same shape in both trees and `git diff` on an upstream bump names
// the rules that changed instead of one enormous blob.
function writeRules(sourceId, rules) {
  const dir = path.join(VENDOR_DIR, sourceId);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });

  for (const rule of rules) {
    const safe = String(rule.id).replace(/[^A-Za-z0-9._-]/g, '_');
    fs.writeFileSync(path.join(dir, `${safe}.json`), `${JSON.stringify(rule, null, 2)}\n`);
  }
  return dir;
}

async function ingestSource(source, { offlineFile = null } = {}) {
  const adapter = loadAdapter(source.adapter);
  if (!adapter || typeof adapter.ingest !== 'function') {
    return { source, error: `no adapter implemented for "${source.adapter}"` };
  }

  let raw;
  try {
    if (offlineFile) raw = fs.readFileSync(offlineFile, 'utf8');
    else if (source.expand === 'github-dir') raw = JSON.stringify(await expandGithubDirs(source.urls || [source.url]));
    else raw = await get(source.url);
  } catch (e) {
    // A source that cannot be reached leaves the previously ingested rules in
    // place. The alternative — wiping them because a CDN was down — would turn
    // a network blip into a silent loss of detection.
    return { source, error: e.message };
  }

  let result;
  try {
    result = adapter.ingest(raw, source);
  } catch (e) {
    return { source, error: `adapter failed: ${e.message}` };
  }

  const dir = writeRules(source.id, result.rules);
  return { source, ...result, dir };
}

async function main() {
  const wanted = process.argv.slice(2).filter(a => !a.startsWith('--'));
  const includeAll = Boolean(arg('all'));
  const offlineFile = arg('offline');

  let selected = wanted.length ? wanted.map(bySource).filter(Boolean) : SOURCES.filter(s => !s.artifact);
  if (wanted.length && selected.length !== wanted.length) {
    console.error(`Unknown source. Known: ${SOURCES.map(s => s.id).join(', ')}`);
    process.exit(1);
  }

  // Non-redistributable sources are opt-in per run AND excluded when the
  // rules are seeded (scripts/seed.js). Two gates rather than one, because the cost of
  // getting this wrong is a licence violation shipped to every install.
  const blocked = selected.filter(s => !s.redistributable && !includeAll);
  selected = selected.filter(s => s.redistributable || includeAll);

  console.log(`▶ Ingesting ${selected.length} source(s)\n`);

  const results = [];
  for (const source of selected) {
    if (source.licenseWarning) {
      console.log(`  ⚠ ${source.name}: ${source.licenseWarning}\n`);
    }
    const result = await ingestSource(source, { offlineFile: selected.length === 1 ? offlineFile : null });
    results.push(result);

    if (result.error) {
      console.error(`  ✗ ${source.name}: ${result.error}`);
      continue;
    }
    const note = source.partial ? `  (${source.partial})` : '';
    console.log(`  ✓ ${source.name} — ${result.rules.length} of ${result.total} rules${note}`);
    if (result.skipped.length) {
      console.log(`    ${result.skipped.length} skipped:`);
      for (const s of result.skipped.slice(0, 5)) console.log(`      ${s.id}: ${s.reason}`);
      if (result.skipped.length > 5) console.log(`      …and ${result.skipped.length - 5} more`);
    }
  }

  for (const source of blocked) {
    console.log(`  − ${source.name} skipped: not redistributable (use --all to ingest locally)`);
  }

  const ingested = results.filter(r => !r.error);
  if (ingested.length) {
    const attributionDir = await writeAttribution(ingested.map(r => r.source), { root: ROOT, fetch: get, all: SOURCES.filter(s => s.redistributable) });
    console.log(`\n  Attribution written to ${path.relative(ROOT, attributionDir)}/`);
  }

  const failed = results.filter(r => r.error);
  console.log(
    `\n✓ ${ingested.reduce((n, r) => n + r.rules.length, 0)} rules under ${path.relative(ROOT, VENDOR_DIR)}/`
  );
  console.log('  Next: npm test   (compiles and checks every rule), then node scripts/seed.js');

  // A failed source is not a failed build — the previous rules are still there
  // — but it must not pass silently in CI either.
  if (failed.length) process.exitCode = 1;
}

if (require.main === module) {
  main().catch(e => {
    console.error(e.message);
    process.exit(1);
  });
}

module.exports = { ingestSource, writeRules, VENDOR_DIR };
