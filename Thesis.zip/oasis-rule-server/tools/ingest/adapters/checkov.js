'use strict';
const yaml = require('js-yaml');

// Checkov (Apache 2.0) → OASIS IaC policy rules.
//
// Checkov's BUILT-IN checks are Python classes. They cannot be ingested by a
// Node engine at all, and any pipeline claiming to "ingest Checkov" without
// saying so is ingesting almost nothing. What is data — and therefore genuinely
// portable — is Checkov's YAML custom-policy format: a metadata block and a
// definition tree of attribute conditions over resource types.
//
// So this adapter converts YAML policies, and the Python checks remain a
// porting job done as our own rules with attribution. That distinction is
// stated in sources.js as `partial` and printed by the ingest run, because a
// tool that overstates its coverage is worse than one with less of it.
//
// ONE SEMANTIC INVERSION MATTERS. A Checkov definition describes the state the
// world SHOULD be in — "encryption is enabled" — and Checkov reports a failure
// when it does not hold. Our rules fire when they MATCH. So a policy is stored
// as its assertion and the evaluator raises a finding when the assertion is
// FALSE for a resource in scope. Getting this backwards would report every
// correctly-configured resource and stay silent on the broken ones, which is
// the most damaging way a security tool can be wrong.

// Operators we can evaluate. Anything outside this set is refused rather than
// approximated — a policy silently evaluated with the wrong operator produces
// confident, wrong answers.
const SUPPORTED_OPERATORS = new Set([
  'equals', 'not_equals',
  'regex_match', 'not_regex_match',
  'exists', 'not_exists',
  'contains', 'not_contains',
  'within', 'not_within',
  'starting_with', 'not_starting_with',
  'ending_with', 'not_ending_with',
  'greater_than', 'greater_than_or_equal',
  'less_than', 'less_than_or_equal',
  'is_empty', 'is_not_empty',
  'is_true', 'is_false',
  'length_equals', 'length_greater_than', 'length_less_than',
  'subset', 'not_subset',
  'intersects', 'not_intersects',
]);

const SEVERITIES = new Set(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']);

class UnsupportedPolicy extends Error {}

/**
 * Normalises a Checkov definition tree into our own.
 *
 * Throws UnsupportedPolicy for anything we cannot evaluate correctly. The
 * caller turns that into a reported skip, exactly like a Gitleaks regex that
 * will not compile.
 */
function normalise(node) {
  if (!node || typeof node !== 'object') throw new UnsupportedPolicy('empty definition');

  for (const junction of ['and', 'or']) {
    if (Array.isArray(node[junction])) {
      return { op: junction, children: node[junction].map(normalise) };
    }
  }
  if (node.not) return { op: 'not', children: [normalise(node.not)] };

  const condType = node.cond_type;

  // A connection condition asks whether one resource REFERENCES another, which
  // needs a resolved resource graph — every reference, variable and module
  // output followed. We do not build one, and a connection check evaluated
  // without a graph would answer "no connection" for everything and fail every
  // resource it touched. Refused.
  if (condType === 'connection') {
    throw new UnsupportedPolicy('connection conditions need a resource graph');
  }

  if (condType === 'filter' || condType === 'resource') {
    return {
      op: 'filter',
      attribute: node.attribute || 'resource_type',
      operator: node.operator || 'within',
      value: node.value,
    };
  }

  if (condType !== 'attribute') {
    throw new UnsupportedPolicy(`unsupported cond_type "${condType}"`);
  }

  if (!SUPPORTED_OPERATORS.has(node.operator)) {
    throw new UnsupportedPolicy(`unsupported operator "${node.operator}"`);
  }
  if (!node.attribute) throw new UnsupportedPolicy('attribute condition has no attribute');

  return {
    op: 'attribute',
    resourceTypes: [].concat(node.resource_types || []).map(String),
    attribute: String(node.attribute),
    operator: node.operator,
    value: node.value,
  };
}

// Every resource type the policy mentions, so the scanner can skip a document
// without walking its whole condition tree.
function resourceTypesIn(node, out = new Set()) {
  if (!node || typeof node !== 'object') return out;
  for (const t of node.resourceTypes || []) out.add(t);
  if (node.op === 'filter' && node.attribute === 'resource_type') {
    for (const t of [].concat(node.value || [])) out.add(String(t));
  }
  for (const child of node.children || []) resourceTypesIn(child, out);
  return out;
}

function severityOf(metadata) {
  const declared = String(metadata.severity || '').toUpperCase();
  // Checkov policies frequently omit severity. MEDIUM rather than HIGH: an
  // imported policy with no stated severity has not earned a place above
  // findings whose severity someone actually chose.
  return SEVERITIES.has(declared) ? declared : 'MEDIUM';
}

function toRule(policy, source, ingestedAt) {
  const metadata = policy.metadata || {};
  if (!metadata.id) throw new UnsupportedPolicy('policy has no metadata.id');
  if (!policy.definition) throw new UnsupportedPolicy('policy has no definition');

  const definition = normalise(policy.definition);
  const resourceTypes = [...resourceTypesIn(definition)];
  if (!resourceTypes.length) {
    // Without a resource type the policy has no scope, so it would be evaluated
    // against every resource in every file.
    throw new UnsupportedPolicy('policy names no resource types');
  }

  return {
    id: `checkov-${metadata.id}`,
    language: 'iac',
    type: 'IAC',
    engine: 'iac-policy',
    severity: severityOf(metadata),
    confidence: 'HIGH',
    category: String(metadata.category || 'IAC_POLICY').toUpperCase().replace(/[^A-Z0-9]+/g, '_'),
    title: metadata.name || metadata.id,
    description:
      `${metadata.name || metadata.id}. This resource does not satisfy the policy.`,
    remediation: metadata.guideline
      ? `See ${metadata.guideline}`
      : 'Change the resource so it satisfies the policy condition above.',
    resourceTypes,
    // The assertion. A finding is raised when this is FALSE for a resource in
    // scope — see the header.
    definition,
    provenance: {
      source: source.id,
      sourceName: source.name,
      upstreamId: metadata.id,
      license: source.license,
      sourceUrl: source.url,
      homepage: source.homepage,
      ingestedAt,
    },
  };
}

/**
 * @param {string} raw     one or more YAML policy documents, or a JSON array of
 *                         { name, content } from a GitHub contents listing
 * @param {object} source  the row from sources.js
 */
function ingest(raw, source) {
  const ingestedAt = new Date().toISOString();
  const rules = [];
  const skipped = [];

  // Two shapes reach this function: a directory listing fetched from the GitHub
  // API, and a plain YAML file handed over with --offline. Supporting both is
  // what makes the offline path a real path rather than a demo.
  let documents = [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      documents = parsed
        .filter(f => f && typeof f.content === 'string' && /\.ya?ml$/i.test(f.name || ''))
        .map(f => ({ name: f.name, text: Buffer.from(f.content, 'base64').toString('utf8') }));
    }
  } catch (_) {
    documents = [{ name: 'policy.yaml', text: String(raw || '') }];
  }

  for (const doc of documents) {
    let policies;
    try {
      policies = yaml.loadAll(doc.text).filter(Boolean);
    } catch (e) {
      skipped.push({ id: doc.name, reason: `unreadable YAML: ${e.message.split('\n')[0]}` });
      continue;
    }

    for (const policy of policies) {
      const id = (policy && policy.metadata && policy.metadata.id) || doc.name;
      try {
        rules.push(toRule(policy, source, ingestedAt));
      } catch (e) {
        if (e instanceof UnsupportedPolicy) skipped.push({ id, reason: e.message });
        else skipped.push({ id, reason: `could not convert: ${e.message}` });
      }
    }
  }

  return { rules, skipped, total: rules.length + skipped.length };
}

module.exports = { ingest, normalise, toRule, resourceTypesIn, severityOf, UnsupportedPolicy, SUPPORTED_OPERATORS };
