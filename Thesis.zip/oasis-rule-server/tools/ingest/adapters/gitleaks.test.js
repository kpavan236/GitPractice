'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { ingest, translateGoRegex, severityFor, allowlistOf } = require('./gitleaks');

const SOURCE = {
  id: 'gitleaks',
  name: 'Gitleaks',
  license: 'MIT',
  url: 'https://example.invalid/gitleaks.toml',
  homepage: 'https://github.com/gitleaks/gitleaks',
};

// Gitleaks is Go, and Go's regexp is RE2. The dialects agree on most syntax and
// disagree on exactly the constructs gitleaks uses most, so the translation is
// where this adapter is either correct or quietly useless.

test('(?i) at the start becomes a real JavaScript flag', () => {
  // The single most common construct in gitleaks.toml. JavaScript has no inline
  // form, so untranslated it is a syntax error and the rule would be dropped.
  const out = translateGoRegex('(?i)AKIA[0-9A-Z]{16}');
  assert.equal(out.error, undefined);
  assert.equal(out.source, 'AKIA[0-9A-Z]{16}');
  assert.equal(out.flags, 'i');
  assert.ok(new RegExp(out.source, out.flags).test('akia0000000000000000'));
});

test('combined leading flags are all carried across', () => {
  const out = translateGoRegex('(?is)secret.*value');
  assert.equal(out.flags, 'is');
  assert.equal(out.source, 'secret.*value');
});

test('Go named groups are rewritten', () => {
  const out = translateGoRegex('(?P<token>ghp_[0-9a-zA-Z]{36})');
  assert.equal(out.error, undefined);
  assert.equal(out.source, '(?<token>ghp_[0-9a-zA-Z]{36})');
});

test('POSIX classes are expanded', () => {
  const out = translateGoRegex('[[:alnum:]]{20}');
  assert.equal(out.error, undefined);
  assert.ok(new RegExp(out.source).test('abcdefghij0123456789'));
});

test('Go absolute anchors become JavaScript anchors', () => {
  const out = translateGoRegex('\\Atoken\\z');
  assert.equal(out.source, '^token$');
});

test('a mid-pattern (?i) is hoisted, and the widening is recorded', () => {
  // Real gitleaks patterns do this: `dp\.pt\.(?i)[a-z0-9]{43}` is
  // case-sensitive up to the prefix and insensitive after it. JavaScript cannot
  // say that. Rejecting outright dropped 23 real rules, and a dropped secret
  // rule is a MISS; hoisting only ever matches MORE, so the failure mode
  // becomes a false positive instead of an undetected credential.
  const out = translateGoRegex(String.raw`dp\.pt\.(?i)[a-z0-9]{43}`);
  assert.equal(out.error, undefined);
  assert.equal(out.flags, 'i');
  assert.equal(out.widened, true);
  assert.ok(new RegExp(out.source, out.flags).test(`dp.pt.${'A'.repeat(43)}`));
  // …and it still matches everything upstream matched.
  assert.ok(new RegExp(out.source, out.flags).test(`dp.pt.${'a'.repeat(43)}`));
});

test('a mid-pattern (?m) is refused, because it is not a widening', () => {
  // `m` changes what ^ and $ mean. That can match DIFFERENT things, including
  // fewer, so it cannot be hoisted the way `i` and `s` can.
  const out = translateGoRegex('abc(?m)^def');
  assert.match(out.error, /\(\?m\)/);
});

test('an unwidened pattern is not marked as widened', () => {
  assert.equal(translateGoRegex('(?i)AKIA[0-9A-Z]{16}').widened, false);
});

test('every accepted pattern has been compiled', () => {
  // The guarantee this adapter makes. A pattern that fails to compile at
  // runtime disables itself silently, and a secret scanner that quietly stopped
  // checking is worse than one that never claimed to.
  assert.match(translateGoRegex('([unclosed').error, /does not compile/);
  assert.match(translateGoRegex('a{2,1}').error, /does not compile/);
  assert.equal(translateGoRegex('').error, 'empty pattern');
});

// ── Rule conversion ────────────────────────────────────────────────────────

const TOML = String.raw`
title = "gitleaks config"

[[rules]]
id = "aws-access-token"
description = "AWS Access Token"
regex = '''(?i)(A3T[A-Z0-9]|AKIA|ASIA)[A-Z0-9]{16}'''
keywords = ["akia", "asia"]
entropy = 3.5

[[rules]]
id = "generic-api-key"
description = "Generic API Key"
regex = '''(?i)api[_-]?key['"]?\s*[:=]\s*['"]([0-9a-z]{32,})['"]'''
secretGroup = 1
[rules.allowlist]
regexes = ['''example''']
paths = ['''(.*?)(test|spec)(.*?)''']
stopwords = ["placeholder"]

[[rules]]
id = "keyword-only"
description = "No regex on this one"
keywords = ["nope"]

[[rules]]
id = "broken-regex"
description = "Cannot compile"
regex = '''([unclosed'''
`;

test('converts a gitleaks config into OASIS secret rules', () => {
  const { rules, skipped, total } = ingest(TOML, SOURCE);

  assert.equal(total, 4);
  assert.equal(rules.length, 2);
  assert.deepEqual(rules.map(r => r.id), ['gitleaks-aws-access-token', 'gitleaks-generic-api-key']);

  const aws = rules[0];
  assert.equal(aws.type, 'SECRET');
  // The discriminator that keeps secret patterns away from the generic line
  // scanner, which does not mask what it finds.
  assert.equal(aws.engine, 'secret');
  assert.equal(aws.patternFlags, 'i');
  assert.equal(aws.entropy, 3.5);
  assert.deepEqual(aws.keywords, ['akia', 'asia']);
  assert.equal(aws.cwe, 'CWE-798');
  assert.ok(new RegExp(aws.pattern, aws.patternFlags).test('AKIA0123456789ABCDEF'));
});

test('a rule that cannot be ingested is reported by id, never emitted', () => {
  const { skipped } = ingest(TOML, SOURCE);
  const ids = skipped.map(s => s.id);
  assert.deepEqual(ids.sort(), ['broken-regex', 'keyword-only']);
  assert.ok(skipped.every(s => s.reason), 'every skip states why');
});

test('every rule carries provenance and its licence', () => {
  // What makes THIRD_PARTY_LICENSES generatable rather than hand-maintained,
  // and what lets a finding say which upstream rule produced it.
  const { rules } = ingest(TOML, SOURCE);
  for (const rule of rules) {
    assert.equal(rule.provenance.source, 'gitleaks');
    assert.equal(rule.provenance.license, 'MIT');
    assert.ok(rule.provenance.upstreamId);
    assert.ok(rule.provenance.ingestedAt);
  }
  assert.equal(rules[0].provenance.upstreamId, 'aws-access-token');
});

test('allowlists are carried across and compiled', () => {
  const { rules } = ingest(TOML, SOURCE);
  const generic = rules.find(r => r.id === 'gitleaks-generic-api-key');
  assert.deepEqual(generic.allowlist.stopwords, ['placeholder']);
  assert.equal(generic.allowlist.regexes.length, 1);
  assert.equal(generic.secretGroup, 1);
});

test('reads the newer allowlists array as well as the older table', () => {
  // Losing an exclusion because upstream changed shape means false positives we
  // already knew about coming back.
  const merged = allowlistOf({
    allowlist: { stopwords: ['old'] },
    allowlists: [{ stopwords: ['new'], paths: ['vendor/'] }],
  });
  assert.deepEqual(merged.stopwords, ['old', 'new']);
  assert.deepEqual(merged.paths, ['vendor/']);
});

test('high-impact providers outrank generic secrets', () => {
  assert.equal(severityFor({ id: 'aws-access-token' }), 'CRITICAL');
  assert.equal(severityFor({ id: 'private-key', description: 'Private Key' }), 'CRITICAL');
  assert.equal(severityFor({ id: 'some-vendor-token', description: 'Vendor token' }), 'HIGH');
});

test('an empty or ruleless config yields nothing and does not throw', () => {
  assert.deepEqual(ingest('', SOURCE).rules, []);
  assert.deepEqual(ingest('title = "x"', SOURCE).rules, []);
});
