'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { ingest, normalise, UnsupportedPolicy } = require('./checkov');
const { satisfies } = require('oasis-analyzer/src/iac/evaluate');

const SOURCE = {
  id: 'checkov',
  name: 'Checkov',
  license: 'Apache-2.0',
  url: 'https://example.invalid/checkov',
  homepage: 'https://github.com/bridgecrewio/checkov',
};

const POLICY = `
metadata:
  id: "CKV2_CUSTOM_1"
  name: "S3 bucket must not be public"
  category: "NETWORKING"
  severity: "HIGH"
  guideline: "https://docs.example.com/s3"
definition:
  cond_type: "attribute"
  resource_types:
    - "aws_s3_bucket"
  attribute: "acl"
  operator: "not_equals"
  value: "public-read"
`;

test('converts a Checkov YAML policy into a rule', () => {
  const { rules, skipped } = ingest(POLICY, SOURCE);
  assert.deepEqual(skipped, []);
  assert.equal(rules.length, 1);

  const rule = rules[0];
  assert.equal(rule.id, 'checkov-CKV2_CUSTOM_1');
  assert.equal(rule.engine, 'iac-policy');
  assert.equal(rule.type, 'IAC');
  assert.equal(rule.severity, 'HIGH');
  assert.deepEqual(rule.resourceTypes, ['aws_s3_bucket']);
  assert.match(rule.remediation, /docs\.example\.com/);
  assert.equal(rule.provenance.license, 'Apache-2.0');
  assert.equal(rule.provenance.upstreamId, 'CKV2_CUSTOM_1');
});

test('the converted rule evaluates the way Checkov intends', () => {
  // The end-to-end property: an ingested policy must reach the same verdict the
  // upstream tool would. A policy states what SHOULD hold, and a finding is
  // raised when it does not.
  const [rule] = ingest(POLICY, SOURCE).rules;
  const bucket = body => ({ type: 'aws_s3_bucket', name: 'b', file: 'x.tf', line: 1, body });

  assert.equal(satisfies(rule.definition, bucket({ acl: 'private' })), true);
  assert.equal(satisfies(rule.definition, bucket({ acl: 'public-read' })), false);
});

test('nested and / or / not trees are normalised', () => {
  const nested = normalise({
    and: [
      { cond_type: 'attribute', resource_types: ['aws_elb'], attribute: 'a', operator: 'is_true' },
      {
        or: [
          { cond_type: 'attribute', resource_types: ['aws_elb'], attribute: 'b', operator: 'exists' },
          { not: { cond_type: 'attribute', resource_types: ['aws_elb'], attribute: 'c', operator: 'exists' } },
        ],
      },
    ],
  });

  assert.equal(nested.op, 'and');
  assert.equal(nested.children.length, 2);
  assert.equal(nested.children[1].op, 'or');
  assert.equal(nested.children[1].children[1].op, 'not');
});

test('a connection condition is refused, not faked', () => {
  // A connection check asks whether one resource references another, which
  // needs a resolved resource graph. Evaluated without one it would answer "no
  // connection" for everything and fail every resource it touched.
  assert.throws(
    () => normalise({ cond_type: 'connection', resource_types: ['aws_elb'], operator: 'exists' }),
    UnsupportedPolicy
  );

  const { rules, skipped } = ingest(`
metadata:
  id: "CKV2_CONN"
  name: "Needs a graph"
definition:
  cond_type: "connection"
  resource_types: ["aws_elb"]
  connected_resource_types: ["aws_security_group"]
  operator: "exists"
`, SOURCE);

  assert.deepEqual(rules, []);
  assert.equal(skipped.length, 1);
  assert.match(skipped[0].reason, /resource graph/);
});

test('an unsupported operator is refused rather than approximated', () => {
  const { rules, skipped } = ingest(`
metadata:
  id: "CKV2_OP"
  name: "Unknown operator"
definition:
  cond_type: "attribute"
  resource_types: ["aws_s3_bucket"]
  attribute: "acl"
  operator: "telepathy"
`, SOURCE);
  assert.deepEqual(rules, []);
  assert.match(skipped[0].reason, /unsupported operator/);
});

test('a policy with no resource types is refused', () => {
  // Without a scope it would be evaluated against every resource in every file.
  const { rules, skipped } = ingest(`
metadata:
  id: "CKV2_NOSCOPE"
  name: "No scope"
definition:
  cond_type: "attribute"
  attribute: "acl"
  operator: "exists"
`, SOURCE);
  assert.deepEqual(rules, []);
  assert.match(skipped[0].reason, /resource types/);
});

test('a missing severity defaults down, not up', () => {
  // An imported policy that never stated a severity has not earned a place
  // above findings whose severity someone actually chose.
  const { rules } = ingest(`
metadata:
  id: "CKV2_NOSEV"
  name: "No severity"
definition:
  cond_type: "attribute"
  resource_types: ["aws_s3_bucket"]
  attribute: "acl"
  operator: "exists"
`, SOURCE);
  assert.equal(rules[0].severity, 'MEDIUM');
});

test('reads a GitHub contents listing as well as a plain file', () => {
  // The network path fetches a directory listing; --offline hands over one
  // file. Both are real paths, so both are supported.
  const listing = JSON.stringify([
    { name: 'policy.yaml', content: Buffer.from(POLICY).toString('base64') },
    { name: 'README.md', content: Buffer.from('# not a policy').toString('base64') },
  ]);
  const { rules } = ingest(listing, SOURCE);
  assert.equal(rules.length, 1);
  assert.equal(rules[0].id, 'checkov-CKV2_CUSTOM_1');
});

test('unreadable YAML is reported, not thrown', () => {
  const { rules, skipped } = ingest('metadata:\n  - [unclosed\n', SOURCE);
  assert.deepEqual(rules, []);
  assert.equal(skipped.length, 1);
});

test('an empty input yields nothing', () => {
  assert.deepEqual(ingest('', SOURCE).rules, []);
  assert.deepEqual(ingest(null, SOURCE).rules, []);
});
