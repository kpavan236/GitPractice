'use strict';
const { parseToml } = require('../toml');

// Gitleaks (MIT) → OASIS secret rules.
//
// The rules are data, so this is a real ingestion rather than a porting job.
// The one thing that is NOT free is the regex dialect: gitleaks is Go, and Go's
// regexp is RE2. RE2 and JavaScript agree on most syntax and disagree on enough
// to matter, so every pattern is translated and then COMPILED before it is
// accepted. A pattern that cannot be compiled is dropped and reported by id —
// never emitted — because a rule that fails to compile at runtime disables
// itself silently, and a secret scanner that silently stopped checking for AWS
// keys is worse than one that never claimed to.

// Go inline flags at the start of a pattern: (?i), (?is), (?im)…
const LEADING_FLAGS = /^\(\?([ims]+)\)/;

const POSIX_CLASSES = {
  '[:alpha:]': 'A-Za-z',
  '[:digit:]': '0-9',
  '[:alnum:]': 'A-Za-z0-9',
  '[:upper:]': 'A-Z',
  '[:lower:]': 'a-z',
  '[:space:]': '\\s',
  '[:word:]': '\\w',
  '[:xdigit:]': '0-9A-Fa-f',
  '[:punct:]': '!-/:-@\\[-`{-~',
};

/**
 * Translates a Go/RE2 pattern into an equivalent JavaScript one.
 *
 * Returns { source, flags, error }. `error` set means the rule must be dropped:
 * this function never returns a pattern it has not itself compiled.
 */
function translateGoRegex(pattern) {
  let source = String(pattern == null ? '' : pattern);
  if (!source) return { error: 'empty pattern' };

  let flags = '';

  // (?i) at the start becomes a real flag. This is by far the most common
  // construct in gitleaks.toml, and JavaScript has no inline form of it.
  const leading = LEADING_FLAGS.exec(source);
  if (leading) {
    for (const flag of leading[1]) {
      // Go's `s` (dot matches newline) is JavaScript's `s`; `m` and `i` match.
      if (!flags.includes(flag)) flags += flag;
    }
    source = source.slice(leading[0].length);
  }

  // A flag group anywhere else sets the flag for the rest of its enclosing
  // group — `dp\.pt\.(?i)[a-z0-9]{43}` is case-sensitive up to the prefix and
  // insensitive after it. JavaScript has no way to say that.
  //
  // Rejecting outright cost 23 real rules (Adobe, Alibaba, Doppler and others),
  // and a dropped secret rule is a MISS. Hoisting the flag to the whole pattern
  // is a widening: `i` and `s` can only ever make a regex match a superset of
  // what it matched before, so the failure mode becomes an occasional false
  // positive rather than an undetected credential. That is the right direction
  // for a secret scanner, and the rule is marked so the change is visible.
  //
  // `m` is NOT hoisted: it changes what ^ and $ mean, which is not a widening —
  // it can match different things, including fewer.
  let widened = false;
  const inline = source.match(/\(\?([ims]+)\)/g) || [];
  if (inline.length) {
    const letters = new Set(inline.join('').replace(/[()?]/g, ''));
    if (letters.has('m')) {
      return { error: 'inline (?m) changes anchor meaning and cannot be hoisted' };
    }
    for (const flag of letters) if (!flags.includes(flag)) flags += flag;
    source = source.replace(/\(\?[is]+\)/g, '');
    widened = true;
  }

  // Go named groups are (?P<name>…); JavaScript uses (?<name>…).
  source = source.replace(/\(\?P</g, '(?<');

  // POSIX character classes exist in RE2 and not in JavaScript.
  for (const [posix, replacement] of Object.entries(POSIX_CLASSES)) {
    source = source.split(posix).join(replacement);
  }

  // Go's absolute anchors.
  source = source.replace(/\\A/g, '^').replace(/\\z/g, '$').replace(/\\Z/g, '$');

  try {
    // The acceptance test. Anything that survives this is known to run.
    // eslint-disable-next-line no-new
    new RegExp(source, flags);
  } catch (e) {
    return { error: `does not compile in JavaScript: ${e.message}` };
  }

  return { source, flags, widened };
}

// Gitleaks carries no severity. Almost every secret is worth acting on, so the
// floor is HIGH rather than MEDIUM; the handful below are the ones where a leak
// is immediately and totally exploitable, and they are called out so a triage
// queue sorted by severity puts them first.
const CRITICAL = /private[-_ ]?key|aws|gcp|azure|stripe[-_ ]?live|slack[-_ ]?token|github[-_ ]?pat|npm[-_ ]?token|database[-_ ]?url/i;

function severityFor(rule) {
  const text = `${rule.id || ''} ${rule.description || ''}`;
  return CRITICAL.test(text) ? 'CRITICAL' : 'HIGH';
}

function categoryFor(rule) {
  return String(rule.id || 'SECRET')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 60);
}

// Gitleaks has carried both `[rules.allowlist]` and, more recently, an
// `allowlists` array. Both are read: a config that used the newer form would
// otherwise lose its exclusions and produce false positives we already know
// about.
function allowlistOf(rule) {
  const lists = []
    .concat(rule.allowlist ? [rule.allowlist] : [])
    .concat(Array.isArray(rule.allowlists) ? rule.allowlists : []);
  if (!lists.length) return null;

  const merged = { regexes: [], paths: [], stopwords: [] };
  for (const list of lists) {
    for (const key of ['regexes', 'paths', 'stopwords']) {
      for (const value of list[key] || []) merged[key].push(String(value));
    }
  }
  // Allowlist regexes go through the same translation and the same compile
  // check. One that does not compile is dropped rather than failing the rule —
  // losing an exclusion costs a false positive, losing the rule costs a miss.
  merged.regexes = merged.regexes
    .map(r => translateGoRegex(r))
    .filter(r => !r.error)
    .map(r => r.source);

  return merged.regexes.length || merged.paths.length || merged.stopwords.length ? merged : null;
}

/**
 * @param {string} toml     the raw gitleaks.toml
 * @param {object} source   the row from sources.js
 * @returns {{ rules: Array, skipped: Array, total: number }}
 */
function ingest(toml, source) {
  const config = parseToml(toml);
  const upstream = Array.isArray(config.rules) ? config.rules : [];

  const rules = [];
  const skipped = [];
  const ingestedAt = new Date().toISOString();

  for (const rule of upstream) {
    if (!rule || !rule.id) {
      skipped.push({ id: '(no id)', reason: 'rule has no id' });
      continue;
    }
    if (!rule.regex) {
      // Gitleaks allows a keyword-only rule; we have no engine for one, and
      // saying so beats emitting a rule that matches nothing.
      skipped.push({ id: rule.id, reason: 'no regex' });
      continue;
    }

    const translated = translateGoRegex(rule.regex);
    if (translated.error) {
      skipped.push({ id: rule.id, reason: translated.error });
      continue;
    }

    const allowlist = allowlistOf(rule);

    rules.push({
      // Namespaced so an upstream id can never collide with one of ours, and so
      // a finding's rule id says where the rule came from.
      id: `gitleaks-${rule.id}`,
      language: 'secrets',
      type: 'SECRET',
      // The discriminator that decides which engine runs this rule. Without it
      // a secret pattern would be picked up by the generic line-pattern
      // scanner, which does not mask or hash what it finds — and a secret
      // written into the findings file in plaintext turns a security tool into
      // a second copy of the leak.
      engine: 'secret',
      files: ['**/*'],
      pattern: translated.source,
      patternFlags: translated.flags,
      // True when a mid-pattern (?i)/(?s) was hoisted to the whole pattern. The
      // rule matches a superset of what upstream matches, so a surprising hit
      // has a documented explanation rather than looking like a bug.
      widenedFromInlineFlags: translated.widened || undefined,
      // Gitleaks uses keywords as a cheap prefilter: if none appear in the
      // file, the regex is never run. Worth keeping — it is most of why
      // gitleaks is fast over large histories.
      keywords: Array.isArray(rule.keywords) ? rule.keywords.map(k => String(k).toLowerCase()) : [],
      entropy: typeof rule.entropy === 'number' ? rule.entropy : null,
      secretGroup: typeof rule.secretGroup === 'number' ? rule.secretGroup : null,
      allowlist,
      severity: severityFor(rule),
      confidence: rule.entropy ? 'HIGH' : 'MEDIUM',
      category: categoryFor(rule),
      cwe: 'CWE-798',
      owasp: 'A07:2021-Identification and Authentication Failures',
      title: rule.description || rule.id,
      description:
        `${rule.description || rule.id}. A credential matching this provider's format appears in the source.`,
      remediation:
        'Revoke and rotate the credential — removing it from the file is not enough, because it '
        + 'remains in git history and in any clone. Then move it to the secret store.',

      // Provenance. Every ingested rule can name where it came from and under
      // what licence, which is what makes the attribution file generatable
      // rather than hand-maintained.
      provenance: {
        source: source.id,
        sourceName: source.name,
        upstreamId: rule.id,
        license: source.license,
        sourceUrl: source.url,
        homepage: source.homepage,
        ingestedAt,
      },
    });
  }

  return { rules, skipped, total: upstream.length };
}

module.exports = { ingest, translateGoRegex, severityFor, categoryFor, allowlistOf, POSIX_CLASSES };
