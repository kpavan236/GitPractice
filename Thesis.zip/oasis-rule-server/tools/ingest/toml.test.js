'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseToml, TomlError } = require('./toml');

// gitleaks.toml is the rule set, so a parser bug here is a silently wrong rule
// set — not a crash. These tests are shaped around the constructs that file
// actually uses, and around the one mistake that would corrupt nearly every
// rule in it.

test('parses the shape of a gitleaks rule file', () => {
  const config = parseToml(`
title = "gitleaks config"

[extend]
useDefault = true

[[rules]]
id = "aws-access-token"
description = "AWS Access Token"
regex = '''(A3T[A-Z0-9]|AKIA|ASIA)[A-Z0-9]{16}'''
keywords = ["akia", "asia"]
entropy = 3.5

[[rules]]
id = "github-pat"
description = "GitHub Personal Access Token"
regex = '''ghp_[0-9a-zA-Z]{36}'''
`);

  assert.equal(config.title, 'gitleaks config');
  assert.equal(config.extend.useDefault, true);
  assert.equal(config.rules.length, 2);
  assert.equal(config.rules[0].id, 'aws-access-token');
  assert.deepEqual(config.rules[0].keywords, ['akia', 'asia']);
  assert.equal(config.rules[0].entropy, 3.5);
  assert.equal(config.rules[1].id, 'github-pat');
});

test('literal strings keep their backslashes', () => {
  // THE test. Every gitleaks regex is a ''' literal precisely so backslashes
  // mean themselves. A parser that processed escapes here would turn \d into d
  // — still a valid regex, matching the letter d, silently wrong in about a
  // hundred and seventy rules at once.
  const config = parseToml(String.raw`
[[rules]]
regex = '''(?i)\b(\d{3}-\d{2}-\d{4})\b'''
single = 'C:\path\to\nowhere'
`);
  assert.equal(config.rules[0].regex, String.raw`(?i)\b(\d{3}-\d{2}-\d{4})\b`);
  assert.equal(config.rules[0].single, String.raw`C:\path\to\nowhere`);
});

test('basic strings do process escapes', () => {
  const config = parseToml('a = "line\\nbreak"\nb = "quote\\"inside"\nc = "\\u0041"');
  assert.equal(config.a, 'line\nbreak');
  assert.equal(config.b, 'quote"inside');
  assert.equal(config.c, 'A');
});

test('a sub-table attaches to the array-of-tables entry above it', () => {
  // [rules.allowlist] must land on the LAST [[rules]] entry, not on a shared
  // top-level object. Getting this wrong applies one rule's allowlist to every
  // rule in the file.
  const config = parseToml(`
[[rules]]
id = "first"
[rules.allowlist]
regexes = ['''example\\.com''']

[[rules]]
id = "second"
[rules.allowlist]
paths = ['''test/''']
`);
  assert.equal(config.rules.length, 2);
  assert.deepEqual(config.rules[0].allowlist.regexes, ['example\\.com']);
  assert.equal(config.rules[0].allowlist.paths, undefined);
  assert.deepEqual(config.rules[1].allowlist.paths, ['test/']);
});

test('handles multi-line arrays and trailing commas', () => {
  const config = parseToml(`
keywords = [
  "one",
  "two",
  "three",
]
`);
  assert.deepEqual(config.keywords, ['one', 'two', 'three']);
});

test('handles comments, including after values', () => {
  const config = parseToml(`
# leading comment
a = 1 # trailing comment
# another
b = true
`);
  assert.equal(config.a, 1);
  assert.equal(config.b, true);
});

test('handles multi-line literal and basic strings', () => {
  const config = parseToml(`
a = '''
first
second'''
b = """
alpha
beta"""
`);
  // The newline immediately after the opening delimiter is not part of the value.
  assert.equal(config.a, 'first\nsecond');
  assert.equal(config.b, 'alpha\nbeta');
});

test('handles nested and quoted keys', () => {
  const config = parseToml(`
[a.b]
c = 1
["quoted key"]
d = 2
`);
  assert.equal(config.a.b.c, 1);
  assert.equal(config['quoted key'].d, 2);
});

test('handles inline tables', () => {
  const config = parseToml('point = { x = 1, y = 2 }');
  assert.deepEqual(config.point, { x: 1, y: 2 });
});

test('parses numbers in the forms gitleaks uses', () => {
  const config = parseToml('a = 3.5\nb = 42\nc = -1\nd = 1_000\ne = 0x1F');
  assert.equal(config.a, 3.5);
  assert.equal(config.b, 42);
  assert.equal(config.c, -1);
  assert.equal(config.d, 1000);
  assert.equal(config.e, 31);
});

test('refuses what it cannot parse rather than guessing', () => {
  // A parser that returns something plausible for input it does not understand
  // is how a rule set ends up quietly half-loaded.
  assert.throws(() => parseToml('a = 2024-01-01'), TomlError);
  assert.throws(() => parseToml("a = 'unterminated"), TomlError);
  assert.throws(() => parseToml('a = '), TomlError);
  assert.throws(() => parseToml('[unclosed'), TomlError);
});

test('an empty document is an empty object', () => {
  assert.deepEqual(parseToml(''), {});
  assert.deepEqual(parseToml('# only a comment\n'), {});
  assert.deepEqual(parseToml(null), {});
});
