'use strict';

// The upstream rule sources, as data.
//
// Adding a source is a row here plus an adapter module. That is the whole
// extension point, and it is deliberately boring: the interesting decisions —
// what we are allowed to redistribute, what a rule becomes once ingested — are
// properties of the source, not code paths scattered through a pipeline.
//
// LICENCE IS A FIRST-CLASS FIELD, AND IT GATES THE BUILD.
//
// This product is distributed: a signed .pkg and .exe, plus a rule bundle
// served from the licence service. Several excellent rule sets may not be
// redistributed that way, and the difference between "we may read this" and "we
// may ship this" is not something to leave to whoever runs the script next.
// `redistributable: false` means the rules can be ingested for local analysis —
// which their licences permit — and are excluded from the signed bundle by
// tools/build-rules.js. The exclusion is enforced in code and asserted by a
// test, because a licence violation that depends on someone remembering a flag
// is a licence violation waiting to happen.

const SOURCES = [
  {
    id: 'gitleaks',
    name: 'Gitleaks',
    kind: 'SECRET',
    license: 'MIT',
    licenseUrl: 'https://raw.githubusercontent.com/gitleaks/gitleaks/master/LICENSE',
    homepage: 'https://github.com/gitleaks/gitleaks',
    // The rule set itself: one TOML file, ~170 rules with entropy thresholds
    // and allowlists. Genuinely data, which is why this source ingests cleanly.
    url: 'https://raw.githubusercontent.com/gitleaks/gitleaks/master/config/gitleaks.toml',
    adapter: 'gitleaks',
    redistributable: true,
    attribution:
      'Secret detection rules derived from Gitleaks (https://github.com/gitleaks/gitleaks), MIT licensed.',
  },

  {
    id: 'checkov',
    name: 'Checkov',
    kind: 'IAC',
    license: 'Apache-2.0',
    licenseUrl: 'https://raw.githubusercontent.com/bridgecrewio/checkov/main/LICENSE',
    homepage: 'https://github.com/bridgecrewio/checkov',
    // Most of Checkov's checks are PYTHON CLASSES and cannot be executed by a
    // Node engine at any price. Its GRAPH CHECKS, however, are YAML: a metadata
    // block and a definition tree of attribute conditions. Those are data, and
    // those are what this ingests.
    //
    // A further subset is still out of reach: a graph check using `connection`
    // asks whether one resource references another, which needs a resolved
    // resource graph we do not build. Those are refused by name at ingest time
    // rather than evaluated wrongly.
    urls: [
      'https://api.github.com/repos/bridgecrewio/checkov/contents/checkov/terraform/checks/graph_checks/aws',
      'https://api.github.com/repos/bridgecrewio/checkov/contents/checkov/terraform/checks/graph_checks/azure',
      'https://api.github.com/repos/bridgecrewio/checkov/contents/checkov/terraform/checks/graph_checks/gcp',
      'https://api.github.com/repos/bridgecrewio/checkov/contents/checkov/kubernetes/checks/graph_checks',
    ],
    url: 'https://github.com/bridgecrewio/checkov',
    expand: 'github-dir',
    adapter: 'checkov',
    redistributable: true,
    partial: 'YAML graph checks only — Checkov\'s Python checks are code, and its connection checks need a resource graph',
    attribution:
      'Infrastructure-as-code policies derived from Checkov (https://github.com/bridgecrewio/checkov), Apache 2.0 licensed.',
  },

  {
    id: 'semgrep',
    name: 'Semgrep Rules',
    kind: 'SAST',
    license: 'Semgrep Rules License v1.0',
    licenseUrl: 'https://semgrep.dev/legal/rules-license',
    homepage: 'https://github.com/semgrep/semgrep-rules',
    url: 'https://api.github.com/repos/semgrep/semgrep-rules/contents',
    adapter: 'semgrep',
    // NOT redistributable. The Semgrep Rules License permits use "only for your
    // own internal business purposes" and states that it "does not allow you to
    // distribute the rules, or to make them available to others as a service".
    // Shipping them inside the installer, or serving them from the licence
    // service, is precisely those two things.
    //
    // Ingesting them for a developer's own scanning is within the licence, so
    // the source stays supported and opt-in. It is excluded from the bundle.
    redistributable: false,
    licenseWarning:
      'Semgrep rules may be used locally but MUST NOT be redistributed or served. '
      + 'They are excluded from the signed bundle and from the installers. '
      + 'Confirm with legal before changing this.',
    attribution:
      'Semgrep rules (https://github.com/semgrep/semgrep-rules) are used locally under the '
      + 'Semgrep Rules License v1.0 and are not redistributed with this product.',
  },

  {
    id: 'osv',
    name: 'OSV / GitHub Advisory Database',
    kind: 'SCA',
    license: 'CC0-1.0',
    licenseUrl: 'https://raw.githubusercontent.com/github/advisory-database/main/LICENSE.md',
    homepage: 'https://github.com/github/advisory-database',
    url: 'https://api.osv.dev/v1/query',
    adapter: 'osv',
    redistributable: true,
    // Not a rule set, and pretending it is one would produce a multi-gigabyte
    // "bundle". ~250k advisories, already queried live per dependency by
    // version-watch/registries/osv.js. This source exists here so an air-gapped
    // install can mirror the database offline; it is written to its own
    // artifact, never into the rule bundle.
    artifact: 'advisories',
    attribution:
      'Vulnerability data from OSV.dev and the GitHub Advisory Database '
      + '(https://github.com/github/advisory-database), CC0 1.0.',
  },
];

function bySource(id) {
  return SOURCES.find(s => s.id === id) || null;
}

// The sources whose output may be signed and shipped. build-rules.js filters on
// this, and a test asserts that nothing outside it reaches a bundle.
function redistributableIds() {
  return SOURCES.filter(s => s.redistributable).map(s => s.id);
}

function ruleSources() {
  return SOURCES.filter(s => !s.artifact);
}

module.exports = { SOURCES, bySource, redistributableIds, ruleSources };
