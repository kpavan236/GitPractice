'use strict';

// A TOML parser, because gitleaks.toml is the rule set and we cannot install a
// parser to read it.
//
// The no-dependency rule is not negotiable here — the whole product ships as an
// Electron app that must work on a laptop with nothing installed — so this is
// the same trade the tree-sitter WASM grammars made: vendor a small amount of
// capability rather than take a dependency.
//
// Scope is deliberately TOML-as-gitleaks-uses-it, not TOML 1.0 entire. What is
// supported: comments, dotted and quoted keys, tables, arrays of tables, inline
// tables, arrays (including multi-line), booleans, integers, floats, and all
// four string forms. What is NOT: dates and times. gitleaks.toml contains none,
// and a date parser nobody exercises is a liability rather than a feature — it
// throws on encountering one instead of silently producing a wrong value.
//
// The part that actually matters for correctness is literal strings. Gitleaks
// writes every regex as '''...''' precisely so backslashes mean themselves, so
// a parser that processed escapes inside them would quietly corrupt roughly
// every rule in the file — `\d` becoming `d`, matching the letter rather than a
// digit. Literal strings are therefore returned raw, byte for byte.

class TomlError extends Error {
  constructor(message, line) {
    super(line ? `${message} (line ${line})` : message);
    this.name = 'TomlError';
    this.line = line || null;
  }
}

function parseToml(input) {
  const text = String(input == null ? '' : input).replace(/\r\n/g, '\n');
  let i = 0;

  const lineAt = pos => text.slice(0, pos).split('\n').length;
  const fail = message => {
    throw new TomlError(message, lineAt(i));
  };

  const root = {};
  // Where bare `key = value` pairs currently land. Moved by every table header.
  let current = root;

  const isWs = c => c === ' ' || c === '\t';
  const isNewline = c => c === '\n';

  function skipInlineSpace() {
    while (i < text.length && isWs(text[i])) i++;
  }

  // Whitespace, newlines and comments — everything that can sit between two
  // meaningful tokens at the top level.
  function skipTrivia() {
    for (;;) {
      while (i < text.length && (isWs(text[i]) || isNewline(text[i]))) i++;
      if (text[i] === '#') {
        while (i < text.length && !isNewline(text[i])) i++;
        continue;
      }
      return;
    }
  }

  function parseBasicString(terminator) {
    // terminator is '"' or '"""'; escapes are processed in both.
    i += terminator.length;
    // A newline immediately after """ is not part of the value.
    if (terminator.length === 3 && text[i] === '\n') i++;

    let out = '';
    while (i < text.length) {
      if (text.startsWith(terminator, i)) {
        i += terminator.length;
        return out;
      }
      const c = text[i];
      if (c === '\\') {
        const next = text[i + 1];
        // Line-ending backslash in a multi-line string swallows the newline and
        // the indentation that follows it.
        if (terminator.length === 3 && (next === '\n' || (isWs(next) && /^[ \t]*\n/.test(text.slice(i + 1))))) {
          i++;
          while (i < text.length && (isWs(text[i]) || isNewline(text[i]))) i++;
          continue;
        }
        i += 2;
        switch (next) {
          case 'n': out += '\n'; break;
          case 't': out += '\t'; break;
          case 'r': out += '\r'; break;
          case 'b': out += '\b'; break;
          case 'f': out += '\f'; break;
          case '"': out += '"'; break;
          case '\\': out += '\\'; break;
          case 'u': case 'U': {
            const width = next === 'u' ? 4 : 8;
            const hex = text.slice(i, i + width);
            if (!/^[0-9a-fA-F]+$/.test(hex)) fail('bad unicode escape');
            out += String.fromCodePoint(parseInt(hex, 16));
            i += width;
            break;
          }
          default: fail(`unknown escape \\${next}`);
        }
        continue;
      }
      if (c === '\n' && terminator.length === 1) fail('newline in a single-line string');
      out += c;
      i++;
    }
    return fail('unterminated string');
  }

  function parseLiteralString(terminator) {
    // ' or ''' — NO escape processing. This is what keeps every gitleaks regex
    // intact.
    i += terminator.length;
    if (terminator.length === 3 && text[i] === '\n') i++;

    const end = text.indexOf(terminator, i);
    if (end === -1) return fail('unterminated literal string');
    const out = text.slice(i, end);
    if (terminator.length === 1 && out.includes('\n')) fail('newline in a single-line string');
    i = end + terminator.length;
    return out;
  }

  function parseString() {
    if (text.startsWith("'''", i)) return parseLiteralString("'''");
    if (text.startsWith('"""', i)) return parseBasicString('"""');
    if (text[i] === "'") return parseLiteralString("'");
    if (text[i] === '"') return parseBasicString('"');
    return fail('expected a string');
  }

  function parseArray() {
    i++; // [
    const out = [];
    for (;;) {
      skipTrivia();
      if (i >= text.length) return fail('unterminated array');
      if (text[i] === ']') {
        i++;
        return out;
      }
      out.push(parseValue());
      skipTrivia();
      if (text[i] === ',') {
        i++;
        continue;
      }
      if (text[i] === ']') {
        i++;
        return out;
      }
      return fail('expected , or ] in array');
    }
  }

  function parseInlineTable() {
    i++; // {
    const out = {};
    for (;;) {
      skipInlineSpace();
      if (text[i] === '}') {
        i++;
        return out;
      }
      const path = parseKeyPath();
      skipInlineSpace();
      if (text[i] !== '=') return fail('expected = in inline table');
      i++;
      skipInlineSpace();
      assign(out, path, parseValue());
      skipInlineSpace();
      if (text[i] === ',') {
        i++;
        continue;
      }
      if (text[i] === '}') {
        i++;
        return out;
      }
      return fail('expected , or } in inline table');
    }
  }

  function parseValue() {
    const c = text[i];
    if (c === '"' || c === "'") return parseString();
    if (c === '[') return parseArray();
    if (c === '{') return parseInlineTable();

    // Bare token: boolean, integer, or float.
    const start = i;
    while (i < text.length && !/[\s,\]}#]/.test(text[i])) i++;
    const raw = text.slice(start, i);

    if (raw === 'true') return true;
    if (raw === 'false') return false;
    if (/^[+-]?\d{4}-\d{2}-\d{2}/.test(raw)) {
      // Deliberate: see the header. A wrong date is worse than a refusal.
      return fail('dates are not supported by this parser');
    }

    const numeric = raw.replace(/_/g, '');
    if (/^[+-]?(0x[0-9a-fA-F]+|0o[0-7]+|0b[01]+)$/.test(numeric)) return Number(numeric);
    if (/^[+-]?\d+$/.test(numeric)) return parseInt(numeric, 10);
    if (/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(numeric)) return parseFloat(numeric);
    if (/^[+-]?(inf|nan)$/.test(numeric)) return numeric.includes('nan') ? NaN : (numeric[0] === '-' ? -Infinity : Infinity);

    return fail(`cannot parse value: ${raw.slice(0, 40)}`);
  }

  // a.b."c d" → ['a','b','c d']
  function parseKeyPath() {
    const path = [];
    for (;;) {
      skipInlineSpace();
      if (text[i] === '"' || text[i] === "'") path.push(parseString());
      else {
        const start = i;
        while (i < text.length && /[A-Za-z0-9_-]/.test(text[i])) i++;
        if (i === start) return fail('expected a key');
        path.push(text.slice(start, i));
      }
      skipInlineSpace();
      if (text[i] === '.') {
        i++;
        continue;
      }
      return path;
    }
  }

  function descend(container, path) {
    let node = container;
    for (const key of path) {
      let next = node[key];
      if (next === undefined) {
        next = {};
        node[key] = next;
      } else if (Array.isArray(next)) {
        // A dotted path through an array of tables addresses its LAST element,
        // which is what makes [rules.allowlist] attach to the rule above it.
        // Navigate INTO the last entry — do not write it back over the array,
        // which would collapse every [[rules]] parsed so far into one object.
        next = next[next.length - 1];
      }
      if (typeof next !== 'object' || next === null) fail(`cannot redefine ${key}`);
      node = next;
    }
    return node;
  }

  function assign(container, path, value) {
    const node = descend(container, path.slice(0, -1));
    node[path[path.length - 1]] = value;
  }

  for (;;) {
    skipTrivia();
    if (i >= text.length) break;

    if (text[i] === '[') {
      const isArrayTable = text[i + 1] === '[';
      i += isArrayTable ? 2 : 1;
      const path = parseKeyPath();
      skipInlineSpace();
      if (isArrayTable) {
        if (!text.startsWith(']]', i)) fail('expected ]]');
        i += 2;
      } else {
        if (text[i] !== ']') fail('expected ]');
        i += 1;
      }

      if (isArrayTable) {
        const parent = descend(root, path.slice(0, -1));
        const key = path[path.length - 1];
        if (!Array.isArray(parent[key])) parent[key] = [];
        const entry = {};
        parent[key].push(entry);
        current = entry;
      } else {
        current = descend(root, path);
      }
      continue;
    }

    const path = parseKeyPath();
    skipInlineSpace();
    if (text[i] !== '=') fail('expected =');
    i++;
    skipInlineSpace();
    assign(current, path, parseValue());
  }

  return root;
}

module.exports = { parseToml, TomlError };
