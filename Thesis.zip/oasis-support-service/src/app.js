'use strict';
const crypto = require('node:crypto');
const express = require('express');
const { errorHandler } = require('./errors');
const { rateLimit } = require('./rate-limit');
const { createHasher } = require('./secrets');
const { createFakeNotifier } = require('./notifier');
const { messageRoutes } = require('./routes/messages');

/**
 * Builds the HTTP app. Everything it needs is passed in, so tests hand it a throwaway database.
 * Logging: one line per request (method, path, status, time, request id). The body is NEVER logged: it holds a person's words, name and address.
 */
function createApp({ db, hashPepper, notifier = createFakeNotifier(), supportMailbox = null, noticesPerHour, trustProxy = 0, tls = false, limiter = rateLimit(), log = line => console.log(JSON.stringify(line)) }) {
  const hash = createHasher(hashPepper);
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);

  app.use((req, res, next) => {
    const inbound = req.get('X-Request-Id');
    req.id = inbound && /^[A-Za-z0-9_-]{8,64}$/.test(inbound) ? inbound : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Referrer-Policy', 'no-referrer');
    if (tls) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.set('Cache-Control', 'no-store');
    const started = Date.now();
    res.on('finish', () => log({ level: 'info', requestId: req.id, method: req.method, path: req.path, status: res.statusCode, ms: Date.now() - started }));
    next();
  });

  app.get('/healthz', (_req, res) => res.json({ ok: true }));
  app.get('/readyz', async (_req, res) => {
    try { await db.query('SELECT 1'); res.json({ ok: true }); }
    catch (_) { res.status(503).json({ ok: false }); }
  });

  const v1 = express.Router();
  v1.use(limiter);
  v1.use(express.json({ limit: '32kb' }));      // a 4,000-character message can be 16 KB of UTF-8
  v1.use(messageRoutes({ db, hash, notifier, supportMailbox, noticesPerHour, log }));
  app.use('/v1', v1);

  app.use((req, res) => res.status(404).json({ error: 'not_found', message: 'No such route.', requestId: req.id }));
  app.use(errorHandler(log));
  return app;
}

module.exports = { createApp };
