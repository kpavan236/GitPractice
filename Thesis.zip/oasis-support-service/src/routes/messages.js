'use strict';
const express = require('express');
const { validateFeedback, validateSupportRequest, cleanVersion, cleanScreen, cleanMachineId, readIdempotencyKey } = require('../forms');
const { ApiError, refuse, wrap } = require('../errors');
const { tx } = require('../db');
const { uuidv7 } = require('../uuid');

const FEEDBACK_PER_HOUR = 10;           // per email address and per machine
const SUPPORT_REQUESTS_PER_HOUR = 5;    // per email address
const SUPPORT_REQUESTS_PER_MACHINE_PER_HOUR = 10;
const NOTICES_PER_HOUR = 60;            // emails to the support mailbox, from this process, whoever sends them

const tooMany = () => refuse('Too many messages from this address. Please try again in a while.', 'too_many_requests', {}, 429);
const keyReused = () => new ApiError(409, 'That Idempotency-Key was already used for a different message. Send a new key for each new message.', 'idempotency_conflict');

/** At most `perHour` emails to the support mailbox from this process, however many requests arrive: the requests are all stored and listed either way. */
function noticeBudget(perHour, now = Date.now) {
  let windowStart = now(), used = 0;
  return () => { const t = now(); if (t - windowStart >= 3_600_000) { windowStart = t; used = 0; } return used++ < perHour; };
}

/**
 * POST /v1/feedback and POST /v1/support-request: what a person sends from the OASIS app. Both can be sent by someone with no licence, so both carry the
 * same protections as the Buy form: validation, a per-address and per-machine limit, an Idempotency-Key so a retry never makes a second row, and no body
 * in any log. Feedback may be anonymous; a support request needs an email address, the only way to answer.
 *
 * An Idempotency-Key is bound to the message it was first used with: the same key and the same message is a retry (the first answer comes back); the same
 * key and a different message is refused (409), never silently dropped. A key that is present but malformed is refused (400), because ignoring it would
 * turn a retry into a duplicate. Without a key a retry is a new message.
 */
function messageRoutes({ db, hash, notifier, supportMailbox = null, noticesPerHour = NOTICES_PER_HOUR, now = Date.now, log = () => {} }) {
  const router = express.Router();
  const mayNotify = noticeBudget(noticesPerHour, now);
  const replay = (res, reference) => { res.set('Idempotent-Replay', 'true'); return res.json({ ok: true, reference }); };
  const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
  /** A machine id is only ever kept as a keyed hash: it can be matched by someone who holds the id, and read by nobody. */
  const installationRef = body => { const id = cleanMachineId(body.machineId); return id ? hash('installation', id) : null; };
  const keyOf = req => {
    const k = readIdempotencyKey(req.get('Idempotency-Key'));
    if (k.bad) throw refuse('The Idempotency-Key must be 8 to 100 letters, digits, "-" or "_".', 'bad_idempotency_key');
    return k.key;
  };

  /** The reference of an earlier submit with this key: the same message gets it back, a different one is refused. */
  async function earlier(table, key, requestHash) {
    if (!key) return null;
    const { rows } = await db.query(`SELECT reference, request_hash FROM ${table} WHERE idempotency_key = $1`, [key]);
    if (!rows.length) return null;
    if (rows[0].request_hash !== requestHash) throw keyReused();
    return rows[0].reference;
  }

  /**
   * Checks the limits and inserts in ONE transaction that first locks on the address (and the machine), so a burst of parallel requests cannot all pass the
   * count before any of them is stored. Returns the new reference, or null when another copy of the same submit won.
   */
  async function store({ lockOn, limits, insertSql, insertParams }) {
    return tx(db, async client => {
      for (const l of lockOn) await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [l]);
      for (const { sql, params, max } of limits) {
        if ((await client.query(sql, params)).rows[0].n >= max) throw tooMany();
      }
      const { rows } = await client.query(insertSql, insertParams);
      return rows.length ? rows[0].reference : null;
    });
  }

  router.post('/feedback', wrap(async (req, res) => {
    const checked = validateFeedback(req.body);
    if (!checked.ok) throw refuse('Some details need fixing.', 'invalid', { errors: checked.errors });
    const d = checked.value, body = bodyOf(req);
    const key = keyOf(req), ref = installationRef(body);
    const version = cleanVersion(body.appVersion), screen = cleanScreen(body.screen);
    const requestHash = hash('request', JSON.stringify(['feedback', d.category, d.rating, d.message, d.email, version, screen, ref]));

    const seen = await earlier('feedback', key, requestHash);
    if (seen) return replay(res, seen);

    const limits = [];
    if (d.email) limits.push({ sql: `SELECT count(*)::int AS n FROM feedback WHERE email = $1 AND created_at > now() - interval '1 hour'`, params: [d.email], max: FEEDBACK_PER_HOUR });
    if (ref) limits.push({ sql: `SELECT count(*)::int AS n FROM feedback WHERE installation_ref = $1 AND created_at > now() - interval '1 hour'`, params: [ref], max: FEEDBACK_PER_HOUR });
    const reference = await store({
      lockOn: [d.email && `email:${d.email}`, ref && `machine:${ref}`].filter(Boolean), limits,
      insertSql: `INSERT INTO feedback (feedback_id, idempotency_key, request_hash, category_code, rating, message, email, app_version, screen, installation_ref)
                  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) ON CONFLICT (idempotency_key) DO NOTHING RETURNING reference`,
      insertParams: [uuidv7(), key, requestHash, d.category, d.rating, d.message, d.email, version, screen, ref],
    });
    if (reference) return res.json({ ok: true, reference });
    return replay(res, await earlier('feedback', key, requestHash));       // the same submit won a moment ago
  }));

  router.post('/support-request', wrap(async (req, res) => {
    const checked = validateSupportRequest(req.body);
    if (!checked.ok) throw refuse('Some details need fixing.', 'invalid', { errors: checked.errors });
    const d = checked.value, body = bodyOf(req);
    const key = keyOf(req), ref = installationRef(body);
    const version = cleanVersion(body.appVersion);
    const requestHash = hash('request', JSON.stringify(['support-request', d.subject, d.message, d.contactName, d.email, version, ref]));

    const seen = await earlier('support_request', key, requestHash);
    if (seen) return replay(res, seen);

    const limits = [{ sql: `SELECT count(*)::int AS n FROM support_request WHERE email = $1 AND created_at > now() - interval '1 hour'`, params: [d.email], max: SUPPORT_REQUESTS_PER_HOUR }];
    if (ref) limits.push({ sql: `SELECT count(*)::int AS n FROM support_request WHERE installation_ref = $1 AND created_at > now() - interval '1 hour'`, params: [ref], max: SUPPORT_REQUESTS_PER_MACHINE_PER_HOUR });
    const reference = await store({
      lockOn: [`email:${d.email}`, ref && `machine:${ref}`].filter(Boolean), limits,
      insertSql: `INSERT INTO support_request (support_request_id, idempotency_key, request_hash, subject, message, contact_name, email, app_version, installation_ref)
                  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) ON CONFLICT (idempotency_key) DO NOTHING RETURNING reference`,
      insertParams: [uuidv7(), key, requestHash, d.subject, d.message, d.contactName, d.email, version, ref],
    });
    if (!reference) return replay(res, await earlier('support_request', key, requestHash));

    // Tell the support team: best effort, after the request is stored. A mail fault (a rejection OR a throw) must never lose a person's request or make the
    // app think it failed (the support list shows every request whether or not the email went). Only a NEW request notifies, never a replay, and never
    // more than `noticesPerHour` from this process: past that the requests are still stored and listed, so mailing the team about each one adds nothing.
    if (supportMailbox) {
      if (mayNotify()) {
        try { await notifier.notifySupportRequest({ to: supportMailbox, reference, subject: d.subject, contactName: d.contactName, email: d.email }); }
        catch (err) { log({ level: 'error', requestId: req.id, msg: 'support notice not sent', reference, error: err && err.name }); }
      } else {
        log({ level: 'warn', requestId: req.id, msg: 'support notice skipped: hourly budget used', reference });
      }
    }
    return res.json({ ok: true, reference });
  }));

  return router;
}

module.exports = { messageRoutes, FEEDBACK_PER_HOUR, SUPPORT_REQUESTS_PER_HOUR, SUPPORT_REQUESTS_PER_MACHINE_PER_HOUR, NOTICES_PER_HOUR };
