'use strict';
const { normaliseEmail } = require('./forms');

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Reads and checks the settings once, at start-up. A missing or malformed setting stops the service with a clear message. */
function loadConfig(env = process.env) {
  const need = name => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  const hashPepper = need('HASH_PEPPER');
  if (hashPepper.length < 32) throw new Error('HASH_PEPPER must be at least 32 characters.');
  const production = env.NODE_ENV === 'production';

  if (production && (env.TRUST_PROXY === undefined || env.TRUST_PROXY === '')) {
    throw new Error('TRUST_PROXY must be set in production (the number of proxies in front of the service; 0 if none), or every caller appears to come from the proxy.');
  }
  const tlsCertFile = env.TLS_CERT_FILE || null;
  const tlsKeyFile = env.TLS_KEY_FILE || null;
  if (Boolean(tlsCertFile) !== Boolean(tlsKeyFile)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together (or both left unset).');
  const tls = Boolean(tlsCertFile);
  if (production && !tls && env.ALLOW_PLAIN_HTTP !== '1') {
    throw new Error('Production needs TLS: set TLS_CERT_FILE and TLS_KEY_FILE, or set ALLOW_PLAIN_HTTP=1 only when the hosting platform terminates TLS in front of the service.');
  }
  const notifier = env.NOTIFIER || 'fake';
  if (notifier !== 'fake') throw new Error('NOTIFIER must be "fake": no email provider has been approved yet (IT Helpdesk, cainc.service-now.com).');
  if (production) throw new Error('Production needs an approved email sender; the fake one would never deliver a support notice.');
  const printCodes = env.DEV_PRINT_NOTICES === '1';

  let supportMailbox = null;
  if (env.SUPPORT_MAILBOX) {
    supportMailbox = normaliseEmail(env.SUPPORT_MAILBOX);
    if (!supportMailbox) throw new Error('SUPPORT_MAILBOX must be one email address.');
  }
  return {
    tls, tlsCertFile, tlsKeyFile,
    shutdownTimeoutMs: whole(env, 'SHUTDOWN_TIMEOUT_MS', { min: 1, max: 600_000, fallback: 10_000 }),
    hashPepper, supportMailbox, notifier, printNotices: printCodes,
    port: whole(env, 'PORT', { min: 1, max: 65535, fallback: 4040 }),
    supportDatabaseUrl: need('SUPPORT_DATABASE_URL'),
    trustProxy: whole(env, 'TRUST_PROXY', { min: 0, max: 10, fallback: 0 }),
  };
}

module.exports = { loadConfig };
