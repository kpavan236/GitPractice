'use strict';
const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const { loadConfig } = require('./config');
const { createPool } = require('./db');
const { createApp } = require('./app');
const { createFakeNotifier } = require('./notifier');
const { createShutdown } = require('./shutdown');

async function main() {
  const config = loadConfig();
  const db = createPool(config.supportDatabaseUrl);
  const app = createApp({ db, hashPepper: config.hashPepper, notifier: createFakeNotifier({ print: config.printNotices }), supportMailbox: config.supportMailbox, trustProxy: config.trustProxy, tls: config.tls });
  const server = config.tls
    ? https.createServer({ cert: fs.readFileSync(config.tlsCertFile), key: fs.readFileSync(config.tlsKeyFile) }, app)
    : http.createServer(app);
  server.listen(config.port, () => console.log(JSON.stringify({ level: 'info', msg: 'listening', port: config.port, tls: config.tls })));
  const stop = createShutdown({ server, pools: [db], timeoutMs: config.shutdownTimeoutMs });
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch(err => { console.error(JSON.stringify({ level: 'fatal', error: err.message })); process.exit(1); });
