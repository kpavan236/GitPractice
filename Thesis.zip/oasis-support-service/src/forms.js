'use strict';

// Input rules for what a person types into the Feedback and Contact support forms. Each function returns tidied values, never the raw input:
// control characters are removed, a number arrives as a number, unknown fields are dropped. A person may write anything in a message, so a
// message is stored as text and is never trusted, logged or put into an email.

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/;
const MAX_EMAIL = 254;
const CATEGORIES = ['bug', 'idea', 'praise', 'other'];

/** The address, trimmed and lower-cased, or null when it is not exactly one email address. */
function normaliseEmail(value) {
  if (typeof value !== 'string') return null;
  const s = value.trim().toLowerCase();
  if (!s || s.length > MAX_EMAIL || /[\s,;<>\u0000-\u001f\u007f\u0085\u2028\u2029\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/.test(s)) return null;
  if ((s.match(/@/g) || []).length !== 1 || !EMAIL.test(s)) return null;
  return s;
}

/** One line: line breaks and tabs become spaces, other control characters (and the Unicode line and paragraph separators) go. */
// Characters that cannot be seen but change how text reads: zero-width characters, direction overrides and isolates, the BOM. They make a subject or a
// name in an email to the support team look like something else, so they are removed from everything a person types.
const INVISIBLE = /[\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/g;
/** A hard ceiling on what is even looked at: cleaning is linear, but a megabyte of spaces is not a message. */
const MAX_RAW = 20_000;

const oneLine = text => String(text).replace(/[\r\n\t\u0085\u2028\u2029]+/g, ' ').replace(/[\u0000-\u001f\u007f]/g, '').replace(INVISIBLE, '').replace(/ {2,}/g, ' ').trim();

/** Several lines: line breaks are kept (as \n), other control characters go, and more than one blank line in a row is squeezed. */
const manyLines = text => String(text).replace(/\r\n?|\u0085|\u2028|\u2029/g, '\n').replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, '').replace(INVISIBLE, '').split('\n').map(l => l.trimEnd()).join('\n').replace(/\n{3,}/g, '\n\n').trim();

function line(input, label, { max }) {
  if (typeof input !== 'string') return { error: `Enter ${label}.` };
  if (input.length > MAX_RAW) return { error: `Keep ${label} under ${max} characters.` };
  const value = oneLine(input);
  if (!value) return { error: `Enter ${label}.` };
  if (value.length > max) return { error: `Keep ${label} under ${max} characters.` };
  return { value };
}

function message(input, label = 'your message') {
  if (typeof input !== 'string') return { error: `Enter ${label}.` };
  if (input.length > MAX_RAW) return { error: `Keep ${label} under 4,000 characters.` };
  const value = manyLines(input);
  if (!value) return { error: `Enter ${label}.` };
  if (value.length > 4000) return { error: `Keep ${label} under 4,000 characters.` };
  return { value };
}

function emailField(input, { required }) {
  if (input === undefined || input === null || input === '') return required ? { error: 'Enter a valid email address.' } : { value: null };
  const value = normaliseEmail(input);
  return value ? { value } : { error: 'Enter a valid email address.' };
}

/** "1.2.3-beta" style only; anything else is dropped rather than stored. */
const cleanVersion = v => (typeof v === 'string' && /^[0-9A-Za-z.+-]{1,20}$/.test(v) ? v : null);
/** Which tab the message was sent from: a short lower-case code, else dropped. */
const cleanScreen = v => (typeof v === 'string' && /^[a-z0-9-]{1,40}$/.test(v) ? v : null);
/** A machine id, if it is well formed; it is only ever hashed. */
const cleanMachineId = v => (typeof v === 'string' && /^[A-Za-z0-9_-]{16,64}$/.test(v) ? v : null);
/** { key } (a good one), { key: null } (none sent), or { bad: true } (sent but malformed: refused, because ignoring it would silently turn a retry into a duplicate). */
function readIdempotencyKey(value) {
  if (value === undefined) return { key: null };
  const s = Array.isArray(value) ? value[0] : value;
  return typeof s === 'string' && /^[A-Za-z0-9_-]{8,100}$/.test(s) ? { key: s } : { bad: true };
}

/** @returns { ok: true, value } | { ok: false, errors: { field: message } } */
function validateFeedback(input) {
  const src = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const errors = {}, value = {};

  if (typeof src.category === 'string' && CATEGORIES.includes(src.category.trim().toLowerCase())) value.category = src.category.trim().toLowerCase();
  else errors.category = `Choose one of: ${CATEGORIES.join(', ')}.`;

  const msg = message(src.message);
  if (msg.error) errors.message = msg.error; else value.message = msg.value;

  const email = emailField(src.email, { required: false });
  if (email.error) errors.email = email.error; else value.email = email.value;

  if (src.rating === undefined || src.rating === null) value.rating = null;
  else if (Number.isInteger(src.rating) && src.rating >= 1 && src.rating <= 5) value.rating = src.rating;
  else errors.rating = 'The rating must be a whole number from 1 to 5.';

  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, value };
}

function validateSupportRequest(input) {
  const src = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const errors = {}, value = {};

  const subject = line(src.subject, 'a subject', { max: 150 });
  if (subject.error) errors.subject = subject.error; else value.subject = subject.value;

  const msg = message(src.message);
  if (msg.error) errors.message = msg.error; else value.message = msg.value;

  const name = line(src.contactName, 'your name', { max: 150 });
  if (name.error) errors.contactName = name.error; else value.contactName = name.value;

  const email = emailField(src.email, { required: true });
  if (email.error) errors.email = email.error; else value.email = email.value;

  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, value };
}

module.exports = { normaliseEmail, validateFeedback, validateSupportRequest, cleanVersion, cleanScreen, cleanMachineId, readIdempotencyKey, CATEGORIES, oneLine, manyLines };
