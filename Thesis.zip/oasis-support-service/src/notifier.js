'use strict';

/**
 * The email sender, behind one method. No real provider is approved yet (new email services go through the IT Helpdesk, cainc.service-now.com,
 * first, and the wording needs CA employee review), so the only implementation is a FAKE that keeps what it was asked to send, in memory, for
 * tests. docs/fakes.md says what the real one must do.
 *
 *   notifySupportRequest({ to, reference, subject, contactName, email })   a new "contact support" message, to the support mailbox
 *
 * The notice carries who and about what, NOT the message itself (free text a person typed): support reads that in the tool.
 * `print` writes only the reference to the terminal, for a developer without a mailbox; config.js refuses it in production.
 */
function createFakeNotifier({ print = false, out = line => console.log(line) } = {}) {
  const supportNotices = [];
  return {
    kind: 'fake',
    supportNotices,
    async notifySupportRequest(notice) {
      supportNotices.push({ ...notice, at: Date.now() });
      if (supportNotices.length > 1000) supportNotices.shift();      // a fake that runs for weeks must not grow without limit
      if (print) out(`(development only) support notice sent to ${notice.to}: new support request ${notice.reference}`);
    },
    lastSupportNotice: () => supportNotices[supportNotices.length - 1] || null,
  };
}

module.exports = { createFakeNotifier };
