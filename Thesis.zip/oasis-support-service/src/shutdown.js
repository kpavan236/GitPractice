'use strict';

/**
 * Returns stop(signal): stop accepting, close idle keep-alive connections, wait for in-flight requests, end the database pools, exit 0.
 * If that has not finished within timeoutMs the process exits 1 anyway. Calling it again while stopping does nothing.
 */
function createShutdown({ server, pools = [], timeoutMs = 10_000, exit = process.exit, log = line => console.log(JSON.stringify(line)) }) {
  let stopping = false;
  return function stop(signal) {
    if (stopping) return;
    stopping = true;
    log({ level: 'info', msg: 'shutting down', signal });
    const timer = setTimeout(() => {
      log({ level: 'error', msg: 'shutdown timed out; forcing exit' });
      server.closeAllConnections();
      exit(1);
    }, timeoutMs);
    timer.unref();
    server.close(async () => {
      for (const pool of pools) await Promise.resolve().then(() => pool.end()).catch(() => {});
      clearTimeout(timer);
      exit(0);
    });
    server.closeIdleConnections();
  };
}

module.exports = { createShutdown };
