'use strict';
const { createApp } = require('../../src/app');
const { createTestDatabase } = require('./db');
const { createFakeNotifier } = require('../../src/notifier');
const { rateLimit } = require('../../src/rate-limit');

const PEPPER = 'test-pepper-test-pepper-test-pepper-0123';

/** A running service on a free port, on a throwaway database. `logs` collects every log line so tests can check what was (not) logged. */
async function startService(options = {}) {
  const owned = options.db ? null : await createTestDatabase();
  const db = options.db || owned.db;
  const logs = [];
  const notifier = createFakeNotifier();
  const app = createApp({
    db, hashPepper: PEPPER, notifier, supportMailbox: options.supportMailbox === undefined ? 'support@support.example.test' : options.supportMailbox,
    noticesPerHour: options.noticesPerHour,
    limiter: options.limiter || rateLimit({ max: 10_000 }), log: line => logs.push(line),
  });
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, route, body, headers = {}) => {
    const res = await fetch(`${base}${route}`, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    return { status: res.status, headers: res.headers, body: await res.json().catch(() => ({})) };
  };
  return {
    db, base, logs, notifier, hashPepper: PEPPER, call,
    post: (route, body, headers) => call('POST', route, body, headers),
    async close() { await new Promise(r => server.close(r)); if (owned) await owned.drop(); },
  };
}

module.exports = { startService };
