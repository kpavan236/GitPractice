'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { FEEDBACK_PER_HOUR } = require('../src/routes/messages');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const form = (over = {}) => ({ category: 'idea', message: 'The dependency graph could group by team.', appVersion: '2.0.1', screen: 'repos', ...over });
const rows = (sql, params) => svc.db.query(sql, params).then(r => r.rows);
let n = 0;
const key = () => `fb-key-${++n}-${Date.now()}`;
const machine = () => crypto.randomBytes(16).toString('hex');
const send = (body, headers = {}) => svc.post('/v1/feedback', body, { 'Idempotency-Key': key(), ...headers });

test('feedback is stored with a reference, and only the fields the form asks for', async () => {
  const r = await send({ ...form({ email: 'Pat@Acme.Example.Test', rating: 4 }), status: 'RESOLVED', assigned_to_user_id: 'x', phone: '555 0100', created_at: '2001-01-01' });
  assert.equal(r.status, 200);
  assert.match(r.body.reference, /^FB-\d{6}$/);
  assert.deepEqual(Object.keys(r.body).sort(), ['ok', 'reference']);
  const [row] = await rows('SELECT * FROM feedback WHERE reference = $1', [r.body.reference]);
  assert.deepEqual([row.category_code, row.rating, row.email, row.app_version, row.screen], ['idea', 4, 'pat@acme.example.test', '2.0.1', 'repos']);
  assert.equal(row.message, 'The dependency graph could group by team.');
  assert.ok(Math.abs(row.created_at - Date.now()) < 10_000, 'the time is the server\'s');
  assert.ok(!Object.keys(row).some(c => /phone|status|assigned/.test(c)));
});

test('feedback can be anonymous: no address, no rating, no machine', async () => {
  const r = await send({ category: 'praise', message: 'Love the security tab' });
  assert.equal(r.status, 200);
  const [row] = await rows('SELECT email, rating, installation_ref, screen, app_version FROM feedback WHERE reference = $1', [r.body.reference]);
  assert.deepEqual(row, { email: null, rating: null, installation_ref: null, screen: null, app_version: null });
});

test('a machine id is kept only as a keyed hash; the same machine gives the same hash, another gives another', async () => {
  const m = machine();
  const a = await send(form({ machineId: m })), b = await send(form({ machineId: m })), c = await send(form({ machineId: machine() }));
  const refs = (await rows('SELECT installation_ref FROM feedback WHERE reference = ANY($1) ORDER BY created_at', [[a.body.reference, b.body.reference, c.body.reference]])).map(r => r.installation_ref);
  assert.equal(refs[0], refs[1]); assert.notEqual(refs[0], refs[2]);
  assert.match(refs[0], /^[0-9a-f]{64}$/);
  assert.ok(!JSON.stringify(await rows('SELECT * FROM feedback')).includes(m));
});

test('every category is accepted in any case; anything else is refused with a message per field', async () => {
  for (const category of ['bug', 'IDEA', ' Praise ', 'other']) assert.equal((await send(form({ category }))).status, 200, category);
  const r = await send({ category: 'complaint', message: '', email: 'not-an-email', rating: 6 });
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'invalid');
  for (const f of ['category', 'message', 'email', 'rating']) assert.ok(r.body.errors[f], `a message for ${f}`);
  assert.ok(r.body.requestId);
  assert.ok(!JSON.stringify(r.body).includes('not-an-email'), 'the refusal does not echo what was typed');
});

test('ratings must be whole numbers 1 to 5; messages 1 to 4,000 characters', async () => {
  for (const rating of [0, 6, 2.5, '3', true, [3], {}]) {
    const r = await send(form({ rating }));
    assert.equal(r.status, 400, JSON.stringify(rating));
    assert.ok(r.body.errors.rating, JSON.stringify(rating));
  }
  for (const rating of [1, 5, null]) assert.equal((await send(form({ rating }))).status, 200);
  for (const message of ['', '   \n  ', 'x'.repeat(4001), 5, null, ['a'], { a: 1 }]) assert.equal((await send(form({ message }))).status, 400, JSON.stringify(message).slice(0, 20));
  assert.equal((await send(form({ message: 'x'.repeat(4000) }))).status, 200);
  assert.equal((await send(form({ message: '😀'.repeat(2000) }))).status, 200, '2,000 emoji is 4,000 UTF-16 units: fine, and fits the column');
  assert.equal((await send(form({ message: '😀'.repeat(2001) }))).status, 400);
});

test('a message keeps its line breaks, loses control characters, and is stored as written otherwise (including anything that looks like code)', async () => {
  const text = "First line\r\n\r\n\r\n\r\nSecond\u0000 line\u0007\n'; DROP TABLE feedback; --\n<script>alert(1)</script>";
  const r = await send(form({ message: text }));
  assert.equal(r.status, 200);
  const [row] = await rows('SELECT message FROM feedback WHERE reference = $1', [r.body.reference]);
  assert.equal(row.message, "First line\n\nSecond line\n'; DROP TABLE feedback; --\n<script>alert(1)</script>");
  assert.ok((await rows('SELECT count(*)::int AS n FROM feedback'))[0].n > 0);
});

test('screen and version are short codes or dropped, never stored as typed', async () => {
  const r = await send(form({ screen: 'Repos <b>', appVersion: '1.0; DROP' }));
  const [row] = await rows('SELECT screen, app_version FROM feedback WHERE reference = $1', [r.body.reference]);
  assert.deepEqual(row, { screen: null, app_version: null });
});

test('the same key with a different feedback is refused (409); a malformed key is refused (400)', async () => {
  const k = key();
  const first = await svc.post('/v1/feedback', form({ message: 'First thing' }), { 'Idempotency-Key': k });
  const other = await svc.post('/v1/feedback', form({ message: 'Another thing' }), { 'Idempotency-Key': k });
  assert.equal(other.status, 409); assert.equal(other.body.reason, 'idempotency_conflict');
  assert.equal((await svc.post('/v1/feedback', form({ message: 'First thing' }), { 'Idempotency-Key': k })).body.reference, first.body.reference);
  assert.equal((await svc.post('/v1/feedback', form(), { 'Idempotency-Key': 'bad key!' })).body.reason, 'bad_idempotency_key');
});

test('a parallel burst cannot get past the per-address limit', async () => {
  const email = `burst-${Date.now()}@acme.example.test`;
  const results = await Promise.all(Array.from({ length: 16 }, () => send(form({ email }))));
  assert.equal(results.filter(r => r.status === 200).length, FEEDBACK_PER_HOUR);
  assert.equal((await rows('SELECT count(*)::int AS n FROM feedback WHERE email = $1', [email]))[0].n, FEEDBACK_PER_HOUR);
});

test('a hidden character in an address is a 400, and hidden characters are removed from a message', async () => {
  for (const email of ['a\u0000b@acme.example.test', 'a\u200bb@acme.example.test', 'a\u202eb@acme.example.test']) assert.equal((await send(form({ email }))).status, 400, JSON.stringify(email));
  const r = await send(form({ message: 'hello\u202e world\u200b' }));
  assert.equal((await rows('SELECT message FROM feedback WHERE reference = $1', [r.body.reference]))[0].message, 'hello world');
  assert.equal((await send(form({ message: ' '.repeat(31_000) }))).status, 400);
});

test('feedback cannot be emptied or edited even by TRUNCATE', async () => {
  await assert.rejects(svc.db.query('TRUNCATE feedback'), /append-only/);
});

test('weird bodies are 400s, never 500s', async () => {
  for (const body of [[], 'text', 5, null, '{', '[]', JSON.stringify([{ category: 'idea' }])]) {
    const r = await svc.post('/v1/feedback', typeof body === 'string' ? body : JSON.stringify(body), { 'Idempotency-Key': key() });
    assert.equal(r.status, 400, JSON.stringify(body));
  }
  const big = await svc.post('/v1/feedback', { category: 'idea', message: 'x'.repeat(40_000) });
  assert.equal(big.status, 413);
  const wrongType = await fetch(`${svc.base}/v1/feedback`, { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'category=idea' });
  assert.equal(wrongType.status, 400);
});

test('the same submit twice (a dropped connection) gets the same reference and makes one row', async () => {
  const k = key(), body = form({ message: 'Retry me' });
  const first = await svc.post('/v1/feedback', body, { 'Idempotency-Key': k });
  const again = await svc.post('/v1/feedback', body, { 'Idempotency-Key': k });
  assert.equal(again.body.reference, first.body.reference);
  assert.equal(again.headers.get('idempotent-replay'), 'true');
  assert.equal((await rows('SELECT count(*)::int AS n FROM feedback WHERE message = $1', ['Retry me']))[0].n, 1);
});

test('six copies of one submit at once make exactly one row', async () => {
  const k = key();
  const results = await Promise.all(Array.from({ length: 6 }, () => svc.post('/v1/feedback', form({ message: 'Racing copies' }), { 'Idempotency-Key': k })));
  assert.ok(results.every(r => r.status === 200));
  assert.equal(new Set(results.map(r => r.body.reference)).size, 1);
  assert.equal((await rows('SELECT count(*)::int AS n FROM feedback WHERE message = $1', ['Racing copies']))[0].n, 1);
});

test('limits: ten per email address and ten per machine in an hour; a replay is answered whatever the limit says', async () => {
  const m = machine();
  for (let i = 0; i < FEEDBACK_PER_HOUR; i++) assert.equal((await send(form({ machineId: m }))).status, 200);
  const over = await send(form({ machineId: m }));
  assert.equal(over.status, 429); assert.equal(over.body.reason, 'too_many_requests');
  assert.equal((await send(form({ machineId: machine() }))).status, 200, 'another machine is unaffected');

  const email = 'chatty@acme.example.test';
  let last;
  for (let i = 0; i < FEEDBACK_PER_HOUR; i++) last = await send(form({ email }));
  assert.equal(last.status, 200);
  assert.equal((await send(form({ email: email.toUpperCase() }))).status, 429);

  const k = key();
  const first = await svc.post('/v1/feedback', form({ message: 'Before the limit' }), { 'Idempotency-Key': k });
  for (let i = 0; i < FEEDBACK_PER_HOUR; i++) await send(form({ email: 'late@acme.example.test' }));
  assert.equal((await svc.post('/v1/feedback', form({ message: 'Before the limit' }), { 'Idempotency-Key': k })).body.reference, first.body.reference);
});

test('feedback is append-only: it can be neither edited nor deleted', async () => {
  const r = await send(form());
  await assert.rejects(svc.db.query(`UPDATE feedback SET message = 'edited' WHERE reference = $1`, [r.body.reference]), /append-only/);
  await assert.rejects(svc.db.query('DELETE FROM feedback WHERE reference = $1', [r.body.reference]), /append-only/);
});

test('the support list view shows category labels and what was said', async () => {
  const r = await send(form({ category: 'bug', message: 'View me', rating: 2 }));
  const [v] = await rows('SELECT category, rating, message, screen FROM v_feedback WHERE reference = $1', [r.body.reference]);
  assert.deepEqual(v, { category: 'Something is wrong', rating: 2, message: 'View me', screen: 'repos' });
});

test('a database fault is a 5xx, never a refusal: the app must treat it as an outage', async () => {
  const broken = await startService({ db: { query: async () => { throw new Error('connection refused: 10.0.0.5:5432'); } } });
  try {
    const r = await broken.post('/v1/feedback', form());
    assert.equal(r.status, 500); assert.equal(r.body.error, 'internal');
    assert.ok(!JSON.stringify(r.body).includes('10.0.0.5'));
    assert.ok(!JSON.stringify(broken.logs).includes('10.0.0.5'), 'nor does the log carry the address');
  } finally { await broken.close(); }
});

test('what people wrote, their address and their machine id never appear in a log line', async () => {
  const m = machine();
  await send(form({ email: 'logcheck@acme.example.test', message: 'A very private sentence about our build server', machineId: m }));
  const text = JSON.stringify(svc.logs);
  assert.ok(svc.logs.length > 10);
  for (const secret of ['logcheck@', 'private sentence', m, 'fb-key-']) assert.ok(!text.includes(secret), secret);
});
