'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createShutdown } = require('../src/shutdown');

const listen = server => new Promise(r => server.listen(0, '127.0.0.1', r));

test('shutdown: stops accepting, ends pools, exits 0 once drained; runs only once', async () => {
  const server = http.createServer((_q, s) => s.end('ok'));
  await listen(server);
  const calls = []; let code;
  const done = new Promise(r => { code = r; });
  const stop = createShutdown({ server, pools: [{ end: async () => calls.push('end1') }, { end: async () => { calls.push('end2'); throw new Error('x'); } }], timeoutMs: 1000, exit: c => code(c), log: () => {} });
  stop('SIGTERM'); stop('SIGINT');
  assert.equal(await done, 0);
  assert.deepEqual(calls, ['end1', 'end2']);
  assert.equal(server.listening, false);
});

test('shutdown: force-exits with 1 when a connection will not drain before the timeout', async () => {
  const server = http.createServer(() => { /* never answers */ });
  await listen(server);
  const req = http.get({ host: '127.0.0.1', port: server.address().port }).on('error', () => {});
  await new Promise(r => setTimeout(r, 50));
  const done = new Promise(r => { createShutdown({ server, pools: [], timeoutMs: 100, exit: r, log: () => {} })('SIGTERM'); });
  assert.equal(await done, 1);
  req.destroy(); server.closeAllConnections();
});
