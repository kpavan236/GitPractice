'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { startService } = require('./helpers/server');

const base = { SUPPORT_DATABASE_URL: 'postgres://x/s', HASH_PEPPER: 'p'.repeat(32) };

test('configuration: required settings, ranges, the support mailbox, and what production refuses', () => {
  const c = loadConfig(base);
  assert.deepEqual([c.port, c.supportMailbox, c.printNotices, c.trustProxy], [4040, null, false, 0]);
  assert.throws(() => loadConfig({ ...base, SUPPORT_DATABASE_URL: '' }), /SUPPORT_DATABASE_URL/);
  assert.throws(() => loadConfig({ ...base, HASH_PEPPER: '' }), /HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, HASH_PEPPER: 'short' }), /HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, PORT: 'x' }), /PORT/);
  assert.throws(() => loadConfig({ ...base, NOTIFIER: 'smtp' }), /NOTIFIER/);
  assert.equal(loadConfig({ ...base, SUPPORT_MAILBOX: ' Support@Example.test ' }).supportMailbox, 'support@example.test');
  assert.throws(() => loadConfig({ ...base, SUPPORT_MAILBOX: 'a@b.test, c@d.test' }), /SUPPORT_MAILBOX/);
  assert.equal(loadConfig({ ...base, DEV_PRINT_NOTICES: '1' }).printNotices, true);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production' }), /TRUST_PROXY/);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', TRUST_PROXY: '1', ALLOW_PLAIN_HTTP: '1' }), /approved email sender/);
});

test('health and readiness; an unknown route is a 404 in the standard shape', async () => {
  const svc = await startService();
  try {
    assert.equal((await svc.call('GET', '/healthz')).body.ok, true);
    assert.equal((await svc.call('GET', '/readyz')).status, 200);
    const nf = await svc.call('GET', '/v1/nope');
    assert.equal(nf.status, 404); assert.equal(nf.body.error, 'not_found'); assert.ok(nf.body.requestId);
    assert.equal(nf.headers.get('cache-control'), 'no-store');
    const down = await startService({ db: { query: async () => { throw new Error('down'); } } });
    try { assert.equal((await down.call('GET', '/readyz')).status, 503); } finally { await down.close(); }
  } finally { await svc.close(); }
});

test('TLS settings: both or neither, production needs TLS or an explicit plain-HTTP opt-out, shutdown timeout range', () => {
  const c = loadConfig(base);
  assert.deepEqual([c.tls, c.tlsCertFile, c.tlsKeyFile, c.shutdownTimeoutMs], [false, null, null, 10_000]);
  const both = loadConfig({ ...base, TLS_CERT_FILE: '/x/cert.pem', TLS_KEY_FILE: '/x/key.pem' });
  assert.deepEqual([both.tls, both.tlsCertFile, both.tlsKeyFile], [true, '/x/cert.pem', '/x/key.pem']);
  assert.throws(() => loadConfig({ ...base, TLS_CERT_FILE: '/x/cert.pem' }), /TLS_KEY_FILE/);
  assert.throws(() => loadConfig({ ...base, TLS_KEY_FILE: '/x/key.pem' }), /TLS_CERT_FILE/);
  const prod = { ...base, NODE_ENV: 'production', TRUST_PROXY: '0' };
  assert.throws(() => loadConfig(prod), /ALLOW_PLAIN_HTTP/);
  // with TLS or the opt-out, the TLS rule passes and the (separate) email-sender rule is what remains
  assert.throws(() => loadConfig({ ...prod, ALLOW_PLAIN_HTTP: '1' }), /approved email sender/);
  assert.throws(() => loadConfig({ ...prod, TLS_CERT_FILE: '/x/c', TLS_KEY_FILE: '/x/k' }), /approved email sender/);
  assert.equal(loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: '2500' }).shutdownTimeoutMs, 2500);
  assert.throws(() => loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: '0' }), /SHUTDOWN_TIMEOUT_MS/);
});

test('headers: Referrer-Policy always; HSTS only when TLS is on', async () => {
  const { createApp } = require('../src/app');
  const get = async tls => {
    const app = createApp({ db: { query: async () => ({}) }, hashPepper: 'p'.repeat(32), tls, log: () => {} });
    const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
    try { return (await fetch(`http://127.0.0.1:${server.address().port}/healthz`)).headers; }
    finally { await new Promise(r => { server.close(r); server.closeAllConnections(); }); }
  };
  const plain = await get(false), secure = await get(true);
  assert.equal(plain.get('referrer-policy'), 'no-referrer');
  assert.equal(plain.get('strict-transport-security'), null);
  assert.match(secure.get('strict-transport-security'), /max-age=\d+/);
});
