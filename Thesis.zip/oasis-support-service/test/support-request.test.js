'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { SUPPORT_REQUESTS_PER_HOUR, SUPPORT_REQUESTS_PER_MACHINE_PER_HOUR } = require('../src/routes/messages');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const form = (over = {}) => ({ subject: 'Cannot connect to Jenkins', message: 'The Setup tab says the token is rejected, but it worked yesterday.', contactName: 'Pat Example', email: 'Pat@Acme.Example.Test', appVersion: '2.0.1', ...over });
const rows = (sql, params) => svc.db.query(sql, params).then(r => r.rows);
let n = 0;
const key = () => `sr-key-${++n}-${Date.now()}`;
const machine = () => crypto.randomBytes(16).toString('hex');
const send = (body, headers = {}) => svc.post('/v1/support-request', body, { 'Idempotency-Key': key(), ...headers });
const unique = () => `u${++n}-${Date.now().toString(36)}@acme.example.test`;

test('a request is stored with a reference and status NEW, and only the fields the form asks for', async () => {
  const r = await send({ ...form(), status_code: 'CLOSED', assigned_to_user_id: '0190aaaa-0000-7000-8000-000000000000', customer_ref: '0190aaaa-0000-7000-8000-000000000001', phone: '555 0100' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.match(r.body.reference, /^SR-\d{6}$/);
  assert.deepEqual(Object.keys(r.body).sort(), ['ok', 'reference']);
  const [row] = await rows('SELECT * FROM support_request WHERE reference = $1', [r.body.reference]);
  assert.deepEqual([row.subject, row.contact_name, row.email, row.app_version], ['Cannot connect to Jenkins', 'Pat Example', 'pat@acme.example.test', '2.0.1']);
  assert.equal(row.status_code, 'NEW', 'a person cannot set the status');
  assert.equal(row.assigned_to_user_id, null); assert.equal(row.customer_ref, null);
  const history = await rows('SELECT to_status_code, reason, changed_by_user_id FROM support_request_status_history WHERE support_request_id = $1', [row.support_request_id]);
  assert.deepEqual(history, [{ to_status_code: 'NEW', reason: 'Submitted', changed_by_user_id: null }]);
});

test('every field but the machine is required, with a message per field; nothing is stored and nothing is echoed back', async () => {
  const before = (await rows('SELECT count(*)::int AS n FROM support_request'))[0].n;
  const r = await send({ subject: '', message: '   ', contactName: '', email: 'not-an-email' });
  assert.equal(r.status, 400); assert.equal(r.body.reason, 'invalid');
  for (const f of ['subject', 'message', 'contactName', 'email']) assert.ok(r.body.errors[f], f);
  assert.ok(!JSON.stringify(r.body).includes('not-an-email'));
  assert.equal((await send(form({ email: undefined }))).body.errors.email, 'Enter a valid email address.', 'an address is the only way to reply, so it is required');
  assert.equal((await rows('SELECT count(*)::int AS n FROM support_request'))[0].n, before);
});

test('lengths: subject 150, name 150, message 4,000; the wrong type is a refusal, not an error', async () => {
  assert.equal((await send(form({ subject: 'x'.repeat(150), contactName: 'n'.repeat(150), message: 'm'.repeat(4000), email: unique() }))).status, 200);
  for (const over of [{ subject: 'x'.repeat(151) }, { contactName: 'n'.repeat(151) }, { message: 'm'.repeat(4001) }, { subject: 5 }, { subject: ['a'] }, { message: { a: 1 } }, { contactName: null }, { email: ['a@b.test'] }, { email: 'a@b.test, c@d.test' }, { email: `${'a'.repeat(250)}@b.test` }]) {
    const r = await send(form({ ...over, email: over.email || unique() }));
    assert.equal(r.status, 400, JSON.stringify(over).slice(0, 40)); assert.equal(r.body.reason, 'invalid');
  }
});

test('a subject is one line and a name is one line, even if a line break is sent; a message keeps its breaks; control characters go', async () => {
  const r = await send(form({ subject: 'Two\nlines\r\there\u0000', contactName: 'Pat\nExample', message: 'a\r\n\r\n\r\nb\u0007c', email: unique() }));
  const [row] = await rows('SELECT subject, contact_name, message FROM support_request WHERE reference = $1', [r.body.reference]);
  assert.deepEqual(row, { subject: 'Two lines here', contact_name: 'Pat Example', message: 'a\n\nbc' });
});

test('the machine id is optional and kept only as a keyed hash, the same one the feedback route makes', async () => {
  const m = machine();
  const r = await send(form({ machineId: m, email: unique() }));
  const [row] = await rows('SELECT installation_ref FROM support_request WHERE reference = $1', [r.body.reference]);
  const f = await svc.post('/v1/feedback', { category: 'bug', message: 'same machine', machineId: m }, { 'Idempotency-Key': key() });
  const [fb] = await rows('SELECT installation_ref FROM feedback WHERE reference = $1', [f.body.reference]);
  assert.match(row.installation_ref, /^[0-9a-f]{64}$/);
  assert.equal(row.installation_ref, fb.installation_ref, 'so support can see one machine\'s feedback and requests together');
  assert.ok(!JSON.stringify(await rows('SELECT * FROM support_request')).includes(m));
  for (const bad of ['short', 'x'.repeat(100), 5, ['a'.repeat(20)]]) {
    const x = await send(form({ machineId: bad, email: unique() }));
    assert.equal(x.status, 200);
    assert.equal((await rows('SELECT installation_ref FROM support_request WHERE reference = $1', [x.body.reference]))[0].installation_ref, null, 'a malformed id is dropped, not an error');
  }
});

test('the same submit twice, or six identical copies at once, makes one request and one notice', async () => {
  const k = key(), body = form({ subject: 'Retry me', email: unique() });
  const noticesBefore = svc.notifier.supportNotices.length;
  const first = await svc.post('/v1/support-request', body, { 'Idempotency-Key': k });
  const again = await svc.post('/v1/support-request', body, { 'Idempotency-Key': k });
  assert.equal(again.body.reference, first.body.reference);
  assert.equal(again.headers.get('idempotent-replay'), 'true');

  const k2 = key(), same = form({ subject: 'Racing copies', email: unique() });
  const results = await Promise.all(Array.from({ length: 6 }, () => svc.post('/v1/support-request', same, { 'Idempotency-Key': k2 })));
  assert.ok(results.every(r => r.status === 200), JSON.stringify(results.map(r => r.status)));
  assert.equal(new Set(results.map(r => r.body.reference)).size, 1);
  assert.equal((await rows(`SELECT count(*)::int AS n FROM support_request WHERE subject IN ('Retry me', 'Racing copies')`))[0].n, 2);
  assert.equal(svc.notifier.supportNotices.length - noticesBefore, 2, 'one notice for each real request, none for a replay');
});

test('a key is bound to its message: the same key with a different message is refused, never silently dropped', async () => {
  const k = key(), email = unique();
  const first = await svc.post('/v1/support-request', form({ email, subject: 'First' }), { 'Idempotency-Key': k });
  const other = await svc.post('/v1/support-request', form({ email, subject: 'A different message' }), { 'Idempotency-Key': k });
  assert.equal(other.status, 409); assert.equal(other.body.reason, 'idempotency_conflict');
  assert.equal((await rows('SELECT count(*)::int AS n FROM support_request WHERE email = $1', [email]))[0].n, 1);
  const tell = await svc.post('/v1/support-request', form({ email, subject: 'First' }), { 'Idempotency-Key': k });
  assert.equal(tell.body.reference, first.body.reference, 'the real retry still works');
  for (const bad of ['short', 'has spaces in it', 'x'.repeat(101), 'semi;colon;key', '']) {
    const r = await svc.post('/v1/support-request', form({ email: unique() }), { 'Idempotency-Key': bad });
    assert.equal(r.status, 400, JSON.stringify(bad)); assert.equal(r.body.reason, 'bad_idempotency_key');
  }
});

test('without a key a retry is a new message (that is why the app sends one); nothing breaks', async () => {
  const email = unique();
  const a = await svc.post('/v1/support-request', form({ email })), b = await svc.post('/v1/support-request', form({ email }));
  assert.equal(a.status, 200); assert.equal(b.status, 200);
  assert.notEqual(a.body.reference, b.body.reference);
});

test('a parallel burst cannot get past the limit: twelve at once for one address store at most five', async () => {
  const email = unique();
  const results = await Promise.all(Array.from({ length: 12 }, () => send(form({ email }))));
  assert.equal(results.filter(r => r.status === 200).length, SUPPORT_REQUESTS_PER_HOUR);
  assert.ok(results.filter(r => r.status !== 200).every(r => r.status === 429));
  assert.equal((await rows('SELECT count(*)::int AS n FROM support_request WHERE email = $1', [email]))[0].n, SUPPORT_REQUESTS_PER_HOUR);
});

test('the refusal at the limit does not promise that support has the message (nothing was stored)', async () => {
  const email = unique();
  for (let i = 0; i < SUPPORT_REQUESTS_PER_HOUR; i++) await send(form({ email }));
  const r = await send(form({ email }));
  assert.equal(r.status, 429);
  assert.ok(!/in touch|received|we have/i.test(r.body.message), r.body.message);
});

test('limits: five per email address and ten per machine in an hour, and a replay beats the limit', async () => {
  const email = unique();
  for (let i = 0; i < SUPPORT_REQUESTS_PER_HOUR; i++) assert.equal((await send(form({ email }))).status, 200);
  const over = await send(form({ email: email.toUpperCase() }));
  assert.equal(over.status, 429); assert.equal(over.body.reason, 'too_many_requests');
  assert.equal((await send(form({ email: unique() }))).status, 200, 'another address is unaffected');

  const m = machine();
  for (let i = 0; i < SUPPORT_REQUESTS_PER_MACHINE_PER_HOUR; i++) assert.equal((await send(form({ email: unique(), machineId: m }))).status, 200);
  assert.equal((await send(form({ email: unique(), machineId: m }))).status, 429);

  const k = key(), e2 = unique();
  const first = await svc.post('/v1/support-request', form({ email: e2 }), { 'Idempotency-Key': k });
  for (let i = 0; i < SUPPORT_REQUESTS_PER_HOUR; i++) await send(form({ email: e2 }));
  assert.equal((await svc.post('/v1/support-request', form({ email: e2 }), { 'Idempotency-Key': k })).body.reference, first.body.reference);
});

// ── The support mailbox (fake sender until an email provider is approved) ────

test('a new request tells the support mailbox once: who and about what, but NOT the message the person wrote', async () => {
  const before = svc.notifier.supportNotices.length;
  const email = unique();
  const r = await send(form({ subject: 'Notice me', contactName: 'Nia Example', email, message: 'A private sentence about our build server' }));
  assert.equal(svc.notifier.supportNotices.length, before + 1);
  const notice = svc.notifier.lastSupportNotice();
  assert.deepEqual({ ...notice, at: 0 }, { to: 'support@support.example.test', reference: r.body.reference, subject: 'Notice me', contactName: 'Nia Example', email, at: 0 });
  assert.ok(!JSON.stringify(notice).includes('private sentence'), 'free text a person typed is not put into an email');
});

test('a refused or over-limit request sends nothing; with no mailbox configured nothing is sent either', async () => {
  const before = svc.notifier.supportNotices.length;
  await send({ subject: '', message: '', contactName: '', email: 'bad' });
  const email = unique();
  for (let i = 0; i < SUPPORT_REQUESTS_PER_HOUR; i++) await send(form({ email }));
  const count = svc.notifier.supportNotices.length;
  assert.equal(count - before, SUPPORT_REQUESTS_PER_HOUR);
  await send(form({ email }));
  assert.equal(svc.notifier.supportNotices.length, count);

  const quiet = await startService({ db: svc.db, supportMailbox: null });
  try { assert.equal((await quiet.post('/v1/support-request', form({ email: unique() }))).status, 200); assert.equal(quiet.notifier.supportNotices.length, 0); }
  finally { await quiet.close(); }
});

test('past the hourly budget of notices the requests are still stored and listed, but the mailbox is not mailed again', async () => {
  const capped = await startService({ db: svc.db, noticesPerHour: 2 });
  try {
    const refs = [];
    for (let i = 0; i < 4; i++) refs.push((await capped.post('/v1/support-request', form({ email: unique() }), { 'Idempotency-Key': key() })).body.reference);
    assert.equal(capped.notifier.supportNotices.length, 2);
    assert.equal((await rows('SELECT count(*)::int AS n FROM support_request WHERE reference = ANY($1)', [refs]))[0].n, 4, 'all four are stored');
    assert.equal(capped.logs.filter(l => l.msg === 'support notice skipped: hourly budget used').length, 2);
  } finally { await capped.close(); }
});

test('an email sender that throws instead of rejecting does not lose the request either', async () => {
  const failing = await startService({ db: svc.db });
  try {
    failing.notifier.notifySupportRequest = () => { throw new Error('sync boom'); };
    const r = await failing.post('/v1/support-request', form({ email: unique() }), { 'Idempotency-Key': key() });
    assert.equal(r.status, 200);
    assert.ok(failing.logs.some(l => l.msg === 'support notice not sent'));
  } finally { await failing.close(); }
});

test('an email address with a hidden character is refused as an address, not a 500', async () => {
  for (const email of ['a\u0000b@acme.example.test', 'a\u200bb@acme.example.test', 'a\u202eb@acme.example.test', 'a\ufeffb@acme.example.test', 'a\u0085b@acme.example.test', 'a\tb@acme.example.test']) {
    const r = await send(form({ email }));
    assert.equal(r.status, 400, JSON.stringify(email)); assert.ok(r.body.errors.email);
  }
});

test('hidden characters that make text read differently are removed from what a person types (and so from the email to support)', async () => {
  const r = await send(form({ subject: 'Invoice\u202e fdp.exe\u200b', contactName: 'Pat\u2066 Example\ufeff', message: 'hello\u202e world', email: unique() }));
  const [row] = await rows('SELECT subject, contact_name, message FROM support_request WHERE reference = $1', [r.body.reference]);
  assert.deepEqual(row, { subject: 'Invoice fdp.exe', contact_name: 'Pat Example', message: 'hello world' });
  assert.deepEqual([svc.notifier.lastSupportNotice().subject, svc.notifier.lastSupportNotice().contactName], ['Invoice fdp.exe', 'Pat Example']);
});

test('a huge message of spaces is refused quickly: cleaning cannot be used to tie the process up', async () => {
  const started = Date.now();
  const r = await send(form({ message: ' '.repeat(31_000), email: unique() }));
  assert.equal(r.status, 400);
  assert.ok(Date.now() - started < 1000);
  const big = await send(form({ message: `${' '.repeat(15_000)}real text`, email: unique() }));
  assert.equal(big.status, 200, 'a long run of whitespace before real text is trimmed, not refused');
});

test('if the email cannot be sent the request is still stored and the app is told it worked; the fault is logged without the details', async () => {
  const failing = await startService({ db: svc.db });
  try {
    failing.notifier.notifySupportRequest = async () => { throw new Error('provider down: contact failing@acme.example.test'); };
    const r = await failing.post('/v1/support-request', form({ email: 'failing@acme.example.test' }), { 'Idempotency-Key': key() });
    assert.equal(r.status, 200);
    assert.equal((await rows('SELECT count(*)::int AS n FROM support_request WHERE reference = $1', [r.body.reference]))[0].n, 1);
    const line = failing.logs.find(l => l.msg === 'support notice not sent');
    assert.ok(line && line.reference === r.body.reference);
    assert.ok(!JSON.stringify(failing.logs).includes('failing@acme.example.test'));
  } finally { await failing.close(); }
});

// ── What the database guarantees (support's tools will rely on it) ───────────

async function newRequest(extra = {}) {
  const r = await send(form({ email: unique(), ...extra }));
  return (await rows('SELECT support_request_id AS id FROM support_request WHERE reference = $1', [r.body.reference]))[0].id;
}
const move = (id, to, reason) => svc.db.connect().then(async c => {
  try {
    await c.query('BEGIN');
    if (reason !== undefined) await c.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await c.query('UPDATE support_request SET status_code = $2 WHERE support_request_id = $1', [id, to]);
    await c.query('COMMIT');
  } catch (err) { await c.query('ROLLBACK'); throw err; } finally { c.release(); }
});

test('a status move needs a reason and must be an allowed one; every move is on record; closed is final', async () => {
  const id = await newRequest();
  await assert.rejects(move(id, 'IN_PROGRESS'), /needs a reason/);
  await move(id, 'IN_PROGRESS', 'Picked up by Sam');
  await assert.rejects(move(id, 'NEW', 'back again'), /cannot go from IN_PROGRESS to NEW/);
  await move(id, 'RESOLVED', 'Answered by email');
  await move(id, 'IN_PROGRESS', 'The person wrote back');
  await move(id, 'CLOSED', 'Sorted');
  await assert.rejects(move(id, 'IN_PROGRESS', 'reopen'), /cannot go from CLOSED/);
  const h = await rows('SELECT from_status_code, to_status_code, reason FROM support_request_status_history WHERE support_request_id = $1 ORDER BY changed_at', [id]);
  assert.deepEqual(h.map(x => `${x.from_status_code || '-'}>${x.to_status_code}`), ['->NEW', 'NEW>IN_PROGRESS', 'IN_PROGRESS>RESOLVED', 'RESOLVED>IN_PROGRESS', 'IN_PROGRESS>CLOSED']);
  assert.equal(h[1].reason, 'Picked up by Sam');
  await assert.rejects(svc.db.query('DELETE FROM support_request_status_history'), /append-only/);
  await assert.rejects(svc.db.query(`UPDATE support_request_status_history SET reason = 'edited'`), /append-only/);
});

test('what a person submitted can never be edited, by anyone', async () => {
  const id = await newRequest({ machineId: machine() });
  const id2 = await newRequest({ appVersion: '2.0.1' });
  for (const col of ["subject = 'x'", "message = 'x'", "contact_name = 'x'", "email = 'x@y.test'", "reference = 'SR-999999'", "installation_ref = NULL", "created_at = now() - interval '1 day'",
    "idempotency_key = 'changed-key-123'", "app_version = '9.9.9'", "request_hash = NULL", "support_request_id = gen_random_uuid()"]) {
    await assert.rejects(svc.db.query(`UPDATE support_request SET ${col} WHERE support_request_id = ANY($1)`, [[id, id2]]), /What a person submitted cannot be edited/, col);
  }
  await assert.rejects(svc.db.query('TRUNCATE support_request, feedback, support_note, support_request_status_history CASCADE'), /append-only/);
  await svc.db.query('UPDATE support_request SET assigned_to_user_id = gen_random_uuid() WHERE support_request_id = $1', [id]);      // assigning is allowed
});

test('notes are append-only, and the list view counts them', async () => {
  const id = await newRequest();
  const author = crypto.randomUUID();
  await svc.db.query('INSERT INTO support_note (note_id, support_request_id, author_user_id, body) VALUES (gen_random_uuid(), $1, $2, $3)', [id, author, 'Called the customer']);
  await assert.rejects(svc.db.query(`UPDATE support_note SET body = 'edited'`), /append-only/);
  await assert.rejects(svc.db.query('DELETE FROM support_note'), /append-only/);
  const [v] = await rows('SELECT status, notes, hours_open_or_to_close, email_domain FROM v_support_request WHERE support_request_id = $1', [id]);
  assert.deepEqual([v.status, v.notes, v.email_domain], ['New', 1, 'acme.example.test']);
});

test('a database fault is a 5xx and is logged without the address or the words', async () => {
  const broken = await startService({ db: { query: async () => { throw Object.assign(new Error('connection refused 10.0.0.5 for secret@acme.example.test'), { code: 'ECONNREFUSED' }); } } });
  try {
    const r = await broken.post('/v1/support-request', form());
    assert.equal(r.status, 500); assert.equal(r.body.error, 'internal');
    const text = JSON.stringify(broken.logs);
    assert.ok(!text.includes('10.0.0.5') && !text.includes('secret@'));
  } finally { await broken.close(); }
});

test('what people wrote, their name and address, and their machine id never appear in a log line', async () => {
  const m = machine();
  await send(form({ subject: 'Distinctive subject line', message: 'A very private sentence about our build server', contactName: 'Zelda Distinct', email: 'logcheck2@acme.example.test', machineId: m }));
  const text = JSON.stringify(svc.logs);
  assert.ok(svc.logs.length > 10);
  for (const secret of ['Distinctive subject', 'private sentence', 'Zelda', 'logcheck2@', m, 'sr-key-']) assert.ok(!text.includes(secret), secret);
});
