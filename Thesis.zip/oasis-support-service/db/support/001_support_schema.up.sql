-- Support database (PostgreSQL 16): what people send from the OASIS app. Two kinds of message, kept apart because they are handled differently:
--
--   feedback         "this tab is slow", "I like this": anonymous-capable, append-only, nothing to reply to unless an address was given.
--   support_request  "I need help": needs an address (the ONLY way to reply), has a status, an owner, notes, and a history of every move.
--
-- Personal data: an email address, a contact name, and FREE TEXT (a person may write anything in a message). All marked -- PII. There is no phone
-- number anywhere. A machine id is never stored: only a keyed hash (installation_ref), so a message can be matched to a machine by someone who
-- holds the machine id, and by nobody else.
-- Conventions: uuid keys (UUIDv7, made by the application); times are timestamptz (UTC); references are what the person is shown (FB-000123, SR-000123).

BEGIN;

CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

-- ── Reference (lookup) tables ───────────────────────────────────────────────

CREATE TABLE feedback_category (category_code text PRIMARY KEY, label text NOT NULL);
INSERT INTO feedback_category (category_code, label) VALUES ('bug', 'Something is wrong'), ('idea', 'An idea'), ('praise', 'Something works well'), ('other', 'Something else');

CREATE TABLE request_status (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL, is_closed boolean NOT NULL);
INSERT INTO request_status (status_code, label, sort_order, is_closed) VALUES
  ('NEW', 'New', 1, false), ('IN_PROGRESS', 'Being looked at', 2, false), ('RESOLVED', 'Answered', 3, false), ('CLOSED', 'Closed', 4, true);

CREATE TABLE request_status_transition (
  from_status_code text NOT NULL REFERENCES request_status (status_code),
  to_status_code   text NOT NULL REFERENCES request_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code),
  CHECK (from_status_code <> to_status_code)
);
INSERT INTO request_status_transition (from_status_code, to_status_code) VALUES
  ('NEW', 'IN_PROGRESS'), ('NEW', 'RESOLVED'), ('NEW', 'CLOSED'),
  ('IN_PROGRESS', 'RESOLVED'), ('IN_PROGRESS', 'CLOSED'),
  ('RESOLVED', 'IN_PROGRESS'), ('RESOLVED', 'CLOSED');          -- a person may write back after an answer; a closed request stays closed

CREATE SEQUENCE feedback_number_seq;
CREATE SEQUENCE support_request_number_seq;

-- ── Feedback ────────────────────────────────────────────────────────────────

CREATE TABLE feedback (
  feedback_id      uuid PRIMARY KEY,
  reference        text NOT NULL UNIQUE DEFAULT 'FB-' || lpad(nextval('feedback_number_seq')::text, 6, '0'),
  idempotency_key  text UNIQUE CHECK (idempotency_key IS NULL OR char_length(idempotency_key) BETWEEN 8 AND 100),   -- one per submit: a retry finds the same row
  category_code    text NOT NULL REFERENCES feedback_category (category_code),
  rating           smallint CHECK (rating IS NULL OR rating BETWEEN 1 AND 5),
  message          text NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 4000),     -- PII: free text, may hold anything
  email            text CHECK (email IS NULL OR (char_length(email) <= 254 AND email = lower(email) AND email ~ '^[^@[:space:],;<>]+@[^@[:space:],;<>]+\.[^@[:space:],;<>]{2,}$')),   -- PII; optional
  app_version      text CHECK (app_version IS NULL OR char_length(app_version) <= 20),
  screen           text CHECK (screen IS NULL OR screen ~ '^[a-z0-9-]{1,40}$'),               -- which tab it was sent from
  installation_ref text CHECK (installation_ref IS NULL OR installation_ref ~ '^[0-9a-f]{64}$'),   -- keyed hash of the machine id, never the id
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX feedback_recent        ON feedback (created_at);
CREATE INDEX feedback_by_category   ON feedback (category_code, created_at);
CREATE INDEX feedback_by_email      ON feedback (email, created_at) WHERE email IS NOT NULL;           -- the per-address rate limit
CREATE INDEX feedback_by_machine    ON feedback (installation_ref, created_at) WHERE installation_ref IS NOT NULL;
CREATE TRIGGER feedback_append_only BEFORE UPDATE OR DELETE ON feedback FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ── Support requests ────────────────────────────────────────────────────────

CREATE TABLE support_request (
  support_request_id uuid PRIMARY KEY,
  reference          text NOT NULL UNIQUE DEFAULT 'SR-' || lpad(nextval('support_request_number_seq')::text, 6, '0'),
  idempotency_key    text UNIQUE CHECK (idempotency_key IS NULL OR char_length(idempotency_key) BETWEEN 8 AND 100),
  subject            text NOT NULL CHECK (char_length(btrim(subject)) BETWEEN 1 AND 150),
  message            text NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 4000),    -- PII: free text
  contact_name       text NOT NULL CHECK (char_length(btrim(contact_name)) BETWEEN 1 AND 150),   -- PII
  email              text NOT NULL CHECK (char_length(email) <= 254 AND email = lower(email) AND email ~ '^[^@[:space:],;<>]+@[^@[:space:],;<>]+\.[^@[:space:],;<>]{2,}$'),   -- PII; the only way to reply
  app_version        text CHECK (app_version IS NULL OR char_length(app_version) <= 20),
  installation_ref   text CHECK (installation_ref IS NULL OR installation_ref ~ '^[0-9a-f]{64}$'),
  status_code        text NOT NULL DEFAULT 'NEW' REFERENCES request_status (status_code),
  status_changed_at  timestamptz NOT NULL DEFAULT clock_timestamp(),
  assigned_to_user_id uuid,                                                      -- a staff user in the identity database; no cross-database FK
  customer_ref       uuid,                                                       -- the customer database's customer id, once support has linked it
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  row_version        int NOT NULL DEFAULT 1
);
CREATE INDEX support_request_open     ON support_request (created_at) WHERE status_code IN ('NEW', 'IN_PROGRESS', 'RESOLVED');
CREATE INDEX support_request_by_email ON support_request (email, created_at);                  -- the per-address rate limit
CREATE INDEX support_request_by_machine ON support_request (installation_ref, created_at) WHERE installation_ref IS NOT NULL;
CREATE INDEX support_request_assignee ON support_request (assigned_to_user_id) WHERE assigned_to_user_id IS NOT NULL;

CREATE TABLE support_request_status_history (
  history_id         uuid PRIMARY KEY,
  support_request_id uuid NOT NULL REFERENCES support_request (support_request_id),
  from_status_code   text REFERENCES request_status (status_code),                 -- null for the first status
  to_status_code     text NOT NULL REFERENCES request_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,                                                          -- null when the system made it (a new request)
  reason             text NOT NULL CHECK (char_length(reason) BETWEEN 1 AND 500)    -- every move is explained
);
CREATE INDEX support_request_history_request ON support_request_status_history (support_request_id, changed_at);
CREATE TRIGGER support_request_history_append_only BEFORE UPDATE OR DELETE ON support_request_status_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE support_note (
  note_id            uuid PRIMARY KEY,
  support_request_id uuid NOT NULL REFERENCES support_request (support_request_id),
  author_user_id     uuid NOT NULL,                                                 -- a staff user in the identity database
  body               text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 4000),
  created_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX support_note_request ON support_note (support_request_id, created_at);
CREATE TRIGGER support_note_append_only BEFORE UPDATE OR DELETE ON support_note FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A status move must be an allowed one and carry a reason (set app.reason, and app.actor_id, inside the transaction, as in the other databases).
-- What the person wrote is never edited: support adds notes and moves the status, nothing else.
CREATE FUNCTION support_request_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM request_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A support request cannot go from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A support request status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  IF NEW.subject IS DISTINCT FROM OLD.subject OR NEW.message IS DISTINCT FROM OLD.message OR NEW.contact_name IS DISTINCT FROM OLD.contact_name
     OR NEW.email IS DISTINCT FROM OLD.email OR NEW.reference IS DISTINCT FROM OLD.reference OR NEW.created_at IS DISTINCT FROM OLD.created_at
     OR NEW.installation_ref IS DISTINCT FROM OLD.installation_ref THEN
    RAISE EXCEPTION 'What a person submitted cannot be edited.' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER support_request_before_update BEFORE UPDATE ON support_request FOR EACH ROW EXECUTE FUNCTION support_request_before_update();

CREATE FUNCTION support_request_write_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO support_request_status_history (history_id, support_request_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.support_request_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid,
            CASE WHEN TG_OP = 'INSERT' THEN 'Submitted' ELSE btrim(current_setting('app.reason', true)) END);
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER support_request_history_write AFTER INSERT OR UPDATE ON support_request FOR EACH ROW EXECUTE FUNCTION support_request_write_history();

-- ── Read views for the support team's lists (their screens are later work) ──

CREATE VIEW v_support_request AS
SELECT r.support_request_id, r.reference, r.subject, r.contact_name, r.email, split_part(r.email, '@', 2) AS email_domain,
       s.label AS status, s.is_closed, r.status_changed_at, r.assigned_to_user_id, r.customer_ref, r.app_version, r.created_at,
       round(extract(epoch FROM (CASE WHEN s.is_closed THEN r.status_changed_at ELSE now() END - r.created_at)) / 3600.0, 1) AS hours_open_or_to_close,
       (SELECT count(*) FROM support_note n WHERE n.support_request_id = r.support_request_id)::int AS notes
FROM support_request r JOIN request_status s ON s.status_code = r.status_code;

CREATE VIEW v_feedback AS
SELECT f.feedback_id, f.reference, c.label AS category, f.rating, f.message, f.email, f.app_version, f.screen, f.created_at
FROM feedback f JOIN feedback_category c ON c.category_code = f.category_code;

COMMIT;
