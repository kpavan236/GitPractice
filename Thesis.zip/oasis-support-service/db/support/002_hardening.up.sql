-- Support database, migration 002: hardening found in review.
--
-- 1. request_hash: a retry (same Idempotency-Key) must be the SAME message. The key alone used to return the first reference for any body, so a client that
--    reused a key lost every later message and was told it had worked. The service now stores a keyed hash of what was submitted and refuses a mismatch.
-- 2. TRUNCATE: the append-only guard was a row trigger, so TRUNCATE walked past it. It is blocked as well.
-- 3. What a person submitted also includes its idempotency key, id and app version: none of them may be edited.

BEGIN;

ALTER TABLE feedback        ADD COLUMN request_hash text CHECK (request_hash IS NULL OR request_hash ~ '^[0-9a-f]{64}$');
ALTER TABLE support_request ADD COLUMN request_hash text CHECK (request_hash IS NULL OR request_hash ~ '^[0-9a-f]{64}$');

CREATE TRIGGER feedback_no_truncate                        BEFORE TRUNCATE ON feedback                        FOR EACH STATEMENT EXECUTE FUNCTION forbid_change();
CREATE TRIGGER support_request_no_truncate                 BEFORE TRUNCATE ON support_request                 FOR EACH STATEMENT EXECUTE FUNCTION forbid_change();
CREATE TRIGGER support_request_history_no_truncate         BEFORE TRUNCATE ON support_request_status_history  FOR EACH STATEMENT EXECUTE FUNCTION forbid_change();
CREATE TRIGGER support_note_no_truncate                    BEFORE TRUNCATE ON support_note                    FOR EACH STATEMENT EXECUTE FUNCTION forbid_change();

CREATE OR REPLACE FUNCTION support_request_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM request_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A support request cannot go from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A support request status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  IF NEW.subject IS DISTINCT FROM OLD.subject OR NEW.message IS DISTINCT FROM OLD.message OR NEW.contact_name IS DISTINCT FROM OLD.contact_name
     OR NEW.email IS DISTINCT FROM OLD.email OR NEW.reference IS DISTINCT FROM OLD.reference OR NEW.created_at IS DISTINCT FROM OLD.created_at
     OR NEW.installation_ref IS DISTINCT FROM OLD.installation_ref OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
     OR NEW.support_request_id IS DISTINCT FROM OLD.support_request_id OR NEW.app_version IS DISTINCT FROM OLD.app_version
     OR NEW.request_hash IS DISTINCT FROM OLD.request_hash THEN
    RAISE EXCEPTION 'What a person submitted cannot be edited.' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;

COMMIT;
