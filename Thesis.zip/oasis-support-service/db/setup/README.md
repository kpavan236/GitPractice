# Support database setup

Plain SQL to build the support database (PostgreSQL 16) from nothing. These files are for a **new, empty** database.
For day-to-day schema changes use `npm run migrate` (`db/support/`).

| File | Run as | What it does |
|---|---|---|
| `00_create_database_and_roles.sql` | superuser, connected to `postgres` | Creates the database (default `support_db`), an application role (default `oasis_support_app`, placeholder password), grants, default privileges. No extensions needed. |
| `01_support_schema_and_seed.sql` | the same superuser, connected to the new database | **Generated** from `db/support/` by `npm run db:setup:build`: every table, index, view, trigger, function, constraint and all reference data (feedback categories, request statuses and allowed moves), plus the `schema_migration` rows. |
| `02_optional_dev_data.sql` | same | **DEV ONLY.** A few synthetic rows (`example.test` addresses, invented names). |

Never edit 01 by hand: change `db/support/` and rebuild. Run 01 once per database (the migrations do not use `IF NOT EXISTS`).

## Run

Replace the placeholders. Do not put real passwords on a command line or in a file in the repo.

```bash
psql -v ON_ERROR_STOP=1 -h HOST -U ADMIN_USER -d postgres    -f db/setup/00_create_database_and_roles.sql
psql -v ON_ERROR_STOP=1 -h HOST -U ADMIN_USER -d support_db  -f db/setup/01_support_schema_and_seed.sql
psql -v ON_ERROR_STOP=1 -h HOST -U ADMIN_USER -d support_db  -f db/setup/02_optional_dev_data.sql    # local development only
```

Options for 00: `-v dbname=NAME`, `-v app_role=ROLE`. The role is created with the password `CHANGE_ME_use_a_secret_manager`, a placeholder: set the real one from your
secret manager (`ALTER ROLE oasis_support_app PASSWORD '...'`, typed in psql, not stored in a file).

Then point the service at it: `SUPPORT_DATABASE_URL=postgres://oasis_support_app:PASSWORD@HOST:5432/support_db`.
The application role has no DDL rights; run `npm run migrate` with an administrative connection. Because 01 records the migrations with their checksums, it reports `up to date`.

## Verify

```sql
\dt                                                       -- 8 tables: feedback, feedback_category, request_status, request_status_transition,
                                                          --          schema_migration, support_note, support_request, support_request_status_history
\dv                                                       -- v_feedback, v_support_request
SELECT filename FROM schema_migration ORDER BY filename;  -- 001_support_schema.up.sql, 002_hardening.up.sql
SELECT count(*) FROM feedback_category;                   -- 4
SELECT count(*) FROM request_status;                      -- 4
SELECT count(*) FROM request_status_transition;           -- 7
```

After 02: 3 `feedback`, 2 `support_request`, 3 `support_request_status_history`, 1 `support_note`.

## Reset (local development only, destroys data)

```bash
psql -v ON_ERROR_STOP=1 -h HOST -U ADMIN_USER -d postgres -c 'DROP DATABASE support_db WITH (FORCE)'
```

then run 00 and 01 again. Check the database name twice before dropping; never do this to a shared or production database.

## Personal data

Real rows hold email addresses, names and free-text messages. Only the synthetic rows in 02 belong in a development database.
