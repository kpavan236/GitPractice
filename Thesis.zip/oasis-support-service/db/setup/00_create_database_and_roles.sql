-- Support database: create the database and the application role. Run as a PostgreSQL superuser (or a role with CREATEDB and CREATEROLE), connected to
-- the maintenance database "postgres", with psql (it uses psql meta-commands):
--
--   psql -v ON_ERROR_STOP=1 -d postgres -f 00_create_database_and_roles.sql
--
-- Optional psql variables (defaults in brackets): dbname [support_db], app_role [oasis_support_app].
-- Example: psql -v ON_ERROR_STOP=1 -v dbname=support_db -d postgres -f 00_create_database_and_roles.sql
--
-- The password below is a PLACEHOLDER. Replace it with a value from your secret manager before running anywhere but a throwaway local machine,
-- or run "ALTER ROLE ... PASSWORD" afterwards. Never commit a real password.
-- Re-runnable: an existing database or role is left as it is.

\if :{?dbname}
\else
  \set dbname support_db
\endif
\if :{?app_role}
\else
  \set app_role oasis_support_app
\endif

-- Application role: can log in, owns nothing, cannot create databases or roles.
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE', :'app_role', 'CHANGE_ME_use_a_secret_manager')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'app_role') \gexec

-- The database (CREATE DATABASE cannot run inside a transaction, hence \gexec). Owned by the role running this script.
SELECT format('CREATE DATABASE %I ENCODING ''UTF8''', :'dbname')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = :'dbname') \gexec

REVOKE ALL ON DATABASE :"dbname" FROM PUBLIC;
GRANT CONNECT ON DATABASE :"dbname" TO :"app_role";

\connect :"dbname"

-- Extensions: none are required. gen_random_uuid() (used by the status-history trigger) is built into PostgreSQL 13 and later; this schema targets 16.

REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO :"app_role";

-- Objects are created by 01_support_schema_and_seed.sql, run as the SAME superuser as this file. These default privileges give the application role what the
-- service and oasis-support-portal need on them: read and write rows and use the reference sequences. No DELETE or TRUNCATE (the tables that hold
-- submissions are append-only by trigger anyway), and no DDL: schema changes ("npm run migrate") use an administrative connection.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE ON TABLES TO :"app_role";
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO :"app_role";
