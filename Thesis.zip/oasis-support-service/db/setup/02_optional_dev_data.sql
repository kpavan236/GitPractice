-- DEV ONLY. Synthetic sample rows for local development. Never run this against a shared, staging or production database.
-- Every name, address and message below is invented (addresses use the reserved example.test domain). No real personal data.
-- Run after 01, against the support database: psql -v ON_ERROR_STOP=1 -d support_db -f 02_optional_dev_data.sql

BEGIN;

INSERT INTO feedback (feedback_id, category_code, rating, message, email, app_version, screen) VALUES
  ('00000000-0000-7000-8000-000000000001', 'idea',   4, 'DEV SAMPLE: it would help to have a larger text option.', 'sample.one@example.test', '1.0.0', 'home'),
  ('00000000-0000-7000-8000-000000000002', 'praise', 5, 'DEV SAMPLE: this tab loads quickly.', NULL, '1.0.0', 'reports'),
  ('00000000-0000-7000-8000-000000000003', 'bug',    NULL, 'DEV SAMPLE: the button does nothing on my sample device.', 'sample.two@example.test', '1.0.1', NULL);

INSERT INTO support_request (support_request_id, subject, message, contact_name, email, app_version) VALUES
  ('00000000-0000-7000-8000-0000000000a1', 'DEV SAMPLE: cannot sign in', 'DEV SAMPLE: invented text for local testing only.', 'Sample Person One', 'sample.person.one@example.test', '1.0.0'),
  ('00000000-0000-7000-8000-0000000000a2', 'DEV SAMPLE: question about a screen', 'DEV SAMPLE: invented text for local testing only.', 'Sample Person Two', 'sample.person.two@example.test', '1.0.1');

-- A status move needs a reason (and may name the staff user), set for this transaction only (SET LOCAL semantics).
SELECT set_config('app.reason', 'DEV SAMPLE: picked up for local testing', true), set_config('app.actor_id', '00000000-0000-7000-8000-0000000000b1', true);
UPDATE support_request SET status_code = 'IN_PROGRESS', assigned_to_user_id = '00000000-0000-7000-8000-0000000000b1'
WHERE support_request_id = '00000000-0000-7000-8000-0000000000a1';

INSERT INTO support_note (note_id, support_request_id, author_user_id, body) VALUES
  ('00000000-0000-7000-8000-0000000000c1', '00000000-0000-7000-8000-0000000000a1', '00000000-0000-7000-8000-0000000000b1', 'DEV SAMPLE: invented staff note.');

COMMIT;
