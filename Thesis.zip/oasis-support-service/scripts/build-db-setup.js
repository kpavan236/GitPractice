'use strict';
// Regenerates db/setup/01_support_schema_and_seed.sql from db/support/*.sql, so the setup file cannot drift from the migrations.
// Usage: npm run db:setup:build      (no dependencies)
// It follows src/migrate.js: files matching /^\d+_.*\.sql$/ that do not end in .down.sql, in file-name order, and one schema_migration row per
// file holding the sha256 of the file's UTF-8 text, so a later `npm run migrate` sees every file as already applied.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const root = path.join(__dirname, '..');
const migrationsDir = path.join(root, 'db', 'support');
const outFile = path.join(root, 'db', 'setup', '01_support_schema_and_seed.sql');

const files = fs.readdirSync(migrationsDir).filter(f => /^\d+_.*\.sql$/.test(f) && !f.endsWith('.down.sql')).sort();
if (!files.length) throw new Error(`No migration files found in ${migrationsDir}`);

const parts = [
  `-- GENERATED FILE. Do not edit by hand: run "npm run db:setup:build" (scripts/build-db-setup.js) after any change in db/support/.
-- Complete support database setup: every migration in db/support/ in order (schema, indexes, views, triggers, functions, reference data),
-- plus the schema_migration bookkeeping rows that src/migrate.js would write (filename + sha256 checksum of the file), so "npm run migrate"
-- afterwards reports "up to date".
-- Run it against the support database, e.g.: psql -v ON_ERROR_STOP=1 -d support_db -f 01_support_schema_and_seed.sql
-- Do not run it twice on the same database (the migrations create objects without IF NOT EXISTS).
`,
  `-- ── Migration bookkeeping table (as created by src/migrate.js) ──
CREATE TABLE IF NOT EXISTS schema_migration (filename text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now());
`,
];
for (const file of files) {
  const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
  const checksum = crypto.createHash('sha256').update(sql).digest('hex');
  parts.push(`-- ════════════════════════════════════════════════════════════════════════
-- Source: db/support/${file}
-- ════════════════════════════════════════════════════════════════════════
${sql.endsWith('\n') ? sql : sql + '\n'}
INSERT INTO schema_migration (filename, checksum) VALUES ('${file}', '${checksum}');
`);
}
fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, parts.join('\n'));
console.log(`wrote ${path.relative(root, outFile)} from ${files.length} migration(s): ${files.join(', ')}`);
