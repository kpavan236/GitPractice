# oasis-support-service

Feedback and "contact support" messages from the i-Ready OASIS app. A person does not need a licence to use either, so both routes are open to any
caller and protected by validation, limits and the way the data is kept.

Plan: `oasis-licence-service/docs/plans/2026-10-08-activation-blocking-support-plan.md`, section 7 (task T6). The app reaches this service through the
same base URL as the licence service once a gateway exists; until then it is called directly.

## Overview

- Receives two kinds of message from the OASIS app: **feedback** (anonymous allowed) and **support requests** (an email address is required, it is the only way to reply).
- Validates and cleans them, applies limits, stores them in the support PostgreSQL database and answers with a reference (`FB-000123`, `SR-000123`).
- For a new support request it can announce who and about what to a support mailbox (a fake sender today, see "Faked until IT approves it").
- Staff work these in **`oasis-support-portal`**, which reads this database: list, open one, assign, move the status, link a customer, add notes, and read feedback.
  This service has no staff-facing endpoints.

## Tech stack

Node.js 22 or later (`engines` in `package.json`), Express 4, `pg` 8 (PostgreSQL 16 schema), the built-in `node:test` runner. No other runtime dependencies.

## Prerequisites

- Node.js 22 or later and npm.
- PostgreSQL 16, reachable from where you run the service. For local work and tests: `docker run --name oasis-pg -e POSTGRES_PASSWORD=local-dev-only -p 5433:5432 postgres:16`
  (a local, test-only password; use a secret manager everywhere else).

## Quick start

```bash
npm install
cp .env.example .env            # fill in HASH_PEPPER and SUPPORT_DATABASE_URL; never commit .env
set -a; . ./.env; set +a        # the service reads the environment; it does not load .env itself
npm run migrate                 # applies db/support, once each, with checksums
npm start                       # listens on PORT (default 4040)
curl localhost:4040/healthz     # {"ok":true}
```

To create the database and role from scratch with plain SQL instead, see [db/setup/README.md](db/setup/README.md).

## Configuration

Read once at start-up by `src/config.js`; a missing or malformed value stops the service with a message. `.env.example` holds placeholders only.

| Variable | Required | Default | Meaning |
|---|---|---|---|
| `PORT` | no | `4040` | HTTP port, a whole number 1 to 65535. |
| `SUPPORT_DATABASE_URL` | yes | none | PostgreSQL connection string for the support database, e.g. `postgres://USER:PASSWORD@HOST:5432/support_db`. Also used by `npm run migrate`. Holds a password: keep it in a secret store. |
| `HASH_PEPPER` | yes | none | At least 32 random characters. Keys the HMAC-SHA-256 hashes of machine ids (and of the request fingerprint used for `Idempotency-Key`). Keep it in a secret store. Changing it stops old messages matching a machine. |
| `SUPPORT_MAILBOX` | no | unset | One email address that is told about each new support request (who and about what, never the message). Unset means no email. |
| `TRUST_PROXY` | in production | `0` | Number of proxies in front of the service, 0 to 10. Must be set when `NODE_ENV=production`. Must equal the real number: it decides which address the per-caller limit counts. |
| `NOTIFIER` | no | `fake` | Only `fake` exists until an email provider is approved (IT Helpdesk, cainc.service-now.com); any other value stops start-up. |
| `DEV_PRINT_NOTICES` | no | `0` | `1` prints the reference of each support notice to the terminal. Development only. |
| `TLS_CERT_FILE`, `TLS_KEY_FILE` | both or neither | unset | Paths to PEM certificate and key files. When both are set the service serves HTTPS itself and sends `Strict-Transport-Security`. Setting only one stops start-up. |
| `ALLOW_PLAIN_HTTP` | no | unset | `1` lets `NODE_ENV=production` start without TLS files. Only for a hosting platform that terminates TLS for the service. Without it, production and no TLS files stops start-up. |
| `SHUTDOWN_TIMEOUT_MS` | no | `10000` | On SIGTERM/SIGINT the service stops accepting, lets in-flight requests finish, ends the database pool and exits; after this many milliseconds (1 to 600000) it exits anyway with code 1. |

`NODE_ENV=production` currently stops start-up whatever else is set, because only the fake sender exists (`src/config.js`).
`TEST_PG_ADMIN_URL` is read by the tests only (see "Test"); it is not in `.env.example`.

## Project structure

```
src/server.js         start-up: config, database pool, app, graceful shutdown
src/app.js            builds the Express app: request id, headers, health routes, /v1 router, 404, error handler
src/routes/messages.js POST /v1/feedback and POST /v1/support-request
src/forms.js          input rules and cleaning (email, text, version, screen, machine id, Idempotency-Key)
src/config.js         environment settings, checked once
src/secrets.js        keyed hashing (HASH_PEPPER)
src/rate-limit.js     per-caller limit in the process
src/notifier.js       the fake email sender (swap point, see docs/fakes.md)
src/errors.js         ApiError, refusals, error handler
src/db.js, uuid.js    pool and transaction helper; UUIDv7
src/migrate.js        migration runner for db/support
db/support/           migrations (001 schema, 002 hardening)
db/setup/             one-shot SQL setup for a new database (see db/setup/README.md)
scripts/              build-db-setup.js
docs/fakes.md         what is faked and what the real one must do
test/                 node:test files and helpers (real PostgreSQL)
```

## API endpoints

Two `POST` routes under `/v1` (JSON), plus two health routes.

### Routes (`POST`, JSON, under `/v1`)

| Route | Body | Answer |
|---|---|---|
| `/feedback` | `category` (`bug`, `idea`, `praise`, `other`), `message` (1 to 4,000), optional `email`, optional `rating` (1 to 5), `appVersion`, optional `screen` (which tab), optional `machineId` | `{ ok, reference: "FB-000123" }` |
| `/support-request` | `subject` (1 to 150), `message` (1 to 4,000), `contactName` (1 to 150), `email` (required: the only way to reply), `appVersion`, optional `machineId` | `{ ok, reference: "SR-000123" }` |

Field rules as `src/forms.js` enforces them: text has control characters and invisible characters removed (a message keeps its line breaks), lengths are counted after cleaning;
`email` is one address, trimmed and lower-cased, at most 254 characters; `category` is matched ignoring case; `rating` must be a whole number; unknown fields are dropped.
`appVersion` (up to 20 of letters, digits, `.`, `+`, `-`), `screen` (lower-case letters, digits, `-`, up to 40) and `machineId` (16 to 64 of letters, digits, `_`, `-`) are optional:
a value that does not fit is dropped, not refused.

- Send an `Idempotency-Key` header (8 to 100 letters, digits, `-` or `_`) once per submit. **The key is bound to the message**: the same key and the same message is a retry (the first answer comes back with `Idempotent-Replay: true`, never a second row); the same key with a different message is `409 idempotency_conflict`; a malformed key is `400 bad_idempotency_key`. Without a key a retry is a new message.
- 400 `invalid` with `errors` (a message per field), 400 `bad_json`, 404 `not_found`, 429 `too_many_requests`, 413 over 32 KB, 5xx for any fault (the app treats that as "unavailable" and never as a refusal).
- Limits per hour: feedback 10 per email address and 10 per machine; support requests 5 per address and 10 per machine, checked under a lock so a parallel burst cannot pass them; plus a per-network-address limit in the process (an IPv6 caller is counted by its /64) and at most 60 emails to the support mailbox an hour from one process (the requests are all stored and listed regardless).
- Every answer carries an `X-Request-Id` (a valid inbound one is reused), `Cache-Control: no-store` and `X-Content-Type-Options: nosniff`.
- Contact is **by email only**. No phone number is collected anywhere.

### Health routes

`GET /healthz` answers `{ "ok": true }`. `GET /readyz` runs `SELECT 1` and answers `{ "ok": true }`, or 503 `{ "ok": false }` when the database is unreachable.

## What it stores (`db/support`)

- `feedback`: append-only. `support_request`: a status (`NEW`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`), an owner, and a **history of every move with a reason**, written by the
  database. What a person submitted can never be edited, and a closed request stays closed. `support_note`: append-only notes by staff. Views `v_support_request` and `v_feedback` are
  what the support team's lists will read.
- **A machine id is never stored**, only a keyed hash (`HASH_PEPPER`). The same machine gives the same hash in both tables, so support can see its feedback and requests together.
- Personal data: the email address, the contact name, and **the free text** (a person may write anything in a message; it may hold secrets pasted by mistake). All marked `-- PII` in the schema.

## Scripts

| Script | What it does |
|---|---|
| `npm start` | `node src/server.js` (settings from the environment). |
| `npm run start:local` | The same, loading `.env` with `node --env-file=.env`. |
| `npm run migrate` | Applies `db/support/*.sql` (not `*.down.sql`) in name order, once each, recording a checksum in `schema_migration`; stops if an applied file has changed. Needs `SUPPORT_DATABASE_URL`. |
| `npm test` | `node --test "test/**/*.test.js"` |
| `npm run db:setup:build` | Regenerates `db/setup/01_support_schema_and_seed.sql` from `db/support/`. Run it after any migration change. |

## Database

The support database is a separate PostgreSQL 16 database (default name `support_db`); this service and `oasis-support-portal` point at it, and it refers to other
services' data by id only. Schema changes live in `db/support/` as numbered migrations. To set up a new database in one go (database, application role, full schema and
reference data, optional synthetic dev rows) use the SQL in [`db/setup/`](db/setup/README.md).

## Privacy notes

**These are personal data and must be handled as such:**

- `email` (feedback optional, support request required), `contact_name`, and the **free-text** `message` (and `subject`) are stored as written. A person may type anything,
  including personal details or secrets pasted by mistake. They are marked `-- PII` in the schema and are shown by the `v_support_request` and `v_feedback` views.
- Staff notes (`support_note.body`) can also contain personal data.
- The machine id is never stored; only a keyed hash (`installation_ref`).
- Nothing a person wrote is logged, emailed or echoed in an error (see "Rules this code keeps"). Keep database access, backups and exports to people who need them.
- There is no retention or purge job yet (see "Not built"). Do not load real personal data into a local or shared development database; use the synthetic rows in `db/setup/02_optional_dev_data.sql`.

## Test

```bash
npm test
```

Real PostgreSQL, a throwaway database per file (`TEST_PG_ADMIN_URL`, default `postgres://postgres:local-dev-only@localhost:5433/postgres`, the local container from
"Prerequisites"). Tests create the database, run the migrations, and drop it afterwards. Files: `config`, `feedback`, `support-request`, `rate-limit`.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| `HASH_PEPPER is required.` / `must be at least 32 characters` / `SUPPORT_DATABASE_URL is required.` | The environment is not loaded: `.env` is not read automatically (see Quick start). |
| `NOTIFIER must be "fake"` or `Production needs an approved email sender` | Only the fake sender exists; do not set `NODE_ENV=production` yet. |
| `TRUST_PROXY must be set in production` | Set it to the number of proxies (0 if none). |
| `<file> was applied and has since changed` from `npm run migrate` | An applied migration was edited. Revert it and add a new numbered file. |
| `Cannot reach PostgreSQL for the tests` | Start PostgreSQL on port 5433 or set `TEST_PG_ADMIN_URL`. |
| `/readyz` answers 503 | The service cannot reach `SUPPORT_DATABASE_URL`. |
| Every caller gets 429 | `TRUST_PROXY` is lower than the real proxy count, so all callers share one address. |
| 409 `idempotency_conflict` | The same `Idempotency-Key` was sent with a different message. |

## Faked until IT approves it

The email to the support mailbox is a fake. **`docs/fakes.md` lists it, its swap point and what the real one must do.** Production refuses to start with it.

## Rules this code keeps

- **Nothing a person wrote reaches a log, an email or an error.** Logs hold method, path, status, time and a request id; a refusal never echoes what was typed; the support notice carries
  who and about what, never the message. An internal fault is logged by its kind and code only.
- 4xx only for a person's mistake; anything unexpected is 5xx.
- A message is text: control characters are removed, line breaks kept, and it is stored as written otherwise. It is never interpreted.
- A request is stored **before** anyone is told, and telling the team is best effort: a mail fault never loses a request or makes the app think it failed.

## Decisions I made

1. **No block check here.** The block list lives in the licence service's database, and a service must not read another's. A blocked machine can still send feedback or ask for help, which
   is arguably right (a person whose licence was revoked may need to contact support). The gateway's access check will cover it when it exists.
2. **A support request needs an email address, feedback does not.** Without an address there is nothing to reply to.
3. **The notice to the mailbox omits the message** (see `docs/fakes.md`).
4. **Staff reading and answering these lives in `oasis-support-portal`** (it reads this database): list, open one, assign, move the status, link a customer, add notes, and read feedback.

## Known limits (not fixed)

- The per-address and per-machine limits can be sidestepped by varying the address and the machine id, so the real ceiling is the network-address limit in the process (30 a minute per caller) plus
  the hourly cap on emails. A gateway limit and retention are needed before this is public. `TRUST_PROXY` must equal the real number of proxies: too low and every caller shares one bucket, too high and a
  caller can invent addresses.
- A limit refusal (429) tells a caller that an address or a machine wrote recently. Accepted: it is the same signal the Buy form gives.
- The email notice is sent after the request is stored and is not retried: a crash between the two loses the notice (not the request).
- References come from a sequence: they are guessable, show volume, and have gaps.
- Updates to a support request must use `SET LOCAL` (or `set_config(..., true)`) for `app.reason` and `app.actor_id` inside a transaction, never `SET` on a pooled connection.

## Not built

- A reply-by-email path, a real email provider (IT Helpdesk), and CA review of the text the app shows after sending.
- A rate limit shared across instances (the limit is per process), TLS, deployment, CI with scanning, and an owner.
- Retention: feedback and support requests have no purge job yet; the plan says the period is still to be set. A person's export or delete path is planned.
- Dependencies: `express` and `pg` (both MIT).

## Email (SMTP) placeholder

Email sending is not implemented. `NOTIFIER=fake` is the only accepted value, and production refuses it until a provider is approved (IT Helpdesk, cainc.service-now.com). `.env.example` reserves the names `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD` and `SMTP_FROM`, commented out and blank. Nothing reads them yet. The owner configures SMTP later; real values belong in the untracked `.env` or a secret store, never in the repository.
