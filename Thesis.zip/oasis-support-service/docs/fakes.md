# Faked integrations (waiting on the IT Helpdesk)

Anything that needs a new external service is **faked** until IT approves it (cainc.service-now.com, IT Helpdesk first). A fake does the
whole job in memory, so every flow works and is tested; going live means writing the real implementation behind the same interface.

| Integration | Interface (the swap point) | What the fake does | What the real one must do |
|---|---|---|---|
| **Email sender** (support-mailbox notice) | `src/notifier.js`: `notifySupportRequest({ to, reference, subject, contactName, email })` | Keeps each notice in memory (last 1,000). `DEV_PRINT_NOTICES=1` prints only the reference. | Deliver the email. Throwing is fine: `src/routes/messages.js` logs it (reference only) and still answers the app, because the request is already stored. Use CA-reviewed wording. |

- The notice carries who and about what, **never the message** a person typed. Keep it that way in the real sender: free text can contain anything, including
  secrets pasted by mistake.
- It holds a customer's name and email address (CA confidential, PII): send it only to `SUPPORT_MAILBOX`, keep it out of logs and analytics.
- `src/config.js` refuses to start in production with the fake sender.
- Feedback sends no email: it is read from the list. Add one only if the volume needs it.
- This notifier mirrors `oasis-licence-service/src/notifier.js`; when there is a real sender, put it in the shared package rather than writing it three times.
