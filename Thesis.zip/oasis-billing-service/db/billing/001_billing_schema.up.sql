-- Billing database (PostgreSQL 16). CA confidential financial data.
--
-- Owns subscriptions (what a customer pays for and how often), invoices and their
-- lines, payments, credit notes, and the monthly billing runs. Customers live in
-- the customer database and licences in the licence database; this database points
-- at them with plain ids and NO cross-database FK. The link between a subscription
-- and its licence is stored HERE only (the licence database does not repeat it).
--
-- Normal forms are explained in README.md. Conventions: uuid keys (UUIDv7, made by
-- the application); times are timestamptz (UTC); business dates are date; money is
-- a whole number of minor units (cents) in *_minor columns, never floating point;
-- columns holding personal data are marked -- PII. The outbox/inbox tables for
-- events come from the shared library's migration.
--
-- Needs the btree_gist extension (standard PostgreSQL contrib) for the "no
-- overlapping versions" constraint.

BEGIN;

CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ── Shared helpers ──────────────────────────────────────────────────────────

CREATE FUNCTION touch_row() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  RETURN NEW;
END $$;

CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

-- ── Reference (lookup) tables ───────────────────────────────────────────────

CREATE TABLE currency (
  currency_code     char(3) PRIMARY KEY CHECK (currency_code ~ '^[A-Z]{3}$'),     -- ISO 4217
  name              text NOT NULL,
  minor_unit_digits smallint NOT NULL CHECK (minor_unit_digits BETWEEN 0 AND 3)   -- 2 for dollars and cents
);
CREATE TABLE billing_interval (interval_code text PRIMARY KEY, label text NOT NULL, months smallint NOT NULL CHECK (months > 0));
CREATE TABLE payment_method   (method_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE subscription_status (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);
CREATE TABLE invoice_status      (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);

-- The allowed status moves are DATA, so the state machines are enforced by the
-- database and a new move is an INSERT, not a code change.
CREATE TABLE subscription_status_transition (
  from_status_code text NOT NULL REFERENCES subscription_status (status_code),
  to_status_code   text NOT NULL REFERENCES subscription_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code), CHECK (from_status_code <> to_status_code)
);
CREATE TABLE invoice_status_transition (
  from_status_code text NOT NULL REFERENCES invoice_status (status_code),
  to_status_code   text NOT NULL REFERENCES invoice_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code), CHECK (from_status_code <> to_status_code)
);

-- Gap-free document numbers (INV-2026-000001, CN-2026-000001). The counter row is
-- locked until the surrounding transaction ends, so two documents never share a
-- number, and a rolled-back document gives its number back.
CREATE TABLE document_number_sequence (
  series      text NOT NULL CHECK (series IN ('INV', 'CN')),
  year        int  NOT NULL CHECK (year BETWEEN 2000 AND 2999),
  last_number int  NOT NULL CHECK (last_number >= 0),
  PRIMARY KEY (series, year)
);

CREATE FUNCTION next_document_number(p_series text, p_year int) RETURNS text LANGUAGE plpgsql AS $$
DECLARE n int;
BEGIN
  INSERT INTO document_number_sequence (series, year, last_number) VALUES (p_series, p_year, 1)
  ON CONFLICT (series, year) DO UPDATE SET last_number = document_number_sequence.last_number + 1
  RETURNING last_number INTO n;
  RETURN format('%s-%s-%s', p_series, p_year, lpad(n::text, 6, '0'));
END $$;

-- ── Subscriptions ───────────────────────────────────────────────────────────

CREATE TABLE subscription (
  subscription_id    uuid PRIMARY KEY,
  customer_id        uuid NOT NULL,                                              -- customer database
  license_id         uuid,                                                       -- licence database; null until the licence exists
  interval_code      text NOT NULL REFERENCES billing_interval (interval_code),
  currency_code      char(3) NOT NULL REFERENCES currency (currency_code),
  status_code        text NOT NULL DEFAULT 'ACTIVE' REFERENCES subscription_status (status_code),
  status_changed_at  timestamptz NOT NULL DEFAULT clock_timestamp(),
  starts_on          date NOT NULL,
  ends_on            date,
  next_billing_on    date,
  payment_terms_days int NOT NULL DEFAULT 30 CHECK (payment_terms_days BETWEEN 0 AND 365),
  auto_renew         boolean NOT NULL DEFAULT true,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  row_version        int NOT NULL DEFAULT 1,
  CHECK (ends_on IS NULL OR ends_on >= starts_on),
  CHECK (status_code NOT IN ('CANCELLED', 'ENDED') OR next_billing_on IS NULL)
);
CREATE INDEX subscription_customer     ON subscription (customer_id, status_code);
CREATE INDEX subscription_license      ON subscription (license_id);
CREATE INDEX subscription_next_billing ON subscription (next_billing_on) WHERE status_code = 'ACTIVE';

CREATE TABLE subscription_status_history (
  history_id         uuid PRIMARY KEY,
  subscription_id    uuid NOT NULL REFERENCES subscription (subscription_id),
  from_status_code   text REFERENCES subscription_status (status_code),
  to_status_code     text NOT NULL REFERENCES subscription_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,
  reason             text NOT NULL CHECK (char_length(reason) BETWEEN 1 AND 500)
);
CREATE INDEX subscription_status_history_sub ON subscription_status_history (subscription_id, changed_at);
CREATE INDEX subscription_status_history_to  ON subscription_status_history (to_status_code, changed_at);
CREATE TRIGGER subscription_status_history_append_only BEFORE UPDATE OR DELETE ON subscription_status_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A subscription's customer and currency never change (start a new one instead), so
-- anything derived from them (an invoice's customer and currency) can never drift.
CREATE FUNCTION subscription_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.currency_code IS DISTINCT FROM OLD.currency_code THEN
    RAISE EXCEPTION 'A subscription''s customer and currency cannot change; start a new subscription.' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM subscription_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A subscription cannot move from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A subscription status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER subscription_before_update BEFORE UPDATE ON subscription FOR EACH ROW EXECUTE FUNCTION subscription_before_update();

CREATE FUNCTION subscription_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO subscription_status_history (history_id, subscription_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.subscription_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid,
            coalesce(nullif(btrim(current_setting('app.reason', true)), ''), 'Subscription created'));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER subscription_status_history_write AFTER INSERT OR UPDATE ON subscription FOR EACH ROW EXECUTE FUNCTION subscription_write_status_history();

-- What is being paid for, versioned: never edited. A price or quantity change
-- closes the current row and opens a new one, so recurring revenue can be rebuilt
-- for any past month. The plan code and description are as sold (the plan itself
-- is in the licence database).
CREATE TABLE subscription_item (
  item_id          uuid PRIMARY KEY,
  subscription_id  uuid NOT NULL REFERENCES subscription (subscription_id),
  plan_code        text NOT NULL,
  description      text NOT NULL CHECK (char_length(btrim(description)) BETWEEN 1 AND 200),
  unit_price_minor bigint NOT NULL CHECK (unit_price_minor >= 0),
  quantity         int NOT NULL CHECK (quantity > 0),
  effective_from   date NOT NULL,
  effective_until  date,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_until IS NULL OR effective_until > effective_from),
  EXCLUDE USING gist (subscription_id WITH =, plan_code WITH =, daterange(effective_from, effective_until) WITH &&)   -- one version at a time
);
CREATE INDEX subscription_item_sub ON subscription_item (subscription_id, effective_from);

CREATE FUNCTION subscription_item_only_close() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'subscription items are never deleted; close them instead' USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.effective_until IS NOT NULL
     OR (NEW.item_id, NEW.subscription_id, NEW.plan_code, NEW.description, NEW.unit_price_minor, NEW.quantity, NEW.effective_from, NEW.created_at)
        IS DISTINCT FROM
        (OLD.item_id, OLD.subscription_id, OLD.plan_code, OLD.description, OLD.unit_price_minor, OLD.quantity, OLD.effective_from, OLD.created_at) THEN
    RAISE EXCEPTION 'a subscription item can only be closed, once; insert a new version instead' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER subscription_item_only_close BEFORE UPDATE OR DELETE ON subscription_item FOR EACH ROW EXECUTE FUNCTION subscription_item_only_close();

-- ── Invoices ────────────────────────────────────────────────────────────────
-- An invoice does not store its customer or currency (its subscription knows both,
-- and neither can change), and it does not store how much has been paid (that is
-- added up from the payments). It starts as a DRAFT, and from the moment it is
-- ISSUED its amounts, lines and bill-to details are frozen: mistakes are fixed with
-- a credit note, never by editing.

CREATE TABLE invoice (
  invoice_id         uuid PRIMARY KEY,
  subscription_id    uuid NOT NULL REFERENCES subscription (subscription_id),
  invoice_number     text UNIQUE CHECK (invoice_number ~ '^INV-[0-9]{4}-[0-9]{6}$'),       -- assigned by the database when issued
  status_code        text NOT NULL DEFAULT 'DRAFT' REFERENCES invoice_status (status_code),
  status_changed_at  timestamptz NOT NULL DEFAULT clock_timestamp(),
  period_start       date NOT NULL,
  period_end         date NOT NULL,
  issued_on          date,
  due_on             date,
  subtotal_minor     bigint NOT NULL DEFAULT 0 CHECK (subtotal_minor >= 0),    -- the sum of the lines, frozen at issue and checked against them
  discount_minor     bigint NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
  tax_minor          bigint NOT NULL DEFAULT 0 CHECK (tax_minor >= 0),         -- the sum of the lines' tax, frozen at issue and checked
  total_minor        bigint NOT NULL DEFAULT 0 CHECK (total_minor >= 0),
  created_by_user_id uuid,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  row_version        int NOT NULL DEFAULT 1,
  CHECK (period_end >= period_start),
  CHECK (discount_minor <= subtotal_minor),
  CHECK (total_minor = subtotal_minor - discount_minor + tax_minor),
  CHECK (status_code IN ('DRAFT', 'CANCELLED') OR (invoice_number IS NOT NULL AND issued_on IS NOT NULL AND due_on IS NOT NULL)),
  CHECK (issued_on IS NULL OR due_on IS NULL OR due_on >= issued_on)
);
-- Generating the same period twice cannot create a second live invoice.
CREATE UNIQUE INDEX invoice_one_per_period ON invoice (subscription_id, period_start) WHERE status_code NOT IN ('VOID', 'CANCELLED');
CREATE INDEX invoice_by_status ON invoice (status_code, due_on);
CREATE INDEX invoice_due       ON invoice (due_on) WHERE status_code IN ('ISSUED', 'SENT', 'OVERDUE');

CREATE TABLE invoice_status_history (
  history_id         uuid PRIMARY KEY,
  invoice_id         uuid NOT NULL REFERENCES invoice (invoice_id),
  from_status_code   text REFERENCES invoice_status (status_code),
  to_status_code     text NOT NULL REFERENCES invoice_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,
  reason             text NOT NULL CHECK (char_length(reason) BETWEEN 1 AND 500)
);
CREATE INDEX invoice_status_history_invoice ON invoice_status_history (invoice_id, changed_at);
CREATE INDEX invoice_status_history_to      ON invoice_status_history (to_status_code, changed_at);
CREATE TRIGGER invoice_status_history_append_only BEFORE UPDATE OR DELETE ON invoice_status_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Who the invoice is addressed to, as it was when issued. Personal data, kept apart
-- from the invoice so the invoice itself carries none. Editable only while DRAFT.
CREATE TABLE invoice_bill_to (                                                   -- PII
  invoice_id     uuid PRIMARY KEY REFERENCES invoice (invoice_id),
  name           text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
  line1          text NOT NULL,
  line2          text,
  city           text NOT NULL,
  state_province text,
  postal_code    text,
  country_code   char(2) NOT NULL CHECK (country_code ~ '^[A-Z]{2}$'),
  tax_id         text
);

CREATE TABLE invoice_line (
  line_id              uuid PRIMARY KEY,
  invoice_id           uuid NOT NULL REFERENCES invoice (invoice_id),
  line_no              int NOT NULL CHECK (line_no >= 1),
  subscription_item_id uuid REFERENCES subscription_item (item_id),             -- null for a manual line
  plan_code            text,
  description          text NOT NULL CHECK (char_length(btrim(description)) BETWEEN 1 AND 200),
  quantity             numeric NOT NULL CHECK (quantity > 0),
  unit_price_minor     bigint NOT NULL CHECK (unit_price_minor >= 0),
  amount_minor         bigint NOT NULL CHECK (amount_minor >= 0),
  tax_rate_bp          int NOT NULL DEFAULT 0 CHECK (tax_rate_bp BETWEEN 0 AND 10000),   -- basis points: 1000 = 10%
  tax_minor            bigint NOT NULL DEFAULT 0 CHECK (tax_minor >= 0),
  UNIQUE (invoice_id, line_no),
  CHECK (amount_minor = round(quantity * unit_price_minor)),                     -- the line adds up
  CHECK (tax_minor = round(amount_minor * tax_rate_bp / 10000.0))                -- and so does its tax
);
CREATE INDEX invoice_line_item ON invoice_line (subscription_item_id);

-- Bill-to details and lines may only change while the invoice is still a draft.
CREATE FUNCTION invoice_child_draft_only() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE st text;
BEGIN
  SELECT status_code INTO st FROM invoice WHERE invoice_id = (CASE WHEN TG_OP = 'DELETE' THEN OLD.invoice_id ELSE NEW.invoice_id END);
  IF st IS DISTINCT FROM 'DRAFT' THEN
    RAISE EXCEPTION 'The invoice is % and can no longer be changed; issue a credit note instead.', st USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END $$;
CREATE TRIGGER invoice_bill_to_draft_only BEFORE INSERT OR UPDATE OR DELETE ON invoice_bill_to FOR EACH ROW EXECUTE FUNCTION invoice_child_draft_only();
CREATE TRIGGER invoice_line_draft_only    BEFORE INSERT OR UPDATE OR DELETE ON invoice_line    FOR EACH ROW EXECUTE FUNCTION invoice_child_draft_only();

CREATE FUNCTION invoice_before_insert() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status_code <> 'DRAFT' OR NEW.invoice_number IS NOT NULL OR NEW.issued_on IS NOT NULL THEN
    RAISE EXCEPTION 'An invoice starts as a draft; its number and issue date are assigned when it is issued.' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER invoice_before_insert BEFORE INSERT ON invoice FOR EACH ROW EXECUTE FUNCTION invoice_before_insert();

CREATE FUNCTION invoice_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  line_sum bigint; tax_sum bigint; line_count int; terms int; paid bigint; credited bigint;
BEGIN
  -- Once issued, nothing that makes up the invoice can change.
  IF OLD.status_code <> 'DRAFT' AND
     (NEW.subscription_id, NEW.period_start, NEW.period_end, NEW.invoice_number, NEW.issued_on, NEW.due_on,
      NEW.subtotal_minor, NEW.discount_minor, NEW.tax_minor, NEW.total_minor)
     IS DISTINCT FROM
     (OLD.subscription_id, OLD.period_start, OLD.period_end, OLD.invoice_number, OLD.issued_on, OLD.due_on,
      OLD.subtotal_minor, OLD.discount_minor, OLD.tax_minor, OLD.total_minor) THEN
    RAISE EXCEPTION 'Invoice % is issued and cannot be changed; issue a credit note instead.', OLD.invoice_id USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.status_code = 'DRAFT' AND NEW.invoice_number IS NOT NULL THEN
    RAISE EXCEPTION 'Invoice numbers are assigned by the database.' USING ERRCODE = 'check_violation';
  END IF;

  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;

  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM invoice_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'An invoice cannot move from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'An invoice status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;

    IF OLD.status_code = 'DRAFT' AND NEW.status_code = 'ISSUED' THEN
      IF NOT EXISTS (SELECT 1 FROM invoice_bill_to WHERE invoice_id = NEW.invoice_id) THEN
        RAISE EXCEPTION 'An invoice needs bill-to details before it can be issued.' USING ERRCODE = 'check_violation';
      END IF;
      SELECT coalesce(sum(amount_minor), 0), coalesce(sum(tax_minor), 0), count(*) INTO line_sum, tax_sum, line_count
        FROM invoice_line WHERE invoice_id = NEW.invoice_id;
      IF line_count = 0 THEN
        RAISE EXCEPTION 'An invoice needs at least one line before it can be issued.' USING ERRCODE = 'check_violation';
      END IF;
      IF line_sum <> NEW.subtotal_minor OR tax_sum <> NEW.tax_minor THEN
        RAISE EXCEPTION 'The lines (% subtotal, % tax) do not match the invoice (% subtotal, % tax).', line_sum, tax_sum, NEW.subtotal_minor, NEW.tax_minor
          USING ERRCODE = 'check_violation';
      END IF;
      SELECT payment_terms_days INTO terms FROM subscription WHERE subscription_id = NEW.subscription_id;
      NEW.issued_on := coalesce(NEW.issued_on, CURRENT_DATE);
      NEW.due_on := coalesce(NEW.due_on, NEW.issued_on + terms);
      NEW.invoice_number := next_document_number('INV', EXTRACT(year FROM NEW.issued_on)::int);
    END IF;

    IF NEW.status_code = 'PAID' THEN
      SELECT coalesce(sum(amount_minor), 0) INTO paid FROM payment WHERE invoice_id = NEW.invoice_id;
      SELECT coalesce(sum(amount_minor), 0) INTO credited FROM credit_note WHERE invoice_id = NEW.invoice_id;
      IF paid + credited < NEW.total_minor THEN
        RAISE EXCEPTION 'The invoice is not fully paid: % paid and % credited of %.', paid, credited, NEW.total_minor USING ERRCODE = 'check_violation';
      END IF;
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION invoice_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO invoice_status_history (history_id, invoice_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.invoice_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid,
            coalesce(nullif(btrim(current_setting('app.reason', true)), ''), 'Invoice created'));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER invoice_status_history_write AFTER INSERT OR UPDATE ON invoice FOR EACH ROW EXECUTE FUNCTION invoice_write_status_history();

-- ── Payments and credit notes ───────────────────────────────────────────────
-- Neither stores a customer or a currency: the invoice knows both. Neither is ever
-- edited; a mistake is reversed with a new row (a negative payment).

CREATE TABLE payment (
  payment_id          uuid PRIMARY KEY,
  invoice_id          uuid NOT NULL REFERENCES invoice (invoice_id),
  amount_minor        bigint NOT NULL CHECK (amount_minor <> 0),                  -- a reversal is negative
  method_code         text NOT NULL REFERENCES payment_method (method_code),
  reference           text,
  received_on         date NOT NULL,
  recorded_by_user_id uuid NOT NULL,
  recorded_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payment_invoice  ON payment (invoice_id);
CREATE INDEX payment_received ON payment (received_on);
CREATE TRIGGER payment_append_only BEFORE UPDATE OR DELETE ON payment FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE credit_note (
  credit_note_id      uuid PRIMARY KEY,
  invoice_id          uuid NOT NULL REFERENCES invoice (invoice_id),
  credit_note_number  text NOT NULL UNIQUE CHECK (credit_note_number ~ '^CN-[0-9]{4}-[0-9]{6}$'),   -- assigned by the database
  amount_minor        bigint NOT NULL CHECK (amount_minor > 0),
  reason              text NOT NULL CHECK (char_length(btrim(reason)) BETWEEN 1 AND 500),
  issued_on           date NOT NULL DEFAULT CURRENT_DATE,
  created_by_user_id  uuid,
  created_at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX credit_note_invoice ON credit_note (invoice_id);
CREATE TRIGGER credit_note_append_only BEFORE UPDATE OR DELETE ON credit_note FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A payment must be for an issued invoice, and the total paid can never go below
-- zero or above what is owed (the total less credit notes). The invoice row is
-- locked so two payments recorded together cannot both slip past the limit.
CREATE FUNCTION payment_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE inv record; paid bigint; credited bigint;
BEGIN
  SELECT status_code, total_minor INTO inv FROM invoice WHERE invoice_id = NEW.invoice_id FOR UPDATE;
  IF inv.status_code NOT IN ('ISSUED', 'SENT', 'OVERDUE', 'PAID') THEN
    RAISE EXCEPTION 'A payment cannot be recorded against a % invoice.', inv.status_code USING ERRCODE = 'check_violation';
  END IF;
  SELECT coalesce(sum(amount_minor), 0) INTO paid FROM payment WHERE invoice_id = NEW.invoice_id;
  SELECT coalesce(sum(amount_minor), 0) INTO credited FROM credit_note WHERE invoice_id = NEW.invoice_id;
  IF paid + NEW.amount_minor < 0 THEN
    RAISE EXCEPTION 'That reversal is larger than what has been paid.' USING ERRCODE = 'check_violation';
  END IF;
  IF paid + NEW.amount_minor > inv.total_minor - credited THEN
    RAISE EXCEPTION 'That payment is more than the amount owed.' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER payment_guard BEFORE INSERT ON payment FOR EACH ROW EXECUTE FUNCTION payment_guard();

CREATE FUNCTION credit_note_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE inv record; credited bigint; paid bigint;
BEGIN
  SELECT status_code, total_minor INTO inv FROM invoice WHERE invoice_id = NEW.invoice_id FOR UPDATE;
  IF inv.status_code NOT IN ('ISSUED', 'SENT', 'OVERDUE', 'PAID') THEN
    RAISE EXCEPTION 'A credit note cannot be raised against a % invoice.', inv.status_code USING ERRCODE = 'check_violation';
  END IF;
  SELECT coalesce(sum(amount_minor), 0) INTO credited FROM credit_note WHERE invoice_id = NEW.invoice_id;
  SELECT coalesce(sum(amount_minor), 0) INTO paid FROM payment WHERE invoice_id = NEW.invoice_id;
  IF credited + NEW.amount_minor > inv.total_minor THEN
    RAISE EXCEPTION 'Credit notes cannot add up to more than the invoice total.' USING ERRCODE = 'check_violation';
  END IF;
  IF paid > inv.total_minor - (credited + NEW.amount_minor) THEN
    RAISE EXCEPTION 'That credit would leave the invoice overpaid; reverse a payment first.' USING ERRCODE = 'check_violation';
  END IF;
  NEW.credit_note_number := next_document_number('CN', EXTRACT(year FROM NEW.issued_on)::int);
  RETURN NEW;
END $$;
CREATE TRIGGER credit_note_guard BEFORE INSERT ON credit_note FOR EACH ROW EXECUTE FUNCTION credit_note_guard();

CREATE TRIGGER invoice_before_update BEFORE UPDATE ON invoice FOR EACH ROW EXECUTE FUNCTION invoice_before_update();

-- ── Billing runs ────────────────────────────────────────────────────────────
-- The monthly job records itself, so a period is billed once and a failure is visible.

CREATE TABLE billing_run (
  run_id           uuid PRIMARY KEY,
  period_start     date NOT NULL,
  period_end       date NOT NULL,
  started_at       timestamptz NOT NULL DEFAULT now(),
  finished_at      timestamptz,
  status           text NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'succeeded', 'failed')),
  invoices_created int NOT NULL DEFAULT 0 CHECK (invoices_created >= 0),
  error            text CHECK (error IS NULL OR char_length(error) <= 1000),
  CHECK (period_end >= period_start),
  CHECK ((finished_at IS NULL) = (status = 'running')),
  CHECK ((status = 'failed') = (error IS NOT NULL))
);
-- A period can only be running or done once; a failed run can be retried.
CREATE UNIQUE INDEX billing_run_one_per_period ON billing_run (period_start, period_end) WHERE status IN ('running', 'succeeded');

-- ── Read views ──────────────────────────────────────────────────────────────

-- An invoice with its customer and currency (through the subscription) and what
-- has been paid and credited, added up from the payments and credit notes.
CREATE VIEW v_invoice AS
SELECT
  i.invoice_id, i.invoice_number, s.customer_id, i.subscription_id, st.label AS status, i.status_changed_at,
  s.currency_code, i.period_start, i.period_end, i.issued_on, i.due_on,
  i.subtotal_minor, i.discount_minor, i.tax_minor, i.total_minor,
  coalesce(c.credited, 0) AS credited_minor,
  coalesce(p.paid, 0)     AS paid_minor,
  i.total_minor - coalesce(c.credited, 0) - coalesce(p.paid, 0) AS balance_due_minor,
  p.last_received_on,
  CASE WHEN i.status_code IN ('ISSUED', 'SENT', 'OVERDUE') AND i.total_minor - coalesce(c.credited, 0) - coalesce(p.paid, 0) > 0
       THEN greatest(0, CURRENT_DATE - i.due_on) ELSE 0 END AS days_overdue
FROM invoice i
JOIN subscription s    ON s.subscription_id = i.subscription_id
JOIN invoice_status st ON st.status_code = i.status_code
LEFT JOIN LATERAL (SELECT sum(amount_minor)::bigint AS paid, max(received_on) AS last_received_on FROM payment WHERE invoice_id = i.invoice_id) p ON true
LEFT JOIN LATERAL (SELECT sum(amount_minor)::bigint AS credited FROM credit_note WHERE invoice_id = i.invoice_id) c ON true;

-- Recurring revenue of every active subscription TODAY, from its current items.
-- ARR is the yearly value; MRR is a twelfth of it (a monthly subscription's MRR is
-- exact; an annual one is rounded to the nearest minor unit).
CREATE VIEW v_subscription_mrr AS
SELECT
  s.subscription_id, s.customer_id, s.currency_code, bi.label AS billing_interval,
  t.price_per_period_minor,
  (t.price_per_period_minor * 12 / bi.months) AS arr_minor,
  ((t.price_per_period_minor * 12 / bi.months) + 6) / 12 AS mrr_minor
FROM subscription s
JOIN billing_interval bi ON bi.interval_code = s.interval_code
JOIN LATERAL (
  SELECT coalesce(sum(unit_price_minor * quantity), 0)::bigint AS price_per_period_minor
  FROM subscription_item it
  WHERE it.subscription_id = s.subscription_id AND it.effective_from <= CURRENT_DATE AND (it.effective_until IS NULL OR it.effective_until > CURRENT_DATE)
) t ON true
WHERE s.status_code = 'ACTIVE';

COMMIT;
