-- Fixed reference data the application relies on. Safe to run more than once.
-- One currency is used at launch; the others are here so adding one later needs no migration.
INSERT INTO currency (currency_code, name, minor_unit_digits) VALUES
  ('USD', 'US dollar', 2), ('CAD', 'Canadian dollar', 2), ('EUR', 'Euro', 2), ('GBP', 'Pound sterling', 2), ('INR', 'Indian rupee', 2)
ON CONFLICT DO NOTHING;

INSERT INTO billing_interval (interval_code, label, months) VALUES ('monthly', 'Monthly', 1), ('annual', 'Annual', 12) ON CONFLICT DO NOTHING;

INSERT INTO payment_method (method_code, label) VALUES
  ('bank_transfer', 'Bank transfer'), ('po', 'Purchase order'), ('cheque', 'Cheque'), ('other', 'Other')
ON CONFLICT DO NOTHING;

INSERT INTO subscription_status (status_code, label, sort_order) VALUES
  ('ACTIVE', 'Active', 1), ('PAUSED', 'Paused', 2), ('CANCELLED', 'Cancelled', 3), ('ENDED', 'Ended', 4)
ON CONFLICT DO NOTHING;
INSERT INTO subscription_status_transition (from_status_code, to_status_code) VALUES
  ('ACTIVE', 'PAUSED'), ('PAUSED', 'ACTIVE'), ('ACTIVE', 'CANCELLED'), ('PAUSED', 'CANCELLED'), ('ACTIVE', 'ENDED'), ('PAUSED', 'ENDED')
ON CONFLICT DO NOTHING;

INSERT INTO invoice_status (status_code, label, sort_order) VALUES
  ('DRAFT', 'Draft', 1), ('ISSUED', 'Issued', 2), ('SENT', 'Sent', 3), ('PAID', 'Paid', 4),
  ('OVERDUE', 'Overdue', 5), ('VOID', 'Void', 6), ('CANCELLED', 'Cancelled', 7)
ON CONFLICT DO NOTHING;
-- CANCELLED is a draft thrown away before it was ever issued. VOID is an issued invoice
-- withdrawn afterwards. Paid invoices are never voided: they are credited. PAID can go
-- back to SENT or OVERDUE only when a payment is reversed.
INSERT INTO invoice_status_transition (from_status_code, to_status_code) VALUES
  ('DRAFT', 'ISSUED'), ('DRAFT', 'CANCELLED'),
  ('ISSUED', 'SENT'), ('ISSUED', 'PAID'), ('ISSUED', 'OVERDUE'), ('ISSUED', 'VOID'),
  ('SENT', 'PAID'), ('SENT', 'OVERDUE'), ('SENT', 'VOID'),
  ('OVERDUE', 'PAID'), ('OVERDUE', 'VOID'),
  ('PAID', 'SENT'), ('PAID', 'OVERDUE')
ON CONFLICT DO NOTHING;
