-- Billing database, migration 003: invoicing for one-off and request-based invoices (spec 2026-10-14-invoicing-design.md).
-- The base schema is subscription-centric. This relaxes that where needed and adds what is missing. Nothing here deletes data.
BEGIN;

-- ── Numbering: receipts join the series ──────────────────────────────────────
ALTER TABLE document_number_sequence DROP CONSTRAINT document_number_sequence_series_check;
ALTER TABLE document_number_sequence ADD CONSTRAINT document_number_sequence_series_check CHECK (series IN ('INV', 'CN', 'RCT'));

-- ── Invoice: customer, currency, owner, source, one-offs ─────────────────────
ALTER TABLE invoice
  ADD COLUMN customer_id                 uuid,
  ADD COLUMN currency_code               char(3) REFERENCES currency (currency_code),
  ADD COLUMN source_purchase_request_id  uuid,                                 -- a plain id: the request lives in the customer database
  ADD COLUMN owner_user_id               uuid,
  ADD COLUMN closed_at                   timestamptz,
  ADD COLUMN notes                       text CHECK (notes IS NULL OR char_length(notes) <= 1000);

UPDATE invoice i SET customer_id = s.customer_id, currency_code = s.currency_code FROM subscription s WHERE s.subscription_id = i.subscription_id AND i.customer_id IS NULL;

-- Required for every new or changed row. Rows from before the migration are already backfilled above (customer, currency); owner is unknown for them, so that check is left unvalidated.
ALTER TABLE invoice
  ADD CONSTRAINT invoice_customer_required CHECK (customer_id IS NOT NULL) NOT VALID,
  ADD CONSTRAINT invoice_currency_required CHECK (currency_code IS NOT NULL) NOT VALID,
  ADD CONSTRAINT invoice_owner_required    CHECK (owner_user_id IS NOT NULL) NOT VALID;
ALTER TABLE invoice VALIDATE CONSTRAINT invoice_customer_required;
ALTER TABLE invoice VALIDATE CONSTRAINT invoice_currency_required;

ALTER TABLE invoice ALTER COLUMN subscription_id DROP NOT NULL, ALTER COLUMN period_start DROP NOT NULL, ALTER COLUMN period_end DROP NOT NULL;
DROP INDEX invoice_one_per_period;
CREATE UNIQUE INDEX invoice_one_per_period ON invoice (subscription_id, period_start) WHERE subscription_id IS NOT NULL AND status_code NOT IN ('VOID', 'CANCELLED');
CREATE INDEX invoice_customer ON invoice (customer_id, status_code);
CREATE INDEX invoice_owner    ON invoice (owner_user_id, status_code);
CREATE INDEX invoice_source   ON invoice (source_purchase_request_id) WHERE source_purchase_request_id IS NOT NULL;

-- ── Lines: a discount is a negative line; tax is an ordinary line ────────────
ALTER TABLE invoice_line DROP CONSTRAINT invoice_line_unit_price_minor_check;
ALTER TABLE invoice_line DROP CONSTRAINT invoice_line_amount_minor_check;

-- ── The invoice trigger: one-offs, negative lines, closed_at, immutable customer and currency ──
CREATE OR REPLACE FUNCTION invoice_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  pos bigint; neg bigint; tax_sum bigint; line_count int; terms int; paid bigint; credited bigint;
BEGIN
  IF OLD.status_code <> 'DRAFT' AND
     (NEW.subscription_id, NEW.period_start, NEW.period_end, NEW.invoice_number, NEW.issued_on, NEW.due_on,
      NEW.subtotal_minor, NEW.discount_minor, NEW.tax_minor, NEW.total_minor, NEW.customer_id, NEW.currency_code)
     IS DISTINCT FROM
     (OLD.subscription_id, OLD.period_start, OLD.period_end, OLD.invoice_number, OLD.issued_on, OLD.due_on,
      OLD.subtotal_minor, OLD.discount_minor, OLD.tax_minor, OLD.total_minor, OLD.customer_id, OLD.currency_code) THEN
    RAISE EXCEPTION 'Invoice % is issued and cannot be changed; issue a credit note instead.', OLD.invoice_id USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.status_code = 'DRAFT' AND NEW.invoice_number IS NOT NULL THEN
    RAISE EXCEPTION 'Invoice numbers are assigned by the database.' USING ERRCODE = 'check_violation';
  END IF;

  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;

  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM invoice_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'An invoice cannot move from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'An invoice status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;

    IF OLD.status_code = 'DRAFT' AND NEW.status_code = 'ISSUED' THEN
      IF NOT EXISTS (SELECT 1 FROM invoice_bill_to WHERE invoice_id = NEW.invoice_id) THEN
        RAISE EXCEPTION 'An invoice needs bill-to details before it can be issued.' USING ERRCODE = 'check_violation';
      END IF;
      SELECT coalesce(sum(amount_minor) FILTER (WHERE amount_minor > 0), 0), coalesce(sum(amount_minor) FILTER (WHERE amount_minor < 0), 0), coalesce(sum(tax_minor), 0), count(*)
        INTO pos, neg, tax_sum, line_count FROM invoice_line WHERE invoice_id = NEW.invoice_id;
      IF line_count = 0 THEN
        RAISE EXCEPTION 'An invoice needs at least one line before it can be issued.' USING ERRCODE = 'check_violation';
      END IF;
      IF pos <> NEW.subtotal_minor OR -neg <> NEW.discount_minor OR tax_sum <> NEW.tax_minor THEN
        RAISE EXCEPTION 'The lines (% charges, % discounts, % tax) do not match the invoice (% subtotal, % discount, % tax).', pos, -neg, tax_sum, NEW.subtotal_minor, NEW.discount_minor, NEW.tax_minor
          USING ERRCODE = 'check_violation';
      END IF;
      IF NEW.total_minor <= 0 THEN
        RAISE EXCEPTION 'The invoice total must be more than zero.' USING ERRCODE = 'check_violation';
      END IF;
      IF NEW.subscription_id IS NOT NULL THEN SELECT payment_terms_days INTO terms FROM subscription WHERE subscription_id = NEW.subscription_id; END IF;
      NEW.issued_on := coalesce(NEW.issued_on, CURRENT_DATE);
      NEW.due_on := coalesce(NEW.due_on, NEW.issued_on + terms);
      IF NEW.due_on IS NULL THEN
        RAISE EXCEPTION 'An invoice needs a due date before it can be issued.' USING ERRCODE = 'check_violation';
      END IF;
      NEW.invoice_number := next_document_number('INV', EXTRACT(year FROM NEW.issued_on)::int);
    END IF;

    IF NEW.status_code = 'PAID' THEN
      SELECT coalesce(sum(amount_minor), 0) INTO paid FROM payment WHERE invoice_id = NEW.invoice_id;
      SELECT coalesce(sum(amount_minor), 0) INTO credited FROM credit_note WHERE invoice_id = NEW.invoice_id;
      IF paid + credited < NEW.total_minor THEN
        RAISE EXCEPTION 'The invoice is not fully paid: % paid and % credited of %.', paid, credited, NEW.total_minor USING ERRCODE = 'check_violation';
      END IF;
      IF NEW.closed_at IS NULL THEN NEW.closed_at := clock_timestamp(); END IF;      -- the first time only: who closed the deal does not change when a payment is reversed
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;

-- ── Payments: receipts, reversals ────────────────────────────────────────────
-- Payments stay append-only. "Voiding" a payment is a negative row that points at it and gives a reason; the original is never edited.
ALTER TABLE payment
  ADD COLUMN receipt_number        text UNIQUE CHECK (receipt_number ~ '^RCT-[0-9]{4}-[0-9]{6}$'),
  ADD COLUMN receipt_issued_on     date,
  ADD COLUMN reverses_payment_id   uuid UNIQUE REFERENCES payment (payment_id),
  ADD COLUMN void_reason           text CHECK (void_reason IS NULL OR char_length(btrim(void_reason)) BETWEEN 1 AND 500);
ALTER TABLE payment ADD CONSTRAINT payment_receipt_or_reversal CHECK (
  (amount_minor > 0 AND receipt_number IS NOT NULL AND receipt_issued_on IS NOT NULL AND reverses_payment_id IS NULL AND void_reason IS NULL)
  OR (amount_minor < 0 AND receipt_number IS NULL AND reverses_payment_id IS NOT NULL AND void_reason IS NOT NULL)) NOT VALID;

CREATE OR REPLACE FUNCTION payment_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE inv record; paid bigint; credited bigint; orig record;
BEGIN
  SELECT status_code, total_minor INTO inv FROM invoice WHERE invoice_id = NEW.invoice_id FOR UPDATE;      -- two payments at once queue here
  IF inv.status_code NOT IN ('ISSUED', 'SENT', 'OVERDUE', 'PAID') THEN
    RAISE EXCEPTION 'A payment cannot be recorded against a % invoice.', inv.status_code USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.reverses_payment_id IS NOT NULL THEN
    SELECT invoice_id, amount_minor INTO orig FROM payment WHERE payment_id = NEW.reverses_payment_id;
    IF orig.invoice_id IS DISTINCT FROM NEW.invoice_id OR orig.amount_minor <= 0 OR NEW.amount_minor <> -orig.amount_minor THEN
      RAISE EXCEPTION 'A reversal must cancel exactly one earlier payment on the same invoice.' USING ERRCODE = 'check_violation';
    END IF;
  END IF;
  SELECT coalesce(sum(amount_minor), 0) INTO paid FROM payment WHERE invoice_id = NEW.invoice_id;
  SELECT coalesce(sum(amount_minor), 0) INTO credited FROM credit_note WHERE invoice_id = NEW.invoice_id;
  IF paid + NEW.amount_minor < 0 THEN
    RAISE EXCEPTION 'That reversal is larger than what has been paid.' USING ERRCODE = 'check_violation';
  END IF;
  IF paid + NEW.amount_minor > inv.total_minor - credited THEN
    RAISE EXCEPTION 'That payment is more than the amount owed.' USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.amount_minor > 0 THEN
    NEW.receipt_issued_on := coalesce(NEW.receipt_issued_on, CURRENT_DATE);
    NEW.receipt_number := next_document_number('RCT', EXTRACT(year FROM NEW.receipt_issued_on)::int);
  END IF;
  RETURN NEW;
END $$;

-- ── New tables ───────────────────────────────────────────────────────────────
CREATE TABLE follow_up (
  follow_up_id      uuid PRIMARY KEY,
  invoice_id        uuid NOT NULL REFERENCES invoice (invoice_id),
  by_user_id        uuid NOT NULL,
  at                timestamptz NOT NULL DEFAULT now(),
  channel           text NOT NULL CHECK (channel IN ('call', 'email', 'meeting', 'other')),
  outcome           text NOT NULL CHECK (char_length(btrim(outcome)) BETWEEN 1 AND 200),
  note              text CHECK (note IS NULL OR char_length(note) <= 1000),
  next_follow_up_on date
);
CREATE INDEX follow_up_invoice ON follow_up (invoice_id, at);
CREATE INDEX follow_up_due     ON follow_up (next_follow_up_on) WHERE next_follow_up_on IS NOT NULL;
CREATE TRIGGER follow_up_append_only BEFORE UPDATE OR DELETE ON follow_up FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE invoice_share_link (
  link_id            uuid PRIMARY KEY,
  invoice_id         uuid NOT NULL REFERENCES invoice (invoice_id),
  token_hash         text NOT NULL UNIQUE,                                     -- a keyed hash: the token itself is never stored
  expires_at         timestamptz NOT NULL,
  revoked_at         timestamptz,
  revoked_by_user_id uuid,
  created_by_user_id uuid NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  last_viewed_at     timestamptz,
  view_count         int NOT NULL DEFAULT 0 CHECK (view_count >= 0)
);
CREATE INDEX invoice_share_link_invoice ON invoice_share_link (invoice_id);

CREATE TABLE invoice_owner_history (
  history_id         bigserial PRIMARY KEY,
  invoice_id         uuid NOT NULL REFERENCES invoice (invoice_id),
  from_user_id       uuid,
  to_user_id         uuid NOT NULL,
  changed_by_user_id uuid NOT NULL,
  changed_at         timestamptz NOT NULL DEFAULT now(),
  reason             text NOT NULL CHECK (char_length(btrim(reason)) BETWEEN 1 AND 500)
);
CREATE INDEX invoice_owner_history_invoice ON invoice_owner_history (invoice_id, changed_at);
CREATE TRIGGER invoice_owner_history_append_only BEFORE UPDATE OR DELETE ON invoice_owner_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Who did what, when and why, for everything the status history does not already say: draft edits, links, payments, follow-ups, owner changes.
CREATE TABLE invoice_event (
  event_id      bigserial PRIMARY KEY,
  invoice_id    uuid NOT NULL REFERENCES invoice (invoice_id),
  at            timestamptz NOT NULL DEFAULT now(),
  actor_user_id uuid NOT NULL,
  actor_role    text NOT NULL CHECK (actor_role IN ('user', 'admin')),
  action        text NOT NULL,
  reason        text CHECK (reason IS NULL OR char_length(reason) <= 500),
  detail        jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX invoice_event_invoice ON invoice_event (invoice_id, at);
CREATE TRIGGER invoice_event_append_only BEFORE UPDATE OR DELETE ON invoice_event FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE idempotency_key (
  scope         text NOT NULL,
  key           text NOT NULL CHECK (char_length(key) BETWEEN 8 AND 100),
  actor_user_id uuid NOT NULL,
  request_hash  text NOT NULL,
  status        int NOT NULL,
  response      jsonb NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (scope, key, actor_user_id)
);

-- What each role may do is DATA: a new rule is an INSERT, not a deploy. The service reads this on every call.
CREATE TABLE action_role (
  action    text NOT NULL,
  role_code text NOT NULL CHECK (role_code IN ('user', 'admin')),
  PRIMARY KEY (action, role_code)
);
INSERT INTO action_role (action, role_code) VALUES
  ('invoice.read', 'user'), ('invoice.read', 'admin'),
  ('invoice.draft', 'user'), ('invoice.draft', 'admin'),
  ('invoice.cancel_draft', 'user'), ('invoice.cancel_draft', 'admin'),
  ('invoice.issue', 'user'), ('invoice.issue', 'admin'),
  ('invoice.mark_sent', 'user'), ('invoice.mark_sent', 'admin'),
  ('link.manage', 'user'), ('link.manage', 'admin'),
  ('payment.record', 'user'), ('payment.record', 'admin'),
  ('followup.log', 'user'), ('followup.log', 'admin'),
  ('invoice.void', 'admin'), ('payment.void', 'admin'), ('credit_note.create', 'admin'), ('owner.change', 'admin'), ('report.read', 'admin');

COMMIT;
