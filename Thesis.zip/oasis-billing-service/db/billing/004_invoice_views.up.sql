-- Billing database, migration 004: one place that knows an invoice's money and whether it is overdue.
-- "Overdue" is computed from the due date and the balance, so every screen and report is right even if the nightly job has never run.
-- Business dates use the database's time zone; run billing_db in the business's own (ALTER DATABASE billing_db SET timezone TO 'Asia/Kolkata').
BEGIN;

CREATE VIEW v_invoice_state AS
SELECT t.*,
       CASE WHEN t.is_open AND t.due_on IS NOT NULL THEN
         CASE WHEN t.due_on >= CURRENT_DATE THEN 'current' WHEN CURRENT_DATE - t.due_on <= 30 THEN '1-30' WHEN CURRENT_DATE - t.due_on <= 60 THEN '31-60' ELSE '61+' END
       END AS aging_bucket,
       CASE WHEN t.is_overdue AND t.follow_up_count = 0 THEN 'missing'
            WHEN t.is_open AND t.next_follow_up_on < CURRENT_DATE THEN 'lapsed' END AS follow_up_health
  FROM (
    SELECT s.*,
           (s.status_code IN ('ISSUED', 'SENT', 'OVERDUE') AND s.balance_minor > 0) AS is_open,
           (s.status_code IN ('ISSUED', 'SENT', 'OVERDUE') AND s.due_on < CURRENT_DATE AND s.balance_minor > 0) AS is_overdue,
           CASE WHEN s.status_code IN ('ISSUED', 'SENT', 'OVERDUE') AND s.due_on < CURRENT_DATE AND s.balance_minor > 0 THEN 'OVERDUE' ELSE s.status_code END AS effective_status
      FROM (
        SELECT i.*, b.name AS bill_to_name, m.paid_minor, m.credited_minor, m.last_follow_up_at, m.next_follow_up_on, m.follow_up_count,
               i.total_minor - m.credited_minor - m.paid_minor AS balance_minor
          FROM invoice i
          LEFT JOIN invoice_bill_to b ON b.invoice_id = i.invoice_id
          CROSS JOIN LATERAL (SELECT
            COALESCE((SELECT sum(p.amount_minor) FROM payment p WHERE p.invoice_id = i.invoice_id), 0) AS paid_minor,
            COALESCE((SELECT sum(c.amount_minor) FROM credit_note c WHERE c.invoice_id = i.invoice_id), 0) AS credited_minor,
            (SELECT max(f.at) FROM follow_up f WHERE f.invoice_id = i.invoice_id) AS last_follow_up_at,
            (SELECT f.next_follow_up_on FROM follow_up f WHERE f.invoice_id = i.invoice_id ORDER BY f.at DESC, f.follow_up_id DESC LIMIT 1) AS next_follow_up_on,
            (SELECT count(*) FROM follow_up f WHERE f.invoice_id = i.invoice_id) AS follow_up_count) m
      ) s
  ) t;

COMMIT;
