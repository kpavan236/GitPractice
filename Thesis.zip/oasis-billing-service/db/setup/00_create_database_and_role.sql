-- OASIS billing service: database, application role.
--
-- Run ONCE, as a PostgreSQL administrator, connected to the maintenance database:
--   psql "postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432/postgres" -v ON_ERROR_STOP=1 -f db/setup/00_create_database_and_role.sql
-- Then apply the schema with: BILLING_DATABASE_URL=... npm run migrate   (as the administrator, so the application role needs no CREATE)
--
-- SECURITY: the password below is a PLACEHOLDER. Replace it (ALTER ROLE ... PASSWORD) with a value from your secret manager and never commit the real one.
-- The application role gets data access only: no CREATE, no DROP, not a superuser. The billing service is the only thing that writes this database.

\set ON_ERROR_STOP on

SELECT 'CREATE ROLE oasis_billing_app LOGIN PASSWORD ''CHANGE_ME_use_a_secret_manager'' NOSUPERUSER NOCREATEDB NOCREATEROLE'
 WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'oasis_billing_app')
\gexec

SELECT 'CREATE DATABASE billing_db ENCODING ''UTF8'''
 WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'billing_db')
\gexec

REVOKE ALL ON DATABASE billing_db FROM PUBLIC;
GRANT CONNECT ON DATABASE billing_db TO oasis_billing_app;

\connect billing_db
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO oasis_billing_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO oasis_billing_app;
-- btree_gist (PostgreSQL contrib, a "trusted" extension since version 13) backs the "no overlapping periods" constraints.
CREATE EXTENSION IF NOT EXISTS btree_gist;
