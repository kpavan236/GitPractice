# oasis-billing-service

The i-Ready OASIS billing service: invoices, receipts and payment follow-up. It is the only thing that writes `billing_db`. The support portal calls its staff API (service key plus the acting staff member and role). Customers open a read-only link page on this service directly. That share-link page is the only unauthenticated surface; everything under `/v1/staff` needs the service key. (`/healthz` and `/readyz` are bare liveness and readiness checks that return no business data.)

This service sends no email and has no one-time codes. Production cannot start yet: only the fake notifier exists, and the config refuses `NODE_ENV=production` (the same as the other services) until an email sender is approved (see `docs/fakes.md`).

## Run it locally

```bash
docker run -d --name oasis-pg -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16     # local development only
psql "postgres://postgres:local-dev-only@localhost:5433/postgres" -v ON_ERROR_STOP=1 -f db/setup/00_create_database_and_role.sql
cp .env.example .env          # then fill in BILLING_DATABASE_URL, BILLING_SERVICE_KEY, BILLING_HASH_PEPPER (32+ random characters each)
npm install
npm run migrate               # applies db/billing/*.sql once each, checksummed
npm run start:local
```

The whole local stack (all services) is started by `oasis-support-portal/scripts/stack.sh`.

## Settings (names only; values live in the untracked `.env` or a secret store)

| Name | Default | Meaning |
|---|---|---|
| `PORT` | `4060` | Port |
| `BILLING_DATABASE_URL` | required | The billing database |
| `BILLING_SERVICE_KEY` | required, 32+ chars | The portal sends it with every staff call |
| `BILLING_HASH_PEPPER` | required, 32+ chars | Keys share-link tokens into one-way hashes. If it is lost every issued link stops working |
| `BILLING_CURRENCY` | `INR` | The one currency |
| `SHARE_LINK_DEFAULT_DAYS` | `14` | Life of a new link, 1 to 365 |
| `PUBLIC_BASE_URL` | `http://127.0.0.1:<PORT>` | Where customers open links (https in production, required there) |
| `TLS_CERT_FILE`, `TLS_KEY_FILE` | none | TLS served by this service: both or neither. Production refuses to start without them unless `ALLOW_PLAIN_HTTP=1` |
| `ALLOW_PLAIN_HTTP` | none | `1` only where the platform ends TLS before traffic reaches the service |
| `SHUTDOWN_TIMEOUT_MS` | `10000` | In-flight requests get this long on SIGTERM |
| `NOTIFIER` | `fake` | The only accepted value |

There is no reverse proxy, nginx or tunnel anywhere, and no `TRUST_PROXY` setting: the rate limiter keys on the socket address.

## Staff API (`/v1/staff`, every call carries `X-Service-Key`, `X-Acting-User`, `X-Acting-Role`)

| Route | Action (role data in `action_role`) |
|---|---|
| `POST /invoices` (accepts `Idempotency-Key`) | `invoice.draft` |
| `GET /invoices`, `GET /invoices/:id` | `invoice.read` |
| `PATCH /invoices/:id`, `POST /invoices/:id/cancel` | `invoice.draft`, `invoice.cancel_draft` |
| `POST /invoices/:id/issue`, `/mark-sent` | `invoice.issue`, `invoice.mark_sent` |
| `POST /invoices/:id/void` | `invoice.void` (admin) |
| `POST /invoices/:id/payments` (accepts `Idempotency-Key`) | `payment.record` |
| `POST /invoices/:id/payments/:paymentId/void` | `payment.void` (admin) |
| `POST /invoices/:id/credit-notes` | `credit_note.create` (admin) |
| `POST /invoices/:id/owner` | `owner.change` (admin) |
| `POST /invoices/:id/follow-ups`, `GET /follow-ups/queue`, `GET /follow-ups/summary` | `followup.log`, `invoice.read` |
| `POST /invoices/:id/links`, `POST /invoices/:id/links/:linkId/revoke` | `link.manage` |
| `GET /reports/dashboard`, `GET /reports/export` | `report.read` (admin) |
| `GET /whoami`, `GET /can/:action` | any valid caller |

Public: `GET /i/<token>` (read-only, no login, no cookies, rate-limited) and `GET /i-static/invoice.css`. `GET /healthz`, `GET /readyz`.

Refusals are 4xx with `{ error, message, reason, requestId }`. A fault on our side is a 500 that says nothing about the cause.

## Roles are data

Who may do what is the `action_role` table, read on every call. To let users void an invoice: `INSERT INTO action_role (action, role_code) VALUES ('invoice.void', 'user');`. The service enforces this itself; the portal hiding a button is not the protection.

## Money and numbers

Integer minor units. Totals are computed by the database from the lines. A discount is a negative line; tax is an ordinary line. Numbers `INV-YYYY-nnnnnn`, `CN-YYYY-nnnnnn`, `RCT-YYYY-nnnnnn` are allocated inside the issuing transaction: unique and gap-free per series. Payments and their reversals are append-only; "voiding" a payment adds a negative row that points at it.

Business dates use the database's time zone. Set it to the business's: `ALTER DATABASE billing_db SET timezone TO 'Asia/Kolkata';`.

## The nightly overdue job

`npm run mark-overdue` moves unpaid ISSUED and SENT invoices past their due date to OVERDUE and prints `{"marked": n}`. It is documented here and NOT scheduled by this repository. The screens and reports compute "overdue" at read time, so nothing depends on it running.

## Security notes

- Share-link tokens are 256 random bits, shown once, stored only as a keyed hash, with expiry and revocation. Expired, revoked, wrong and malformed links give one identical page.
- The customer page sends a strict content policy (no scripts), `no-store`, `noindex`, and no cookies.
- Logs hold method, path (`/i/:token` for links), status, time and request id. Never a body, query string, name, amount, token or key.
- Invoices, balances and customer names are CA confidential financial data and personal data. Use synthetic data in tests, fixtures and docs.
- Code in this repository was written with AI assistance. It goes through the standard code review, CI/CD and SAST/DAST gates like any other code, and customer-facing wording needs CA employee review before real customers see it.
- No data retention period is set and nothing is scheduled.

## Operator notes

- Voiding a payment is admin-only; cancelling a draft is open to any user. Both are rows in `action_role`.
- Voiding a payment adds a reversing row; the original payment shows as voided.
- The rate limiter is per process and per address. It is a first line, not a substitute for a gateway.
- Business dates (due, overdue) use the database time zone.
- Customer-facing wording needs CA employee review before real customers see it.
- No retention period is set and nothing is scheduled for it.

## Tests

`npm test` runs against a real PostgreSQL (default `postgres://postgres:local-dev-only@localhost:5433/postgres`, override with `TEST_PG_ADMIN_URL`). Each test file makes a throwaway database and drops it afterwards.
