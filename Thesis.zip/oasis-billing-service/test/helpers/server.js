'use strict';
const { createApp } = require('../../src/app');
const { createTestDatabase } = require('./db');
const { createFakeNotifier } = require('../../src/notifier');
const { rateLimit } = require('../../src/rate-limit');
const { STAFF_A } = require('./fixtures');

const KEY = 'test-service-key-test-service-key-0123';
const PEPPER = 'test-pepper-test-pepper-test-pepper-0123';

/** A running billing API on a free port, on a throwaway database. `logs` collects every log line so tests can check what was (not) logged. */
async function startService(options = {}) {
  const dbs = options.dbs || await createTestDatabase();
  const logs = [];
  const notifier = createFakeNotifier();
  const app = createApp({
    db: dbs.db, serviceKey: KEY, hashPepper: PEPPER, currency: options.currency || 'INR', shareLinkDefaultDays: options.shareLinkDefaultDays || 14,
    publicBaseUrl: 'http://billing.example.test', notifier, limiter: rateLimit({ max: 100_000 }), publicLimiter: options.publicLimiter || rateLimit({ max: 100_000 }),
    log: line => logs.push(line), ...(options.app || {}),
  });
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const asUser = (userId = STAFF_A) => ({ userId, role: 'user' });
  const asAdmin = (userId = STAFF_A) => ({ userId, role: 'admin' });
  const call = async (method, route, body, { actor = asUser(), headers = {}, key = KEY } = {}) => {
    const h = { 'content-type': 'application/json', ...headers };
    if (key) h['X-Service-Key'] = key;
    if (actor) { h['X-Acting-User'] = actor.userId; h['X-Acting-Role'] = actor.role; }
    const res = await fetch(`${base}${route}`, { method, headers: h, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    const text = await res.text();
    let json = {}; try { json = JSON.parse(text); } catch (_) { /* not JSON: a page or an empty answer */ }
    return { status: res.status, headers: res.headers, body: json, text };
  };
  return {
    ...dbs, app, base, logs, notifier, KEY, PEPPER, asUser, asAdmin, call,
    get: (route, o) => call('GET', route, undefined, o), post: (route, body, o) => call('POST', route, body, o),
    patch: (route, body, o) => call('PATCH', route, body, o), put: (route, body, o) => call('PUT', route, body, o),
    async close() { await new Promise(r => server.close(r)); if (!options.dbs) await dbs.drop(); },
  };
}

module.exports = { startService, KEY, PEPPER };
