'use strict';
const { uuidv7 } = require('../../src/uuid');

const STAFF_A = '00000000-0000-7000-8000-00000000000a';
const STAFF_B = '00000000-0000-7000-8000-00000000000b';
const ADMIN_1 = '00000000-0000-7000-8000-0000000000ad';
const CUSTOMER_1 = '00000000-0000-7000-8000-0000000000c1';
const CUSTOMER_2 = '00000000-0000-7000-8000-0000000000c2';

/** A draft invoice straight into the database (synthetic data), for the schema tests only. Returns the invoice id. */
async function newDraft(db, o = {}) {
  const id = uuidv7();
  await db.query(
    `INSERT INTO invoice (invoice_id, customer_id, currency_code, owner_user_id, created_by_user_id, due_on, subtotal_minor, total_minor)
     VALUES ($1, $2, 'INR', $3, $3, $4, $5, $5)`, [id, o.customerId || CUSTOMER_1, o.ownerId || STAFF_A, o.dueOn || null, o.totalMinor || 0]);
  return id;
}
async function addBillTo(db, invoiceId) {
  await db.query(`INSERT INTO invoice_bill_to (invoice_id, name, line1, city, country_code) VALUES ($1, 'Example School District', '1 Example Road', 'Pune', 'IN')`, [invoiceId]);
}
async function addLine(db, invoiceId, { description = 'Licence, 25 seats', quantity = 1, unitPriceMinor = 10000, lineNo = 1 } = {}) {
  await db.query(
    `INSERT INTO invoice_line (line_id, invoice_id, line_no, description, quantity, unit_price_minor, amount_minor) VALUES ($1, $2, $3, $4, $5, $6, round($5::numeric * $6::bigint))`,
    [uuidv7(), invoiceId, lineNo, description, quantity, unitPriceMinor]);
}

const inDays = n => new Date(Date.now() + n * 86_400_000).toISOString().slice(0, 10);

/** A valid create-invoice request body (synthetic). Override any top-level field. */
const validInvoice = (o = {}) => ({
  customerId: CUSTOMER_1,
  billTo: { name: 'Example School District', line1: '1 Example Road', city: 'Pune', countryCode: 'IN' },
  lines: [{ description: 'i-Ready licence, 25 seats', quantity: 25, unitPriceMinor: 40000 }],
  dueOn: inDays(30),
  ...o,
});

/** Moves an issued invoice's dates into the past, for the overdue tests. Triggers are off for this one statement: an issued invoice is immutable in real life. */
async function backdate(db, invoiceId, { issuedDaysAgo, dueDaysAgo }) {
  const c = await db.connect();
  try {
    await c.query(`SET session_replication_role = replica`);
    await c.query('UPDATE invoice SET issued_on = CURRENT_DATE - $2::int, due_on = CURRENT_DATE - $3::int WHERE invoice_id = $1', [invoiceId, issuedDaysAgo, dueDaysAgo]);
  } finally { await c.query(`SET session_replication_role = DEFAULT`); c.release(); }
}

/** A calendar day as the DATABASE sees it, offset from today. The tests must agree with the database about "today", not with the test machine's clock. */
async function dbDate(db, offsetDays = 0) {
  return (await db.query(`SELECT (CURRENT_DATE + $1::int)::text AS d`, [offsetDays])).rows[0].d;
}

module.exports = { ADMIN_1, dbDate, STAFF_A, STAFF_B, CUSTOMER_1, CUSTOMER_2, newDraft, addBillTo, addLine, validInvoice, inDays, backdate };
