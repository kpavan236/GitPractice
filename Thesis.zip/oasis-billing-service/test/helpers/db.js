'use strict';
require('../../src/pg-types');
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { migrate } = require('../../src/migrate');

// Tests run against REAL PostgreSQL, because the rules that matter (gap-free numbers, append-only history, status moves, the payment limit) live in the database.
// Each call makes one throwaway database on the server named by TEST_PG_ADMIN_URL and drops it afterwards.
const ADMIN_URL = process.env.TEST_PG_ADMIN_URL || 'postgres://postgres:local-dev-only@localhost:5433/postgres';
const urlFor = name => { const u = new URL(ADMIN_URL); u.pathname = `/${name}`; return u.toString(); };

async function createTestDatabase() {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try { await admin.query('SELECT 1'); }
  catch (err) { await admin.end().catch(() => {}); throw new Error(`Cannot reach PostgreSQL for the tests (${err.message}). Start one, or set TEST_PG_ADMIN_URL.`); }
  const name = `t_${crypto.randomBytes(4).toString('hex')}_billing`;
  await admin.query(`CREATE DATABASE ${name}`);
  await migrate(urlFor(name), path.join(__dirname, '..', '..', 'db', 'billing'));
  const db = new Pool({ connectionString: urlFor(name), max: 10 });
  db.on('error', () => {});
  return {
    db, url: urlFor(name),
    async drop() { await db.end(); await admin.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`); await admin.end(); },
  };
}

module.exports = { createTestDatabase };
