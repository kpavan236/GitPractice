'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { startService } = require('./helpers/server');
const { validInvoice } = require('./helpers/fixtures');
const { rateLimit } = require('../src/rate-limit');

const ROOT = path.join(__dirname, '..');
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
const sources = walk(path.join(ROOT, 'src')).filter(f => f.endsWith('.js'));

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

test('a request body over 32 KB is a 413, and a non-JSON body is a 400, never a 500', async () => {
  const big = await svc.post('/v1/staff/invoices', JSON.stringify({ notes: 'x'.repeat(40_000) }));
  assert.equal(big.status, 413); assert.equal(big.body.reason, 'too_large');
  const res = await fetch(`${svc.base}/v1/staff/invoices`, { method: 'POST', headers: { 'content-type': 'text/plain', 'X-Service-Key': svc.KEY, 'X-Acting-User': '00000000-0000-7000-8000-00000000000a', 'X-Acting-Role': 'user' }, body: 'hello' });
  assert.equal(res.status, 400);
});

test('an unknown staff route without the key is a 401 (the key is asked first), with the key a 404', async () => {
  assert.equal((await svc.get('/v1/staff/nope', { key: null })).status, 401);
  assert.equal((await svc.get('/v1/staff/nope')).status, 404);
  assert.equal((await svc.call('DELETE', '/v1/staff/invoices/00000000-0000-7000-8000-00000000dead')).status, 404);
});

test('the staff API is rate-limited per address', async () => {
  const s = await startService({ app: { limiter: rateLimit({ max: 3 }) } });
  try {
    const codes = []; for (let i = 0; i < 5; i++) codes.push((await s.get('/v1/staff/whoami')).status);
    assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  } finally { await s.close(); }
});

test('one full flow leaves logs with only the allowed fields and nothing sensitive', async () => {
  const s = await startService();
  try {
    const id = (await s.post('/v1/staff/invoices', validInvoice({ billTo: { name: 'Zebra Secret Academy', line1: '9 Hidden Lane', city: 'Pune', countryCode: 'IN' }, notes: 'INTERNAL-NOTE' }))).body.invoice.invoiceId;
    await s.post(`/v1/staff/invoices/${id}/issue`, {});
    await s.post(`/v1/staff/invoices/${id}/payments`, { amountMinor: 987654, method: 'po', reference: 'PO-SECRET-77' });
    const link = (await s.post(`/v1/staff/invoices/${id}/links`, {})).body.link;
    await fetch(link.url.replace('http://billing.example.test', s.base));
    await s.get('/v1/staff/reports/dashboard', { actor: s.asAdmin() });
    const allowed = new Set(['level', 'requestId', 'method', 'path', 'status', 'ms', 'msg', 'code', 'error']);
    for (const line of s.logs) for (const k of Object.keys(line)) assert.ok(allowed.has(k), `unexpected log field ${k}`);
    const all = JSON.stringify(s.logs);
    for (const secret of ['Zebra', 'Hidden Lane', 'INTERNAL-NOTE', 'PO-SECRET-77', '987654', link.url.split('/i/')[1], s.KEY, s.PEPPER]) assert.ok(!all.includes(secret), secret);
  } finally { await s.close(); }
});

test('the process refuses to start without its settings, with one plain line and no stack', () => {
  const r = spawnSync(process.execPath, ['src/server.js'], { cwd: ROOT, env: { PATH: process.env.PATH }, encoding: 'utf8' });
  assert.equal(r.status, 1);
  assert.match(r.stderr, /BILLING_DATABASE_URL is required/);
  assert.ok(!/\n\s+at /.test(r.stderr), 'no stack trace');
});

test('no reverse proxy, tunnel, trust-proxy setting or email library appears in the code, and SMTP names are never read', () => {
  const banned = [/http-proxy/i, /nginx/i, /caddy/i, /traefik/i, /haproxy/i, /ngrok/i, /trust proxy/i, /TRUST_PROXY/, /nodemailer/i, /createTransport/, /process\.env\.SMTP_/, /env\.SMTP_/];
  for (const f of sources) {
    const text = fs.readFileSync(f, 'utf8');
    for (const re of banned) assert.ok(!re.test(text), `${path.relative(ROOT, f)} matches ${re}`);
  }
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  assert.deepEqual(Object.keys(pkg.dependencies).sort(), ['express', 'pg']);
});

test('.env.example holds names and safe defaults only: every secret is empty', () => {
  const lines = fs.readFileSync(path.join(ROOT, '.env.example'), 'utf8').split('\n').filter(l => /^[A-Z_]+=/.test(l));
  const value = name => (lines.find(l => l.startsWith(`${name}=`)) || '').slice(name.length + 1);
  for (const name of ['BILLING_SERVICE_KEY', 'BILLING_HASH_PEPPER']) assert.equal(value(name), '', name);
  assert.match(value('BILLING_DATABASE_URL'), /USER:PASSWORD@HOST/);
  assert.equal(value('NOTIFIER'), 'fake');
});
