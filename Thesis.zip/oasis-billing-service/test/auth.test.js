'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { STAFF_A } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

test('a staff call without the service key, or with a wrong one of the same length, is a 401', async () => {
  const none = await svc.get('/v1/staff/whoami', { key: null });
  assert.equal(none.status, 401); assert.equal(none.body.reason, 'service_key_required');
  const wrong = await svc.get('/v1/staff/whoami', { key: 'x'.repeat(svc.KEY.length) });
  assert.equal(wrong.status, 401);
  const short = await svc.get('/v1/staff/whoami', { key: 'x' });
  assert.equal(short.status, 401);
});

test('the key is checked before anything else: a bad actor with a bad key is still a 401', async () => {
  const r = await svc.call('GET', '/v1/staff/whoami', undefined, { key: null, actor: { userId: 'nonsense', role: 'root' } });
  assert.equal(r.status, 401);
});

test('the acting user must be a uuid and the role user or admin; the role is never taken from the body', async () => {
  const badId = await svc.get('/v1/staff/whoami', { actor: { userId: 'not-a-uuid', role: 'user' } });
  assert.equal(badId.status, 400); assert.equal(badId.body.reason, 'bad_actor');
  const badRole = await svc.get('/v1/staff/whoami', { actor: { userId: STAFF_A, role: 'root' } });
  assert.equal(badRole.status, 400);
  const missing = await svc.get('/v1/staff/whoami', { actor: null });
  assert.equal(missing.status, 400);
  const ok = await svc.get('/v1/staff/whoami', { actor: svc.asAdmin() });
  assert.deepEqual(ok.body, { userId: STAFF_A, role: 'admin' });
});

test('the role matrix is read from the database on every call', async () => {
  const a = await svc.get('/v1/staff/can/invoice.void', { actor: svc.asUser() });
  assert.equal(a.status, 403); assert.equal(a.body.reason, 'forbidden');
  assert.equal((await svc.get('/v1/staff/can/invoice.void', { actor: svc.asAdmin() })).status, 200);
  assert.equal((await svc.get('/v1/staff/can/invoice.issue', { actor: svc.asUser() })).status, 200);
  // data, not code: grant it and the very next call allows it
  await svc.db.query(`INSERT INTO action_role (action, role_code) VALUES ('invoice.void', 'user')`);
  assert.equal((await svc.get('/v1/staff/can/invoice.void', { actor: svc.asUser() })).status, 200);
  await svc.db.query(`DELETE FROM action_role WHERE action = 'invoice.void' AND role_code = 'user'`);
  assert.equal((await svc.get('/v1/staff/can/invoice.void', { actor: svc.asUser() })).status, 403);
});

test('an action nobody holds is refused, not allowed by default', async () => {
  assert.equal((await svc.get('/v1/staff/can/no.such.action', { actor: svc.asAdmin() })).status, 403);
});

test('the key and the acting user never reach a log line', async () => {
  await svc.get('/v1/staff/whoami');
  const all = JSON.stringify(svc.logs);
  assert.ok(!all.includes(svc.KEY)); assert.ok(!all.includes(STAFF_A));
});
