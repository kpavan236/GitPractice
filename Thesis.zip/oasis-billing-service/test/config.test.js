'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');

const GOOD = {
  BILLING_DATABASE_URL: 'postgres://u:p@localhost:5433/billing_db',
  BILLING_SERVICE_KEY: 'k'.repeat(40),
  BILLING_HASH_PEPPER: 'p'.repeat(40),
};

test('defaults: port 4060, INR, 14-day links, fake notifier, no TLS in development', () => {
  const c = loadConfig({ ...GOOD });
  assert.equal(c.port, 4060);
  assert.equal(c.currency, 'INR');
  assert.equal(c.shareLinkDefaultDays, 14);
  assert.equal(c.notifier, 'fake');
  assert.equal(c.tls, false);
  assert.equal(c.publicBaseUrl, 'http://127.0.0.1:4060');
});

test('each secret is required and at least 32 characters', () => {
  for (const name of ['BILLING_DATABASE_URL', 'BILLING_SERVICE_KEY', 'BILLING_HASH_PEPPER']) {
    const env = { ...GOOD }; delete env[name];
    assert.throws(() => loadConfig(env), new RegExp(`${name} is required`));
  }
  assert.throws(() => loadConfig({ ...GOOD, BILLING_SERVICE_KEY: 'short' }), /BILLING_SERVICE_KEY must be at least 32/);
  assert.throws(() => loadConfig({ ...GOOD, BILLING_HASH_PEPPER: 'short' }), /BILLING_HASH_PEPPER must be at least 32/);
});

test('the notifier must be "fake": no email provider is approved', () => {
  assert.throws(() => loadConfig({ ...GOOD, NOTIFIER: 'smtp' }), /NOTIFIER must be "fake"/);
});

test('currency is a three-letter code; share-link days are 1 to 365', () => {
  assert.equal(loadConfig({ ...GOOD, BILLING_CURRENCY: 'usd' }).currency, 'USD');
  assert.throws(() => loadConfig({ ...GOOD, BILLING_CURRENCY: 'RUPEE' }), /BILLING_CURRENCY/);
  assert.throws(() => loadConfig({ ...GOOD, SHARE_LINK_DEFAULT_DAYS: '0' }), /SHARE_LINK_DEFAULT_DAYS/);
  assert.throws(() => loadConfig({ ...GOOD, SHARE_LINK_DEFAULT_DAYS: '366' }), /SHARE_LINK_DEFAULT_DAYS/);
});

test('TLS: both files or neither; production refuses plain http unless ALLOW_PLAIN_HTTP=1', () => {
  assert.throws(() => loadConfig({ ...GOOD, TLS_CERT_FILE: '/x.pem' }), /set together/);
  assert.throws(() => loadConfig({ ...GOOD, NODE_ENV: 'production', PUBLIC_BASE_URL: 'https://pay.example.test' }), /TLS_CERT_FILE and TLS_KEY_FILE/);
  // With ALLOW_PLAIN_HTTP=1 the TLS check passes, and the next production check (the email sender) is the one that stops it.
  assert.throws(() => loadConfig({ ...GOOD, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', PUBLIC_BASE_URL: 'https://pay.example.test' }), /approved email sender/);
  assert.throws(() => loadConfig({ ...GOOD, ALLOW_PLAIN_HTTP: 'yes' }), /ALLOW_PLAIN_HTTP/);
});

test('PUBLIC_BASE_URL is a plain web address, https in production, required in production', () => {
  assert.throws(() => loadConfig({ ...GOOD, PUBLIC_BASE_URL: 'ftp://x.test' }), /PUBLIC_BASE_URL/);
  assert.throws(() => loadConfig({ ...GOOD, PUBLIC_BASE_URL: 'https://x.test/?a=1' }), /PUBLIC_BASE_URL/);
  assert.throws(() => loadConfig({ ...GOOD, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1' }), /PUBLIC_BASE_URL is required/);
  assert.throws(() => loadConfig({ ...GOOD, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', PUBLIC_BASE_URL: 'http://x.test' }), /https in production/);
});

test('production refuses the fake notifier, as the other services do', () => {
  assert.throws(() => loadConfig({ ...GOOD, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', PUBLIC_BASE_URL: 'https://x.test' }), /approved email sender/);
});
