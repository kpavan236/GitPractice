'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, backdate, STAFF_A, STAFF_B } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const url = (id, tail = '') => `/v1/staff/invoices/${id}${tail}`;
/** An issued, sent invoice of 10,000 minor units. */
async function issued(s = svc, total = 10000) {
  const id = (await s.post('/v1/staff/invoices', validInvoice({ lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: total }] }))).body.invoice.invoiceId;
  await s.post(url(id, '/issue'), {});
  await s.post(url(id, '/mark-sent'), { channel: 'email' });
  return id;
}
const pay = (id, amountMinor, o = {}, opts) => svc.post(url(id, '/payments'), { amountMinor, method: 'bank_transfer', reference: 'SYNTH-REF-1', ...o }, opts);
const state = async id => (await svc.get(url(id))).body;

test('a partial payment keeps the invoice open and gets a receipt; the final one marks it PAID and closes the deal', async () => {
  const id = await issued();
  const a = await pay(id, 4000);
  assert.equal(a.status, 201);
  assert.match(a.body.payment.receiptNumber, /^RCT-\d{4}-\d{6}$/);
  assert.equal(a.body.invoice.status, 'SENT'); assert.equal(a.body.invoice.paidMinor, 4000); assert.equal(a.body.invoice.balanceMinor, 6000); assert.equal(a.body.invoice.closedAt, null);
  const b = await pay(id, 6000, { method: 'po' });
  assert.equal(b.body.invoice.status, 'PAID'); assert.equal(b.body.invoice.balanceMinor, 0); assert.ok(b.body.invoice.closedAt);
  assert.notEqual(a.body.payment.receiptNumber, b.body.payment.receiptNumber);
  const s = await state(id);
  assert.equal(s.payments.length, 2);
  assert.deepEqual(s.statusHistory.map(h => h.to).slice(-1), ['PAID']);
});

test('refusals: more than the balance (with the balance), zero, negative, fractional, text, unknown method, future date, not payable', async () => {
  const id = await issued();
  const over = await pay(id, 10001);
  assert.equal(over.status, 409); assert.equal(over.body.reason, 'payment_exceeds_balance'); assert.equal(over.body.balanceMinor, 10000);
  for (const [amount, reason] of [[0, 'bad_amount'], [-5, 'bad_amount'], [10.5, 'bad_amount'], ['100', 'bad_amount'], [1e15, 'bad_amount']]) assert.equal((await pay(id, amount)).body.reason, reason, String(amount));
  assert.equal((await pay(id, 100, { method: 'bitcoin' })).body.reason, 'bad_method');
  assert.equal((await pay(id, 100, { receivedOn: '2999-01-01' })).body.reason, 'received_in_future');
  const aDraft = (await svc.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;
  assert.equal((await pay(aDraft, 100)).body.reason, 'invoice_not_payable');
  assert.equal((await pay('not-an-id', 100)).status, 404);
  assert.equal((await state(id)).payments.length, 0);
});

test('a paid invoice takes no more payments', async () => {
  const id = await issued(); await pay(id, 10000);
  const r = await pay(id, 1);
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'already_paid');
});

test('two people record the last 10,000 at the same moment: exactly one succeeds, the invoice is never overpaid', async () => {
  const id = await issued();
  const all = await Promise.all(Array.from({ length: 8 }, (_, i) => pay(id, 10000, { reference: `R${i}` })));
  assert.deepEqual(all.map(r => r.status).sort(), [201, 409, 409, 409, 409, 409, 409, 409]);
  const s = await state(id);
  assert.equal(s.invoice.paidMinor, 10000); assert.equal(s.payments.length, 1); assert.equal(s.invoice.status, 'PAID');
});

test('two payments of 6,000 at once on 10,000: one wins, the other is told the balance', async () => {
  const id = await issued();
  const [a, b] = await Promise.all([pay(id, 6000), pay(id, 6000)]);
  assert.deepEqual([a.status, b.status].sort(), [201, 409]);
  const loser = a.status === 409 ? a : b;
  assert.equal(loser.body.balanceMinor, 4000);
});

test('double submit with one Idempotency-Key records one payment and returns the same receipt; another amount with that key is refused', async () => {
  const id = await issued();
  const h = { headers: { 'Idempotency-Key': 'pay-key-0001' } };
  const a = await pay(id, 2500, {}, h), b = await pay(id, 2500, {}, h);
  assert.equal(a.status, 201); assert.equal(b.status, 201);
  assert.equal(b.body.payment.paymentId, a.body.payment.paymentId); assert.equal(b.headers.get('idempotent-replayed'), 'true');
  assert.equal((await state(id)).payments.length, 1);
  const other = await pay(id, 2600, {}, h);
  assert.equal(other.status, 422); assert.equal(other.body.reason, 'idempotency_key_reused');
  const par = await Promise.all(Array.from({ length: 6 }, () => pay(id, 100, {}, { headers: { 'Idempotency-Key': 'pay-key-race-1' } })));
  assert.ok(par.every(r => r.status === 201)); assert.equal(new Set(par.map(r => r.body.payment.paymentId)).size, 1);
  assert.equal((await state(id)).payments.length, 2);
});

test('receipt numbers across many invoices recorded at once are unique and have no gaps', async () => {
  const s = await startService();
  try {
    const ids = []; for (let i = 0; i < 6; i++) ids.push(await issued(s));
    const all = await Promise.all(ids.map(id => s.post(url(id, '/payments'), { amountMinor: 1000, method: 'cheque' })));
    const n = all.map(r => Number(r.body.payment.receiptNumber.slice(-6))).sort((a, b) => a - b);
    assert.deepEqual(n, [1, 2, 3, 4, 5, 6]);
  } finally { await s.close(); }
});

test('voiding a payment: a user is refused; an admin needs a reason; the invoice reopens; the first closed_at is kept', async () => {
  const id = await issued();
  const p = (await pay(id, 10000)).body;
  const closedAt = p.invoice.closedAt;
  const vurl = url(id, `/payments/${p.payment.paymentId}/void`);
  assert.equal((await svc.post(vurl, { reason: 'Cheque bounced' }, { actor: svc.asUser() })).status, 403);
  assert.equal((await svc.post(vurl, {}, { actor: svc.asAdmin() })).body.reason, 'reason_required');
  const v = await svc.post(vurl, { reason: 'Cheque bounced' }, { actor: svc.asAdmin(STAFF_B) });
  assert.equal(v.status, 200); assert.equal(v.body.invoice.status, 'SENT'); assert.equal(v.body.invoice.paidMinor, 0); assert.equal(v.body.invoice.balanceMinor, 10000);
  assert.equal(v.body.invoice.closedAt, closedAt);
  const s = await state(id);
  assert.equal(s.payments.find(x => x.paymentId === p.payment.paymentId).isVoided, true);
  assert.equal(s.payments.find(x => x.reversesPaymentId === p.payment.paymentId).voidReason, 'Cheque bounced');
  assert.equal((await svc.post(vurl, { reason: 'again' }, { actor: svc.asAdmin() })).body.reason, 'already_voided');
  const again = await pay(id, 10000);                                  // paying again closes it again, with the same first closed_at
  assert.equal(again.body.invoice.status, 'PAID'); assert.equal(again.body.invoice.closedAt, closedAt);
});

test('voiding a payment on a PAID invoice already past its due date reopens it as OVERDUE, not SENT', async () => {
  const id = await issued();
  const p = (await pay(id, 10000)).body;
  await backdate(svc.db, id, { issuedDaysAgo: 40, dueDaysAgo: 5 });
  const v = await svc.post(url(id, `/payments/${p.payment.paymentId}/void`), { reason: 'Reversed by the bank' }, { actor: svc.asAdmin() });
  assert.equal(v.body.invoice.status, 'OVERDUE');
});

test('voiding a payment that belongs to another invoice, or does not exist, is a 404', async () => {
  const a = await issued(), b = await issued();
  const p = (await pay(a, 1000)).body.payment.paymentId;
  assert.equal((await svc.post(url(b, `/payments/${p}/void`), { reason: 'x' }, { actor: svc.asAdmin() })).status, 404);
  assert.equal((await svc.post(url(a, '/payments/00000000-0000-7000-8000-00000000dead/void'), { reason: 'x' }, { actor: svc.asAdmin() })).status, 404);
  assert.equal((await svc.post(url(a, '/payments/nope/void'), { reason: 'x' }, { actor: svc.asAdmin() })).status, 404);
});

test('an invoice with payments cannot be voided; an admin voids the payments first', async () => {
  const id = await issued();
  await pay(id, 1000);
  const r = await svc.post(url(id, '/void'), { reason: 'Wrong district' }, { actor: svc.asAdmin() });
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'has_payments');
});

test('credit notes: admin only; a partial credit gets a CN number and lowers the balance; crediting the rest of the balance marks it PAID; crediting everything unpaid says use void', async () => {
  const id = await issued();
  const cnUrl = url(id, '/credit-notes');
  assert.equal((await svc.post(cnUrl, { amountMinor: 1000, reason: 'Fewer seats' }, { actor: svc.asUser() })).status, 403);
  assert.equal((await svc.post(cnUrl, { amountMinor: 1000 }, { actor: svc.asAdmin() })).body.reason, 'reason_required');
  assert.equal((await svc.post(cnUrl, { amountMinor: 10000, reason: 'Whole thing' }, { actor: svc.asAdmin() })).body.reason, 'use_void');
  const a = await svc.post(cnUrl, { amountMinor: 1000, reason: 'Fewer seats' }, { actor: svc.asAdmin() });
  assert.equal(a.status, 201); assert.match(a.body.creditNote.creditNoteNumber, /^CN-\d{4}-\d{6}$/);
  assert.equal(a.body.invoice.balanceMinor, 9000); assert.equal(a.body.invoice.creditedMinor, 1000);
  await pay(id, 6000);
  const b = await svc.post(cnUrl, { amountMinor: 3000, reason: 'Goodwill' }, { actor: svc.asAdmin() });
  assert.equal(b.body.invoice.status, 'PAID'); assert.equal(b.body.invoice.balanceMinor, 0);
  assert.equal((await svc.post(cnUrl, { amountMinor: 1, reason: 'Too late' }, { actor: svc.asAdmin() })).status, 409);
});

test('nothing a person typed or the amounts reach a log line', async () => {
  const id = await issued(svc, 1_000_000);
  svc.logs.length = 0;
  await pay(id, 765432, { reference: 'PO-SECRET-REF-91' });
  const all = JSON.stringify(svc.logs);
  for (const secret of ['PO-SECRET-REF-91', '765432']) assert.ok(!all.includes(secret), secret);
});

test('every payment, void and credit is in the invoice activity with who and why', async () => {
  const id = await issued();
  const p = (await pay(id, 500, {}, { actor: svc.asUser(STAFF_B) })).body.payment;
  await svc.post(url(id, `/payments/${p.paymentId}/void`), { reason: 'Entered twice' }, { actor: svc.asAdmin(STAFF_A) });
  const a = (await state(id)).activity;
  const rec = a.find(x => x.action === 'payment.record'), vd = a.find(x => x.action === 'payment.void');
  assert.equal(rec.actorUserId, STAFF_B); assert.equal(rec.actorRole, 'user');
  assert.equal(vd.actorUserId, STAFF_A); assert.equal(vd.actorRole, 'admin'); assert.equal(vd.reason, 'Entered twice');
});
