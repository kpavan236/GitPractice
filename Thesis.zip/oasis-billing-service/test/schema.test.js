'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createTestDatabase } = require('./helpers/db');
const { newDraft, addBillTo, addLine, STAFF_A, STAFF_B, CUSTOMER_1 } = require('./helpers/fixtures');
const { uuidv7 } = require('../src/uuid');

let t, db;
test.before(async () => { t = await createTestDatabase(); db = t.db; });
test.after(async () => { await t.drop(); });

/** Runs `sql` in one transaction with the reason and actor the application always sets. */
async function asApp(fn) {
  const c = await db.connect();
  try {
    await c.query('BEGIN');
    await c.query(`SELECT set_config('app.reason', 'test', true), set_config('app.actor_id', $1, true)`, [STAFF_A]);
    const out = await fn(c);
    await c.query('COMMIT');
    return out;
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}
const issue = (c, id, dueOn = '2030-02-15') => c.query(`UPDATE invoice SET status_code = 'ISSUED', issued_on = '2030-01-15', due_on = $2 WHERE invoice_id = $1`, [id, dueOn]);

test('a one-off invoice needs no subscription or period, and is refused without a customer', async () => {
  const id = await newDraft(db);
  const { rows: [r] } = await db.query('SELECT subscription_id, period_start FROM invoice WHERE invoice_id = $1', [id]);
  assert.equal(r.subscription_id, null); assert.equal(r.period_start, null);
  await assert.rejects(db.query(`INSERT INTO invoice (invoice_id, currency_code, owner_user_id) VALUES ($1, 'INR', $2)`, [uuidv7(), STAFF_A]), /invoice_customer_required/);
});

test('issuing a one-off invoice allocates a gap-free number and needs a due date', async () => {
  const a = await newDraft(db), b = await newDraft(db);
  for (const id of [a, b]) { await addBillTo(db, id); await addLine(db, id); await db.query('UPDATE invoice SET subtotal_minor = 10000, total_minor = 10000 WHERE invoice_id = $1', [id]); }
  await assert.rejects(asApp(c => c.query(`UPDATE invoice SET status_code = 'ISSUED', issued_on = '2030-01-15' WHERE invoice_id = $1`, [a])), /due date/);
  await asApp(c => issue(c, a)); await asApp(c => issue(c, b));
  const { rows } = await db.query('SELECT invoice_number FROM invoice WHERE invoice_id IN ($1, $2) ORDER BY invoice_number', [a, b]);
  assert.deepEqual(rows.map(r => r.invoice_number), ['INV-2030-000001', 'INV-2030-000002']);
});

test('discount lines are negative; the frozen totals must match the lines; a zero or negative total cannot be issued', async () => {
  const id = await newDraft(db);
  await addBillTo(db, id);
  await addLine(db, id, { quantity: 1, unitPriceMinor: 10000 });
  await addLine(db, id, { description: 'Early-payment discount', quantity: 1, unitPriceMinor: -1000, lineNo: 2 });
  await db.query('UPDATE invoice SET subtotal_minor = 10000, discount_minor = 1000, total_minor = 9000 WHERE invoice_id = $1', [id]);
  await asApp(c => issue(c, id));
  const { rows: [r] } = await db.query('SELECT total_minor, status_code FROM invoice WHERE invoice_id = $1', [id]);
  assert.equal(Number(r.total_minor), 9000); assert.equal(r.status_code, 'ISSUED');

  const wrong = await newDraft(db); await addBillTo(db, wrong); await addLine(db, wrong);
  await assert.rejects(asApp(c => issue(c, wrong)), /do not match/);          // lines say 10000, the invoice still says 0

  const zero = await newDraft(db); await addBillTo(db, zero); await addLine(db, zero, { unitPriceMinor: 0 });
  await assert.rejects(asApp(c => issue(c, zero)), /total must be more than zero/);
});

test('receipts: a payment gets RCT-YYYY-nnnnnn, a reversal needs a reason and cannot be repeated; overpayment is refused', async () => {
  const id = await newDraft(db); await addBillTo(db, id); await addLine(db, id);
  await db.query('UPDATE invoice SET subtotal_minor = 10000, total_minor = 10000 WHERE invoice_id = $1', [id]);
  await asApp(c => issue(c, id));
  const pay = amount => asApp(c => c.query(
    `INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id) VALUES ($1, $2, $3, 'bank_transfer', CURRENT_DATE, $4) RETURNING payment_id, receipt_number`, [uuidv7(), id, amount, STAFF_A]));
  const first = (await pay(4000)).rows[0];
  assert.match(first.receipt_number, /^RCT-\d{4}-\d{6}$/);
  await assert.rejects(pay(6001), /more than the amount owed/);
  const rev = reason => asApp(c => c.query(
    `INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id, reverses_payment_id, void_reason) VALUES ($1, $2, -4000, 'other', CURRENT_DATE, $3, $4, $5)`,
    [uuidv7(), id, STAFF_A, first.payment_id, reason]));
  await assert.rejects(rev(null), /payment_receipt_or_reversal/);
  await rev('Cheque bounced');
  await assert.rejects(rev('Again'), /larger than what has been paid|unique/i);       // a payment can be reversed once
});

test('closed_at is set when an invoice first reaches PAID and survives a reopen', async () => {
  const id = await newDraft(db); await addBillTo(db, id); await addLine(db, id);
  await db.query('UPDATE invoice SET subtotal_minor = 10000, total_minor = 10000 WHERE invoice_id = $1', [id]);
  await asApp(c => issue(c, id));
  await asApp(c => c.query(`INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id) VALUES ($1, $2, 10000, 'po', CURRENT_DATE, $3)`, [uuidv7(), id, STAFF_A]));
  await asApp(c => c.query(`UPDATE invoice SET status_code = 'PAID' WHERE invoice_id = $1`, [id]));
  const { rows: [paid] } = await db.query('SELECT closed_at FROM invoice WHERE invoice_id = $1', [id]);
  assert.ok(paid.closed_at);
  await asApp(c => c.query(`UPDATE invoice SET status_code = 'SENT' WHERE invoice_id = $1`, [id]));      // PAID -> SENT is an allowed move
  const { rows: [again] } = await db.query('SELECT closed_at FROM invoice WHERE invoice_id = $1', [id]);
  assert.equal(String(again.closed_at), String(paid.closed_at));
});

test('new tables exist and the history ones are append-only', async () => {
  const id = await newDraft(db);
  const f = uuidv7();
  await db.query(`INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome) VALUES ($1, $2, $3, 'call', 'No answer')`, [f, id, STAFF_A]);
  await assert.rejects(db.query(`UPDATE follow_up SET outcome = 'x' WHERE follow_up_id = $1`, [f]), /append-only/);
  await db.query(`INSERT INTO invoice_owner_history (invoice_id, from_user_id, to_user_id, changed_by_user_id, reason) VALUES ($1, $2, $3, $2, 'Handover')`, [id, STAFF_A, STAFF_B]);
  await assert.rejects(db.query('DELETE FROM invoice_owner_history'), /append-only/);
  await db.query(`INSERT INTO invoice_event (invoice_id, actor_user_id, actor_role, action) VALUES ($1, $2, 'user', 'test')`, [id, STAFF_A]);
  await assert.rejects(db.query('DELETE FROM invoice_event'), /append-only/);
  await assert.rejects(db.query(`INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome) VALUES ($1, $2, $3, 'carrier-pigeon', 'x')`, [uuidv7(), id, STAFF_A]), /check/);
});

test('the one-invoice-per-period rule applies only to subscription invoices', async () => {
  const sub = uuidv7();
  await db.query(`INSERT INTO subscription (subscription_id, customer_id, interval_code, currency_code, starts_on) VALUES ($1, $2, 'monthly', 'INR', '2030-01-01')`, [sub, CUSTOMER_1]);
  const ins = () => db.query(`INSERT INTO invoice (invoice_id, subscription_id, customer_id, currency_code, owner_user_id, period_start, period_end) VALUES ($1, $2, $3, 'INR', $4, '2030-01-01', '2030-01-31')`, [uuidv7(), sub, CUSTOMER_1, STAFF_A]);
  await ins();
  await assert.rejects(ins(), /invoice_one_per_period/);
  await newDraft(db); await newDraft(db);                // two one-offs for the same customer are fine
});

test('the role table says who may do what, as data', async () => {
  const { rows } = await db.query(`SELECT action, role_code FROM action_role ORDER BY action, role_code`);
  const has = (a, r) => rows.some(x => x.action === a && x.role_code === r);
  assert.ok(has('invoice.issue', 'user') && has('invoice.issue', 'admin'));
  for (const a of ['invoice.void', 'payment.void', 'credit_note.create', 'owner.change', 'report.read']) { assert.ok(has(a, 'admin'), a); assert.ok(!has(a, 'user'), a); }
});

test('the idempotency table keeps the first answer per actor, scope and key', async () => {
  await db.query(`INSERT INTO idempotency_key (scope, key, actor_user_id, request_hash, status, response) VALUES ('invoice.create', 'key-00001', $1, 'h', 201, '{}')`, [STAFF_A]);
  await assert.rejects(db.query(`INSERT INTO idempotency_key (scope, key, actor_user_id, request_hash, status, response) VALUES ('invoice.create', 'key-00001', $1, 'h', 201, '{}')`, [STAFF_A]), /duplicate|unique/i);
});
