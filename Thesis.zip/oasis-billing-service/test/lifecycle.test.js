'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, inDays, backdate, STAFF_A, STAFF_B } = require('./helpers/fixtures');
const { markOverdue } = require('../src/overdue');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });
const draft = async (o, opts) => (await svc.post('/v1/staff/invoices', validInvoice(o), opts)).body.invoice.invoiceId;
const url = (id, tail = '') => `/v1/staff/invoices/${id}${tail}`;
const year = new Date().getFullYear();

test('issuing gives the next INV number, today as the issue date, and a status-history row with who and why', async () => {
  const id = await draft();
  const r = await svc.post(url(id, '/issue'), {});
  assert.equal(r.status, 200);
  assert.match(r.body.invoice.invoiceNumber, new RegExp(`^INV-${year}-\\d{6}$`));
  assert.equal(r.body.invoice.status, 'ISSUED');
  const h = await svc.db.query(`SELECT to_status_code, reason, changed_by_user_id FROM invoice_status_history WHERE invoice_id = $1 ORDER BY changed_at`, [id]);
  assert.deepEqual(h.rows.map(x => [x.to_status_code, x.reason]), [['DRAFT', 'Invoice created'], ['ISSUED', 'Issued']]);
  assert.equal(h.rows[1].changed_by_user_id, STAFF_A);
  const e = await svc.db.query(`SELECT action FROM invoice_event WHERE invoice_id = $1 ORDER BY event_id`, [id]);
  assert.deepEqual(e.rows.map(x => x.action), ['invoice.create', 'invoice.issue']);
});

test('issue needs a due date (given now or already on the draft) that is not before today, and a total above zero', async () => {
  const none = await draft({ dueOn: undefined });
  const r = await svc.post(url(none, '/issue'), {});
  assert.equal(r.status, 400); assert.equal(r.body.reason, 'due_date_required');
  assert.equal((await svc.post(url(none, '/issue'), { dueOn: '2001-01-01' })).body.reason, 'due_before_issue');
  assert.equal((await svc.post(url(none, '/issue'), { dueOn: 'tomorrow' })).body.reason, 'bad_date');
  const ok = await svc.post(url(none, '/issue'), { dueOn: inDays(10) });
  assert.equal(ok.body.invoice.dueOn, inDays(10));
  const zero = await draft({ lines: [{ description: 'Free pilot', quantity: 1, unitPriceMinor: 0 }] });
  assert.equal((await svc.post(url(zero, '/issue'), {})).body.reason, 'total_not_positive');
});

test('an issued invoice cannot be edited, cancelled as a draft, or issued again', async () => {
  const id = await draft();
  await svc.post(url(id, '/issue'), {});
  assert.equal((await svc.patch(url(id), { notes: 'x' })).body.reason, 'not_a_draft');
  assert.equal((await svc.post(url(id, '/cancel'), { reason: 'x' })).body.reason, 'not_a_draft');
  const again = await svc.post(url(id, '/issue'), {});
  assert.equal(again.status, 409); assert.equal(again.body.reason, 'not_a_draft');
});

test('two people issuing the same draft at once: one succeeds, the rest get 409, and one number is used', async () => {
  const id = await draft();
  const before = Number((await svc.db.query(`SELECT count(*) FROM invoice WHERE invoice_number IS NOT NULL`)).rows[0].count);
  const all = await Promise.all(Array.from({ length: 6 }, () => svc.post(url(id, '/issue'), {})));
  assert.deepEqual(all.map(r => r.status).sort(), [200, 409, 409, 409, 409, 409]);
  assert.equal(Number((await svc.db.query(`SELECT count(*) FROM invoice WHERE invoice_number IS NOT NULL`)).rows[0].count), before + 1);
});

test('twelve different drafts issued at the same moment get twelve different, consecutive numbers (no gaps)', async () => {
  const s = await startService();           // a fresh database so the numbers start at 1
  try {
    const ids = [];
    for (let i = 0; i < 12; i++) ids.push((await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId);
    const all = await Promise.all(ids.map(id => s.post(url(id, '/issue'), {})));
    assert.ok(all.every(r => r.status === 200));
    const n = all.map(r => Number(r.body.invoice.invoiceNumber.slice(-6))).sort((a, b) => a - b);
    assert.deepEqual(n, Array.from({ length: 12 }, (_, i) => i + 1));
  } finally { await s.close(); }
});

test('a refused issue uses up no number: the next successful issue still gets 000001', async () => {
  const s = await startService();
  try {
    const good = (await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;
    const noDue = (await s.post('/v1/staff/invoices', validInvoice({ dueOn: undefined }))).body.invoice.invoiceId;
    assert.equal((await s.post(url(noDue, '/issue'), {})).status, 400);
    const r = await s.post(url(good, '/issue'), {});
    assert.match(r.body.invoice.invoiceNumber, /-000001$/);
  } finally { await s.close(); }
});

test('mark sent: ISSUED becomes SENT; doing it again keeps SENT and is recorded; a draft cannot be marked sent', async () => {
  const id = await draft();
  assert.equal((await svc.post(url(id, '/mark-sent'), { channel: 'email' })).body.reason, 'bad_status');
  await svc.post(url(id, '/issue'), {});
  const r = await svc.post(url(id, '/mark-sent'), { channel: 'email', note: 'Sent the link to the finance office' });
  assert.equal(r.status, 200); assert.equal(r.body.invoice.status, 'SENT');
  const again = await svc.post(url(id, '/mark-sent'), { channel: 'call' });
  assert.equal(again.status, 200); assert.equal(again.body.invoice.status, 'SENT');
  assert.equal((await svc.post(url(id, '/mark-sent'), { channel: 'carrier-pigeon' })).body.reason, 'bad_channel');
  const e = await svc.db.query(`SELECT detail FROM invoice_event WHERE invoice_id = $1 AND action = 'invoice.mark_sent' ORDER BY event_id`, [id]);
  assert.deepEqual(e.rows.map(x => x.detail.channel), ['email', 'call']);
});

test('void: a user is refused by the service itself; an admin needs a reason; the invoice keeps its number', async () => {
  const id = await draft();
  await svc.post(url(id, '/issue'), {});
  const denied = await svc.post(url(id, '/void'), { reason: 'x' }, { actor: svc.asUser() });
  assert.equal(denied.status, 403);
  assert.equal((await svc.post(url(id, '/void'), {}, { actor: svc.asAdmin() })).body.reason, 'reason_required');
  const r = await svc.post(url(id, '/void'), { reason: 'Raised to the wrong district' }, { actor: svc.asAdmin(STAFF_B) });
  assert.equal(r.status, 200); assert.equal(r.body.invoice.status, 'VOID'); assert.ok(r.body.invoice.invoiceNumber);
  assert.equal((await svc.post(url(id, '/void'), { reason: 'again' }, { actor: svc.asAdmin() })).body.reason, 'bad_status');
  const h = await svc.db.query(`SELECT reason, changed_by_user_id FROM invoice_status_history WHERE invoice_id = $1 AND to_status_code = 'VOID'`, [id]);
  assert.deepEqual(h.rows, [{ reason: 'Raised to the wrong district', changed_by_user_id: STAFF_B }]);
  assert.equal((await svc.post(url(await draft(), '/void'), { reason: 'x' }, { actor: svc.asAdmin() })).body.reason, 'bad_status');      // a draft is cancelled, not voided
});

test('overdue is computed at read time: the screens are right even if the nightly job never ran', async () => {
  const id = await draft();
  await svc.post(url(id, '/issue'), {});
  await svc.post(url(id, '/mark-sent'), { channel: 'email' });
  const fresh = await svc.get(url(id));
  assert.equal(fresh.body.invoice.isOverdue, false);
  await backdate(svc.db, id, { issuedDaysAgo: 40, dueDaysAgo: 10 });
  const r = await svc.get(url(id));
  assert.equal(r.body.invoice.status, 'SENT');                          // stored status has not moved
  assert.equal(r.body.invoice.isOverdue, true); assert.equal(r.body.invoice.effectiveStatus, 'OVERDUE');
  const list = ids => ids.body.invoices.map(i => i.invoiceId);
  assert.ok(list(await svc.get('/v1/staff/invoices?overdue=1')).includes(id));
  assert.ok(list(await svc.get('/v1/staff/invoices?status=OVERDUE')).includes(id));
  assert.ok(!list(await svc.get('/v1/staff/invoices?status=SENT')).includes(id));
  assert.ok(!list(await svc.get('/v1/staff/invoices?overdue=0')).includes(id));
});

test('the nightly job moves unpaid ISSUED and SENT invoices past due to OVERDUE, once, and leaves everything else alone', async () => {
  const s = await startService();
  try {
    const mk = async () => { const id = (await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId; await s.post(url(id, '/issue'), {}); return id; };
    const lateIssued = await mk(), lateSent = await mk(), notYet = await mk(), aDraft = (await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;
    await s.post(url(lateSent, '/mark-sent'), { channel: 'email' });
    await backdate(s.db, lateIssued, { issuedDaysAgo: 30, dueDaysAgo: 2 });
    await backdate(s.db, lateSent, { issuedDaysAgo: 30, dueDaysAgo: 1 });
    assert.equal(await markOverdue(s.db), 2);
    assert.equal(await markOverdue(s.db), 0);
    const status = async id => (await s.get(url(id))).body.invoice.status;
    assert.equal(await status(lateIssued), 'OVERDUE'); assert.equal(await status(lateSent), 'OVERDUE');
    assert.equal(await status(notYet), 'ISSUED'); assert.equal(await status(aDraft), 'DRAFT');
    const h = await s.db.query(`SELECT reason, changed_by_user_id FROM invoice_status_history WHERE invoice_id = $1 AND to_status_code = 'OVERDUE'`, [lateIssued]);
    assert.deepEqual(h.rows, [{ reason: 'Past its due date (nightly job)', changed_by_user_id: null }]);
    assert.equal((await s.get('/v1/staff/invoices?overdue=1')).body.total, 2);         // still listed once each, with or without the job
  } finally { await s.close(); }
});

test('void is refused with has_payments (409) once a payment is recorded', async () => {
  const id = await draft();
  await svc.post(url(id, '/issue'), {});
  await svc.db.query(`INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id) VALUES (gen_random_uuid(), $1, 100, 'bank_transfer', CURRENT_DATE, $2)`, [id, STAFF_A]);
  const r = await svc.post(url(id, '/void'), { reason: 'x' }, { actor: svc.asAdmin() });
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'has_payments');
});

test('the nightly job leaves PAID and VOID invoices alone, even past due, and does not abort', async () => {
  const s = await startService();
  try {
    const mk = async () => { const id = (await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId; await s.post(url(id, '/issue'), {}); return id; };
    const paid = await mk(), voided = await mk(), late = await mk();
    const total = (await s.db.query('SELECT total_minor FROM invoice WHERE invoice_id = $1', [paid])).rows[0].total_minor;
    await s.db.query(`INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id) VALUES (gen_random_uuid(), $1, $2::bigint, 'bank_transfer', CURRENT_DATE, $3)`, [paid, total, STAFF_A]);
    await s.db.query(`WITH r AS (SELECT set_config('app.reason', 'Paid in full', true)) UPDATE invoice SET status_code = 'PAID' FROM r WHERE invoice_id = $1`, [paid]);      // the payments service (a later task) does this; here we do it directly
    assert.equal((await s.post(url(voided, '/void'), { reason: 'Raised in error' }, { actor: s.asAdmin() })).status, 200);
    for (const id of [paid, voided, late]) await backdate(s.db, id, { issuedDaysAgo: 30, dueDaysAgo: 3 });
    const before = (await s.get(url(paid))).body.invoice.status;
    assert.equal(before, 'PAID');
    assert.equal(await markOverdue(s.db), 1);
    assert.equal((await s.get(url(paid))).body.invoice.status, 'PAID');
    assert.equal((await s.get(url(voided))).body.invoice.status, 'VOID');
    assert.equal((await s.get(url(late))).body.invoice.status, 'OVERDUE');
  } finally { await s.close(); }
});

test('a void or cancelled invoice owes nothing: balanceMinor is 0 in the single view and the list', async () => {
  const id = await draft();
  await svc.post(url(id, '/issue'), {});
  assert.equal((await svc.get(url(id))).body.invoice.balanceMinor > 0, true);
  assert.equal((await svc.post(url(id, '/void'), { reason: 'Raised in error' }, { actor: svc.asAdmin() })).status, 200);
  const cancelled = await draft();
  assert.equal((await svc.post(url(cancelled, '/cancel'), { reason: 'Not needed' })).status, 200);
  for (const want of [id, cancelled]) {
    assert.equal((await svc.get(url(want))).body.invoice.balanceMinor, 0);
    const list = (await svc.get('/v1/staff/invoices?pageSize=200')).body.invoices;
    const row = list.find(i => i.invoiceId === want);
    if (row) assert.equal(row.balanceMinor, 0);
  }
  assert.ok((await svc.get('/v1/staff/invoices?pageSize=200')).body.invoices.some(i => i.invoiceId === id), 'the voided invoice is in the list, so the list assertion ran');
});
