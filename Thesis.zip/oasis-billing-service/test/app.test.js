'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/app');

const base = { serviceKey: 'k'.repeat(40), hashPepper: 'p'.repeat(40), currency: 'INR', shareLinkDefaultDays: 14, publicBaseUrl: 'http://127.0.0.1:4060' };
const okDb = { query: async () => ({ rows: [{ '?column?': 1 }] }) };
const badDb = { query: async () => { throw new Error('connection refused to 10.0.0.5'); } };

async function run(options, fn) {
  const logs = [];
  const app = createApp({ db: okDb, ...base, log: l => logs.push(l), ...options });
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try { await fn(`http://127.0.0.1:${server.address().port}`, logs); } finally { await new Promise(r => server.close(r)); }
}

test('/healthz and /readyz answer without a key; /readyz says 503 when the database is down', async () => {
  await run({}, async url => {
    assert.equal((await fetch(`${url}/healthz`)).status, 200);
    assert.equal((await fetch(`${url}/readyz`)).status, 200);
  });
  await run({ db: badDb }, async url => {
    const r = await fetch(`${url}/readyz`);
    assert.equal(r.status, 503);
    assert.deepEqual(await r.json(), { ok: false });
  });
});

test('protective headers on every answer, and no X-Powered-By', async () => {
  await run({ hsts: true }, async url => {
    const r = await fetch(`${url}/healthz`);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(r.headers.get('cache-control'), 'no-store');
    assert.equal(r.headers.get('referrer-policy'), 'no-referrer');
    assert.match(r.headers.get('strict-transport-security'), /max-age=31536000/);
    assert.ok(!r.headers.get('x-powered-by'));
  });
});

test('an unknown route is a 404 JSON answer with a request id', async () => {
  await run({}, async url => {
    const r = await fetch(`${url}/nope`);
    assert.equal(r.status, 404);
    const body = await r.json();
    assert.equal(body.error, 'not_found');
    assert.ok(body.requestId);
  });
});

test('request logs hold method, path, status, time and request id: never a body or a query string', async () => {
  await run({}, async (url, logs) => {
    await fetch(`${url}/healthz?secret=abc123`, { headers: { 'X-Request-Id': 'abcdefgh1234' } });
    const line = logs.find(l => l.path === '/healthz');
    assert.deepEqual(Object.keys(line).sort(), ['level', 'method', 'ms', 'path', 'requestId', 'status']);
    assert.equal(line.requestId, 'abcdefgh1234');
    assert.ok(!JSON.stringify(logs).includes('abc123'));
  });
});

test('a 500 says nothing about the cause and logs only the error code', async () => {
  const routes = app => app.get('/boom', () => { throw Object.assign(new Error('password=hunter2 host=10.0.0.5'), { code: 'XX000' }); });
  await run({ routes }, async (url, logs) => {
    const r = await fetch(`${url}/boom`);
    assert.equal(r.status, 500);
    assert.ok(!JSON.stringify(await r.json()).includes('hunter2'));
    assert.ok(!JSON.stringify(logs).includes('hunter2'));
    assert.ok(logs.some(l => l.level === 'error' && l.code === 'XX000'));
  });
});
