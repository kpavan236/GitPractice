'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createFakeNotifier } = require('../src/notifier');

test('the fake notifier records the call and sends nothing', async () => {
  const n = createFakeNotifier();
  await n.sendInvoiceLink({ to: 'finance@example.test', link: 'http://billing.example.test/i/abc', invoiceNumber: 'INV-2030-000001' });
  assert.equal(n.kind, 'fake'); assert.equal(n.sent.length, 1); assert.equal(n.last().invoiceNumber, 'INV-2030-000001');
});

test('the fake keeps at most 1000 calls', async () => {
  const n = createFakeNotifier();
  for (let i = 0; i < 1005; i++) await n.sendInvoiceLink({ to: 'a@example.test', link: 'l', invoiceNumber: `INV-${i}` });
  assert.equal(n.sent.length, 1000); assert.equal(n.sent[0].invoiceNumber, 'INV-5');
});
