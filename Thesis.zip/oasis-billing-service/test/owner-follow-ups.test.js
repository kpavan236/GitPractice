'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, backdate, dbDate, STAFF_A, STAFF_B, ADMIN_1 } = require('./helpers/fixtures');
const { uuidv7 } = require('../src/uuid');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });
const url = (id, tail = '') => `/v1/staff/invoices/${id}${tail}`;

/** An issued, sent invoice owned by `owner` (the creator). */
async function open(s, owner = STAFF_A, o = {}) {
  const id = (await s.post('/v1/staff/invoices', validInvoice(o), { actor: s.asUser(owner) })).body.invoice.invoiceId;
  await s.post(url(id, '/issue'), {}); await s.post(url(id, '/mark-sent'), { channel: 'email' });
  return id;
}

test('only an admin changes the owner, with a reason; each change keeps who, when and why', async () => {
  const id = await open(svc);
  const u = url(id, '/owner');
  assert.equal((await svc.post(u, { toUserId: STAFF_B, reason: 'Handover' }, { actor: svc.asUser() })).status, 403);
  assert.equal((await svc.post(u, { toUserId: STAFF_B }, { actor: svc.asAdmin(ADMIN_1) })).body.reason, 'reason_required');
  assert.equal((await svc.post(u, { toUserId: 'nobody', reason: 'r' }, { actor: svc.asAdmin(ADMIN_1) })).body.reason, 'bad_owner');
  assert.equal((await svc.post(u, { toUserId: STAFF_A, reason: 'r' }, { actor: svc.asAdmin(ADMIN_1) })).body.reason, 'same_owner');
  const r = await svc.post(u, { toUserId: STAFF_B, reason: 'Account moved to the south team' }, { actor: svc.asAdmin(ADMIN_1) });
  assert.equal(r.status, 200); assert.equal(r.body.invoice.ownerUserId, STAFF_B); assert.equal(r.body.invoice.createdByUserId, STAFF_A);
  const g = (await svc.get(url(id))).body;
  assert.equal(g.ownerHistory.length, 1);
  assert.deepEqual({ ...g.ownerHistory[0], at: undefined }, { fromUserId: STAFF_A, toUserId: STAFF_B, changedByUserId: ADMIN_1, at: undefined, reason: 'Account moved to the south team' });
  assert.equal((await svc.post(url('00000000-0000-7000-8000-00000000dead', '/owner'), { toUserId: STAFF_B, reason: 'r' }, { actor: svc.asAdmin() })).status, 404);
});

test('any staff member may log a follow-up on any open invoice, and it is kept with who and when', async () => {
  const id = await open(svc, STAFF_A);
  const tomorrow = await dbDate(svc.db, 1);
  const r = await svc.post(url(id, '/follow-ups'), { channel: 'call', outcome: 'Finance office asked for a PO number', note: 'Call back Thursday', nextFollowUpOn: tomorrow }, { actor: svc.asUser(STAFF_B) });
  assert.equal(r.status, 201); assert.equal(r.body.invoice.followUpCount, 1); assert.equal(r.body.invoice.nextFollowUpOn, tomorrow);
  const g = (await svc.get(url(id))).body;
  assert.equal(g.followUps[0].byUserId, STAFF_B); assert.equal(g.followUps[0].channel, 'call'); assert.ok(g.followUps[0].at);
  assert.ok(g.invoice.lastFollowUpAt);
  assert.equal(g.activity.find(a => a.action === 'followup.log').detail.channel, 'call');
});

test('follow-up refusals: bad channel, blank outcome, a date in the past, a draft, a paid invoice', async () => {
  const id = await open(svc);
  const u = url(id, '/follow-ups');
  assert.equal((await svc.post(u, { channel: 'carrier-pigeon', outcome: 'x' })).body.reason, 'bad_channel');
  assert.equal((await svc.post(u, { channel: 'call', outcome: '  ' })).body.reason, 'bad_outcome');
  assert.equal((await svc.post(u, { channel: 'call', outcome: 'x', nextFollowUpOn: await dbDate(svc.db, -1) })).body.reason, 'next_follow_up_in_past');
  assert.equal((await svc.post(u, { channel: 'call', outcome: 'x', nextFollowUpOn: 'soon' })).body.reason, 'bad_date');
  const aDraft = (await svc.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;
  assert.equal((await svc.post(url(aDraft, '/follow-ups'), { channel: 'call', outcome: 'x' })).body.reason, 'bad_status');
  await svc.post(url(id, '/payments'), { amountMinor: 1_000_000, method: 'po' });
  assert.equal((await svc.post(u, { channel: 'call', outcome: 'x' })).status, 409);
});

test('a follow-up cannot be edited or deleted afterwards', async () => {
  const id = await open(svc);
  await svc.post(url(id, '/follow-ups'), { channel: 'email', outcome: 'Reminder sent by the account manager' });
  await assert.rejects(svc.db.query(`UPDATE follow_up SET outcome = 'changed'`), /append-only/);
  await assert.rejects(svc.db.query(`DELETE FROM follow_up`), /append-only/);
});

test('the queue holds overdue invoices and those with a follow-up due today or lapsed, grouped by owner; paid ones and future dates are left out', async () => {
  const s = await startService();
  try {
    const overdue = await open(s, STAFF_A); await backdate(s.db, overdue, { issuedDaysAgo: 40, dueDaysAgo: 5 });
    const dueToday = await open(s, STAFF_B);
    await s.post(url(dueToday, '/follow-ups'), { channel: 'call', outcome: 'Promised to pay', nextFollowUpOn: await dbDate(s.db, 0) }, { actor: s.asUser(STAFF_B) });
    const lapsed = await open(s, STAFF_B);
    await s.db.query(`INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome, next_follow_up_on) VALUES ($1, $2, $3, 'call', 'Will pay soon', CURRENT_DATE - 3)`, [uuidv7(), lapsed, STAFF_B]);
    const later = await open(s, STAFF_A);
    await s.post(url(later, '/follow-ups'), { channel: 'call', outcome: 'Next week', nextFollowUpOn: await dbDate(s.db, 7) });
    const paid = await open(s, STAFF_A); await s.post(url(paid, '/payments'), { amountMinor: 1_000_000, method: 'po' });
    const aDraft = (await s.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;

    const q = (await s.get('/v1/staff/follow-ups/queue')).body;
    const flat = q.groups.flatMap(g => g.invoices.map(i => [g.ownerUserId, i.invoiceId, i.reason]));
    assert.deepEqual(flat.sort(), [[STAFF_A, overdue, 'overdue'], [STAFF_B, dueToday, 'due_today'], [STAFF_B, lapsed, 'lapsed']].sort());
    assert.ok(![later, paid, aDraft].some(id => flat.some(f => f[1] === id)));
    assert.equal(q.groups.length, 2);
    assert.deepEqual((await s.get(`/v1/staff/follow-ups/queue?ownerId=${STAFF_B}`)).body.groups.map(g => g.ownerUserId), [STAFF_B]);
    assert.deepEqual((await s.get(`/v1/staff/follow-ups/summary?ownerId=${STAFF_B}`)).body, { overdue: 0, followUpsDue: 2 });
    assert.deepEqual((await s.get('/v1/staff/follow-ups/summary')).body, { overdue: 1, followUpsDue: 2 });
    assert.equal((await s.get('/v1/staff/follow-ups/queue?ownerId=x')).status, 400);
  } finally { await s.close(); }
});

test('an overdue invoice that is also due for a follow-up today says both', async () => {
  const s = await startService();
  try {
    const id = await open(s); await backdate(s.db, id, { issuedDaysAgo: 40, dueDaysAgo: 5 });
    await s.post(url(id, '/follow-ups'), { channel: 'meeting', outcome: 'Met the principal', nextFollowUpOn: await dbDate(s.db, 0) });
    assert.equal((await s.get('/v1/staff/follow-ups/queue')).body.groups[0].invoices[0].reason, 'overdue_and_due');
  } finally { await s.close(); }
});
