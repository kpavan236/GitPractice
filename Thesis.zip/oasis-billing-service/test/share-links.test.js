'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, STAFF_A, STAFF_B, CUSTOMER_1 } = require('./helpers/fixtures');
const { rateLimit } = require('../src/rate-limit');
const { createTestDatabase } = require('./helpers/db');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });
const url = (id, tail = '') => `/v1/staff/invoices/${id}${tail}`;
const page = async path => { const r = await fetch(`${svc.base}${path}`); return { status: r.status, headers: r.headers, text: await r.text() }; };
const tokenOf = linkUrl => linkUrl.split('/i/')[1];

async function issued(o = {}, s = svc) {
  const id = (await s.post('/v1/staff/invoices', validInvoice(o))).body.invoice.invoiceId;
  await s.post(url(id, '/issue'), {});
  return id;
}

test('a link can be made for an issued invoice only', async () => {
  const aDraft = (await svc.post('/v1/staff/invoices', validInvoice())).body.invoice.invoiceId;
  const r = await svc.post(url(aDraft, '/links'), {});
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'bad_status');
  const id = await issued();
  await svc.post(url(id, '/void'), { reason: 'Mistake' }, { actor: svc.asAdmin() });
  assert.equal((await svc.post(url(id, '/links'), {})).status, 409);
  assert.equal((await svc.post(url('00000000-0000-7000-8000-00000000dead', '/links'), {})).status, 404);
});

test('the link carries a 256-bit token, expires in 14 days by default, and the token is shown once and stored only as a hash', async () => {
  const id = await issued();
  const r = await svc.post(url(id, '/links'), {}, { actor: svc.asUser(STAFF_B) });
  assert.equal(r.status, 201);
  assert.match(r.body.link.url, /^http:\/\/billing\.example\.test\/i\/[A-Za-z0-9_-]{43}$/);
  const token = tokenOf(r.body.link.url);
  const days = (new Date(r.body.link.expiresAt) - Date.now()) / 86_400_000;
  assert.ok(days > 13.99 && days <= 14.01, String(days));
  const rows = (await svc.db.query('SELECT * FROM invoice_share_link WHERE invoice_id = $1', [id])).rows;
  assert.equal(rows.length, 1);
  assert.ok(!JSON.stringify(rows).includes(token));
  assert.match(rows[0].token_hash, /^[0-9a-f]{64}$/);
  assert.equal(rows[0].created_by_user_id, STAFF_B);
  const g = await svc.get(url(id));                                                  // staff can see that a link exists, never its secret
  assert.ok(!g.text.includes(token)); assert.ok(!g.text.includes(rows[0].token_hash));
  assert.equal(g.body.shareLinks[0].state, 'active'); assert.equal(g.body.shareLinks[0].viewCount, 0);
  const ev = await svc.db.query(`SELECT detail FROM invoice_event WHERE invoice_id = $1 AND action = 'link.create'`, [id]);
  assert.ok(!JSON.stringify(ev.rows).includes(token));
});

test('a custom life of 1 to 365 days is accepted; anything else is a 400', async () => {
  const id = await issued();
  const r = await svc.post(url(id, '/links'), { days: 30 });
  assert.ok(Math.abs((new Date(r.body.link.expiresAt) - Date.now()) / 86_400_000 - 30) < 0.01);
  for (const days of [0, 366, -1, 1.5, '7', null]) assert.equal((await svc.post(url(id, '/links'), { days })).body.reason, 'bad_days', String(days));
});

test('the customer opens the link with no login: a read-only page with the invoice, no staff details, no internal ids, no cookies, no scripts', async () => {
  const id = await issued({ notes: 'INTERNAL-NOTE-XYZ', billTo: { name: 'Example Public School', line1: '1 Example Road', city: 'Pune', countryCode: 'IN' },
    lines: [{ description: 'i-Ready licence, 25 seats', quantity: 25, unitPriceMinor: 40000 }, { description: 'Early-payment discount', quantity: 1, unitPriceMinor: -50000 }] });
  const link = (await svc.post(url(id, '/links'), {})).body.link;
  const p = await page(`/i/${tokenOf(link.url)}`);
  assert.equal(p.status, 200); assert.match(p.headers.get('content-type'), /text\/html/);
  const number = (await svc.get(url(id))).body.invoice.invoiceNumber;
  for (const shown of [number, 'Example Public School', 'i-Ready licence, 25 seats', 'Early-payment discount', '₹400.00', '₹10,000.00', '₹9,500.00']) assert.ok(p.text.includes(shown), shown);
  for (const hidden of ['INTERNAL-NOTE-XYZ', STAFF_A, CUSTOMER_1, id, link.linkId]) assert.ok(!p.text.includes(hidden), hidden);
  assert.ok(!/<script/i.test(p.text)); assert.ok(!/<form/i.test(p.text)); assert.ok(!/<button/i.test(p.text), 'no pay button: there is no payment provider');
  assert.equal(p.headers.get('set-cookie'), null);
  assert.equal(p.headers.get('cache-control'), 'no-store');
  assert.match(p.headers.get('content-security-policy'), /default-src 'none'/); assert.ok(!/unsafe-inline|script-src/.test(p.headers.get('content-security-policy')));
  assert.match(p.headers.get('x-robots-tag'), /noindex/); assert.equal(p.headers.get('x-frame-options'), 'DENY'); assert.equal(p.headers.get('referrer-policy'), 'no-referrer');
  const css = await page('/i-static/invoice.css');
  assert.equal(css.status, 200); assert.match(css.headers.get('content-type'), /text\/css/); assert.match(css.text, /@media print/);
});

test('what a person typed is escaped on the page', async () => {
  const id = await issued({ billTo: { name: 'School <script>alert(1)</script> & Sons', line1: '"1" <b>Road</b>', city: 'Pune', countryCode: 'IN' } });
  const p = await page(`/i/${tokenOf((await svc.post(url(id, '/links'), {})).body.link.url)}`);
  assert.ok(p.text.includes('School &lt;script&gt;alert(1)&lt;/script&gt; &amp; Sons'));
  assert.ok(!p.text.includes('<script>alert')); assert.ok(!p.text.includes('<b>Road</b>'));
});

test('each view is counted; staff can see "opened"', async () => {
  const id = await issued();
  const t = tokenOf((await svc.post(url(id, '/links'), {})).body.link.url);
  for (let i = 0; i < 3; i++) await page(`/i/${t}`);
  const l = (await svc.get(url(id))).body.shareLinks[0];
  assert.equal(l.viewCount, 3); assert.ok(l.lastViewedAt);
});

test('expired, revoked, wrong and malformed tokens all give the same page, status and headers, and are not counted', async () => {
  const id = await issued();
  const live = (await svc.post(url(id, '/links'), {})).body.link;
  const expired = (await svc.post(url(id, '/links'), {})).body.link;
  const revoked = (await svc.post(url(id, '/links'), {})).body.link;
  await svc.db.query(`UPDATE invoice_share_link SET expires_at = now() - interval '1 minute' WHERE link_id = $1`, [expired.linkId]);
  assert.equal((await svc.post(url(id, `/links/${revoked.linkId}/revoke`), {})).status, 200);
  const rnd = 'A'.repeat(43);
  const cases = [tokenOf(expired.url), tokenOf(revoked.url), rnd, 'abc', 'x'.repeat(200), '%00', '%zz', '..%2f..', `${tokenOf(live.url)}/extra`, '', '   '];
  const results = [];
  const allHeaders = h => JSON.stringify([...h.entries()].filter(([k]) => !['x-request-id', 'date'].includes(k)).sort());
  for (const c of cases.concat(['/' + tokenOf(live.url)])) { const p = await page(`/i/${c}`); results.push([p.status, allHeaders(p.headers), p.text]); }
  const first = JSON.stringify(results[0]);
  assert.ok(results.every(r => JSON.stringify(r) === first), 'every invalid link looks the same');
  assert.equal(results[0][0], 404); assert.match(results[0][2], /no longer valid/i);
  const links = (await svc.get(url(id))).body.shareLinks;
  assert.equal(links.find(l => l.linkId === live.linkId).viewCount, 0, 'no invalid attempt counted against the live link');
  assert.equal(links.find(l => l.linkId === expired.linkId).viewCount, 0);
  assert.equal(links.find(l => l.linkId === revoked.linkId).viewCount, 0);
  assert.equal(links.find(l => l.linkId === revoked.linkId).state, 'revoked'); assert.equal(links.find(l => l.linkId === expired.linkId).state, 'expired');
  assert.equal((await page('/i')).status, 404);
  assert.equal((await fetch(`${svc.base}/i/${tokenOf(live.url)}`, { method: 'POST' })).status, 404);
});

test('revoking: a user may; twice is a 409; another invoice\'s link id is a 404; the customer is turned away at once', async () => {
  const a = await issued(), b = await issued();
  const l = (await svc.post(url(a, '/links'), {})).body.link;
  assert.equal((await svc.post(url(b, `/links/${l.linkId}/revoke`), {})).status, 404);
  assert.equal((await svc.post(url(a, `/links/${l.linkId}/revoke`), {}, { actor: svc.asUser(STAFF_B) })).status, 200);
  assert.equal((await svc.post(url(a, `/links/${l.linkId}/revoke`), {})).body.reason, 'already_revoked');
  assert.equal((await page(`/i/${tokenOf(l.url)}`)).status, 404);
  assert.equal((await svc.post(url(a, '/links/nope/revoke'), {})).status, 404);
});

test('a paid invoice\'s page shows its receipts, a balance of zero, and leaves out a voided payment', async () => {
  const id = await issued({ lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: 10000 }] });
  const first = (await svc.post(url(id, '/payments'), { amountMinor: 4000, method: 'bank_transfer', reference: 'SECRET-BANK-REF' })).body.payment;
  const second = (await svc.post(url(id, '/payments'), { amountMinor: 6000, method: 'po' })).body.payment;
  const t = tokenOf((await svc.post(url(id, '/links'), {})).body.link.url);
  let p = await page(`/i/${t}`);
  assert.ok(p.text.includes(first.receiptNumber) && p.text.includes(second.receiptNumber)); assert.ok(/Paid/i.test(p.text)); assert.ok(p.text.includes('₹0.00'));
  assert.ok(!p.text.includes('SECRET-BANK-REF'), 'a payment reference is not shown to the customer');
  await svc.post(url(id, `/payments/${first.paymentId}/void`), { reason: 'Reversed' }, { actor: svc.asAdmin() });
  p = await page(`/i/${t}`);
  assert.ok(!p.text.includes(first.receiptNumber)); assert.ok(p.text.includes(second.receiptNumber));
  assert.ok(p.text.includes('₹40.00'), 'the balance owed is back');
});

test('the public page is rate-limited per address', async () => {
  const s = await startService({ publicLimiter: rateLimit({ max: 3 }) });
  try {
    const codes = [];
    for (let i = 0; i < 5; i++) codes.push((await fetch(`${s.base}/i/${'B'.repeat(43)}`)).status);
    assert.deepEqual(codes, [404, 404, 404, 429, 429]);
  } finally { await s.close(); }
});

test('a link is never logged: the path is logged as /i/:token', async () => {
  const id = await issued();
  const t = tokenOf((await svc.post(url(id, '/links'), {})).body.link.url);
  svc.logs.length = 0;
  await page(`/i/${t}?utm=abc123`);
  const all = JSON.stringify(svc.logs);
  assert.ok(!all.includes(t)); assert.ok(!all.includes('abc123'));
  assert.ok(svc.logs.some(l => l.path === '/i/:token' && l.status === 200));
});

test('a link for a voided invoice is invalid, like an unknown token, and is not counted', async () => {
  const id = await issued();
  const l = (await svc.post(url(id, '/links'), {})).body.link;
  await svc.post(url(id, '/void'), { reason: 'Mistake' }, { actor: svc.asAdmin() });
  const p = await page(`/i/${tokenOf(l.url)}`), unknown = await page(`/i/${'C'.repeat(43)}`);
  assert.equal(p.status, 404); assert.equal(p.text, unknown.text); assert.ok(!/Amount due/.test(p.text));
  assert.equal((await svc.get(url(id))).body.shareLinks[0].viewCount, 0);
});

test('HEAD does not count a view, and a doubled slash is the invalid page', async () => {
  const id = await issued();
  const t = tokenOf((await svc.post(url(id, '/links'), {})).body.link.url);
  await fetch(`${svc.base}/i/${t}`, { method: 'HEAD' });
  assert.equal((await page(`/i//${t}`)).status, 404);
  assert.equal((await svc.get(url(id))).body.shareLinks[0].viewCount, 0);
});

test('a link is not logged under any letter case either', async () => {
  const id = await issued();
  const t = tokenOf((await svc.post(url(id, '/links'), {})).body.link.url);
  svc.logs.length = 0;
  const p = await page(`/I/${t}`);
  assert.equal(p.status, 200);
  const all = JSON.stringify(svc.logs);
  assert.ok(!all.includes(t)); assert.ok(svc.logs.some(l => l.path === '/i/:token'));
});

test('an error inside the public route logs /i/:token, never the token', async () => {
  const dbs = await createTestDatabase();
  const real = dbs.db;
  const broken = new Proxy(real, { get: (o, k) => k === 'query' ? (sql, ...a) => (/SET view_count/.test(sql) ? Promise.reject(Object.assign(new Error('boom'), { code: 'XX000' })) : o.query(sql, ...a)) : (typeof o[k] === 'function' ? o[k].bind(o) : o[k]) });
  const s = await startService({ dbs: { ...dbs, db: broken } });
  try {
    const t = 'D'.repeat(43);
    const r = await fetch(`${s.base}/I/${t}?x=secretq`);
    assert.equal(r.status, 500);
    const all = JSON.stringify(s.logs);
    assert.ok(!all.includes(t)); assert.ok(!all.includes('secretq'));
    assert.ok(s.logs.some(l => l.level === 'error' && l.path === '/i/:token'));
  } finally { await s.close(); await dbs.drop(); }
});
