'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');

test('the staff API says which currency and default link life it uses', async () => {
  const s = await startService({ currency: 'USD', shareLinkDefaultDays: 21 });
  try {
    assert.deepEqual((await s.get('/v1/staff/settings')).body, { currency: 'USD', shareLinkDefaultDays: 21 });
    assert.equal((await s.get('/v1/staff/settings', { key: null })).status, 401);
  } finally { await s.close(); }
});
