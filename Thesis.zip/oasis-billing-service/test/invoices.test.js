'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, inDays, STAFF_A, STAFF_B, CUSTOMER_1, CUSTOMER_2 } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });
const count = async () => Number((await svc.db.query('SELECT count(*) FROM invoice')).rows[0].count);
const create = (o, opts) => svc.post('/v1/staff/invoices', validInvoice(o), opts);

test('creates a draft: no number yet, owner is the creator, currency from settings, totals from the lines', async () => {
  const r = await create();
  assert.equal(r.status, 201);
  const inv = r.body.invoice;
  assert.equal(inv.status, 'DRAFT'); assert.equal(inv.invoiceNumber, null);
  assert.equal(inv.ownerUserId, STAFF_A); assert.equal(inv.currency, 'INR');
  assert.equal(inv.totalMinor, 1_000_000); assert.equal(inv.subtotalMinor, 1_000_000); assert.equal(inv.discountMinor, 0); assert.equal(inv.balanceMinor, 1_000_000);
  assert.equal(inv.billToName, 'Example School District');
  const ev = await svc.db.query(`SELECT actor_user_id, actor_role, action FROM invoice_event WHERE invoice_id = $1`, [inv.invoiceId]);
  assert.deepEqual(ev.rows, [{ actor_user_id: STAFF_A, actor_role: 'user', action: 'invoice.create' }]);
  const h = await svc.db.query(`SELECT to_status_code, reason FROM invoice_status_history WHERE invoice_id = $1`, [inv.invoiceId]);
  assert.deepEqual(h.rows, [{ to_status_code: 'DRAFT', reason: 'Invoice created' }]);
});

test('a half rounds away from zero like the database does, with no drift: 1.5 x 333 is 500', async () => {
  const r = await create({ lines: [{ description: 'Part', quantity: 1.5, unitPriceMinor: 333 }, { description: 'Part', quantity: 3, unitPriceMinor: 3333 }] });
  assert.equal(r.body.invoice.totalMinor, 500 + 9999);
});

test('a discount is a negative line; one bigger than the charges is refused and leaves nothing behind', async () => {
  const ok = await create({ lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: 10000 }, { description: 'Early-payment discount', quantity: 1, unitPriceMinor: -1500 }] });
  assert.equal(ok.body.invoice.subtotalMinor, 10000); assert.equal(ok.body.invoice.discountMinor, 1500); assert.equal(ok.body.invoice.totalMinor, 8500);
  const before = await count();
  const bad = await create({ lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: 1000 }, { description: 'Discount', quantity: 1, unitPriceMinor: -1001 }] });
  assert.equal(bad.status, 400); assert.equal(bad.body.reason, 'discount_exceeds_charges');
  assert.equal(await count(), before);
});

test('bad input is a 400 with a reason, never a 500, and creates nothing', async () => {
  const line = o => ({ description: 'Licence', quantity: 1, unitPriceMinor: 100, ...o });
  const cases = [
    ['no body at all', undefined, 'bad_customer'],
    ['customer is not an id', { customerId: 'abc' }, 'bad_customer'],
    ['no lines', { lines: [] }, 'lines_required'],
    ['lines is not a list', { lines: 'x' }, 'lines_required'],
    ['51 lines', { lines: Array.from({ length: 51 }, () => line()) }, 'lines_required'],
    ['quantity zero', { lines: [line({ quantity: 0 })] }, 'bad_line'],
    ['quantity negative', { lines: [line({ quantity: -1 })] }, 'bad_line'],
    ['quantity 0.0004 (more than 3 decimals)', { lines: [line({ quantity: 0.0004 })] }, 'bad_line'],
    ['quantity in exponent form', { lines: [line({ quantity: 1e-7 })] }, 'bad_line'],
    ['quantity above 10000', { lines: [line({ quantity: 10001 })] }, 'bad_line'],
    ['unit price as text', { lines: [line({ unitPriceMinor: '100' })] }, 'bad_line'],
    ['unit price fractional', { lines: [line({ unitPriceMinor: 1.5 })] }, 'bad_line'],
    ['unit price above the cap', { lines: [line({ unitPriceMinor: 10_000_000_001 })] }, 'bad_line'],
    ['blank description', { lines: [line({ description: '   ' })] }, 'bad_line'],
    ['description over 200 characters', { lines: [line({ description: 'x'.repeat(201) })] }, 'bad_line'],
    ['no bill-to', { billTo: undefined }, 'bill_to_required'],
    ['bad country', { billTo: { name: 'X', line1: 'y', city: 'z', countryCode: 'India' } }, 'bad_bill_to'],
    ['not a real date', { dueOn: '2026-02-30' }, 'bad_date'],
    ['date in the wrong shape', { dueOn: '31/10/2026' }, 'bad_date'],
    ['notes over 1000 characters', { notes: 'n'.repeat(1001) }, 'bad_field'],
    ['request id that is not an id', { sourcePurchaseRequestId: 'PR-000123' }, 'bad_source'],
  ];
  const before = await count();
  for (const [name, patch, reason] of cases) {
    const body = patch === undefined ? {} : { ...validInvoice(), ...patch };
    const r = await svc.post('/v1/staff/invoices', body);
    assert.equal(r.status, 400, name); assert.equal(r.body.reason, reason, name);
  }
  assert.equal((await svc.post('/v1/staff/invoices', '{not json')).status, 400);
  assert.equal(await count(), before);
});

test('the biggest allowed line still adds up exactly (no overflow, no rounding)', async () => {
  const r = await create({ lines: Array.from({ length: 50 }, () => ({ description: 'Big', quantity: 10000, unitPriceMinor: 10_000_000_000 })) });
  assert.equal(r.status, 201);
  assert.equal(r.body.invoice.totalMinor, 50 * 10000 * 10_000_000_000);
});

test('idempotency: the same key and request gives the same invoice once; a different request with that key is refused', async () => {
  const key = 'create-key-0001';
  const before = await count();
  const a = await create({}, { headers: { 'Idempotency-Key': key } });
  const b = await create({}, { headers: { 'Idempotency-Key': key } });
  assert.equal(a.status, 201); assert.equal(b.status, 201);
  assert.equal(b.body.invoice.invoiceId, a.body.invoice.invoiceId);
  assert.equal(b.headers.get('idempotent-replayed'), 'true'); assert.equal(a.headers.get('idempotent-replayed'), null);
  assert.equal(await count(), before + 1);
  const other = await create({ notes: 'different' }, { headers: { 'Idempotency-Key': key } });
  assert.equal(other.status, 422); assert.equal(other.body.reason, 'idempotency_key_reused');
  assert.equal((await create({}, { headers: { 'Idempotency-Key': 'x' } })).body.reason, 'bad_idempotency_key');
});

test('idempotency: eight identical requests at the same moment make exactly one invoice', async () => {
  const key = 'create-key-race-1';
  const before = await count();
  const all = await Promise.all(Array.from({ length: 8 }, () => create({}, { headers: { 'Idempotency-Key': key } })));
  assert.ok(all.every(r => r.status === 201));
  assert.equal(new Set(all.map(r => r.body.invoice.invoiceId)).size, 1);
  assert.equal(await count(), before + 1);
});

test('reading: a full invoice, and 404 (not 500) for an id that is unknown or not an id', async () => {
  const { invoice } = (await create()).body;
  const r = await svc.get(`/v1/staff/invoices/${invoice.invoiceId}`);
  assert.equal(r.status, 200);
  assert.deepEqual(Object.keys(r.body).sort(), ['activity', 'billTo', 'creditNotes', 'followUps', 'invoice', 'lines', 'ownerHistory', 'payments', 'shareLinks', 'statusHistory']);
  assert.equal(r.body.lines[0].lineNo, 1); assert.equal(r.body.billTo.name, 'Example School District');
  assert.equal((await svc.get('/v1/staff/invoices/00000000-0000-7000-8000-00000000dead')).status, 404);
  assert.equal((await svc.get('/v1/staff/invoices/not-an-id')).status, 404);
});

test('editing a draft replaces lines and bill-to, can clear the due date, and recomputes the totals', async () => {
  const { invoice } = (await create()).body;
  const url = `/v1/staff/invoices/${invoice.invoiceId}`;
  const r = await svc.patch(url, { lines: [{ description: 'Renewal, 10 seats', quantity: 10, unitPriceMinor: 5000 }], dueOn: null, notes: 'PO to follow', billTo: { name: 'Example Academy', line1: '2 Sample Street', city: 'Mumbai', countryCode: 'IN' } });
  assert.equal(r.status, 200);
  assert.equal(r.body.invoice.totalMinor, 50000); assert.equal(r.body.invoice.dueOn, null); assert.equal(r.body.invoice.notes, 'PO to follow'); assert.equal(r.body.invoice.billToName, 'Example Academy');
  const g = await svc.get(url);
  assert.equal(g.body.lines.length, 1);
  assert.equal((await svc.patch(url, {})).body.reason, 'nothing_to_change');
  assert.equal((await svc.patch(url, { lines: [] })).body.reason, 'lines_required');
});

test('cancelling a draft needs a reason; afterwards it cannot be edited or cancelled again', async () => {
  const { invoice } = (await create()).body;
  const url = `/v1/staff/invoices/${invoice.invoiceId}`;
  assert.equal((await svc.post(`${url}/cancel`, {})).body.reason, 'reason_required');
  const c = await svc.post(`${url}/cancel`, { reason: 'Entered by mistake' });
  assert.equal(c.status, 200); assert.equal(c.body.invoice.status, 'CANCELLED');
  const e = await svc.patch(url, { notes: 'x' });
  assert.equal(e.status, 409); assert.equal(e.body.reason, 'not_a_draft');
  assert.equal((await svc.post(`${url}/cancel`, { reason: 'again' })).status, 409);
  const h = await svc.db.query(`SELECT to_status_code, reason, changed_by_user_id FROM invoice_status_history WHERE invoice_id = $1 ORDER BY changed_at`, [invoice.invoiceId]);
  assert.deepEqual(h.rows.map(x => [x.to_status_code, x.reason]), [['DRAFT', 'Invoice created'], ['CANCELLED', 'Entered by mistake']]);
  assert.equal(h.rows[1].changed_by_user_id, STAFF_A);
});

test('listing filters by status, customer and owner, pages, and refuses silly paging', async () => {
  const s = await startService();
  try {
    const mk = (o, opts) => s.post('/v1/staff/invoices', validInvoice(o), opts);
    const a = (await mk({ customerId: CUSTOMER_1 })).body.invoice;
    const b = (await mk({ customerId: CUSTOMER_2 }, { actor: s.asUser(STAFF_B) })).body.invoice;
    await s.post(`/v1/staff/invoices/${b.invoiceId}/cancel`, { reason: 'Duplicate' });
    const ids = r => r.body.invoices.map(i => i.invoiceId);
    assert.deepEqual(ids(await s.get('/v1/staff/invoices')).sort(), [a.invoiceId, b.invoiceId].sort());
    assert.deepEqual(ids(await s.get('/v1/staff/invoices?status=DRAFT')), [a.invoiceId]);
    assert.deepEqual(ids(await s.get('/v1/staff/invoices?status=cancelled')), [b.invoiceId]);
    assert.deepEqual(ids(await s.get(`/v1/staff/invoices?customerId=${CUSTOMER_2}`)), [b.invoiceId]);
    assert.deepEqual(ids(await s.get(`/v1/staff/invoices?ownerId=${STAFF_B}`)), [b.invoiceId]);
    const page = await s.get('/v1/staff/invoices?limit=1&offset=1');
    assert.equal(page.body.invoices.length, 1); assert.equal(page.body.total, 2);
    for (const q of ['limit=0', 'limit=201', 'offset=-1', 'limit=abc', 'status=NOPE', 'customerId=x', 'ownerId=x', 'dueFrom=soon']) assert.equal((await s.get(`/v1/staff/invoices?${q}`)).status, 400, q);
  } finally { await s.close(); }
});

test('nothing a person typed reaches a log line', async () => {
  svc.logs.length = 0;
  await create({ billTo: { name: 'Zebra Secret Academy', line1: '9 Hidden Lane', city: 'Pune', countryCode: 'IN' }, lines: [{ description: 'Quokka licence', quantity: 7, unitPriceMinor: 123457 }] });
  const all = JSON.stringify(svc.logs);
  for (const secret of ['Zebra', 'Hidden', 'Quokka', '123457', '864199']) assert.ok(!all.includes(secret), secret);
});
