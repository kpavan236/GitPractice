'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { validInvoice, backdate, dbDate, STAFF_A, STAFF_B, CUSTOMER_1, CUSTOMER_2 } = require('./helpers/fixtures');
const { markOverdue } = require('../src/overdue');
const { uuidv7 } = require('../src/uuid');

const url = (id, tail = '') => `/v1/staff/invoices/${id}${tail}`;
const admin = s => ({ actor: s.asAdmin() });

/**
 * A known set of invoices (all synthetic), in a fresh database:
 *   Owner A, customer 1:  a1 10,000 paid in full today, issued 10 days ago      a2 20,000 sent, due in 20 days
 *                         a3 10,000 issued 40 days ago, due 10 days ago, 2,000 paid
 *   Owner B, customer 2:  b1  5,000 due 45 days ago, no follow-up                b2  7,000 due 70 days ago, follow-up date lapsed
 *                         b3 a draft                                             b4 issued then voided
 * Nobody ran the nightly job: every "overdue" below is computed at read time.
 */
async function scenario(s) {
  const mk = async (owner, customerId, total) => (await s.post('/v1/staff/invoices', validInvoice({ customerId, lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: total }] }), { actor: s.asUser(owner) })).body.invoice.invoiceId;
  const issue = async id => { await s.post(url(id, '/issue'), {}); return id; };
  const ids = {};
  ids.a1 = await issue(await mk(STAFF_A, CUSTOMER_1, 10000)); await backdate(s.db, ids.a1, { issuedDaysAgo: 10, dueDaysAgo: -20 });
  await s.post(url(ids.a1, '/payments'), { amountMinor: 10000, method: 'bank_transfer' });
  ids.a2 = await issue(await mk(STAFF_A, CUSTOMER_1, 20000)); await s.post(url(ids.a2, '/mark-sent'), { channel: 'email' }); await backdate(s.db, ids.a2, { issuedDaysAgo: 1, dueDaysAgo: -20 });
  ids.a3 = await issue(await mk(STAFF_A, CUSTOMER_1, 10000)); await backdate(s.db, ids.a3, { issuedDaysAgo: 40, dueDaysAgo: 10 });
  await s.post(url(ids.a3, '/payments'), { amountMinor: 2000, method: 'cheque' });
  ids.b1 = await issue(await mk(STAFF_B, CUSTOMER_2, 5000)); await backdate(s.db, ids.b1, { issuedDaysAgo: 60, dueDaysAgo: 45 });
  ids.b2 = await issue(await mk(STAFF_B, CUSTOMER_2, 7000)); await backdate(s.db, ids.b2, { issuedDaysAgo: 100, dueDaysAgo: 70 });
  await s.db.query(`INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome, next_follow_up_on) VALUES ($1, $2, $3, 'call', 'Will pay soon', CURRENT_DATE - 3)`, [uuidv7(), ids.b2, STAFF_B]);
  ids.b3 = await mk(STAFF_B, CUSTOMER_2, 3000);
  ids.b4 = await issue(await mk(STAFF_B, CUSTOMER_2, 4000)); await s.post(url(ids.b4, '/void'), { reason: 'Duplicate' }, admin(s));
  return ids;
}

let svc, ids;
test.before(async () => { svc = await startService(); ids = await scenario(svc); });
test.after(async () => { await svc.close(); });
const dash = async () => (await svc.get('/v1/staff/reports/dashboard', admin(svc))).body;
const idsOf = r => r.body.invoices.map(i => i.invoiceId).sort();

test('status tiles use the effective status, with count and amount', async () => {
  const d = await dash();
  assert.deepEqual(d.tiles, {
    DRAFT: { count: 1, amountMinor: 3000 }, ISSUED: { count: 0, amountMinor: 0 }, SENT: { count: 1, amountMinor: 20000 },
    OVERDUE: { count: 3, amountMinor: 22000 }, PAID: { count: 1, amountMinor: 10000 }, VOID: { count: 1, amountMinor: 4000 },
  });
  assert.equal(d.currency, 'INR');
});

test('money: outstanding, overdue, and collected this month (net of anything voided)', async () => {
  const d = await dash();
  assert.deepEqual(d.money, { outstandingMinor: 40000, overdueMinor: 20000, collectedThisMonthMinor: 12000 });
});

test('aging puts each open balance in current, 1-30, 31-60 or 61+ days past due', async () => {
  assert.deepEqual((await dash()).aging, { current: { count: 1, amountMinor: 20000 }, '1-30': { count: 1, amountMinor: 8000 }, '31-60': { count: 1, amountMinor: 5000 }, '61+': { count: 1, amountMinor: 7000 } });
});

test('by owner: invoices, value, paid value, who closed deals, and average days to pay', async () => {
  const d = await dash();
  const a = d.byOwner.find(o => o.ownerUserId === STAFF_A), b = d.byOwner.find(o => o.ownerUserId === STAFF_B);
  assert.deepEqual(a, { ownerUserId: STAFF_A, invoices: 3, valueMinor: 40000, paidValueMinor: 12000, closedCount: 1, closedValueMinor: 10000, avgDaysToPay: 10 });
  assert.deepEqual(b, { ownerUserId: STAFF_B, invoices: 2, valueMinor: 12000, paidValueMinor: 0, closedCount: 0, closedValueMinor: 0, avgDaysToPay: null });
});

test('by customer: outstanding balance, last payment, last follow-up', async () => {
  const d = await dash();
  const c1 = d.byCustomer.find(c => c.customerId === CUSTOMER_1), c2 = d.byCustomer.find(c => c.customerId === CUSTOMER_2);
  assert.equal(c1.outstandingMinor, 28000); assert.equal(c1.lastPaymentOn, await dbDate(svc.db, 0)); assert.equal(c1.lastFollowUpAt, null); assert.equal(c1.billToName, 'Example School District');
  assert.equal(c2.outstandingMinor, 12000); assert.equal(c2.lastPaymentOn, null); assert.ok(c2.lastFollowUpAt);
});

test('follow-up health: overdue with no follow-up, and a lapsed follow-up date', async () => {
  const h = (await dash()).followUpHealth;
  assert.equal(h.missing, 2); assert.equal(h.lapsed, 1);
  assert.deepEqual(h.items.map(i => [i.invoiceId, i.followUpHealth]).sort(), [[ids.a3, 'missing'], [ids.b1, 'missing'], [ids.b2, 'lapsed']].sort());
});

test('the nightly job changes nothing on the dashboard: it was already right without it', async () => {
  // The nightly job rewrites the stored status (and its timestamp) on the invoices; the effective status and every figure stay the same.
  const snap = async () => { const d = await dash(); return JSON.stringify({ ...d, asOf: null, followUpHealth: { ...d.followUpHealth, items: d.followUpHealth.items.map(({ status, statusChangedAt, ...rest }) => rest) } }); };
  const before = await snap();
  assert.equal(await markOverdue(svc.db), 3);
  assert.equal(await snap(), before);
  assert.equal(await markOverdue(svc.db), 0);
});

test('every figure opens the matching invoice list', async () => {
  const list = async q => idsOf(await svc.get(`/v1/staff/invoices?${q}`));
  assert.deepEqual(await list('status=SENT'), [ids.a2]);
  assert.deepEqual(await list('status=OVERDUE'), [ids.a3, ids.b1, ids.b2].sort());
  assert.deepEqual(await list('open=1'), [ids.a2, ids.a3, ids.b1, ids.b2].sort());
  assert.deepEqual(await list('bucket=61%2B'), [ids.b2]);
  assert.deepEqual(await list('bucket=current'), [ids.a2]);
  assert.deepEqual(await list('bucket=1-30'), [ids.a3]);
  assert.deepEqual(await list(`closed=1&ownerId=${STAFF_A}`), [ids.a1]);
  assert.deepEqual(await list('health=missing'), [ids.a3, ids.b1].sort());
  assert.deepEqual(await list('health=lapsed'), [ids.b2]);
  assert.deepEqual(await list(`customerId=${CUSTOMER_2}&open=1`), [ids.b1, ids.b2].sort());
  for (const q of ['bucket=soon', 'health=never', 'open=2', 'closed=yes']) assert.equal((await svc.get(`/v1/staff/invoices?${q}`)).status, 400, q);
});

test('the export has the rows of the filtered list, ignores paging, and says if it was cut short', async () => {
  const r = await svc.get('/v1/staff/reports/export?status=OVERDUE&limit=1&offset=5', admin(svc));
  assert.equal(r.status, 200); assert.equal(r.body.rows.length, 3); assert.equal(r.body.total, 3); assert.equal(r.body.truncated, false);
  assert.equal((await svc.get('/v1/staff/reports/export?status=NOPE', admin(svc))).status, 400);
});

test('a user may not read the dashboard or the export; the portal hiding them is not what protects them', async () => {
  assert.equal((await svc.get('/v1/staff/reports/dashboard')).status, 403);
  assert.equal((await svc.get('/v1/staff/reports/export')).status, 403);
});

test('voiding a payment reopens the invoice but the owner keeps the "closed" credit; paying again does not move it', async () => {
  const s = await startService();
  try {
    const i = await scenario(s);
    const closed = async () => (await s.get('/v1/staff/reports/dashboard', admin(s))).body.byOwner.find(o => o.ownerUserId === STAFF_A);
    const before = await closed();
    const pay = (await s.get(url(i.a1))).body.payments[0];
    await s.post(url(i.a1, `/payments/${pay.paymentId}/void`), { reason: 'Bank reversed it' }, admin(s));
    const after = await closed();
    assert.equal(after.closedCount, 1); assert.equal(after.closedValueMinor, 10000); assert.equal(after.paidValueMinor, before.paidValueMinor - 10000);
    const d = (await s.get('/v1/staff/reports/dashboard', admin(s))).body;
    assert.equal(d.tiles.PAID.count, 0); assert.equal(d.money.outstandingMinor, 50000);
    await s.post(url(i.a1, '/payments'), { amountMinor: 10000, method: 'po' });
    assert.equal((await closed()).avgDaysToPay, 10);
  } finally { await s.close(); }
});

test('an empty database gives zeros and empty lists, not errors', async () => {
  const s = await startService();
  try {
    const d = (await s.get('/v1/staff/reports/dashboard', admin(s))).body;
    assert.equal(d.tiles.PAID.count, 0); assert.deepEqual(d.money, { outstandingMinor: 0, overdueMinor: 0, collectedThisMonthMinor: 0 });
    assert.deepEqual(d.byOwner, []); assert.deepEqual(d.byCustomer, []); assert.deepEqual(d.followUpHealth, { missing: 0, lapsed: 0, items: [] });
    assert.deepEqual(d.aging, { current: { count: 0, amountMinor: 0 }, '1-30': { count: 0, amountMinor: 0 }, '31-60': { count: 0, amountMinor: 0 }, '61+': { count: 0, amountMinor: 0 } });
  } finally { await s.close(); }
});
