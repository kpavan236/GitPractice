# Fakes in this service

## The notifier (`src/notifier.js`)

`sendInvoiceLink({ to, link, invoiceNumber })` records the call in memory (the last 1,000) and sends nothing. Staff send share links themselves today.

A real implementation needs, before it exists:
1. An email provider approved through the IT Helpdesk (cainc.service-now.com).
2. CA employee review of the message wording, since customers will read it.
3. A decision on where `to` comes from (the customer contact is not stored in this database).
4. The SMTP settings (`SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`) read from the environment, never committed. The names are reserved in `.env.example`; nothing reads them.

`config.js` refuses any `NOTIFIER` other than `fake`, and refuses production while only the fake exists.
