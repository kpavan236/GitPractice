'use strict';

/**
 * The invoice-link sender, behind one method: sendInvoiceLink({ to, link, invoiceNumber }). No real provider is approved (new email services go through the IT
 * Helpdesk, cainc.service-now.com, first, and the wording needs CA employee review), so the only implementation is a FAKE that records the call in memory.
 * Staff send the link themselves today; this exists so a real sender can be added later without touching the callers.
 */
function createFakeNotifier() {
  const sent = [];
  return {
    kind: 'fake',
    sent,
    async sendInvoiceLink(message) {
      sent.push({ ...message, at: Date.now() });
      if (sent.length > 1000) sent.shift();      // a fake that runs for weeks must not grow without limit
    },
    last: () => sent[sent.length - 1] || null,
  };
}

module.exports = { createFakeNotifier };
