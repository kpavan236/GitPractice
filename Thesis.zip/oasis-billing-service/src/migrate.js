'use strict';
// Applies db/billing/*.sql, in file-name order, once each. Records every file (with a checksum) in schema_migration, and stops if a file that was
// applied has since changed. Usage: node src/migrate.js   (needs BILLING_DATABASE_URL)
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');

async function migrate(connectionString, dir) {
  const pool = new Pool({ connectionString, max: 1 });
  try {
    await pool.query('CREATE TABLE IF NOT EXISTS schema_migration (filename text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())');
    const files = fs.readdirSync(dir).filter(f => /^\d+_.*\.sql$/.test(f) && !f.endsWith('.down.sql')).sort();
    const applied = [];
    for (const file of files) {
      const sql = fs.readFileSync(path.join(dir, file), 'utf8');
      const checksum = crypto.createHash('sha256').update(sql).digest('hex');
      const done = await pool.query('SELECT checksum FROM schema_migration WHERE filename = $1', [file]);
      if (done.rowCount) {
        if (done.rows[0].checksum !== checksum) throw new Error(`${file} was applied and has since changed. Add a new migration instead of editing an old one.`);
        continue;
      }
      await pool.query(sql);
      await pool.query('INSERT INTO schema_migration (filename, checksum) VALUES ($1, $2)', [file, checksum]);
      applied.push(file);
    }
    return applied;
  } finally { await pool.end(); }
}

module.exports = { migrate };

if (require.main === module) {
  (async () => {
    if (!process.env.BILLING_DATABASE_URL) throw new Error('BILLING_DATABASE_URL is required.');
    const applied = await migrate(process.env.BILLING_DATABASE_URL, path.join(__dirname, '..', 'db', 'billing'));
    console.log(`billing: ${applied.length ? `applied ${applied.join(', ')}` : 'up to date'}`);
  })().catch(err => { console.error(err.message); process.exit(1); });
}
