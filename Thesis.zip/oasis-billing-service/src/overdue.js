'use strict';
const { tx } = require('./db');

/**
 * Moves unpaid ISSUED and SENT invoices that are past their due date to OVERDUE, and returns how many moved. Safe to run any number of times.
 * The screens and reports compute "overdue" themselves (v_invoice_state), so nothing depends on this having run.
 */
async function markOverdue(db) {
  return tx(db, async client => {
    await client.query(`SELECT set_config('app.reason', 'Past its due date (nightly job)', true), set_config('app.actor_id', '', true)`);
    const { rowCount } = await client.query(
      // The status test is repeated on the outer statement on purpose: if a payment or a void commits between the snapshot and the row lock, Postgres rechecks it and skips that row.
      `UPDATE invoice SET status_code = 'OVERDUE' WHERE status_code IN ('ISSUED', 'SENT') AND invoice_id IN (SELECT invoice_id FROM v_invoice_state WHERE status_code IN ('ISSUED', 'SENT') AND is_overdue)`);
    return rowCount;
  });
}

module.exports = { markOverdue };
