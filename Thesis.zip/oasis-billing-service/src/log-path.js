'use strict';

/** The path to write in a log: no query string, and a share link (any case, since Express routes case-insensitively) never appears, only /i/:token. */
const logPath = req => {
  const path = String(req.originalUrl || req.url || '').split('?')[0];
  return /^\/i(\/|$)/i.test(path) ? '/i/:token' : path;
};

module.exports = { logPath };
