'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { isUuid } = require('./validate');

/** Only an admin changes who owns an invoice. Each change is kept (from, to, by whom, when, why); "who closed the deal" in the reports follows the owner. */
function createOwner({ db, invoices, events }) {
  async function change(actor, id, input) {
    if (!isUuid(input.toUserId)) throw refuse('toUserId must be a staff member id.', 'bad_owner');
    const reason = invoices.reasonOf(input);
    return tx(db, async client => {
      const inv = await invoices.lock(client, id);
      if (inv.owner_user_id === input.toUserId) throw refuse('That person already owns this invoice.', 'same_owner');
      await client.query('UPDATE invoice SET owner_user_id = $2 WHERE invoice_id = $1', [id, input.toUserId]);
      await client.query('INSERT INTO invoice_owner_history (invoice_id, from_user_id, to_user_id, changed_by_user_id, reason) VALUES ($1, $2, $3, $4, $5)', [id, inv.owner_user_id, input.toUserId, actor.userId, reason]);
      await events.record(client, { invoiceId: id, actor, action: 'owner.change', reason, detail: { from: inv.owner_user_id, to: input.toUserId } });
      return { invoice: await invoices.read(client, id) };
    });
  }
  return { change };
}

module.exports = { createOwner };
