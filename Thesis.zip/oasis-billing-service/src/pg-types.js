'use strict';
const { types } = require('pg');

// A business date (due on, received on) is a calendar day, not an instant. pg would turn it into a JavaScript Date at local midnight and
// the day could shift with the server's time zone. Keep it as the text the database sent: "2026-10-31".
types.setTypeParser(1082, value => value);
