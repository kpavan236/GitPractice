'use strict';
const crypto = require('node:crypto');
const { refuse } = require('./errors');
const { tx } = require('./db');

/** The same JSON with its keys in a fixed order, so the same request always hashes the same. */
const stable = v => (Array.isArray(v) ? `[${v.map(stable).join(',')}]` : v && typeof v === 'object' ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${stable(v[k])}`).join(',')}}` : JSON.stringify(v));

/**
 * A retry with the same Idempotency-Key gets the FIRST answer back and does nothing twice; the same key with a different request is refused, never silently replayed.
 * Two requests with the same key at the same moment queue on an advisory lock (taken inside the transaction), so the second one always sees the first one's stored answer.
 * The stored answer is written in the SAME transaction as the work: a request that fails stores nothing, so it can be retried.
 */
function createIdempotency({ db }) {
  async function run({ scope, key, actor, body }, work) {
    if (key === undefined) return tx(db, async client => ({ ...(await work(client)), replayed: false }));
    if (typeof key !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(key)) throw refuse('Idempotency-Key must be 8 to 100 letters, digits, dashes or underscores.', 'bad_idempotency_key');
    const requestHash = crypto.createHash('sha256').update(stable(body)).digest('hex');
    return tx(db, async client => {
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`${scope}\u001f${key}\u001f${actor.userId}`]);
      const { rows: [seen] } = await client.query('SELECT request_hash, status, response FROM idempotency_key WHERE scope = $1 AND key = $2 AND actor_user_id = $3', [scope, key, actor.userId]);
      if (seen) {
        if (seen.request_hash !== requestHash) throw refuse('That Idempotency-Key was already used for a different request.', 'idempotency_key_reused', {}, 422);
        return { status: seen.status, body: seen.response, replayed: true };
      }
      const out = await work(client);
      await client.query('INSERT INTO idempotency_key (scope, key, actor_user_id, request_hash, status, response) VALUES ($1, $2, $3, $4, $5, $6)',
        [scope, key, actor.userId, requestHash, out.status, JSON.stringify(out.body)]);
      return { ...out, replayed: false };
    });
  }
  return { run };
}

module.exports = { createIdempotency };
