'use strict';
const crypto = require('node:crypto');
const { refuse } = require('./errors');

const { UUID } = require('./validate');

/**
 * Every staff call carries the service key, and says which staff member is acting and in which role (the portal knows both). The key is checked FIRST, in constant time
 * and on hashes of equal length, so neither its length nor its content leaks. The role is a header the portal sets from the signed-in session; it is never read from a body.
 */
function createServiceAuth({ serviceKey }) {
  const want = crypto.createHash('sha256').update(serviceKey).digest();
  return (req, _res, next) => {
    const sent = crypto.createHash('sha256').update(req.get('X-Service-Key') || '').digest();
    if (!req.get('X-Service-Key') || !crypto.timingSafeEqual(sent, want)) return next(refuse('A valid service key is required.', 'service_key_required', {}, 401));
    const userId = req.get('X-Acting-User') || '', role = req.get('X-Acting-Role') || '';
    if (!UUID.test(userId) || !['user', 'admin'].includes(role)) return next(refuse('Say who is acting: X-Acting-User (an id) and X-Acting-Role (user or admin).', 'bad_actor'));
    req.actor = { userId, role };
    next();
  };
}

module.exports = { createServiceAuth };
