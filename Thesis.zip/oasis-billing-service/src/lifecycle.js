'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { text, isoDate } = require('./validate');

const CHANNELS = ['email', 'call', 'meeting', 'other'];

/** Issue, mark sent and void. Every change takes the invoice's row lock first, so two people acting on one invoice queue instead of racing. */
function createLifecycle({ db, invoices, events }) {
  async function issue(actor, id, input) {
    const dueOn = isoDate(input.dueOn, { name: 'dueOn', optional: true });
    return tx(db, async client => {
      const inv = await invoices.lock(client, id);
      if (inv.status_code !== 'DRAFT') throw refuse('Only a draft can be issued.', 'not_a_draft', { status: inv.status_code }, 409);
      const { rows: [c] } = await client.query(
        `SELECT (SELECT count(*) FROM invoice_line WHERE invoice_id = $1) AS lines, EXISTS (SELECT 1 FROM invoice_bill_to WHERE invoice_id = $1) AS has_bill_to, CURRENT_DATE::text AS today`, [id]);
      if (Number(c.lines) === 0) throw refuse('Add at least one line before issuing.', 'lines_required');
      if (!c.has_bill_to) throw refuse('Add the bill-to details before issuing.', 'bill_to_required');
      if (BigInt(inv.total_minor) <= 0n) throw refuse('The invoice total must be more than zero.', 'total_not_positive');
      const due = dueOn || inv.due_on;
      if (!due) throw refuse('Choose a due date before issuing.', 'due_date_required');
      if (due < c.today) throw refuse('The due date cannot be before today.', 'due_before_issue');
      await events.setContext(client, actor, 'Issued');
      await client.query(`UPDATE invoice SET status_code = 'ISSUED', issued_on = CURRENT_DATE, due_on = $2 WHERE invoice_id = $1`, [id, due]);
      await events.record(client, { invoiceId: id, actor, action: 'invoice.issue', detail: { dueOn: due } });
      return { invoice: await invoices.read(client, id) };
    });
  }

  async function markSent(actor, id, input) {
    if (!CHANNELS.includes(input.channel)) throw refuse(`channel must be one of ${CHANNELS.join(', ')}.`, 'bad_channel');
    const note = text(input.note, { name: 'note', max: 500, optional: true });
    return tx(db, async client => {
      const inv = await invoices.lock(client, id);
      if (!['ISSUED', 'SENT', 'OVERDUE'].includes(inv.status_code)) throw refuse('Only an issued invoice can be marked as sent.', 'bad_status', { status: inv.status_code }, 409);
      if (inv.status_code === 'ISSUED') {
        await events.setContext(client, actor, `Marked as sent by ${input.channel}`);
        await client.query(`UPDATE invoice SET status_code = 'SENT' WHERE invoice_id = $1`, [id]);
      }
      await events.record(client, { invoiceId: id, actor, action: 'invoice.mark_sent', reason: note ?? null, detail: { channel: input.channel } });
      return { invoice: await invoices.read(client, id) };
    });
  }

  async function voidInvoice(actor, id, input) {
    const reason = invoices.reasonOf(input);
    return tx(db, async client => {
      const inv = await invoices.lock(client, id);
      if (!['ISSUED', 'SENT', 'OVERDUE'].includes(inv.status_code)) throw refuse('Only an issued, unpaid invoice can be voided. A paid invoice is credited instead.', 'bad_status', { status: inv.status_code }, 409);
      const { rows: [p] } = await client.query('SELECT COALESCE(sum(amount_minor), 0) AS paid FROM payment WHERE invoice_id = $1', [id]);
      if (BigInt(p.paid) > 0n) throw refuse('Payments have been recorded. Void them first, or raise a credit note.', 'has_payments', {}, 409);
      await events.setContext(client, actor, reason);
      await client.query(`UPDATE invoice SET status_code = 'VOID' WHERE invoice_id = $1`, [id]);
      await events.record(client, { invoiceId: id, actor, action: 'invoice.void', reason });
      return { invoice: await invoices.read(client, id) };
    });
  }

  return { issue, markSent, void: voidInvoice };
}

module.exports = { createLifecycle, CHANNELS };
