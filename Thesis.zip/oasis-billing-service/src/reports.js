'use strict';

const num = v => (v === null || v === undefined ? null : Number(v));
const STATUSES = ['DRAFT', 'ISSUED', 'SENT', 'OVERDUE', 'PAID', 'VOID'];
const BUCKETS = ['current', '1-30', '31-60', '61+'];
const ISSUED_FAMILY = `status_code IN ('ISSUED', 'SENT', 'OVERDUE', 'PAID')`;

/**
 * Admin figures. Everything reads v_invoice_state, so "overdue" is the same everywhere and is right even if the nightly job has never run.
 * "Who closed the deal" is the owner of an invoice that ever reached PAID (closed_at is set the first time, and survives a reversed payment).
 */
function createReports({ db, invoices, currency }) {
  async function dashboard() {
    const [tiles, money, collected, aging, owners, customers, health, items, today] = await Promise.all([
      db.query(`SELECT effective_status AS status, count(*) AS count, COALESCE(sum(total_minor), 0) AS amount FROM v_invoice_state GROUP BY 1`),
      db.query(`SELECT COALESCE(sum(balance_minor) FILTER (WHERE is_open), 0) AS outstanding, COALESCE(sum(balance_minor) FILTER (WHERE is_overdue), 0) AS overdue FROM v_invoice_state`),
      db.query(`SELECT COALESCE(sum(amount_minor), 0) AS collected FROM payment WHERE received_on >= date_trunc('month', CURRENT_DATE)::date AND received_on < (date_trunc('month', CURRENT_DATE) + interval '1 month')::date`),
      db.query(`SELECT aging_bucket AS bucket, count(*) AS count, COALESCE(sum(balance_minor), 0) AS amount FROM v_invoice_state WHERE aging_bucket IS NOT NULL GROUP BY 1`),
      db.query(`SELECT owner_user_id,
                       count(*) FILTER (WHERE ${ISSUED_FAMILY}) AS invoices,
                       COALESCE(sum(total_minor) FILTER (WHERE ${ISSUED_FAMILY}), 0) AS value_minor,
                       COALESCE(sum(paid_minor) FILTER (WHERE ${ISSUED_FAMILY}), 0) AS paid_value_minor,
                       count(*) FILTER (WHERE closed_at IS NOT NULL) AS closed_count,
                       COALESCE(sum(total_minor) FILTER (WHERE closed_at IS NOT NULL), 0) AS closed_value_minor,
                       round(avg(closed_at::date - issued_on) FILTER (WHERE closed_at IS NOT NULL), 1) AS avg_days_to_pay
                  FROM v_invoice_state WHERE owner_user_id IS NOT NULL GROUP BY owner_user_id HAVING count(*) FILTER (WHERE ${ISSUED_FAMILY}) > 0 ORDER BY value_minor DESC, owner_user_id`),
      db.query(`SELECT v.customer_id, max(v.bill_to_name) AS bill_to_name, COALESCE(sum(v.balance_minor) FILTER (WHERE v.is_open), 0) AS outstanding_minor, max(v.last_follow_up_at) AS last_follow_up_at,
                       (SELECT max(p.received_on) FROM payment p JOIN invoice i ON i.invoice_id = p.invoice_id
                         WHERE i.customer_id = v.customer_id AND p.amount_minor > 0 AND NOT EXISTS (SELECT 1 FROM payment r WHERE r.reverses_payment_id = p.payment_id)) AS last_payment_on
                  FROM v_invoice_state v GROUP BY v.customer_id HAVING count(*) FILTER (WHERE v.status_code NOT IN ('DRAFT', 'CANCELLED')) > 0 ORDER BY outstanding_minor DESC, v.customer_id LIMIT 200`),
      db.query(`SELECT follow_up_health AS health, count(*) AS count FROM v_invoice_state WHERE follow_up_health IS NOT NULL GROUP BY 1`),
      db.query(`SELECT * FROM v_invoice_state WHERE follow_up_health IS NOT NULL ORDER BY due_on, invoice_id LIMIT 50`),
      db.query(`SELECT CURRENT_DATE::text AS today`),
    ]);
    const tile = Object.fromEntries(STATUSES.map(s => [s, { count: 0, amountMinor: 0 }]));
    for (const r of tiles.rows) if (tile[r.status]) tile[r.status] = { count: Number(r.count), amountMinor: Number(r.amount) };
    const bucket = Object.fromEntries(BUCKETS.map(b => [b, { count: 0, amountMinor: 0 }]));
    for (const r of aging.rows) bucket[r.bucket] = { count: Number(r.count), amountMinor: Number(r.amount) };
    const h = Object.fromEntries(health.rows.map(r => [r.health, Number(r.count)]));
    return {
      currency, asOf: today.rows[0].today, tiles: tile,
      money: { outstandingMinor: Number(money.rows[0].outstanding), overdueMinor: Number(money.rows[0].overdue), collectedThisMonthMinor: Number(collected.rows[0].collected) },
      aging: bucket,
      byOwner: owners.rows.map(r => ({ ownerUserId: r.owner_user_id, invoices: Number(r.invoices), valueMinor: Number(r.value_minor), paidValueMinor: Number(r.paid_value_minor),
        closedCount: Number(r.closed_count), closedValueMinor: Number(r.closed_value_minor), avgDaysToPay: num(r.avg_days_to_pay) })),
      byCustomer: customers.rows.map(r => ({ customerId: r.customer_id, billToName: r.bill_to_name, outstandingMinor: Number(r.outstanding_minor), lastPaymentOn: r.last_payment_on, lastFollowUpAt: r.last_follow_up_at })),
      followUpHealth: { missing: h.missing || 0, lapsed: h.lapsed || 0, items: items.rows.map(invoices.shape) },
    };
  }

  const EXPORT_MAX = 10_000;
  async function exportRows(query) {
    const { limit: _l, offset: _o, ...filters } = query;
    const out = await invoices.list({ ...filters, limit: String(EXPORT_MAX), offset: '0' }, { maxLimit: EXPORT_MAX });
    return { rows: out.invoices, total: out.total, truncated: out.total > out.invoices.length };
  }

  return { dashboard, exportRows };
}

module.exports = { createReports };
