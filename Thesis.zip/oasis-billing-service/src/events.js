'use strict';

/** The audit row for one change: who, in which role, when, what and why. Written on the SAME connection as the change, so one cannot exist without the other. */
function createEvents() {
  async function record(client, { invoiceId, actor, action, reason = null, detail = {} }) {
    await client.query(
      'INSERT INTO invoice_event (invoice_id, actor_user_id, actor_role, action, reason, detail) VALUES ($1, $2, $3, $4, $5, $6)',
      [invoiceId, actor.userId, actor.role, action, reason, JSON.stringify(detail)]);
  }
  /** The status-history trigger records who made a change and why from these two transaction settings. Call it before any change of status. */
  async function setContext(client, actor, reason) {
    await client.query(`SELECT set_config('app.actor_id', $1, true), set_config('app.reason', $2, true)`, [actor.userId, reason]);
  }
  return { record, setContext };
}

module.exports = { createEvents };
