'use strict';
require('./pg-types');
const crypto = require('node:crypto');
const express = require('express');
const { refuse, wrap, errorHandler } = require('./errors');
const { createServiceAuth } = require('./service-auth');
const { createPermissions } = require('./permissions');
const { createEvents } = require('./events');
const { rateLimit } = require('./rate-limit');
const { createFakeNotifier } = require('./notifier');
const { createIdempotency } = require('./idempotency');
const { createInvoices } = require('./invoices');
const { invoiceRoutes } = require('./routes/invoices');
const { createLifecycle } = require('./lifecycle');
const { lifecycleRoutes } = require('./routes/lifecycle');
const { createPayments } = require('./payments');
const { paymentRoutes } = require('./routes/payments');
const { createOwner } = require('./owner');
const { createFollowUps } = require('./follow-ups');
const { followUpRoutes } = require('./routes/follow-ups');
const { logPath } = require('./log-path');
const { createShareLinks } = require('./share-links');
const { shareLinkRoutes } = require('./routes/share-links');
const { publicRoutes } = require('./routes/public');
const { createReports } = require('./reports');
const { reportRoutes } = require('./routes/reports');

/**
 * Builds the HTTP app. Everything it needs is passed in, so tests hand it a throwaway database.
 * Logging: one line per request (method, path, status, time, request id). Never a body, a query string, a token or an amount.
 * `routes(app)` is a test seam: it may add routes to the app just before the 404. Production never passes it.
 */
function createApp({ db, serviceKey, hashPepper, currency, shareLinkDefaultDays, publicBaseUrl, notifier = createFakeNotifier(), hsts = false,
  limiter = rateLimit({ max: 600 }), publicLimiter = rateLimit({ max: 30 }), routes, log = line => console.log(JSON.stringify(line)) }) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    const inbound = req.get('X-Request-Id');
    req.id = inbound && /^[A-Za-z0-9_-]{8,64}$/.test(inbound) ? inbound : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Cache-Control', 'no-store');
    res.set('Referrer-Policy', 'no-referrer');
    if (hsts) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    const started = Date.now();
    // A share link carries its secret in the path, so it is never logged as it came in. The query string is never logged either.
    const path = logPath(req);
    res.on('finish', () => log({ level: 'info', requestId: req.id, method: req.method, path, status: res.statusCode, ms: Date.now() - started }));
    next();
  });

  app.get('/healthz', (_req, res) => res.json({ ok: true }));
  app.get('/readyz', async (_req, res) => {
    try { await db.query('SELECT 1'); res.json({ ok: true }); }
    catch (_) { res.status(503).json({ ok: false }); }
  });

  const staff = express.Router();
  staff.use(limiter);
  staff.use(express.json({ limit: '32kb' }));
  const permissions = createPermissions({ db });
  const events = createEvents();                 // later tasks hand `permissions` and `events` to their routers
  staff.use(createServiceAuth({ serviceKey }));
  staff.get('/whoami', (req, res) => res.json(req.actor));
  staff.get('/settings', (_req, res) => res.json({ currency, shareLinkDefaultDays }));      // so the portal can show the currency and the default link life without its own copy
  staff.get('/can/:action', wrap(async (req, res) => {
    if (!(await permissions.can(req.actor.role, req.params.action))) throw refuse('You do not have permission to do that.', 'forbidden', {}, 403);
    res.json({ ok: true });
  }));
  const idempotency = createIdempotency({ db });
  const invoices = createInvoices({ db, events, idempotency, currency });
  staff.use(invoiceRoutes({ invoices, permissions }));
  const lifecycle = createLifecycle({ db, invoices, events });
  staff.use(lifecycleRoutes({ lifecycle, permissions }));
  const payments = createPayments({ db, invoices, idempotency, events });
  staff.use(paymentRoutes({ payments, permissions }));
  const owner = createOwner({ db, invoices, events });
  const followUps = createFollowUps({ db, invoices, events });
  staff.use(followUpRoutes({ owner, followUps, permissions }));
  const shareLinks = createShareLinks({ db, invoices, events, hashPepper, defaultDays: shareLinkDefaultDays, publicBaseUrl });
  staff.use(shareLinkRoutes({ shareLinks, permissions }));
  const reports = createReports({ db, invoices, currency });
  staff.use(reportRoutes({ reports, permissions }));
  app.use('/v1/staff', staff);
  app.use(publicRoutes({ shareLinks, publicLimiter }));
  if (routes) routes(app);

  app.use((req, res) => res.status(404).json({ error: 'not_found', message: 'No such route.', requestId: req.id }));
  app.use(errorHandler(log));
  return app;
}

module.exports = { createApp };
