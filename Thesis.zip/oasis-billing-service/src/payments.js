'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { text, whole, isoDate, isUuid } = require('./validate');

const MAX_AMOUNT = 100_000_000_000_000;
const PAYABLE = ['ISSUED', 'SENT', 'OVERDUE'];

function createPayments({ db, invoices, idempotency, events }) {
  /** Paid, credited and today, read under the invoice's row lock: two payments at once cannot both see the same balance. */
  async function money(client, id) {
    const { rows: [m] } = await client.query(
      `SELECT total_minor, due_on, (SELECT COALESCE(sum(amount_minor), 0) FROM payment WHERE invoice_id = $1) AS paid,
              (SELECT COALESCE(sum(amount_minor), 0) FROM credit_note WHERE invoice_id = $1) AS credited, CURRENT_DATE::text AS today FROM invoice WHERE invoice_id = $1`, [id]);
    return { total: BigInt(m.total_minor), paid: BigInt(m.paid), credited: BigInt(m.credited), dueOn: m.due_on, today: m.today };
  }

  async function markPaid(client, actor, id, reason) {
    await events.setContext(client, actor, reason);
    await client.query(`UPDATE invoice SET status_code = 'PAID' WHERE invoice_id = $1`, [id]);
  }

  async function record(actor, invoiceId, input, { idempotencyKey } = {}) {
    const amountMinor = whole(input.amountMinor, { name: 'amountMinor', min: 1, max: MAX_AMOUNT, reason: 'bad_amount' });
    const method = text(input.method, { name: 'method', max: 30, reason: 'bad_method' });
    const reference = text(input.reference, { name: 'reference', max: 100, optional: true });
    const receivedOn = isoDate(input.receivedOn, { name: 'receivedOn', optional: true });
    if (!isUuid(invoiceId)) throw refuse('No such invoice.', 'not_found', {}, 404);
    return idempotency.run({ scope: `payment.record:${invoiceId}`, key: idempotencyKey, actor, body: input }, async client => {
      const inv = await invoices.lock(client, invoiceId);
      if (inv.status_code === 'PAID') throw refuse('This invoice is already paid in full.', 'already_paid', {}, 409);
      if (!PAYABLE.includes(inv.status_code)) throw refuse('Payments can only be recorded against an issued invoice.', 'invoice_not_payable', { status: inv.status_code }, 409);
      const methods = (await client.query('SELECT method_code FROM payment_method')).rows.map(r => r.method_code);
      if (!methods.includes(method)) throw refuse(`method must be one of ${methods.join(', ')}.`, 'bad_method', { methods });
      const m = await money(client, invoiceId);
      if (receivedOn && receivedOn > m.today) throw refuse('A payment cannot be received in the future.', 'received_in_future');
      const balance = m.total - m.credited - m.paid;
      if (BigInt(amountMinor) > balance) throw refuse('That is more than the amount still owed.', 'payment_exceeds_balance', { balanceMinor: Number(balance) }, 409);
      const paymentId = uuidv7();
      const { rows: [p] } = await client.query(
        `INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, reference, received_on, recorded_by_user_id) VALUES ($1, $2, $3, $4, $5, COALESCE($6::date, CURRENT_DATE), $7)
         RETURNING receipt_number, receipt_issued_on, received_on`, [paymentId, invoiceId, amountMinor, method, reference ?? null, receivedOn ?? null, actor.userId]);
      if (BigInt(amountMinor) === balance) await markPaid(client, actor, invoiceId, `Paid in full (receipt ${p.receipt_number})`);
      await events.record(client, { invoiceId, actor, action: 'payment.record', detail: { paymentId, receiptNumber: p.receipt_number, amountMinor, method } });
      return { status: 201, body: {
        payment: { paymentId, amountMinor, method, reference: reference ?? null, receivedOn: p.received_on, receiptNumber: p.receipt_number, receiptIssuedOn: p.receipt_issued_on },
        invoice: await invoices.read(client, invoiceId) } };
    });
  }

  async function voidPayment(actor, invoiceId, paymentId, input) {
    const reason = invoices.reasonOf(input);
    return tx(db, async client => {
      const inv = await invoices.lock(client, invoiceId);
      if (!isUuid(paymentId)) throw refuse('No such payment.', 'not_found', {}, 404);
      const { rows: [p] } = await client.query('SELECT payment_id, amount_minor, method_code, receipt_number FROM payment WHERE payment_id = $1 AND invoice_id = $2', [paymentId, invoiceId]);
      if (!p || BigInt(p.amount_minor) <= 0n) throw refuse('No such payment.', 'not_found', {}, 404);
      if ((await client.query('SELECT 1 FROM payment WHERE reverses_payment_id = $1', [paymentId])).rowCount) throw refuse('That payment was already voided.', 'already_voided', {}, 409);
      await client.query(
        `INSERT INTO payment (payment_id, invoice_id, amount_minor, method_code, received_on, recorded_by_user_id, reverses_payment_id, void_reason) VALUES ($1, $2, $3, $4, CURRENT_DATE, $5, $6, $7)`,
        [uuidv7(), invoiceId, (-BigInt(p.amount_minor)).toString(), p.method_code, actor.userId, paymentId, reason]);
      if (inv.status_code === 'PAID') {
        const m = await money(client, invoiceId);
        if (m.paid + m.credited < m.total) {
          await events.setContext(client, actor, `Payment ${p.receipt_number} voided: ${reason}`);
          await client.query('UPDATE invoice SET status_code = $2 WHERE invoice_id = $1', [invoiceId, m.dueOn < m.today ? 'OVERDUE' : 'SENT']);
        }
      }
      await events.record(client, { invoiceId, actor, action: 'payment.void', reason, detail: { paymentId, receiptNumber: p.receipt_number } });
      return { invoice: await invoices.read(client, invoiceId) };
    });
  }

  async function creditNote(actor, invoiceId, input) {
    const amountMinor = whole(input.amountMinor, { name: 'amountMinor', min: 1, max: MAX_AMOUNT, reason: 'bad_amount' });
    const reason = invoices.reasonOf(input);
    return tx(db, async client => {
      const inv = await invoices.lock(client, invoiceId);
      if (!['ISSUED', 'SENT', 'OVERDUE', 'PAID'].includes(inv.status_code)) throw refuse('A credit note can only be raised against an issued invoice.', 'invoice_not_payable', { status: inv.status_code }, 409);
      const m = await money(client, invoiceId);
      if (m.paid === 0n && m.credited + BigInt(amountMinor) >= m.total) throw refuse('That would credit the whole invoice. Void it instead.', 'use_void', {}, 409);
      const id = uuidv7();
      const { rows: [c] } = await client.query(
        `INSERT INTO credit_note (credit_note_id, invoice_id, amount_minor, reason, created_by_user_id) VALUES ($1, $2, $3, $4, $5) RETURNING credit_note_number, issued_on`, [id, invoiceId, amountMinor, reason, actor.userId]);
      const after = await money(client, invoiceId);
      if (inv.status_code !== 'PAID' && after.paid + after.credited >= after.total) await markPaid(client, actor, invoiceId, `Settled by credit note ${c.credit_note_number}`);
      await events.record(client, { invoiceId, actor, action: 'credit_note.create', reason, detail: { creditNoteId: id, creditNoteNumber: c.credit_note_number, amountMinor } });
      return { creditNote: { creditNoteId: id, creditNoteNumber: c.credit_note_number, amountMinor, reason, issuedOn: c.issued_on }, invoice: await invoices.read(client, invoiceId) };
    });
  }

  return { record, voidPayment, creditNote };
}

module.exports = { createPayments };
