'use strict';
const crypto = require('node:crypto');

/**
 * Keyed one-way hashes for values that must be findable but never readable: licence keys, email addresses, machine ids for the
 * block list, one-time codes. HMAC-SHA-256 with a server secret (BILLING_HASH_PEPPER), so a copy of the database alone reveals none of
 * them. The purpose is part of the input, so the same text hashed for two purposes gives two unrelated results.
 */
function createHasher(pepper) {
  if (typeof pepper !== 'string' || pepper.length < 32) throw new Error('BILLING_HASH_PEPPER must be at least 32 characters.');
  return (purpose, value) => crypto.createHmac('sha256', pepper).update(`${purpose}\u0000${value}`).digest('hex');
}

/** A licence key as people type it: spaces trimmed, upper-case. */
const normaliseKey = value => (typeof value === 'string' ? value.trim().toUpperCase() : '');

const safeEqualHex = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));

module.exports = { createHasher, normaliseKey, safeEqualHex };
