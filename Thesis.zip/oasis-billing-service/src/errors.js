'use strict';
const { logPath } = require('./log-path');

/** A refusal the person can be told about: 4xx, a customer-facing message, and a machine-readable reason. */
class ApiError extends Error {
  constructor(status, message, reason, extra = {}) {
    super(message);
    this.status = status;
    this.reason = reason;
    this.extra = extra;
  }
}

const refuse = (message, reason, extra, status = 400) => new ApiError(status, message, reason, extra);

/**
 * A rule the database enforces (a check, the allowed status moves, the payment limit, a unique number) must read as a plain refusal, never a 500.
 * The messages the triggers raise are written for people and are passed on; a bare constraint name is not, so it gets a generic sentence.
 */
function asRefusal(err) {
  if (!err || typeof err.code !== 'string' || err instanceof ApiError) return err;
  if (err.code === '23514' || err.code === '23001') return refuse(err.constraint ? 'That change breaks a billing rule.' : err.message, 'rule_violation', {}, 409);
  if (err.code === '23505') return refuse('That already exists.', 'conflict', {}, 409);
  if (err.code === '23503') return refuse('That refers to something that does not exist.', 'bad_reference');
  if (err.code === '22003') return refuse('That number is too large.', 'number_too_large');
  return err;
}

/**
 * Every route handler is wrapped so a thrown error ends here. An ApiError is a business refusal (4xx). Anything else is OUR
 * fault: it is logged without the request body (which may hold an email address) and answered as 500, so the app treats it as
 * an outage rather than a refusal and nobody is locked out by a bug on this side.
 */
function errorHandler(log) {
  return (err, req, res, _next) => {
    err = asRefusal(err);
    if (err instanceof ApiError) {
      return res.status(err.status).json({ error: 'rejected', message: err.message, reason: err.reason, requestId: req.id, ...err.extra });
    }
    if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'rejected', message: 'That request is too large.', reason: 'too_large', requestId: req.id });
    if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'rejected', message: 'The request was not valid JSON.', reason: 'bad_json', requestId: req.id });
    if (err && Number.isInteger(err.status) && err.status >= 400 && err.status < 500 && err.expose) return res.status(400).json({ error: 'rejected', message: 'The request could not be read.', reason: 'bad_request', requestId: req.id });
    log({ level: 'error', requestId: req.id, path: logPath(req), error: err && err.name, code: err && err.code });     // never the message: it can carry a host address or a value
    res.status(500).json({ error: 'internal', message: 'Something went wrong on our side. Please try again later.', requestId: req.id });
  };
}

const wrap = handler => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

module.exports = { ApiError, refuse, errorHandler, wrap, asRefusal };
