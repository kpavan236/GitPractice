'use strict';
const { refuse } = require('./errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const CONTROL = /[\u0000-\u001f\u007f]/g;

const isUuid = v => typeof v === 'string' && UUID.test(v);
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});

/** Text typed by a person: control characters become spaces and the ends are trimmed. Returns undefined when it is absent and optional. */
function text(value, { name, min = 1, max, optional = false, reason = 'bad_field' }) {
  if (value === undefined || value === null || value === '') {
    if (optional) return undefined;
    throw refuse(`${name} is required.`, reason);
  }
  if (typeof value !== 'string') throw refuse(`${name} must be text.`, reason);
  const v = value.replace(CONTROL, ' ').trim();
  if (v.length < min || v.length > max) throw refuse(`${name} must be from ${min} to ${max} characters.`, reason);
  return v;
}

/** A whole number that is a real JavaScript number (not a string, not a float) inside the range. */
function whole(value, { name, min, max, reason = 'bad_field' }) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < min || value > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, reason);
  return value;
}

/** A calendar date as 2026-10-31, and a real one (no 2026-02-30). */
function isoDate(value, { name, optional = false, reason = 'bad_date' }) {
  if (value === undefined || value === null || value === '') {
    if (optional) return undefined;
    throw refuse(`${name} is required.`, reason);
  }
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw refuse(`${name} must be a date like 2026-10-31.`, reason);
  const d = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== value || d.getUTCFullYear() < 2000 || d.getUTCFullYear() > 2999) throw refuse(`${name} is not a real date.`, reason);
  return value;
}

module.exports = { UUID, isUuid, bodyOf, text, whole, isoDate };
