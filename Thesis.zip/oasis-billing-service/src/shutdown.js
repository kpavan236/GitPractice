'use strict';

/**
 * Builds the shutdown function: stop accepting, drop idle connections, let in-flight requests finish, end the database pools, exit.
 * If requests have not drained by `timeoutMs`, the remaining connections are closed and the exit code is 1. A second signal is ignored.
 * `exit` and `log` are passed in so tests can call it without ending the process.
 */
function createShutdown({ server, pools, timeoutMs, exit = process.exit, log = line => console.log(JSON.stringify(line)) }) {
  let running = null;
  return function shutdown(signal) {
    if (running) return running;
    log({ level: 'info', msg: 'shutting down', signal });
    running = (async () => {
      let timer;
      const drained = new Promise(resolve => { server.close(() => resolve(true)); });
      server.closeIdleConnections();
      const timedOut = new Promise(resolve => { timer = setTimeout(() => resolve(false), timeoutMs); });
      const clean = await Promise.race([drained, timedOut]);
      clearTimeout(timer);
      if (!clean) { log({ level: 'warn', msg: 'shutdown timed out; closing remaining connections' }); server.closeAllConnections(); }
      await Promise.all(pools.map(p => p.end().catch(() => {})));
      exit(clean ? 0 : 1);
    })();
    return running;
  };
}

module.exports = { createShutdown };
