'use strict';
// The nightly job: node src/mark-overdue.js (needs BILLING_DATABASE_URL). It prints how many invoices moved and nothing else. It is documented but NOT scheduled by this repository.
const { createPool } = require('./db');
const { markOverdue } = require('./overdue');

(async () => {
  if (!process.env.BILLING_DATABASE_URL) throw new Error('BILLING_DATABASE_URL is required.');
  const db = createPool(process.env.BILLING_DATABASE_URL);
  try { console.log(JSON.stringify({ marked: await markOverdue(db) })); } finally { await db.end(); }
})().catch(err => { console.error(JSON.stringify({ level: 'fatal', error: err.code || err.name })); process.exit(1); });
