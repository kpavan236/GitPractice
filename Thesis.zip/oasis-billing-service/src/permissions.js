'use strict';
const { refuse, wrap } = require('./errors');

/** Who may do what is the action_role table, read on every call, so a rule changes with an INSERT. An action no role holds is refused. */
function createPermissions({ db }) {
  const can = async (role, action) => (await db.query('SELECT 1 FROM action_role WHERE action = $1 AND role_code = $2', [action, role])).rowCount > 0;
  const needs = action => wrap(async (req, _res, next) => {
    if (!(await can(req.actor.role, action))) throw refuse('You do not have permission to do that.', 'forbidden', {}, 403);
    next();
  });
  return { can, needs };
}

module.exports = { createPermissions };
