'use strict';

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Reads and checks the settings once, at start-up. A missing or malformed setting stops the service with a clear message. */
function loadConfig(env = process.env) {
  const need = name => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  const secret = name => { const v = need(name); if (v.length < 32) throw new Error(`${name} must be at least 32 characters.`); return v; };
  const production = env.NODE_ENV === 'production';

  const tlsCertFile = env.TLS_CERT_FILE || '', tlsKeyFile = env.TLS_KEY_FILE || '';
  if (Boolean(tlsCertFile) !== Boolean(tlsKeyFile)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together.');
  const tls = Boolean(tlsCertFile);
  if (env.ALLOW_PLAIN_HTTP !== undefined && !['', '0', '1'].includes(env.ALLOW_PLAIN_HTTP)) throw new Error('ALLOW_PLAIN_HTTP must be 1 or 0.');
  if (production && !tls && env.ALLOW_PLAIN_HTTP !== '1') throw new Error('Production needs TLS_CERT_FILE and TLS_KEY_FILE, or ALLOW_PLAIN_HTTP=1 when the hosting platform ends TLS.');

  const port = whole(env, 'PORT', { min: 1, max: 65535, fallback: 4060 });
  const publicBaseUrl = env.PUBLIC_BASE_URL || (production ? '' : `${tls ? 'https' : 'http'}://127.0.0.1:${port}`);
  if (!publicBaseUrl) throw new Error('PUBLIC_BASE_URL is required in production: the address customers open invoice links at.');
  let parsed;
  try { parsed = new URL(publicBaseUrl); } catch { throw new Error('PUBLIC_BASE_URL must be a web address such as https://billing.example.test.'); }
  if (!['https:', 'http:'].includes(parsed.protocol) || parsed.search || parsed.hash || parsed.username) throw new Error('PUBLIC_BASE_URL must be a plain web address: no query, fragment or login.');
  if (production && parsed.protocol !== 'https:') throw new Error('PUBLIC_BASE_URL must be https in production.');

  const notifier = env.NOTIFIER || 'fake';
  if (notifier !== 'fake') throw new Error('NOTIFIER must be "fake": no email provider has been approved yet (IT Helpdesk, cainc.service-now.com).');
  if (production) throw new Error('Production needs an approved email sender; the fake one would never deliver an invoice link.');

  const currency = (env.BILLING_CURRENCY || 'INR').toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error('BILLING_CURRENCY must be a three-letter currency code such as INR.');

  return {
    port, tls, tlsCertFile, tlsKeyFile, notifier, currency,
    publicBaseUrl: publicBaseUrl.replace(/\/$/, ''),
    databaseUrl: need('BILLING_DATABASE_URL'),
    serviceKey: secret('BILLING_SERVICE_KEY'),
    hashPepper: secret('BILLING_HASH_PEPPER'),
    shareLinkDefaultDays: whole(env, 'SHARE_LINK_DEFAULT_DAYS', { min: 1, max: 365, fallback: 14 }),
    shutdownTimeoutMs: whole(env, 'SHUTDOWN_TIMEOUT_MS', { min: 100, max: 300000, fallback: 10000 }),
  };
}

module.exports = { loadConfig };
