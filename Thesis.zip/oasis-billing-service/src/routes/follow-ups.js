'use strict';
const express = require('express');
const { wrap } = require('../errors');
const { bodyOf } = require('../validate');

function followUpRoutes({ owner, followUps, permissions }) {
  const router = express.Router();
  const one = (req, name) => (typeof req.query[name] === 'string' ? req.query[name] : undefined);

  router.post('/invoices/:id/owner', permissions.needs('owner.change'), wrap(async (req, res) => res.json(await owner.change(req.actor, req.params.id, bodyOf(req)))));

  router.post('/invoices/:id/follow-ups', permissions.needs('followup.log'), wrap(async (req, res) => {
    const out = await followUps.log(req.actor, req.params.id, bodyOf(req));
    res.status(out.status).json({ followUp: out.followUp, invoice: out.invoice });
  }));

  router.get('/follow-ups/queue', permissions.needs('invoice.read'), wrap(async (req, res) => res.json(await followUps.queue({ ownerId: one(req, 'ownerId') }))));
  router.get('/follow-ups/summary', permissions.needs('invoice.read'), wrap(async (req, res) => res.json(await followUps.summary({ ownerId: one(req, 'ownerId') }))));
  return router;
}

module.exports = { followUpRoutes };
