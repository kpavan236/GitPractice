'use strict';
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const { wrap } = require('../errors');
const { invoicePage, invalidPage } = require('../public-page');

const CSS = fs.readFileSync(path.join(__dirname, '..', 'public', 'invoice.css'), 'utf8');
const INVALID = invalidPage();         // one fixed page, so every invalid link gets byte-identical bytes

/**
 * The customer's side: GET /i/<token>, no login, no cookies, read-only. The token is read from the raw address (not decoded by the router), so a malformed one
 * cannot produce a different answer from an unknown one. A strict content policy: no scripts, only this site's own stylesheet.
 */
function publicRoutes({ shareLinks, publicLimiter }) {
  const router = express.Router();
  const headers = (res, type) => res.set({
    'Content-Type': type,
    'Content-Security-Policy': "default-src 'none'; style-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    'X-Frame-Options': 'DENY', 'X-Robots-Tag': 'noindex, nofollow, noarchive', 'Cache-Control': 'no-store',
  });

  router.get('/i-static/invoice.css', (_req, res) => { res.set({ 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' }); res.send(CSS); });

  router.use('/i', publicLimiter, wrap(async (req, res, next) => {
    if (req.method !== 'GET') return next();       // HEAD is not served, so it can never count a view
    const token = req.originalUrl.split('?')[0].replace(/^\/i\/?/i, '');
    const data = token.includes('/') ? null : await shareLinks.view(token);
    headers(res, 'text/html; charset=utf-8');
    if (!data) return res.status(404).send(INVALID);
    res.send(invoicePage(data));
  }));
  return router;
}

module.exports = { publicRoutes };
