'use strict';
const express = require('express');
const { wrap } = require('../errors');
const { bodyOf } = require('../validate');

function shareLinkRoutes({ shareLinks, permissions }) {
  const router = express.Router();
  router.post('/invoices/:id/links', permissions.needs('link.manage'), wrap(async (req, res) => {
    const out = await shareLinks.create(req.actor, req.params.id, bodyOf(req));
    res.status(out.status).json(out.body);
  }));
  router.post('/invoices/:id/links/:linkId/revoke', permissions.needs('link.manage'), wrap(async (req, res) => res.json(await shareLinks.revoke(req.actor, req.params.id, req.params.linkId))));
  return router;
}

module.exports = { shareLinkRoutes };
