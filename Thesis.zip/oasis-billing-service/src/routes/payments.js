'use strict';
const express = require('express');
const { wrap } = require('../errors');
const { bodyOf } = require('../validate');

function paymentRoutes({ payments, permissions }) {
  const router = express.Router();

  router.post('/invoices/:id/payments', permissions.needs('payment.record'), wrap(async (req, res) => {
    const out = await payments.record(req.actor, req.params.id, bodyOf(req), { idempotencyKey: req.get('Idempotency-Key') });
    if (out.replayed) res.set('Idempotent-Replayed', 'true');
    res.status(out.status).json(out.body);
  }));

  router.post('/invoices/:id/payments/:paymentId/void', permissions.needs('payment.void'), wrap(async (req, res) => {
    res.json(await payments.voidPayment(req.actor, req.params.id, req.params.paymentId, bodyOf(req)));
  }));

  router.post('/invoices/:id/credit-notes', permissions.needs('credit_note.create'), wrap(async (req, res) => {
    res.status(201).json(await payments.creditNote(req.actor, req.params.id, bodyOf(req)));
  }));

  return router;
}

module.exports = { paymentRoutes };
