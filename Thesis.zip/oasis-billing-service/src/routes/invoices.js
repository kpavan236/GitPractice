'use strict';
const express = require('express');
const { wrap } = require('../errors');
const { bodyOf } = require('../validate');

/** One explicit handler per route. The permission is the first thing every route checks (read from action_role). */
function invoiceRoutes({ invoices, permissions }) {
  const router = express.Router();

  router.post('/invoices', permissions.needs('invoice.draft'), wrap(async (req, res) => {
    const out = await invoices.create(req.actor, bodyOf(req), { idempotencyKey: req.get('Idempotency-Key') });
    if (out.replayed) res.set('Idempotent-Replayed', 'true');
    res.status(out.status).json(out.body);
  }));

  router.get('/invoices', permissions.needs('invoice.read'), wrap(async (req, res) => {
    res.json(await invoices.list(req.query));
  }));

  router.get('/invoices/:id', permissions.needs('invoice.read'), wrap(async (req, res) => {
    res.json(await invoices.get(req.params.id));
  }));

  router.patch('/invoices/:id', permissions.needs('invoice.draft'), wrap(async (req, res) => {
    res.json(await invoices.updateDraft(req.actor, req.params.id, bodyOf(req)));
  }));

  router.post('/invoices/:id/cancel', permissions.needs('invoice.cancel_draft'), wrap(async (req, res) => {
    res.json(await invoices.cancelDraft(req.actor, req.params.id, bodyOf(req)));
  }));

  return router;
}

module.exports = { invoiceRoutes };
