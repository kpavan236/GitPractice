'use strict';
const express = require('express');
const { wrap } = require('../errors');
const { bodyOf } = require('../validate');

function lifecycleRoutes({ lifecycle, permissions }) {
  const router = express.Router();
  router.post('/invoices/:id/issue', permissions.needs('invoice.issue'), wrap(async (req, res) => res.json(await lifecycle.issue(req.actor, req.params.id, bodyOf(req)))));
  router.post('/invoices/:id/mark-sent', permissions.needs('invoice.mark_sent'), wrap(async (req, res) => res.json(await lifecycle.markSent(req.actor, req.params.id, bodyOf(req)))));
  router.post('/invoices/:id/void', permissions.needs('invoice.void'), wrap(async (req, res) => res.json(await lifecycle.void(req.actor, req.params.id, bodyOf(req)))));
  return router;
}

module.exports = { lifecycleRoutes };
