'use strict';
const express = require('express');
const { wrap } = require('../errors');

function reportRoutes({ reports, permissions }) {
  const router = express.Router();
  router.get('/reports/dashboard', permissions.needs('report.read'), wrap(async (_req, res) => res.json(await reports.dashboard())));
  router.get('/reports/export', permissions.needs('report.read'), wrap(async (req, res) => res.json(await reports.exportRows(req.query))));
  return router;
}

module.exports = { reportRoutes };
