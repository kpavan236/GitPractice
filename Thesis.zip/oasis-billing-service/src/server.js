'use strict';
const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const { createShutdown } = require('./shutdown');
const { loadConfig } = require('./config');
const { createPool } = require('./db');
const { createApp } = require('./app');
const { createFakeNotifier } = require('./notifier');

async function main() {
  const config = loadConfig();
  const db = createPool(config.databaseUrl);
  const tls = config.tls ? { cert: fs.readFileSync(config.tlsCertFile), key: fs.readFileSync(config.tlsKeyFile) } : null;
  const app = createApp({ db, serviceKey: config.serviceKey, hashPepper: config.hashPepper, currency: config.currency, shareLinkDefaultDays: config.shareLinkDefaultDays,
    publicBaseUrl: config.publicBaseUrl, notifier: createFakeNotifier(), hsts: Boolean(tls) });
  const server = tls ? https.createServer(tls, app) : http.createServer(app);
  server.listen(config.port, () => console.log(JSON.stringify({ level: 'info', msg: 'listening', port: config.port, tls: Boolean(tls) })));
  const stop = createShutdown({ server, pools: [db], timeoutMs: config.shutdownTimeoutMs });
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch(err => { console.error(JSON.stringify({ level: 'fatal', error: err.message })); process.exit(1); });
