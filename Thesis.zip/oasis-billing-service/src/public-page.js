'use strict';

const esc = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
/** Minor units to a money string. Every currency this service accepts has two minor digits. */
const money = (minor, currency) => new Intl.NumberFormat('en-IN', { style: 'currency', currency, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(minor) / 100);
const STATUS = { ISSUED: 'Awaiting payment', SENT: 'Awaiting payment', OVERDUE: 'Overdue', PAID: 'Paid', VOID: 'Void' };

const shell = (title, body) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title>${esc(title)}</title>
<link rel="stylesheet" href="/i-static/invoice.css">
</head>
<body>
<main>
${body}
</main>
</body>
</html>
`;

/** The page for every link that does not work: unknown, expired and revoked look exactly the same, so nothing can be learned by trying. It holds nothing that varies. */
const invalidPage = () => shell('Link no longer valid', `<h1>This link is no longer valid</h1>
<p>The invoice link you opened has expired or was withdrawn. Please contact the person who sent it to you for a new link.</p>`);

function invoicePage({ invoice: i, billTo: b, lines, receipts, credits }) {
  const c = i.currency_code;
  const m = v => esc(money(v, c));
  const address = b ? [b.name, b.line1, b.line2, [b.city, b.state_province, b.postal_code].filter(Boolean).join(', '), b.country_code].filter(Boolean).map(esc).join('<br>') : '';
  const rows = lines.map(l => `<tr><td>${esc(l.description)}</td><td class="num">${esc(l.quantity)}</td><td class="num">${m(l.unit_price_minor)}</td><td class="num">${m(l.amount_minor)}</td></tr>`).join('\n');
  const receiptRows = receipts.map(r => `<tr><td>${esc(r.receipt_number)}</td><td>${esc(r.received_on)}</td><td>${esc(r.method)}</td><td class="num">${m(r.amount_minor)}</td></tr>`).join('\n');
  const creditRows = credits.map(r => `<tr><td>${esc(r.credit_note_number)}</td><td>${esc(r.issued_on)}</td><td class="num">-${m(r.amount_minor)}</td></tr>`).join('\n');
  const settled = Number(i.balance_minor) <= 0 && i.effective_status === 'PAID';
  return shell(`Invoice ${i.invoice_number}`, `<h1>Invoice ${esc(i.invoice_number)}</h1>
<p class="status status-${esc(i.effective_status.toLowerCase())}">${esc(STATUS[i.effective_status] || i.effective_status)}</p>
<dl class="dates"><dt>Issued</dt><dd>${esc(i.issued_on)}</dd><dt>Due</dt><dd>${esc(i.due_on)}</dd></dl>
<h2>Bill to</h2>
<p>${address}</p>
<table>
<caption>Items</caption>
<thead><tr><th scope="col">Description</th><th scope="col" class="num">Quantity</th><th scope="col" class="num">Unit price</th><th scope="col" class="num">Amount</th></tr></thead>
<tbody>
${rows}
</tbody>
</table>
<table class="totals">
<tbody>
<tr><th scope="row">Charges</th><td class="num">${m(i.subtotal_minor)}</td></tr>
${Number(i.discount_minor) > 0 ? `<tr><th scope="row">Discounts</th><td class="num">-${m(i.discount_minor)}</td></tr>` : ''}
<tr><th scope="row">Total</th><td class="num">${m(i.total_minor)}</td></tr>
${Number(i.credited_minor) > 0 ? `<tr><th scope="row">Credit notes</th><td class="num">-${m(i.credited_minor)}</td></tr>` : ''}
${Number(i.paid_minor) > 0 ? `<tr><th scope="row">Paid</th><td class="num">-${m(i.paid_minor)}</td></tr>` : ''}
<tr class="due"><th scope="row">${settled ? 'Paid in full' : 'Amount due'}</th><td class="num">${m(Math.max(Number(i.balance_minor), 0))}</td></tr>
</tbody>
</table>
${receipts.length ? `<h2>Receipts</h2>
<table>
<thead><tr><th scope="col">Receipt</th><th scope="col">Received</th><th scope="col">Method</th><th scope="col" class="num">Amount</th></tr></thead>
<tbody>
${receiptRows}
</tbody>
</table>` : ''}
${credits.length ? `<h2>Credit notes</h2>
<table>
<thead><tr><th scope="col">Credit note</th><th scope="col">Issued</th><th scope="col" class="num">Amount</th></tr></thead>
<tbody>
${creditRows}
</tbody>
</table>` : ''}`);
}

module.exports = { invoicePage, invalidPage, esc, money };
