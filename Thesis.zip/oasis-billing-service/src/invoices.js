'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { text, whole, isoDate, isUuid } = require('./validate');

const MAX_LINES = 50;
// With these caps one line is at most 10,000 x 10,000,000,000 = 10^14 and 50 lines at most 5 x 10^15, under 2^53 (9.007 x 10^15): sums and totals are exact as JavaScript numbers.
const MAX_QUANTITY = 10_000;
const MAX_UNIT_MINOR = 10_000_000_000;
const STATUSES = ['DRAFT', 'ISSUED', 'SENT', 'PAID', 'OVERDUE', 'VOID', 'CANCELLED'];

const notFound = () => refuse('No such invoice.', 'not_found', {}, 404);
const num = v => (v === null || v === undefined ? null : Number(v));
const reasonOf = body => text(body && body.reason, { name: 'A reason', max: 500, reason: 'reason_required' });

function lineOf(raw, i) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw refuse(`Line ${i + 1} is not valid.`, 'bad_line');
  const description = text(raw.description, { name: `Line ${i + 1} description`, max: 200, reason: 'bad_line' });
  const q = typeof raw.quantity === 'number' ? String(raw.quantity) : raw.quantity;
  if (typeof q !== 'string' || !/^\d{1,5}(\.\d{1,3})?$/.test(q) || Number(q) <= 0 || Number(q) > MAX_QUANTITY) throw refuse(`Line ${i + 1} quantity must be more than 0, at most ${MAX_QUANTITY}, with up to 3 decimals.`, 'bad_line');
  const unitPriceMinor = whole(raw.unitPriceMinor, { name: `Line ${i + 1} unitPriceMinor`, min: -MAX_UNIT_MINOR, max: MAX_UNIT_MINOR, reason: 'bad_line' });
  return { description, quantity: q, unitPriceMinor };
}

function linesOf(lines) {
  if (!Array.isArray(lines) || lines.length < 1 || lines.length > MAX_LINES) throw refuse(`Give from 1 to ${MAX_LINES} lines.`, 'lines_required');
  return lines.map(lineOf);
}

function billToOf(b) {
  if (!b || typeof b !== 'object' || Array.isArray(b)) throw refuse('Bill-to details are required.', 'bill_to_required');
  const t = (value, name, max, optional = false) => text(value, { name: `Bill-to ${name}`, max, optional, reason: 'bad_bill_to' });
  const country = typeof b.countryCode === 'string' ? b.countryCode.toUpperCase() : '';
  if (!/^[A-Z]{2}$/.test(country)) throw refuse('Bill-to countryCode must be two letters, such as IN.', 'bad_bill_to');
  return { name: t(b.name, 'name', 200), line1: t(b.line1, 'line1', 200), line2: t(b.line2, 'line2', 200, true), city: t(b.city, 'city', 100),
    stateProvince: t(b.stateProvince, 'stateProvince', 100, true), postalCode: t(b.postalCode, 'postalCode', 20, true), taxId: t(b.taxId, 'taxId', 50, true), countryCode: country };
}

function shape(r) {
  return {
    invoiceId: r.invoice_id, invoiceNumber: r.invoice_number, status: r.status_code, effectiveStatus: r.effective_status, isOverdue: r.is_overdue,
    customerId: r.customer_id, billToName: r.bill_to_name, currency: r.currency_code, ownerUserId: r.owner_user_id, createdByUserId: r.created_by_user_id,
    sourcePurchaseRequestId: r.source_purchase_request_id, issuedOn: r.issued_on, dueOn: r.due_on,
    subtotalMinor: num(r.subtotal_minor), discountMinor: num(r.discount_minor), taxMinor: num(r.tax_minor), totalMinor: num(r.total_minor),
    paidMinor: num(r.paid_minor), creditedMinor: num(r.credited_minor), balanceMinor: (r.status_code === 'VOID' || r.status_code === 'CANCELLED') ? 0 : num(r.balance_minor),
    closedAt: r.closed_at, notes: r.notes, createdAt: r.created_at, statusChangedAt: r.status_changed_at, lastFollowUpAt: r.last_follow_up_at,
    nextFollowUpOn: r.next_follow_up_on, followUpCount: num(r.follow_up_count), agingBucket: r.aging_bucket, followUpHealth: r.follow_up_health,
  };
}

function createInvoices({ db, events, idempotency, currency }) {
  async function read(client, id) {
    const { rows: [r] } = await client.query('SELECT * FROM v_invoice_state WHERE invoice_id = $1', [id]);
    return r ? shape(r) : null;
  }

  /** Locks the invoice row for this transaction (so two changes to one invoice queue) and returns it. 404 if there is none. */
  async function lock(client, id) {
    if (!isUuid(id)) throw notFound();
    const { rows: [r] } = await client.query('SELECT * FROM invoice WHERE invoice_id = $1 FOR UPDATE', [id]);
    if (!r) throw notFound();
    return r;
  }

  async function writeBillTo(client, id, b) {
    await client.query(
      `INSERT INTO invoice_bill_to (invoice_id, name, line1, line2, city, state_province, postal_code, country_code, tax_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (invoice_id) DO UPDATE SET name = EXCLUDED.name, line1 = EXCLUDED.line1, line2 = EXCLUDED.line2, city = EXCLUDED.city,
         state_province = EXCLUDED.state_province, postal_code = EXCLUDED.postal_code, country_code = EXCLUDED.country_code, tax_id = EXCLUDED.tax_id`,
      [id, b.name, b.line1, b.line2 ?? null, b.city, b.stateProvince ?? null, b.postalCode ?? null, b.countryCode, b.taxId ?? null]);
  }

  /** Each line's amount is computed by the database (round half away from zero), so the page, the totals and the checks can never disagree. */
  async function writeLines(client, id, lines) {
    await client.query('DELETE FROM invoice_line WHERE invoice_id = $1', [id]);
    for (const [i, l] of lines.entries()) {
      await client.query(
        `INSERT INTO invoice_line (line_id, invoice_id, line_no, description, quantity, unit_price_minor, amount_minor) VALUES ($1, $2, $3, $4, $5::numeric, $6::bigint, round($5::numeric * $6::bigint))`,
        [uuidv7(), id, i + 1, l.description, l.quantity, l.unitPriceMinor]);
    }
    const { rows: [s] } = await client.query(
      `SELECT COALESCE(sum(amount_minor) FILTER (WHERE amount_minor > 0), 0) AS charges, COALESCE(-sum(amount_minor) FILTER (WHERE amount_minor < 0), 0) AS discounts FROM invoice_line WHERE invoice_id = $1`, [id]);
    if (BigInt(s.discounts) > BigInt(s.charges)) throw refuse('The discounts are larger than the charges.', 'discount_exceeds_charges');
    await client.query('UPDATE invoice SET subtotal_minor = $2::bigint, discount_minor = $3::bigint, total_minor = $2::bigint - $3::bigint WHERE invoice_id = $1', [id, s.charges, s.discounts]);
  }

  async function create(actor, input, { idempotencyKey } = {}) {
    if (!isUuid(input.customerId)) throw refuse('customerId must be a customer id.', 'bad_customer');
    if (input.sourcePurchaseRequestId !== undefined && input.sourcePurchaseRequestId !== null && !isUuid(input.sourcePurchaseRequestId)) throw refuse('sourcePurchaseRequestId must be an id.', 'bad_source');
    const lines = linesOf(input.lines);
    const billTo = billToOf(input.billTo);
    const dueOn = isoDate(input.dueOn, { name: 'dueOn', optional: true });
    const notes = text(input.notes, { name: 'notes', max: 1000, optional: true });
    return idempotency.run({ scope: 'invoice.create', key: idempotencyKey, actor, body: input }, async client => {
      const id = uuidv7();
      await events.setContext(client, actor, 'Invoice created');
      await client.query(
        `INSERT INTO invoice (invoice_id, customer_id, currency_code, owner_user_id, created_by_user_id, source_purchase_request_id, due_on, notes) VALUES ($1, $2, $3, $4, $4, $5, $6, $7)`,
        [id, input.customerId, currency, actor.userId, input.sourcePurchaseRequestId ?? null, dueOn ?? null, notes ?? null]);
      await writeBillTo(client, id, billTo);
      await writeLines(client, id, lines);
      await events.record(client, { invoiceId: id, actor, action: 'invoice.create', detail: { lines: lines.length, fromRequest: Boolean(input.sourcePurchaseRequestId) } });
      return { status: 201, body: { invoice: await read(client, id) } };
    });
  }

  async function get(id) {
    if (!isUuid(id)) throw notFound();
    const { rows: [row] } = await db.query('SELECT * FROM v_invoice_state WHERE invoice_id = $1', [id]);
    if (!row) throw notFound();
    const q = (sql, params = [id]) => db.query(sql, params).then(r => r.rows);
    const [billTo, lines, history, payments, credits, followUps, links, owners, activity] = await Promise.all([
      q('SELECT name, line1, line2, city, state_province, postal_code, country_code, tax_id FROM invoice_bill_to WHERE invoice_id = $1'),
      q('SELECT line_no, description, quantity, unit_price_minor, amount_minor FROM invoice_line WHERE invoice_id = $1 ORDER BY line_no'),
      q('SELECT from_status_code, to_status_code, changed_at, changed_by_user_id, reason FROM invoice_status_history WHERE invoice_id = $1 ORDER BY changed_at, history_id'),
      q(`SELECT p.payment_id, p.amount_minor, p.method_code, p.reference, p.received_on, p.receipt_number, p.receipt_issued_on, p.recorded_by_user_id, p.recorded_at, p.reverses_payment_id, p.void_reason,
                EXISTS (SELECT 1 FROM payment r WHERE r.reverses_payment_id = p.payment_id) AS is_voided FROM payment p WHERE p.invoice_id = $1 ORDER BY p.recorded_at, p.payment_id`),
      q('SELECT credit_note_id, credit_note_number, amount_minor, reason, issued_on, created_by_user_id FROM credit_note WHERE invoice_id = $1 ORDER BY created_at'),
      q('SELECT follow_up_id, by_user_id, at, channel, outcome, note, next_follow_up_on FROM follow_up WHERE invoice_id = $1 ORDER BY at, follow_up_id'),
      q(`SELECT link_id, created_at, created_by_user_id, expires_at, revoked_at, last_viewed_at, view_count,
                CASE WHEN revoked_at IS NOT NULL THEN 'revoked' WHEN expires_at <= now() THEN 'expired' ELSE 'active' END AS state FROM invoice_share_link WHERE invoice_id = $1 ORDER BY created_at`),
      q('SELECT from_user_id, to_user_id, changed_by_user_id, changed_at, reason FROM invoice_owner_history WHERE invoice_id = $1 ORDER BY history_id'),
      q('SELECT at, actor_user_id, actor_role, action, reason, detail FROM invoice_event WHERE invoice_id = $1 ORDER BY event_id DESC LIMIT 200'),
    ]);
    const b = billTo[0];
    return {
      invoice: shape(row),
      billTo: b ? { name: b.name, line1: b.line1, line2: b.line2, city: b.city, stateProvince: b.state_province, postalCode: b.postal_code, countryCode: b.country_code, taxId: b.tax_id } : null,
      lines: lines.map(l => ({ lineNo: l.line_no, description: l.description, quantity: l.quantity, unitPriceMinor: num(l.unit_price_minor), amountMinor: num(l.amount_minor) })),
      statusHistory: history.map(h => ({ from: h.from_status_code, to: h.to_status_code, at: h.changed_at, byUserId: h.changed_by_user_id, reason: h.reason })),
      payments: payments.map(p => ({ paymentId: p.payment_id, amountMinor: num(p.amount_minor), method: p.method_code, reference: p.reference, receivedOn: p.received_on, receiptNumber: p.receipt_number,
        receiptIssuedOn: p.receipt_issued_on, recordedByUserId: p.recorded_by_user_id, recordedAt: p.recorded_at, reversesPaymentId: p.reverses_payment_id, voidReason: p.void_reason, isVoided: p.is_voided })),
      creditNotes: credits.map(c => ({ creditNoteId: c.credit_note_id, creditNoteNumber: c.credit_note_number, amountMinor: num(c.amount_minor), reason: c.reason, issuedOn: c.issued_on, createdByUserId: c.created_by_user_id })),
      followUps: followUps.map(f => ({ followUpId: f.follow_up_id, byUserId: f.by_user_id, at: f.at, channel: f.channel, outcome: f.outcome, note: f.note, nextFollowUpOn: f.next_follow_up_on })),
      shareLinks: links.map(l => ({ linkId: l.link_id, createdAt: l.created_at, createdByUserId: l.created_by_user_id, expiresAt: l.expires_at, revokedAt: l.revoked_at, lastViewedAt: l.last_viewed_at, viewCount: l.view_count, state: l.state })),
      ownerHistory: owners.map(o => ({ fromUserId: o.from_user_id, toUserId: o.to_user_id, changedByUserId: o.changed_by_user_id, at: o.changed_at, reason: o.reason })),
      activity: activity.map(a => ({ at: a.at, actorUserId: a.actor_user_id, actorRole: a.actor_role, action: a.action, reason: a.reason, detail: a.detail })),
    };
  }

  /** Parses the filter query into a WHERE clause. Shared by the list, the CSV export and the reports so "the filtered list" means one thing. */
  function filterOf(query) {
    const where = [], params = [];
    const add = (sql, value) => { params.push(value); where.push(sql.replace('?', `$${params.length}`)); };
    const one = name => { const v = query[name]; if (v !== undefined && typeof v !== 'string') throw refuse(`${name} must be a single value.`, 'bad_filter'); return v === '' ? undefined : v; };
    const id = (name, column) => { const v = one(name); if (v === undefined) return; if (!isUuid(v)) throw refuse(`${name} must be an id.`, 'bad_filter'); add(`${column} = ?`, v); };
    const day = (name, sql) => { const v = one(name); if (v === undefined) return; add(sql, isoDate(v, { name, reason: 'bad_filter' })); };
    const status = one('status');
    if (status !== undefined) {
      const s = status.toUpperCase();
      if (!STATUSES.includes(s)) throw refuse('status is not a status an invoice can have.', 'bad_filter');
      add('effective_status = ?', s);
    }
    id('customerId', 'customer_id'); id('ownerId', 'owner_user_id'); id('sourcePurchaseRequestId', 'source_purchase_request_id');
    day('dueFrom', 'due_on >= ?'); day('dueTo', 'due_on <= ?');
    const overdue = one('overdue');
    if (overdue !== undefined) { if (!['0', '1'].includes(overdue)) throw refuse('overdue must be 1 or 0.', 'bad_filter'); where.push(overdue === '1' ? 'is_overdue' : 'NOT is_overdue'); }
    const flag = (name, sql) => {
      const v = one(name);
      if (v === undefined) return;
      if (!['0', '1'].includes(v)) throw refuse(`${name} must be 1 or 0.`, 'bad_filter');
      if (v === '1') where.push(sql);
    };
    flag('open', 'is_open'); flag('closed', 'closed_at IS NOT NULL');
    const choice = (name, column, allowed) => {
      const v = one(name);
      if (v === undefined) return;
      if (!allowed.includes(v)) throw refuse(`${name} must be one of ${allowed.join(', ')}.`, 'bad_filter');
      add(`${column} = ?`, v);
    };
    choice('bucket', 'aging_bucket', ['current', '1-30', '31-60', '61+']);
    choice('health', 'follow_up_health', ['missing', 'lapsed']);
    return { sql: where.length ? `WHERE ${where.join(' AND ')}` : '', params };
  }

  async function list(query, { maxLimit = 200 } = {}) {
    const limit = query.limit === undefined ? 50 : (/^\d+$/.test(String(query.limit)) ? Number(query.limit) : 0);
    const offset = query.offset === undefined ? 0 : (/^\d+$/.test(String(query.offset)) ? Number(query.offset) : -1);
    if (limit < 1 || limit > maxLimit) throw refuse(`limit must be a whole number from 1 to ${maxLimit}.`, 'bad_filter');
    if (offset < 0 || offset > 1_000_000) throw refuse('offset must be a whole number from 0 to 1,000,000.', 'bad_filter');
    const f = filterOf(query);
    const [{ rows }, { rows: [{ total }] }] = await Promise.all([
      db.query(`SELECT * FROM v_invoice_state ${f.sql} ORDER BY created_at DESC, invoice_id DESC LIMIT ${limit} OFFSET ${offset}`, f.params),
      db.query(`SELECT count(*) AS total FROM v_invoice_state ${f.sql}`, f.params),
    ]);
    return { invoices: rows.map(shape), total: Number(total), limit, offset };
  }

  async function updateDraft(actor, id, input) {
    const has = k => Object.prototype.hasOwnProperty.call(input, k);
    if (!['lines', 'billTo', 'dueOn', 'notes'].some(has)) throw refuse('Give lines, billTo, dueOn or notes to change.', 'nothing_to_change');
    const lines = has('lines') ? linesOf(input.lines) : null;
    const billTo = has('billTo') ? billToOf(input.billTo) : null;
    const dueOn = has('dueOn') ? (input.dueOn === null ? null : isoDate(input.dueOn, { name: 'dueOn' })) : undefined;
    const notes = has('notes') ? (input.notes === null ? null : text(input.notes, { name: 'notes', max: 1000 })) : undefined;
    return tx(db, async client => {
      const inv = await lock(client, id);
      if (inv.status_code !== 'DRAFT') throw refuse('Only a draft can be edited. Issued invoices are never changed; use a credit note.', 'not_a_draft', { status: inv.status_code }, 409);
      if (billTo) await writeBillTo(client, id, billTo);
      if (lines) await writeLines(client, id, lines);
      if (dueOn !== undefined) await client.query('UPDATE invoice SET due_on = $2 WHERE invoice_id = $1', [id, dueOn]);
      if (notes !== undefined) await client.query('UPDATE invoice SET notes = $2 WHERE invoice_id = $1', [id, notes]);
      await events.record(client, { invoiceId: id, actor, action: 'invoice.edit', detail: { fields: ['lines', 'billTo', 'dueOn', 'notes'].filter(has) } });
      return { invoice: await read(client, id) };
    });
  }

  async function cancelDraft(actor, id, body) {
    const reason = reasonOf(body);
    return tx(db, async client => {
      const inv = await lock(client, id);
      if (inv.status_code !== 'DRAFT') throw refuse('Only a draft can be cancelled. An issued invoice is voided by an admin.', 'not_a_draft', { status: inv.status_code }, 409);
      await events.setContext(client, actor, reason);
      await client.query(`UPDATE invoice SET status_code = 'CANCELLED' WHERE invoice_id = $1`, [id]);
      await events.record(client, { invoiceId: id, actor, action: 'invoice.cancel_draft', reason });
      return { invoice: await read(client, id) };
    });
  }

  return { create, get, list, updateDraft, cancelDraft, lock, read, shape, filterOf, reasonOf };
}

module.exports = { createInvoices, notFound, reasonOf };
