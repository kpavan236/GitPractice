'use strict';
const crypto = require('node:crypto');
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { whole, isUuid } = require('./validate');
const { createHasher } = require('./secrets');

const SHAREABLE = ['ISSUED', 'SENT', 'OVERDUE', 'PAID'];

/**
 * The customer's link: 256 random bits, shown to staff once, stored only as a keyed hash (BILLING_HASH_PEPPER), with an expiry and revocation.
 * A copy of the database alone yields no working link.
 */
function createShareLinks({ db, invoices, events, hashPepper, defaultDays, publicBaseUrl }) {
  const hash = createHasher(hashPepper);
  const hashOf = token => hash('invoice-share-link', token);

  async function create(actor, invoiceId, input) {
    const days = input.days === undefined ? defaultDays : whole(input.days, { name: 'days', min: 1, max: 365, reason: 'bad_days' });
    return tx(db, async client => {
      const inv = await invoices.lock(client, invoiceId);
      if (!SHAREABLE.includes(inv.status_code)) throw refuse('Only an issued invoice can be shared.', 'bad_status', { status: inv.status_code }, 409);
      const token = crypto.randomBytes(32).toString('base64url');
      const linkId = uuidv7();
      const { rows: [l] } = await client.query(
        `INSERT INTO invoice_share_link (link_id, invoice_id, token_hash, expires_at, created_by_user_id) VALUES ($1, $2, $3, now() + make_interval(days => $4::int), $5) RETURNING expires_at`,
        [linkId, invoiceId, hashOf(token), days, actor.userId]);
      await events.record(client, { invoiceId, actor, action: 'link.create', detail: { linkId, days } });      // never the token
      return { status: 201, body: { link: { linkId, url: `${publicBaseUrl}/i/${token}`, expiresAt: l.expires_at }, invoice: await invoices.read(client, invoiceId) } };
    });
  }

  async function revoke(actor, invoiceId, linkId) {
    return tx(db, async client => {
      await invoices.lock(client, invoiceId);
      if (!isUuid(linkId)) throw refuse('No such link.', 'not_found', {}, 404);
      const { rows: [l] } = await client.query('SELECT revoked_at FROM invoice_share_link WHERE link_id = $1 AND invoice_id = $2 FOR UPDATE', [linkId, invoiceId]);
      if (!l) throw refuse('No such link.', 'not_found', {}, 404);
      if (l.revoked_at) throw refuse('That link was already revoked.', 'already_revoked', {}, 409);
      await client.query('UPDATE invoice_share_link SET revoked_at = now(), revoked_by_user_id = $2 WHERE link_id = $1', [linkId, actor.userId]);
      await events.record(client, { invoiceId, actor, action: 'link.revoke', detail: { linkId } });
      return { invoice: await invoices.read(client, invoiceId) };
    });
  }

  /** Counts the view and returns what the customer page shows, or null. Unknown, expired and revoked are indistinguishable. */
  async function view(token) {
    if (typeof token !== 'string' || token.length > 100) return null;
    const { rows: [l] } = await db.query(
      `UPDATE invoice_share_link SET view_count = view_count + 1, last_viewed_at = now() WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > now()
         AND EXISTS (SELECT 1 FROM invoice v WHERE v.invoice_id = invoice_share_link.invoice_id AND v.status_code <> 'VOID') RETURNING invoice_id`, [hashOf(token)]);
    if (!l) return null;
    const id = l.invoice_id;
    const [{ rows: [i] }, { rows: [b] }, { rows: lines }, { rows: receipts }, { rows: credits }] = await Promise.all([
      db.query('SELECT invoice_number, effective_status, issued_on, due_on, currency_code, subtotal_minor, discount_minor, total_minor, paid_minor, credited_minor, balance_minor FROM v_invoice_state WHERE invoice_id = $1', [id]),
      db.query('SELECT name, line1, line2, city, state_province, postal_code, country_code FROM invoice_bill_to WHERE invoice_id = $1', [id]),
      db.query('SELECT description, quantity, unit_price_minor, amount_minor FROM invoice_line WHERE invoice_id = $1 ORDER BY line_no', [id]),
      db.query(`SELECT p.receipt_number, p.received_on, p.amount_minor, m.label AS method FROM payment p JOIN payment_method m ON m.method_code = p.method_code
                 WHERE p.invoice_id = $1 AND p.amount_minor > 0 AND NOT EXISTS (SELECT 1 FROM payment r WHERE r.reverses_payment_id = p.payment_id) ORDER BY p.recorded_at, p.payment_id`, [id]),
      db.query('SELECT credit_note_number, issued_on, amount_minor FROM credit_note WHERE invoice_id = $1 ORDER BY created_at', [id]),
    ]);
    // Only what the customer needs. No ids, no notes, no staff. A payment's reference is the customer's own and stays out too.
    return { invoice: i, billTo: b || null, lines, receipts, credits };
  }

  return { create, revoke, view };
}

module.exports = { createShareLinks };
