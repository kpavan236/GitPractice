'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { text, isoDate, isUuid } = require('./validate');

const CHANNELS = ['call', 'email', 'meeting', 'other'];

/** A follow-up is a LOG of what staff did (a call, a meeting). Nothing is sent from here. */
function createFollowUps({ db, invoices, events }) {
  async function log(actor, id, input) {
    if (!CHANNELS.includes(input.channel)) throw refuse(`channel must be one of ${CHANNELS.join(', ')}.`, 'bad_channel');
    const outcome = text(input.outcome, { name: 'outcome', max: 200, reason: 'bad_outcome' });
    const note = text(input.note, { name: 'note', max: 1000, optional: true });
    const next = isoDate(input.nextFollowUpOn, { name: 'nextFollowUpOn', optional: true });
    return tx(db, async client => {
      const inv = await invoices.lock(client, id);
      if (!['ISSUED', 'SENT', 'OVERDUE'].includes(inv.status_code)) throw refuse('Follow-ups are for issued, unpaid invoices.', 'bad_status', { status: inv.status_code }, 409);
      if (next) {
        const { rows: [d] } = await client.query('SELECT CURRENT_DATE::text AS today');
        if (next < d.today) throw refuse('The next follow-up cannot be in the past.', 'next_follow_up_in_past');
      }
      const followUpId = uuidv7();
      const { rows: [f] } = await client.query(
        'INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome, note, next_follow_up_on) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING at',
        [followUpId, id, actor.userId, input.channel, outcome, note ?? null, next ?? null]);
      // The outcome and the note can hold what a customer said: they live in follow_up only, never in the activity detail.
      await events.record(client, { invoiceId: id, actor, action: 'followup.log', detail: { channel: input.channel, nextFollowUpOn: next ?? null } });
      return { status: 201, followUp: { followUpId, byUserId: actor.userId, at: f.at, channel: input.channel, outcome, note: note ?? null, nextFollowUpOn: next ?? null }, invoice: await invoices.read(client, id) };
    });
  }

  const ownerFilter = ownerId => {
    if (ownerId !== undefined && !isUuid(ownerId)) throw refuse('ownerId must be an id.', 'bad_filter');
    return ownerId ? { sql: ' AND owner_user_id = $1', params: [ownerId] } : { sql: '', params: [] };
  };

  async function queue({ ownerId } = {}) {
    const f = ownerFilter(ownerId);
    const { rows } = await db.query(
      `SELECT *, CURRENT_DATE::text AS today FROM v_invoice_state WHERE is_open AND (is_overdue OR next_follow_up_on <= CURRENT_DATE)${f.sql} ORDER BY owner_user_id, due_on, invoice_id LIMIT 1000`, f.params);
    const groups = new Map();
    for (const r of rows) {
      const due = r.next_follow_up_on !== null && r.next_follow_up_on <= r.today;
      const reason = r.is_overdue && due ? 'overdue_and_due' : r.is_overdue ? 'overdue' : r.next_follow_up_on < r.today ? 'lapsed' : 'due_today';
      if (!groups.has(r.owner_user_id)) groups.set(r.owner_user_id, []);
      groups.get(r.owner_user_id).push({ ...invoices.shape(r), reason });
    }
    return { today: rows[0] ? rows[0].today : null, groups: [...groups].map(([ownerUserId, list]) => ({ ownerUserId, invoices: list })) };
  }

  async function summary({ ownerId } = {}) {
    const f = ownerFilter(ownerId);
    const { rows: [r] } = await db.query(
      `SELECT count(*) FILTER (WHERE is_overdue) AS overdue, count(*) FILTER (WHERE next_follow_up_on <= CURRENT_DATE) AS due FROM v_invoice_state WHERE is_open${f.sql}`, f.params);
    return { overdue: Number(r.overdue), followUpsDue: Number(r.due) };
  }

  return { log, queue, summary };
}

module.exports = { createFollowUps };
