'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Worker } = require('worker_threads');
const analyzer = require('../src');

const ruleSet = {
  version: 'p@1', source: 'test',
  rules: [
    { id: 'T-1', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN', files: ['**/*.txt'], title: 't', category: 'TEST' },
    { id: 'T-AST', language: 'javascript', severity: 'HIGH', query: '(call_expression function: (identifier) @f (#eq? @f "eval")) @sink', title: 'eval', category: 'INJECTION' },
  ],
};
const repo = () => {
  const p = fs.mkdtempSync(path.join(os.tmpdir(), 'an-'));
  fs.writeFileSync(path.join(p, 'a.txt'), 'FORBIDDEN\n');
  fs.writeFileSync(path.join(p, 'b.js'), 'eval(x);\n');
  return p;
};

test('ENGINES declares the four engines at schema 1', () => {
  assert.equal(analyzer.ENGINES, 'ast:1,pattern:1,iac-policy:1,secret:1');
});

test('resolveRuleSet requires a rule set and shapes it', () => {
  assert.throws(() => analyzer.resolveRuleSet(undefined), /ruleSet is required/);
  assert.throws(() => analyzer.resolveRuleSet({ rules: 'x' }), /ruleSet is required/);
  const r = analyzer.resolveRuleSet(ruleSet);
  assert.equal(r.cacheVersion, 'p@1');
  assert.equal(r.source, 'test');
  assert.deepEqual(r.rejected, []);
});

test('analyze runs every engine with the given rules and nothing else', async () => {
  const p = repo();
  const { results } = await analyzer.analyze({ repoPath: p, repository: 'r', dir: p, ruleSet });
  const ids = [...results.values()].flatMap(r => r.findings.map(f => f.detections[0].ruleId)).sort();
  assert.deepEqual(ids, ['T-1', 'T-AST']);
});

test('analyze without a rule set reports an error per engine instead of a clean zero', async () => {
  const p = repo();
  const { results } = await analyzer.analyze({ repoPath: p, repository: 'r', dir: p });
  assert.equal(results.size, 4);
  for (const [id, r] of results) assert.match(r.error, /ruleSet is required/, id);
});

test('a worker started from workerPath scans with the rule set in the payload', async () => {
  const p = repo();
  const worker = new Worker(analyzer.workerPath, { workerData: { userGrammarsDir: null } });
  try {
    const reply = await new Promise((resolve, reject) => {
      worker.on('message', m => { if (m.ok !== undefined) resolve(m); });
      worker.on('error', reject);
      worker.postMessage({ id: 1, payload: {
        repoPath: p, repository: 'r', dir: p, bundleVersion: 'p@1', cacheEnabled: false,
        scannerIds: ['PATTERN_SAST', 'AST_SAST'], ruleSet,
      } });
    });
    assert.equal(reply.ok, true, reply.error);
    const ids = reply.result.results.flatMap(([, r]) => r.findings.map(f => f.detections[0].ruleId)).sort();
    assert.deepEqual(ids, ['T-1', 'T-AST']);
  } finally {
    await worker.terminate();
  }
});

test('engines report availability without a rule set: rules arrive per scan', async () => {
  for (const [name, engine] of Object.entries(analyzer.scanners)) {
    const a = await engine.isAvailable();
    if (name === 'secretsBuiltin') { assert.equal(a.available, true); continue; } // its pattern table is built in
    assert.equal(a.available, true, name);
    assert.match(a.version, /rules supplied per scan/, name);
  }
  const withRules = await analyzer.scanners.patternSast.isAvailable({ ruleSet });
  assert.match(withRules.version, /rules p@1 \(test\)/);
});
