'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const analyzer = require('../src');

const GOOD_PATTERN = { id: 'GOOD-P', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN', files: ['**/*.txt'], title: 't', category: 'TEST' };
const GOOD_AST = { id: 'GOOD-A', language: 'javascript', severity: 'HIGH', query: '(call_expression function: (identifier) @f (#eq? @f "eval")) @sink', title: 'eval', category: 'INJECTION' };

const repo = () => {
  const p = fs.mkdtempSync(path.join(os.tmpdir(), 'an-bad-'));
  fs.writeFileSync(path.join(p, 'a.txt'), 'FORBIDDEN\n');
  fs.writeFileSync(path.join(p, 'b.js'), 'eval(x);\n');
  return p;
};

async function scan(rules) {
  const p = repo();
  const { results } = await analyzer.analyze({ repoPath: p, repository: 'r', dir: p, ruleSet: { version: 'bad@1', source: 'test', rules } });
  const ids = [...results.values()].flatMap(r => r.findings.map(f => f.detections[0].ruleId)).sort();
  const errors = [...results].filter(([, r]) => r.error).map(([id, r]) => `${id}: ${r.error}`);
  return { ids, errors, results };
}

const BAD = {
  'a pattern whose regex does not compile': { id: 'BAD-REGEX', language: 'text', severity: 'LOW', pattern: '([unclosed', files: ['**/*.txt'], title: 'x', category: 'TEST' },
  'a pattern rule with no files glob': { id: 'BAD-NOFILES', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN', title: 'x', category: 'TEST' },
  'a rule with an engine this analyzer does not know': { id: 'BAD-ENGINE', language: 'text', severity: 'LOW', engine: 'future-engine', files: ['**/*.txt'], title: 'x', category: 'TEST' },
  'a rule with no engine fields at all': { id: 'BAD-EMPTY', language: 'text', severity: 'LOW', title: 'x', category: 'TEST' },
  'an AST rule whose query does not parse': { id: 'BAD-QUERY', language: 'javascript', severity: 'HIGH', query: '(call_expression (((', title: 'x', category: 'TEST' },
  'an AST rule for a language with no grammar': { id: 'BAD-LANG', language: 'no-such-language', severity: 'HIGH', query: '(identifier) @x', title: 'x', category: 'TEST' },
  'a null entry in the rule list': null,
  // Only throws when a file is matched (inside scanFile), not when the rule is compiled.
  'a pattern rule whose `negate` regex does not compile': { id: 'BAD-NEGATE', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN', negate: '([unclosed', files: ['**/*.txt'], title: 'x', category: 'TEST' },
  'a pattern rule whose `requiresContext` regex does not compile': { id: 'BAD-CTX', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN', requiresContext: '([unclosed', files: ['**/*.txt'], title: 'x', category: 'TEST' },
  'an AST rule whose `negate` regex does not compile': { id: 'BAD-A-NEGATE', language: 'javascript', severity: 'HIGH', query: GOOD_AST.query, negate: '([unclosed', title: 'x', category: 'TEST' },
  'an AST rule whose `requiresContext` regex does not compile': { id: 'BAD-A-CTX', language: 'javascript', severity: 'HIGH', query: GOOD_AST.query, requiresContext: '([unclosed', title: 'x', category: 'TEST' },
  'a string entry in the rule list': 'not a rule',
};

for (const [name, bad] of Object.entries(BAD)) {
  test(`${name} is skipped: the other rules still report and no engine fails`, async () => {
    const { ids, errors } = await scan([bad, GOOD_PATTERN, GOOD_AST]);
    assert.deepEqual(errors, [], 'no engine may fail because of one bad rule');
    assert.deepEqual(ids, ['GOOD-A', 'GOOD-P']);
  });
}


test('resolveRuleSet reports how many entries it dropped, so the loss is visible', () => {
  const r = analyzer.resolveRuleSet({ rules: [GOOD_PATTERN, null, 'x', { ...GOOD_PATTERN, id: 'BAD', negate: '([' }] });
  assert.deepEqual(r.rules.map(x => x.id), ['GOOD-P']);
  assert.equal(r.droppedRules, 3);
});
