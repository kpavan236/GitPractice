# oasis-analyzer

Parsers and rule engines for the iready-oasis security scanner: tree-sitter AST rules, line
patterns, structured IaC policies and secrets, plus the shared file walk, per-file cache and
worker entry point.

It owns **how to execute rules**, not **which rules to run**. The caller always passes a complete
`ruleSet`; a missing one is an error, never an empty scan.

## Overview

The analyzer scans the files of a checked-out repository and returns normalised findings. One
shared walk of the tree (`src/corpus.js`) offers each file to four engines:

| Engine id (`scanner.id`) | Key in `scanners` | What it checks |
|---|---|---|
| `AST_SAST` | `astSast` | Rules with a tree-sitter `query`, for Java, JavaScript/TypeScript and Python |
| `PATTERN_SAST` | `patternSast` | Line-regex rules (`pattern` + `files` globs) for formats with no grammar (Dockerfiles, Terraform, manifests, CI files, .env) |
| `IAC_POLICY` | `iacPolicy` | Policies (`engine: 'iac-policy'` + `definition`) evaluated against parsed Terraform (`.tf`) and YAML resources |
| `BUILTIN_SECRETS` | `secretsBuiltin` | Built-in credential patterns plus rules with `engine: 'secret'`; findings are masked and hashed, plaintext is never stored in the finding |

The rules arrive per call. An engine with nothing to do (for example no AST rules in the rule set)
reports itself skipped in its `stats` rather than returning a clean-looking zero.

## Tech stack

- Node.js (`engines.node >= 18`), CommonJS, no build step
- `web-tree-sitter` (WASM tree-sitter runtime) with vendored grammars for java, javascript, typescript, python
- `js-yaml` (YAML parsing for IaC manifests)
- Node's built-in test runner (`node --test`)

## Prerequisites

- Node.js 18 or newer (verified here on v26.10.0) and npm.
- No compiler or native build tools: the tree-sitter runtime and grammars are WASM.

## Install

    npm install

During development iready-oasis depends on this repo as `file:../oasis-analyzer` (a symlink).
Release builds must install a packed tarball (`npm pack`) instead. `package.json` is
`"private": true` and its `files` list is `src` and `README.md`.

## Usage

There is no CLI and no HTTP server. It is a library, plus a worker-thread entry point. Entry is
`src/index.js` (`main` in `package.json`).

### Library

```js
const analyzer = require('oasis-analyzer');   // or require('./src') inside this repo

const ruleSet = {
  version: 'p@1', source: 'demo',
  rules: [
    { id: 'T-1', language: 'text', severity: 'LOW', pattern: 'FORBIDDEN',
      files: ['**/*.txt'], title: 't', category: 'TEST' },
    { id: 'T-AST', language: 'javascript', severity: 'HIGH',
      query: '(call_expression function: (identifier) @f (#eq? @f "eval")) @sink',
      title: 'eval', category: 'INJECTION' },
  ],
};

const { results, corpus } = await analyzer.analyze({
  repoPath: '/path/to/repo', repository: 'my-repo', dir: '/path/to/store', ruleSet,
});
for (const [engineId, r] of results) console.log(engineId, r.findings.length, r.stats, r.error);
```

Verified by running this against a temp directory containing `a.txt` (`FORBIDDEN`) and `b.js`
(`eval(x);`): `PATTERN_SAST` returned `T-1` at `a.txt:1`, `AST_SAST` returned `T-AST` at `b.js:1`,
`BUILTIN_SECRETS` scanned 2 files with 15 built-in rules, and `IAC_POLICY` reported
`skipped: true, reason: "no IaC policies in bundle p@1"`.

### API

| Export | Meaning |
|---|---|
| `analyze({ repoPath, repository, ruleSet, dir, maxFiles, cache, onProgress, files, scanners })` | One shared walk through the engines. Returns `{ results: Map(engineId -> {findings, stats, error}), corpus, cache }`. `scanners` defaults to all four. `files` is an optional list of repo-relative paths to visit instead of walking the tree. `onProgress({file, filesScanned, filesTotal})` is called per file. `cache` is an object with the shape returned by `createCache` in `src/scan-cache.js` (that factory is not re-exported from `index.js`). |
| `scanners` | `{ secretsBuiltin, patternSast, iacPolicy, astSast }` |
| `ENGINES` | `ast:1,pattern:1,iac-policy:1,secret:1`: engine names and rule-schema versions, sent to the rule server to check a profile is runnable |
| `workerPath` | Worker-thread entry. Message payload carries `ruleSet`; `workerData: { userGrammarsDir }` |
| `startWorker({ resolvePayload })` | What the worker entry runs; an embedding scanner can supply `resolvePayload` to fill in a payload |
| `resolveRuleSet(ruleSet)` | Validates and shapes a rule set (`rules`, `version`, `cacheVersion`, `source`, `createdAt`, `ageDays`, `rejected`); throws `ruleSet is required` if `rules` is not an array |
| `finding`, `loadPlugins` | Finding model (`createFinding`, severity helpers); grammar plugin loader |
| `version` | `package.json` version |

Each scanner also exposes `isAvailable({ ruleSet })`, `prepare`, `scanFile`, `finish` and `scan`.

### Worker thread

```js
const { Worker } = require('worker_threads');
const worker = new Worker(analyzer.workerPath, { workerData: { userGrammarsDir: null } });
worker.on('message', m => { /* { id, progress } while running, then { id, ok: true, result } or { id, ok: false, error } */ });
worker.postMessage({ id: 1, payload: {
  repoPath, repository, dir, bundleVersion: 'p@1', cacheEnabled: false,
  scannerIds: ['PATTERN_SAST', 'AST_SAST'], ruleSet,
} });
```

Payload fields read by `src/worker-core.js`: `repoPath`, `repository`, `dir`, `scannerIds`,
`bundleVersion`, `maxFiles`, `cacheEnabled`, `files`, `ruleSet`. Progress messages are throttled to
every 100 ms (first and last file always get through). `result` holds `results` (array of
`[scannerId, {findings, stats, error}]`), `corpus`, `cacheStats` and `secrets` (the plaintext
credentials of secret findings, carried explicitly because that field is non-enumerable and would
not survive the thread boundary).

## Inputs and outputs

**Input: rule set** (object). `rules` is required. Optional: `version`, `cacheVersion`, `source`,
`createdAt`, `rejected`. Rule shapes:

- AST: `query` (tree-sitter query) plus `language`
- Line rule: `pattern` + `files` (glob or list; required, no default). Optional `negate`, `requiresContext`, `includeComments`, `caseSensitive`
- IaC: `engine: 'iac-policy'` + `definition` (operators such as `equals`, `exists`, `is_true`, `regex_match`, `within`, `length_greater_than`; combinators `and`, `or`, `not`, `filter`; see `src/iac/evaluate.js`)
- Secret: `engine: 'secret'` + `pattern` (optional `patternFlags`)

**Input: repository** on disk (`repoPath`). A non-existent path throws.

**Output: findings.** Created by `finding.createFinding`: `type` (one of `SAST, SCA, SECRET, SBOM, LICENSE, CONTAINER, IAC, DAST, API, CLOUD, QUALITY`), `category`, `severity` (`CRITICAL|HIGH|MEDIUM|LOW|INFO`), `title`, `description`, `repository`, `file` (repo-relative, forward slashes), `startLine`, `endLine`, `cwe`, `cve`, `status: 'OPEN'`, `detections: [{ source, ruleId }]`, `remediation`, `evidence`, `metadata`. `id`, `fingerprint`, `risk` and timestamps are left `null` for the caller to assign.

**Output: stats and corpus.** Per-engine `stats` (files scanned/analysed, rule counts, `truncated`, `truncatedReason`) and a `corpus` summary `{ filesVisited, filesRead, bytesRead, truncated, truncatedReason }`.

**Inline suppression.** A comment `oasis:ignore [ruleId] [-- reason]` (leader `//`, `#`, `/*` or `--`) suppresses the finding on its own line or the line below (`src/ignore.js`). The repository-level ignore file and baseline live in iready-oasis, not here.

## Configuration

The analyzer takes configuration as arguments; it reads no config file. Environment variables:

| Variable | Effect |
|---|---|
| `OASIS_SCAN_MAX_FILES` | File cap per scan (default 20000). A scan that hits it reports `truncated: true` with a reason |
| `OASIS_SCAN_NO_CACHE` | Set to `1` to disable the per-file cache |

Walk limits (constants in `src/corpus.js`): skips directories such as `.git`, `node_modules`,
`target`, `build`, `dist`, `vendor`, `.terraform`; skips binary/archive/image extensions and
`.min.js`, `.map`, `.lock`; skips empty files and files over 2 MB (pattern engine: 1 MB; lines over
4000 characters are skipped).

`.env.example` is not present in this repo.

## Project structure

| Path | Role |
|---|---|
| `src/index.js` | Public entry: `analyze`, `scanners`, `ENGINES`, exports |
| `src/corpus.js` | Shared lazy walk, progress, file cap, `runCorpusScanners` |
| `src/worker.js`, `src/worker-core.js` | Worker-thread entry and message handler |
| `src/rules.js` | `resolveRuleSet` |
| `src/finding.js` | Finding model, severity normalisation, CVSS band helper |
| `src/paths.js` | POSIX-relative paths, `isInside` check |
| `src/ignore.js` | `oasis:ignore` markers and glob matcher |
| `src/scan-cache.js` | Per-file findings cache keyed on content, path, engine, rule version and app version; JSON file per repository under `<dir>/cache/` |
| `src/scanners/secrets-builtin.js`, `src/secret-patterns.js` | Secret engine and built-in pattern table |
| `src/scanners/pattern-sast.js` | Line-pattern engine |
| `src/scanners/sast-ast.js` | AST engine scanner (taint-aware severity adjustment) |
| `src/scanners/iac-policy.js` | IaC engine for `.tf` and `.yml/.yaml` |
| `src/ast/engine.js`, `src/ast/taint.js` | tree-sitter loading, queries, grammar plugins; taint-source name list |
| `src/ast/grammars/*.wasm` | Vendored grammars: java, javascript, typescript, python |
| `src/iac/hcl.js`, `src/iac/evaluate.js` | Terraform subset parser; policy evaluator |
| `test/api.test.js` | Tests for the public API and worker |
| `db/setup/README.md` | Notes that there is no database |

Grammar plugins: `loadPlugins(dir)` reads each subdirectory containing `manifest.json`
(`language`, `displayName`, `extensions`, `version`) and `grammar.wasm`, with optional `rules.json`.

## Scripts

| Script | Command |
|---|---|
| `npm test` | `node --test --test-force-exit "test/**/*.test.js"` |

## Testing

    npm install && npm test

Last run: 6 tests, 6 pass, 0 fail.

## Relationship to oasis-rule-server and iready-oasis

Only what the code shows:

- iready-oasis is the embedding scanner. It depends on this package, passes the `ruleSet`, and owns the store, the repository ignore file and baseline, fingerprints and risk. Comments in the code also reference its `server/security/index.js`.
- `ENGINES` is "sent to the rule server" so the server can refuse a profile containing rules this analyzer cannot run. The rule server is not referenced by name or called anywhere in this repo.

## Limitations

- Regex line rules cannot distinguish code from comments or strings; use AST rules where a grammar exists (Java, JavaScript, TypeScript, Python).
- The HCL parser reads literals only; expressions such as `var.x` are kept as raw text and not evaluated.
- IaC covers Terraform and YAML with a `kind`; no other formats.
- A scan stops at the file cap (default 20000) and says so in the result.
- The cache only fits engines that are pure functions of one file; files containing a live-looking secret are always rescanned.
- If a grammar fails to load (often a tree-sitter ABI mismatch after a dependency bump), that language is silently disabled, not an error.
- `analyze()` uses a cache only if you pass `cache`; the worker creates one itself.
- No database, no network calls, no CLI.

## Troubleshooting

- `ruleSet is required`: the caller passed no `ruleSet` (or `rules` is not an array). Every engine reports this per engine in `results`.
- `Repository path does not exist`: check `repoPath`.
- An engine shows `skipped: true`: the rule set has no rules for that engine.
- No AST findings for a language: check `availableLanguages()` in `src/ast/engine.js` and the grammar ABI vs `web-tree-sitter`.
- Stale findings after rule changes: caching is keyed on `bundleVersion`; bump `version`/`cacheVersion`, or set `OASIS_SCAN_NO_CACHE=1`.
- Partial scan: look for `truncated` and raise `OASIS_SCAN_MAX_FILES`.

## License and third-party notes

No LICENSE file is present and the package is `private`. Runtime dependencies are `js-yaml` and
`web-tree-sitter`; check their licenses and those of the vendored tree-sitter grammar `.wasm`
files (code comments say they are taken from `@vscode/tree-sitter-wasm`) before any external
distribution. Test credentials should always be synthetic.
