# Database setup

oasis-analyzer has **no database**, so there is nothing to create here and no SQL files.

A search of `src/` found no SQL engine, driver, ORM or SQL statements. The only matches were a
credential-detection regex in `src/secret-patterns.js` that recognises `postgres://` and
`mysql://` connection strings in scanned files, which is detection of other people's
configuration and not a dependency. `package.json` lists only `js-yaml` and `web-tree-sitter`.

## What it uses instead

| Need | Mechanism |
|---|---|
| Findings, stats, rule set | In memory only. `analyze()` returns them to the caller (a `Map` of engine id to `{ findings, stats, error }`). Persisting findings is the embedding scanner's job (iready-oasis), not this package's. |
| Per-file result cache (optional) | A JSON file per repository at `<dir>/cache/<repository>.json`, written by `src/scan-cache.js` only when a cache is supplied (the worker always creates one unless `cacheEnabled: false` or `OASIS_SCAN_NO_CACHE=1`). It is disposable: deleting it only costs speed. |
| AST grammars | Vendored `.wasm` files in `src/ast/grammars/`, plus optional user grammar plugins read from a directory the caller passes. |
