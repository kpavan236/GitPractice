'use strict';

// A Terraform (HCL2) parser, scoped to what a policy needs to read.
//
// Checkov's policies are overwhelmingly about Terraform, so an adapter that
// could not read .tf files would be an adapter with nothing to evaluate. There
// is no HCL parser we can install — the no-dependency rule again — so this
// reads the subset that matters: blocks, their labels, attributes, nested
// blocks, and literal values.
//
// WHAT IT DELIBERATELY DOES NOT DO is evaluate expressions. `count`, `for_each`,
// `${var.x}`, function calls and conditionals are captured as their raw source
// text rather than resolved. Resolving them means implementing Terraform, and a
// half-resolved expression is worse than an unresolved one: a policy comparing
// against a wrong computed value answers confidently and incorrectly, whereas
// an unresolved string simply fails to match a literal and the policy reports
// nothing for that attribute.
//
// The practical consequence, stated so nobody has to discover it: a policy
// asserting `encrypted == true` will not be satisfied by `encrypted = var.enc`.
// That is a false positive, and it is the safe direction — it surfaces a
// resource a human then reads, rather than passing one nobody looks at.

const BLOCK_START = /^([A-Za-z_][A-Za-z0-9_-]*)((?:\s+(?:"[^"]*"|[A-Za-z_][A-Za-z0-9_-]*))*)\s*\{\s*$/;
const ATTRIBUTE = /^([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/;
const NESTED_BLOCK = /^([A-Za-z_][A-Za-z0-9_-]*)((?:\s+"[^"]*")*)\s*\{\s*$/;

function stripComments(line) {
  // Only comments that start a token. A `#` inside a quoted string is data, and
  // stripping it would corrupt every CIDR-in-a-comment and URL in the file.
  let out = '';
  let quote = null;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quote) {
      out += c;
      if (c === quote && line[i - 1] !== '\\') quote = null;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      out += c;
      continue;
    }
    if (c === '#') break;
    if (c === '/' && line[i + 1] === '/') break;
    out += c;
  }
  return out;
}

function parseLabels(raw) {
  return (raw || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map(l => l.replace(/^"|"$/g, ''));
}

// Literal values only. Anything else comes back as its source text, which is
// the honest representation of "we did not evaluate this".
function parseValue(raw) {
  const text = String(raw).trim().replace(/,$/, '');

  if (/^"[\s\S]*"$/.test(text)) {
    const inner = text.slice(1, -1);
    // An interpolated string is an expression, not a literal.
    return inner.includes('${') ? text : inner.replace(/\\"/g, '"').replace(/\\n/g, '\n');
  }
  if (text === 'true') return true;
  if (text === 'false') return false;
  if (text === 'null') return null;
  if (/^-?\d+$/.test(text)) return parseInt(text, 10);
  if (/^-?\d*\.\d+$/.test(text)) return parseFloat(text);

  // [\s\S] rather than . — a multi-line list contains newlines, and `.`
  // does not match them, so the dotted form silently fell through to "raw
  // text" and every multi-line CIDR list stopped being a list.
  if (/^\[[\s\S]*\]$/.test(text)) {
    const inner = text.slice(1, -1).trim();
    if (!inner) return [];
    // Split on commas that are not inside quotes or brackets.
    const parts = [];
    let depth = 0;
    let quote = null;
    let current = '';
    for (const c of inner) {
      if (quote) {
        current += c;
        if (c === quote) quote = null;
        continue;
      }
      if (c === '"' || c === "'") { quote = c; current += c; continue; }
      if (c === '[' || c === '{') depth++;
      if (c === ']' || c === '}') depth--;
      if (c === ',' && depth === 0) { parts.push(current); current = ''; continue; }
      current += c;
    }
    if (current.trim()) parts.push(current);
    return parts.map(p => parseValue(p));
  }

  return text;
}

// Repeated blocks of the same name become a list. Terraform allows several
// `ingress` blocks on one security group, and collapsing them to the last one
// would hide every rule but one — which is exactly the rule an attacker uses.
function attach(target, key, value) {
  if (!(key in target)) {
    target[key] = value;
    return;
  }
  if (Array.isArray(target[key])) target[key].push(value);
  else target[key] = [target[key], value];
}

/**
 * Parses HCL into `{ blocks: [{ type, labels, body, line }] }`.
 */
function parseHcl(text) {
  const lines = String(text == null ? '' : text).split('\n');
  const blocks = [];

  // Each frame is one open `{`. The root frame collects top-level blocks.
  const stack = [{ body: null, key: null, line: 0 }];
  let heredoc = null;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];

    if (heredoc) {
      if (rawLine.trim() === heredoc.terminator) {
        attach(heredoc.target, heredoc.key, heredoc.lines.join('\n'));
        heredoc = null;
      } else {
        heredoc.lines.push(rawLine);
      }
      continue;
    }

    const line = stripComments(rawLine).trim();
    if (!line) continue;

    const top = stack[stack.length - 1];

    if (line === '}' || line === '},') {
      const frame = stack.pop();
      if (stack.length === 0) stack.push({ body: null, key: null, line: 0 });
      if (frame && frame.emit) blocks.push(frame.emit);
      else if (frame && frame.parent) attach(frame.parent, frame.key, frame.body);
      continue;
    }

    // A top-level block: resource "aws_s3_bucket" "b" {
    if (top.body === null) {
      const match = BLOCK_START.exec(line);
      if (match) {
        const labels = parseLabels(match[2]);
        const body = {};
        const block = { type: match[1], labels, body, line: i + 1 };
        stack.push({ body, key: null, emit: block, line: i + 1 });
      }
      continue;
    }

    // A nested block inside the current body.
    const nested = NESTED_BLOCK.exec(line);
    if (nested && !line.includes('=')) {
      const body = {};
      stack.push({ body, key: nested[1], parent: top.body, line: i + 1 });
      continue;
    }

    const attribute = ATTRIBUTE.exec(line);
    if (attribute) {
      const key = attribute[1];
      const rest = attribute[2].trim();

      const here = /^<<-?([A-Za-z_][A-Za-z0-9_]*)$/.exec(rest);
      if (here) {
        heredoc = { target: top.body, key, terminator: here[1], lines: [] };
        continue;
      }

      // A value that opens a brace or bracket and does not close on this line
      // spans several lines; gather them before parsing.
      if (/^[[{]/.test(rest) && !isBalanced(rest)) {
        let buffer = rest;
        let j = i + 1;
        while (j < lines.length && !isBalanced(buffer)) {
          // Joined with a NEWLINE, not a space. A multi-line map separates its
          // entries by line rather than by comma, so joining with spaces left
          // parseObject with nothing to split on and collapsed the whole map
          // into a single malformed key.
          buffer += `\n${stripComments(lines[j]).trim()}`;
          j++;
        }
        i = j - 1;
        attach(top.body, key, /^\{/.test(buffer) ? parseObject(buffer) : parseValue(buffer));
        continue;
      }

      attach(top.body, key, /^\{/.test(rest) ? parseObject(rest) : parseValue(rest));
    }
  }

  return { blocks };
}

function isBalanced(text) {
  let depth = 0;
  let quote = null;
  for (const c of text) {
    if (quote) {
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '[' || c === '{') depth++;
    if (c === ']' || c === '}') depth--;
  }
  return depth === 0;
}

function parseObject(text) {
  const inner = text.trim().replace(/^\{/, '').replace(/\}$/, '').trim();
  const out = {};
  if (!inner) return out;

  for (const part of inner.split(/[,\n]/)) {
    const match = /^\s*"?([A-Za-z_][A-Za-z0-9_.-]*)"?\s*[:=]\s*(.+?)\s*$/.exec(part);
    if (match) out[match[1]] = parseValue(match[2]);
  }
  return out;
}

/**
 * Terraform blocks as policy resources.
 *
 * Only `resource` and `data` blocks become resources — a `variable` or
 * `terraform` block is configuration about the configuration, and evaluating a
 * bucket policy against a provider block produces noise.
 */
function resourcesFrom(text, file) {
  const { blocks } = parseHcl(text);
  return blocks
    .filter(b => (b.type === 'resource' || b.type === 'data') && b.labels.length >= 1)
    .map(b => ({
      type: b.labels[0],
      name: b.labels[1] || b.labels[0],
      file,
      line: b.line,
      body: b.body,
    }));
}

module.exports = { parseHcl, resourcesFrom, parseValue, parseObject, stripComments, isBalanced };
