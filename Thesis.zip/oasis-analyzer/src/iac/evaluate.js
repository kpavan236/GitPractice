'use strict';

// Evaluates an ingested IaC policy against a parsed resource.
//
// A resource is `{ type, name, file, line, body }`, where `body` is a plain
// object produced by the HCL or YAML parser. Everything here works on that
// shape and knows nothing about either format, which is what lets one policy
// engine serve Terraform and Kubernetes.
//
// THE INVERSION. A policy definition states what SHOULD be true. `satisfies()`
// answers whether it is. A finding is raised when the answer is NO. Getting
// this backwards reports every correctly configured resource and stays silent
// on the broken ones — confidently, and in the direction that gets people
// hurt — so it is stated here, tested directly, and never inferred at a call
// site.

// A missing attribute is not the same as an attribute set to null, and neither
// is the same as false. A sentinel keeps them apart; using `undefined` alone
// made `exists` and `is_false` agree on an absent boolean, which is wrong for
// both.
const MISSING = Symbol('missing');

/**
 * Reads a dotted attribute path out of a resource body.
 *
 * Supports the `*` wildcard Checkov uses to reach into lists — `ingress.*.cidr`
 * yields every element's cidr — so a policy over a list of rules is evaluated
 * against each of them rather than against the list object.
 *
 * Always returns an array of values, because a wildcard path is inherently
 * multi-valued and special-casing the single case leaks into every operator.
 */
function readPath(body, path) {
  let nodes = [body];

  for (const segment of String(path).split('.')) {
    const next = [];
    for (const node of nodes) {
      if (node === null || node === undefined) continue;

      if (segment === '*') {
        if (Array.isArray(node)) next.push(...node);
        else if (typeof node === 'object') next.push(...Object.values(node));
        continue;
      }
      // A list reached by a plain segment is searched element-wise. Terraform
      // renders repeated blocks as a list, so `ingress.cidr_blocks` has to work
      // whether there is one ingress block or four.
      if (Array.isArray(node)) {
        for (const item of node) {
          if (item && typeof item === 'object' && segment in item) next.push(item[segment]);
        }
        continue;
      }
      if (typeof node === 'object' && segment in node) next.push(node[segment]);
    }
    nodes = next;
    if (!nodes.length) return [MISSING];
  }

  return nodes.length ? nodes : [MISSING];
}

function asNumber(value) {
  const n = typeof value === 'number' ? value : parseFloat(value);
  return Number.isFinite(n) ? n : null;
}

function asList(value) {
  if (Array.isArray(value)) return value;
  if (value === MISSING || value === undefined || value === null) return [];
  return [value];
}

function looseEquals(a, b) {
  if (a === b) return true;
  // Terraform and YAML both produce `"true"` where a policy says `true`, and a
  // strict comparison would silently fail every boolean policy.
  if (typeof a === 'boolean' || typeof b === 'boolean') {
    return String(a).toLowerCase() === String(b).toLowerCase();
  }
  const na = asNumber(a);
  const nb = asNumber(b);
  if (na !== null && nb !== null) return na === nb;
  return String(a) === String(b);
}

// Each operator answers a question about ONE value. `MISSING` is passed in
// deliberately rather than short-circuited, because `not_exists` and
// `is_empty` are precisely the operators that need to see it.
const OPERATORS = {
  exists: v => v !== MISSING && v !== null && v !== undefined,
  not_exists: v => v === MISSING || v === null || v === undefined,

  equals: (v, e) => v !== MISSING && looseEquals(v, e),
  not_equals: (v, e) => v === MISSING || !looseEquals(v, e),

  is_true: v => v !== MISSING && String(v).toLowerCase() === 'true',
  is_false: v => v !== MISSING && String(v).toLowerCase() === 'false',

  is_empty: v => v === MISSING || v === null || v === '' || (Array.isArray(v) && v.length === 0),
  is_not_empty: v => !OPERATORS.is_empty(v),

  regex_match: (v, e) => {
    if (v === MISSING) return false;
    try {
      return new RegExp(String(e)).test(String(v));
    } catch (_) {
      // A policy carrying an uncompilable regex must not silently pass. False
      // means "does not satisfy", which surfaces as a finding a human reads.
      return false;
    }
  },
  not_regex_match: (v, e) => v === MISSING || !OPERATORS.regex_match(v, e),

  contains: (v, e) => {
    if (v === MISSING) return false;
    if (Array.isArray(v)) return v.some(item => looseEquals(item, e));
    return String(v).includes(String(e));
  },
  not_contains: (v, e) => v === MISSING || !OPERATORS.contains(v, e),

  within: (v, e) => v !== MISSING && asList(e).some(item => looseEquals(item, v)),
  not_within: (v, e) => v === MISSING || !OPERATORS.within(v, e),

  starting_with: (v, e) => v !== MISSING && String(v).startsWith(String(e)),
  not_starting_with: (v, e) => v === MISSING || !OPERATORS.starting_with(v, e),
  ending_with: (v, e) => v !== MISSING && String(v).endsWith(String(e)),
  not_ending_with: (v, e) => v === MISSING || !OPERATORS.ending_with(v, e),

  greater_than: (v, e) => asNumber(v) !== null && asNumber(e) !== null && asNumber(v) > asNumber(e),
  greater_than_or_equal: (v, e) => asNumber(v) !== null && asNumber(e) !== null && asNumber(v) >= asNumber(e),
  less_than: (v, e) => asNumber(v) !== null && asNumber(e) !== null && asNumber(v) < asNumber(e),
  less_than_or_equal: (v, e) => asNumber(v) !== null && asNumber(e) !== null && asNumber(v) <= asNumber(e),

  length_equals: (v, e) => asList(v === MISSING ? [] : v).length === asNumber(e),
  length_greater_than: (v, e) => asList(v === MISSING ? [] : v).length > asNumber(e),
  length_less_than: (v, e) => asList(v === MISSING ? [] : v).length < asNumber(e),

  subset: (v, e) => v !== MISSING && asList(v).every(item => asList(e).some(x => looseEquals(x, item))),
  not_subset: (v, e) => v === MISSING || !OPERATORS.subset(v, e),
  intersects: (v, e) => v !== MISSING && asList(v).some(item => asList(e).some(x => looseEquals(x, item))),
  not_intersects: (v, e) => v === MISSING || !OPERATORS.intersects(v, e),
};

function evaluateAttribute(condition, resource) {
  // A condition scoped to other resource types is vacuously satisfied here.
  if (condition.resourceTypes && condition.resourceTypes.length
      && !condition.resourceTypes.includes(resource.type)) {
    return true;
  }

  const operator = OPERATORS[condition.operator];
  // An operator we do not implement must not read as "satisfied" — that would
  // silently pass every resource the policy was written to catch.
  if (!operator) return false;

  const values = readPath(resource.body, condition.attribute);

  // A wildcard path yields many values. Checkov's semantics are that EVERY
  // matched element must satisfy the condition — one public subnet in a list of
  // ten is still a finding.
  return values.every(value => operator(value, condition.value));
}

/**
 * Whether a resource satisfies a policy definition.
 *
 * True means compliant. A finding is raised on false — see the header.
 */
function satisfies(definition, resource) {
  if (!definition || typeof definition !== 'object') return true;

  switch (definition.op) {
    case 'and':
      return (definition.children || []).every(child => satisfies(child, resource));
    case 'or':
      return (definition.children || []).some(child => satisfies(child, resource));
    case 'not':
      return !satisfies((definition.children || [])[0], resource);
    case 'filter':
      // A filter narrows scope rather than asserting anything, so a resource
      // outside it is not a violation. Scope is applied by inScope() before a
      // resource ever reaches here; treating it as satisfied keeps a filter
      // nested inside an `and` from inverting the result.
      return true;
    case 'attribute':
      return evaluateAttribute(definition, resource);
    default:
      return true;
  }
}

/**
 * Whether a policy applies to a resource at all.
 *
 * Separate from satisfaction because "this policy says nothing about this
 * resource" and "this resource complies" are different facts, and conflating
 * them is how a policy about S3 buckets ends up reporting on IAM roles.
 */
function inScope(rule, resource) {
  const types = rule.resourceTypes || [];
  if (!types.length) return false;
  return types.includes(resource.type);
}

/**
 * Every resource that violates the policy.
 */
function violations(rule, resources) {
  return (resources || []).filter(r => inScope(rule, r) && !satisfies(rule.definition, r));
}

module.exports = { satisfies, inScope, violations, readPath, evaluateAttribute, OPERATORS, MISSING };
