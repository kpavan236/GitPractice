'use strict';
const path = require('path');
const { runCorpusScanners } = require('./corpus');
const { resolveRuleSet } = require('./rules');
const finding = require('./finding');
const { loadPlugins } = require('./ast/engine');
const secretsBuiltin = require('./scanners/secrets-builtin').scanner;
const patternSast = require('./scanners/pattern-sast').scanner;
const iacPolicy = require('./scanners/iac-policy').scanner;
const astSast = require('./scanners/sast-ast').scanner;

// What this analyzer can execute: engine name and rule-schema version. The
// scanner sends it to the rule server so the server can refuse a profile that
// contains rules this analyzer does not understand.
const ENGINES = 'ast:1,pattern:1,iac-policy:1,secret:1';
const scanners = { secretsBuiltin, patternSast, iacPolicy, astSast };

function analyze({ scanners: list = Object.values(scanners), ...options } = {}) {
  return runCorpusScanners(list, options);
}

module.exports = {
  analyze, scanners, ENGINES, resolveRuleSet, loadPlugins, finding,
  workerPath: path.join(__dirname, 'worker.js'),
  startWorker: require('./worker-core').startWorker,
  version: require('../package.json').version,
};
