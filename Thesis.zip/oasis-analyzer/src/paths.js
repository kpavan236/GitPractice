'use strict';
const path = require('path');


// Repository-relative paths, always with forward slashes.
//
// path.relative() returns the host separator, so the same file scanned on
// Windows and on macOS yields `src\App.java` and `src/App.java`. Those are
// different strings, so they produce different FINGERPRINTS — the same finding
// would appear twice for a team split across operating systems, and triage
// applied on one would not carry to the other.
//
// Forward slashes everywhere: git uses them, the manifests use them, and every
// UI we render into displays them fine.

function toPosix(p) {
  return String(p == null ? '' : p).split(path.sep).join('/');
}

// Repo-relative, posix-separated, no leading "./".
function relativeToRepo(repoPath, filePath) {
  return toPosix(path.relative(repoPath, filePath)).replace(/^\.\//, '');
}

// Whether a path stays inside the repository. Used before reading anything a
// scanner or an ignore file names, so a crafted entry cannot walk out of the
// clone directory.
function isInside(repoPath, candidate) {
  const rel = path.relative(repoPath, candidate);
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

module.exports = { toPosix, relativeToRepo, isInside };