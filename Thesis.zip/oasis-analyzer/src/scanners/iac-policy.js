'use strict';
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { createFinding } = require('../finding');
const { relativeToRepo } = require('../paths');
const { resolveRuleSet } = require('../rules');
const { runOverOwnCorpus } = require('../corpus');
const { resourcesFrom } = require('../iac/hcl');
const { violations } = require('../iac/evaluate');

// Structured IaC policy evaluation.
//
// This is the third engine, and it exists because the other two cannot answer
// the question policies actually ask. A tree-sitter query needs a grammar we do
// not have for HCL. A line regex cannot say "this security group has an ingress
// block whose cidr_blocks contains 0.0.0.0/0" — it can only say "this line
// contains 0.0.0.0/0", which is why the pattern rules lean on requiresContext
// and still misfire on a commented-out example.
//
// Here a file is PARSED into resources and a policy is evaluated against their
// attributes. That is what makes Checkov's policies portable at all, and it is
// strictly more precise than the pattern rules covering the same ground — the
// pattern rules stay because they cover formats this engine has no parser for.

const MAX_FILE_BYTES = 2 * 1024 * 1024;

const TERRAFORM = /\.tf$/i;
const YAML_FILE = /\.ya?ml$/i;

// Kubernetes manifests identify their own type; a YAML file without `kind` is
// some other kind of configuration and has no resources to evaluate.
function resourcesFromYaml(text, file) {
  let documents;
  try {
    documents = yaml.loadAll(text).filter(d => d && typeof d === 'object');
  } catch (_) {
    // One malformed manifest never fails the scan.
    return [];
  }

  return documents
    .filter(d => typeof d.kind === 'string')
    .map(d => ({
      type: d.kind,
      name: (d.metadata && d.metadata.name) || d.kind,
      file,
      // YAML gives no line numbers without a custom loader, and a wrong line
      // number is worse than none: it sends the reader to unrelated code. The
      // finding points at the file.
      line: null,
      body: d,
    }));
}

function resourcesIn(text, relativePath) {
  if (TERRAFORM.test(relativePath)) return resourcesFrom(text, relativePath);
  if (YAML_FILE.test(relativePath)) return resourcesFromYaml(text, relativePath);
  return [];
}

/**
 * Evaluates policy rules against one file's resources.
 *
 * Exported so a policy can be exercised against a string, which is what keeps
 * the fixtures for this engine as cheap as the other two.
 */
function scanContent(text, relativePath, repository, rules) {
  const resources = resourcesIn(text, relativePath);
  if (!resources.length) return [];

  const findings = [];

  for (const rule of rules) {
    for (const resource of violations(rule, resources)) {
      findings.push(
        createFinding({
          type: rule.type || 'IAC',
          category: rule.category || 'IAC_POLICY',
          severity: rule.severity,
          title: rule.title,
          description: rule.description || rule.title,
          repository,
          file: relativePath,
          startLine: resource.line,
          endLine: resource.line,
          cwe: rule.cwe || null,
          source: 'IAC_POLICY',
          ruleId: rule.id,
          remediation: rule.remediation || null,
          // The resource, not a line of text. A policy finding is about a
          // resource, and naming it is what makes the finding actionable in a
          // file with forty of them.
          evidence: `${relativePath} — ${resource.type}.${resource.name} does not satisfy ${rule.id}`,
          metadata: {
            snippet: `${resource.type}.${resource.name}`,
            resourceType: resource.type,
            resourceName: resource.name,
            confidence: rule.confidence || 'HIGH',
            engine: 'iac-policy',
            owasp: rule.owasp || null,
            provenance: rule.provenance || null,
            ruleBundleVersion: rule._bundleVersion || null,
            ruleSource: rule.source === 'user' ? 'user' : 'bundled',
          },
        })
      );
    }
  }

  return findings;
}

const scanner = {
  id: 'IAC_POLICY',
  type: 'IAC',
  produces: ['IAC'],
  name: 'IaC policies (structured)',
  requires: null,

  async isAvailable({ ruleSet } = {}) {
    // Whether the engine can run does not depend on rules; those arrive per scan.
    if (!ruleSet) return { available: true, version: 'rules supplied per scan', hint: null };
    const bundle = resolveRuleSet(ruleSet);
    const count = bundle.rules.filter(r => r.engine === 'iac-policy').length;
    return {
      available: true,
      version: `rules ${bundle.version || 'none'} (${bundle.source}) · ${count} policies`,
      hint: count ? null : 'no IaC policies in the current bundle',
    };
  },

  prepare({ ruleSet }) {
    const bundle = resolveRuleSet(ruleSet);
    const rules = bundle.rules
      .filter(r => r.engine === 'iac-policy' && r.definition)
      .map(r => ({ ...r, _bundleVersion: bundle.version }));

    if (!rules.length) {
      // Skipped, not a clean pass. An engine with no policies checks nothing,
      // and a zero that looks like a result is the failure this codebase
      // keeps trying to eliminate.
      return { skipped: true, reason: `no IaC policies in bundle ${bundle.version || '(none)'}` };
    }
    return { bundle, rules, analysed: 0, resourceCount: 0 };
  },

  scanFile(file, ctx, { repository }) {
    // The name test comes before the read, and reading is lazy, so the Java
    // and JavaScript that make up most of a repository cost this scanner
    // nothing even though it now shares the walk.
    if (!TERRAFORM.test(file.relPath) && !YAML_FILE.test(file.relPath)) return [];
    if (file.size > MAX_FILE_BYTES) return [];

    // The resource count is cached alongside the findings. It is how this
    // scanner reports what it actually understood — a Terraform repository
    // where the parser produced nothing would otherwise report a confident
    // zero — so losing it on a cache hit would make a cached scan look like a
    // parser failure.
    const hit = ctx.cache && ctx.cache.getEntry(file);
    if (hit) {
      const resourceCount = (hit.extras && hit.extras.resources) || 0;
      if (resourceCount) { ctx.analysed += 1; ctx.resourceCount += resourceCount; }
      return hit.findings;
    }

    const text = file.text;
    if (text === null) return [];

    const resources = resourcesIn(text, file.relPath);
    if (!resources.length) {
      // Cached as "nothing here", so a YAML file that is not a manifest is not
      // re-parsed on every scan.
      if (ctx.cache) ctx.cache.set(file, [], { resources: 0 });
      return [];
    }

    ctx.analysed += 1;
    ctx.resourceCount += resources.length;
    const findings = scanContent(text, file.relPath, repository, ctx.rules);
    if (ctx.cache) ctx.cache.set(file, findings, { resources: resources.length });
    return findings;
  },

  finish(ctx, corpus) {
    return {
      filesAnalysed: ctx.analysed,
      // How much was actually understood. A repository of Terraform where the
      // parser produced no resources would otherwise report a confident zero.
      resources: ctx.resourceCount,
      policies: ctx.rules.length,
      ruleBundle: ctx.bundle.version,
      truncated: corpus.truncated,
      truncatedReason: corpus.truncatedReason,
    };
  },

  async scan(options) {
    return runOverOwnCorpus(this, options);
  },
};

module.exports = { scanner, scanContent, resourcesIn, resourcesFromYaml };
