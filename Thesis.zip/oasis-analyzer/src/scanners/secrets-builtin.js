'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createFinding } = require('../finding');
const { PATTERNS, isPlaceholder, shannonEntropy } = require('../secret-patterns');
const { relativeToRepo } = require('../paths');
const { walk, shouldSkipFile, runOverOwnCorpus } = require('../corpus');
const { resolveRuleSet } = require('../rules');
const { globToRegExp } = require('../ignore');

// Secret scanning with no external tooling.
//
// Gitleaks is better and is wired up separately, but it has to be installed.
// This runs everywhere, which matters more than being exhaustive: a scanner
// that needs `brew install` before it finds the AWS key someone committed last
// week will not be there the week it happens.
//
// THE SECRET ITSELF IS NEVER STORED OR LOGGED. A finding carries a SHA-256 of
// the credential (for deduplication) and a masked preview (for recognising it).
// Writing the value into the findings file would turn a security tool into a
// second copy of the leak.

const MAX_LINE_LENGTH = 4000;

// Masks the middle, keeping enough at each end to recognise which credential it
// is without reproducing it.
function maskSecret(secret) {
  if (secret.length <= 8) return '*'.repeat(secret.length);
  return `${secret.slice(0, 4)}${'*'.repeat(Math.min(12, secret.length - 8))}${secret.slice(-4)}`;
}

function hashSecret(secret) {
  return crypto.createHash('sha256').update(secret).digest('hex');
}

/**
 * Secret rules carried in the signed bundle, compiled into the shape the
 * built-in table uses.
 *
 * This is what lets the ~220 Gitleaks rules ship and update without a release,
 * alongside the 15 hand-written ones. They run HERE rather than in the generic
 * line-pattern engine for one reason: this engine masks and hashes what it
 * finds and never stores the plaintext. A secret matched by the wrong engine
 * would be written into the findings file verbatim.
 */
function bundleSecretRules(ruleSet) {
  // A missing rule set throws: a scan that silently ran no secret rules would
  // look exactly like a clean repository.
  const bundle = resolveRuleSet(ruleSet);

  const compiled = [];
  for (const rule of bundle.rules) {
    if (rule.engine !== 'secret' || !rule.pattern) continue;
    try {
      const flags = `${rule.patternFlags || ''}g`.replace(/(.)(?=.*\1)/g, '');
      compiled.push({
        id: rule.id,
        name: rule.title || rule.id,
        pattern: new RegExp(rule.pattern, flags),
        severity: rule.severity || 'HIGH',
        entropyFloor: typeof rule.entropy === 'number' ? rule.entropy : null,
        // Gitleaks uses keywords as a cheap prefilter — if none appear in the
        // file the regex is never run. With 220 rules over a large repository
        // that is most of the difference between a fast scan and an unusable
        // one.
        keywords: Array.isArray(rule.keywords) ? rule.keywords : [],
        secretGroup: rule.secretGroup || null,
        allowlist: rule.allowlist
          ? {
              regexes: (rule.allowlist.regexes || []).map(r => {
                try { return new RegExp(r, 'i'); } catch (_) { return null; }
              }).filter(Boolean),
              paths: (rule.allowlist.paths || []).map(p => {
                try { return new RegExp(p, 'i'); } catch (_) { return null; }
              }).filter(Boolean),
              stopwords: (rule.allowlist.stopwords || []).map(w => String(w).toLowerCase()),
            }
          : null,
        category: rule.category,
        description: rule.description,
        remediation: rule.remediation,
        cwe: rule.cwe || 'CWE-798',
        verifiable: false,
        provenance: rule.provenance || null,
        source: rule.source || null,
      });
    } catch (_) {
      // A rule that will not compile is dropped rather than failing the scan.
      // The build already rejects these; this is the runtime backstop.
    }
  }
  return compiled;
}

// Upstream allowlists exist because the upstream project already knows these
// matches are noise. Honouring them is most of the difference between 220
// useful rules and 220 rules people turn off.
function isAllowlisted(rule, secret, relativePath) {
  const allow = rule.allowlist;
  if (!allow) return false;
  if (allow.paths.some(p => p.test(relativePath))) return true;
  if (allow.regexes.some(r => r.test(secret))) return true;
  const lower = secret.toLowerCase();
  return allow.stopwords.some(w => lower.includes(w));
}

function scanContent(content, relativePath, repository, bundleRules = []) {
  const findings = [];
  const lines = content.split('\n');
  const haystack = bundleRules.length ? content.toLowerCase() : '';

  for (const rule of [...PATTERNS, ...bundleRules]) {
    // The keyword prefilter. Skipping a rule whose keywords appear nowhere in
    // the file avoids running its regex over every line for nothing.
    if (rule.keywords && rule.keywords.length && !rule.keywords.some(k => haystack.includes(k))) {
      continue;
    }
    // Regexes in the table are global and therefore stateful; reset before use
    // or every second scan silently starts mid-string.
    rule.pattern.lastIndex = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.length > MAX_LINE_LENGTH) continue;

      let match;
      rule.pattern.lastIndex = 0;
      while ((match = rule.pattern.exec(line)) !== null) {
        const secret = (rule.secretGroup ? match[rule.secretGroup] : null) || match[1] || match[0];
        if (!secret || isPlaceholder(secret)) continue;
        if (isAllowlisted(rule, secret, relativePath)) continue;

        // Some rules only fire above an entropy floor, so that
        // `password = "see the wiki"` does not become a critical finding.
        if (rule.entropyFloor && shannonEntropy(secret) < rule.entropyFloor) continue;

        const finding = createFinding({
            type: 'SECRET',
            category: rule.category || rule.id.toUpperCase().replace(/-/g, '_'),
            severity: rule.severity,
            title: rule.name,
            description:
              rule.description
              || `A ${rule.name.toLowerCase()} appears in source. Treat it as compromised: `
                 + 'rotate the credential first, then remove it from the file and from git history.',
            repository,
            file: relativePath,
            startLine: i + 1,
            cwe: rule.cwe || 'CWE-798',
            source: 'BUILTIN_SECRETS',
            ruleId: rule.id,
            remediation:
              rule.remediation
              || 'Rotate the credential at its provider, move the value into the app\'s '
                 + 'configuration or a secret manager, and purge it from git history.',
            evidence: `${relativePath}:${i + 1} — ${maskSecret(secret)}`,
            metadata: {
              // The hash gives deduplication something stable to key on without
              // the value travelling with it.
              secretHash: hashSecret(secret),
              masked: maskSecret(secret),
              entropy: Math.round(shannonEntropy(secret) * 100) / 100,
              verifiable: rule.verifiable,
              // Nothing claims to be verified until secret-verify.js has asked
              // the provider, which only happens when the operator opts in.
              verified: false,
              // Which upstream rule set found it, where the rule came from.
              provenance: rule.provenance || null,
              ruleSource: rule.source === 'user' ? 'user' : 'bundled',
            },
        });

        // The plaintext, carried on a NON-ENUMERABLE field.
        //
        // Validity checking needs the credential, and the only moment it is
        // available is now — it is deliberately never stored. Non-enumerable
        // means JSON.stringify skips it, so it cannot reach the findings file,
        // a log line, or an API response even by accident. The orchestrator
        // reads it during the scan and it dies with the scan.
        Object.defineProperty(finding, '_plaintext', { value: secret, enumerable: false });
        findings.push(finding);

        // One finding per rule per line. A line matching the same rule twice is
        // almost always one credential caught by an overlapping pattern.
        break;
      }
    }
  }

  return findings;
}

const scanner = {
  id: 'BUILTIN_SECRETS',
  type: 'SECRET',
  name: 'Built-in secret scanner',
  requires: null,

  async isAvailable() {
    return { available: true, version: 'built-in', hint: null };
  },

  // ── Shared-corpus hooks ──────────────────────────────────────────────────
  //
  // prepare/scanFile/finish let this scanner share ONE walk and ONE read with
  // the other content scanners instead of doing its own. `scan()` below is the
  // same three steps driven over a private walk, so running it alone behaves
  // exactly as it always did.

  prepare({ ruleSet }) {
    // Loaded once per scan, not per file: compiling 220 regexes for every file
    // in a repository would dominate the run.
    const bundleRules = bundleSecretRules(ruleSet);
    return { bundleRules, scanned: 0, skipped: 0 };
  },

  scanFile(file, ctx, { repository }) {
    // Cache first: an unchanged file cannot produce a different answer, and
    // this scanner is the most expensive one in a scan (2.8s of regex over a
    // 1,150-file repository). The hit still counts as scanned — it WAS scanned,
    // just previously — so the coverage panel does not report a collapse in
    // what was examined the first time the cache does its job.
    const cached = ctx.cache && ctx.cache.get(file);
    if (cached) { ctx.scanned += 1; return cached; }

    const content = file.text;
    if (content === null) { ctx.skipped += 1; return []; }
    // A binary carries no readable credential and costs the whole budget.
    if (file.binary) { ctx.skipped += 1; return []; }

    ctx.scanned += 1;
    const findings = scanContent(content, file.relPath, repository, ctx.bundleRules);
    // Files holding a live credential decline to cache themselves — the
    // plaintext the verifier needs cannot survive JSON.
    if (ctx.cache) ctx.cache.set(file, findings);
    return findings;
  },

  finish(ctx, corpus) {
    return {
      filesScanned: ctx.scanned,
      filesSkipped: ctx.skipped,
      // Split, so "we check for 236 kinds of credential" is visible and a
      // bundle that failed to load shows up as a number that dropped.
      rules: PATTERNS.length + ctx.bundleRules.length,
      builtInRules: PATTERNS.length,
      bundleRules: ctx.bundleRules.length,
      // Surfaced rather than silently truncating: a repository that hits the
      // cap has been only partly scanned, and the UI must not imply otherwise.
      truncated: corpus.truncated,
      truncatedReason: corpus.truncatedReason,
    };
  },

  async scan(options) {
    return runOverOwnCorpus(this, options);
  },
};

// walk/shouldSkipFile are re-exported: five modules import them from here,
// and they now live in ../corpus where the shared pass uses them.
module.exports = { scanner, scanContent, bundleSecretRules, isAllowlisted, maskSecret, hashSecret, walk, shouldSkipFile };