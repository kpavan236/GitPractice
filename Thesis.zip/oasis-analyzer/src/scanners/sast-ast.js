'use strict';
const fs = require('fs');
const path = require('path');
const { createFinding } = require('../finding');
const { relativeToRepo } = require('../paths');
const { parseInlineIgnores, inlineIgnoreFor } = require('../ignore');
const { TAINT_SOURCES } = require('../ast/taint');
const engine = require('../ast/engine');
const { resolveRuleSet } = require('../rules');
const { runOverOwnCorpus } = require('../corpus');

// SAST over a real syntax tree, driven by the signed rule bundle.
//
// The regex scanner it supersedes matched text on a line. This matches
// STRUCTURE: a rule says "a method invocation named executeQuery whose argument
// list contains X", and a string literal or a comment containing the same words
// cannot match, because they are different nodes.
//
// Both engines are live during the port. A bundle rule with a `query` runs
// here; one with a `pattern` runs in sast-builtin.js. They dedupe against each
// other through the shared fingerprint, so a rule ported from one to the other
// produces the same finding rather than a duplicate.

const MAX_FILE_BYTES = 1024 * 1024;

const SEVERITY_LADDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];

// A low-confidence match is reported one band down, so an uncertain guess
// cannot outrank a certain finding.
function adjustSeverity(severity, confidence) {
  if (confidence !== 'LOW') return severity;
  const i = SEVERITY_LADDER.indexOf(severity);
  return i === -1 ? severity : SEVERITY_LADDER[Math.min(SEVERITY_LADDER.length - 1, i + 1)];
}

// Every identifier inside a subtree.
//
// This is where the AST engine earns its place. A string literal is ONE leaf
// node — there are no identifier nodes inside it — so collecting identifiers
// structurally cannot be fooled by a variable name that happens to appear in
// SQL text. The regex engine flagged a correctly parameterised
// `prepareStatement("SELECT * FROM t WHERE n = ?")` because the tainted
// variable was called `n` and the column was too. That class of false positive
// is simply unavailable here.
function identifiersIn(node) {
  const names = [];
  const visit = n => {
    if (n.type === 'identifier' || n.type === 'property_identifier' || n.type === 'field_identifier') {
      names.push(n.text);
    }
    for (let i = 0; i < n.namedChildCount; i++) visit(n.namedChild(i));
  };
  visit(node);
  return names;
}

// A subtree's text with every string literal removed.
//
// Source patterns are dotted expressions — `request.`, `req.params.` — so they
// have to be matched against text, not against bare identifiers. But raw text
// reintroduces the false positive that string literals cause. Dropping the
// literals gives both: `req.query.msg` still matches, while the `n` inside
// "WHERE n = ?" is simply not there to match.
// A template literal is NOT wholly a string: `${...}` inside it is executable
// code, and it is the interpolation that makes
// db.query(`SELECT ... ${req.params.id}`) an injection. Strip the literal
// FRAGMENTS and keep the substitutions.
const STRING_NODES = new Set([
  'string_literal', 'string', 'string_fragment', 'text_block', 'concatenated_string',
]);

function textWithoutStrings(node) {
  if (STRING_NODES.has(node.type)) return '';
  if (node.namedChildCount === 0) return node.text;

  let out = '';
  let cursor = node.startIndex;
  for (let i = 0; i < node.namedChildCount; i++) {
    const child = node.namedChild(i);
    // Punctuation and operators between named children — the dots that make a
    // member expression readable as one.
    out += node.text.slice(cursor - node.startIndex, child.startIndex - node.startIndex);
    out += textWithoutStrings(child);
    cursor = child.endIndex;
  }
  out += node.text.slice(cursor - node.startIndex);
  return out;
}

// Whether anything attacker-controlled reaches this call, judged on the
// argument nodes rather than on a line of text.
function nodeIsTainted(match, taintedNames) {
  const args = match.captures.args || match.captures.value || match.node;

  // A source called directly in the arguments: request.getParameter(...).
  if (TAINT_SOURCES.test(textWithoutStrings(args))) return 'direct';
  // A variable a source flowed into earlier. Identifier NODES, so a name that
  // merely appears inside a SQL string cannot match.
  if (identifiersIn(args).some(name => taintedNames.has(name))) return 'variable';
  return null;
}

// Variables assigned from a taint source, collected from the tree rather than
// by scanning lines. Still intraprocedural — a declaration anywhere in the file
// taints the name — but it no longer depends on assignment syntax being
// recognisable by regex.
async function taintedVariables(tree, language) {
  const names = new Set();
  const queries = {
    java: '(local_variable_declaration declarator: (variable_declarator name: (identifier) @name value: (_) @value))',
    javascript: '(variable_declarator name: (identifier) @name value: (_) @value)',
    typescript: '(variable_declarator name: (identifier) @name value: (_) @value)',
    python: '(assignment left: (identifier) @name right: (_) @value)',
  };
  const query = queries[language];
  if (!query) return names;

  const assignments = (await engine.runQuery(tree, language, query))
    .filter(m => m.captures.name && m.captures.value)
    .map(m => ({
      name: m.captures.name.text,
      identifiers: identifiersIn(m.captures.value),
      text: textWithoutStrings(m.captures.value),
    }));

  // Propagated to a fixed point, because taint moves through intermediate
  // variables:
  //
  //   String n   = request.getParameter("n");   // tainted by a source
  //   String sql = "SELECT ... " + n;           // tainted by n
  //   stmt.executeQuery(sql);                   // the sink sees sql
  //
  // A single pass marks only `n` and misses the finding entirely — which is
  // exactly the realistic shape this engine exists to catch. Bounded, so a
  // cyclic assignment cannot spin.
  for (let pass = 0; pass < 10; pass++) {
    let added = false;
    for (const a of assignments) {
      if (names.has(a.name)) continue;
      const tainted =
        TAINT_SOURCES.test(a.text) ||
        a.identifiers.some(id => names.has(id));
      if (tainted) {
        names.add(a.name);
        added = true;
      }
    }
    if (!added) break;
  }
  return names;
}

// Two coarse filters a tree-sitter query cannot express, applied around the
// structural match rather than instead of it.
//
//   negate           text anywhere in the FILE that means the risky construct
//                    was handled — a factory whose setFeature call disables
//                    external entities, an MD5 used as a cache key. Query
//                    predicates cannot see outside the matched node.
//   requiresContext  text near the match that establishes it matters — a
//                    Random used for a token rather than for a retry delay.
//
// Both are regexes over source text, which is exactly the imprecision the AST
// engine was meant to remove. They are acceptable HERE because they only ever
// remove or gate a match that already matched structurally: a sloppy negate
// loses a finding, it cannot invent one.
function passesTextFilters(rule, source, lines, startLine) {
  if (rule.negate && new RegExp(rule.negate, 'i').test(source)) return false;

  if (rule.requiresContext) {
    const window = lines.slice(Math.max(0, startLine - 4), startLine + 3).join('\n');
    if (!new RegExp(rule.requiresContext, 'i').test(window)) return false;
  }
  return true;
}

async function scanSource(source, relativePath, repository, rules) {
  const language = engine.languageFor(path.extname(relativePath));
  if (!language) return [];

  // TypeScript is parsed by its own grammar but has no rules of its own, and a
  // strict language match meant every .ts and .tsx file was parsed, matched
  // against nothing, and reported clean. That is the exact failure this design
  // exists to prevent: silence that reads as a pass. The TypeScript grammar is
  // a superset of JavaScript's, so the JavaScript rules compile and match
  // against a TypeScript tree — verified for all of them by the test below.
  const RULE_FALLBACK = { typescript: ['javascript'] };
  const languages = [language, ...(RULE_FALLBACK[language] || [])];
  const applicable = rules.filter(r => r.query && languages.includes(r.language));
  if (!applicable.length) return [];

  const tree = await engine.parse(source, language);
  if (!tree) return [];

  try {
    const tainted = await taintedVariables(tree, language);
    const inlineIgnores = parseInlineIgnores(source);
    const lines = source.split('\n');
    const findings = [];

    for (const rule of applicable) {
      for (const match of await engine.runQuery(tree, language, rule.query)) {
        let taintedVia = null;
        if (rule.requiresTaint) {
          taintedVia = nodeIsTainted(match, tainted);
          if (!taintedVia) continue;
        }

        const startLine = match.startLine;
        if (!passesTextFilters(rule, source, lines, startLine)) continue;
        if (inlineIgnoreFor(inlineIgnores, { startLine, detections: [{ ruleId: rule.id }], category: rule.category })) {
          continue;
        }

        findings.push(
          createFinding({
            type: 'SAST',
            category: rule.category || 'UNCATEGORISED',
            severity: adjustSeverity(rule.severity, rule.confidence),
            title: rule.title,
            description:
              (rule.description || rule.title) +
              (rule.confidence === 'LOW'
                ? ' This rule is low confidence — it matches a risky shape without proving the value is attacker-controlled.'
                : ''),
            repository,
            file: relativePath,
            startLine,
            endLine: match.endLine,
            cwe: rule.cwe || null,
            source: 'AST_SAST',
            ruleId: rule.id,
            remediation: rule.remediation || null,
            evidence: `${relativePath}:${startLine} — ${match.text.split('\n')[0].trim().slice(0, 200)}`,
            metadata: {
              // The matched node, normalised into the fingerprint, so the
              // finding follows the code when it moves.
              snippet: match.text.split('\n')[0].trim(),
              confidence: rule.confidence || 'MEDIUM',
              tainted: Boolean(rule.requiresTaint),
              taintedVia,
              cvssVector: rule.cvss || null,
              owasp: rule.owasp || null,
              engine: 'tree-sitter',
              ruleBundleVersion: rule._bundleVersion || null,
              ruleSource: rule.source === 'user' ? 'user' : 'bundled',
            },
          })
        );
      }
    }
    return findings;
  } finally {
    // WASM memory is not garbage collected. A repository scan parses thousands
    // of files, and leaking every tree exhausts the heap well before finishing.
    tree.delete();
  }
}

const scanner = {
  id: 'AST_SAST',
  type: 'SAST',
  name: 'AST SAST (tree-sitter)',
  requires: null,

  async isAvailable({ ruleSet } = {}) {
    const languages = engine.availableLanguages();
    if (!languages.length) {
      return { available: false, version: null, hint: 'no tree-sitter grammars are bundled with this build' };
    }
    // Whether the engine can run does not depend on rules; those arrive per scan.
    if (!ruleSet) return { available: true, version: `rules supplied per scan · ${languages.join(' ')}`, hint: null };
    const bundle = resolveRuleSet(ruleSet);
    return {
      available: true,
      version: `rules ${bundle.version || 'none'} (${bundle.source}) · ${languages.join(' ')}`,
      hint: null,
    };
  },

  prepare({ ruleSet }) {
    const bundle = resolveRuleSet(ruleSet);
    const rules = bundle.rules
      .filter(r => r.query)
      .map(r => ({ ...r, _bundleVersion: bundle.version }));

    if (!rules.length) {
      // Reported rather than returning a clean-looking zero: no rules means
      // nothing was checked.
      return { skipped: true, reason: `no AST rules in bundle ${bundle.version || '(none)'}` };
    }
    return { bundle, rules, analysed: 0 };
  },

  // Async, unlike the other scanners': tree-sitter parses across a WASM
  // boundary. The shared walk awaits each file for exactly this.
  async scanFile(file, ctx, { repository }) {
    if (!engine.languageFor(path.extname(file.absPath))) return [];
    if (file.size > MAX_FILE_BYTES) return [];

    // Rebuilding a syntax tree is the expensive part of this scanner, and an
    // unchanged file parses to the same tree every time.
    const cached = ctx.cache && ctx.cache.get(file);
    if (cached) { ctx.analysed += 1; return cached; }

    const source = file.text;
    if (source === null) return [];

    ctx.analysed += 1;
    const findings = await scanSource(source, file.relPath, repository, ctx.rules);
    if (ctx.cache) ctx.cache.set(file, findings);
    return findings;
  },

  finish(ctx, corpus) {
    return {
      filesAnalysed: ctx.analysed,
      rules: ctx.rules.length,
      ruleBundle: ctx.bundle.version,
      ruleSource: ctx.bundle.source,
      // Rules that quietly stopped updating are a silent failure mode.
      ruleAgeDays: ctx.bundle.ageDays,
      rejectedBundles: ctx.bundle.rejected,
      languages: engine.availableLanguages().join(' '),
      truncated: corpus.truncated,
      truncatedReason: corpus.truncatedReason,
    };
  },

  async scan(options) {
    return runOverOwnCorpus(this, options);
  },
};

module.exports = { scanner, scanSource, adjustSeverity, taintedVariables, identifiersIn, textWithoutStrings, passesTextFilters };
