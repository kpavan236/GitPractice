'use strict';
const fs = require('fs');
const { createFinding } = require('../finding');
const { relativeToRepo } = require('../paths');
const { parseInlineIgnores, inlineIgnoreFor, globToRegExp } = require('../ignore');
const { resolveRuleSet } = require('../rules');
const { runOverOwnCorpus } = require('../corpus');
const { adjustSeverity, passesTextFilters } = require('./sast-ast');

// Line-pattern rules — the engine for everything tree-sitter cannot parse.
//
// The AST engine is strictly better where a grammar exists, and nothing here
// tries to compete with it. It exists because the grammar set is four languages
// and the file types that carry the most misconfiguration are not among them:
// Dockerfiles, Terraform, Kubernetes manifests, CI definitions, .env files. A
// Dockerfile grammar is 400 KB to detect `USER root`, which is one regex.
//
// This also closes a hole. rule-bundle.js has always accepted a rule with
// `pattern` instead of `query` — the format was designed for both — but the
// engine that ran them was retired when the AST engine landed. Until this file,
// a `pattern` rule validated, signed, shipped, and then matched nothing, which
// is the worst possible failure for a security rule: it looks present and finds
// nothing.
//
// The trade-off is stated plainly because it decides which engine a new rule
// belongs in: a regex cannot tell code from a comment, a value from the string
// that mentions it, or a call from its own documentation. The mitigations below
// (comment skipping, `negate`, `requiresContext`) narrow that, they do not
// remove it. A rule for Java, JavaScript, TypeScript, or Python should be an
// AST `query` — always. Reach for `pattern` when there is no grammar.

const MAX_FILE_BYTES = 1024 * 1024;

// A minified bundle on one 2 MB line will run every rule's regex against the
// whole thing. Nothing useful is ever found there, and a pathological rule
// would hang the scan.
const MAX_LINE_LENGTH = 4000;

// Comment leaders for the file types this engine covers. A pattern matching
// inside a comment is a false positive, and in these formats — where half the
// file is often commented-out configuration — it is the DOMINANT false
// positive: a Terraform file that documents `cidr_blocks = ["0.0.0.0/0"]` in a
// "do not do this" comment would otherwise be flagged for the very warning it
// carries. A rule that genuinely wants comments sets `includeComments`.
const COMMENT_RE = /^\s*(?:#|\/\/|--|;|\*|<!--)/;

/**
 * Compiles a bundle rule for execution, or returns null if it cannot run.
 *
 * A rule that does not compile is dropped rather than throwing, matching the
 * AST engine: one malformed rule disables itself, it does not stop the scan.
 * The build (tools/build-rules.js) is where a bad rule is supposed to be
 * caught, and it rejects the same things this drops.
 */
function compileRule(rule) {
  if (!rule || !rule.pattern) return null;

  // Secret rules also carry a `pattern`, and they are NOT ours to run. They are
  // executed by the secrets engine, which masks and hashes what it finds; this
  // engine writes the matched line into the finding as evidence, so running a
  // secret rule here would put the credential in plaintext into the findings
  // file and turn a security tool into a second copy of the leak.
  if (rule.engine === 'secret') return null;

  // `files` is REQUIRED for a pattern rule and deliberately has no default.
  // An AST rule is scoped by its language — the grammar simply will not parse
  // anything else — but a regex has no such limit, so a rule without a glob
  // would run against every file in the repository. `USER root` is a Dockerfile
  // finding and a false positive in a README.
  if (!rule.files) return null;

  const globs = (Array.isArray(rule.files) ? rule.files : [rule.files]).map(String);

  try {
    return {
      ...rule,
      _match: globs.map(globToRegExp),
      // Case-insensitive by default, consistent with `negate` and
      // `requiresContext`. Dockerfile instructions are conventionally
      // uppercase but `user root` is equally valid, and a rule that misses the
      // lowercase spelling is a rule that misses the finding.
      _re: new RegExp(rule.pattern, rule.caseSensitive ? '' : 'i'),
    };
  } catch (_) {
    return null;
  }
}

function rulesForPath(rules, relativePath) {
  return rules.filter(r => r._match.some(m => m.test(relativePath)));
}

/**
 * Runs pattern rules over one file's text.
 *
 * Exported so the rule corpus can exercise a rule against a string, which is
 * what makes a detect/clean fixture pair cheap enough that every rule has one.
 */
function scanContent(source, relativePath, repository, rules) {
  const applicable = rulesForPath(rules, relativePath);
  if (!applicable.length) return [];

  const lines = source.split('\n');
  const inlineIgnores = parseInlineIgnores(source);
  const findings = [];

  for (const rule of applicable) {
    // File-wide filters are checked once per rule rather than per line: a
    // `negate` that means "this file already handles it" cannot become true
    // halfway down the file.
    if (rule.negate && new RegExp(rule.negate, 'i').test(source)) continue;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line || line.length > MAX_LINE_LENGTH) continue;
      if (!rule.includeComments && COMMENT_RE.test(line)) continue;
      if (!rule._re.test(line)) continue;

      const startLine = i + 1;
      // negate is already handled above; this applies requiresContext with the
      // same window semantics the AST engine uses, so a rule behaves the same
      // way in either engine.
      if (!passesTextFilters({ requiresContext: rule.requiresContext }, source, lines, startLine)) continue;
      if (inlineIgnoreFor(inlineIgnores, { startLine, detections: [{ ruleId: rule.id }], category: rule.category })) {
        continue;
      }

      const snippet = line.trim().slice(0, 200);

      findings.push(
        createFinding({
          // A pattern rule declares what KIND of finding it produces. Without
          // this every Dockerfile and Terraform finding would file itself under
          // SAST, and "we have no IaC coverage" would be indistinguishable from
          // "our IaC findings are mislabelled".
          type: rule.type || 'SAST',
          category: rule.category || 'UNCATEGORISED',
          severity: adjustSeverity(rule.severity, rule.confidence),
          title: rule.title,
          description:
            (rule.description || rule.title) +
            (rule.confidence === 'LOW'
              ? ' This rule is low confidence — it matches text on a line, without parsing the file.'
              : ''),
          repository,
          file: relativePath,
          startLine,
          endLine: startLine,
          cwe: rule.cwe || null,
          source: 'PATTERN_SAST',
          ruleId: rule.id,
          remediation: rule.remediation || null,
          evidence: `${relativePath}:${startLine} — ${snippet}`,
          metadata: {
            snippet,
            confidence: rule.confidence || 'MEDIUM',
            cvssVector: rule.cvss || null,
            owasp: rule.owasp || null,
            // Named so a reader can tell at a glance why a finding is less
            // precise than its neighbour from the same scan.
            engine: 'pattern',
            ruleBundleVersion: rule._bundleVersion || null,
            // Whether the rule behind this finding is signed and shipped with
            // the app, or an unsigned rule from a user's own pack — a
            // different trust question than which scanner ran it.
            ruleSource: rule.source === 'user' ? 'user' : 'bundled',
          },
        })
      );
    }
  }

  return findings;
}

const scanner = {
  id: 'PATTERN_SAST',
  type: 'IAC',
  // Two capabilities from one engine. The orchestrator credits coverage per
  // TYPE, so declaring both is what stops an IaC-only scan reporting SAST as
  // unchecked and vice versa.
  produces: ['IAC', 'SAST'],
  name: 'Pattern rules (IaC · config)',
  requires: null,

  async isAvailable({ ruleSet } = {}) {
    // Whether the engine can run does not depend on rules; those arrive per scan.
    if (!ruleSet) return { available: true, version: 'rules supplied per scan', hint: null };
    const bundle = resolveRuleSet(ruleSet);
    const count = bundle.rules.filter(r => r.pattern && r.engine !== 'secret').length;
    return {
      available: true,
      version: `rules ${bundle.version || 'none'} (${bundle.source}) · ${count} pattern rules`,
      // Available with zero rules is a real state — an older bundle that
      // predates pattern rules — and it finds nothing. Saying so beats a green
      // tick over an engine with nothing to run.
      hint: count ? null : 'no pattern rules in the current bundle',
    };
  },

  prepare({ ruleSet }) {
    const bundle = resolveRuleSet(ruleSet);
    const rules = bundle.rules
      .filter(r => r.pattern && r.engine !== 'secret')
      .map(r => compileRule({ ...r, _bundleVersion: bundle.version }))
      .filter(Boolean);

    if (!rules.length) {
      // Skipped, not "completed with zero findings". The orchestrator reads
      // this to decide whether IaC was actually covered, and a clean-looking
      // zero from an engine with no rules is the silence this codebase keeps
      // trying to eliminate.
      return { skipped: true, reason: `no pattern rules in bundle ${bundle.version || '(none)'}` };
    }
    return { bundle, rules, analysed: 0 };
  },

  scanFile(file, ctx, { repository }) {
    // The glob test comes before the read, and `file.text` is lazy, so a file
    // no rule matches still costs this scanner nothing — the saving its own
    // comments called "the whole cost of this scanner" survives the shared walk.
    if (!rulesForPath(ctx.rules, file.relPath).length) return [];
    if (file.size > MAX_FILE_BYTES) return [];

    const cached = ctx.cache && ctx.cache.get(file);
    if (cached) { ctx.analysed += 1; return cached; }

    const source = file.text;
    if (source === null) return [];

    ctx.analysed += 1;
    const findings = scanContent(source, file.relPath, repository, ctx.rules);
    if (ctx.cache) ctx.cache.set(file, findings);
    return findings;
  },

  finish(ctx, corpus) {
    return {
      filesAnalysed: ctx.analysed,
      rules: ctx.rules.length,
      ruleBundle: ctx.bundle.version,
      ruleSource: ctx.bundle.source,
      ruleAgeDays: ctx.bundle.ageDays,
      truncated: corpus.truncated,
      truncatedReason: corpus.truncatedReason,
    };
  },

  async scan(options) {
    return runOverOwnCorpus(this, options);
  },
};

module.exports = { scanner, scanContent, compileRule, rulesForPath, COMMENT_RE };