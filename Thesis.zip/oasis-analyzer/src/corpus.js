'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { relativeToRepo } = require('./paths');

// One pass over a repository, shared by every content scanner.
//
// The walk itself was already shared code — pattern-sast and iac-policy import
// it from secrets-builtin. It was simply being RUN four times, once per
// scanner, and each run read every file again. A scan of a large repository
// therefore walked the same directories four times and pulled the same bytes
// off disk four times to hand them to four pure functions.
//
// This inverts it: walk once, and offer each file to every scanner in turn.
//
// TWO THINGS KEEP IT HONEST, and both are load-bearing:
//
//   Reading is LAZY. pattern-sast skips files that match no rule glob and its
//   comments call that "the whole cost of this scanner". If the corpus read
//   eagerly, running that scanner alone would get slower, not faster. `text` is
//   a getter: no consumer, no read.
//
//   Reading is CACHED PER FILE, not per corpus. Four scanners asking for the
//   same file costs one read; the text is dropped when the walk moves on. A
//   corpus that held every file would trade an I/O problem for a memory one on
//   exactly the large repositories this is meant to help.

const DEFAULT_MAX_FILES = Number(process.env.OASIS_SCAN_MAX_FILES) || 20000;

const SKIP_DIRS = new Set([
  '.git', 'node_modules', 'target', 'build', 'dist', 'out', 'vendor',
  '.gradle', '.mvn', '.idea', '.vscode', 'coverage', '__pycache__',
  '.venv', 'venv', '.next', '.nuxt', '.terraform', 'bin', 'obj',
]);

// Binary and generated files. Scanning a 40 MB jar for entropy finds nothing
// and costs the whole scan budget.
const SKIP_EXTENSIONS = new Set([
  '.jar', '.war', '.ear', '.zip', '.tar', '.gz', '.bz2', '.xz', '.7z', '.rar',
  '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.svg', '.webp', '.tiff',
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
  '.mp3', '.mp4', '.avi', '.mov', '.wav', '.woff', '.woff2', '.ttf', '.eot',
  '.class', '.o', '.so', '.dylib', '.dll', '.exe', '.bin', '.pyc',
  '.lock', '.min.js', '.map',
]);

const MAX_FILE_BYTES = 2 * 1024 * 1024;

function shouldSkipFile(name) {
  const lower = name.toLowerCase();
  if (SKIP_EXTENSIONS.has(path.extname(lower))) return true;
  // Compound extensions that path.extname() only sees the tail of.
  return lower.endsWith('.min.js') || lower.endsWith('.map') || lower.endsWith('.lock');
}

// Walks the repository, yielding scannable file paths.
function* walk(dir, root, budget) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (_) {
    return; // unreadable directory — skip rather than fail the scan
  }

  for (const entry of entries) {
    if (budget.files >= budget.maxFiles) return;
    const full = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      yield* walk(full, root, budget);
      continue;
    }
    if (!entry.isFile()) continue;
    if (shouldSkipFile(entry.name)) continue;

    let stat;
    try {
      stat = fs.statSync(full);
    } catch (_) {
      continue;
    }
    if (stat.size > MAX_FILE_BYTES || stat.size === 0) continue;

    budget.files += 1;
    yield full;
  }
}

// Visits an explicit list of repo-relative paths instead of walking the tree —
// Quick Scan's input. SKIP_DIRS is still honoured (a changed path inside
// node_modules is not something anyone asked to scan), but directories are not
// recursed into: the list is expected to already be file paths, from a git diff.
function* fileList(repoPath, files, budget) {
  for (const relPath of files) {
    if (budget.files >= budget.maxFiles) return;
    if (relPath.split('/').some(seg => SKIP_DIRS.has(seg))) continue;
    if (shouldSkipFile(path.basename(relPath))) continue;

    const full = path.join(repoPath, relPath);
    let stat;
    try {
      stat = fs.statSync(full);
    } catch (_) {
      continue; // renamed/deleted since the diff was taken
    }
    if (!stat.isFile() || stat.size > MAX_FILE_BYTES || stat.size === 0) continue;

    budget.files += 1;
    yield full;
  }
}

// Null bytes in the content mean binary, whatever the extension said.
// Reported rather than skipped: secrets-builtin skips binaries and pattern-sast
// never did, and quietly changing one scanner's coverage while speeding up
// another is not a refactor.
function looksBinary(content) {
  return content.indexOf('\0') !== -1;
}

/**
 * How many files the walk will visit.
 *
 * The denominator for a progress bar, and the only honest way to get one: the
 * walk is lazy and a repository does not know its own size. It costs a second
 * pass over the directory entries — readdir and stat, no reads — which is a
 * fraction of what scanning the same files costs, and is only paid when someone
 * is watching a bar.
 */
function countFiles(repoPath, { maxFiles = DEFAULT_MAX_FILES, files = null } = {}) {
  const budget = { files: 0, maxFiles };
  let total = 0;
  const source = files ? fileList(repoPath, files, budget) : walk(repoPath, repoPath, budget);
  // eslint-disable-next-line no-unused-vars
  for (const _ of source) total += 1;
  return total;
}

/**
 * Walks a repository once, handing each file to `visit`.
 *
 * The file handed over is lazy — `size` and `relPath` are free, `text` and
 * `sha256` cost one read between all consumers.
 *
 * ASYNC because the AST scanner's per-file work is: tree-sitter parses through
 * a WASM boundary. Awaiting each file keeps memory at one file rather than
 * collecting the whole corpus to process later, which is the trade this module
 * exists to avoid.
 *
 * @param {function}  opts.onProgress  ({file, filesScanned, filesTotal}) per
 *                                     file. Its presence is what buys the
 *                                     pre-count; without it nothing is counted.
 * @param {Array<string>} opts.files   repo-relative paths to visit instead of
 *                                     walking the tree — Quick Scan's input.
 *                                     Absent/null means the normal full walk;
 *                                     an empty array visits nothing.
 * @param {function({relPath, absPath, size, text, sha256, binary})} visit
 * @returns {Promise<{filesVisited, filesRead, bytesRead, truncated, truncatedReason}>}
 */
async function forEachFile(repoPath, { maxFiles = DEFAULT_MAX_FILES, onProgress = null, files = null } = {}, visit) {
  if (!fs.existsSync(repoPath)) {
    // Never an empty result: zero findings from a path that does not exist
    // looks exactly like a clean repository.
    throw new Error(`Repository path does not exist: ${repoPath}`);
  }

  // Counted against the same cap the walk uses, so a bar over a repository that
  // hits the limit still reaches the end instead of stalling part way.
  const filesTotal = onProgress ? countFiles(repoPath, { maxFiles, files }) : 0;

  const budget = { files: 0, maxFiles };
  let filesVisited = 0;
  let filesRead = 0;
  let bytesRead = 0;

  const source = files ? fileList(repoPath, files, budget) : walk(repoPath, repoPath, budget);
  for (const absPath of source) {
    let size = 0;
    try {
      size = fs.statSync(absPath).size;
    } catch (_) {
      continue;                      // vanished between walk and stat
    }

    let text;                        // undefined = not read yet, null = unreadable
    let sha256;
    let binary;

    const file = {
      absPath,
      // POSIX-relative: a Windows separator would fingerprint the same finding
      // differently from the same scan run on macOS, splitting one issue in two.
      relPath: relativeToRepo(repoPath, absPath),
      size,

      get text() {
        if (text === undefined) {
          try {
            text = fs.readFileSync(absPath, 'utf8');
            filesRead += 1;
            bytesRead += size;
          } catch (_) {
            text = null;             // deleted mid-scan by a build running alongside
          }
        }
        return text;
      },

      get sha256() {
        if (sha256 === undefined) {
          const content = file.text;
          sha256 = content === null ? null : crypto.createHash('sha256').update(content).digest('hex');
        }
        return sha256;
      },

      get binary() {
        if (binary === undefined) {
          const content = file.text;
          binary = content === null ? false : looksBinary(content);
        }
        return binary;
      },
    };

    filesVisited += 1;
    // Reported BEFORE the file is scanned, so what is on screen is the file
    // currently being worked on rather than the one just finished — which is
    // what a reader looking for the file a scan is stuck on needs.
    if (onProgress) onProgress({ file: file.relPath, filesScanned: filesVisited, filesTotal });
    await visit(file);
  }

  const truncated = budget.files >= maxFiles;
  return {
    filesVisited,
    filesRead,
    bytesRead,
    // Reported, never silent — a partial scan must not read as a clean one.
    truncated,
    truncatedReason: truncated
      ? `stopped after ${maxFiles} files — raise OASIS_SCAN_MAX_FILES to scan the whole repository`
      : null,
  };
}

/**
 * Runs several corpus-capable scanners over ONE pass of the repository.
 *
 * This is where the saving actually lands: four scanners, one walk, one read
 * per file. Each still gets exactly the files it wants, because `scanFile`
 * decides per file and reading is lazy — a scanner that ignores a file costs
 * nothing for it.
 *
 * ONE SCANNER THROWING MUST NOT LOSE THE OTHERS' WORK. They share a pass now,
 * so an exception that escaped would discard three scanners' findings along
 * with the one that failed. A scanner that throws is dropped from the rest of
 * the walk and reported as failed on its own, exactly as the sequential
 * orchestrator does it.
 *
 * @returns {Map<string, {findings, stats, error}>} keyed by scanner id
 */
async function runCorpusScanners(scanners, { repoPath, repository, dir, maxFiles, cache = null, onProgress = null, files = null, ruleSet = null } = {}) {
  const results = new Map();
  const active = [];
  // Every path visited, so the cache can drop entries for files that are gone.
  const seenPaths = [];

  for (const scanner of scanners) {
    try {
      const ctx = scanner.prepare({ repoPath, repository, dir, ruleSet });
      // Handed to the scanner so it decides for itself what a hit means for its
      // own counters. Absent when caching is off, and every scanner treats that
      // as "always a miss".
      if (ctx && cache) ctx.cache = cache.for(scanner.id);
      // A scanner with nothing to do (no rules in the bundle, say) reports
      // itself skipped rather than completing with a clean-looking zero.
      if (ctx && ctx.skipped) {
        results.set(scanner.id, { findings: [], stats: ctx, error: null });
        continue;
      }
      active.push({ scanner, ctx, findings: [] });
    } catch (e) {
      results.set(scanner.id, { findings: [], stats: null, error: e.message });
    }
  }

  const corpus = await forEachFile(repoPath, { maxFiles, onProgress, files }, async file => {
    seenPaths.push(file.relPath);
    for (const entry of active) {
      if (entry.failed) continue;
      try {
        const found = await entry.scanner.scanFile(file, entry.ctx, { repository, repoPath });
        if (found && found.length) entry.findings.push(...found);
      } catch (e) {
        // Dropped for the rest of the walk, with its reason kept.
        entry.failed = e.message;
      }
    }
  });

  for (const entry of active) {
    if (entry.failed) {
      results.set(entry.scanner.id, { findings: [], stats: null, error: entry.failed });
      continue;
    }
    let stats = null;
    try {
      stats = entry.scanner.finish(entry.ctx, corpus);
    } catch (e) {
      results.set(entry.scanner.id, { findings: entry.findings, stats: null, error: e.message });
      continue;
    }
    results.set(entry.scanner.id, { findings: entry.findings, stats, error: null });
  }

  // Written once for the whole pass, pruned to what still exists.
  if (cache) cache.save(seenPaths);

  return { results, corpus, cache: cache ? cache.stats : null };
}

/**
 * A single corpus-capable scanner over its own private pass.
 *
 * This is what `scan()` calls, so running one scanner standalone behaves
 * exactly as it did before the walk was shared — same files, same stats, same
 * findings. Sharing the pass is an orchestration decision, not a change to what
 * any scanner means.
 */
async function runOverOwnCorpus(scanner, options = {}) {
  const { results } = await runCorpusScanners([scanner], options);
  const result = results.get(scanner.id);
  if (result.error) throw new Error(result.error);
  return { findings: result.findings, stats: result.stats };
}

module.exports = {
  forEachFile,
  countFiles,
  runCorpusScanners,
  runOverOwnCorpus,
  walk,
  shouldSkipFile,
  DEFAULT_MAX_FILES,
  MAX_FILE_BYTES,
};
