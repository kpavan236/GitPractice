'use strict';

// Credential patterns for the built-in secret scanner.
//
// Split into its own file because this table is the part that will be edited
// most often — a new provider prefix should be a one-line addition, not a
// journey through scanner code.
//
// Each entry:
//   id          stable rule id, reported as the detection's ruleId
//   name        what the UI shows
//   severity    CRITICAL for anything granting direct account access
//   pattern     global regex; group 1 is the secret if the match includes
//               surrounding syntax, otherwise the whole match is the secret
//   verifiable  whether a live-credential check could exist for it later
//
// Patterns are anchored on provider-specific prefixes wherever possible. The
// generic entropy rule at the bottom of secrets.js is what catches the rest,
// and it is deliberately conservative — a secret scanner that cries wolf gets
// switched off, and then it catches nothing at all.

const PATTERNS = [
  {
    id: 'aws-access-key-id',
    name: 'AWS access key ID',
    severity: 'CRITICAL',
    // AKIA (long-lived user key) and ASIA (temporary STS key).
    pattern: /\b((?:AKIA|ASIA)[0-9A-Z]{16})\b/g,
    verifiable: true,
  },
  {
    id: 'aws-secret-access-key',
    name: 'AWS secret access key',
    severity: 'CRITICAL',
    pattern: /aws_?secret_?access_?key["'\s:=]+([A-Za-z0-9/+=]{40})\b/gi,
    verifiable: true,
  },
  {
    id: 'github-pat',
    name: 'GitHub personal access token',
    severity: 'CRITICAL',
    pattern: /\b(gh[pousr]_[A-Za-z0-9]{36,255})\b/g,
    verifiable: true,
  },
  {
    id: 'github-fine-grained-pat',
    name: 'GitHub fine-grained token',
    severity: 'CRITICAL',
    pattern: /\b(github_pat_[A-Za-z0-9_]{60,255})\b/g,
    verifiable: true,
  },
  {
    id: 'slack-token',
    name: 'Slack token',
    severity: 'HIGH',
    pattern: /\b(xox[baprs]-[A-Za-z0-9-]{10,})\b/g,
    verifiable: true,
  },
  {
    id: 'slack-webhook',
    name: 'Slack webhook URL',
    severity: 'MEDIUM',
    pattern: /(https:\/\/hooks\.slack\.com\/services\/T[A-Za-z0-9_/]{20,})/g,
    verifiable: false,
  },
  {
    id: 'private-key',
    name: 'Private key',
    severity: 'CRITICAL',
    pattern: /(-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----)/g,
    verifiable: false,
  },
  {
    id: 'google-api-key',
    name: 'Google API key',
    severity: 'HIGH',
    pattern: /\b(AIza[0-9A-Za-z_-]{35})\b/g,
    verifiable: true,
  },
  {
    id: 'stripe-secret-key',
    name: 'Stripe secret key',
    severity: 'CRITICAL',
    pattern: /\b(sk_(?:live|test)_[0-9A-Za-z]{24,})\b/g,
    verifiable: true,
  },
  {
    id: 'npm-token',
    name: 'npm access token',
    severity: 'HIGH',
    pattern: /\b(npm_[A-Za-z0-9]{36})\b/g,
    verifiable: true,
  },
  {
    id: 'jenkins-api-token',
    name: 'Jenkins API token',
    severity: 'HIGH',
    // 32 hex characters assigned to something named like a Jenkins token.
    pattern: /jenkins[_-]?(?:api[_-]?)?token["'\s:=]+([0-9a-f]{32,34})\b/gi,
    verifiable: false,
  },
  {
    id: 'jwt',
    name: 'JSON Web Token',
    severity: 'MEDIUM',
    pattern: /\b(eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\b/g,
    verifiable: false,
  },
  {
    id: 'basic-auth-url',
    name: 'Credentials in URL',
    severity: 'HIGH',
    // https://user:password@host — the password is group 1.
    pattern: /https?:\/\/[^\s:/@]+:([^\s:/@]{4,})@[^\s/]+/g,
    verifiable: false,
  },
  {
    id: 'postgres-url',
    name: 'Database connection string with password',
    severity: 'HIGH',
    pattern: /(?:postgres|postgresql|mysql|mongodb(?:\+srv)?):\/\/[^\s:/@]+:([^\s:/@]{4,})@[^\s/]+/g,
    verifiable: false,
  },
  {
    id: 'generic-secret-assignment',
    name: 'Hardcoded secret',
    severity: 'MEDIUM',
    // A variable that names itself a secret, assigned a quoted literal. The
    // entropy and placeholder checks in secrets.js do the real filtering here.
    pattern: /(?:password|passwd|secret|api[_-]?key|apikey|auth[_-]?token|access[_-]?token|private[_-]?key|client[_-]?secret)["'\s]*[:=]\s*["']([^"'\s]{8,})["']/gi,
    verifiable: false,
    entropyFloor: 3.0,
  },
];

// Strings that look like credentials but are telling you to replace them.
// Matched against the secret itself, case-insensitively.
const PLACEHOLDER_PATTERNS = [
  /^x+$/i,
  /^\.+$/,
  /^\*+$/,
  /^<.*>$/,
  /^\$\{.*\}$/, // ${ENV_VAR}
  /^\$[A-Z_]+$/, // $ENV_VAR
  /^%[A-Z_]+%$/, // %ENV_VAR%
  /^(your|my|the)[_-]?/i,
  /^(example|sample|dummy|placeholder|redacted|removed|changeme|change[_-]?me)/i,
  /^(test|fake|mock|stub|invalid|none|null|nil|undefined|empty)$/i,
  /^(password|secret|token|apikey|api[_-]?key|credentials?)$/i,
  /^(insert|enter|put)[_-]?/i,
  /^[a-f0-9]{1,7}$/i, // too short to be meaningful
  /^(abc|123|foo|bar|baz|qwerty)/i,
  /xxxx/i,
  /^AKIAIOSFODNN7EXAMPLE$/, // AWS's own documentation key

  // Documentation placeholders that carry a REAL provider prefix, so the
  // start-anchored patterns above never see the marker:
  //   xoxb-your-bot-token      ghp_your_token_here      sk-example-key
  //
  // Matched as a DELIMITED word rather than a substring, so a genuine random
  // secret that happens to contain those letters cannot be dismissed. That
  // direction matters more than the noise: a missed credential is unbounded
  // damage, a false positive is an annoyance.
  /[-_.](your|my|our)[-_.]/i,
  /[-_.](goes|token|key|secret)[-_]here\b/i,
  /(example|placeholder|redacted|changeme|dummy|sample)/i,
];

function isPlaceholder(secret) {
  return PLACEHOLDER_PATTERNS.some(p => p.test(secret));
}

// Shannon entropy in bits per character. A base64 key runs around 4.5-6; an
// English word or a path runs under 3.5.
function shannonEntropy(value) {
  if (!value) return 0;
  const counts = new Map();
  for (const ch of value) counts.set(ch, (counts.get(ch) || 0) + 1);
  let entropy = 0;
  for (const count of counts.values()) {
    const p = count / value.length;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

module.exports = { PATTERNS, PLACEHOLDER_PATTERNS, isPlaceholder, shannonEntropy };