'use strict';
const { parentPort, workerData } = require('worker_threads');
const { runCorpusScanners } = require('./corpus');
const { createCache } = require('./scan-cache');
const { loadPlugins } = require('./ast/engine');

// One repository's shared scanning pass, off the server's event loop.
//
// Everything expensive about a scan is here: reading the tree, running ~236
// secret patterns over every line, and rebuilding a syntax tree per source
// file. On the main thread that work froze the HTTP server for the duration,
// so the dashboard could not even report the progress of the scan that was
// blocking it.
//
// Each worker thread has its own module state, separate from the main
// thread's. The main thread calls setUserRulesDir()/loadPlugins() once at
// startup (server/security/index.js), but that call never reaches a worker —
// so without doing it here too, a user's custom rule pack or grammar plugin
// is invisible to every real scan, which runs on this pool by default.
// workerData carries the same two directories the main thread was configured
// with, and this runs before the scanners below are required, so their first
// loadRules({dir}) call already sees user packs.
if (workerData) {
  loadPlugins(workerData.userGrammarsDir);
}

// The scanners are required at module load, ONCE per thread, because that is
// when the rule bundle is verified and the tree-sitter grammars are compiled.
// The pool reuses threads for exactly this reason.
const SCANNERS = new Map(
  [
    require('./scanners/secrets-builtin').scanner,
    require('./scanners/pattern-sast').scanner,
    require('./scanners/iac-policy').scanner,
    require('./scanners/sast-ast').scanner,
  ].map(s => [s.id, s])
);

// A finding's plaintext credential lives on a NON-ENUMERABLE field, so the
// verifier can ask the provider whether the key is still live while never
// letting the value reach the store, a log, or a report.
//
// Structured clone copies own enumerable properties, so that field does not
// survive the trip to the parent thread — silently. Secret verification would
// have gone on "working" while quietly verifying nothing. It is carried across
// explicitly instead, and reattached on the other side.
function extractSecrets(findings) {
  const secrets = [];
  for (const f of findings) {
    if (f._plaintext && f.fingerprint) secrets.push([f.fingerprint, f._plaintext]);
  }
  return secrets;
}

// How often the thread is allowed to speak. Every file would be twenty thousand
// messages per repository, each one a structured clone and a wake-up on the very
// event loop this work was moved off. The dashboard polls at second granularity,
// so a report ten times a second is already more than anyone can read — the file
// name shown skips ahead, which is what watching a fast scan looks like.
const PROGRESS_INTERVAL_MS = 100;

// `resolvePayload` lets the embedding scanner supply what a caller left out
// (iready-oasis fills in its built-in rules for legacy callers). The analyzer's
// own entry point passes nothing, so a missing ruleSet is reported as an error.
function startWorker({ resolvePayload = p => p } = {}) {
parentPort.on('message', async ({ id, payload: rawPayload }) => {
  try {
    const payload = resolvePayload(rawPayload);
    const { repoPath, repository, dir, scannerIds, bundleVersion, maxFiles, cacheEnabled, files, ruleSet } = payload;

    // The first and the last file always get through: the first is what turns a
    // bar from empty into "started", and the last is what stops it short of the
    // end it actually reached.
    let lastReport = 0;
    const onProgress = progress => {
      const now = Date.now();
      const boundary = progress.filesScanned === 1 || progress.filesScanned === progress.filesTotal;
      if (!boundary && now - lastReport < PROGRESS_INTERVAL_MS) return;
      lastReport = now;
      parentPort.postMessage({ id, progress });
    };

    const scanners = (scannerIds || []).map(sid => SCANNERS.get(sid)).filter(Boolean);
    const cache = createCache({
      dir,
      repository,
      bundleVersion,
      ...(cacheEnabled === false ? { enabled: false } : {}),
    });

    const { results, corpus } = await runCorpusScanners(scanners, {
      repoPath, repository, dir, maxFiles, cache, onProgress, files, ruleSet,
    });

    const all = [];
    const out = [];
    for (const [scannerId, result] of results) {
      out.push([scannerId, {
        findings: result.findings,
        stats: result.stats,
        error: result.error,
      }]);
      all.push(...result.findings);
    }

    parentPort.postMessage({
      id,
      ok: true,
      result: {
        results: out,
        corpus,
        cacheStats: cache.stats,
        secrets: extractSecrets(all),
      },
    });
  } catch (e) {
    parentPort.postMessage({ id, ok: false, error: e.message });
  }
});
}

module.exports = { startWorker };
