'use strict';
// Worker-thread entry. Started as `new Worker(analyzer.workerPath, { workerData })`.
require('./worker-core').startWorker();
