'use strict';

// The one internal finding model.
//
// Every scanner speaks a different schema — Semgrep emits `check_id` and a
// `start.line`, Gitleaks emits `RuleID` and `StartLine`, OSV emits an aliases
// array — and none of them agree on severity words. Everything above this file
// works on the shape defined here, so adding a scanner means writing one
// adapter, not touching the dashboard, the risk engine, or the store.
//
// This is a single-user desktop tool, so there is deliberately no
// organizationId or projectId. Carrying tenancy fields that are always the same
// constant would be fiction; a repository is the top of the hierarchy here.

const TYPES = ['SAST', 'SCA', 'SECRET', 'SBOM', 'LICENSE', 'CONTAINER', 'IAC', 'DAST', 'API', 'CLOUD', 'QUALITY'];

// Produced today. The rest are listed so that a scanner added later slots into
// the same enum rather than inventing a parallel one.
//
// QUALITY is last for a reason. It is not a security type and never ranks
// against one: it exists so lint findings can be filtered as a group, because a
// CRITICAL sitting under four hundred `no-unused-vars` entries is a finding
// nobody reads. Everything above it is a vulnerability; QUALITY is a code
// smell, and the list should not blur the two.
const IMPLEMENTED_TYPES = ['SAST', 'SCA', 'SECRET', 'SBOM', 'LICENSE', 'IAC', 'QUALITY'];

const SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];

// Ordered worst-first for sorting and for "what is the worst thing here".
const SEVERITY_RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };

// A subset of the full lifecycle. The states tied to automated remediation
// (FIX_AVAILABLE, PR_CREATED) are absent because nothing here creates pull
// requests yet — adding them later is an enum entry, not a redesign.
const STATUSES = [
  'OPEN',
  'FIXED_PENDING_VERIFICATION',
  'RESOLVED',
  'REOPENED',
  'SUPPRESSED',
  'FALSE_POSITIVE',
];

// Statuses that mean "this still needs someone's attention".
const ACTIVE_STATUSES = ['OPEN', 'REOPENED', 'FIXED_PENDING_VERIFICATION'];

// Scanner severity vocabularies, mapped onto ours. Anything unrecognised
// becomes MEDIUM rather than being dropped or silently treated as INFO: an
// unknown severity is a scanner we have not taught this table about, and
// hiding those findings at the bottom of the list is how they get missed.
const SEVERITY_ALIASES = {
  critical: 'CRITICAL',
  high: 'HIGH',
  error: 'HIGH',
  moderate: 'MEDIUM',
  medium: 'MEDIUM',
  warning: 'MEDIUM',
  low: 'LOW',
  minor: 'LOW',
  info: 'INFO',
  information: 'INFO',
  informational: 'INFO',
  note: 'INFO',
  unknown: 'MEDIUM',
};

function normaliseSeverity(value) {
  if (!value) return 'MEDIUM';
  const key = String(value).trim().toLowerCase();
  return SEVERITY_ALIASES[key] || (SEVERITIES.includes(key.toUpperCase()) ? key.toUpperCase() : 'MEDIUM');
}

// CVSS base score → severity band, per the CVSS v3 qualitative scale.
function severityFromCvss(score) {
  const n = Number(score);
  if (!Number.isFinite(n)) return null;
  if (n >= 9.0) return 'CRITICAL';
  if (n >= 7.0) return 'HIGH';
  if (n >= 4.0) return 'MEDIUM';
  if (n > 0) return 'LOW';
  return 'INFO';
}

/**
 * Builds a normalised finding. Adapters call this rather than assembling object
 * literals, so a missing field is a default here instead of `undefined` three
 * layers away in the dashboard.
 */
function createFinding({
  type,
  category,
  severity,
  title,
  description = '',
  repository,
  file = null,
  startLine = null,
  endLine = null,
  cwe = null,
  cve = null,
  source,
  ruleId = null,
  remediation = null,
  evidence = null,
  metadata = {},
}) {
  if (!TYPES.includes(type)) throw new Error(`Unknown finding type: ${type}`);
  if (!source) throw new Error('A finding must record which scanner produced it');
  if (!repository) throw new Error('A finding must belong to a repository');

  return {
    id: null, // assigned by the store once deduplication has run
    fingerprint: null, // assigned by fingerprint.js
    type,
    category: category || 'UNCATEGORISED',
    severity: normaliseSeverity(severity),
    title: title || category || 'Security finding',
    description,
    repository,
    file,
    startLine,
    endLine: endLine === null ? startLine : endLine,
    cwe,
    cve,
    status: 'OPEN',
    // Every scanner that reported this same issue. One finding, many
    // detections — see fingerprint.js for why they collapse.
    detections: [{ source, ruleId, detectedAt: null }],
    remediation,
    // Deterministic supporting facts. Kept separate from `description` so the
    // UI can show provenance without an AI-written narrative getting mixed in.
    evidence,
    risk: null, // assigned by risk.js
    metadata,
    firstSeenAt: null,
    lastSeenAt: null,
  };
}

function isActive(finding) {
  return ACTIVE_STATUSES.includes(finding.status);
}

function compareBySeverity(a, b) {
  return SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity];
}

// Worst severity in a list, or null for an empty one.
function worstSeverity(findings) {
  return findings.reduce((worst, f) => {
    if (!worst) return f.severity;
    return SEVERITY_RANK[f.severity] < SEVERITY_RANK[worst] ? f.severity : worst;
  }, null);
}

function countBySeverity(findings) {
  const counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
  for (const f of findings) counts[f.severity] = (counts[f.severity] || 0) + 1;
  return counts;
}

module.exports = {
  TYPES,
  IMPLEMENTED_TYPES,
  SEVERITIES,
  SEVERITY_RANK,
  STATUSES,
  ACTIVE_STATUSES,
  createFinding,
  normaliseSeverity,
  severityFromCvss,
  isActive,
  compareBySeverity,
  worstSeverity,
  countBySeverity,
};