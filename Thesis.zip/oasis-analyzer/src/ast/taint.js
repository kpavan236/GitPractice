'use strict';

// Values that plausibly come from outside the program.
//
// Lived in sast-rules.js next to the regex rule table; moved here when that
// table was retired, because taint sources are a property of the ANALYSIS, not
// of any one rule format. Rules declare that they require taint; this decides
// what taint is.
//
// Deliberately a name list rather than something cleverer: framework entry
// points are conventional, and a list a developer can read and extend beats an
// inference nobody can predict.
const TAINT_SOURCES = new RegExp(
  [
    'request\\.', 'req\\.', 'HttpServletRequest', 'getParameter', 'getHeader',
    'getQueryString', 'getInputStream', 'RequestParam', 'PathVariable',
    'RequestBody', 'params\\.', 'query\\.', 'body\\.', 'argv', 'process\\.env',
    'input', 'userInput', 'user_input', 'FormData', 'searchParams',
    '\\$_GET', '\\$_POST', '\\$_REQUEST', 'os\\.environ', 'sys\\.argv',
  ].join('|'),
  'i'
);

module.exports = { TAINT_SOURCES };
