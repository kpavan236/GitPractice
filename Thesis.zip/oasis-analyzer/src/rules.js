'use strict';

const isRegex = (source) => {
  try { new RegExp(source, 'i'); return true; } catch (_) { return false; }
};

// One malformed rule must disable itself, never stop a scan: a non-object entry or a
// `negate`/`requiresContext` regex that does not compile would otherwise throw inside
// an engine and take every other rule of that engine down with it. The build and the
// release fixtures are where such a rule is supposed to be caught; this is the backstop.
function isUsableRule(rule) {
  if (!rule || typeof rule !== 'object' || Array.isArray(rule)) return false;
  for (const field of ['negate', 'requiresContext']) {
    if (rule[field] !== undefined && rule[field] !== null && rule[field] !== '' && !isRegex(String(rule[field]))) return false;
  }
  return true;
}

// The analyzer never decides which rules to run: the caller (scanner) passes a
// complete rule set. A missing one is a caller bug and must be loud, because a
// scan that silently runs zero rules looks exactly like a clean repository.
function resolveRuleSet(ruleSet) {
  if (!ruleSet || !Array.isArray(ruleSet.rules)) throw new Error('ruleSet is required');
  const ageDays = ruleSet.createdAt
    ? Math.floor((Date.now() - new Date(ruleSet.createdAt).getTime()) / 86400000)
    : null;
  const rules = ruleSet.rules.filter(isUsableRule);
  return {
    rules,
    droppedRules: ruleSet.rules.length - rules.length,
    version: ruleSet.version || null,
    cacheVersion: ruleSet.cacheVersion || ruleSet.version || 'none',
    source: ruleSet.source || 'caller',
    createdAt: ruleSet.createdAt || null,
    ageDays,
    rejected: ruleSet.rejected || [],
  };
}

module.exports = { resolveRuleSet, isUsableRule };
