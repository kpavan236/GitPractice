CREATE TABLE staff (
  user_id uuid PRIMARY KEY, email text NOT NULL UNIQUE, password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('author','admin')), active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE session (
  token_hash text PRIMARY KEY, user_id uuid NOT NULL REFERENCES staff(user_id),
  csrf text NOT NULL, expires_at timestamptz NOT NULL
);
CREATE TABLE role_permission (role text NOT NULL, permission text NOT NULL, PRIMARY KEY (role, permission));
