INSERT INTO role_permission (role, permission) VALUES
 ('author','rule.read'),('author','rule.write'),('author','rule.test'),('author','rule.propose'),('author','language.read'),('author','release.read'),
 ('admin','rule.read'),('admin','rule.write'),('admin','rule.test'),('admin','rule.propose'),('admin','rule.approve'),('admin','rule.deprecate'),
 ('admin','language.read'),('admin','language.write'),('admin','release.read'),('admin','release.publish'),('admin','release.rollback'),
 ('admin','staff.manage'),('admin','audit.read');
