// A per-viewer convenience only: a half-edited rule survives a reload. The server copy is the real one; storage can be missing or blocked, so nothing depends on it.

const key = (id) => `studio.draft.${id || 'new'}`;

export function loadDraft(id) {
  try { const raw = localStorage.getItem(key(id)); return raw ? JSON.parse(raw) : null; } catch (_) { return null; }
}
export function saveDraft(id, values) {
  try { localStorage.setItem(key(id), JSON.stringify({ savedAt: new Date().toISOString(), values })); } catch (_) { /* storage unavailable: the draft just is not kept */ }
}
export function clearDraft(id) {
  try { localStorage.removeItem(key(id)); } catch (_) { /* nothing to clear */ }
}
