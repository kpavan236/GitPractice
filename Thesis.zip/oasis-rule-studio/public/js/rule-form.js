import { h, field, select } from './dom.js';
import { PILLARS, SEVERITIES, opts } from './labels.js';

const lines = (text) => text.split('\n').map((s) => s.trim()).filter(Boolean);
const csv = (text) => text.split(',').map((s) => s.trim()).filter(Boolean);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

/**
 * The rule editor's fields. `body` is the stored rule; fields this form does not show are kept as they are.
 * `locked` (a seeded rule) makes every field read-only except severity, pillar and tags.
 */
export function ruleForm({ body, languages, locked, isNew, onInput }) {
  const ro = (extra = {}) => ({ ...extra, readonly: locked, disabled: undefined });
  const text = (v, props) => h('input', { type: 'text', value: v || '', ...props });
  const area = (v, rows, props) => h('textarea', { rows, spellcheck: 'false', class: 'code', ...props }, v || '');
  const ex = body.example || {};
  const inputs = {
    id: text(body.id, { readonly: !isNew, maxlength: 100 }),
    language: languages.length ? select(opts([...new Set([...languages, body.language].filter(Boolean))]), body.language || '', { disabled: !isNew }) : text(body.language, { readonly: !isNew }),
    pillar: select(opts(PILLARS), body.pillar || 'security'),
    severity: select(opts(SEVERITIES), body.severity || 'MEDIUM'),
    tags: text((body.tags || []).join(', '), { maxlength: 400 }),
    title: text(body.title, ro()),
    description: area(body.description, 3, ro()),
    pattern: area(body.pattern, 2, ro()),
    query: area(body.query, 3, ro()),
    files: area((body.files || []).join('\n'), 2, ro()),
    exampleFile: text(ex.file, ro()),
    vulnerable: area(ex.vulnerable, 6, ro()),
    fixed: area(ex.fixed, 6, ro()),
  };
  const fields = [
    ['id', 'Rule id', 'Lowercase letters, digits and hyphens. It cannot change after the rule is created.'],
    ['language', 'Language'], ['pillar', 'Pillar'], ['severity', 'Severity'], ['tags', 'Tags', 'Separate with commas.'],
    ['title', 'Title'], ['description', 'Description'],
    ['pattern', 'Pattern (regular expression)'], ['query', 'AST query (leave empty for a pattern rule)'], ['files', 'Files it applies to', 'One glob per line, for example **/*.go'],
    ['exampleFile', 'Example file name'], ['vulnerable', 'Vulnerable example (must be flagged)'], ['fixed', 'Fixed example (must be clean)'],
  ].map(([k, label, hint]) => ({ k, ...field(label, inputs[k], hint) }));
  for (const f of fields) f.input.addEventListener('input', () => onInput());

  const read = () => {
    const out = { ...body };
    const put = (key, value) => { if (value === '' || (Array.isArray(value) && !value.length)) delete out[key]; else out[key] = value; };
    out.id = inputs.id.value.trim();
    out.language = inputs.language.value.trim();
    out.pillar = inputs.pillar.value;
    out.severity = inputs.severity.value;
    put('tags', csv(inputs.tags.value));
    put('title', inputs.title.value.trim());
    put('description', inputs.description.value.trim());
    put('pattern', inputs.pattern.value.trim());
    put('query', inputs.query.value.trim());
    put('files', lines(inputs.files.value));
    const example = { ...(body.example || {}), file: inputs.exampleFile.value.trim(), vulnerable: inputs.vulnerable.value, fixed: inputs.fixed.value };
    if (example.file || example.vulnerable || example.fixed) out.example = example; else delete out.example;
    return out;
  };

  /** The fields that differ from the stored rule, with null for "now empty" (the server removes a field sent as null). */
  const patch = () => {
    const now = read();
    const out = {};
    for (const key of new Set([...Object.keys(now), ...Object.keys(body)])) {
      if (key === 'id' || key === 'language') continue;
      if (!same(now[key], body[key])) out[key] = now[key] === undefined ? null : now[key];
    }
    return out;
  };

  const write = (values) => {
    const set = (el, v) => { el.value = v == null ? '' : v; };
    set(inputs.pillar, values.pillar); set(inputs.severity, values.severity); set(inputs.tags, (values.tags || []).join(', '));
    set(inputs.title, values.title); set(inputs.description, values.description); set(inputs.pattern, values.pattern); set(inputs.query, values.query);
    set(inputs.files, (values.files || []).join('\n'));
    const e = values.example || {};
    set(inputs.exampleFile, e.file); set(inputs.vulnerable, e.vulnerable); set(inputs.fixed, e.fixed);
    if (isNew) { set(inputs.id, values.id); set(inputs.language, values.language); }
  };

  return { nodes: fields.map((f) => f.node), read, patch, write };
}
