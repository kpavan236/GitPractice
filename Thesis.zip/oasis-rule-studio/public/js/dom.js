// Small helpers for building the page. Everything that came from the server or a person goes in as TEXT (textContent / text nodes);
// no markup string is ever parsed into the page, so a rule's description or example can never run as script or change the page.

const LINK_KEYS = ['href', 'src', 'action', 'formaction'];

/** h('button', { class: 'primary', onclick: fn }, 'Save', otherNode). `value` is applied after the children, so a <select> picks the right option. */
export function h(tag, props, ...children) {
  const node = document.createElement(tag);
  let value;
  for (const [key, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (LINK_KEYS.includes(key) && /^[\s\u0000-\u001f]*(?:javascript|data|vbscript):/i.test(String(v))) throw new Error(`Refusing a ${key} that is not a link`);
    if (key.toLowerCase().startsWith('on') && typeof v !== 'function') throw new Error('Refusing an event handler that is not a function');
    if (key === 'class') node.className = v;
    else if (key === 'text') node.textContent = v;
    else if (key === 'value') value = v;
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), v);
    else if (v === true) node.setAttribute(key, '');
    else node.setAttribute(key, String(v));
  }
  append(node, children);
  if (value !== undefined) node.value = value;
  return node;
}

export function append(node, children) {
  for (const child of children.flat(Infinity)) {
    if (child === undefined || child === null || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

export const mount = (parent, ...children) => append(parent, children);
export const clear = (node) => { node.replaceChildren(); return node; };
export const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

export function debounce(fn, ms) {
  let t;
  const run = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  run.cancel = () => clearTimeout(t);
  return run;
}

export function fmtDateTime(value) {
  const d = new Date(value);
  return value && !Number.isNaN(d.getTime()) ? d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '';
}

export const badge = (text, tone = 'muted') => h('span', { class: `badge ${tone}` }, text);
export const notice = (tone, ...children) => h('div', { class: `notice ${tone}`, role: tone === 'bad' ? 'alert' : 'status' }, ...children);
export const loading = () => h('p', { class: 'loading', role: 'status' }, 'Loading…');
export const empty = (title, detail) => h('div', { class: 'empty' }, h('p', { class: 'empty-title' }, title), detail ? h('p', {}, detail) : null);

export function pageHeader(title, subtitle, ...actions) {
  return h('div', { class: 'page-header' },
    h('div', {}, h('h1', { tabindex: '-1', id: 'page-title' }, title), subtitle ? h('p', { class: 'subtitle' }, subtitle) : null),
    actions.length ? h('div', { class: 'page-actions' }, ...actions) : null);
}

let nextId = 0;
/** A labelled control. Returns { node, input }. */
export function field(label, input, hint) {
  const id = input.id || `f${++nextId}`;
  input.id = id;
  if (hint) input.setAttribute('aria-describedby', `${id}-hint`);
  return { input, node: h('div', { class: 'field' }, h('label', { for: id }, label), input, hint ? h('p', { class: 'hint', id: `${id}-hint` }, hint) : null) };
}

/** options: [value, label] pairs. */
export const select = (options, value, props = {}) => h('select', { ...props, value }, options.map(([v, label]) => h('option', { value: v }, label)));

export function table(columns, rows, caption) {
  return h('div', { class: 'table-wrap' }, h('table', {},
    caption ? h('caption', { class: 'visually-hidden' }, caption) : null,
    h('thead', {}, h('tr', {}, columns.map((c) => h('th', { scope: 'col', class: c.class }, c.title)))),
    h('tbody', {}, rows.map((row) => h('tr', {}, columns.map((c) => h('td', { class: c.class }, c.render(row))))))));
}
