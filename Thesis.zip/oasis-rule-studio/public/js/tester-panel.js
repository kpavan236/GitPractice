import { h, clear, debounce, mount, plural } from './dom.js';
import { api } from './api.js';
import { ruleLink } from './labels.js';

const DELAY_MS = 400;
const isPattern = (rule) => Boolean(rule.pattern) && !rule.query && (!rule.engine || rule.engine === 'pattern');

/**
 * The live check shared by the wizard and the editor: runs the rule against its own two examples (and, for pattern rules, the sample files),
 * and looks for similar rules, 400 ms after the last change. `getRule()` returns the rule as it stands now.
 */
export function liveTest({ getRule, selfId = null, onChange = () => {} }) {
  const result = h('div', { class: 'live-result', 'aria-live': 'polite' });
  const extras = h('div', { class: 'live-extras' });
  const node = h('section', { class: 'live-test', 'aria-label': 'Live test' }, h('h3', {}, 'Live test'), result, extras);
  let passes = false;
  let seq = 0;
  let last = { key: null, impact: null, dupes: null };

  const show = (tone, headline, ...detail) => { clear(result); mount(result, h('p', { class: `live-headline ${tone}` }, headline), ...detail); };

  async function run() {
    const mine = ++seq;
    const rule = getRule();
    if (!rule.pattern && !rule.query && !rule.engine) { passes = false; onChange(false); show('muted', 'Add a pattern and both examples to see a test result.'); clear(extras); return; }
    let test;
    try { test = await api('POST', '/rules/test', { rule }); }
    catch (e) { if (mine !== seq) return; passes = false; onChange(false); show('bad', 'The test could not run.', h('p', {}, e.message)); return; }
    if (mine !== seq) return;
    passes = test.ok === true;
    onChange(passes);
    const lines = (test.detect && test.detect.lines) || [];
    if (passes) {
      show('good', 'Test passes', h('p', {}, `The vulnerable example is flagged on ${lines.length === 1 ? 'line' : 'lines'} ${lines.join(', ')}, and the fixed example is clean.`));
    } else {
      show('bad', 'Test fails', h('ul', {}, (test.problems || []).map((p) => h('li', {}, p))),
        lines.length ? h('p', {}, `Matched on ${lines.length === 1 ? 'line' : 'lines'} ${lines.join(', ')} of the vulnerable example.`) : null,
        h('p', { class: 'hint' }, 'Fix the pattern or the examples until the vulnerable one is flagged and the fixed one is clean.'));
    }
    // Only a passing rule is worth the two extra calls, and only when what they look at (pattern, query, engine, language, files) changed since the last time.
    if (!passes) { clear(extras); return; }
    const key = JSON.stringify([rule.pattern, rule.query, rule.engine, rule.language, rule.files]);
    if (key !== last.key) {
      const [impact, dupes] = await Promise.all([
        isPattern(rule) ? api('POST', '/rules/impact', { rule }).catch(() => null) : null,
        rule.language ? api('POST', '/rules/duplicates', { rule }).catch(() => null) : null,
      ]);
      if (mine !== seq) return;
      last = { key, impact, dupes };
    }
    const { impact, dupes } = last;
    clear(extras);
    if (impact && impact.available) mount(extras, h('p', { class: 'impact' }, `Changes results in ${impact.filesMatched} of ${impact.filesScanned} files in the sample set.`));
    const similar = ((dupes && dupes.duplicates) || []).filter((id) => id !== selfId);
    if (similar.length) mount(extras, h('p', { class: 'notice warn', role: 'status' }, `${plural(similar.length, 'rule')} already look${similar.length === 1 ? 's' : ''} like this one: `, similar.flatMap((id, i) => [i ? ', ' : '', ruleLink(id)]), '. Check them before you save.'));
  }

  const schedule = debounce(run, DELAY_MS);
  return { node, schedule, runNow: () => { schedule.cancel(); return run(); }, passes: () => passes, stop: () => { schedule.cancel(); seq += 1; } };
}
