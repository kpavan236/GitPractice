// The only place that talks to the server. Every state-changing call carries the session's CSRF token (from /auth/me or sign-in).

export class ApiError extends Error {
  constructor(status, code, message, body) { super(message); this.status = status; this.code = code; this.body = body || {}; }
}

let csrf = null;
let me = null;
let onSignedOut = () => {};

export function setMe(value) { me = value; csrf = value ? value.csrf : null; }
export const getMe = () => me;
export const can = (permission) => Boolean(me && Array.isArray(me.permissions) && me.permissions.includes(permission));
export function setSignedOutHandler(fn) { onSignedOut = fn; }

// What to do next, by error code. A message the server wrote itself (it names the field or rule) is kept and these words follow it.
const NEXT = {
  REASON_REQUIRED: 'Enter a reason and try again.',
  FORBIDDEN: 'Your role does not allow this. Ask an admin if you need it.',
  CSRF: 'Your session is out of date. Reload the page and sign in again.',
  INVALID_CREDENTIALS: 'The email or password is not right. Check both and try again.',
  TOO_MANY_ATTEMPTS: 'Too many sign-in attempts. Wait a minute and try again.',
  TOO_LARGE: 'That is too large to send. Split it into smaller parts and try again.',
  BAD_REQUEST: 'The request was not understood. Reload the page and try again.',
  NOT_FOUND: 'Go back to the list and refresh it.',
  INVALID: 'Fix that and try again.',
  BAD_IMPORT: 'Check the file and try again.',
  CONFLICT: 'The current state does not allow this. Refresh the page and check the status.',
  FIXTURE_FAILED: 'The rule does not pass its own examples. Open the rule, fix the pattern or the examples, and try again.',
  BULK_REFUSED: 'Nothing was changed. Remove the rules listed and try again.',
  IMPORT_INVALID: 'Nothing was imported. Fix the rules marked invalid and preview again.',
  SEEDED_RULE_LIMITED: 'Clone the rule to change anything other than severity, pillar and tags.',
  INTERNAL: 'The server hit an error. Try again, and tell an admin if it keeps happening.',
};
const SERVER_WORDS_WIN = new Set(['INVALID', 'CONFLICT', 'NOT_FOUND', 'BAD_IMPORT', 'IMPACT_FAILED', 'IMPACT_UNSUPPORTED']);
const sentence = (text) => (/[.!?]$/.test(text) ? text : `${text}.`);

const NOT_ANSWERING = 'The rules service is not answering. Wait a moment and try again; if it keeps happening, tell an admin.';

function messageFor(status, code, body, retryAfter) {
  if (code === 'TOO_MANY_REQUESTS') {
    const n = Number(retryAfter);
    return `You are going faster than the server allows. Wait ${Number.isFinite(n) && n > 0 ? `${Math.ceil(n)} second${Math.ceil(n) === 1 ? '' : 's'}` : 'a minute'} and try again.`;
  }
  if (status === 503 || (status >= 500 && !(body && body.error))) return NOT_ANSWERING;
  const next = NEXT[code];
  if (body && body.message && SERVER_WORDS_WIN.has(code)) return next ? `${sentence(body.message)} ${next}` : sentence(body.message);
  if (next) return next;
  if (status === 0) return 'Could not reach the server. Check your connection and try again.';
  return `The server refused the request (${code || status}). Try again, and tell an admin if it keeps happening.`;
}

async function send(method, path, body) {
  let res;
  try {
    res = await fetch(`/v1/studio${path}`, {
      method, credentials: 'same-origin',
      headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...(csrf && method !== 'GET' ? { 'x-csrf-token': csrf } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (_) { throw new ApiError(0, 'NETWORK', messageFor(0, 'NETWORK', {}), {}); }
  return res;
}

async function fail(res) {
  let json = {};
  try { json = await res.json(); } catch (_) { /* not JSON */ }
  const err = new ApiError(res.status, json.error || 'ERROR', messageFor(res.status, json.error, json, res.headers.get('retry-after')), json);
  if (res.status === 401 && json.error === 'UNAUTHENTICATED' && me) { setMe(null); onSignedOut(); }
  throw err;
}

/** api('POST', '/rules', body) -> parsed JSON; throws ApiError with a message that says what to do next. */
export async function api(method, path, body) {
  const res = await send(method, path, body);
  if (!res.ok) await fail(res);
  return res.json();
}

export async function apiText(path) {
  const res = await send('GET', path);
  if (!res.ok) await fail(res);
  return res.text();
}
