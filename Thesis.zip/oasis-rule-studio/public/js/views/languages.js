import { h, clear, mount, notice, loading, pageHeader, table, badge, plural } from '../dom.js';
import { api } from '../api.js';
import { PILLARS } from '../labels.js';

export async function renderLanguages(root, ctx) {
  clear(root).append(pageHeader('Languages'), loading());
  let languages;
  try { languages = (await api('GET', '/languages/coverage')).languages; } catch (e) { if (ctx.isCurrent()) clear(root).append(pageHeader('Languages'), notice('bad', e.message)); return; }
  if (!ctx.isCurrent()) return;
  const short = languages.filter((l) => !l.meetsMinimum);
  clear(root);
  mount(root, pageHeader('Languages', 'Active rules per language and pillar. A language needs at least one active rule.'),
    short.length ? notice('bad', `${plural(short.length, 'language')} ${short.length === 1 ? 'has' : 'have'} no active rule: ${short.map((l) => l.name).join(', ')}. Add a rule from New rule, then propose it for approval.`) : notice('good', 'Every language has at least one active rule.'),
    table([
      { title: 'Language', render: (l) => `${l.name} (${l.language})` },
      ...PILLARS.map((p) => ({ title: p, class: 'num', render: (l) => l.pillars[p] })),
      { title: 'Active rules', class: 'num', render: (l) => l.ruleCount },
      { title: 'Syntax-aware', render: (l) => (l.grammar ? 'Yes' : 'No') },
      { title: 'Coverage', render: (l) => (l.meetsMinimum ? badge('Has rules', 'good') : h('span', { class: 'flag-bad' }, h('span', { 'aria-hidden': 'true' }, '⚑ '), 'No active rules')) },
    ], languages, 'Rule coverage by language'));
}
