import { h, clear, mount, field, select, notice, loading, pageHeader, table, fmtDateTime, debounce } from '../dom.js';
import { api, can } from '../api.js';
import { statusBadge } from '../labels.js';
import { ruleForm } from '../rule-form.js';
import { liveTest } from '../tester-panel.js';
import { loadDraft, saveDraft, clearDraft } from '../drafts.js';
import { askAction, toast } from '../dialogs.js';

// Ruling 15: said before the save, and again in the dialog, so nobody is surprised that an edit pulls a rule out of the release.
export const DEMOTION_WARNING = 'This rule will leave the next release until it is proposed and approved again.';

const BLANK = { pillar: 'security', severity: 'MEDIUM', files: ['**/*'], example: { file: '', vulnerable: '', fixed: '' } };

// `initial` is a message ({ tone, children }) from the action that caused this re-render; it is shown once the page is drawn.
export async function renderRuleEditor(root, ctx, idParam, initial = null) {
  const isNew = idParam === 'new';
  clear(root).append(loading());
  let rule; let languages = [];
  try {
    [rule, languages] = await Promise.all([
      isNew ? Promise.resolve({ body: BLANK, status: 'draft', origin: 'user', version: 0 }) : api('GET', `/rules/${encodeURIComponent(idParam)}`),
      api('GET', '/languages/coverage').then((r) => r.languages.map((l) => l.language)).catch(() => []),
    ]);
  } catch (e) { if (ctx.isCurrent()) { clear(root).append(pageHeader('Rule'), notice('bad', e.message, ' ', h('a', { href: '#/rules' }, 'Back to the rules'))); } return; }
  if (!ctx.isCurrent()) return;
  const history = isNew ? [] : await api('GET', `/rules/${encodeURIComponent(idParam)}/history`).then((r) => r.versions).catch(() => []);
  if (!ctx.isCurrent()) return;
  build(root, ctx, { isNew, rule, languages, history, initial });
}

function build(root, ctx, { isNew, rule, languages, history, initial }) {
  const me = ctx.me;
  const locked = !isNew && rule.origin !== 'user';
  const demotes = !isNew && !locked && rule.status === 'active';
  const draftId = isNew ? null : rule.id;
  let baseline = '';
  const message = h('div', { class: 'messages' });
  let dirty = false;

  const say = (tone, ...c) => { clear(message); mount(message, notice(tone, ...c)); message.scrollIntoView({ block: 'nearest' }); };
  const failed = (e) => say('bad', e.message, e.body && e.body.problems ? h('ul', {}, e.body.problems.map((p) => h('li', {}, typeof p === 'string' ? p : `${p.id}: ${p.problem}`))) : null);

  const form = ruleForm({ body: rule.body, languages, locked, isNew, onInput: () => { dirty = JSON.stringify(form.read()) !== baseline; refresh(); live.schedule(); keep(); } });
  baseline = JSON.stringify(form.read());
  const keep = debounce(() => saveDraft(draftId, form.read()), 300);
  const live = liveTest({ getRule: form.read, selfId: rule.id, onChange: () => refresh() });

  const save = h('button', { class: 'primary', type: 'button', onclick: onSave }, locked ? 'Save severity, pillar and tags' : 'Save changes');
  const propose = h('button', { class: 'secondary', type: 'button', onclick: () => act('propose', 'Propose this rule for approval', 'Propose') }, 'Propose');
  const approve = h('button', { class: 'secondary', type: 'button', onclick: () => act('approve', 'Approve this rule', 'Approve') }, 'Approve');
  const deprecate = h('button', { class: 'danger', type: 'button', onclick: () => act('deprecate', 'Deprecate this rule', 'Deprecate', true) }, 'Deprecate');
  const clone = h('button', { class: 'secondary', type: 'button', onclick: onClone }, 'Clone');
  const proposedByMe = rule.proposedBy && me && String(rule.proposedBy).toLowerCase() === String(me.email).toLowerCase();

  function refresh() {
    save.disabled = !can('rule.write') || (!isNew && !dirty);
    propose.disabled = dirty || !live.passes();
    propose.title = dirty ? 'Save your changes first.' : live.passes() ? '' : 'The live test must pass before a rule can be proposed.';
    approve.disabled = Boolean(proposedByMe);
    approve.title = proposedByMe ? 'You proposed this rule. A different admin has to approve it.' : '';
  }

  async function onSave() {
    const warning = demotes ? [notice('warn', DEMOTION_WARNING)] : [];
    if (isNew) {
      const a = await askAction({ title: 'Save new rule as a draft', intro: [h('p', {}, 'The rule starts as a draft. It reaches users only after it is proposed and approved by a different admin.')], confirmLabel: 'Save draft' });
      if (!a) return;
      try { const saved = await api('POST', '/rules', { rule: form.read(), reason: a.reason }); clearDraft(null); toast('Draft saved.'); location.hash = `#/rule/${encodeURIComponent(saved.id)}`; } catch (e) { failed(e); }
      return;
    }
    const all = form.patch();
    const patch = locked ? Object.fromEntries(['severity', 'pillar', 'tags'].filter((k) => k in all).map((k) => [k, all[k]])) : all;
    if (!Object.keys(patch).length) return say('info', 'There is nothing to save yet. Change a field first.');
    const a = await askAction({ title: 'Save changes', intro: [...warning, h('p', {}, `Fields changed: ${Object.keys(patch).join(', ')}.`)], confirmLabel: 'Save changes' });
    if (!a) return;
    try {
      const saved = await api('PATCH', `/rules/${encodeURIComponent(rule.id)}`, { patch, reason: a.reason });
      clearDraft(rule.id);
      await renderRuleEditor(root, ctx, rule.id, { tone: 'good', children: [`Saved as version ${saved.version}. Status is now ${saved.status}.`, saved.status === 'draft' && rule.status === 'active' ? ' It is out of the next release until it is proposed and approved again.' : ''] });
    } catch (e) { failed(e); }
  }

  async function act(verb, title, label, danger = false) {
    const a = await askAction({ title, confirmLabel: label, danger, intro: verb === 'approve' ? [h('p', {}, 'Approving makes the rule active, and it joins the next release you build.')] : [] });
    if (!a) return;
    try {
      const out = await api('POST', `/rules/${encodeURIComponent(rule.id)}/${verb}`, { reason: a.reason });
      await renderRuleEditor(root, ctx, rule.id, { tone: 'good', children: [`Done. The rule is now ${out.status}.`] });
    } catch (e) { failed(e); }
  }

  async function onClone() {
    const newId = h('input', { type: 'text', maxlength: 100, autocomplete: 'off', value: `${rule.id}-copy` });
    const a = await askAction({ title: `Clone ${rule.id}`, intro: [h('p', {}, 'The copy is a new draft that you can edit fully.')], fields: [{ name: 'newId', label: 'New rule id', input: newId, hint: 'Lowercase letters, digits and hyphens.' }], confirmLabel: 'Clone' });
    if (!a) return;
    try { const copy = await api('POST', `/rules/${encodeURIComponent(rule.id)}/clone`, { newId: a.values.newId.trim(), reason: a.reason }); toast('Cloned as a draft.'); location.hash = `#/rule/${encodeURIComponent(copy.id)}`; } catch (e) { failed(e); }
  }

  async function revert(version) {
    const a = await askAction({ title: `Revert to version ${version}`, intro: [h('p', {}, 'This writes a new version with the old content.'), demotes ? notice('warn', DEMOTION_WARNING) : null], confirmLabel: 'Revert', danger: true });
    if (!a) return;
    try { const out = await api('POST', `/rules/${encodeURIComponent(rule.id)}/revert`, { version, reason: a.reason }); await renderRuleEditor(root, ctx, rule.id, { tone: 'good', children: [`Reverted. Status is now ${out.status}.`] }); } catch (e) { failed(e); }
  }

  const stored = loadDraft(draftId);
  const restore = stored && JSON.stringify(stored.values) !== baseline ? notice('info', `You have unsaved edits from this browser (${fmtDateTime(stored.savedAt)}). `,
    h('button', { class: 'link', type: 'button', onclick: () => { form.write(stored.values); dirty = true; refresh(); live.schedule(); restore.remove(); } }, 'Restore them'), ' ',
    h('button', { class: 'link', type: 'button', onclick: () => { clearDraft(draftId); restore.remove(); } }, 'Discard them')) : null;

  clear(root);
  mount(root,
    pageHeader(isNew ? 'New rule' : rule.id, isNew ? 'All fields. For a guided start, use the wizard.' : `${rule.language} · ${rule.pillar} · version ${rule.version}`,
      isNew ? null : [statusBadge(rule.status), h('span', { class: 'meta' }, `origin: ${rule.origin}`)]),
    locked ? notice('info', 'This rule came with the built-in set. You can change its severity, pillar and tags. To change anything else, clone it and edit the copy.') : null,
    demotes ? notice('warn', DEMOTION_WARNING, ' Changing only severity, pillar or tags in the bulk bar does not do this.') : null,
    rule.status === 'proposed' ? notice('info', `Proposed${rule.proposedBy ? ` by ${rule.proposedBy}` : ''}. A different admin approves it.`) : null,
    restore, message,
    h('div', { class: 'editor-grid' }, h('form', { class: 'rule-form', onsubmit: (e) => e.preventDefault() }, form.nodes), live.node),
    h('div', { class: 'button-row' }, can('rule.write') ? save : null, !isNew && can('rule.propose') && rule.status === 'draft' ? propose : null,
      !isNew && can('rule.approve') && rule.status === 'proposed' ? approve : null, !isNew && can('rule.deprecate') && rule.status === 'active' ? deprecate : null,
      !isNew && can('rule.write') ? clone : null, h('a', { href: '#/rules', class: 'button secondary' }, 'Back to the rules')),
    isNew ? null : historySection(rule, history, revert, !locked && can('rule.write')));
  if (initial) say(initial.tone, ...initial.children);
  refresh();
  live.schedule();
  ctx.onLeave(() => { live.stop(); keep.cancel(); });
}

function historySection(rule, versions, revert, canRevert) {
  const sorted = [...versions].sort((a, b) => b.version - a.version);
  const nums = sorted.map((v) => [String(v.version), `Version ${v.version}`]);
  const from = select(nums, nums[1] ? nums[1][0] : nums[0] && nums[0][0], { 'aria-label': 'Compare from' });
  const to = select(nums, nums[0] && nums[0][0], { 'aria-label': 'Compare to' });
  const out = h('div', { class: 'diff-out' });
  const compare = async () => {
    clear(out).append(loading());
    try {
      const { fields } = await api('GET', `/rules/${encodeURIComponent(rule.id)}/diff?from=${from.value}&to=${to.value}`);
      clear(out);
      mount(out, fields.length ? table([{ title: 'Field', render: (f) => f.field }, { title: `Version ${from.value}`, render: (f) => h('pre', {}, show(f.before)) }, { title: `Version ${to.value}`, render: (f) => h('pre', {}, show(f.after)) }], fields, 'Differences between two versions') : h('p', {}, 'These two versions are the same.'));
    } catch (e) { clear(out).append(notice('bad', e.message)); }
  };
  return h('section', { class: 'history' }, h('h2', {}, 'Version history'),
    table([{ title: 'Version', render: (v) => v.version }, { title: 'Changed by', render: (v) => v.changedBy }, { title: 'When', render: (v) => fmtDateTime(v.changedAt) }, { title: 'Reason', render: (v) => v.reason || '' },
      { title: '', render: (v) => (canRevert && v.version !== rule.version ? h('button', { class: 'secondary small', type: 'button', onclick: () => revert(v.version) }, 'Revert to this') : '') }], sorted, 'Version history'),
    sorted.length > 1 ? h('div', { class: 'button-row' }, field('From', from).node, field('To', to).node, h('button', { class: 'secondary', type: 'button', onclick: compare }, 'Compare side by side')) : null, out);
}

const show = (v) => (v === null || v === undefined ? '(not set)' : typeof v === 'string' ? v : JSON.stringify(v, null, 2));
