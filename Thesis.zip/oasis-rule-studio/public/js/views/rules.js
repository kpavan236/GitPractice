import { h, clear, mount, field, select, notice, loading, empty, pageHeader, table, plural } from '../dom.js';
import { api, can } from '../api.js';
import { PILLARS, SEVERITIES, ENGINES, STATUSES, opts, statusBadge, severityBadge, ruleLink } from '../labels.js';
import { askAction, toast } from '../dialogs.js';
import { showExport } from './import-export.js';

const MAX_BULK = 200;

export async function renderRules(root, ctx) {
  const filters = { language: '', pillar: '', severity: '', engine: '', status: '', search: '' };
  const selected = new Set();
  let rows = [];
  let languages = [];
  try { languages = (await api('GET', '/languages/coverage')).languages.map((l) => l.language); } catch (_) { /* the filter just has no languages */ }
  if (!ctx.isCurrent()) return;

  const list = h('div', { class: 'rule-list' });
  const bar = h('div', { class: 'bulk-bar', hidden: true });
  const count = h('p', { class: 'hint', role: 'status' });
  let token = 0;

  async function load() {
    const mine = ++token;
    clear(list).append(loading());
    const qs = new URLSearchParams(Object.entries(filters).filter(([, v]) => v)).toString();
    try { const out = await api('GET', `/rules${qs ? `?${qs}` : ''}`); if (mine !== token || !ctx.isCurrent()) return; rows = out.rules; } catch (e) { if (mine === token) clear(list).append(notice('bad', e.message, ' ', h('button', { class: 'link', type: 'button', onclick: load }, 'Try again'))); return; }
    for (const id of [...selected]) if (!rows.some((r) => r.id === id)) selected.delete(id);
    draw();
  }

  const checkbox = (r) => {
    const c = h('input', { type: 'checkbox', 'aria-label': `Select ${r.id}`, checked: selected.has(r.id) });
    c.addEventListener('change', () => { if (c.checked) selected.add(r.id); else selected.delete(r.id); drawBar(); });
    return c;
  };

  function draw() {
    clear(list);
    count.textContent = `${plural(rows.length, 'rule')} shown`;
    if (!rows.length) { mount(list, empty('No rules match these filters.', 'Clear a filter, or create a rule with New rule.')); drawBar(); return; }
    const all = h('input', { type: 'checkbox', 'aria-label': 'Select all shown rules' });
    all.addEventListener('change', () => { for (const r of rows.slice(0, MAX_BULK)) { if (all.checked) selected.add(r.id); else selected.delete(r.id); } draw(); });
    mount(list, table([
      { title: 'Select', class: 'narrow', render: checkbox },
      { title: 'Rule', render: (r) => ruleLink(r.id) }, { title: 'Title', render: (r) => r.title || '' }, { title: 'Language', render: (r) => r.language },
      { title: 'Pillar', render: (r) => r.pillar }, { title: 'Severity', render: (r) => severityBadge(r.severity) }, { title: 'Status', render: (r) => statusBadge(r.status) },
      { title: 'Origin', render: (r) => r.origin }, { title: 'Version', class: 'num', render: (r) => r.version },
    ], rows, 'Rules'));
    if (can('rule.write')) list.querySelector('th').replaceChildren(all);
    drawBar();
  }

  function drawBar() {
    clear(bar);
    bar.hidden = !selected.size || !can('rule.write');
    if (bar.hidden) return;
    const actions = [['severity', 'Set severity'], ['pillar', 'Set pillar'], ['tag-add', 'Add a tag'], ...(can('rule.deprecate') ? [['deprecate', 'Deprecate'], ['reactivate', 'Reactivate']] : [])];
    const action = select(actions, 'severity', { 'aria-label': 'Bulk action' });
    const valueBox = h('span', {});
    const preview = h('div', { class: 'bulk-preview' });
    const drawValue = () => {
      clear(valueBox);
      const kind = action.value;
      const v = kind === 'severity' ? select(opts(SEVERITIES), 'MEDIUM') : kind === 'pillar' ? select(opts(PILLARS), 'security') : kind === 'tag-add' ? h('input', { type: 'text', maxlength: 64, 'aria-label': 'Tag', placeholder: 'tag' }) : null;
      if (v) { v.setAttribute('aria-label', 'Value'); v.dataset.role = 'value'; valueBox.append(v); }
      clear(preview);
    };
    action.addEventListener('change', drawValue);
    const request = (extra) => ({ ids: [...selected], action: action.value, value: valueBox.firstChild ? valueBox.firstChild.value : undefined, ...extra });
    const run = async () => {
      clear(preview).append(loading());
      try {
        const out = await api('POST', '/rules/bulk', request({ dryRun: true }));
        clear(preview);
        mount(preview, h('p', {}, h('strong', {}, `${plural(out.wouldChange.length, 'rule')} would change.`), ' Nothing is saved until you apply.'),
          out.wouldChange.length ? table([{ title: 'Rule', render: (c) => c.id }, { title: 'Now', render: (c) => String(Array.isArray(c.before) ? c.before.join(', ') : c.before) }, { title: 'After', render: (c) => String(Array.isArray(c.after) ? c.after.join(', ') : c.after) }], out.wouldChange, 'Preview') : null,
          out.problems.length ? notice('warn', 'These rules cannot be changed this way. Deselect them and preview again:', h('ul', {}, out.problems.map((p) => h('li', {}, `${p.id}: ${p.problem}`)))) : null,
          out.wouldChange.length && !out.problems.length ? h('button', { class: 'primary', type: 'button', onclick: () => apply(out.wouldChange.length) }, `Apply to ${plural(out.wouldChange.length, 'rule')}`) : null,
          action.value === 'severity' || action.value === 'pillar' || action.value === 'tag-add' ? h('p', { class: 'hint' }, 'Severity, pillar and tag changes do not send an active rule back to draft.') : null);
      } catch (e) { clear(preview).append(notice('bad', e.message)); }
    };
    const apply = async (n) => {
      const a = await askAction({ title: `Apply to ${plural(n, 'rule')}`, intro: [h('p', {}, 'This changes the rules you previewed.')], confirmLabel: 'Apply', danger: action.value === 'deprecate' });
      if (!a) return;
      try { const out = await api('POST', '/rules/bulk', request({ reason: a.reason })); toast(`Changed ${plural(out.changed.length, 'rule')}.`); selected.clear(); load(); } catch (e) { clear(preview).append(notice('bad', e.message, e.body && e.body.problems ? h('ul', {}, e.body.problems.map((p) => h('li', {}, `${p.id}: ${p.problem}`))) : null)); }
    };
    drawValue();
    mount(bar, h('strong', {}, `${plural(selected.size, 'rule')} selected`), selected.size > MAX_BULK ? notice('warn', `Bulk actions take up to ${MAX_BULK} rules. Narrow the selection.`) : null,
      action, valueBox, h('button', { class: 'secondary', type: 'button', disabled: selected.size > MAX_BULK, onclick: run }, 'Preview'), h('button', { class: 'link', type: 'button', onclick: () => { selected.clear(); draw(); } }, 'Clear selection'), preview);
  }

  const filterBox = h('div', { class: 'filters toolbar' },
    ...[['language', 'Language', opts(languages, 'All')], ['pillar', 'Pillar', opts(PILLARS, 'All')], ['severity', 'Severity', opts(SEVERITIES, 'All')], ['engine', 'Engine', opts(ENGINES, 'All')], ['status', 'Status', opts(STATUSES, 'All')]]
      .map(([k, label, o]) => { const s = select(o, ''); s.addEventListener('change', () => { filters[k] = s.value; load(); }); return field(label, s).node; }),
    (() => { const i = h('input', { type: 'search', placeholder: 'Id or title', autocomplete: 'off' }); let t; i.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { filters.search = i.value.trim(); load(); }, 300); }); return field('Search', i).node; })());

  clear(root);
  mount(root, pageHeader('Rules', 'Filter, select several, and change them together. Every change asks for a reason.',
    can('rule.write') ? h('a', { href: '#/wizard', class: 'button primary' }, 'New rule') : null, can('rule.write') ? h('a', { href: '#/import', class: 'button secondary' }, 'Import') : null,
    h('button', { class: 'secondary', type: 'button', onclick: () => showExport({ language: filters.language, pillar: filters.pillar, status: filters.status }) }, 'Export')),
  filterBox, count, bar, list);
  load();
}
