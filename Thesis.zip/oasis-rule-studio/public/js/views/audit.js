import { h, clear, mount, field, select, notice, loading, pageHeader, table, fmtDateTime } from '../dom.js';
import { api, can } from '../api.js';

export async function renderAudit(root, ctx) {
  if (!can('audit.read')) { clear(root).append(pageHeader('Audit log'), notice('info', 'The audit log is for admins. Ask an admin if you need something from it.')); return; }
  const limit = select([['100', 'Latest 100'], ['200', 'Latest 200'], ['500', 'Latest 500']], '100');
  const out = h('div', {});
  const load = async () => {
    clear(out).append(loading());
    try {
      const { entries } = await api('GET', `/audit?limit=${limit.value}`);
      if (!ctx.isCurrent()) return;
      clear(out);
      mount(out, table([{ title: 'When', render: (e) => fmtDateTime(e.at) }, { title: 'Who', render: (e) => e.actor }, { title: 'Action', render: (e) => e.action }, { title: 'Subject', render: (e) => e.subject || '' },
        { title: 'Outcome', render: (e) => e.outcome || '' }, { title: 'Reason', render: (e) => e.reason || '' }], entries, 'Audit log'));
    } catch (e) { clear(out).append(notice('bad', e.message)); }
  };
  limit.addEventListener('change', load);
  clear(root);
  mount(root, pageHeader('Audit log', 'Every change, who made it and why.'), field('Show', limit).node, out);
  load();
}
