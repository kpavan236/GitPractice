import { h, clear, mount, field, notice } from '../dom.js';
import { api } from '../api.js';

export function renderLogin(root, { message, onSignedIn }) {
  const email = h('input', { type: 'email', autocomplete: 'username', required: true });
  const password = h('input', { type: 'password', autocomplete: 'current-password', required: true });
  const status = h('div', { class: 'messages' });
  const submit = h('button', { type: 'submit', class: 'primary block' }, 'Sign in');
  const form = h('form', { onsubmit: async (e) => {
    e.preventDefault();
    submit.disabled = true; clear(status);
    try { const me = await api('POST', '/auth/login', { email: email.value.trim(), password: password.value }); password.value = ''; onSignedIn(me); }
    catch (err) { mount(status, notice('bad', err.message)); submit.disabled = false; password.focus(); }
  } }, field('Work email', email).node, field('Password', password).node, submit);
  clear(root);
  mount(root, h('div', { class: 'login-shell' },
    h('aside', { class: 'login-brand' }, h('span', { class: 'brand-mark large', 'aria-hidden': 'true' }, 'R'), h('p', { class: 'login-product' }, 'Rules Studio'), h('p', { class: 'login-tag' }, 'Write, test and release the code-quality and security rules that OASIS scans with.')),
    h('main', { id: 'main', class: 'login-card' }, h('h1', { tabindex: '-1' }, 'Sign in'), h('p', { class: 'subtitle' }, 'Use the account an admin created for you.'), message ? notice('info', message) : null, status, form)));
  email.focus();
}
