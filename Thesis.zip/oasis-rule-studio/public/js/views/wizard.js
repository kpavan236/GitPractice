import { h, clear, mount, field, select, notice, loading, pageHeader, debounce } from '../dom.js';
import { api, can } from '../api.js';
import { PILLARS, SEVERITIES, opts } from '../labels.js';
import { liveTest } from '../tester-panel.js';
import { askAction, toast } from '../dialogs.js';

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
const STEPS = ['Language and pillar', 'Template', 'Examples and details'];

export async function renderWizard(root, ctx) {
  clear(root).append(loading());
  let languages; let templates;
  try {
    [languages, templates] = await Promise.all([api('GET', '/languages/coverage').then((r) => r.languages), api('GET', '/templates').then((r) => r.templates)]);
  } catch (e) { if (ctx.isCurrent()) clear(root).append(pageHeader('New rule'), notice('bad', e.message)); return; }
  if (!ctx.isCurrent()) return;

  const state = { step: 1, language: languages[0] ? languages[0].language : '', pillar: 'security', templateId: templates[0] && templates[0].id, params: {}, built: null, bad: '', good: '', title: '', severity: 'MEDIUM', description: '', id: '', idEdited: false };
  let created = null;
  const body = h('div', { class: 'wizard-body' });
  const nav = h('div', { class: 'button-row' });
  const message = h('div', { class: 'messages' });
  const say = (tone, ...c) => { clear(message); mount(message, notice(tone, ...c)); };

  const rule = () => {
    const files = (state.built && state.built.files) || ['**/*'];
    const ext = (/\*(\.[A-Za-z0-9]+)$/.exec(files[0]) || [])[1] || '.txt';
    return { id: state.id, language: state.language, pillar: state.pillar, severity: state.severity, title: state.title.trim(), description: state.description.trim(), files, pattern: state.built ? state.built.pattern : '', example: { file: `example${ext}`, vulnerable: state.bad, fixed: state.good } };
  };
  const live = liveTest({ getRule: rule, onChange: () => buttons() });

  const stepper = () => h('ol', { class: 'steps', 'aria-label': 'Steps' }, STEPS.map((t, i) => h('li', { class: i + 1 === state.step ? 'current' : i + 1 < state.step ? 'done' : '', 'aria-current': i + 1 === state.step ? 'step' : null }, `${i + 1}. ${t}`)));

  function step1() {
    const lang = select(languages.map((l) => [l.language, `${l.name} (${l.language})`]), state.language);
    const pillar = select(opts(PILLARS), state.pillar);
    lang.addEventListener('change', () => { state.language = lang.value; state.built = null; });
    pillar.addEventListener('change', () => { state.pillar = pillar.value; });
    return [field('Language', lang).node, field('Pillar', pillar, 'What the rule protects: security, reliability, maintainability or code quality.').node];
  }

  function step2() {
    const params = h('div', { class: 'params' });
    const status = h('p', { class: 'hint' });
    const build = debounce(async () => {
      const t = templates.find((x) => x.id === state.templateId);
      if (!t || t.params.some((p) => !String(state.params[p.name] || '').trim())) { state.built = null; status.textContent = 'Fill in the field above to build the pattern.'; buttons(); return; }
      try { state.built = (await api('POST', `/templates/${encodeURIComponent(t.id)}/build`, { language: state.language, params: state.params })).rule; status.textContent = `Pattern: ${state.built.pattern}`; } catch (e) { state.built = null; status.textContent = e.message; }
      buttons();
    }, 400);
    const drawParams = () => {
      clear(params);
      const t = templates.find((x) => x.id === state.templateId);
      if (!t) return;
      for (const p of t.params) {
        const input = h('input', { type: 'text', autocomplete: 'off', maxlength: 200, placeholder: p.example ? `for example ${p.example}` : null, value: state.params[p.name] || '' });
        input.addEventListener('input', () => { state.params[p.name] = input.value; build(); });
        mount(params, field(p.label, input).node);
      }
      build();
    };
    const list = h('fieldset', { class: 'templates' }, h('legend', {}, 'Pick a template'), templates.map((t) => {
      const radio = h('input', { type: 'radio', name: 'template', value: t.id, checked: t.id === state.templateId });
      radio.addEventListener('change', () => { state.templateId = t.id; state.params = {}; state.built = null; drawParams(); });
      return h('label', { class: 'template' }, radio, h('span', {}, h('strong', {}, t.title), h('br'), h('span', { class: 'hint' }, t.description)));
    }));
    drawParams();
    return [list, params, status];
  }

  function step3() {
    const bind = (key, input, onChange) => { input.addEventListener('input', () => { state[key] = input.value; if (onChange) onChange(); live.schedule(); buttons(); }); return input; };
    const title = bind('title', h('input', { type: 'text', maxlength: 200, value: state.title }), () => { if (!state.idEdited) { state.id = `${state.language}-${slug(state.title)}`; idInput.value = state.id; } });
    const idInput = bind('id', h('input', { type: 'text', maxlength: 100, value: state.id }), () => { state.idEdited = true; });
    const code = (key, label, hint) => field(label, bind(key, h('textarea', { rows: 6, spellcheck: 'false', class: 'code' }, state[key])), hint).node;
    const sev = select(opts(SEVERITIES), state.severity);
    sev.addEventListener('change', () => { state.severity = sev.value; live.schedule(); });
    return [h('div', { class: 'editor-grid' }, h('div', {},
      h('p', { class: 'hint' }, `Pattern from your template: ${state.built ? state.built.pattern : '(none yet)'}`),
      code('bad', 'A bad example (must be flagged)', 'Paste a short piece of code that has the problem.'),
      code('good', 'A good example (must be clean)', 'The same code, fixed.'),
      field('Title', title).node, field('Rule id', idInput, 'Lowercase letters, digits and hyphens. Filled in from the title; change it if you like.').node,
      field('Severity', sev).node, field('Description', bind('description', h('textarea', { rows: 3 }, state.description))).node), live.node)];
  }

  function buttons() {
    const ready = state.step === 3 && state.id && state.title.trim() && state.bad && state.good && state.description.trim();
    const back = state.step > 1 ? h('button', { class: 'secondary', type: 'button', onclick: () => go(state.step - 1) }, 'Back') : null;
    const next = state.step < 3 ? h('button', { class: 'primary', type: 'button', disabled: (state.step === 2 && !state.built), onclick: () => go(state.step + 1) }, 'Next') : null;
    const draft = state.step === 3 ? h('button', { class: 'primary', type: 'button', disabled: !ready || !can('rule.write'), onclick: () => save(false) }, 'Save draft') : null;
    const propose = state.step === 3 && can('rule.propose') ? h('button', { class: 'secondary', type: 'button', disabled: !ready || !live.passes(), title: live.passes() ? '' : 'The live test must pass before a rule can be proposed.', onclick: () => save(true) }, 'Propose') : null;
    clear(nav);
    mount(nav, back, next, draft, propose, h('a', { href: '#/rules', class: 'button secondary' }, 'Cancel'));
  }

  async function save(andPropose) {
    const a = await askAction({ title: andPropose ? 'Save and propose this rule' : 'Save this rule as a draft', confirmLabel: andPropose ? 'Save and propose' : 'Save draft',
      intro: [h('p', {}, andPropose ? 'The rule is saved, then proposed. A different admin has to approve it before it reaches a release.' : 'A draft is not in any release. You can edit it, propose it, or leave it.')] });
    if (!a) return;
    try {
      if (!created) created = await api('POST', '/rules', { rule: rule(), reason: a.reason });
      if (andPropose) await api('POST', `/rules/${encodeURIComponent(created.id)}/propose`, { reason: a.reason });
      toast(andPropose ? 'Saved and proposed.' : 'Draft saved.');
      location.hash = `#/rule/${encodeURIComponent(created.id)}`;
    } catch (e) {
      say('bad', e.message, created ? h('span', {}, ' The draft was saved: ', h('a', { href: `#/rule/${encodeURIComponent(created.id)}` }, 'open it'), '.') : null);
    }
  }

  function go(n) {
    state.step = n;
    clear(message);
    clear(body);
    mount(body, stepper(), ...[step1, step2, step3][n - 1]());
    buttons();
    if (n === 3) live.schedule();
  }

  clear(root);
  mount(root, pageHeader('New rule', 'Three steps. The live test checks the rule against your two examples as you type.'), message, h('form', { onsubmit: (e) => e.preventDefault() }, body), nav);
  go(1);
  ctx.onLeave(() => live.stop());
}
