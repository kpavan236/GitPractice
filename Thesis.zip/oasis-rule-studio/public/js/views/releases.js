import { h, clear, mount, field, select, notice, loading, empty, pageHeader, table, badge, fmtDateTime, plural } from '../dom.js';
import { api, can } from '../api.js';
import { askAction, toast } from '../dialogs.js';
import { ruleLink } from '../labels.js';

const STATE_TONE = { candidate: 'info', beta: 'warn', stable: 'good', retired: 'muted' };

// `initial` is a message ({ tone, children }) from the action that caused this re-render; it is shown once the page is drawn.
export async function renderReleases(root, ctx, initial = null) {
  clear(root).append(pageHeader('Releases'), loading());
  let data;
  try { data = await api('GET', '/releases'); } catch (e) { if (ctx.isCurrent()) clear(root).append(pageHeader('Releases'), notice('bad', e.message)); return; }
  if (!ctx.isCurrent()) return;
  const message = h('div', { class: 'messages' });
  const detail = h('div', { class: 'release-detail' });
  const say = (tone, ...c) => { clear(message); mount(message, notice(tone, ...c)); };
  const reload = (message) => renderReleases(root, ctx, message);
  const publisher = can('release.publish');
  const roller = can('release.rollback');

  async function build() {
    const a = await askAction({ title: 'Build a candidate release', intro: [h('p', {}, 'This collects every active rule into a new candidate. Every rule is tested against its own examples first. Nothing is published yet.')], confirmLabel: 'Build candidate' });
    if (!a) return;
    try {
      const out = await api('POST', '/releases/candidate', { reason: a.reason });
      await reload({ tone: 'good', children: [`Candidate ${out.releaseNo} built with ${plural(out.summary.rules, 'rule')} in ${plural(out.summary.packs.length, 'pack')}.`, out.summary.skippedNoFixture > 0 ? ` ${plural(out.summary.skippedNoFixture, 'rule')} had no examples to test and ${out.summary.skippedNoFixture === 1 ? 'was' : 'were'} included without a test.` : ''] });
    } catch (e) {
      if (e.code === 'FIXTURE_FAILED') say('bad', 'No candidate was built because these rules fail their own examples. Open each one, fix it or move it out of active, then build again:', h('ul', {}, (e.body.failures || []).map((id) => h('li', {}, ruleLink(id)))));
      else say('bad', e.message);
    }
  }

  async function diff(r) {
    clear(detail).append(loading());
    try {
      const d = await api('GET', `/releases/${r.releaseNo}/diff`);
      clear(detail);
      const group = (title, ids, link) => h('div', { class: 'diff-group' }, h('h3', {}, `${title} (${ids.length})`), ids.length ? h('ul', {}, ids.map((id) => h('li', {}, link ? ruleLink(id) : id))) : h('p', { class: 'hint' }, 'None'));
      mount(detail, h('h2', {}, `Release ${r.releaseNo} compared with the current stable release`), group('Rules added', d.added, true), group('Rules changed', d.changed, true), group('Rules deprecated', d.deprecated, true), group('Packs changed', d.packsChanged, false));
    } catch (e) { clear(detail).append(notice('bad', e.message)); }
  }

  async function publish(r, channel) {
    const a = await askAction({ title: channel === 'beta' ? `Publish release ${r.releaseNo} to beta` : `Promote release ${r.releaseNo} to stable`, confirmLabel: channel === 'beta' ? 'Publish to beta' : 'Promote to stable',
      intro: [h('p', {}, channel === 'beta' ? 'Beta users receive this release.' : 'Stable users receive this release. Only a release that has been on beta can go to stable.')] });
    if (!a) return;
    try { await api('POST', `/releases/${r.releaseNo}/publish`, { channel, reason: a.reason }); await reload({ tone: 'good', children: [`Release ${r.releaseNo} is now on ${channel}.`] }); } catch (e) { say('bad', e.message); }
  }

  async function rollback(r) {
    const channel = select([['beta', 'beta'], ['stable', 'stable']], 'stable');
    const a = await askAction({ title: `Roll back to release ${r.releaseNo}`, confirmLabel: 'Roll back', danger: true, fields: [{ name: 'channel', label: 'Channel to roll back', input: channel }],
      intro: [h('p', {}, `The channel goes back to release ${r.releaseNo}. People on that channel get it the next time they check.`)] });
    if (!a) return;
    try { await api('POST', '/releases/rollback', { channel: a.values.channel, toReleaseNo: r.releaseNo, reason: a.reason }); await reload({ tone: 'good', children: [`The ${a.values.channel} channel is back on release ${r.releaseNo}.`] }); } catch (e) { say('bad', e.message); }
  }

  const head = (c) => (data.channels[c] === null ? 'nothing yet' : `release ${data.channels[c]}`);
  const actions = (r) => h('div', { class: 'button-row' }, h('button', { class: 'secondary small', type: 'button', onclick: () => diff(r) }, 'Diff against stable'),
    publisher && r.state === 'candidate' ? h('button', { class: 'secondary small', type: 'button', onclick: () => publish(r, 'beta') }, 'Publish to beta') : null,
    publisher && r.state === 'beta' ? h('button', { class: 'secondary small', type: 'button', onclick: () => publish(r, 'stable') }, 'Promote to stable') : null,
    roller && (r.state === 'beta' || r.state === 'stable') ? h('button', { class: 'danger small', type: 'button', onclick: () => rollback(r) }, 'Roll back to this') : null);

  clear(root);
  mount(root, pageHeader('Releases', `Beta is on ${head('beta')}. Stable is on ${head('stable')}.`, publisher ? h('button', { class: 'primary', type: 'button', onclick: build }, 'Build candidate') : null), message,
    data.releases.length ? table([{ title: 'Release', class: 'num', render: (r) => r.releaseNo }, { title: 'State', render: (r) => badge(r.state, STATE_TONE[r.state] || 'muted') }, { title: 'Rules', class: 'num', render: (r) => r.ruleCount },
      { title: 'Packs', class: 'num', render: (r) => r.packCount }, { title: 'Built by', render: (r) => r.createdBy }, { title: 'Built', render: (r) => fmtDateTime(r.createdAt) }, { title: 'Actions', render: actions }], data.releases, 'Releases')
      : empty('No releases yet.', publisher ? 'Build a candidate to start.' : 'An admin builds the first candidate.'), detail);
  if (initial) say(initial.tone, ...initial.children);
}
