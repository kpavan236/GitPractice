import { h, clear, mount, field, select, notice, pageHeader, table, plural } from '../dom.js';
import { api, apiText, can } from '../api.js';
import { PILLARS, STATUSES, opts } from '../labels.js';
import { askAction, toast } from '../dialogs.js';

// Handed from the Rules screen to this one in memory when its Export button is pressed; nothing is stored.
let pendingFilters = {};
export function showExport(filters) { pendingFilters = { ...filters }; location.hash = '#/import'; }

function exportSection(filters) {
  const make = (key, label, options) => { const s = select(options, filters[key] || ''); return { s, node: field(label, s).node }; };
  const language = make('language', 'Language', [['', 'All'], ...(filters.languages || []).map((l) => [l, l])]);
  const pillar = make('pillar', 'Pillar', opts(PILLARS, 'All'));
  const status = make('status', 'Status', opts(STATUSES, 'All'));
  const format = select([['json', 'JSON'], ['yaml', 'YAML']], 'json', { 'aria-label': 'Export format' });
  const out = h('div', { class: 'export-out' });
  const go = async () => {
    const qs = new URLSearchParams(Object.entries({ language: language.s.value, pillar: pillar.s.value, status: status.s.value, format: format.value }).filter(([, v]) => v)).toString();
    clear(out).append(h('p', { class: 'loading', role: 'status' }, 'Preparing…'));
    try {
      const text = await apiText(`/export?${qs}`);
      clear(out);
      mount(out, h('p', { class: 'hint' }, 'The rules that match, as stored. Copy the text, or download it.'), h('textarea', { rows: 12, readonly: true, class: 'code', 'aria-label': 'Exported rules' }, text),
        h('a', { class: 'button secondary', download: `rules.${format.value}`, href: URL.createObjectURL(new Blob([text], { type: 'text/plain' })) }, 'Download the file'));
    } catch (e) { clear(out).append(notice('bad', e.message)); }
  };
  return h('section', {}, h('h2', {}, 'Export'), h('div', { class: 'filters' }, language.node, pillar.node, status.node, field('Format', format).node), h('button', { class: 'secondary', type: 'button', onclick: go }, 'Export'), out);
}

const ACTION_TEXT = { add: 'New draft', update: 'Replaces the rule (an active rule goes back to draft)', invalid: 'Invalid' };

export async function renderImportExport(root, ctx) {
  const text = h('textarea', { rows: 10, class: 'code', 'aria-label': 'Rules to import', placeholder: 'Paste JSON or YAML here, or choose a file.' });
  const format = select([['json', 'JSON'], ['yaml', 'YAML']], 'json', { 'aria-label': 'Import format' });
  const fileInput = h('input', { type: 'file', accept: '.json,.yaml,.yml,application/json', 'aria-label': 'Choose a file' });
  const result = h('div', { class: 'import-result' });
  let plan = null;
  fileInput.addEventListener('change', async () => {
    const f = fileInput.files[0];
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) { clear(result).append(notice('bad', 'That file is over 2 MB. Split it into smaller files and try again.')); return; }
    text.value = await f.text();
    format.value = /\.ya?ml$/i.test(f.name) ? 'yaml' : 'json';
    plan = null; clear(result);
  });
  text.addEventListener('input', () => { plan = null; });

  async function preview() {
    if (!text.value.trim()) { clear(result).append(notice('warn', 'Paste some rules or choose a file first.')); return; }
    clear(result).append(h('p', { class: 'loading', role: 'status' }, 'Checking every rule…'));
    try {
      plan = await api('POST', '/import/preview', { format: format.value, text: text.value });
      const bad = plan.rows.filter((r) => r.action === 'invalid').length;
      const updates = plan.rows.filter((r) => r.action === 'update').length;
      clear(result);
      mount(result, table([{ title: 'Rule', render: (r) => r.id }, { title: 'What would happen', render: (r) => ACTION_TEXT[r.action] || r.action },
        { title: 'Test', render: (r) => (r.action === 'invalid' ? '' : r.testOk ? 'Passes' : 'Fails (can still be saved as a draft)') }, { title: 'Problem', render: (r) => r.problem || '' }], plan.rows, 'Import preview'),
      bad ? notice('bad', `${plural(bad, 'rule')} invalid. Nothing can be imported until you fix them in the file and preview again.`) : null,
      updates ? notice('warn', `${plural(updates, 'existing rule')} would be replaced. An active rule goes back to draft and leaves the next release until it is proposed and approved again.`) : null,
      can('rule.write') ? h('button', { class: 'primary', type: 'button', disabled: bad > 0 || !plan.rows.length, onclick: commit }, 'Commit drafts') : null);
    } catch (e) { plan = null; clear(result).append(notice('bad', e.message)); }
  }

  async function commit() {
    const a = await askAction({ title: 'Commit the import', intro: [h('p', {}, 'New rules are saved as drafts. Nothing reaches a release until it is proposed and approved.')], confirmLabel: 'Commit drafts' });
    if (!a) return;
    try {
      const out = await api('POST', '/import/commit', { format: format.value, text: text.value, reason: a.reason });
      toast(`Imported: ${plural(out.created.length, 'new draft')}, ${plural(out.updated.length, 'rule')} updated.`);
      clear(result).append(notice('good', `Created ${out.created.length}, updated ${out.updated.length}. `, h('a', { href: '#/rules' }, 'Go to the rules')));
    } catch (e) { clear(result).append(notice('bad', e.message)); }
  }

  let languages = [];
  try { languages = (await api('GET', '/languages/coverage')).languages.map((l) => l.language); } catch (_) { /* the filter just offers All */ }
  if (!ctx.isCurrent()) return;
  const filters = { ...pendingFilters, languages };
  pendingFilters = {};
  clear(root);
  mount(root, pageHeader('Import and export', 'Move rules in and out as JSON or YAML. Imports always arrive as drafts.'),
    h('section', {}, h('h2', {}, 'Import'), can('rule.write') ? [field('File', fileInput).node, field('Format', format).node, field('Or paste the rules', text).node, h('button', { class: 'secondary', type: 'button', onclick: preview }, 'Preview'), result] : notice('info', 'Your role cannot import rules. Ask an author or an admin.')),
    exportSection(filters));
}
