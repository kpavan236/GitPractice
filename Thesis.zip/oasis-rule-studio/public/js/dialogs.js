import { h, field, mount } from './dom.js';

export function toast(message, tone = 'good') {
  const region = document.getElementById('toasts');
  const node = h('div', { class: `toast ${tone}` }, message);
  region.append(node);
  setTimeout(() => node.remove(), tone === 'bad' ? 9000 : 4500);
}

/**
 * Every state-changing action goes through here: a dialog that shows what is about to happen and asks for a reason (and any extra fields).
 * Resolves to { reason, values } or null when cancelled.
 */
export function askAction({ title, intro = [], fields = [], confirmLabel = 'Confirm', danger = false, reasonLabel = 'Reason (kept in the audit log)' }) {
  return new Promise((resolve) => {
    const before = document.activeElement;
    const reason = field(reasonLabel, h('textarea', { rows: 3, required: true, maxlength: 500 }));
    const extra = fields.map((f) => ({ name: f.name, ...field(f.label, f.input, f.hint) }));
    const problem = h('p', { class: 'form-error', role: 'alert' });
    const done = (value) => { overlay.remove(); document.removeEventListener('keydown', onKey); if (before && before.focus) before.focus(); resolve(value); };
    const submit = (e) => {
      e.preventDefault();
      if (!reason.input.value.trim()) { problem.textContent = 'Enter a reason, then confirm.'; reason.input.focus(); return; }
      done({ reason: reason.input.value.trim(), values: Object.fromEntries(extra.map((f) => [f.name, f.input.value])) });
    };
    const form = h('form', { onsubmit: submit },
      h('h2', { id: 'dlg-title' }, title), ...[].concat(intro), extra.map((f) => f.node), reason.node, problem,
      h('div', { class: 'dialog-actions' },
        h('button', { type: 'button', class: 'secondary', onclick: () => done(null) }, 'Cancel'),
        h('button', { type: 'submit', class: danger ? 'danger' : 'primary' }, confirmLabel)));
    const overlay = h('div', { class: 'overlay' }, h('div', { class: 'dialog', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'dlg-title' }, form));
    const onKey = (e) => {
      if (e.key === 'Escape') return done(null);
      if (e.key !== 'Tab') return;
      const items = [...overlay.querySelectorAll('input, select, textarea, button')].filter((n) => !n.disabled);
      const first = items[0]; const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey);
    mount(document.body, overlay);
    (extra[0] ? extra[0].input : reason.input).focus();
  });
}
