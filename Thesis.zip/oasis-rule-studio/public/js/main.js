import { h, clear, mount, notice } from './dom.js';
import { api, setMe, getMe, can, setSignedOutHandler } from './api.js';
import { renderLogin } from './views/login.js';
import { renderRules } from './views/rules.js';
import { renderRuleEditor } from './views/rule-editor.js';
import { renderWizard } from './views/wizard.js';
import { renderImportExport } from './views/import-export.js';
import { renderLanguages } from './views/languages.js';
import { renderReleases } from './views/releases.js';
import { renderAudit } from './views/audit.js';

const root = document.getElementById('app');
let leave = [];
let generation = 0;

const NAV = [
  ['#/rules', 'Rules', 'rule.read'], ['#/wizard', 'New rule', 'rule.write'], ['#/import', 'Import and export', 'rule.read'],
  ['#/languages', 'Languages', 'language.read'], ['#/releases', 'Releases', 'release.read'], ['#/audit', 'Audit log', 'audit.read'],
];

function showLogin(message) {
  stopView(); setMe(null); document.title = 'Rules Studio';
  renderLogin(root, { message, onSignedIn: (me) => { setMe(me); location.hash = '#/rules'; startShell(); } });
}

function stopView() { generation += 1; for (const f of leave) f(); leave = []; }

async function signOut() {
  try { await api('POST', '/auth/logout', {}); } catch (e) { if (e.status !== 401) { alert('Could not sign out. Check your connection and try again; your session is still open.'); return; } }
  showLogin();
}

function route() {
  const me = getMe();
  if (!me) return;
  stopView();
  const mine = generation;
  const hash = location.hash || '#/rules';
  const view = document.getElementById('view');
  document.querySelectorAll('nav a').forEach((a) => { if (hash.startsWith(a.getAttribute('href'))) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  const ctx = { me, isCurrent: () => mine === generation, onLeave: (f) => leave.push(f) };
  const [, name, arg] = /^#\/([a-z]+)(?:\/(.+))?$/.exec(hash) || [];
  const id = arg ? decodeURIComponent(arg) : null;
  const views = { rules: () => renderRules(view, ctx), rule: () => renderRuleEditor(view, ctx, id || 'new'), wizard: () => renderWizard(view, ctx), import: () => renderImportExport(view, ctx), languages: () => renderLanguages(view, ctx), releases: () => renderReleases(view, ctx), audit: () => renderAudit(view, ctx) };
  Promise.resolve((views[name] || views.rules)()).then(() => { const t = document.getElementById('page-title'); if (t && mine === generation) t.focus(); })
    .catch(() => { if (mine === generation) clear(view).append(notice('bad', 'This page could not be shown. Reload and try again.')); });
}

function startShell() {
  const me = getMe();
  clear(root);
  const initials = (me.email || '?').slice(0, 2).toUpperCase();
  mount(root, h('header', { class: 'topbar' }, h('span', { class: 'brand' }, h('span', { class: 'brand-mark', 'aria-hidden': 'true' }, 'R'), 'Rules Studio'),
    h('nav', { 'aria-label': 'Main' }, NAV.filter(([, , p]) => can(p)).map(([href, label]) => h('a', { href }, label))),
    h('span', { class: 'who' }, h('span', { class: 'avatar', 'aria-hidden': 'true' }, initials), `${me.email} (${me.role})`), h('button', { class: 'secondary small', type: 'button', onclick: signOut }, 'Sign out')),
  h('main', { id: 'main' }, h('div', { id: 'view' })));
  route();
}

window.addEventListener('hashchange', route);
setSignedOutHandler(() => showLogin('Your session ended. Sign in again to continue; unsaved rule edits are kept in this browser.'));

(async () => {
  try { setMe(await api('GET', '/auth/me')); startShell(); } catch (e) { if (e.status === 401) showLogin(); else { clear(root).append(h('main', { class: 'center-card' }, h('h1', {}, 'Rules Studio'), notice('bad', e.message), h('button', { class: 'primary', type: 'button', onclick: () => location.reload() }, 'Try again'))); } }
})();
