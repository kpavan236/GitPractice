import { h, badge } from './dom.js';

export const PILLARS = ['security', 'reliability', 'maintainability', 'code-quality'];
export const SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
export const ENGINES = ['pattern', 'ast', 'iac-policy', 'secret'];
export const STATUSES = ['draft', 'proposed', 'active', 'deprecated'];

const STATUS_TONE = { draft: 'muted', proposed: 'warn', active: 'good', deprecated: 'muted' };
const SEVERITY_TONE = { CRITICAL: 'bad', HIGH: 'bad', MEDIUM: 'warn', LOW: 'info', INFO: 'muted' };

export const statusBadge = (s) => badge(s, STATUS_TONE[s] || 'muted');
export const severityBadge = (s) => badge(s, SEVERITY_TONE[s] || 'muted');
export const opts = (list, any) => [...(any ? [['', any]] : []), ...list.map((v) => [v, v])];
export const ruleLink = (id) => h('a', { class: 'rule-id', href: `#/rule/${encodeURIComponent(id)}` }, id);
