'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const { waitFor, retryOnPortInUse, connectRefused, freePort } = require('./helpers/wait');

test('waitFor returns the first truthy value, polling an async condition', async () => {
  let n = 0;
  assert.equal(await waitFor(async () => (++n >= 3 ? 'ready' : null), { intervalMs: 1, timeoutMs: 5000 }), 'ready');
  assert.equal(n, 3);
});

test('waitFor keeps polling through a throwing condition, and the timeout message names what was last seen', async () => {
  let n = 0;
  await assert.rejects(waitFor(() => { n += 1; throw new Error('not yet 42'); }, { intervalMs: 1, timeoutMs: 40, message: 'the answer' }), /waiting for the answer; threw .*not yet 42/s);
  assert.ok(n > 1);
  await assert.rejects(waitFor(() => 0, { intervalMs: 1, timeoutMs: 20, message: 'zero to change' }), /waiting for zero to change; last value 0/);
});

test('retryOnPortInUse retries a lost port race with a new port, and rethrows anything else at once', async () => {
  const ports = [];
  const out = await retryOnPortInUse(async (p) => { ports.push(p); if (ports.length < 3) throw Object.assign(new Error('listen EADDRINUSE'), { code: 'EADDRINUSE' }); return 'ok'; });
  assert.equal(out, 'ok');
  assert.equal(ports.length, 3);
  let calls = 0;
  await assert.rejects(retryOnPortInUse(async () => { calls += 1; throw new Error('boom'); }), /boom/);
  assert.equal(calls, 1);
  calls = 0;
  await assert.rejects(retryOnPortInUse(async () => { calls += 1; throw new Error('child said EADDRINUSE'); }, { tries: 2 }), /EADDRINUSE/);
  assert.equal(calls, 2);
});

test('connectRefused is false while a listener accepts and true once it has closed', async () => {
  const srv = net.createServer((s) => s.destroy());
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const { port } = srv.address();
  assert.equal(await connectRefused(port), false);
  await new Promise((r) => srv.close(r));
  assert.equal(await connectRefused(port), true);
  assert.ok((await freePort()) > 0);
});
