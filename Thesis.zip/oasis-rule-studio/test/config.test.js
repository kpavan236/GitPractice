'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { loadStudioConfig } = require('../src/config');

const key = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'studio-cfg-')), 'k.pem');
fs.writeFileSync(key, 'not-a-real-key-but-readable');
const BASE = {
  STUDIO_DATABASE_URL: 'postgres://u:p@localhost:5433/studio', RULES_DATABASE_URL: 'postgres://u:p@localhost:5433/rules',
  PACK_DIR: os.tmpdir(), RELEASE_SIGNING_KEY_FILE: key, RELEASE_SIGNING_KEY_ID: 'k1',
};

test('a complete environment loads with the documented defaults', () => {
  const c = loadStudioConfig(BASE);
  assert.equal(c.port, 4050);
  assert.equal(c.trustProxy, 0);
  assert.equal(c.sessionHours, 8);
  assert.equal(c.secureCookies, true);
  assert.equal(c.signingKeyId, 'k1');
  assert.equal(c.sampleCorpusDir, null);
  assert.match(c.analyzerDir, /oasis-analyzer$/);
  assert.equal(c.grammarDir, path.join(c.analyzerDir, 'src', 'ast', 'grammars'));
});

for (const name of ['STUDIO_DATABASE_URL', 'RULES_DATABASE_URL', 'PACK_DIR', 'RELEASE_SIGNING_KEY_FILE', 'RELEASE_SIGNING_KEY_ID']) {
  test(`a missing ${name} stops start-up with a message naming it`, () => {
    const env = { ...BASE }; delete env[name];
    assert.throws(() => loadStudioConfig(env), new RegExp(`${name} is required`));
  });
}

test('an unreadable signing key file is refused without printing its path contents', () => {
  assert.throws(() => loadStudioConfig({ ...BASE, RELEASE_SIGNING_KEY_FILE: '/no/such/key.pem' }), /RELEASE_SIGNING_KEY_FILE must be the path of a readable PEM file/);
});

test('numbers and flags are checked', () => {
  assert.equal(loadStudioConfig({ ...BASE, PORT: '4060', TRUST_PROXY: '2', SESSION_HOURS: '12', COOKIE_SECURE: 'false' }).port, 4060);
  assert.throws(() => loadStudioConfig({ ...BASE, PORT: '70000' }), /PORT must be a whole number from 1 to 65535/);
  assert.throws(() => loadStudioConfig({ ...BASE, TRUST_PROXY: '11' }), /TRUST_PROXY must be a whole number/);
  assert.throws(() => loadStudioConfig({ ...BASE, SESSION_HOURS: '25' }), /SESSION_HOURS must be a whole number/);
  assert.throws(() => loadStudioConfig({ ...BASE, COOKIE_SECURE: 'maybe' }), /COOKIE_SECURE must be true or false/);
});

test('production requires TRUST_PROXY to be set explicitly (0 means no proxy)', () => {
  assert.throws(() => loadStudioConfig({ ...BASE, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1' }), /TRUST_PROXY must be set in production/);
  assert.equal(loadStudioConfig({ ...BASE, NODE_ENV: 'production', TRUST_PROXY: '0', ALLOW_PLAIN_HTTP: '1' }).trustProxy, 0);
});

test('SAMPLE_CORPUS_DIR must be an existing directory when given', () => {
  assert.throws(() => loadStudioConfig({ ...BASE, SAMPLE_CORPUS_DIR: '/no/such/dir' }), /SAMPLE_CORPUS_DIR must be the path of an existing directory/);
  assert.equal(loadStudioConfig({ ...BASE, SAMPLE_CORPUS_DIR: os.tmpdir() }).sampleCorpusDir, os.tmpdir());
});
