'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { verifyManifest } = require('oasis-rule-server');
const { freshBoth } = require('./helpers/db');
const { loadStudioConfig } = require('../src/config');
const { waitFor, withTimeout, retryOnPortInUse, connectRefused, freePort } = require('./helpers/wait');
// STUDIO_SERVER_UNDER_TEST points the start() tests at a mutated COPY of src/server.js (mutation evidence); by default it is the real file.
const SERVER_FILE = process.env.STUDIO_SERVER_UNDER_TEST ? path.resolve(process.env.STUDIO_SERVER_UNDER_TEST) : path.join(__dirname, '..', 'src', 'server.js');
if (process.env.STUDIO_SERVER_UNDER_TEST) console.error(`services tests: STUDIO_SERVER_UNDER_TEST is set, testing ${SERVER_FILE} instead of src/server.js`);
const { createStudioServices } = require('../src/server');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'svc-'));
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const keyFile = path.join(dir, 'key.pem');
fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }));
// The Studio's config accepts only 1-65535 for PORT (0 is rejected), so the tests ask the OS for a free port first (helpers/wait.js freePort)
// and pass that; a lost race for the number (EADDRINUSE) is retried with a new port by retryOnPortInUse.
let port = 4050;
const env = (dbs) => ({ STUDIO_DATABASE_URL: dbs.identity.url, RULES_DATABASE_URL: dbs.rules.url, COOKIE_SECURE: 'false', PORT: String(port), PACK_DIR: path.join(dir, 'packs'), RELEASE_SIGNING_KEY_FILE: keyFile, RELEASE_SIGNING_KEY_ID: 'k1' });

test('the services object has every dependency defined, and releases is fully wired', async () => {
  const db = await freshBoth();
  try {
    const s = createStudioServices(loadStudioConfig(env(db)), { rulesPool: db.rules.pool, identityPool: db.identity.pool });
    for (const k of ['blobs', 'releases', 'auth', 'repo', 'routes', 'releaseRoutes']) assert.ok(s[k], k);
    for (const m of ['buildCandidate', 'publish', 'rollback', 'latest', 'list', 'diff']) assert.equal(typeof s.releases[m], 'function', m);
  } finally { await db.close(); }
});

test('with the real analyzer, a candidate builds, publishes to beta, and latest(beta) verifies with the public key', async () => {
  const db = await freshBoth();
  try {
    await db.rules.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go'])");
    const { releases, repo } = createStudioServices(loadStudioConfig(env(db)), { rulesPool: db.rules.pool, identityPool: db.identity.pool });
    const rule = {
      id: 'go-skip-verify', language: 'go', pillar: 'security', severity: 'HIGH', title: 'TLS verification disabled',
      description: 'InsecureSkipVerify turns off certificate checks.', files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
      example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
    };
    const who = { actor: 'root@example.test', reason: 'smoke' };
    await repo.create(rule, who);
    await repo.setStatus(rule.id, 'proposed', who);
    await repo.setStatus(rule.id, 'active', { actor: 'dee@example.test', reason: 'smoke' });
    const { releaseNo } = await releases.buildCandidate(who);
    await releases.publish(releaseNo, 'beta', who);
    const latest = await releases.latest('beta');
    const manifest = verifyManifest(latest, { k1: publicKey.export({ type: 'spki', format: 'pem' }) });
    assert.equal(manifest.release, releaseNo);
    assert.deepEqual(manifest.packs.map((p) => p.packId), ['core', 'lang-go']);
  } finally { await db.close(); }
});

// ---- start(): start-up checks, listening, and signal handlers ----
const ADMIN_URL = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';
const UNREACHABLE = 'postgres://postgres:wrongpw-canary@127.0.0.1:1/none';
const listen = (s) => new Promise((resolve) => s.close(resolve));

/**
 * Connections other than ours that are open on the named database right now. pg_stat_activity counts EVERY backend on that database,
 * whoever opened it, so tests pass only a database name that is unique to them (freshBoth's random names) and whose fixture pools are unused.
 */
async function connectionsTo(name) {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try { return Number((await admin.query('SELECT count(*) AS n FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()', [name])).rows[0].n); }
  finally { await admin.end(); }
}
/** Pools end asynchronously (on the server's close event or after a failed start), so wait, generously, for the backends to go; the message says how many were left. */
const noConnectionsTo = (name) => waitFor(async () => {
  const n = await connectionsTo(name);
  if (n !== 0) throw new Error(`${n} connection(s) still open on ${name}`);
  return true;
}, { timeoutMs: 20000, intervalMs: 50, message: `no connection left on ${name}` });

test('start() refuses to listen when the identity database is unreachable, naming it', async () => {
  const { start } = require(SERVER_FILE);
  const db = await freshBoth();
  try {
    const err = await withTimeout(start({ ...env(db), STUDIO_DATABASE_URL: UNREACHABLE }), 30000, 'start() to settle (it must reject, not hang)').then(() => null, (e) => e);
    assert.ok(err, 'start() must reject');
    assert.match(err.message, /identity database/i);
    assert.match(err.message, /STUDIO_DATABASE_URL/);
    for (const leak of ['wrongpw-canary', '127.0.0.1', 'postgres://', 'postgres:']) assert.ok(!err.message.includes(leak), `the error must not contain ${leak}`);
    // No pool left open: the rules database (never checked, but its pool existed) has no connection from the failed start().
    await noConnectionsTo(db.rules.name);
  } finally { await db.close(); }
});

test('start() refuses to listen when the rules database is unreachable, naming it', async () => {
  const { start } = require(SERVER_FILE);
  const db = await freshBoth();
  try {
    const err = await withTimeout(start({ ...env(db), RULES_DATABASE_URL: UNREACHABLE }), 30000, 'start() to settle (it must reject, not hang)').then(() => null, (e) => e);
    assert.ok(err, 'start() must reject');
    assert.match(err.message, /rules database/i);
    assert.match(err.message, /RULES_DATABASE_URL/);
    for (const leak of ['wrongpw-canary', '127.0.0.1', 'postgres://', 'postgres:']) assert.ok(!err.message.includes(leak), `the error must not contain ${leak}`);
    // The identity database answered before the rules check failed: its pool must have been ended again.
    await noConnectionsTo(db.identity.name);
  } finally { await db.close(); }
});

test('start() with both databases reachable listens, answers /readyz, and closing the server ends both pools', async (t) => {
  const { start } = require(SERVER_FILE);
  t.mock.method(console, 'log', () => {});
  const db = await freshBoth();
  try {
    const server = await retryOnPortInUse((p) => { port = p; return start(env(db)); });
    try {
      assert.ok(server.listening, 'start() resolves only once the server is listening');
      const res = await fetch(`http://127.0.0.1:${server.address().port}/readyz`);
      assert.equal(res.status, 200);
      assert.deepEqual(await res.json(), { status: 'ok' });
    } finally { await listen(server); }
    await noConnectionsTo(db.identity.name);
    await noConnectionsTo(db.rules.name);
  } finally { await db.close(); }
});

test('start() called twice in one process adds one SIGTERM/SIGINT handler per server and removes them when each server closes', async (t) => {
  const { start } = require(SERVER_FILE);
  t.mock.method(console, 'log', () => {});
  const db = await freshBoth();
  const base = { term: process.listenerCount('SIGTERM'), int: process.listenerCount('SIGINT') };
  let a; let b;
  try {
    a = await retryOnPortInUse((p) => { port = p; return start(env(db)); });
    b = await retryOnPortInUse((p) => { port = p; return start(env(db)); });
    assert.equal(process.listenerCount('SIGTERM'), base.term + 2);
    assert.equal(process.listenerCount('SIGINT'), base.int + 2);
    await listen(a);
    await new Promise((r) => setImmediate(r));
    assert.equal(process.listenerCount('SIGTERM'), base.term + 1);
    await listen(b);
    await new Promise((r) => setImmediate(r));
    assert.equal(process.listenerCount('SIGTERM'), base.term);
    assert.equal(process.listenerCount('SIGINT'), base.int);
  } finally {
    for (const srv of [a, b]) if (srv && srv.listening) await listen(srv);
    await new Promise((r) => setImmediate(r));
    await db.close();
  }
});

// ---- spy pools: every start-up failure path ends BOTH pools; the driver's text never reaches the message ----
const RULES_URL = 'postgres://rulesuser:rulespw-canary@rules-host.invalid:5432/rulesdb';
const IDENTITY_URL = 'postgres://iduser:idpw-canary@identity-host.invalid:5432/iddb';
const spyEnv = () => ({ STUDIO_DATABASE_URL: IDENTITY_URL, RULES_DATABASE_URL: RULES_URL, COOKIE_SECURE: 'false', PORT: String(port), PACK_DIR: path.join(dir, 'packs'), RELEASE_SIGNING_KEY_FILE: keyFile, RELEASE_SIGNING_KEY_ID: 'k1' });
/** A createPool seam returning spy pools; `failing` maps a URL to the error its query rejects with. */
function spyPools(failing = {}) {
  const pools = {};
  const createPool = (url) => {
    pools[url] = { ended: 0, async query() { if (failing[url]) throw failing[url]; return { rows: [{ '?column?': 1 }] }; }, async end() { this.ended += 1; } };
    return pools[url];
  };
  return { createPool, pools };
}
const embedded = (url) => new Error(`connect failed for ${url} (user ${new URL(url).username}, host ${new URL(url).hostname})`);
const NOT_IN_MESSAGE = ['rulespw-canary', 'idpw-canary', 'rulesuser', 'iduser', 'rules-host.invalid', 'identity-host.invalid', 'postgres://'];

test('identity database unreachable: both pools are ended, and the message has the cause and the setting but none of the driver text', async () => {
  const { start } = require(SERVER_FILE);
  const { createPool, pools } = spyPools({ [IDENTITY_URL]: embedded(IDENTITY_URL) });
  port = await freePort();
  const err = await start(spyEnv(), { createPool }).then(() => null, (e) => e);
  assert.ok(err);
  assert.match(err.message, /identity database/i);
  assert.match(err.message, /STUDIO_DATABASE_URL/);
  for (const leak of NOT_IN_MESSAGE) assert.ok(!err.message.includes(leak), `the error must not contain ${leak}`);
  assert.equal(pools[IDENTITY_URL].ended, 1);
  assert.equal(pools[RULES_URL].ended, 1);
});

test('rules database unreachable: both pools are ended, and the message has the cause and the setting but none of the driver text', async () => {
  const { start } = require(SERVER_FILE);
  const { createPool, pools } = spyPools({ [RULES_URL]: embedded(RULES_URL) });
  port = await freePort();
  const err = await start(spyEnv(), { createPool }).then(() => null, (e) => e);
  assert.ok(err);
  assert.match(err.message, /rules database/i);
  assert.match(err.message, /RULES_DATABASE_URL/);
  for (const leak of NOT_IN_MESSAGE) assert.ok(!err.message.includes(leak), `the error must not contain ${leak}`);
  assert.equal(pools[IDENTITY_URL].ended, 1);
  assert.equal(pools[RULES_URL].ended, 1);
});

test('a driver error code is kept in the message (still without the driver text)', async () => {
  const { start } = require(SERVER_FILE);
  const e = Object.assign(embedded(IDENTITY_URL), { code: 'ECONNREFUSED' });
  const { createPool } = spyPools({ [IDENTITY_URL]: e });
  port = await freePort();
  const err = await start(spyEnv(), { createPool }).then(() => null, (x) => x);
  assert.match(err.message, /ECONNREFUSED/);
  for (const leak of NOT_IN_MESSAGE) assert.ok(!err.message.includes(leak), `the error must not contain ${leak}`);
});

test('a listen error (port in use) rejects and ends both pools, with no signal handler left behind', async () => {
  const { start } = require(SERVER_FILE);
  const blocker = require('node:net').createServer();
  await new Promise((r) => blocker.listen(0, r));
  try {
    port = blocker.address().port;
    const { createPool, pools } = spyPools();
    const base = process.listenerCount('SIGTERM');
    const err = await start(spyEnv(), { createPool }).then(() => null, (e) => e);
    assert.equal(err && err.code, 'EADDRINUSE');
    assert.equal(pools[IDENTITY_URL].ended, 1);
    assert.equal(pools[RULES_URL].ended, 1);
    assert.equal(process.listenerCount('SIGTERM'), base);
  } finally { await new Promise((r) => blocker.close(r)); }
});

// ---- the real process: SIGTERM drains in-flight requests, ends the pools, then exits 0; a second SIGTERM changes nothing ----
// Deterministic ordering, no sleeps: `Expect: 100-continue` makes the server answer "100 Continue" as soon as it has read the request headers
// (proof the request is in flight) while the body is withheld; the first SIGTERM goes out only then. The second SIGTERM goes out only once a
// fresh TCP connect is refused (proof server.close() ran, i.e. shutdown is under way). Only after that is the body completed.
/** Spawns the real server on a free port and waits for its 'listening' line; a lost port race (EADDRINUSE) is reported as such so the caller retries. */
async function spawnStudio(db, chosenPort) {
  const { spawn } = require('node:child_process');
  port = chosenPort;
  const child = spawn(process.execPath, [SERVER_FILE], { cwd: path.join(__dirname, '..'), env: { PATH: process.env.PATH, ...env(db) }, stdio: ['ignore', 'pipe', 'pipe'] });
  const run = { child, out: '', port: chosenPort, gone: false };
  run.exited = new Promise((resolve) => child.once('exit', (code, signal) => { run.gone = true; resolve({ code, signal }); }));
  child.stdout.on('data', (d) => { run.out += d; });
  child.stderr.on('data', (d) => { run.out += d; });
  await waitFor(() => run.out.includes('listening') || run.out.includes('EADDRINUSE') || run.gone, { timeoutMs: 30000, message: 'the Studio process to log "listening"' }).catch((err) => { throw new Error(`${err.message}\nchild output: ${run.out}`); });
  if (!run.out.includes('listening')) {
    if (!run.gone) child.kill('SIGKILL');
    await run.exited;
    throw Object.assign(new Error(`the Studio did not start: ${run.out}`), { code: run.out.includes('EADDRINUSE') ? 'EADDRINUSE' : undefined });
  }
  return run;
}

test('SIGTERM lets an in-flight request finish, then the process exits 0; a second SIGTERM during shutdown changes nothing', async () => {
  const http = require('node:http');
  const db = await freshBoth();
  let run;
  try {
    run = await retryOnPortInUse((p) => spawnStudio(db, p));
    const { child } = run;
    const body = JSON.stringify({ email: 'nobody@example.test', password: 'not-a-password' });
    const half = Math.floor(body.length / 2);
    let req;
    const responded = new Promise((resolve, reject) => {
      req = http.request({ host: '127.0.0.1', port: run.port, method: 'POST', path: '/v1/studio/auth/login', agent: false, headers: { Expect: '100-continue', 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } }, (res) => {
        res.resume();
        res.on('end', () => resolve({ status: res.statusCode, complete: res.complete }));
        res.on('error', reject);
      });
      req.on('error', reject);
    });
    responded.catch(() => {});   // reported where it is awaited; this only stops an early rejection from being "unhandled"
    const continued = new Promise((resolve, reject) => { req.once('continue', resolve); req.once('error', reject); });
    await withTimeout(continued, 30000, 'the server to answer 100 Continue (the request is in flight)');
    req.write(body.slice(0, half));

    child.kill('SIGTERM');
    await waitFor(() => connectRefused(run.port), { timeoutMs: 30000, intervalMs: 20, message: 'the server to stop accepting connections after SIGTERM' });
    child.kill('SIGTERM');   // the second signal, during shutdown
    assert.equal(run.gone, false, `the process must still be running while the in-flight request is open: ${run.out}`);
    req.end(body.slice(half));

    const res = await withTimeout(responded, 30000, 'the in-flight request to be answered');
    assert.ok(res.status >= 200 && res.status < 600, `the in-flight request must get a response (got ${res.status})`);
    assert.equal(res.complete, true, 'the response must arrive in full');
    const exit = await withTimeout(run.exited, 30000, 'the process to exit');
    assert.equal(exit.code, 0, `exit code (signal ${exit.signal}): ${run.out}`);
  } finally {
    if (run && !run.gone) run.child.kill('SIGKILL');
    if (run) await run.exited;
    await db.close();
  }
});
