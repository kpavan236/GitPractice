'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { withStudio, goRule } = require('./helpers/studio');

const R = 'because the team asked';
const activate = async (repo, rule) => {
  await repo.create(rule, { actor: 'ann@example.test', reason: R });
  await repo.setStatus(rule.id, 'proposed', { actor: 'ann@example.test', reason: R });
  await repo.setStatus(rule.id, 'active', { actor: 'root@example.test', reason: R });
};
const count = async (pool, t) => Number((await pool.query(`SELECT count(*) FROM ${t}`)).rows[0].count);

test('an admin lists releases: empty first, then after a build', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  const empty = await root('GET', '/releases');
  assert.equal(empty.status, 200);
  assert.deepEqual(empty.body, { releases: [], channels: { beta: null, stable: null } });
  await activate(repo, goRule());
  const built = await root('POST', '/releases/candidate', { reason: R });
  assert.equal(built.status, 201);
  assert.equal(typeof built.body.releaseNo, 'number');
  assert.ok(built.body.summary);
  const list = await root('GET', '/releases');
  assert.equal(list.body.releases.length, 1);
  const [rel] = list.body.releases;
  assert.deepEqual(Object.keys(rel).sort(), ['createdAt', 'createdBy', 'packCount', 'releaseNo', 'ruleCount', 'state']);
  assert.equal(rel.state, 'candidate');
  assert.equal(rel.createdBy, 'root@example.test');
  assert.equal(rel.ruleCount, 1);
  assert.equal(rel.packCount, 2);
  assert.ok(!/signature|keyId/.test(list.text));
}));

test('releases are listed newest first', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  await activate(repo, goRule());
  const a = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  const b = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  assert.deepEqual((await root('GET', '/releases')).body.releases.map((r) => r.releaseNo), [b, a]);
}));

test('an author gets 403 on candidate, publish and rollback but 200 on list and diff', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  const ann = await as('ann');
  await activate(repo, goRule());
  const no = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  assert.equal((await ann('GET', '/releases')).status, 200);
  assert.equal((await ann('GET', `/releases/${no}/diff`)).status, 200);
  assert.equal((await ann('POST', '/releases/candidate', { reason: R })).status, 403);
  assert.equal((await ann('POST', `/releases/${no}/publish`, { channel: 'beta', reason: R })).status, 403);
  assert.equal((await ann('POST', '/releases/rollback', { channel: 'beta', toReleaseNo: no, reason: R })).status, 403);
  assert.equal((await ann('POST', '/releases/candidate', {})).status, 403, 'permission is checked before the reason');
}));

test('candidate without a reason is 400 and stores nothing', () => withStudio(async ({ as, pool }) => {
  const root = await as('root');
  assert.equal((await root('POST', '/releases/candidate', {})).status, 400);
  assert.equal((await root('POST', '/releases/candidate', { reason: '  ' })).status, 400);
  assert.equal(await count(pool, 'release'), 0);
}));

test('a failing active rule fixture gives 422 FIXTURE_FAILED naming the rule, and nothing is stored', () => withStudio(async ({ as, repo, pool }) => {
  const root = await as('root');
  await activate(repo, goRule('go-good'));
  await activate(repo, goRule('go-bad'));
  const res = await root('POST', '/releases/candidate', { reason: R });
  assert.equal(res.status, 422);
  assert.equal(res.body.error, 'FIXTURE_FAILED');
  assert.deepEqual(res.body.failures, ['go-bad']);
  assert.equal(await count(pool, 'release'), 0);
  assert.equal(await count(pool, 'pack'), 0);
}, { releaseTester: { testRule: async (r) => (r.id === 'go-bad' ? { ok: false, problems: ['nope'] } : { ok: true, problems: [] }) } }));

test('candidate, publish to beta, publish to stable, and the list shows the channel heads', () => withStudio(async ({ as, repo, pool }) => {
  const root = await as('root');
  await activate(repo, goRule());
  const no = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  const beta = await root('POST', `/releases/${no}/publish`, { channel: 'beta', reason: R });
  assert.equal(beta.status, 200);
  assert.equal(beta.body.channel, 'beta');
  let list = (await root('GET', '/releases')).body;
  assert.deepEqual(list.channels, { beta: no, stable: null });
  assert.equal(list.releases[0].state, 'beta');
  assert.equal((await root('POST', `/releases/${no}/publish`, { channel: 'stable', reason: R })).status, 200);
  list = (await root('GET', '/releases')).body;
  assert.deepEqual(list.channels, { beta: no, stable: no });
  assert.equal(list.releases[0].state, 'stable');
  const audit = (await pool.query("SELECT actor, reason FROM audit WHERE action = 'release.publish' ORDER BY audit_id")).rows;
  assert.deepEqual(audit, [{ actor: 'root@example.test', reason: R }, { actor: 'root@example.test', reason: R }]);
}));

test('publishing to stable before beta is 409; a bad channel or missing reason is 400; an unknown release is 404', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  await activate(repo, goRule());
  const no = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  const early = await root('POST', `/releases/${no}/publish`, { channel: 'stable', reason: R });
  assert.equal(early.status, 409);
  assert.match(early.body.message, /beta/);
  assert.equal((await root('POST', `/releases/${no}/publish`, { channel: 'gamma', reason: R })).status, 400);
  assert.equal((await root('POST', `/releases/${no}/publish`, { reason: R })).status, 400);
  assert.equal((await root('POST', `/releases/${no}/publish`, { channel: 'beta' })).status, 400);
  assert.equal((await root('POST', '/releases/9999/publish', { channel: 'beta', reason: R })).status, 404);
  assert.equal((await root('POST', '/releases/abc/publish', { channel: 'beta', reason: R })).status, 400);
}));

test('rollback of stable to an earlier published release works and is audited with actor and reason', () => withStudio(async ({ as, repo, pool }) => {
  const root = await as('root');
  const dee = await as('dee');
  await activate(repo, goRule());
  const one = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  await root('POST', `/releases/${one}/publish`, { channel: 'beta', reason: R });
  await root('POST', `/releases/${one}/publish`, { channel: 'stable', reason: R });
  await activate(repo, goRule('go-two'));
  const two = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  await root('POST', `/releases/${two}/publish`, { channel: 'beta', reason: R });
  await root('POST', `/releases/${two}/publish`, { channel: 'stable', reason: R });
  assert.equal((await root('GET', '/releases')).body.channels.stable, two);
  const back = await dee('POST', '/releases/rollback', { channel: 'stable', toReleaseNo: one, reason: 'bad pack' });
  assert.equal(back.status, 200);
  assert.equal((await root('GET', '/releases')).body.channels.stable, one);
  const row = (await pool.query("SELECT actor, reason, subject FROM audit WHERE action = 'release.rollback'")).rows;
  assert.deepEqual(row, [{ actor: 'dee@example.test', reason: 'bad pack', subject: String(one) }]);
  assert.equal((await root('POST', '/releases/rollback', { channel: 'stable', toReleaseNo: one })).status, 400);
  assert.equal((await root('POST', '/releases/rollback', { channel: 'nope', toReleaseNo: one, reason: R })).status, 400);
  assert.equal((await root('POST', '/releases/rollback', { channel: 'stable', toReleaseNo: 'x', reason: R })).status, 400);
  assert.equal((await root('POST', '/releases/rollback', { channel: 'stable', toReleaseNo: 9999, reason: R })).status, 404);
}));

test('rolling back to a candidate is a 409', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  await activate(repo, goRule());
  const no = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  const res = await root('POST', '/releases/rollback', { channel: 'beta', toReleaseNo: no, reason: R });
  assert.equal(res.status, 409);
}));

test('diff of a release; bad numbers are 400; unknown is 404', () => withStudio(async ({ as, repo }) => {
  const root = await as('root');
  await activate(repo, goRule());
  const no = (await root('POST', '/releases/candidate', { reason: R })).body.releaseNo;
  const diff = await root('GET', `/releases/${no}/diff`);
  assert.equal(diff.status, 200);
  assert.deepEqual(diff.body.added, ['go-skip-verify']);
  for (const bad of ['0', '-1', 'abc', '1.5']) assert.equal((await root('GET', `/releases/${bad}/diff`)).status, 400, bad);
  assert.equal((await root('GET', '/releases/9999/diff')).status, 404);
}));

test('unauthenticated is 401 and a POST without the CSRF header is 403', () => withStudio(async ({ base, as, repo }) => {
  const res = await fetch(`${base}/v1/studio/releases`);
  assert.equal(res.status, 401);
  const root = await as('root');
  await activate(repo, goRule());
  const raw = await root('GET', '/releases', undefined, { raw: true });
  assert.equal(raw.status, 200);
  const login = await fetch(`${base}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'root@example.test', password: 'correct horse battery staple' }) });
  const cookie = login.headers.getSetCookie().find((c) => c.startsWith('studio_session=')).split(';')[0];
  const post = await fetch(`${base}/v1/studio/releases/candidate`, { method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: JSON.stringify({ reason: R }) });
  assert.equal(post.status, 403);
}));
