'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const { spawn } = require('node:child_process');
const express = require('express');
const { freshBoth } = require('./helpers/db');
const { createStudioApp } = require('../src/app');
const { createAuth } = require('../src/auth');
const { securityHeaders, CSP } = require('../src/security-headers');
const { hashPassword, verifyPassword, passwordProblem, MIN_LENGTH, MAX_LENGTH } = require('../src/password');
// STAFF_CLI_UNDER_TEST lets a mutation run point these tests at a modified copy of the CLI.
const STAFF_CLI = process.env.STAFF_CLI_UNDER_TEST || path.join(__dirname, '..', 'src', 'staff-cli.js');
if (process.env.STAFF_CLI_UNDER_TEST) console.error(`auth tests: STAFF_CLI_UNDER_TEST is set, testing ${STAFF_CLI} instead of src/staff-cli.js`);
const { createStaff } = require(STAFF_CLI);

const PW = 'correct horse battery staple';
const EXPECTED_CSP = "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";

async function addStaff(pool, email, role, password = PW, active = true) {
  await pool.query('INSERT INTO staff (user_id, email, password_hash, role, active) VALUES ($1,$2,$3,$4,$5)',
    [crypto.randomUUID(), email, await hashPassword(password), role, active]);
}

async function setup(fn, authOpts = {}) {
  const db = await freshBoth();
  const { identity, rules } = db;
  let server;
  try {
    const logs = [];
    const auth = createAuth({ pool: identity.pool, secureCookies: false, sessionHours: 8, log: (m) => logs.push(m), ...authOpts });
    const app = createStudioApp({ auth, pool: identity.pool });
    // a stand-in for Task 10's routes, mounted the way they will be: behind requireSession and a permission
    const guarded = express();
    guarded.post('/publish', auth.requireSession, auth.requirePermission('release.publish'), (_req, res) => res.json({ ok: true }));
    guarded.get('/read', auth.requireSession, auth.requirePermission('rule.read'), (req, res) => res.json({ who: req.staff }));
    const gserver = await new Promise((resolve) => { const s = guarded.listen(0, '127.0.0.1', () => resolve(s)); });
    server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    const base = `http://127.0.0.1:${server.address().port}`;
    const gbase = `http://127.0.0.1:${gserver.address().port}`;
    try { await fn({ db, pool: identity.pool, rulesPool: rules.pool, identity, rules, base, gbase, auth, logs }); }
    finally { await new Promise((r) => { gserver.closeAllConnections(); gserver.close(r); }); }
  } finally {
    if (server) await new Promise((r) => { server.closeAllConnections(); server.close(r); });
    await db.close();
  }
}

const post = (url, body, headers = {}) => fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });
const cookieOf = (res) => (res.headers.getSetCookie().find((c) => c.startsWith('studio_session=')) || '').split(';')[0];
async function login(base, email = 'ann@example.test', password = PW) {
  const res = await post(`${base}/v1/studio/auth/login`, { email, password });
  return { res, cookie: cookieOf(res), body: await res.json() };
}

test('password policy: scrypt hashes verify, wrong ones do not, and weak ones are refused', async () => {
  const h = await hashPassword(PW);
  assert.match(h, /^scrypt\$\d+\$\d+\$\d+\$/);
  assert.equal(await verifyPassword(PW, h), true);
  assert.equal(await verifyPassword(PW + 'x', h), false);
  assert.equal(await verifyPassword(PW, 'garbage'), false);
  assert.notEqual(await hashPassword(PW), h, 'a random salt per hash');
  assert.equal(MIN_LENGTH, 12);
  assert.equal(MAX_LENGTH, 128);
  assert.ok(passwordProblem('short', 'a@b.test'));
  assert.ok(passwordProblem('a'.repeat(MAX_LENGTH + 1), 'a@b.test'));
  assert.ok(passwordProblem('password1234', 'a@b.test'));
  assert.ok(passwordProblem('zzzzzzzzzzzzzz', 'a@b.test'));
  assert.ok(passwordProblem('xxannabelle-xx-1', 'annabelle@b.test'), 'contains the email name');
  assert.ok(passwordProblem(undefined, 'a@b.test'));
  assert.equal(passwordProblem(PW, 'ann@example.test'), null);
});

test('securityHeaders sets the strict CSP and the other headers', () => {
  assert.equal(CSP, EXPECTED_CSP);
  const set = {};
  let nexted = false;
  securityHeaders({}, { set: (k, v) => { set[k] = v; } }, () => { nexted = true; });
  assert.equal(nexted, true);
  assert.equal(set['Content-Security-Policy'], EXPECTED_CSP);
  assert.equal(set['X-Frame-Options'], 'DENY');
  assert.equal(set['Referrer-Policy'], 'no-referrer');
  assert.equal(set['X-Content-Type-Options'], 'nosniff');
});

test('with no Studio routes mounted, an unknown Studio path is a 404 and the sign-in routes still answer', () => setup(async ({ base }) => {
  const missing = await fetch(`${base}/v1/studio/rules`);
  assert.equal(missing.status, 404);
  assert.equal(missing.headers.get('content-security-policy'), EXPECTED_CSP);
  assert.equal((await fetch(`${base}/v1/studio/auth/me`)).status, 401);
}));

test('login sets a hardened cookie, stores only a hash, and me returns role, permissions and csrf', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const { res, cookie, body } = await login(base, ' Ann@Example.TEST ');
  assert.equal(res.status, 200);
  const raw = res.headers.getSetCookie().find((c) => c.startsWith('studio_session='));
  assert.match(raw, /HttpOnly/);
  assert.match(raw, /SameSite=Strict/);
  assert.doesNotMatch(raw, /Secure/, 'secureCookies false in this test');
  assert.equal(body.email, 'ann@example.test');
  assert.equal(body.role, 'author');
  assert.ok(body.permissions.includes('rule.write'));
  assert.ok(!body.permissions.includes('release.publish'));
  assert.match(body.csrf, /^[A-Za-z0-9_-]{43}$/);
  const token = cookie.split('=')[1];
  const rows = (await pool.query('SELECT token_hash, csrf FROM session')).rows;
  assert.equal(rows.length, 1);
  assert.equal(rows[0].token_hash, crypto.createHash('sha256').update(token).digest('hex'));
  assert.notEqual(rows[0].token_hash, token);
  const me = await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie } });
  assert.equal(me.status, 200);
  assert.deepEqual(await me.json(), { email: 'ann@example.test', role: 'author', permissions: body.permissions, csrf: body.csrf });
}));

test('the cookie is Secure when secureCookies is on', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const { res } = await login(base);
  assert.match(res.headers.getSetCookie().find((c) => c.startsWith('studio_session=')), /Secure/);
}, { secureCookies: true }));

test('wrong password and unknown email give the identical 401, and nothing sensitive is logged', () => setup(async ({ pool, base, logs }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const a = await post(`${base}/v1/studio/auth/login`, { email: 'ann@example.test', password: 'wrong password here' });
  const b = await post(`${base}/v1/studio/auth/login`, { email: 'nobody@example.test', password: 'wrong password here' });
  assert.equal(a.status, 401);
  assert.equal(b.status, 401);
  assert.equal(await a.text(), await b.text());
  assert.equal(a.headers.getSetCookie().length, 0);
  assert.ok(logs.length >= 2);
  const all = logs.join('\n');
  assert.ok(!all.includes('wrong password here'));
  assert.ok(!all.toLowerCase().includes('ann@example.test'));
  assert.ok(!all.toLowerCase().includes('nobody@example.test'));
  assert.match(all, /[0-9a-f]{16}/);
}));

test('an unknown email still pays for a hash (similar timing to a wrong password)', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const time = async (email) => { const t = process.hrtime.bigint(); await post(`${base}/v1/studio/auth/login`, { email, password: 'wrong password here' }); return Number(process.hrtime.bigint() - t) / 1e6; };
  await time('ann@example.test');
  const known = await time('ann@example.test');
  const unknown = await time('nobody@example.test');
  assert.ok(unknown > known * 0.4, `unknown ${unknown}ms vs known ${known}ms: the unknown address was not hashed`);
}));

test('a deactivated account cannot sign in, and malformed bodies are 400', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'old@example.test', 'author', PW, false);
  assert.equal((await login(base, 'old@example.test')).res.status, 401);
  assert.equal((await post(`${base}/v1/studio/auth/login`, { email: 'x@example.test' })).status, 400);
  assert.equal((await post(`${base}/v1/studio/auth/login`, { email: ['a'], password: PW })).status, 400);
  const bad = await fetch(`${base}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{nope' });
  assert.equal(bad.status, 400);
}));

test('five failed logins per address within a minute give 429, even for the right password; the window then reopens', () => {
  let t = 1_000_000;
  return setup(async ({ pool, base }) => {
    await addStaff(pool, 'ann@example.test', 'author');
    for (let i = 0; i < 5; i += 1) assert.equal((await login(base, 'ann@example.test', 'wrong password here')).res.status, 401);
    const blocked = await login(base, 'ann@example.test', PW);
    assert.equal(blocked.res.status, 429);
    assert.ok(Number(blocked.res.headers.get('retry-after')) >= 1);
    assert.deepEqual(blocked.body, { error: 'TOO_MANY_ATTEMPTS' });
    assert.equal((await login(base, 'other@example.test', 'wrong password here')).res.status, 401, 'another address is unaffected');
    t += 61_000;
    assert.equal((await login(base, 'ann@example.test', PW)).res.status, 200);
  }, { now: () => t });
});

test('unknown addresses are throttled too, so the 429 does not reveal which addresses exist', () => setup(async ({ base }) => {
  for (let i = 0; i < 5; i += 1) await login(base, 'ghost@example.test', 'wrong password here');
  assert.equal((await login(base, 'ghost@example.test', 'wrong password here')).res.status, 429);
}));

test('me without a cookie, with a junk cookie, or after expiry is 401', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  assert.equal((await fetch(`${base}/v1/studio/auth/me`)).status, 401);
  assert.equal((await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie: 'studio_session=nonsense' } })).status, 401);
  const { cookie } = await login(base);
  assert.equal((await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie } })).status, 200);
  await pool.query("UPDATE session SET expires_at = now() - interval '1 minute'");
  assert.equal((await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie } })).status, 401);
}));

test('a session stops working when the account is deactivated', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const { cookie } = await login(base);
  await pool.query('UPDATE staff SET active = false');
  assert.equal((await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie } })).status, 401);
}));

test('logout needs the csrf header, then ends the session for good and clears the cookie', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const { cookie, body } = await login(base);
  const no = await post(`${base}/v1/studio/auth/logout`, {}, { cookie });
  assert.equal(no.status, 403);
  assert.deepEqual(await no.json(), { error: 'CSRF' });
  const bad = await post(`${base}/v1/studio/auth/logout`, {}, { cookie, 'x-csrf-token': 'x'.repeat(43) });
  assert.equal(bad.status, 403);
  const nonAscii = await post(`${base}/v1/studio/auth/logout`, {}, { cookie, 'x-csrf-token': Buffer.from('é'.repeat(21) + 'a', 'utf8').toString('latin1') });
  assert.equal(nonAscii.status, 403);
  const ok = await post(`${base}/v1/studio/auth/logout`, {}, { cookie, 'x-csrf-token': body.csrf });
  assert.equal(ok.status, 200);
  assert.match(ok.headers.getSetCookie().find((c) => c.startsWith('studio_session=')), /Max-Age=0|Expires=Thu, 01 Jan 1970/);
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM session')).rows[0].n, 0);
  assert.equal((await fetch(`${base}/v1/studio/auth/me`, { headers: { cookie } })).status, 401);
}));

test('state-changing requests need x-csrf-token; reads do not; permissions come from role_permission', () => setup(async ({ pool, base, gbase }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  await addStaff(pool, 'root@example.test', 'admin');
  const ann = await login(base, 'ann@example.test');
  const root = await login(base, 'root@example.test');

  const noCsrf = await post(`${gbase}/publish`, {}, { cookie: root.cookie });
  assert.equal(noCsrf.status, 403);
  assert.deepEqual(await noCsrf.json(), { error: 'CSRF' });
  const noCookie = await post(`${gbase}/publish`, {});
  assert.equal(noCookie.status, 401);

  const forbidden = await post(`${gbase}/publish`, {}, { cookie: ann.cookie, 'x-csrf-token': ann.body.csrf });
  assert.equal(forbidden.status, 403);
  assert.deepEqual(await forbidden.json(), { error: 'FORBIDDEN' });
  const allowed = await post(`${gbase}/publish`, {}, { cookie: root.cookie, 'x-csrf-token': root.body.csrf });
  assert.equal(allowed.status, 200);
  const crossed = await post(`${gbase}/publish`, {}, { cookie: root.cookie, 'x-csrf-token': ann.body.csrf });
  assert.equal(crossed.status, 403, "another session's csrf is not accepted");

  const read = await fetch(`${gbase}/read`, { headers: { cookie: ann.cookie } });
  assert.equal(read.status, 200);
  const { who } = await read.json();
  assert.equal(who.email, 'ann@example.test');
  assert.equal(who.role, 'author');
  assert.ok(who.userId);

  await pool.query("DELETE FROM role_permission WHERE role='author' AND permission='rule.read'");
  assert.equal((await fetch(`${gbase}/read`, { headers: { cookie: ann.cookie } })).status, 403, 'a revoked permission takes effect on the next request');
}));

test('every response carries the CSP, including errors, 404s, logins and the rate limit', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const urls = [
    fetch(`${base}/healthz`),
    fetch(`${base}/nope`),
    fetch(`${base}/v1/studio/auth/me`),
    post(`${base}/v1/studio/auth/login`, { email: 'ann@example.test', password: 'wrong password here' }),
    post(`${base}/v1/studio/auth/login`, { email: 'ann@example.test' }),
    fetch(`${base}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{nope' }),
  ];
  for (const res of await Promise.all(urls)) {
    assert.equal(res.headers.get('content-security-policy'), EXPECTED_CSP);
    assert.equal(res.headers.get('x-frame-options'), 'DENY');
    assert.equal(res.headers.get('referrer-policy'), 'no-referrer');
  }
  const limited = createStudioApp({ auth: createAuth({ pool, secureCookies: false, sessionHours: 1 }), pool, limiter: (_q, r) => r.status(429).json({ error: 'TOO_MANY_REQUESTS' }) });
  const s = await new Promise((resolve) => { const x = limited.listen(0, '127.0.0.1', () => resolve(x)); });
  try {
    const res = await fetch(`http://127.0.0.1:${s.address().port}/nope`);
    assert.equal(res.status, 429);
    assert.equal(res.headers.get('content-security-policy'), EXPECTED_CSP);
  } finally { await new Promise((r) => { s.closeAllConnections(); s.close(r); }); }
}));

test('auth responses are not cacheable', () => setup(async ({ pool, base }) => {
  await addStaff(pool, 'ann@example.test', 'author');
  const { res } = await login(base);
  assert.equal(res.headers.get('cache-control'), 'no-store');
  assert.equal((await fetch(`${base}/v1/studio/auth/me`)).headers.get('cache-control'), 'no-store');
}));

test('createStaff stores a hashed password, lowercases the email, audits, and refuses weak passwords, bad roles and duplicates', () => setup(async ({ pool, rulesPool, base }) => {
  const id = await createStaff({ pool, auditPool: rulesPool, email: 'New.Person@Example.test', role: 'admin', password: PW });
  assert.ok(id);
  const row = (await pool.query('SELECT email, role, password_hash FROM staff')).rows[0];
  assert.equal(row.email, 'new.person@example.test');
  assert.equal(row.role, 'admin');
  assert.ok(!row.password_hash.includes(PW));
  const audit = (await rulesPool.query("SELECT actor, action, subject FROM audit WHERE action='staff.create'")).rows;
  assert.equal(audit.length, 1);
  assert.equal(audit[0].subject, 'new.person@example.test');
  assert.ok(!JSON.stringify(audit).includes(PW));
  assert.equal((await login(base, 'new.person@example.test')).res.status, 200);
  await assert.rejects(createStaff({ pool, auditPool: rulesPool, email: 'a@example.test', role: 'author', password: 'short' }), /at least 12/);
  await assert.rejects(createStaff({ pool, auditPool: rulesPool, email: 'a@example.test', role: 'owner', password: PW }), /author or admin/);
  await assert.rejects(createStaff({ pool, auditPool: rulesPool, email: 'not-an-email', role: 'author', password: PW }), /email/i);
  await assert.rejects(createStaff({ pool, auditPool: rulesPool, email: 'NEW.person@example.test', role: 'author', password: PW }), /already exists/);
}));

test('the create-staff CLI reads the password from a pipe, never from argv, and never prints it', () => setup(async ({ identity, rules, pool }) => {
  const cli = STAFF_CLI;
  const run = (args, stdin, env = {}) => new Promise((resolve) => {
    const p = spawn(process.execPath, [cli, ...args], { env: { ...process.env, STUDIO_DATABASE_URL: identity.url, RULES_DATABASE_URL: rules.url, ...env } });
    let out = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { out += d; });
    p.on('close', (code) => resolve({ code, out }));
    p.stdin.end(stdin);
  });
  const ok = await run(['cli.user@example.test', 'author'], `${PW}\n`);
  assert.equal(ok.code, 0, ok.out);
  assert.ok(!ok.out.includes(PW));
  assert.equal((await pool.query("SELECT role FROM staff WHERE email='cli.user@example.test'")).rows[0].role, 'author');
  const extra = await run(['x@example.test', 'author', 'hunter2hunter2'], `${PW}\n`);
  assert.notEqual(extra.code, 0, 'a password on the command line is refused');
  assert.ok(!extra.out.includes('hunter2hunter2'));
  const weak = await run(['weak@example.test', 'author'], 'short\n');
  assert.notEqual(weak.code, 0);
  assert.ok(!weak.out.includes('short\n'));
  const bad = await run(['a@example.test', 'owner'], `${PW}\n`);
  assert.notEqual(bad.code, 0);
  const none = await run([], '');
  assert.notEqual(none.code, 0);
  assert.match(none.out, /Usage/);
}));

test('createStaff without auditPool is refused before any staff row is written', () => setup(async ({ pool }) => {
  await assert.rejects(createStaff({ pool, email: 'noaudit@example.test', role: 'author', password: PW }), /auditPool is required/);
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM staff WHERE email = $1', ['noaudit@example.test'])).rows[0].n, 0);
}));

for (const missing of ['STUDIO_DATABASE_URL', 'RULES_DATABASE_URL']) {
  test(`the create-staff CLI refuses to start without ${missing}, before asking for a password or writing a staff row`, () => setup(async ({ identity, rules, pool }) => {
    const env = { ...process.env, STUDIO_DATABASE_URL: identity.url, RULES_DATABASE_URL: rules.url };
    delete env[missing];
    const secret = 'must-not-be-read-correct-horse-1';
    const result = await new Promise((resolve, reject) => {
      const p = spawn(process.execPath, [STAFF_CLI, 'nopass@example.test', 'author'], { env, timeout: 30000 });
      let out = '';
      p.stdout.on('data', (d) => { out += d; });
      p.stderr.on('data', (d) => { out += d; });
      p.on('error', reject);
      p.on('close', (code, signal) => resolve({ code, signal, out }));
      p.stdin.end(`${secret}\n`);
    });
    assert.equal(result.signal, null, 'exited by itself, not killed by the timeout');
    assert.notEqual(result.code, 0);
    assert.ok(result.out.includes(`${missing} is required.`), result.out);
    assert.ok(!result.out.includes(secret));
    assert.ok(!/Password|Repeat/.test(result.out), 'no password prompt');
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM staff')).rows[0].n, 0);
  }));
}
