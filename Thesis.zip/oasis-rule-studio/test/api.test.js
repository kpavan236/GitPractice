'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { withStudio, goRule } = require('./helpers/studio');

const R = 'because the team asked';
const auditRows = async (pool, subject) => (await pool.query('SELECT * FROM audit WHERE subject = $1 ORDER BY audit_id', [subject])).rows;

test('an author creates a draft and reads it back', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const made = await ann('POST', '/rules', { rule: goRule(), reason: R });
  assert.equal(made.status, 201);
  const got = await ann('GET', '/rules/go-skip-verify');
  assert.equal(got.status, 200);
  assert.equal(got.body.status, 'draft');
  assert.equal(got.body.body.title, 'TLS verification disabled');
  const list = await ann('GET', '/rules?language=go&status=draft&search=tls');
  assert.deepEqual(list.body.rules.map((r) => r.id), ['go-skip-verify']);
  assert.equal((await ann('GET', '/rules?language=python')).body.rules.length, 0);
  assert.equal((await ann('GET', '/rules?language=a&language=b')).status, 400);
}));

test('an author cannot approve (403)', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule(), reason: R });
  assert.equal((await ann('POST', '/rules/go-skip-verify/propose', { reason: R })).status, 200);
  assert.equal((await ann('POST', '/rules/go-skip-verify/approve', { reason: R })).status, 403);
}));

test('an author proposes their own rule and a different admin approves it (200)', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule(), reason: R });
  assert.equal((await ann('POST', '/rules/go-skip-verify/propose', { reason: R })).status, 200);
  const approved = await (await as('root'))('POST', '/rules/go-skip-verify/approve', { reason: 'reviewed' });
  assert.equal(approved.status, 200);
  assert.equal((await repo.get('go-skip-verify')).status, 'active');
}));

test('the same user approving their own proposal is refused (403)', () => withStudio(async ({ as }) => {
  const root = await as('root');
  await root('POST', '/rules', { rule: goRule(), reason: R });
  assert.equal((await root('POST', '/rules/go-skip-verify/propose', { reason: R })).status, 200);
  const res = await root('POST', '/rules/go-skip-verify/approve', { reason: R });
  assert.equal(res.status, 403);
  assert.equal(res.body.error, 'FORBIDDEN');
}));

test('propose with a failing fixture is refused: 422 FIXTURE_FAILED, and the rule stays a draft', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  const bad = goRule();
  bad.example.fixed = bad.example.vulnerable;
  await ann('POST', '/rules', { rule: bad, reason: R });
  const res = await ann('POST', '/rules/go-skip-verify/propose', { reason: R });
  assert.equal(res.status, 422);
  assert.equal(res.body.error, 'FIXTURE_FAILED');
  assert.match(res.body.problems.join(' '), /fired on its own fix/);
  assert.equal((await repo.get('go-skip-verify')).status, 'draft');
}));

test('clone to another language yields a draft with a new id and the new language globs', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule(), reason: R });
  const res = await ann('POST', '/rules/go-skip-verify/clone', { newId: 'py-skip-verify', language: 'python', reason: R });
  assert.equal(res.status, 201);
  const got = (await ann('GET', '/rules/py-skip-verify')).body;
  assert.equal(got.status, 'draft');
  assert.equal(got.language, 'python');
  assert.deepEqual(got.body.files, ['**/*.py']);
  assert.equal(got.body.pattern, goRule().pattern);
  assert.equal(got.body.example.file, 'main.py');
  assert.equal((await ann('POST', '/rules/go-skip-verify/clone', { newId: 'Bad Id', reason: R })).status, 400);
  assert.equal((await ann('POST', '/rules/go-skip-verify/clone', { newId: 'go-skip-verify', reason: R })).status, 409);
}));

test('bulk dryRun writes nothing and lists the changes', () => withStudio(async ({ as, repo, pool }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('POST', '/rules', { rule: goRule('go-b'), reason: R });
  const before = await pool.query('SELECT count(*) FROM audit');
  const res = await ann('POST', '/rules/bulk', { ids: ['go-a', 'go-b'], action: 'severity', value: 'LOW', dryRun: true });
  assert.equal(res.status, 200);
  assert.deepEqual(res.body.wouldChange, [{ id: 'go-a', before: 'HIGH', after: 'LOW' }, { id: 'go-b', before: 'HIGH', after: 'LOW' }]);
  assert.equal((await repo.get('go-a')).version, 1);
  assert.equal((await repo.get('go-a')).severity, 'HIGH');
  assert.equal((await pool.query('SELECT count(*) FROM audit')).rows[0].count, before.rows[0].count);
  const real = await ann('POST', '/rules/bulk', { ids: ['go-a', 'go-b'], action: 'severity', value: 'LOW', reason: R });
  assert.equal(real.status, 200);
  assert.equal((await repo.get('go-a')).severity, 'LOW');
  assert.equal((await repo.get('go-b')).version, 2);
  const tags = await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'tag-add', value: 'tls', reason: R });
  assert.equal(tags.status, 200);
  assert.deepEqual((await repo.get('go-a')).body.tags, ['tls']);
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'severity', value: 'LOW' })).status, 400);
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a', 'nope'], action: 'severity', value: 'LOW', reason: R })).status, 422);
  assert.equal((await repo.get('go-a')).version, 3, 'a refused bulk wrote nothing');
}));

test('bulk deprecate by an author is refused (403); an admin can deprecate and reactivate', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  const root = await as('root');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('POST', '/rules/go-a/propose', { reason: R });
  await root('POST', '/rules/go-a/approve', { reason: R });
  const refused = await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'deprecate', reason: R });
  assert.equal(refused.status, 403);
  assert.equal((await repo.get('go-a')).status, 'active');
  assert.equal((await root('POST', '/rules/bulk', { ids: ['go-a'], action: 'deprecate', reason: R })).status, 200);
  assert.equal((await repo.get('go-a')).status, 'deprecated');
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'reactivate', reason: R })).status, 403);
  assert.equal((await root('POST', '/rules/bulk', { ids: ['go-a'], action: 'reactivate', reason: R })).status, 200);
  assert.equal((await repo.get('go-a')).status, 'active');
}));

test('every successful mutation adds an audit row containing the reason', () => withStudio(async ({ as, pool }) => {
  const ann = await as('ann');
  const root = await as('root');
  const steps = [
    ['create', () => ann('POST', '/rules', { rule: goRule('go-a'), reason: 'r-create' })],
    ['patch', () => ann('PATCH', '/rules/go-a', { patch: { severity: 'LOW' }, reason: 'r-patch' })],
    ['clone', () => ann('POST', '/rules/go-a/clone', { newId: 'go-b', reason: 'r-clone' })],
    ['revert', () => ann('POST', '/rules/go-a/revert', { version: 1, reason: 'r-revert' })],
    ['propose', () => ann('POST', '/rules/go-a/propose', { reason: 'r-propose' })],
    ['approve', () => root('POST', '/rules/go-a/approve', { reason: 'r-approve' })],
    ['deprecate', () => root('POST', '/rules/go-a/deprecate', { reason: 'r-deprecate' })],
  ];
  for (const [name, run] of steps) {
    const res = await run();
    assert.ok(res.status === 200 || res.status === 201, `${name} -> ${res.status} ${res.text}`);
    const rows = await pool.query('SELECT reason, actor FROM audit WHERE reason = $1', [`r-${name}`]);
    assert.ok(rows.rowCount >= 1, `${name} has an audit row with its reason`);
    assert.match(rows.rows[0].actor, /@example\.test$/);
  }
  const b = await auditRows(pool, 'go-b');
  assert.equal(b[0].reason, 'r-clone');
}));

test('a mutation without a reason is a 400 on every state-changing route, and an empty one too', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  const root = await as('root');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  const routes = [
    [ann, 'POST', '/rules', { rule: goRule('go-z') }],
    [ann, 'PATCH', '/rules/go-a', { patch: { severity: 'LOW' } }],
    [ann, 'POST', '/rules/go-a/clone', { newId: 'go-c' }],
    [ann, 'POST', '/rules/go-a/propose', {}],
    [root, 'POST', '/rules/go-a/approve', {}],
    [root, 'POST', '/rules/go-a/deprecate', {}],
    [ann, 'POST', '/rules/go-a/revert', { version: 1 }],
    [ann, 'POST', '/rules/bulk', { ids: ['go-a'], action: 'severity', value: 'LOW' }],
    [ann, 'POST', '/import/commit', { format: 'json', text: '[]' }],
  ];
  for (const [call, method, p, body] of routes) {
    assert.equal((await call(method, p, body)).status, 400, `${method} ${p} without reason`);
    assert.equal((await call(method, p, { ...body, reason: '   ' })).status, 400, `${method} ${p} blank reason`);
  }
  const row = await repo.get('go-a');
  assert.equal(row.version, 1);
  assert.equal(row.status, 'draft');
}));

test('permissions are by code: an author cannot approve, deprecate or read the audit trail; an admin can', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const root = await as('root');
  assert.equal((await ann('POST', '/rules/x/deprecate', { reason: R })).status, 403);
  assert.equal((await ann('GET', '/audit')).status, 403);
  assert.equal((await root('GET', '/audit?limit=5')).status, 200);
  assert.equal((await ann('GET', '/languages/coverage')).status, 200);
  assert.equal((await ann('GET', '/languages/coverage')).body.languages.length, 2);
}));

test('a seeded rule only allows severity, pillar and tags to change (Ruling 10)', () => withStudio(async ({ as, repo }) => {
  await repo.upsertSeeded({ id: 'Seeded_One', language: 'go', severity: 'HIGH', pattern: 'danger', files: ['**/*.go'] }, { origin: 'seed', actor: 'seed' });
  const ann = await as('ann');
  const bad = await ann('PATCH', '/rules/Seeded_One', { patch: { title: 'x' }, reason: R });
  assert.equal(bad.status, 422);
  assert.equal(bad.body.error, 'SEEDED_RULE_LIMITED');
  const ok = await ann('PATCH', '/rules/Seeded_One', { patch: { severity: 'LOW', pillar: 'reliability', tags: ['a'] }, reason: R });
  assert.equal(ok.status, 200);
  const row = await repo.get('Seeded_One');
  assert.equal(row.severity, 'LOW');
  assert.equal(row.pillar, 'reliability');
  assert.equal(row.version, 2);
  assert.equal((await ann('POST', '/rules/Seeded_One/revert', { version: 1, reason: R })).status, 422);
}));

test('history, diff, duplicates, templates and impact', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('PATCH', '/rules/go-a', { patch: { severity: 'LOW', tags: ['x'] }, reason: 'tweak' });
  const hist = await ann('GET', '/rules/go-a/history');
  assert.deepEqual(hist.body.versions.map((v) => v.version), [1, 2]);
  assert.equal(hist.body.versions[1].reason, 'tweak');
  const diff = await ann('GET', '/rules/go-a/diff?from=1&to=2');
  assert.deepEqual(diff.body.fields.map((f) => f.field).sort(), ['severity', 'tags']);
  assert.deepEqual(diff.body.fields.find((f) => f.field === 'severity'), { field: 'severity', before: 'HIGH', after: 'LOW' });
  assert.equal((await ann('GET', '/rules/go-a/diff?from=1&to=9')).status, 404);
  assert.equal((await ann('GET', '/rules/go-a/diff?from=x&to=2')).status, 400);

  const dup = await ann('POST', '/rules/duplicates', { rule: { ...goRule('go-new'), pattern: ' InsecureSkipVerify:\\s*true ' } });
  assert.deepEqual(dup.body.duplicates, ['go-a']);
  const none = await ann('POST', '/rules/duplicates', { rule: { ...goRule('go-new'), pattern: 'other' } });
  assert.deepEqual(none.body.duplicates, []);

  const templates = await ann('GET', '/templates');
  assert.deepEqual(templates.body.templates.map((t) => t.id), ['dangerous-call', 'forbidden-import', 'hardcoded-value', 'missing-config-key', 'regex-on-line']);
  assert.equal(templates.body.templates[0].build, undefined);
  const built = await ann('POST', '/templates/dangerous-call/build', { params: { function: 'strcpy' }, language: 'go' });
  assert.equal(built.body.rule.pattern, '\\bstrcpy\\s*\\(');
  assert.deepEqual(built.body.rule.files, ['**/*.go']);
  assert.equal((await ann('POST', '/templates/regex-on-line/build', { params: { regex: '(' }, language: 'go' })).status, 400);

  assert.deepEqual((await ann('POST', '/rules/impact', { rule: goRule() })).body, { available: false });
  assert.equal((await ann('POST', '/rules/test', { rule: goRule() })).body.ok, true);
  assert.equal((await ann('POST', '/rules/go-a/test', {})).body.ok, true);
}));

test('impact scans the sample corpus without following links and reports counts only', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'corpus-'));
  fs.writeFileSync(path.join(dir, 'a.go'), 'x := tls.Config{InsecureSkipVerify: true}\n');
  fs.writeFileSync(path.join(dir, 'b.go'), 'x := 1\n');
  fs.writeFileSync(path.join(dir, 'c.py'), 'InsecureSkipVerify: true\n');
  fs.symlinkSync('/etc', path.join(dir, 'link'));
  try {
    await withStudio(async ({ as }) => {
      const res = await (await as('ann'))('POST', '/rules/impact', { rule: goRule() });
      assert.deepEqual(res.body, { available: true, filesScanned: 2, filesMatched: 1 });
      const ast = await (await as('ann'))('POST', '/rules/impact', { rule: { ...goRule(), query: '(x) @m', pattern: undefined } });
      assert.equal(ast.status, 400);
    }, { sampleCorpusDir: dir });
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('import routes accept up to 2 MB; other studio routes stay at 16 KB; errors carry no stack', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const big = JSON.stringify([{ ...goRule('go-big'), description: 'd'.repeat(200 * 1024) }]);
  const ok = await ann('POST', '/import/preview', { format: 'json', text: big });
  assert.equal(ok.status, 200);
  const tooBig = await ann('POST', '/import/preview', { format: 'json', text: 'x'.repeat(2.5 * 1024 * 1024) });
  assert.equal(tooBig.status, 413);
  const small = await ann('POST', '/rules', { rule: { ...goRule('go-z'), description: 'd'.repeat(20 * 1024) }, reason: R });
  assert.equal(small.status, 413);
  const err = await ann('GET', '/rules/not-there');
  assert.equal(err.status, 404);
  assert.doesNotMatch(err.text, /\bat .*\.js:\d+/);
}));

test('the studio API needs a session', () => withStudio(async ({ base }) => {
  assert.equal((await fetch(`${base}/v1/studio/rules`)).status, 401);
  assert.equal((await fetch(`${base}/v1/studio/import/preview`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })).status, 401);
}));

async function activeRule(as, id = 'go-a') {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule(id), reason: R });
  await ann('POST', `/rules/${id}/propose`, { reason: R });
  assert.equal((await (await as('root'))('POST', `/rules/${id}/approve`, { reason: R })).status, 200);
  return ann;
}

test('an author PATCHing an active rule sends it back to draft; it needs propose and a different admin again (Ruling 15)', () => withStudio(async ({ as, repo, pool }) => {
  const ann = await activeRule(as);
  const res = await ann('PATCH', '/rules/go-a', { patch: { pattern: 'other\\(' }, reason: 'change logic' });
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'draft');
  const row = await repo.get('go-a');
  assert.equal(row.status, 'draft');
  assert.equal(row.proposed_by, null);
  assert.equal((await ann('POST', '/rules/go-a/approve', { reason: R })).status, 403);
  assert.equal((await (await as('root'))('POST', '/rules/go-a/approve', { reason: R })).status, 400, 'a draft cannot be approved directly');
  const bad = await ann('PATCH', '/rules/go-a', { patch: { example: { file: 'main.go', vulnerable: 'other(', fixed: 'x' } }, reason: 'fix example' });
  assert.equal(bad.status, 200);
  assert.equal((await ann('POST', '/rules/go-a/propose', { reason: R })).status, 200);
  const dee = await as('dee');
  assert.equal((await dee('POST', '/rules/go-a/approve', { reason: 'reviewed again' })).status, 200);
  const a = await pool.query("SELECT actor, reason FROM audit WHERE action = 'rule.update' AND subject = 'go-a' ORDER BY audit_id");
  assert.deepEqual(a.rows[0], { actor: 'ann@example.test', reason: 'change logic' });
}));

test('reverting an active rule sends it back to draft', () => withStudio(async ({ as, repo, pool }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('PATCH', '/rules/go-a', { patch: { description: 'second' }, reason: R });
  await ann('POST', '/rules/go-a/propose', { reason: R });
  await (await as('root'))('POST', '/rules/go-a/approve', { reason: R });
  assert.equal((await repo.get('go-a')).status, 'active');
  const res = await ann('POST', '/rules/go-a/revert', { version: 1, reason: 'undo' });
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'draft');
  assert.equal((await repo.get('go-a')).proposed_by, null);
  const a = await auditRows(pool, 'go-a');
  assert.equal(a[a.length - 1].reason, 'undo');
}));

test('an import-update of an active rule sends it back to draft', () => withStudio(async ({ as, repo }) => {
  const ann = await activeRule(as);
  const res = await ann('POST', '/import/commit', { format: 'json', text: JSON.stringify([{ ...goRule('go-a'), severity: 'LOW' }]), reason: 'import edit' });
  assert.equal(res.status, 200);
  assert.deepEqual(res.body.updated, ['go-a']);
  assert.equal((await repo.get('go-a')).status, 'draft');
}));

test('a severity change on an active rule via PATCH-metadata or bulk stays active', () => withStudio(async ({ as, repo }) => {
  const ann = await activeRule(as);
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'severity', value: 'LOW', reason: R })).status, 200);
  assert.equal((await repo.get('go-a')).status, 'active');
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'tag-add', value: 't', reason: R })).status, 200);
  assert.equal((await repo.get('go-a')).status, 'active');
  await repo.upsertSeeded({ id: 'Seeded_One', language: 'go', severity: 'HIGH', pattern: 'danger', files: ['**/*.go'] }, { origin: 'seed', actor: 'seed' });
  assert.equal((await ann('PATCH', '/rules/Seeded_One', { patch: { severity: 'LOW' }, reason: R })).status, 200);
  assert.equal((await repo.get('Seeded_One')).status, 'active');
}));

test('bulk tag-add where one rule is at 50 tags writes nothing to any rule and names the offender; dryRun shows the same problem', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('POST', '/rules', { rule: { ...goRule('go-b'), tags: Array.from({ length: 50 }, (_, i) => `t${i}`) }, reason: R });
  const dry = await ann('POST', '/rules/bulk', { ids: ['go-a', 'go-b'], action: 'tag-add', value: 'new', dryRun: true });
  assert.equal(dry.status, 200);
  assert.deepEqual(dry.body.wouldChange.map((c) => c.id), ['go-a']);
  assert.equal(dry.body.problems.length, 1);
  assert.equal(dry.body.problems[0].id, 'go-b');
  const real = await ann('POST', '/rules/bulk', { ids: ['go-a', 'go-b'], action: 'tag-add', value: 'new', reason: R });
  assert.equal(real.status, 422);
  assert.equal(real.body.problems[0].id, 'go-b');
  assert.equal((await repo.get('go-a')).version, 1);
  assert.equal((await repo.get('go-b')).version, 1);
}));

test('bulk planning refuses a malformed existing tag list and an overlong tag as a problem row', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: { ...goRule('go-a'), tags: 'oops' }, reason: R });
  const res = await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'tag-add', value: 'x', dryRun: true });
  assert.equal(res.body.problems[0].id, 'go-a');
  assert.equal((await ann('POST', '/rules/bulk', { ids: ['go-a'], action: 'tag-add', value: 'x'.repeat(65), reason: R })).status, 400);
  assert.equal((await repo.get('go-a')).version, 1);
}));
