'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const read = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('every setting the Studio reads is documented in .env.example and the README', () => {
  const settings = ['STUDIO_DATABASE_URL', 'RULES_DATABASE_URL', 'PACK_DIR', 'RELEASE_SIGNING_KEY_FILE', 'RELEASE_SIGNING_KEY_ID', 'ANALYZER_DIR', 'GRAMMAR_DIR', 'SAMPLE_CORPUS_DIR', 'SESSION_HOURS', 'COOKIE_SECURE', 'PORT', 'TRUST_PROXY'];
  for (const s of settings) {
    assert.ok(read('.env.example').includes(s), `${s} missing from .env.example`);
    assert.ok(read('README.md').includes(s), `${s} missing from README.md`);
  }
});

test('the README names the other project, the PACK_DIR sharing rule and the npm scripts', () => {
  const readme = read('README.md');
  for (const needle of ['oasis-rule-server', 'PACK_DIR', 'npm run create-staff', 'npm run migrate', 'npm run smoke', '/healthz', '4050']) {
    assert.ok(readme.includes(needle), `README.md must mention ${needle}`);
  }
});

// Every setting src/config.js reads, through every access form it uses. An access form this parser does not know fails the test loudly.
function settingsReadByConfig() {
  const src = read('src/config.js');
  const names = new Set();
  const forms = [/\benv\.([A-Z][A-Z0-9_]*)\b/g, /\benv\[\s*'([A-Z][A-Z0-9_]*)'\s*\]/g, /\bneed\(\s*'([A-Z][A-Z0-9_]*)'\s*\)/g, /\bwhole\(\s*env\s*,\s*'([A-Z][A-Z0-9_]*)'/g];
  for (const re of forms) for (const m of src.matchAll(re)) names.add(m[1]);
  // Anything that touches env but matched no known form: only the helpers' own parameter use (env[name], whole(env,...), loadStudioConfig(env = ...)) is allowed.
  const known = src.replace(/\benv\.[A-Z][A-Z0-9_]*\b/g, '').replace(/\benv\[\s*'[A-Z0-9_]+'\s*\]/g, '').replace(/\bneed\(\s*'[A-Z0-9_]+'\s*\)/g, '').replace(/\bwhole\(\s*env\s*,\s*'[A-Z0-9_]+'/g, '');
  for (const m of known.matchAll(/\benv\b(?!\s*[,)=])(?!\[name\])(?!\.[a-z])/g)) {
    const around = known.slice(Math.max(0, m.index - 40), m.index + 40).replace(/\s+/g, ' ');
    assert.fail(`src/config.js reads env in a form this test cannot parse: ...${around}...`);
  }
  assert.ok(names.size >= 12, 'parsed fewer settings than expected from src/config.js');
  names.delete('NODE_ENV');
  return [...names].sort();
}

test('the README settings table has one row per setting src/config.js reads, and .env.example names nothing else', () => {
  const readme = read('README.md');
  const configured = settingsReadByConfig();
  const rows = [...readme.matchAll(/^\| `([A-Z][A-Z0-9_]+)` \|/gm)].map((m) => m[1]).sort();
  assert.deepEqual(rows, configured, 'the settings table and src/config.js disagree');
  const example = [...read('.env.example').matchAll(/^#?\s*([A-Z][A-Z0-9_]+)=/gm)].map((m) => m[1]).sort();
  assert.deepEqual(example, configured, '.env.example and src/config.js disagree');
});

test('every npm script the README names exists in package.json, and the ones it must explain are named', () => {
  const readme = read('README.md');
  const scripts = JSON.parse(read('package.json')).scripts;
  const named = new Set([...readme.matchAll(/npm run ([a-z][a-z:-]*)/g)].map((m) => m[1]));
  if (/npm start\b/.test(readme)) named.add('start');
  if (/npm test\b/.test(readme)) named.add('test');
  for (const s of ['start', 'start:local', 'migrate', 'create-staff', 'smoke', 'test']) assert.ok(named.has(s), `README.md must mention ${s}`);
  const OTHER_REPO = ['migrate:central'];      // oasis-rule-server's script, named in the setup steps; not this package's
  for (const s of named) if (!OTHER_REPO.includes(s)) assert.ok(scripts[s], `README.md names npm script "${s}", which package.json does not define`);
  assert.equal(scripts['start:local'], 'node --env-file=.env src/server.js');
  assert.match(readme, /`npm start` does NOT read it/);
});
