'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

test('the rules service library entry exposes its 30 exports and nothing deeper', () => {
  assert.equal(Object.keys(require('oasis-rule-server')).length, 30);
  assert.throws(() => require('oasis-rule-server/src/pg'), { code: 'ERR_PACKAGE_PATH_NOT_EXPORTED' });
});
