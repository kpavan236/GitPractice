'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshIdentityDb } = require('./helpers/db');

const ADMIN = ['audit.read', 'language.read', 'language.write', 'release.publish', 'release.read', 'release.rollback', 'rule.approve',
  'rule.deprecate', 'rule.propose', 'rule.read', 'rule.test', 'rule.write', 'staff.manage'];
const AUTHOR = ['language.read', 'release.read', 'rule.propose', 'rule.read', 'rule.test', 'rule.write'];

test('the identity migrations create the three tables and seed the same permissions the rules service used to', async () => {
  const db = await freshIdentityDb();
  try {
    const tables = (await db.pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY 1")).rows.map((r) => r.table_name);
    assert.deepEqual(tables, ['role_permission', 'schema_migration', 'session', 'staff']);
    const perms = async (role) => (await db.pool.query('SELECT permission FROM role_permission WHERE role=$1 ORDER BY 1', [role])).rows.map((r) => r.permission);
    assert.deepEqual(await perms('admin'), ADMIN);
    assert.deepEqual(await perms('author'), AUTHOR);
  } finally { await db.close(); }
});

test('a session cannot outlive its staff member and roles are limited to author and admin', async () => {
  const db = await freshIdentityDb();
  try {
    await assert.rejects(db.pool.query("INSERT INTO staff (user_id,email,password_hash,role) VALUES (gen_random_uuid(),'x@example.test','h','owner')"), /check/i);
    await assert.rejects(db.pool.query("INSERT INTO session (token_hash,user_id,csrf,expires_at) VALUES ('t',gen_random_uuid(),'c',now())"), /foreign key/i);
  } finally { await db.close(); }
});
