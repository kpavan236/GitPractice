'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Pool } = require('pg');
const { freshIdentityDb, freshBoth } = require('./helpers/db');

const ADMIN_URL = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';
const MIGRATION_ERROR = /syntax|001_broken/i;

function brokenDir() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-broken-mig-'));
  fs.writeFileSync(path.join(dir, '001_broken.up.sql'), 'CREATE TABLE oops (;');
  return dir;
}

// Only ever asks about names this test created, so parallel test files cannot disturb it.
async function exists(name) {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try {
    return (await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [name])).rowCount === 1;
  } finally { await admin.end(); }
}
const uniqueName = () => `studio_test_${crypto.randomBytes(6).toString('hex')}`;

test('a failing identity migration rejects with the migration error and leaves no database behind', async () => {
  const name = uniqueName();
  await assert.rejects(freshIdentityDb({ migrationsDir: brokenDir(), name }), (err) => MIGRATION_ERROR.test(err.message));
  assert.equal(await exists(name), false);
});

test('freshBoth with a failing identity step leaves neither database behind', async () => {
  const name = uniqueName();
  let rulesName;
  await assert.rejects(freshBoth({ identityMigrationsDir: brokenDir(), name, onRulesDb: (n) => { rulesName = n; } }), (err) => MIGRATION_ERROR.test(err.message));
  assert.match(rulesName, /^rules_test_/);
  assert.equal(await exists(rulesName), false);
  assert.equal(await exists(name), false);
});

test('close() is safe to call twice, and after the pool has already ended', async () => {
  const db = await freshIdentityDb();
  assert.equal(await exists(db.name), true);
  await db.close();
  await db.close();
  assert.equal(await exists(db.name), false);
});

test('freshBoth.close() still drops the rules database when closing the identity database fails', async () => {
  const both = await freshBoth();
  const { identity, rules } = both;
  assert.equal(await exists(identity.name), true);
  assert.equal(await exists(rules.name), true);
  await identity.pool.end(); // makes identity.close() fail on its first step
  await assert.rejects(both.close());
  assert.equal(await exists(identity.name), false);
  assert.equal(await exists(rules.name), false);
  await both.close();
});
