'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createRulesRepo, testRule, createReleases, createBlobStore } = require('oasis-rule-server');
const { freshBoth } = require('./db');
const { createStudioApp } = require('../../src/app');
const { createAuth } = require('../../src/auth');
const { hashPassword } = require('../../src/password');
const { createStudioRoutes } = require('../../src/routes');
const { createReleaseRoutes } = require('../../src/release-routes');

const PW = 'correct horse battery staple';

async function addStaff(pool, email, role) {
  await pool.query('INSERT INTO staff (user_id, email, password_hash, role) VALUES ($1,$2,$3,$4)',
    [crypto.randomUUID(), email, await hashPassword(PW), role]);
}

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'studio-rel-'));

// A minimal analyzer tree: enough for the core pack to build, so release tests need no real analyzer checkout.
function fakeAnalyzer() {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, 'src'));
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'fake', version: '1.0.0' }));
  fs.writeFileSync(path.join(dir, 'src', 'index.js'), "'use strict';\n");
  return dir;
}

/** A real app over a fresh rules database AND a fresh identity database: two authors (ann, bob), two admins (root, dee); languages go and python. */
async function withStudio(fn, { sampleCorpusDir = null, releaseTester = { testRule: async () => ({ ok: true, problems: [] }) }, publicDir = null } = {}) {
  const both = await freshBoth();
  const db = both.rules;
  let server;
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go']),('python','Python',ARRAY['.py'])");
    for (const [email, role] of [['ann@example.test', 'author'], ['bob@example.test', 'author'], ['root@example.test', 'admin'], ['dee@example.test', 'admin']]) {
      await addStaff(both.identity.pool, email, role);
    }
    const auth = createAuth({ pool: both.identity.pool, secureCookies: false, log: () => {} });
    const languages = async () => (await db.pool.query('SELECT id FROM language ORDER BY id')).rows.map((r) => r.id);
    const repo = createRulesRepo({ pool: db.pool, languages });
    const routes = createStudioRoutes({ auth, repo, tester: testRule, pool: db.pool, sampleCorpusDir });
    const { privateKey } = crypto.generateKeyPairSync('ed25519');
    const releases = createReleases({
      pool: db.pool, blobs: createBlobStore(tmp()), rules: repo, tester: releaseTester,
      sign: { privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), keyId: 'k1' }, analyzerDir: fakeAnalyzer(), grammarDir: tmp(),
    });
    const releaseRoutes = createReleaseRoutes({ auth, releases });
    const app = createStudioApp({ auth, routes: [routes, releaseRoutes], pool: db.pool, limiter: (_q, _s, n) => n(), publicDir });
    server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    const base = `http://127.0.0.1:${server.address().port}`;
    const sessions = {};
    async function as(name) {
      if (!sessions[name]) {
        const res = await fetch(`${base}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: `${name}@example.test`, password: PW }) });
        const cookie = res.headers.getSetCookie().find((c) => c.startsWith('studio_session=')).split(';')[0];
        sessions[name] = { cookie, csrf: (await res.json()).csrf };
      }
      const s = sessions[name];
      return async (method, p, body, { raw } = {}) => {
        const res = await fetch(`${base}/v1/studio${p}`, {
          method, headers: { cookie: s.cookie, 'x-csrf-token': s.csrf, ...(body !== undefined ? { 'content-type': 'application/json' } : {}) },
          body: body === undefined ? undefined : JSON.stringify(body),
        });
        if (raw) return res;
        const text = await res.text();
        let json = null; try { json = JSON.parse(text); } catch (_) { /* not json */ }
        return { status: res.status, body: json, text, headers: res.headers };
      };
    }
    await fn({ db, pool: db.pool, identity: both.identity, repo, releases, base, as });
  } finally {
    if (server) await new Promise((r) => { server.closeAllConnections(); server.close(r); });
    await both.close();
  }
}

const goRule = (id = 'go-skip-verify') => ({
  id, language: 'go', pillar: 'security', severity: 'HIGH', title: 'TLS verification disabled',
  description: 'InsecureSkipVerify turns off certificate checks.', files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
  example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
});

module.exports = { withStudio, goRule, PW };
