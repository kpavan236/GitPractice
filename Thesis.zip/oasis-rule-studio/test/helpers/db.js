'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { createPool, migrate } = require('oasis-rule-server');
const { freshDb } = require('oasis-rule-server/testing');

// Local development container (docker run -p 5433:5432 postgres:16); the password is the throw-away local one, not a secret.
const ADMIN_URL = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';

/** Runs every step even if an earlier one throws, then rethrows the first error. */
async function runAll(steps) {
  let first;
  for (const step of steps) {
    try { await step(); } catch (err) { if (first === undefined) first = err; }
  }
  if (first !== undefined) throw first;
}

/** A throwaway identity database with the Studio's own migrations applied. Cleans up after itself on every failure path. */
async function freshIdentityDb({ migrationsDir = path.join(__dirname, '..', '..', 'db', 'identity'), name = `studio_test_${crypto.randomBytes(6).toString('hex')}` } = {}) {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  admin.on('error', () => {});
  const drop = () => admin.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
  let pool;
  try {
    await admin.query(`CREATE DATABASE ${name}`);
    const u = new URL(ADMIN_URL); u.pathname = `/${name}`;
    const url = u.toString();
    await migrate(url, migrationsDir);
    pool = createPool(url);
    let closed = false;
    return {
      pool, url, name,
      async close() {
        if (closed) return;
        closed = true;
        await runAll([() => pool.end(), drop, () => admin.end()]);
      },
    };
  } catch (err) {
    // Best effort: the original error is the one the caller needs to see.
    await runAll([() => (pool ? pool.end() : undefined), drop, () => admin.end()]).catch(() => {});
    throw err;
  }
}

/** One throwaway rules database (from the rules service) and one identity database. */
async function freshBoth({ identityMigrationsDir, name, onRulesDb } = {}) {
  const rules = await freshDb();
  // Lets a test learn the rules database's name even when the identity step is about to fail.
  if (onRulesDb) onRulesDb(new URL(rules.url).pathname.slice(1));
  let identity;
  try {
    identity = await freshIdentityDb({ ...(identityMigrationsDir && { migrationsDir: identityMigrationsDir }), ...(name && { name }) });
  } catch (err) {
    await rules.close().catch(() => {});
    throw err;
  }
  let closed = false;
  return {
    rules: { ...rules, name: rules.name || new URL(rules.url).pathname.slice(1) }, identity,
    async close() {
      if (closed) return;
      closed = true;
      await runAll([() => identity.close(), () => rules.close()]);
    },
  };
}

module.exports = { freshIdentityDb, freshBoth };
