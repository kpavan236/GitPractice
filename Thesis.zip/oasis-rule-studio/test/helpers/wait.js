'use strict';
const net = require('node:net');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Polls `fn` until it returns a truthy value (or resolves to one) and returns that value.
 * The timeout is a HANG detector, not a performance threshold: keep it generous. On timeout the error says what was last seen
 * (the last falsy value, or the last error `fn` threw), so a failure is diagnosable from the message alone.
 */
async function waitFor(fn, { timeoutMs = 30000, intervalMs = 25, message = 'condition' } = {}) {
  const deadline = Date.now() + timeoutMs;
  let last = { kind: 'value', value: undefined };
  for (;;) {
    try {
      const value = await fn();
      if (value) return value;
      last = { kind: 'value', value };
    } catch (err) { last = { kind: 'error', value: err }; }
    if (Date.now() >= deadline) break;
    await sleep(intervalMs);
  }
  const seen = last.kind === 'error' ? `threw ${last.value && last.value.stack ? last.value.stack : last.value}` : `last value ${typeof last.value === 'string' ? JSON.stringify(last.value) : String(last.value)}`;
  throw new Error(`timed out after ${timeoutMs} ms waiting for ${message}; ${seen}`);
}

/** Settles like `promise`, but rejects with `message` after `ms` (a hang detector; the timer never keeps the process alive). */
function withTimeout(promise, ms, message) {
  let timer;
  const hang = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`timed out after ${ms} ms waiting for ${message}`)), ms); timer.unref(); });
  return Promise.race([promise, hang]).finally(() => clearTimeout(timer));
}

/** An unused TCP port, as the OS hands it out. The number is only a hint (another process may take it before we bind): use retryOnPortInUse. */
const freePort = () => new Promise((resolve, reject) => {
  const srv = net.createServer();
  srv.once('error', reject);
  srv.listen(0, '127.0.0.1', () => { const { port } = srv.address(); srv.close(() => resolve(port)); });
});

const isPortInUse = (err) => Boolean(err) && (err.code === 'EADDRINUSE' || /EADDRINUSE/.test(String(err.message || err)));

/**
 * Runs `attempt(port)` with a fresh free port, and again with a new port (up to `tries` times) when it fails with EADDRINUSE,
 * i.e. when another process won the race for the number between the probe and the real bind. Any other error is thrown at once.
 */
async function retryOnPortInUse(attempt, { tries = 3 } = {}) {
  let lastErr;
  for (let i = 0; i < tries; i += 1) {
    const port = await freePort();
    try { return await attempt(port); } catch (err) {
      if (!isPortInUse(err)) throw err;
      lastErr = err;
    }
  }
  throw lastErr;
}

/** Resolves true when a TCP connect to 127.0.0.1:port is refused, false when something accepts it (or the attempt is still pending after 2 s). */
function connectRefused(port) {
  return new Promise((resolve) => {
    const s = net.connect({ host: '127.0.0.1', port });
    const done = (refused) => { s.destroy(); resolve(refused); };
    s.setTimeout(2000, () => done(false));
    s.once('connect', () => done(false));
    s.once('error', (err) => done(err.code === 'ECONNREFUSED'));
  });
}

module.exports = { waitFor, withTimeout, sleep, freePort, retryOnPortInUse, isPortInUse, connectRefused };
