'use strict';
// A very small DOM, just enough to render the Studio views and read back what they drew. The browser modules are copied to a temp
// directory (as ES modules) with dialogs.js replaced by a stub that answers every "reason" dialog, so a test can drive a whole action.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const PUBLIC_JS = path.join(__dirname, '..', '..', 'public', 'js');

const DOM_SOURCE = `
export class FNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attrs = {}; this.listeners = {}; this.className = ''; this.value = ''; this.disabled = false; }
  append(...c) { this.children.push(...c); }
  setAttribute(k, v) { this.attrs[k] = v; }
  removeAttribute(k) { delete this.attrs[k]; }
  addEventListener(k, f) { (this.listeners[k] ||= []).push(f); }
  replaceChildren(...c) { this.children = c; }
  remove() {}
  scrollIntoView() {}
  focus() {}
  set textContent(v) { this.children = [String(v)]; }
  get textContent() { return this.children.map((c) => (typeof c === 'string' ? c : c.textContent)).join(''); }
}
globalThis.Node = FNode;
globalThis.document = { createElement: (t) => new FNode(t), createTextNode: (s) => String(s), getElementById: () => new FNode('div'), addEventListener() {}, removeEventListener() {}, body: new FNode('body') };
globalThis.location = { hash: '' };
export const walk = (n, out = []) => { if (typeof n === 'string') return out; out.push(n); for (const c of n.children) walk(c, out); return out; };
export const findAll = (root, pred) => walk(root).filter(pred);
export const find = (root, pred) => findAll(root, pred)[0];
export const fire = async (node, type, event = {}) => { for (const f of node.listeners[type] || []) await f({ preventDefault() {}, target: node, ...event }); };
`;

const STUB_DIALOGS = `
export const toast = () => {};
export const askAction = async () => ({ reason: 'test reason', values: { newId: 'copy', channel: 'stable' } });
`;

/** Copies public/js to a temp dir, installs the fake DOM and the dialog stub, and returns { dir, load(file), dom }. */
async function setup({ fetchImpl } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-ui-'));
  fs.cpSync(PUBLIC_JS, path.join(dir, 'js'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'package.json'), '{"type":"module"}');
  fs.writeFileSync(path.join(dir, 'js', 'dialogs.js'), STUB_DIALOGS);
  fs.writeFileSync(path.join(dir, 'js', 'fake-dom.js'), DOM_SOURCE);
  const dom = await import(pathToFileURL(path.join(dir, 'js', 'fake-dom.js')));
  const realFetch = globalThis.fetch;
  globalThis.fetch = fetchImpl;
  return {
    dir, dom,
    load: (file) => import(pathToFileURL(path.join(dir, 'js', file))),
    done() { globalThis.fetch = realFetch; fs.rmSync(dir, { recursive: true, force: true }); },
  };
}

/** A fake fetch: routes is { 'METHOD /path': (body) => [status, json, headers?] } and every call is recorded in `calls`. */
function fakeFetch(routes) {
  const calls = [];
  const impl = async (url, init = {}) => {
    const route = `${init.method || 'GET'} ${String(url).replace('/v1/studio', '').split('?')[0]}`;
    calls.push(route);
    const handler = routes[route];
    if (!handler) return { ok: false, status: 404, headers: { get: () => null }, json: async () => ({ error: 'NOT_FOUND' }), text: async () => '' };
    const [status, json, headers = {}] = handler(init.body ? JSON.parse(init.body) : undefined);
    return { ok: status < 400, status, headers: { get: (k) => headers[k.toLowerCase()] || null }, json: async () => { if (json === undefined) throw new Error('not json'); return json; }, text: async () => '' };
  };
  return { impl, calls };
}

module.exports = { setup, fakeFetch };
