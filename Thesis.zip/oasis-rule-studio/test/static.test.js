'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { withStudio } = require('./helpers/studio');
const { CSP } = require('../src/security-headers');

const PUBLIC = path.join(__dirname, '..', 'public');
const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));
const modules = () => walk(path.join(PUBLIC, 'js')).filter((f) => f.endsWith('.js'));
const strip = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').replace(/\s\/\/ .*$/gm, '');

test('the Studio page is served at / with the exact strict content policy, and its assets are served from public/ only', async () => {
  await withStudio(async ({ base }) => {
    const r = await fetch(`${base}/`);
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-type'), /text\/html/);
    const csp = r.headers.get('content-security-policy');
    assert.equal(csp, "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    assert.equal(csp, CSP);
    assert.ok(!/unsafe-inline|unsafe-eval|data:/.test(csp));
    assert.equal(r.headers.get('x-frame-options'), 'DENY');
    assert.equal(r.headers.get('cache-control'), 'no-cache');
    assert.match(await r.text(), /<div id="app">/);
    for (const f of ['/js/main.js', '/js/api.js', '/js/dom.js', '/js/views/rules.js', '/css/studio.css']) assert.equal((await fetch(`${base}${f}`)).status, 200, f);
    assert.match((await fetch(`${base}/js/main.js`)).headers.get('content-type'), /javascript/);
    for (const bad of ['/package.json', '/src/central-app.js', '/.env', '/%2e%2e/package.json']) {
      const x = await fetch(`${base}${bad}`);
      assert.ok([400, 403, 404].includes(x.status), `${bad} -> ${x.status}`);
    }
    const api = await fetch(`${base}/v1/studio/rules`);
    assert.equal(api.status, 401, 'the API still answers as before, and the static handler does not shadow it');
    assert.equal(api.headers.get('cache-control'), 'no-store');
    assert.equal((await fetch(`${base}/v1/nope`)).status, 404);
  }, { publicDir: PUBLIC });
});

test('index.html has no inline script, style or handler, and loads /js/main.js as a module', () => {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script\b[^>]*>/gi)].map((m) => m[0]);
  assert.equal(scripts.length, 1);
  assert.match(scripts[0], /type="module"/);
  assert.match(scripts[0], /src="\/js\/main\.js"/);
  assert.ok(!/<script\b[^>]*>[^<]+<\/script>/i.test(html), 'no script body');
  assert.ok(!/\sstyle=/i.test(html) && !/<style\b/i.test(html), 'no inline style');
  assert.ok(!/\son[a-z]+=/i.test(html), 'no inline event handler');
  assert.ok(!/https?:\/\//.test(html), 'nothing from another site');
  const css = fs.readFileSync(path.join(PUBLIC, 'css', 'studio.css'), 'utf8');
  assert.ok(!/@import|url\(/i.test(css), 'the stylesheet loads nothing');
});

// The banned calls are looked for in the RAW source. (Stripping comments with a regex is unsafe here: a glob such as '**/*' opens a "comment" that hides code up to the next star-slash.)
const BANNED = [/\binnerHTML\b/, /\bouterHTML\b/, /\binsertAdjacentHTML\b/, /\bdocument\.write\b/, /\beval\s*\(/, /\bnew Function\b/, /\bsetTimeout\s*\(\s*['"`]/, /\bsrcdoc\b/, /javascript:/i, /\bcreateContextualFragment\b/];
const bannedIn = (src) => BANNED.filter((re) => re.test(src)).map(String);

test('the scan for banned calls sees code that follows a glob string such as **/*', () => {
  assert.deepEqual(bannedIn("const files = ['**/*'];\nel.innerHTML = x;\nconst more = ['**/*.go'];"), [String(BANNED[0])]);
  assert.deepEqual(bannedIn("const g = '**/*'; eval(code); // ok */"), [String(BANNED[4])]);
  assert.deepEqual(bannedIn("const g = '**/*'; document.write(x); new Function('a');"), [String(BANNED[3]), String(BANNED[5])]);
  assert.deepEqual(bannedIn('const fine = 1;'), []);
  assert.ok(!bannedIn(strip("const f = ['**/*'];\nel.innerHTML = x;\nconst g = ['**/*.go'];")).length, 'documents why the old comment-stripping scan was blind');
});

test('no browser module can turn text into markup or code, store the session, or call another site', () => {
  const files = modules();
  assert.ok(files.length >= 14, `found ${files.length} modules`);
  for (const file of files) {
    const src = fs.readFileSync(file, 'utf8');
    const rel = path.relative(PUBLIC, file);
    assert.deepEqual(bannedIn(src), [], `${rel} uses a banned call`);
    assert.ok(!/document\.cookie|sessionStorage/.test(src), `${rel} touches the session`);
    assert.ok(!/https?:\/\//.test(src), `${rel} names another site`);
    if (!/(^|\/)drafts\.js$/.test(rel)) assert.ok(!/localStorage/.test(src), `${rel} uses localStorage`);
  }
});

test('every browser module is valid JavaScript, and every named import resolves to an export', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-modules-'));
  try {
    for (const file of modules()) {
      const copy = path.join(tmp, `${path.basename(file)}.mjs`);
      fs.copyFileSync(file, copy);
      const r = spawnSync(process.execPath, ['--check', copy], { encoding: 'utf8' });
      assert.equal(r.status, 0, `${path.relative(PUBLIC, file)}: ${r.stderr.split('\n').slice(0, 4).join(' ')}`);
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  const exportsOf = (file) => new Set([...fs.readFileSync(file, 'utf8').matchAll(/export\s+(?:async\s+)?(?:function|const|class|let)\s+([A-Za-z0-9_$]+)/g)].map((m) => m[1]));
  for (const file of modules()) {
    for (const m of fs.readFileSync(file, 'utf8').matchAll(/import\s*\{([^}]*)\}\s*from\s*'([^']+)'/g)) {
      const target = path.resolve(path.dirname(file), m[2]);
      assert.ok(fs.existsSync(target), `${path.relative(PUBLIC, file)} imports ${m[2]}, which does not exist`);
      const have = exportsOf(target);
      for (const name of m[1].split(',').map((s) => s.trim().split(/\s+as\s+/)[0]).filter(Boolean)) assert.ok(have.has(name), `${path.relative(PUBLIC, file)}: ${m[2]} does not export ${name}`);
    }
  }
});

test('the helper that builds elements refuses script-carrying links and non-function handlers, and puts text in as text', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-dom-'));
  try {
    const copy = path.join(tmp, 'dom.mjs');
    fs.copyFileSync(path.join(PUBLIC, 'js', 'dom.js'), copy);
    const probe = path.join(tmp, 'probe.mjs');
    fs.writeFileSync(probe, `
      class Node { constructor(t) { this.tag = t; this.children = []; this.attrs = {}; this.listeners = {}; }
        append(...c) { this.children.push(...c); } setAttribute(k, v) { this.attrs[k] = v; } addEventListener(k, f) { this.listeners[k] = f; }
        replaceChildren() { this.children = []; } set textContent(v) { this.children = [String(v)]; } }
      globalThis.Node = Node;
      globalThis.document = { createElement: (t) => new Node(t), createTextNode: (s) => String(s) };
      const { h } = await import(${JSON.stringify(copy)});
      const out = {};
      out.text = h('p', {}, '<img src=x onerror=alert(1)>').children[0];
      for (const [k, v] of [['href', 'javascript:alert(1)'], ['src', 'data:text/html,x'], ['onclick', 'alert(1)']]) { try { h('a', { [k]: v }); out[k] = 'accepted'; } catch (e) { out[k] = 'refused'; } }
      out.ok = typeof h('button', { onclick: () => {} }).listeners.click;
      out.skipped = h('p', {}, null, undefined, false, 'a').children.length;
      console.log(JSON.stringify(out));
    `);
    const r = spawnSync(process.execPath, [probe], { encoding: 'utf8' });
    assert.equal(r.status, 0, r.stderr);
    assert.deepEqual(JSON.parse(r.stdout), { text: '<img src=x onerror=alert(1)>', href: 'refused', src: 'refused', onclick: 'refused', ok: 'function', skipped: 1 });
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('loading the Studio files does not use up the request limit meant for the API (a page load is about 20 files)', async () => {
  const { createStudioApp } = require('../src/app');
  const auth = { requireSession: (_q, _s, n) => n(), requirePermission: () => (_q, _s, n) => n(), permissionsOf: async () => [], login: async () => ({}), logout: async () => {}, sessionCookie: () => '' };
  const app = createStudioApp({ auth, publicDir: PUBLIC });      // the default limiter: 60 requests a minute
  const server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  try {
    const base = `http://127.0.0.1:${server.address().port}`;
    for (let i = 0; i < 90; i += 1) assert.equal((await fetch(`${base}/js/main.js`)).status, 200, `request ${i + 1}`);
    const api = await fetch(`${base}/v1/nope`);      // a path the limiter covers (the Studio's /healthz sits before it)
    assert.equal(api.status, 404, 'the API limit is untouched by the static files');
    assert.ok(api.headers.get('content-security-policy'));
  } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
});
