'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { setup, fakeFetch } = require('./helpers/fake-dom');
const { waitFor } = require('./helpers/wait');

const ME = { email: 'root@example.test', role: 'admin', csrf: 'c', permissions: ['rule.read', 'rule.write', 'rule.test', 'rule.propose', 'rule.approve', 'rule.deprecate', 'language.read', 'release.read', 'release.publish', 'release.rollback'] };
const ctx = () => ({ me: ME, isCurrent: () => true, onLeave: () => {} });
const body = (extra = {}) => ({ id: 'go-demo', language: 'go', pillar: 'security', severity: 'HIGH', title: 'Old title', description: 'd', files: ['**/*.go'], pattern: 'foo\\(', example: { file: 'x.go', vulnerable: 'foo(1)', fixed: 'bar(1)' }, ...extra });
const detail = (o = {}) => ({ id: 'go-demo', language: 'go', pillar: 'security', severity: 'HIGH', status: 'active', version: 1, origin: 'user', proposedBy: null, body: body(), ...o });

async function editorWith(routes, run) {
  const { impl, calls } = fakeFetch({
    'GET /languages/coverage': () => [200, { languages: [{ language: 'go' }] }],
    'GET /rules/go-demo/history': () => [200, { versions: [{ version: 1, changedBy: 'a', changedAt: null, reason: 'r' }] }],
    'POST /rules/test': () => [200, { ok: true, problems: [], detect: { matched: true, lines: [1] }, clean: { matched: false } }],
    'POST /rules/impact': () => [200, { available: false }],
    'POST /rules/duplicates': () => [200, { duplicates: [] }],
    ...routes,
  });
  const t = await setup({ fetchImpl: impl });
  try { await run(t, calls); } finally { t.done(); }
}

/** Waits (bounded, generously) until the text the view should have drawn is on the page; replaces fixed sleeps after UI actions. */
const shown = (root, re) => waitFor(() => {
  if (!re.test(root.textContent)) throw new Error(`page text is ${JSON.stringify(root.textContent.slice(0, 300))}`);
  return true;
}, { timeoutMs: 30000, intervalMs: 5, message: `the page to show ${re}` });

async function saveWith(t, rootNode, id, edit) {
  const { find, fire } = t.dom;
  const input = edit(rootNode);
  await fire(input, 'input');
  const save = find(rootNode, (n) => n.tag === 'button' && /^Save/.test(n.textContent));
  await fire(save, 'click');
}

test('after saving an edit to an active rule, the saved version and the new status are on the page (Ruling 15)', async () => {
  await editorWith({
    'GET /rules/go-demo': () => [200, detail()],
    'PATCH /rules/go-demo': () => [200, detail({ status: 'draft', version: 2 })],
  }, async (t) => {
    const api = await t.load('api.js'); api.setMe(ME);
    const { renderRuleEditor } = await t.load('views/rule-editor.js');
    const root = new t.dom.FNode('div');
    await renderRuleEditor(root, ctx(), 'go-demo');
    // after the save the stub re-fetch returns the draft
    await saveWith(t, root, 'go-demo', (r) => { const i = t.dom.find(r, (n) => n.tag === 'input' && n.value === 'Old title'); i.value = 'New title'; return i; });
    await shown(root, /Saved as version 2\. Status is now draft\./);
    assert.match(root.textContent, /Saved as version 2\. Status is now draft\./);
    assert.match(root.textContent, /out of the next release until it is proposed and approved again/);
  });
});

test('a seeded rule saved with new severity says so too', async () => {
  await editorWith({
    'GET /rules/go-demo': () => [200, detail({ origin: 'seed' })],
    'PATCH /rules/go-demo': () => [200, detail({ origin: 'seed', version: 2, severity: 'LOW' })],
  }, async (t) => {
    const api = await t.load('api.js'); api.setMe(ME);
    const { renderRuleEditor } = await t.load('views/rule-editor.js');
    const root = new t.dom.FNode('div');
    await renderRuleEditor(root, ctx(), 'go-demo');
    await saveWith(t, root, 'go-demo', (r) => { const s = t.dom.findAll(r, (n) => n.tag === 'select')[2]; s.value = 'LOW'; return s; });
    await shown(root, /Saved as version 2\. Status is now active\./);
    assert.match(root.textContent, /Saved as version 2\. Status is now active\./);
  });
});

test('after building a candidate, publishing and rolling back, the confirmation is on the page', async () => {
  const list = { releases: [{ releaseNo: 1, state: 'beta', createdAt: null, createdBy: 'a', ruleCount: 2, packCount: 1 }], channels: { beta: 1, stable: null } };
  await editorWith({
    'GET /releases': () => [200, list],
    'POST /releases/candidate': () => [201, { releaseNo: 2, summary: { packs: ['core'], rules: 3, skippedNoFixture: 2 } }],
    'POST /releases/1/publish': () => [200, { releaseNo: 1, channel: 'stable', state: 'stable' }],
    'POST /releases/rollback': () => [200, {}],
  }, async (t) => {
    const api = await t.load('api.js'); api.setMe(ME);
    const { renderReleases } = await t.load('views/releases.js');
    const click = async (root, label) => t.dom.fire(t.dom.find(root, (n) => n.tag === 'button' && n.textContent === label), 'click');
    let root = new t.dom.FNode('div');
    await renderReleases(root, ctx());
    await click(root, 'Build candidate'); await shown(root, /Candidate 2 built with 3 rules in 1 pack\./);
    assert.match(root.textContent, /Candidate 2 built with 3 rules in 1 pack\./);
    assert.match(root.textContent, /2 rules had no examples to test and were included without a test\./);
    root = new t.dom.FNode('div'); await renderReleases(root, ctx());
    await click(root, 'Promote to stable'); await shown(root, /Release 1 is now on stable\./);
    assert.match(root.textContent, /Release 1 is now on stable\./);
    root = new t.dom.FNode('div'); await renderReleases(root, ctx());
    await click(root, 'Roll back to this'); await shown(root, /The stable channel is back on release 1\./);
    assert.match(root.textContent, /The stable channel is back on release 1\./);
  });
});

test('the live test asks for duplicates and impact only when it passes and what they look at changed', async () => {
  let pass = true;
  await editorWith({
    'POST /rules/test': () => [200, { ok: pass, problems: pass ? [] : ['missed its vulnerable example'], detect: { matched: pass, lines: [1] }, clean: { matched: false } }],
    'POST /rules/impact': () => [200, { available: true, filesScanned: 10, filesMatched: 2 }],
  }, async (t, calls) => {
    const { liveTest } = await t.load('tester-panel.js');
    let rule = body();
    const live = liveTest({ getRule: () => rule });
    const count = (route) => calls.filter((c) => c === route).length;
    await live.runNow();
    assert.equal(count('POST /rules/test'), 1); assert.equal(count('POST /rules/duplicates'), 1); assert.equal(count('POST /rules/impact'), 1);
    assert.match(live.node.textContent, /Changes results in 2 of 10 files/);
    rule = body({ title: 'Other title', example: { file: 'x.go', vulnerable: 'foo(2)', fixed: 'bar(2)' } });      // examples and title only
    await live.runNow();
    assert.equal(count('POST /rules/test'), 2); assert.equal(count('POST /rules/duplicates'), 1); assert.equal(count('POST /rules/impact'), 1);
    assert.match(live.node.textContent, /Changes results in 2 of 10 files/, 'the cached answer is still shown');
    rule = body({ pattern: 'foo\\(\\d' });
    await live.runNow();
    assert.equal(count('POST /rules/duplicates'), 2); assert.equal(count('POST /rules/impact'), 2);
    pass = false; rule = body({ pattern: 'bar\\(' });
    await live.runNow();
    assert.equal(count('POST /rules/duplicates'), 2, 'a failing test costs one call'); assert.equal(count('POST /rules/impact'), 2);
    live.stop();
  });
});

test('a 429 says how long to wait, and a 503 or a non-JSON 5xx says the service is not answering', async () => {
  const seen = {};
  const { impl } = fakeFetch({
    'GET /a': () => [429, { error: 'TOO_MANY_REQUESTS' }, { 'retry-after': '17' }],
    'GET /b': () => [429, { error: 'TOO_MANY_REQUESTS' }],
    'GET /c': () => [503, undefined],
    'GET /d': () => [502, undefined],
    'GET /e': () => [500, { error: 'INTERNAL' }],
  });
  const t = await setup({ fetchImpl: impl });
  try {
    const { api } = await t.load('api.js');
    for (const k of 'abcde') seen[k] = await api('GET', `/${k}`).then(() => 'ok', (e) => e.message);
  } finally { t.done(); }
  assert.equal(seen.a, 'You are going faster than the server allows. Wait 17 seconds and try again.');
  assert.equal(seen.b, 'You are going faster than the server allows. Wait a minute and try again.');
  const down = 'The rules service is not answering. Wait a moment and try again; if it keeps happening, tell an admin.';
  assert.equal(seen.c, down); assert.equal(seen.d, down);
  assert.match(seen.e, /server hit an error/);
});
