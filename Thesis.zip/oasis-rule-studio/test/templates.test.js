'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { TEMPLATES, byId, escape } = require('../src/templates');
const { validateRule } = require('oasis-rule-server');

const go = { id: 'go', extensions: ['.go'] };

test('dangerous-call with strcpy matches strcpy(a, b) and not strncpy(a, b)', () => {
  const { pattern } = byId('dangerous-call').build({ function: 'strcpy' }, go);
  const re = new RegExp(pattern);
  assert.equal(re.test('strcpy(a, b)'), true);
  assert.equal(re.test('strncpy(a, b)'), false);
});

test('a parameter value such as a.b( is escaped, so it cannot raise a regex compile error', () => {
  assert.equal(escape('a.b('), 'a\\.b\\(');
  for (const id of ['dangerous-call', 'forbidden-import', 'hardcoded-value', 'missing-config-key']) {
    const param = byId(id).params[0].name;
    for (const nasty of ['a.b(', '(', '[', '*', '\\', '|||', 'a{1', '$^']) {
      const { pattern } = byId(id).build({ [param]: nasty }, go);
      assert.doesNotThrow(() => new RegExp(pattern), `${id} with ${nasty}`);
    }
  }
  assert.equal(new RegExp(byId('dangerous-call').build({ function: 'a.b(' }, go).pattern).test('axb ('), false);
});

test('the five templates ship with the exact patterns from the brief', () => {
  assert.deepEqual(TEMPLATES.map((t) => t.id), ['dangerous-call', 'forbidden-import', 'hardcoded-value', 'missing-config-key', 'regex-on-line']);
  assert.equal(byId('forbidden-import').build({ module: 'os' }, go).pattern, '^\\s*(import|using|require|include)\\b.*\\bos\\b');
  assert.equal(byId('hardcoded-value').build({ field: 'password' }, go).pattern, '\\bpassword\\b\\s*[:=]\\s*["\'][^"\']+["\']');
  assert.equal(new RegExp(byId('missing-config-key').build({ key: 'timeout' }, go).pattern).test('  timeout: 30'), true);
  assert.match(byId('missing-config-key').description, /negate/);
  for (const t of TEMPLATES) { assert.equal(t.engine, 'pattern'); assert.ok(t.title); assert.ok(t.params.every((p) => p.name && p.label && p.example)); }
});

test('every template built rule passes validateRule once it has a title, pillar, severity and example', () => {
  for (const t of TEMPLATES) {
    const params = Object.fromEntries(t.params.map((p) => [p.name, p.example]));
    const partial = t.build(params, go);
    const rule = {
      id: `go-${t.id}`, language: 'go', pillar: 'security', severity: 'HIGH', title: t.title, description: 'd',
      example: { file: 'a.go', vulnerable: 'v', fixed: 'f' }, ...partial,
    };
    assert.equal(validateRule(rule, { languages: ['go'] }), null, t.id);
  }
});

test('parameters are checked: missing, non-string, too long, and a bad regex-on-line', () => {
  assert.throws(() => byId('dangerous-call').build({}, go), { code: 'INVALID' });
  assert.throws(() => byId('dangerous-call').build({ function: 5 }, go), { code: 'INVALID' });
  assert.throws(() => byId('dangerous-call').build({ function: 'a'.repeat(300) }, go), { code: 'INVALID' });
  assert.throws(() => byId('regex-on-line').build({ regex: '(' }, go), { code: 'INVALID' });
  assert.throws(() => byId('regex-on-line').build({ regex: 'a*' }, go), { code: 'INVALID' });
  assert.equal(byId('regex-on-line').build({ regex: 'TODO' }, go).pattern, 'TODO');
  assert.equal(byId('nope'), undefined);
});
