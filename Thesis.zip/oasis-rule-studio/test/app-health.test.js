'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createStudioApp } = require('../src/app');

const auth = { requireSession: (_q, r) => r.status(401).json({ error: 'UNAUTHENTICATED' }), requirePermission: () => (_q, _s, n) => n(), login: async () => {}, logout: async () => {} };

async function withApp(options, fn) {
  const app = createStudioApp({ auth, ...options });
  const server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  try { await fn(`http://127.0.0.1:${server.address().port}`); } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
}

test('/healthz answers 200 {status:ok} with the CSP, and the strict limiter does not count it: 100 calls in a row stay 200', async () => {
  await withApp({}, async (base) => {
    const first = await fetch(`${base}/healthz`);
    assert.equal(first.status, 200);
    assert.deepEqual(await first.json(), { status: 'ok' });
    assert.ok(first.headers.get('content-security-policy'));
    for (let i = 0; i < 99; i += 1) assert.equal((await fetch(`${base}/healthz`)).status, 200);
    assert.equal((await fetch(`${base}/nope`)).status, 404, 'the strict budget is untouched');
  });
});

test('/healthz is liveness only: it answers 200 even when the database is down and never touches the pool', async () => {
  let queries = 0;
  const pool = { query: async () => { queries += 1; throw new Error('down'); } };
  await withApp({ pool }, async (base) => {
    const res = await fetch(`${base}/healthz`);
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { status: 'ok' });
  });
  assert.equal(queries, 0);
});

test('/readyz answers 200 {status:ok} when the database check passes', async () => {
  const pool = { query: async () => ({ rows: [{ '?column?': 1 }] }) };
  await withApp({ pool }, async (base) => {
    const res = await fetch(`${base}/readyz`);
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { status: 'ok' });
    assert.ok(res.headers.get('content-security-policy'));
  });
});

test('/readyz reports 500 INTERNAL when the database check fails', async () => {
  const pool = { query: async () => { throw Object.assign(new Error('down'), { code: 'ECONNREFUSED' }); } };
  const log = console.error; console.error = () => {};
  try { await withApp({ pool }, async (base) => { const res = await fetch(`${base}/readyz`); assert.equal(res.status, 500); assert.deepEqual(await res.json(), { error: 'INTERNAL' }); }); } finally { console.error = log; }
});

test('/readyz is behind the strict limiter: the 61st call is the first 429', async () => {
  const pool = { query: async () => ({ rows: [] }) };
  await withApp({ pool }, async (base) => {
    const s = [];
    for (let i = 0; i < 61; i += 1) s.push((await fetch(`${base}/readyz`)).status);
    assert.ok(s.slice(0, 60).every((c) => c === 200));
    assert.equal(s[60], 429);
  });
});
