'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { withStudio, goRule } = require('./helpers/studio');

test('the rules database has no staff tables and the Studio still works: sessions and permissions come from the identity database', () => withStudio(async ({ pool, identity, as }) => {
  const rulesTables = (await pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")).rows.map((r) => r.table_name);
  for (const gone of ['staff', 'session', 'role_permission']) assert.equal(rulesTables.includes(gone), false, `rules database must not contain ${gone}`);
  const ann = await as('ann');
  assert.equal((await ann('GET', '/auth/me')).status, 200);
  assert.equal((await ann('POST', '/rules', { rule: goRule('two-db-rule'), reason: 'test' })).status, 201);
  assert.equal((await identity.pool.query('SELECT count(*)::int AS n FROM session')).rows[0].n, 1);
  const audit = (await pool.query("SELECT actor FROM audit WHERE subject = 'two-db-rule'")).rows;
  assert.ok(audit.length >= 1 && audit.every((r) => r.actor === 'ann@example.test'));
}));
