'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createRulesRepo, createReleases, createBlobStore, decodePack, testRule } = require('oasis-rule-server');
const { freshDb } = require('oasis-rule-server/testing');
const { buildRelease } = require('../scripts/build-release');
const { goRule } = require('./helpers/studio');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'studio-build-release-'));

function fakeAnalyzer() {
  const dir = tmp();
  fs.mkdirSync(path.join(dir, 'src'));
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'fake', version: '1.0.0' }));
  fs.writeFileSync(path.join(dir, 'src', 'index.js'), "'use strict';\n");
  return dir;
}

async function withSetup(fn) {
  const db = await freshDb();
  const dirs = [];
  const dir = () => { const d = tmp(); dirs.push(d); return d; };
  try {
    await db.pool.query("INSERT INTO language (id,name,extensions) VALUES ('go','Go',ARRAY['.go'])");
    const repo = createRulesRepo({ pool: db.pool, languages: async () => ['go'] });
    const rule = goRule();
    const ctx = { actor: 'ann@example.test', reason: 'test' };
    await repo.create(rule, ctx);
    await repo.setStatus(rule.id, 'proposed', ctx);
    await repo.setStatus(rule.id, 'active', { actor: 'root@example.test', reason: 'test' });
    const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
    const keyFile = path.join(dir(), 'sign.pem');
    fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    const packDir = dir();
    const analyzer = fakeAnalyzer(); dirs.push(analyzer);
    const env = { RULES_DATABASE_URL: db.url, PACK_DIR: packDir, RELEASE_SIGNING_KEY_FILE: keyFile, RELEASE_SIGNING_KEY_ID: 'dev-1', ANALYZER_DIR: analyzer, GRAMMAR_DIR: dir() };
    await fn({ db, env, packDir, publicKeyPem: publicKey.export({ type: 'spki', format: 'pem' }) });
  } finally {
    await db.close();
    for (const d of dirs) fs.rmSync(d, { recursive: true, force: true });
  }
}

test('build-release builds, signs and publishes to beta with the Studio\'s own release code; the public service\'s latest verifies', () => withSetup(async ({ db, env, packDir, publicKeyPem }) => {
  const out = await buildRelease({ env });
  assert.equal(out.channel, 'beta');
  assert.equal(out.keyId, 'dev-1');
  assert.deepEqual(out.packs.map((p) => p.packId), ['core', 'lang-go']);
  const releases = createReleases({ pool: db.pool, blobs: createBlobStore(packDir) });
  const latest = await releases.latest('beta');
  assert.equal(latest.manifest.release, out.releaseNo);
  assert.equal(latest.manifest.channel, 'beta');
  const { verifyManifest } = require('oasis-rule-server');
  assert.equal(verifyManifest({ manifest: latest.manifest, keyId: latest.keyId, signature: latest.signature }, { 'dev-1': publicKeyPem }), latest.manifest);
  // the blobs really are in PACK_DIR, and the core pack carries the analyzer sources
  const core = decodePack(await createBlobStore(packDir).get(latest.manifest.packs.find((p) => p.packId === 'core').sha256));
  assert.ok(core.files.some((f) => f.path === 'src/index.js'));
  await assert.rejects(releases.latest('stable'), { code: 'NOT_FOUND' });
}));

test('build-release --channel stable goes through beta first and leaves both channels on the release', () => withSetup(async ({ db, env, packDir }) => {
  const out = await buildRelease({ env, channel: 'stable' });
  const releases = createReleases({ pool: db.pool, blobs: createBlobStore(packDir) });
  assert.equal((await releases.latest('stable')).manifest.release, out.releaseNo);
  assert.equal((await releases.latest('beta')).manifest.release, out.releaseNo);
}));

test('build-release refuses an unknown channel and a missing setting by name, and never prints the key', () => withSetup(async ({ env }) => {
  await assert.rejects(buildRelease({ env, channel: 'gamma' }), /channel must be one of beta, stable/);
  const { RELEASE_SIGNING_KEY_FILE, ...rest } = env;
  await assert.rejects(buildRelease({ env: rest }), /RELEASE_SIGNING_KEY_FILE is required/);
}));
