'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const { createStudioApp } = require('../src/app');
const { rateLimit } = require('oasis-rule-server');

// Stub sign-in: the user is named by the x-user header, so two staff users can be told apart without a database.
function stubAuth() {
  const bad = Object.assign(new Error('INVALID_CREDENTIALS'), { code: 'INVALID_CREDENTIALS' });
  return {
    requireSession: (req, res, next) => { const u = req.get('x-user'); if (!u) return res.status(401).json({ error: 'UNAUTHENTICATED' }); req.staff = { userId: u, email: `${u}@example.test`, role: 'author' }; next(); },
    requirePermission: () => (_q, _s, n) => n(), permissionsOf: async () => [], login: async () => { throw bad; }, logout: async () => {}, sessionCookie: () => '',
  };
}

async function withApp(options, fn) {
  const routes = express.Router();
  routes.get('/ping', (_req, res) => res.json({ ok: true }));
  const app = createStudioApp({ auth: stubAuth(), routes, ...options });
  const server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  try { await fn(`http://127.0.0.1:${server.address().port}`); } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
}
const statuses = async (n, make) => { const out = []; for (let i = 0; i < n; i += 1) out.push((await make()).status); return out; };

test('a signed-in burst of 100 Studio calls is not limited, while 61 unauthenticated API calls from one address are', async () => {
  await withApp({}, async (base) => {
    const studio = await statuses(100, () => fetch(`${base}/v1/studio/ping`, { headers: { 'x-user': 'ann' } }));
    assert.ok(studio.every((s) => s === 200), `studio statuses: ${[...new Set(studio)]}`);
    const open = await statuses(61, () => fetch(`${base}/nope`));
    assert.equal(open.filter((s) => s === 429).length, 1);
    assert.equal(open[60], 429);
  });
});

test('two staff users have separate Studio buckets', async () => {
  await withApp({ studioLimiter: rateLimit({ max: 3, key: (req) => req.staff.userId }) }, async (base) => {
    const call = (u) => fetch(`${base}/v1/studio/ping`, { headers: { 'x-user': u } });
    assert.deepEqual(await statuses(4, () => call('ann')), [200, 200, 200, 429]);
    assert.deepEqual(await statuses(3, () => call('bob')), [200, 200, 200]);
    assert.equal((await call('ann')).status, 429);
  });
});

test('the sign-in routes stay on the strict per-address limit', async () => {
  await withApp({}, async (base) => {
    const login = () => fetch(`${base}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'a@example.test', password: 'x' }) });
    const s = await statuses(61, login);
    assert.equal(s[59], 401);
    assert.equal(s[60], 429);
  });
});

test('unsigned Studio calls from one address are limited too: 1,201 of them end in 429', async () => {
  await withApp({}, async (base) => {
    // a well-formed but unknown session cookie costs a database query in the real service, so it must not be unlimited
    const call = () => fetch(`${base}/v1/studio/ping`);
    const s = await statuses(1201, call);
    assert.ok(s.slice(0, 1200).every((c) => c === 401), 'the first 1,200 are refused as unsigned, not limited');
    assert.equal(s[1200], 429);
  });
});

test('the sign-in routes stay strictly limited however the path is spelled', async () => {
  for (const path of ['/v1/studio/AUTH/login', '/v1/studio/auth//login', '/v1/studio/auth/login/', '/V1/Studio/Auth/Login']) {
    await withApp({}, async (base) => {
      const login = () => fetch(`${base}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'a@example.test', password: 'x' }) });
      const s = await statuses(61, login);
      assert.ok(!s.slice(0, 60).includes(429), `${path}: the first 60 are not limited (${[...new Set(s.slice(0, 60))]})`);
      assert.equal(s[60], 429, `${path}: the 61st is limited`);
    });
  }
});

test('every sign-in route reaches the strict limiter exactly once, however the path is spelled', async () => {
  const forms = [
    ['POST', '/v1/studio/auth/login'], ['POST', '/v1/studio//auth/login'], ['POST', '/v1/studio///auth/login'], ['POST', '/v1/studio/auth//login'],
    ['GET', '/v1/studio/auth/me'], ['GET', '/v1/studio//auth/me'], ['POST', '/v1/studio/auth/logout'], ['POST', '/v1/studio//auth/logout'],
    ['POST', '/V1/STUDIO//AUTH/LOGIN'], ['POST', '/v1/studio//auth/login/'],
  ];
  for (const [method, path] of forms) {
    let hits = 0;
    const limiter = (_req, _res, next) => { hits += 1; next(); };
    await withApp({ limiter }, async (base) => {
      await fetch(`${base}${path}`, { method, headers: { 'content-type': 'application/json' }, body: method === 'POST' ? JSON.stringify({ email: 'a@example.test', password: 'x' }) : undefined });
    });
    assert.equal(hits, 1, `${method} ${path}: strict limiter hits`);
  }
});

test('the strict budget of 60 holds for every sign-in route and spelling: the 61st call is the first 429', async () => {
  const forms = [
    ['POST', '/v1/studio//auth/login'], ['POST', '/v1/studio///auth/login'], ['POST', '/v1/studio//auth//login'],
    ['GET', '/v1/studio//auth/me'], ['POST', '/v1/studio//auth/logout'], ['POST', '/v1/studio/auth/login'], ['GET', '/v1/studio/auth/me'],
  ];
  for (const [method, path] of forms) {
    await withApp({}, async (base) => {
      const s = await statuses(61, () => fetch(`${base}${path}`, { method, headers: { 'content-type': 'application/json' }, body: method === 'POST' ? JSON.stringify({ email: 'a@example.test', password: 'x' }) : undefined }));
      assert.ok(!s.slice(0, 60).includes(429), `${method} ${path}: the first 60 are not limited (${[...new Set(s.slice(0, 60))]})`);
      assert.equal(s[60], 429, `${method} ${path}: the 61st is limited`);
    });
  }
});

test('a non-auth Studio path spelled with a double slash is still limited by the pre-session limiter at 1,201', async () => {
  await withApp({}, async (base) => {
    const s = await statuses(1201, () => fetch(`${base}/v1/studio//ping`));
    assert.ok(s.slice(0, 1200).every((c) => c === 401), 'the first 1,200 are refused as unsigned');
    assert.equal(s[1200], 429);
  });
});

test('the limiter can be keyed by something other than the address', async () => {
  const limit = rateLimit({ max: 1, key: (req) => req.k });
  const res = () => { const r = { headers: {} }; r.set = (k, v) => { r.headers[k] = v; }; r.status = (c) => { r.code = c; return r; }; r.json = () => r; return r; };
  let passed = 0; const next = () => { passed += 1; };
  limit({ k: 'a', ip: '1.1.1.1' }, res(), next); limit({ k: 'b', ip: '1.1.1.1' }, res(), next);
  const blocked = res(); limit({ k: 'a', ip: '1.1.1.1' }, blocked, next);
  assert.equal(passed, 2); assert.equal(blocked.code, 429);
});
