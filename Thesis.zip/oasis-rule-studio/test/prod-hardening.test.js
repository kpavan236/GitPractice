'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { loadStudioConfig } = require('../src/config');
const { createStudioApp } = require('../src/app');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-tls-'));
const key = path.join(dir, 'k.pem');
const cert = path.join(dir, 'c.pem');
fs.writeFileSync(key, 'synthetic-key-text');
fs.writeFileSync(cert, 'synthetic-cert-text');
const BASE = {
  STUDIO_DATABASE_URL: 'postgres://u:p@localhost:5433/studio', RULES_DATABASE_URL: 'postgres://u:p@localhost:5433/rules',
  PACK_DIR: os.tmpdir(), RELEASE_SIGNING_KEY_FILE: key, RELEASE_SIGNING_KEY_ID: 'k1',
};

test('both TLS files set: config carries them, cookies are secure and HSTS is on', () => {
  const c = loadStudioConfig({ ...BASE, TLS_CERT_FILE: cert, TLS_KEY_FILE: key, COOKIE_SECURE: 'false' });
  assert.equal(c.tls.cert, 'synthetic-cert-text');
  assert.equal(c.tls.key, 'synthetic-key-text');
  assert.equal(c.secureCookies, true);
  assert.equal(c.hsts, true);
});

test('no TLS: tls is null and HSTS is off', () => {
  const c = loadStudioConfig(BASE);
  assert.equal(c.tls, null);
  assert.equal(c.hsts, false);
});

test('only one of TLS_CERT_FILE / TLS_KEY_FILE stops start-up', () => {
  assert.throws(() => loadStudioConfig({ ...BASE, TLS_CERT_FILE: cert }), /TLS_CERT_FILE and TLS_KEY_FILE must be set together/);
  assert.throws(() => loadStudioConfig({ ...BASE, TLS_KEY_FILE: key }), /TLS_CERT_FILE and TLS_KEY_FILE must be set together/);
});

test('an unreadable TLS file stops start-up without echoing the path', () => {
  assert.throws(() => loadStudioConfig({ ...BASE, TLS_CERT_FILE: '/no/such/c.pem', TLS_KEY_FILE: key }), (e) => /TLS_CERT_FILE and TLS_KEY_FILE must be paths of readable PEM files/.test(e.message) && !e.message.includes('/no/such'));
});

test('production with no TLS stops unless ALLOW_PLAIN_HTTP=1', () => {
  const prod = { ...BASE, NODE_ENV: 'production', TRUST_PROXY: '0' };
  assert.throws(() => loadStudioConfig(prod), /ALLOW_PLAIN_HTTP/);
  assert.equal(loadStudioConfig({ ...prod, ALLOW_PLAIN_HTTP: '1' }).tls, null);
  assert.equal(loadStudioConfig({ ...prod, TLS_CERT_FILE: cert, TLS_KEY_FILE: key }).hsts, true);
  assert.throws(() => loadStudioConfig({ ...prod, ALLOW_PLAIN_HTTP: 'yes' }), /ALLOW_PLAIN_HTTP must be 1/);
});

test('HSTS header is sent only when asked for', async () => {
  const auth = { requireSession: (_q, r) => r.status(401).end(), login: async () => {}, logout: async () => {} };
  for (const hsts of [true, false]) {
    const app = createStudioApp({ auth, hsts, logRequests: false });
    const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
    try {
      const res = await fetch(`http://127.0.0.1:${server.address().port}/healthz`);
      assert.equal(Boolean(res.headers.get('strict-transport-security')), hsts);
    } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
  }
});

test('request log is one JSON line: method, path, status, ms; no query, body or address', async (t) => {
  const lines = [];
  t.mock.method(console, 'log', (l) => lines.push(l));
  const auth = { requireSession: (_q, r) => r.status(401).end(), login: async () => {}, logout: async () => {} };
  const app = createStudioApp({ auth });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/healthz?email=a@b.example`);
    await res.text();
    await new Promise((r) => setTimeout(r, 50));
  } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
  assert.equal(lines.length, 1);
  const rec = JSON.parse(lines[0]);
  assert.deepEqual(Object.keys(rec).sort(), ['level', 'method', 'ms', 'path', 'status', 'ts']);
  assert.equal(rec.path, '/healthz');
  assert.equal(rec.status, 200);
  assert.ok(!/127\.0\.0\.1|a@b|email/.test(lines[0]));
});

test('an internal error logs one JSON line with the code only, never the message', async (t) => {
  const errs = [];
  t.mock.method(console, 'error', (l) => errs.push(l));
  t.mock.method(console, 'log', () => {});
  const pool = { query: async () => { throw Object.assign(new Error('password=hunter2 host=db.internal'), { code: 'ECONNREFUSED' }); } };
  const auth = { requireSession: (_q, r) => r.status(401).end(), login: async () => {}, logout: async () => {} };
  const app = createStudioApp({ auth, pool });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try { await (await fetch(`http://127.0.0.1:${server.address().port}/readyz`)).text(); } finally { server.closeAllConnections(); await new Promise((r) => server.close(r)); }
  assert.equal(errs.length, 1);
  const rec = JSON.parse(errs[0]);
  assert.equal(rec.level, 'error');
  assert.equal(rec.code, 'ECONNREFUSED');
  assert.ok(!/hunter2|db\.internal/.test(errs[0]));
});
