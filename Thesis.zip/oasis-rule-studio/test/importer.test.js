'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const yaml = require('js-yaml');
const { withStudio, goRule } = require('./helpers/studio');

const R = 'import test';
const invalidRule = () => ({ ...goRule('go-empty'), pattern: 'a*' });
const text = (rules) => JSON.stringify(rules);

test('preview of one valid, one invalid (empty-matching regex) and one existing rule returns add, invalid, update', () => withStudio(async ({ as, repo, pool }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: goRule('go-existing'), reason: R });
  const before = await pool.query('SELECT count(*) FROM audit');
  const res = await ann('POST', '/import/preview', { format: 'json', text: text([goRule('go-new'), invalidRule(), goRule('go-existing')]) });
  assert.equal(res.status, 200);
  assert.deepEqual(res.body.rows.map((r) => [r.id, r.action]), [['go-new', 'add'], ['go-empty', 'invalid'], ['go-existing', 'update']]);
  assert.match(res.body.rows[1].problem, /empty string/);
  assert.equal(res.body.rows[0].testOk, true);
  assert.equal(res.body.rows[1].testOk, undefined);
  assert.equal((await pool.query('SELECT count(*) FROM audit')).rows[0].count, before.rows[0].count, 'preview writes nothing');
  await assert.rejects(() => repo.get('go-new'), { code: 'NOT_FOUND' });
}));

test('commit with an invalid row writes nothing (422)', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  const res = await ann('POST', '/import/commit', { format: 'json', text: text([goRule('go-new'), invalidRule()]), reason: R });
  assert.equal(res.status, 422);
  assert.equal(res.body.error, 'IMPORT_INVALID');
  await assert.rejects(() => repo.get('go-new'), { code: 'NOT_FOUND' });
}));

test('commit creates only draft rules, never active ones, even when the file says status active', () => withStudio(async ({ as, repo, pool }) => {
  const ann = await as('ann');
  const res = await ann('POST', '/import/commit', { format: 'json', text: text([{ ...goRule('go-a'), status: 'active' }, goRule('go-b')]), reason: 'bulk import' });
  assert.equal(res.status, 200);
  assert.deepEqual(res.body.created.sort(), ['go-a', 'go-b']);
  assert.equal((await repo.get('go-a')).status, 'draft');
  assert.equal((await repo.get('go-b')).status, 'draft');
  const rows = await pool.query("SELECT reason FROM audit WHERE action = 'rule.create'");
  assert.ok(rows.rows.every((r) => r.reason === 'bulk import'));
}));

test('commit updates an existing draft with the file content, removing fields the file lacks', () => withStudio(async ({ as, repo }) => {
  const ann = await as('ann');
  await ann('POST', '/rules', { rule: { ...goRule('go-a'), tags: ['old'] }, reason: R });
  const res = await ann('POST', '/import/commit', { format: 'json', text: text([{ ...goRule('go-a'), severity: 'LOW' }]), reason: R });
  assert.deepEqual(res.body.updated, ['go-a']);
  const row = await repo.get('go-a');
  assert.equal(row.severity, 'LOW');
  assert.equal(row.body.tags, undefined);
}));

test('export then import/preview of the same text reports every row as update with no problems (round trip)', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const root = await as('root');
  await ann('POST', '/rules', { rule: goRule('go-a'), reason: R });
  await ann('POST', '/rules', { rule: { ...goRule('go-b'), tags: ['t'] }, reason: R });
  await ann('POST', '/rules/go-b/propose', { reason: R });
  await root('POST', '/rules/go-b/approve', { reason: R });
  for (const format of ['json', 'yaml']) {
    const exp = await ann('GET', `/export?language=go&format=${format}`, undefined, { raw: true });
    assert.equal(exp.status, 200);
    assert.match(exp.headers.get('content-disposition'), /attachment; filename="rules\.(json|yaml)"/);
    const body = await exp.text();
    const prev = await ann('POST', '/import/preview', { format, text: body });
    assert.deepEqual(prev.body.rows.map((r) => [r.id, r.action, r.problem]), [['go-a', 'update', undefined], ['go-b', 'update', undefined]], format);
  }
  assert.equal((await ann('GET', '/export?format=xml')).status, 400);
}));

test('YAML and JSON give the same rows', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const rules = [goRule('go-new'), invalidRule()];
  const j = await ann('POST', '/import/preview', { format: 'json', text: text(rules) });
  const y = await ann('POST', '/import/preview', { format: 'yaml', text: yaml.dump({ rules }) });
  assert.deepEqual(y.body, j.body);
}));

test('YAML cannot construct objects: custom tags are refused with a 400 and no stack', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const res = await ann('POST', '/import/preview', { format: 'yaml', text: '- !!js/function "function(){}"\n' });
  assert.equal(res.status, 400);
  assert.equal(res.body.error, 'BAD_IMPORT');
  assert.doesNotMatch(res.text, /node_modules|\.js:\d+/);
}));

test('import limits and shapes: more than 500 rules, a non-array, a non-object row, a repeated id', () => withStudio(async ({ as }) => {
  const ann = await as('ann');
  const many = Array.from({ length: 501 }, (_, i) => ({ id: `r${i}` }));
  assert.equal((await ann('POST', '/import/preview', { format: 'json', text: text(many) })).status, 400);
  assert.equal((await ann('POST', '/import/preview', { format: 'json', text: '42' })).status, 400);
  assert.equal((await ann('POST', '/import/preview', { format: 'json', text: '{nope' })).status, 400);
  assert.equal((await ann('POST', '/import/preview', { format: 'toml', text: '[]' })).status, 400);
  const rows = (await ann('POST', '/import/preview', { format: 'json', text: text([7, goRule('go-a'), goRule('go-a')]) })).body.rows;
  assert.deepEqual(rows.map((r) => r.action), ['invalid', 'add', 'invalid']);
}));

test('an import cannot replace a seeded rule', () => withStudio(async ({ as, repo }) => {
  await repo.upsertSeeded({ id: 'seeded-one', language: 'go', severity: 'HIGH', pattern: 'danger', files: ['**/*.go'] }, { origin: 'seed', actor: 'seed' });
  const res = await (await as('ann'))('POST', '/import/preview', { format: 'json', text: text([goRule('seeded-one')]) });
  assert.equal(res.body.rows[0].action, 'invalid');
  assert.match(res.body.rows[0].problem, /seeded/);
}));
