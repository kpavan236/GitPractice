#!/usr/bin/env node
'use strict';
// Builds a release from the rules database and the analyzer, signs it and publishes it to a channel, with the same code the Studio's
// release routes use (createStudioServices -> releases.buildCandidate / releases.publish). No sign-in, no UI: for scripted runs, the
// end-to-end proof (scripts/e2e-real-engine.js) and the owner's runbook (docs/E2E.md).
//
// usage: node scripts/build-release.js [--channel beta|stable] [--actor <name>] [--reason <text>]
// settings (the Studio's names): RULES_DATABASE_URL, PACK_DIR, RELEASE_SIGNING_KEY_FILE, RELEASE_SIGNING_KEY_ID, optional ANALYZER_DIR, GRAMMAR_DIR.
// Stable needs the release to be on beta first, so `--channel stable` publishes to beta and then to stable. Prints one JSON line.
const { createPool } = require('oasis-rule-server');
const { loadStudioConfig } = require('../src/config');
const { createStudioServices } = require('../src/server');

const CHANNELS = ['beta', 'stable'];

async function buildRelease({ env = process.env, channel = 'beta', actor = 'build-release-cli', reason = 'scripted release build' } = {}) {
  if (!CHANNELS.includes(channel)) throw new Error(`channel must be one of ${CHANNELS.join(', ')}`);
  // The identity database is a Studio sign-in matter; this script never signs anyone in, so the setting is only there to satisfy the shared loader.
  const config = loadStudioConfig({ ...env, STUDIO_DATABASE_URL: env.STUDIO_DATABASE_URL || env.RULES_DATABASE_URL });
  const rulesPool = createPool(config.rulesDatabaseUrl);
  try {
    const { releases } = createStudioServices(config, { rulesPool, identityPool: null });
    const built = await releases.buildCandidate({ actor, reason });
    await releases.publish(built.releaseNo, 'beta', { actor, reason });
    if (channel === 'stable') await releases.publish(built.releaseNo, 'stable', { actor, reason });
    return {
      releaseNo: built.releaseNo, channel, keyId: config.signingKeyId, rules: Object.keys(built.manifest.ruleVersions).length,
      skippedNoFixture: built.skippedNoFixture, packs: built.manifest.packs.map((p) => ({ packId: p.packId, size: p.size })),
    };
  } finally { await rulesPool.end(); }
}

module.exports = { buildRelease };

if (require.main === module) {
  const arg = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
  buildRelease({ channel: arg('channel', 'beta'), actor: arg('actor'), reason: arg('reason') })
    .then((out) => { console.log(JSON.stringify(out)); }, (err) => { console.error(`build-release: FAILED: ${err.code ? `${err.code}: ` : ''}${err.message}`); process.exit(1); });
}
