#!/usr/bin/env node
'use strict';
// End-to-end check of the split: the Studio signs in, builds and signs a release; the public rules service serves it; the OASIS loader's
// verifier accepts it. Uses throwaway databases and a throwaway key; needs the oasis-pg container (port 5433) and the sibling repos.
// SMOKE_FAULT=wrong-key | tamper-blob | truncate-blob | no-studio deliberately breaks one step, to prove the script can fail. Unset by default.
// SMOKE_OASIS_DIR overrides where the iready-oasis checkout is looked for (a missing one makes the loader check SKIPPED, and the last line says so).
const { spawn, execFileSync } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { Pool } = require('pg');

const ADMIN = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';
const STUDIO = path.resolve(__dirname, '..');
const RULES = path.resolve(STUDIO, '..', 'oasis-rule-server');
const OASIS = process.env.SMOKE_OASIS_DIR || path.resolve(STUDIO, '..', 'iready-oasis');
const MANIFEST = path.join(OASIS, 'server', 'security', 'engine-loader', 'manifest.js');
const RULES_PORT = 5981;
const STUDIO_PORT = 4981;
const FETCH_TIMEOUT_MS = 10000;
const DB_CONNECT_TIMEOUT_MS = 5000;
// Each child gets only these names (values are filled in below); the public service must never see a Studio or signing setting.
const PUBLIC_ENV_KEYS = ['PATH', 'HOME', 'RULES_DATABASE_URL', 'PACK_DIR', 'PORT'];
const STUDIO_ENV_KEYS = ['PATH', 'HOME', 'STUDIO_DATABASE_URL', 'RULES_DATABASE_URL', 'PACK_DIR', 'RELEASE_SIGNING_KEY_FILE', 'RELEASE_SIGNING_KEY_ID', 'COOKIE_SECURE', 'PORT'];
const PW = 'correct horse battery staple';
const FAULT = process.env.SMOKE_FAULT || '';
if (FAULT && !['wrong-key', 'tamper-blob', 'truncate-blob', 'no-studio'].includes(FAULT)) { console.error(`smoke: FAILED: unknown SMOKE_FAULT "${FAULT}"`); process.exit(1); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Every request has a deadline (reading the body included, the signal stays attached), so a wedged service fails the run with a message
// instead of hanging it. Callers wrap the calls and body reads in guard(), so a SIGINT/SIGTERM acts at once instead of after the deadline.
const timedOut = (e) => e && (e.name === 'TimeoutError' || e.name === 'AbortError');
const noAnswer = (method, url) => new Error(`${method} ${new URL(url).pathname} got no answer within ${FETCH_TIMEOUT_MS} ms`);
async function http(url, options = {}) {
  try { return await fetch(url, { ...options, signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) }); } catch (e) {
    if (timedOut(e)) throw noAnswer(options.method || 'GET', url);
    throw e;
  }
}
// Reads a response body (res.json(), res.text(), res.arrayBuffer()); a timeout while reading gives the same message as a request timeout.
async function readBody(res, method, read) {
  try { return await read(res); } catch (e) {
    if (timedOut(e)) throw noAnswer(method, res.url);
    throw e;
  }
}

function pick(source, names) { const out = {}; for (const n of names) if (source[n] !== undefined) out[n] = source[n]; return out; }

// Fails when a child's environment holds a name outside its allowlist (or lacks a setting it needs), so the public service cannot
// quietly come to depend on the signing key or on a Studio setting.
function assertEnv(name, env, allowed, required) {
  const keys = Object.keys(env).sort();
  const extra = keys.filter((k) => !allowed.includes(k));
  const missing = required.filter((k) => env[k] === undefined || env[k] === '');
  if (extra.length || missing.length) throw new Error(`environment self-check failed for the ${name}: unexpected [${extra.join(', ')}], missing [${missing.join(', ')}]`);
  console.log(`smoke: ${name} environment names: ${keys.join(', ')}`);
}

function dbUrl(name) { const u = new URL(ADMIN); u.pathname = `/${name}`; return u.toString(); }

function portFree(port) {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(false));
    s.listen(port, '127.0.0.1', () => s.close(() => resolve(true)));
  });
}

// A child with a rolling tail of its output, so a failure can say what the process last printed (never the environment).
function launch(name, cwd, script, env) {
  const child = spawn('node', [script], { cwd, env, stdio: ['ignore', 'pipe', 'pipe'] });
  const tail = [];
  const keep = (d) => { for (const l of String(d).split('\n')) if (l.trim()) tail.push(l); while (tail.length > 12) tail.shift(); };
  child.stdout.on('data', keep); child.stderr.on('data', keep);
  const svc = { name, child, tail, exited: false };
  child.once('exit', (code, sig) => { svc.exited = true; svc.exitInfo = code === null ? `signal ${sig}` : `code ${code}`; });
  return svc;
}

async function waitFor(url, svc, ms = 20000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (svc.exited) break;
    try { if ((await http(url)).status < 500) return; } catch (_) { /* not up yet */ }
    await sleep(200);
  }
  const why = svc.exited ? `exited (${svc.exitInfo})` : `did not answer within ${ms} ms`;
  throw new Error(`${svc.name} ${why} at ${url}; its last output:\n${svc.tail.map((l) => `    ${l}`).join('\n') || '    (none)'}`);
}

async function stop(svc) {
  if (svc.exited) return;
  const done = new Promise((r) => svc.child.once('exit', r));
  svc.child.kill('SIGTERM');
  const timer = setTimeout(() => svc.child.kill('SIGKILL'), 3000);
  await done; clearTimeout(timer);
}

async function main() {
  const tag = crypto.randomBytes(4).toString('hex');
  const rulesName = `smoke_rules_${tag}`, idName = `smoke_identity_${tag}`;
  let tmp = null;
  const admin = new Pool({ connectionString: ADMIN, max: 1, connectionTimeoutMillis: DB_CONNECT_TIMEOUT_MS });
  const services = [];
  // The first signal rejects `interrupted`, which unwinds through the finally below like any other failure. The handlers stay installed
  // through cleanup (a later signal is ignored there) and the run still ends non-zero when it was interrupted.
  let signalled = null;
  let cleaning = false;
  let rejectInterrupted;
  const interrupted = new Promise((_, reject) => { rejectInterrupted = reject; });
  interrupted.catch(() => {});
  const onSignal = (sig) => { if (!signalled) signalled = sig; if (!cleaning) rejectInterrupted(new Error(`interrupted by ${sig}`)); };
  process.on('SIGINT', onSignal); process.on('SIGTERM', onSignal);
  const guard = (p) => Promise.race([p, interrupted]);
  let failure = null;
  let loader = null;
  try {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-smoke-'));
    const keyFile = path.join(tmp, 'sign.pem');
    const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
    fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    for (const [what, port] of [['public rules service', RULES_PORT], ['Studio', STUDIO_PORT]]) {
      if (!(await portFree(port))) throw new Error(`port ${port} (for the ${what}) is already in use; stop whatever holds it and run again`);
    }
    await guard(admin.query(`CREATE DATABASE ${rulesName}`));
    await guard(admin.query(`CREATE DATABASE ${idName}`));
    const values = { RULES_DATABASE_URL: dbUrl(rulesName), STUDIO_DATABASE_URL: dbUrl(idName), PACK_DIR: path.join(tmp, 'packs'),
      RELEASE_SIGNING_KEY_FILE: keyFile, RELEASE_SIGNING_KEY_ID: 'smoke-1', COOKIE_SECURE: 'false' };
    const publicEnv = { ...pick(process.env, ['PATH', 'HOME']), ...pick(values, ['RULES_DATABASE_URL', 'PACK_DIR']), PORT: String(RULES_PORT) };
    const studioEnv = { ...pick(process.env, ['PATH', 'HOME']), ...pick(values, STUDIO_ENV_KEYS), PORT: String(STUDIO_PORT) };
    assertEnv('public rules service', publicEnv, PUBLIC_ENV_KEYS, ['PATH', 'RULES_DATABASE_URL', 'PACK_DIR', 'PORT']);
    assertEnv('Studio', studioEnv, STUDIO_ENV_KEYS, STUDIO_ENV_KEYS.filter((k) => k !== 'HOME'));
    const env = { ...studioEnv, PORT: '' };   // migrations, seed and the staff CLI: the Studio's settings, no port
    // The setup calls below use execFileSync, which blocks the event loop: a SIGINT/SIGTERM sent while one runs is handled when it returns
    // (each has a 60 s timeout). Everything after the services start is async and guarded.
    const run = (cwd, args, input) => {
      try { execFileSync('node', args, { cwd, env, input, stdio: ['pipe', 'pipe', 'pipe'], timeout: 60000 }); } catch (e) {
        throw new Error(`node ${args.join(' ')} failed: ${String(e.stderr || e.message).trim().split('\n').slice(-3).join(' | ')}`);
      }
    };
    run(RULES, ['src/migrate.js']);
    run(STUDIO, ['scripts/migrate.js']);
    run(RULES, ['scripts/seed-languages.js']);
    for (const [email, role] of [['smoke-author@example.test', 'author'], ['smoke-admin@example.test', 'admin'], ['smoke-admin2@example.test', 'admin']]) {
      run(STUDIO, ['src/staff-cli.js', email, role], `${PW}\n`);
    }
    services.push(launch('public rules service', RULES, 'src/central-server.js', publicEnv));
    if (FAULT !== 'no-studio') services.push(launch('Studio', STUDIO, 'src/server.js', studioEnv));
    await guard(waitFor(`http://127.0.0.1:${RULES_PORT}/v1/health`, services[0]));
    await guard(waitFor(`http://127.0.0.1:${STUDIO_PORT}/readyz`, services[1] || { name: 'Studio (not started: SMOKE_FAULT=no-studio)', tail: [], exited: false }, FAULT === 'no-studio' ? 2000 : 20000));
    console.log('smoke: both services are up');

    const login = async (email) => {
      const res = await guard(http(`http://127.0.0.1:${STUDIO_PORT}/v1/studio/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password: PW }) }));
      if (res.status !== 200) throw new Error(`login ${email}: HTTP ${res.status}`);
      const cookie = res.headers.getSetCookie().find((c) => c.startsWith('studio_session=')).split(';')[0];
      const csrf = (await guard(readBody(res, 'POST', (r) => r.json()))).csrf;
      return async (method, p, body) => {
        const r = await guard(http(`http://127.0.0.1:${STUDIO_PORT}/v1/studio${p}`, { method, headers: { cookie, 'x-csrf-token': csrf, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }));
        const t = await guard(readBody(r, method, (x) => x.text())); let j = null; try { j = JSON.parse(t); } catch (_) { /* not json */ }
        return { status: r.status, body: j, text: t };
      };
    };
    const author = await login('smoke-author@example.test');
    const admin1 = await login('smoke-admin@example.test');
    const admin2 = await login('smoke-admin2@example.test');
    console.log('smoke: three staff members signed in');
    const rule = {
      id: 'go-smoke-skip-verify', language: 'go', pillar: 'security', severity: 'HIGH', title: 'TLS verification disabled',
      description: 'InsecureSkipVerify turns off certificate checks.', files: ['**/*.go'], pattern: 'InsecureSkipVerify:\\s*true',
      example: { file: 'main.go', vulnerable: 'tls.Config{InsecureSkipVerify: true}', fixed: 'tls.Config{MinVersion: tls.VersionTLS12}' },
    };
    const must = (r, ok, what) => { if (!ok.includes(r.status)) throw new Error(`${what}: HTTP ${r.status} ${r.text.slice(0, 200)}`); console.log(`smoke: ${what}: ok`); return r; };
    must(await guard(author('POST', '/rules', { rule, reason: 'smoke' })), [201], 'create rule (author)');
    must(await guard(author('POST', `/rules/${rule.id}/propose`, { reason: 'smoke' })), [200], 'propose rule (author)');
    must(await guard(admin1('POST', `/rules/${rule.id}/approve`, { reason: 'smoke' })), [200], 'approve rule (admin)');
    const cand = must(await guard(admin2('POST', '/releases/candidate', { reason: 'smoke' })), [201], 'build signed candidate (second admin)');
    must(await guard(admin2('POST', `/releases/${cand.body.releaseNo}/publish`, { channel: 'beta', reason: 'smoke' })), [200, 201], 'publish to beta');

    const res = await guard(http(`http://127.0.0.1:${RULES_PORT}/v1/releases/latest?channel=beta`));
    if (res.status !== 200) throw new Error(`public service: /v1/releases/latest answered HTTP ${res.status}`);
    const latest = await guard(readBody(res, 'GET', (r) => r.json()));
    if (!latest.manifest || !latest.signature || latest.keyId !== 'smoke-1') throw new Error('the public service did not serve the signed beta release');
    if (latest.manifest.channel !== 'beta' || latest.manifest.release !== cand.body.releaseNo) throw new Error('the public service served a different release than the one published');
    if (!Array.isArray(latest.manifest.packs) || !latest.manifest.packs.length) throw new Error('the served manifest lists no packs');
    console.log(`smoke: the public service serves release ${latest.manifest.release} on beta (${latest.manifest.packs.length} pack(s))`);
    for (const blob of latest.manifest.packs) {
      const b = await guard(http(`http://127.0.0.1:${RULES_PORT}/v1/blobs/${blob.sha256}`));
      if (b.status !== 200) throw new Error(`blob ${blob.packId}: HTTP ${b.status}`);
      let bytes = Buffer.from(await guard(readBody(b, 'GET', (r) => r.arrayBuffer())));
      if (FAULT === 'tamper-blob') bytes[0] ^= 0xff;
      if (FAULT === 'truncate-blob') bytes = bytes.subarray(0, bytes.length - 1);
      if (bytes.length !== blob.size) throw new Error(`blob ${blob.packId} served by the public service is ${bytes.length} bytes but its manifest says ${blob.size}`);
      if (crypto.createHash('sha256').update(bytes).digest('hex') !== blob.sha256) throw new Error(`blob ${blob.packId} served by the public service does not match its manifest hash`);
    }
    console.log('smoke: every served blob matches its manifest size and hash');

    if (fs.existsSync(MANIFEST)) {
      const { verifyManifest } = require(MANIFEST);
      const trusted = FAULT === 'wrong-key' ? crypto.generateKeyPairSync('ed25519').publicKey : publicKey;
      try {
        verifyManifest({ manifest: latest.manifest, keyId: latest.keyId, signature: latest.signature }, { [latest.keyId]: trusted.export({ type: 'spki', format: 'pem' }) });
      } catch (e) { throw new Error(`the OASIS loader verifier rejected the release (${e.code || 'error'}: ${e.message})`); }
      console.log('smoke: the OASIS loader verifier accepted the release');
      loader = 'loader verification passed';
    } else if (FAULT) {
      throw new Error(`SMOKE_FAULT=${FAULT} needs the loader verifier to prove the fault is caught, but none exists at ${MANIFEST}`);
    } else {
      loader = `loader verification SKIPPED: no verifier at ${MANIFEST}`;
      console.log(`smoke: ${loader}`);
    }
  } catch (err) {
    failure = err;
  } finally {
    cleaning = true;
    const problems = [];
    const attempt = async (what, fn) => { try { await fn(); } catch (e) { problems.push(`${what}: ${e.message}`); } };
    await attempt('stopping services', () => Promise.all(services.map(stop)));
    await attempt(`dropping ${rulesName}`, () => admin.query(`DROP DATABASE IF EXISTS ${rulesName} WITH (FORCE)`));
    await attempt(`dropping ${idName}`, () => admin.query(`DROP DATABASE IF EXISTS ${idName} WITH (FORCE)`));
    await attempt('closing the admin connection', () => admin.end());
    await attempt('removing the temp dir', async () => { if (tmp) fs.rmSync(tmp, { recursive: true, force: true }); });
    if (signalled && !failure) failure = new Error(`interrupted by ${signalled}`);
    if (problems.length) failure = failure || new Error('cleanup incomplete');
    for (const p of problems) console.error(`smoke: cleanup problem: ${p}`);
  }
  if (failure) throw failure;
  return loader;
}

// OK is printed only after cleanup succeeded too.
main().then((loader) => { console.log(`smoke: OK (${loader})`); process.exit(0); }, (err) => { console.error(`smoke: FAILED: ${err.message}`); process.exit(1); });
