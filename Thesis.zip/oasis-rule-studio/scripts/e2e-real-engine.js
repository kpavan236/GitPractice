#!/usr/bin/env node
'use strict';
// End-to-end proof with the REAL engine, on a throwaway stack, one command:
//   seed the rules -> build core (from oasis-analyzer) + language packs (rules + grammars), sign with a throwaway key, publish to beta
//   (scripts/build-release.js, the Studio's own release code) -> serve it with the public rules service -> the OASIS loader installs it
//   -> a scan on the installed engine and one on the bundled engine must report identical findings (iready-oasis/tools/e2e-installed-rules.js).
// Needs the oasis-pg container (port 5433, or RULES_TEST_DATABASE_URL) and the sibling checkouts. Everything it creates (a prefixed database,
// a temp dir with the pack blobs, the throwaway key and HOME, the service process) is removed at the end, pass or fail. It never touches
// ~/.oasis-security, ~/.oasis-local-stack or any other database. Prints `e2e-real-engine: OK` only after cleanup succeeded too.
// E2E_REPO=/path scans an existing repository (read only) instead of the generated sample.
const { spawn, execFileSync } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { Pool } = require('pg');

const ADMIN = process.env.RULES_TEST_DATABASE_URL || 'postgres://postgres:local-dev-only@127.0.0.1:5433/postgres';
const STUDIO = path.resolve(__dirname, '..');
const RULES = path.resolve(STUDIO, '..', 'oasis-rule-server');
const OASIS = process.env.SMOKE_OASIS_DIR || path.resolve(STUDIO, '..', 'iready-oasis');
const ENV_KEEP = ['PATH', 'HOME'];

const say = (m) => console.log(`e2e-real-engine: ${m}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const dbUrl = (name) => { const u = new URL(ADMIN); u.pathname = `/${name}`; return u.toString(); };

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
  });
}

function run(cwd, args, env, label) {
  try { return execFileSync('node', args, { cwd, env, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000 }); } catch (e) {
    throw new Error(`${label} failed: ${String(e.stderr || e.stdout || e.message).trim().split('\n').slice(-6).join(' | ')}`);
  }
}

async function main() {
  const tag = crypto.randomBytes(4).toString('hex');
  const dbName = `e2e_real_rules_${tag}`;
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'oasis-e2e-real-'));
  const admin = new Pool({ connectionString: ADMIN, max: 1, connectionTimeoutMillis: 5000 });
  let service = null;
  let failure = null;
  try {
    for (const dir of [RULES, OASIS, path.resolve(STUDIO, '..', 'oasis-analyzer')]) if (!fs.existsSync(dir)) throw new Error(`the sibling checkout ${dir} is needed`);
    const base = Object.fromEntries(ENV_KEEP.filter((k) => process.env[k] !== undefined).map((k) => [k, process.env[k]]));
    const keyFile = path.join(tmp, 'sign.pem');
    const keysFile = path.join(tmp, 'dev-keys.json');
    const home = path.join(tmp, 'home');
    fs.mkdirSync(home);
    await admin.query(`CREATE DATABASE ${dbName}`);
    const rulesEnv = { ...base, RULES_DATABASE_URL: dbUrl(dbName), PACK_DIR: path.join(tmp, 'packs') };

    run(RULES, ['src/migrate.js'], rulesEnv, 'migrate');
    say(`${run(RULES, ['scripts/seed-central.js'], rulesEnv, 'seed-central').trim()}`);
    const publicPem = run(RULES, ['scripts/gen-signing-key.js', keyFile], base, 'gen-signing-key');
    fs.writeFileSync(keysFile, JSON.stringify({ 'dev-1': publicPem }));
    const built = run(STUDIO, ['scripts/build-release.js', '--channel', 'beta', '--reason', 'e2e real engine'], { ...rulesEnv, RELEASE_SIGNING_KEY_FILE: keyFile, RELEASE_SIGNING_KEY_ID: 'dev-1' }, 'build-release');
    const summary = JSON.parse(built.trim().split('\n').pop());
    say(`built release ${summary.releaseNo} on beta: ${summary.rules} rules, ${summary.packs.length} packs (core ${summary.packs[0].size} bytes)`);

    const port = await freePort();
    service = spawn('node', ['src/central-server.js'], { cwd: RULES, env: { ...rulesEnv, PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'] });
    const tail = [];
    service.on('error', (e) => tail.push(`spawn failed: ${e.message}`));
    for (const s of [service.stdout, service.stderr]) s.on('data', (d) => { tail.push(...String(d).split('\n').filter(Boolean)); while (tail.length > 8) tail.shift(); });
    let up = false;
    for (let i = 0; i < 100 && !up; i += 1) {
      if (service.exitCode !== null || service.pid === undefined) throw new Error(`the public service exited: ${tail.join(' | ')}`);
      try { up = (await fetch(`http://127.0.0.1:${port}/v1/health`, { signal: AbortSignal.timeout(2000) })).ok; } catch { await sleep(200); }
    }
    if (!up) throw new Error(`the public service did not answer on ${port}: ${tail.join(' | ')}`);
    say(`public rules service on 127.0.0.1:${port}`);

    const out = execFileSync('node', [path.join(OASIS, 'tools', 'e2e-installed-rules.js')], {
      cwd: OASIS, encoding: 'utf8', timeout: 300000, stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...base, HOME: home, OASIS_RULE_SERVER_URL: `http://127.0.0.1:${port}`, OASIS_DEV_RULES_PUBLIC_KEYS: keysFile, OASIS_RULES_CHANNEL: 'beta', ...(process.env.E2E_REPO ? { E2E_REPO: process.env.E2E_REPO } : {}) },
    });
    process.stdout.write(out);
  } catch (e) {
    failure = e;
    if (e && e.stdout) process.stdout.write(String(e.stdout));
    if (e && e.stderr) process.stderr.write(String(e.stderr));
  } finally {
    const problems = [];
    const attempt = async (what, fn) => { try { await fn(); } catch (e) { problems.push(`${what}: ${e.message}`); } };
    await attempt('stopping the public service', async () => {
      if (service && service.exitCode === null) { const done = new Promise((r) => service.once('exit', r)); service.kill('SIGTERM'); const t = setTimeout(() => service.kill('SIGKILL'), 3000); await done; clearTimeout(t); }
    });
    await attempt(`dropping ${dbName}`, () => admin.query(`DROP DATABASE IF EXISTS ${dbName} WITH (FORCE)`));
    await attempt('closing the admin connection', () => admin.end());
    await attempt('removing the temp dir', async () => fs.rmSync(tmp, { recursive: true, force: true }));
    for (const p of problems) console.error(`e2e-real-engine: cleanup problem: ${p}`);
    if (problems.length && !failure) failure = new Error('cleanup incomplete');
  }
  if (failure) throw failure;
}

main().then(() => { say('OK'); process.exit(0); }, (e) => { console.error(`e2e-real-engine: FAILED: ${e.message}`); process.exit(1); });
