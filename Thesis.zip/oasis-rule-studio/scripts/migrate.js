'use strict';
// Applies db/identity/*.sql to STUDIO_DATABASE_URL, once each, with checksums (the migrator is the rules service's own).
const path = require('node:path');
const { migrate } = require('oasis-rule-server');

if (require.main === module) {
  (async () => {
    if (!process.env.STUDIO_DATABASE_URL) throw new Error('STUDIO_DATABASE_URL is required.');
    const applied = await migrate(process.env.STUDIO_DATABASE_URL, path.join(__dirname, '..', 'db', 'identity'));
    console.log(`studio identity: ${applied.length ? `applied ${applied.join(', ')}` : 'up to date'}`);
  })().catch((err) => { console.error(err.message); process.exit(1); });
}
