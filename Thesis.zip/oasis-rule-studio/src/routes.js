'use strict';
const path = require('node:path');
const express = require('express');
const { PILLARS, SEVERITIES, engineOf, coverage } = require('oasis-rule-server');
const { TEMPLATES, byId } = require('./templates');
const { diffBodies } = require('./diff');
const { findDuplicates } = require('./duplicates');
const { serialize, planImport } = require('./importer');
const { measureImpact } = require('./impact');

const STATUS_OF = { INVALID: 400, NOT_FOUND: 404, CONFLICT: 409, FORBIDDEN: 403, BAD_IMPORT: 400 };
const MAX_TAGS = 50;      // the same cap updateMetadata enforces, so bulk planning refuses what the write would refuse
const SEEDED_FIELDS = ['severity', 'pillar', 'tags'];
const BULK_ACTIONS = ['severity', 'pillar', 'tag-add', 'deprecate', 'reactivate'];
const IMPORT_JSON_LIMIT = '2mb';      // only the two import routes; the rest of the studio branch is capped at 16kb in src/app.js

const isObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const reasonOk = (v) => typeof v === 'string' && v.trim().length > 0;
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const send = (res, status, error, extra = {}) => res.status(status).json({ error, ...extra });

const summary = (r) => ({
  id: r.rule_id, language: r.language, engine: r.engine, pillar: r.pillar, severity: r.severity,
  status: r.status, version: r.version, origin: r.origin, title: (r.body && r.body.title) || null, updatedAt: r.updated_at,
});
const detail = (r) => ({ ...summary(r), proposedBy: r.proposed_by, body: r.body });

/**
 * The Studio rule-management routes, to be mounted under /v1/studio after requireSession (src/app.js does that).
 * `tester(rule)` is the fixture tester; `sampleCorpusDir` (optional) is where the impact check looks.
 */
function createStudioRoutes({ auth, repo, tester, pool, sampleCorpusDir = null }) {
  const router = express.Router();
  const can = auth.requirePermission;
  const languageIds = async () => (await pool.query('SELECT id FROM language ORDER BY id')).rows.map((r) => r.id);
  const languageEntry = async (id) => (await pool.query('SELECT id, extensions FROM language WHERE id = $1', [id])).rows[0] || null;
  const ctx = (req) => ({ actor: String(req.staff.email).toLowerCase(), reason: req.body.reason });
  const needReason = (req, res, next) => (reasonOk(req.body && req.body.reason) ? next() : send(res, 400, 'REASON_REQUIRED', { message: 'a reason is required' }));
  const query = (req, ...names) => {
    const out = {};
    for (const n of names) {
      const v = req.query[n];
      if (v === undefined || v === '') continue;
      if (typeof v !== 'string') throw Object.assign(new Error(`${n} must be a single value`), { code: 'INVALID' });
      out[n] = v;
    }
    return out;
  };
  const ruleBody = (req) => {
    const rule = req.body && req.body.rule;
    if (!isObject(rule)) throw Object.assign(new Error('a rule object is required'), { code: 'INVALID' });
    return rule;
  };

  router.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

  // ---- reading ----
  router.get('/rules', can('rule.read'), wrap(async (req, res) => {
    const rows = await repo.list(query(req, 'language', 'pillar', 'severity', 'engine', 'status', 'search'));
    res.json({ rules: rows.map(summary) });
  }));

  router.get('/rules/:id', can('rule.read'), wrap(async (req, res) => res.json(detail(await repo.get(req.params.id)))));

  router.get('/rules/:id/history', can('rule.read'), wrap(async (req, res) => {
    const rows = await repo.history(req.params.id);
    res.json({ versions: rows.map((v) => ({ version: v.version, body: v.body, changedBy: v.changed_by, reason: v.reason, changedAt: v.changed_at })) });
  }));

  router.get('/rules/:id/diff', can('rule.read'), wrap(async (req, res) => {
    const { from, to } = query(req, 'from', 'to');
    if (!/^\d{1,9}$/.test(from || '') || !/^\d{1,9}$/.test(to || '')) return send(res, 400, 'INVALID', { message: 'from and to must be version numbers' });
    const versions = await repo.history(req.params.id);
    const a = versions.find((v) => v.version === Number(from));
    const b = versions.find((v) => v.version === Number(to));
    if (!a || !b) return send(res, 404, 'NOT_FOUND', { message: 'that version does not exist' });
    res.json({ fields: diffBodies(a.body, b.body) });
  }));

  // ---- writing one rule ----
  router.post('/rules', can('rule.write'), needReason, wrap(async (req, res) => {
    const row = await repo.create(ruleBody(req), ctx(req));
    res.status(201).json(detail(row));
  }));

  router.patch('/rules/:id', can('rule.write'), needReason, wrap(async (req, res) => {
    const patch = req.body.patch;
    if (!isObject(patch) || !Object.keys(patch).length) return send(res, 400, 'INVALID', { message: 'a patch object is required' });
    const current = await repo.get(req.params.id);
    if (current.origin !== 'user') {
      const other = Object.keys(patch).filter((k) => !SEEDED_FIELDS.includes(k));
      if (other.length) return send(res, 422, 'SEEDED_RULE_LIMITED', { message: `a seeded rule only allows ${SEEDED_FIELDS.join(', ')} to change; clone it to edit anything else` });
      return res.json(detail(await repo.updateMetadata(req.params.id, patch, ctx(req))));
    }
    res.json(detail(await repo.update(req.params.id, patch, ctx(req))));
  }));

  router.post('/rules/:id/clone', can('rule.write'), needReason, wrap(async (req, res) => {
    const { newId, language } = req.body;
    if (typeof newId !== 'string' || !/^[a-z0-9][a-z0-9-]*$/.test(newId)) return send(res, 400, 'INVALID', { message: 'newId must be lowercase letters, digits and hyphens' });
    if (language !== undefined && typeof language !== 'string') return send(res, 400, 'INVALID', { message: 'language must be a language id' });
    const source = await repo.get(req.params.id);
    const copy = { ...source.body, id: newId };
    if (language && language !== source.language) {
      const entry = await languageEntry(language);
      if (!entry) return send(res, 400, 'INVALID', { message: `language "${language}" is not in the language registry` });
      copy.language = language;
      if (copy.files) copy.files = entry.extensions.map((e) => `**/*${e}`);
      if (copy.example && typeof copy.example.file === 'string' && entry.extensions.length) {
        copy.example = { ...copy.example, file: `${copy.example.file.replace(/\.[^./]*$/, '')}${entry.extensions[0]}` };
      }
    }
    res.status(201).json(detail(await repo.create(copy, ctx(req))));
  }));

  router.post('/rules/:id/propose', can('rule.propose'), needReason, wrap(async (req, res) => {
    const current = await repo.get(req.params.id);
    if (current.status !== 'draft') return send(res, 400, 'INVALID', { message: `a ${current.status} rule cannot be proposed` });
    const result = await tester(current.body);
    if (!result.ok) return send(res, 422, 'FIXTURE_FAILED', { problems: result.problems || [] });
    res.json(detail(await repo.setStatus(req.params.id, 'proposed', ctx(req))));
  }));

  router.post('/rules/:id/approve', can('rule.approve'), needReason, wrap(async (req, res) => res.json(detail(await repo.setStatus(req.params.id, 'active', ctx(req))))));
  router.post('/rules/:id/deprecate', can('rule.deprecate'), needReason, wrap(async (req, res) => res.json(detail(await repo.setStatus(req.params.id, 'deprecated', ctx(req))))));

  router.post('/rules/:id/revert', can('rule.write'), needReason, wrap(async (req, res) => {
    const version = req.body.version;
    if (!Number.isInteger(version) || version < 1) return send(res, 400, 'INVALID', { message: 'version must be a whole number' });
    const current = await repo.get(req.params.id);
    if (current.origin !== 'user') return send(res, 422, 'SEEDED_RULE_LIMITED', { message: 'a seeded rule cannot be reverted; change its severity, pillar or tags instead' });
    res.json(detail(await repo.revert(req.params.id, version, ctx(req))));
  }));

  // ---- trying a rule (nothing is written, so no reason) ----
  router.post('/rules/test', can('rule.test'), wrap(async (req, res) => res.json(await tester(ruleBody(req)))));
  router.post('/rules/:id/test', can('rule.test'), wrap(async (req, res) => res.json(await tester((await repo.get(req.params.id)).body))));

  router.post('/rules/impact', can('rule.test'), wrap(async (req, res) => {
    const rule = ruleBody(req);
    if (!sampleCorpusDir) return res.json({ available: false });
    if (engineOf(rule) !== 'pattern') return send(res, 400, 'IMPACT_UNSUPPORTED', { message: 'the impact check covers pattern rules only' });
    const out = await measureImpact(rule, path.resolve(sampleCorpusDir));
    if (out.problem) return send(res, 422, 'IMPACT_FAILED', { message: out.problem });
    res.json({ available: true, filesScanned: out.filesScanned, filesMatched: out.filesMatched });
  }));

  router.post('/rules/duplicates', can('rule.read'), wrap(async (req, res) => {
    const rule = ruleBody(req);
    if (typeof rule.language !== 'string') return send(res, 400, 'INVALID', { message: 'the rule needs a language' });
    res.json({ duplicates: findDuplicates(rule, await repo.list({ language: rule.language })) });
  }));

  // ---- bulk ----
  const bulkNeedsDeprecate = (req, res, next) => (['deprecate', 'reactivate'].includes(req.body && req.body.action) ? can('rule.deprecate')(req, res, next) : next());
  router.post('/rules/bulk', can('rule.write'), bulkNeedsDeprecate, wrap(async (req, res) => {
    const { ids, action, value, dryRun } = req.body;
    if (!Array.isArray(ids) || !ids.length || ids.length > 200 || !ids.every((i) => typeof i === 'string' && i)) return send(res, 400, 'INVALID', { message: 'ids must be a list of 1 to 200 rule ids' });
    if (!BULK_ACTIONS.includes(action)) return send(res, 400, 'INVALID', { message: `action must be one of ${BULK_ACTIONS.join(', ')}` });
    if (action === 'severity' && !SEVERITIES.includes(value)) return send(res, 400, 'INVALID', { message: `value must be one of ${SEVERITIES.join(', ')}` });
    if (action === 'pillar' && !PILLARS.includes(value)) return send(res, 400, 'INVALID', { message: `value must be one of ${PILLARS.join(', ')}` });
    if (action === 'tag-add' && !(typeof value === 'string' && value.trim() && value.length <= 64)) return send(res, 400, 'INVALID', { message: 'value must be a tag of up to 64 characters' });
    const dry = dryRun === true;
    if (!dry && !reasonOk(req.body.reason)) return send(res, 400, 'REASON_REQUIRED', { message: 'a reason is required' });

    const wouldChange = [];
    const problems = [];
    for (const id of [...new Set(ids)]) {
      let row;
      try { row = await repo.get(id); } catch (e) { if (e.code === 'NOT_FOUND') { problems.push({ id, problem: 'does not exist' }); continue; } throw e; }
      let step;
      if (action === 'deprecate') step = row.status === 'active' ? { before: row.status, after: 'deprecated' } : { problem: `a ${row.status} rule cannot be deprecated` };
      else if (action === 'reactivate') step = row.status === 'deprecated' ? { before: row.status, after: 'active' } : { problem: `a ${row.status} rule cannot be reactivated` };
      else if (row.status !== 'draft' && row.status !== 'active') step = { problem: `a ${row.status} rule cannot be edited` };
      else if (action === 'tag-add') {
        const tags = row.body.tags === undefined ? [] : row.body.tags;
        if (!(Array.isArray(tags) && tags.every((t) => typeof t === 'string' && t.trim() && t.length <= 64))) step = { problem: 'its existing tags are malformed' };
        else if (tags.includes(value.trim())) step = null;
        else if (tags.length >= MAX_TAGS) step = { problem: `it already has ${MAX_TAGS} tags` };
        else step = { before: tags, after: [...tags, value.trim()] };
      } else step = row[action] === value ? null : { before: row[action], after: value };
      if (step && step.problem) problems.push({ id, problem: step.problem });
      else if (step) wouldChange.push({ id, ...step });
    }
    if (dry) return res.json({ wouldChange, problems });
    if (problems.length) return send(res, 422, 'BULK_REFUSED', { problems });
    for (const change of wouldChange) {
      if (action === 'deprecate' || action === 'reactivate') await repo.setStatus(change.id, change.after, ctx(req));
      else await repo.updateMetadata(change.id, { [action === 'tag-add' ? 'tags' : action]: change.after }, ctx(req));
    }
    res.json({ changed: wouldChange.map((c) => c.id) });
  }));

  // ---- templates ----
  router.get('/templates', can('rule.read'), (_req, res) => {
    res.json({ templates: TEMPLATES.map(({ id, title, engine, description, params }) => ({ id, title, engine, description, params })) });
  });

  router.post('/templates/:id/build', can('rule.read'), wrap(async (req, res) => {
    const template = byId(req.params.id);
    if (!template) return send(res, 404, 'NOT_FOUND', { message: 'no such template' });
    const language = typeof req.body.language === 'string' ? await languageEntry(req.body.language) : null;
    if (!language) return send(res, 400, 'INVALID', { message: 'language must be a language in the registry' });
    res.json({ rule: template.build(isObject(req.body.params) ? req.body.params : {}, language) });
  }));

  // ---- import and export (the only routes that take bodies up to 2 MB) ----
  const bigJson = express.json({ limit: IMPORT_JSON_LIMIT });
  const importPlan = (req) => planImport({ format: req.body.format, text: req.body.text, repo, languages: languageIds, tester });

  router.post('/import/preview', can('rule.write'), bigJson, wrap(async (req, res) => {
    res.json({ rows: (await importPlan(req)).rows });
  }));

  router.post('/import/commit', can('rule.write'), bigJson, needReason, wrap(async (req, res) => {
    const { rows, items } = await importPlan(req);
    if (rows.some((r) => r.action === 'invalid')) return send(res, 422, 'IMPORT_INVALID', { message: 'nothing was imported because some rules are invalid', rows });
    const created = [];
    const updated = [];
    for (const item of items) {
      if (item.existing) {
        const patch = Object.fromEntries(Object.keys(item.existing.body).filter((k) => !(k in item.body)).map((k) => [k, null]));
        await repo.update(item.body.id, { ...item.body, ...patch }, ctx(req));
        updated.push(item.body.id);
      } else {
        await repo.create(item.body, ctx(req));      // always a draft
        created.push(item.body.id);
      }
    }
    res.json({ created, updated });
  }));

  router.get('/export', can('rule.read'), wrap(async (req, res) => {
    const { language, pillar, status, format = 'json' } = query(req, 'language', 'pillar', 'status', 'format');
    if (format !== 'json' && format !== 'yaml') return send(res, 400, 'INVALID', { message: 'format must be json or yaml' });
    const rows = await repo.list({ language, pillar, status });
    res.set('Content-Type', format === 'yaml' ? 'application/yaml; charset=utf-8' : 'application/json; charset=utf-8');
    res.set('Content-Disposition', `attachment; filename="rules.${format}"`);
    res.send(serialize(format, rows.map((r) => r.body)));
  }));

  // ---- reference ----
  router.get('/languages/coverage', can('language.read'), wrap(async (_req, res) => res.json({ languages: await coverage(pool) })));

  router.get('/audit', can('audit.read'), wrap(async (req, res) => {
    const { limit } = query(req, 'limit');
    const n = limit === undefined ? 100 : Number(limit);
    if (!Number.isInteger(n) || n < 1 || n > 500) return send(res, 400, 'INVALID', { message: 'limit must be 1 to 500' });
    const { rows } = await pool.query('SELECT audit_id, actor, action, subject, reason, outcome, detail, at FROM audit ORDER BY audit_id DESC LIMIT $1', [n]);
    res.json({ entries: rows.map((r) => ({ id: r.audit_id, actor: r.actor, action: r.action, subject: r.subject, reason: r.reason, outcome: r.outcome, detail: r.detail, at: r.at })) });
  }));

  // eslint-disable-next-line no-unused-vars
  router.use((err, _req, res, next) => {
    if (err && err.type === 'entity.too.large') return send(res, 413, 'TOO_LARGE');
    if (err && (err.type === 'entity.parse.failed' || err.type === 'encoding.unsupported' || err.type === 'charset.unsupported')) return send(res, 400, 'BAD_REQUEST');
    if (err && STATUS_OF[err.code]) return send(res, STATUS_OF[err.code], err.code, { message: err.message });
    next(err);
  });

  return router;
}

module.exports = { createStudioRoutes };
