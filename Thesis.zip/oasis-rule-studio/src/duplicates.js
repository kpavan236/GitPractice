'use strict';

const trimmed = (v) => (typeof v === 'string' ? v.trim() : '');
const sourceOf = (p) => { try { return new RegExp(p).source; } catch (_) { return null; } };
const sameFiles = (a, b) => Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((x, i) => x === b[i]);

/** Ids of the stored rows (same language) that the candidate rule duplicates. Rows are {rule_id, language, body}. */
function findDuplicates(rule, rows) {
  const pattern = trimmed(rule.pattern);
  const query = trimmed(rule.query);
  const source = pattern ? sourceOf(pattern) : null;
  return rows.filter((r) => {
    if (r.rule_id === rule.id || r.language !== rule.language) return false;
    const b = r.body || {};
    if (pattern && pattern === trimmed(b.pattern)) return true;
    if (query && query === trimmed(b.query)) return true;
    return Boolean(source) && sameFiles(rule.files, b.files) && sourceOf(trimmed(b.pattern)) === source;
  }).map((r) => r.rule_id);
}

module.exports = { findDuplicates };
