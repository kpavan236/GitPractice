'use strict';
const { isEmptyMatching } = require('oasis-rule-server');

const MAX_PARAM = 200;
const MAX_PATTERN = 500;
const invalid = (message) => Object.assign(new Error(message), { code: 'INVALID' });

/** Escapes regex metacharacters, so a template cannot turn a plain word into an unintended pattern. */
const escape = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function param(params, name, label) {
  const v = params && params[name];
  if (typeof v !== 'string' || !v.trim()) throw invalid(`${label} is required`);
  if (v.length > MAX_PARAM) throw invalid(`${label} is longer than ${MAX_PARAM} characters`);
  return v.trim();
}

// `language` is the registry entry ({id, extensions}); the files glob comes from its extensions.
function filesFor(language) {
  const exts = language && Array.isArray(language.extensions) ? language.extensions : [];
  return exts.length ? exts.map((e) => `**/*${e}`) : ['**/*'];
}

function make(id, title, description, p, pattern) {
  return {
    id, title, engine: 'pattern', description, params: [p],
    build(params, language) {
      return { pattern: pattern(escape(param(params, p.name, p.label))), files: filesFor(language) };
    },
  };
}

const TEMPLATES = [
  make('dangerous-call', 'Call to a dangerous function', 'Flags any call to the named function.',
    { name: 'function', label: 'Function name', example: 'strcpy' }, (e) => `\\b${e}\\s*\\(`),
  make('forbidden-import', 'Forbidden import', 'Flags an import, using, require or include of the named module.',
    { name: 'module', label: 'Module name', example: 'child_process' }, (e) => `^\\s*(import|using|require|include)\\b.*\\b${e}\\b`),
  make('hardcoded-value', 'Hardcoded value in a field', 'Flags a quoted literal assigned to the named field.',
    { name: 'field', label: 'Field name', example: 'password' }, (e) => `\\b${e}\\b\\s*[:=]\\s*["'][^"']+["']`),
  make('missing-config-key', 'Configuration key defined',
    'Matches the line that defines the key. To flag a file that lacks the key, use this pattern as the rule\'s negate setting on a rule that matches the file itself.',
    { name: 'key', label: 'Configuration key', example: 'timeout' }, (e) => `^\\s*["']?${e}["']?\\s*[:=]`),
  {
    id: 'regex-on-line', title: 'Regular expression on a line', engine: 'pattern',
    description: 'Flags any line the regular expression matches. The expression is checked when you build the rule.',
    params: [{ name: 'regex', label: 'Regular expression', example: 'TODO\\(security\\)' }],
    build(params, language) {
      const regex = param(params, 'regex', 'Regular expression');
      if (regex.length > MAX_PATTERN) throw invalid(`the regular expression is longer than ${MAX_PATTERN} characters`);
      try { new RegExp(regex); } catch (e) { throw invalid(`the regular expression does not compile (${e.message})`); }
      if (isEmptyMatching({ pattern: regex })) throw invalid('the regular expression matches the empty string');
      return { pattern: regex, files: filesFor(language) };
    },
  },
];

const byId = (id) => TEMPLATES.find((t) => t.id === id);

module.exports = { TEMPLATES, byId, escape };
