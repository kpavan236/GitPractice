'use strict';

/**
 * One-line JSON logs. Only the fields named here are ever written: a request line carries method, path (no query string), status and
 * milliseconds; nothing from a body, a header, a cookie, an email or a client address.
 */
function line(level, fields) {
  return JSON.stringify({ ts: new Date().toISOString(), level, ...fields });
}

const info = (fields) => console.log(line('info', fields));
const warn = (fields) => console.warn(line('warn', fields));
const error = (fields) => console.error(line('error', fields));

/** Express middleware: logs one line when the response has finished. */
function requestLog(req, res, next) {
  const started = process.hrtime.bigint();
  res.on('finish', () => {
    info({ method: req.method, path: String(req.originalUrl || req.url).split('?')[0], status: res.statusCode, ms: Math.round(Number(process.hrtime.bigint() - started) / 1e6) });
  });
  next();
}

module.exports = { line, info, warn, error, requestLog };
