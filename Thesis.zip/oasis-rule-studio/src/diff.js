'use strict';

function canonical(v) {
  if (Array.isArray(v)) return v.map(canonical);
  if (v && typeof v === 'object') return Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])]));
  return v;
}
const same = (a, b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));

/** Top-level fields that differ between two rule bodies; a missing field shows as undefined (null in JSON). */
function diffBodies(before, after) {
  const keys = [...new Set([...Object.keys(before || {}), ...Object.keys(after || {})])].sort();
  return keys.filter((k) => !same(before[k], after[k])).map((k) => ({ field: k, before: before[k] === undefined ? null : before[k], after: after[k] === undefined ? null : after[k] }));
}

module.exports = { diffBodies };
