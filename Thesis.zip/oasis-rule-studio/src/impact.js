'use strict';
const path = require('node:path');
const { Worker } = require('node:worker_threads');

/** Runs the rule over the sample corpus in a time-limited worker. Resolves to {filesScanned, filesMatched} or {problem}. */
function measureImpact(rule, dir, { timeoutMs = 15000 } = {}) {
  return new Promise((resolve) => {
    let settled = false;
    let timer;
    let worker;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (worker) worker.terminate().catch(() => {});
      resolve(result);
    };
    try { worker = new Worker(path.join(__dirname, 'impact-worker.js'), { workerData: { rule, dir } }); }
    catch (_) { return finish({ problem: 'the impact check could not start' }); }
    timer = setTimeout(() => finish({ problem: `timed out after ${timeoutMs} ms` }), timeoutMs);
    worker.once('message', finish);
    worker.once('error', () => finish({ problem: 'the impact check failed' }));
    worker.once('exit', (code) => finish({ problem: `the impact check stopped early (code ${code})` }));
  });
}

module.exports = { measureImpact };
