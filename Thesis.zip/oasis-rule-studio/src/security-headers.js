'use strict';

const CSP = "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";

function securityHeaders(_req, res, next) {
  res.set('Content-Security-Policy', CSP);
  res.set('X-Frame-Options', 'DENY');
  res.set('Referrer-Policy', 'no-referrer');
  res.set('X-Content-Type-Options', 'nosniff');
  next();
}

/** Tells browsers to use https only; added to the app only when the Studio itself serves TLS. */
function hstsHeader(_req, res, next) {
  res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
}

module.exports = { securityHeaders, hstsHeader, CSP };
