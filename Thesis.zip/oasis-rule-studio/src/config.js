'use strict';
const fs = require('node:fs');
const path = require('node:path');

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Reads and checks every setting once, at start-up. A missing or malformed setting stops the Studio with a message naming it. */
function loadStudioConfig(env = process.env) {
  const need = (name) => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  if (env.COOKIE_SECURE !== undefined && env.COOKIE_SECURE !== '' && !['true', 'false'].includes(env.COOKIE_SECURE)) throw new Error('COOKIE_SECURE must be true or false.');
  const studioDatabaseUrl = need('STUDIO_DATABASE_URL');
  const rulesDatabaseUrl = need('RULES_DATABASE_URL');
  const packDir = need('PACK_DIR');
  const keyFile = need('RELEASE_SIGNING_KEY_FILE');
  const signingKeyId = need('RELEASE_SIGNING_KEY_ID');
  if (env.NODE_ENV === 'production' && (env.TRUST_PROXY === undefined || env.TRUST_PROXY === '')) {
    throw new Error('TRUST_PROXY must be set in production (the number of proxies in front of the Studio; 0 if none), or every caller appears to come from the proxy\'s address.');
  }
  // In-app TLS: both files or neither. Production without TLS must say so (ALLOW_PLAIN_HTTP=1: the hosting platform ends TLS in front of the Studio).
  if (env.ALLOW_PLAIN_HTTP !== undefined && env.ALLOW_PLAIN_HTTP !== '' && env.ALLOW_PLAIN_HTTP !== '1') throw new Error('ALLOW_PLAIN_HTTP must be 1 when set.');
  const certFile = env.TLS_CERT_FILE || '';
  const tlsKeyFile = env.TLS_KEY_FILE || '';
  if (Boolean(certFile) !== Boolean(tlsKeyFile)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together.');
  let tls = null;
  if (certFile) {
    try { tls = { cert: fs.readFileSync(certFile, 'utf8'), key: fs.readFileSync(tlsKeyFile, 'utf8') }; } catch { throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be paths of readable PEM files.'); }
  } else if (env.NODE_ENV === 'production' && env.ALLOW_PLAIN_HTTP !== '1') {
    throw new Error('In production the Studio must serve TLS itself (set TLS_CERT_FILE and TLS_KEY_FILE), or set ALLOW_PLAIN_HTTP=1 when the hosting platform terminates TLS.');
  }
  let signingKeyPem;
  try { signingKeyPem = fs.readFileSync(keyFile, 'utf8'); } catch { throw new Error('RELEASE_SIGNING_KEY_FILE must be the path of a readable PEM file.'); }
  const sampleCorpusDir = env.SAMPLE_CORPUS_DIR || null;
  if (sampleCorpusDir && !(fs.existsSync(sampleCorpusDir) && fs.statSync(sampleCorpusDir).isDirectory())) throw new Error('SAMPLE_CORPUS_DIR must be the path of an existing directory.');
  // The analyzer the core pack is built from (default: the sibling checkout) and its wasm grammars (default: inside it).
  const analyzerDir = env.ANALYZER_DIR || path.resolve(__dirname, '..', '..', 'oasis-analyzer');
  const grammarDir = env.GRAMMAR_DIR || path.join(analyzerDir, 'src', 'ast', 'grammars');
  return {
    port: whole(env, 'PORT', { min: 1, max: 65535, fallback: 4050 }),
    trustProxy: whole(env, 'TRUST_PROXY', { min: 0, max: 10, fallback: 0 }),
    studioDatabaseUrl, rulesDatabaseUrl, packDir, signingKeyPem, signingKeyId,
    sessionHours: whole(env, 'SESSION_HOURS', { min: 1, max: 24, fallback: 8 }),
    secureCookies: tls !== null || env.COOKIE_SECURE !== 'false',
    tls, hsts: tls !== null,
    sampleCorpusDir, analyzerDir, grammarDir,
  };
}

module.exports = { loadStudioConfig };
