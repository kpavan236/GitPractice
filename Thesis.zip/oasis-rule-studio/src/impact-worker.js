'use strict';
// Counts how many sample files a rule would touch. It runs in a worker thread so a pathological regex can be killed from outside.
const fs = require('node:fs');
const path = require('node:path');
const { parentPort, workerData } = require('node:worker_threads');
const { scanContent, compileRule, rulesForPath } = require('oasis-analyzer/src/scanners/pattern-sast');

const MAX_FILES = 20000;
const MAX_BYTES = 1024 * 1024;
const SKIP = new Set(['node_modules', '.git']);

function* walk(root) {
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { continue; }
    for (const e of entries) {
      if (e.isSymbolicLink()) continue;          // never leave the corpus directory
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { if (!SKIP.has(e.name)) stack.push(full); } else if (e.isFile()) yield full;
    }
  }
}

function run({ rule, dir }) {
  const compiled = compileRule({ ...rule, id: rule.id || 'candidate' });
  if (!compiled) return { problem: 'pattern does not compile, or the files glob is missing' };
  let filesScanned = 0;
  let filesMatched = 0;
  let visited = 0;
  for (const file of walk(dir)) {
    if (++visited > MAX_FILES) break;
    const rel = path.relative(dir, file).split(path.sep).join('/');
    if (!rulesForPath([compiled], rel).length) continue;
    let source;
    try { if (fs.statSync(file).size > MAX_BYTES) continue; source = fs.readFileSync(file, 'utf8'); } catch (_) { continue; }
    filesScanned += 1;
    if (scanContent(source, rel, 'repo', [compiled]).length) filesMatched += 1;
  }
  return { filesScanned, filesMatched };
}

parentPort.postMessage(run(workerData));
