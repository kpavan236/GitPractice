'use strict';
const express = require('express');
const { rateLimit } = require('oasis-rule-server');
const { securityHeaders, hstsHeader } = require('./security-headers');
const log = require('./log');
const { authRouter } = require('./auth');

/**
 * The Studio's HTTP surface: sign-in and the Studio API under /v1/studio, GET /healthz (liveness) and GET /readyz (database check), and the UI at / when publicDir is given.
 * Limits: the strict per-address limiter covers sign-in and every path that is not under /v1/studio; the rest of /v1/studio is limited
 * per address BEFORE the session check (a stranger sending well-formed random cookies costs a database lookup each) and per signed-in
 * staff user after it (the live tester fires several calls a minute). `routes` is a router or an array of routers.
 */
function createStudioApp({
  auth, routes = [], trustProxy = 0, pool = null,
  limiter = rateLimit({ max: 60 }),
  preSessionLimiter = rateLimit({ max: 1200 }),
  studioLimiter = rateLimit({ max: 600, key: (req) => req.staff.userId }),
  publicDir = null, hsts = false, logRequests = true,
}) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);
  app.use((_req, res, next) => { res.set('X-Content-Type-Options', 'nosniff'); next(); });
  if (logRequests) app.use(log.requestLog);
  if (hsts) app.use(hstsHeader);
  app.use(securityHeaders);      // before every limiter, so a 429 carries them too
  // The Studio pages (plain HTML and ES modules, no build step). Only publicDir is reachable. Served before the limiters: one page load is about
  // 20 files and must not use up the API's per-minute limit.
  if (publicDir) app.use(express.static(publicDir, { index: 'index.html', dotfiles: 'ignore', etag: true, setHeaders: (res) => res.set('Cache-Control', 'no-cache') }));

  // Liveness: the process answers; no database, no limiter. Readiness (GET /readyz, below) checks the database behind the strict limiter.
  app.get('/healthz', (_req, res) => res.json({ status: 'ok' }));

  const onStudio = (req) => /^\/v1\/studio(?:\/|$)/i.test(req.path);
  app.use((req, res, next) => (onStudio(req) ? next() : limiter(req, res, next)));
  app.get('/readyz', async (_req, res, next) => {
    try { if (pool) await pool.query('SELECT 1'); res.json({ status: 'ok' }); } catch (e) { next(e); }
  });
  // The two import routes parse their own bodies (up to 2 MB) after the session check; everything else is capped at 16kb.
  const small = express.json({ limit: '16kb' });
  app.use('/v1/studio', (req, res, next) => (req.method === 'POST' && (req.path === '/import/preview' || req.path === '/import/commit') ? next() : small(req, res, next)));
  // eslint-disable-next-line no-unused-vars
  app.use('/v1/studio', (err, _req, res, next) => {
    if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'TOO_LARGE' });
    if (err && (err.type === 'entity.parse.failed' || err.type === 'encoding.unsupported' || err.type === 'charset.unsupported')) return res.status(400).json({ error: 'BAD_REQUEST' });
    next(err);
  });
  app.use('/v1/studio', authRouter(auth, { limiter }));
  const list = Array.isArray(routes) ? routes : [routes];
  if (list.length) app.use('/v1/studio', preSessionLimiter, auth.requireSession, studioLimiter, list);

  app.use((_req, res) => res.status(404).json({ error: 'NOT_FOUND' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    log.error({ event: 'unhandled_error', code: err && typeof err.code === 'string' ? err.code : 'error' });
    res.status(500).json({ error: 'INTERNAL' });
  });
  return app;
}

module.exports = { createStudioApp };
