'use strict';
const crypto = require('node:crypto');
const express = require('express');
const { hashPassword, verifyPassword } = require('./password');
const { line } = require('./log');

const COOKIE = 'studio_session';
const TOKEN_SHAPE = /^[A-Za-z0-9_-]{43}$/;      // 32 random bytes, base64url
const MAX_FAILURES = 5;
const WINDOW_MS = 60_000;
const MAX_TRACKED = 50_000;
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const readCookie = (header, name) => { for (const part of String(header || '').split(';')) { const i = part.indexOf('='); if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim(); } return null; };
const normaliseEmail = (email) => String(email).trim().toLowerCase();

/** Compared as bytes, so a non-ASCII value of the same length is a refusal, not an error. */
function sameSecret(sent, want) {
  const a = Buffer.from(String(sent || ''), 'utf8');
  const b = Buffer.from(String(want), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const authError = (code) => Object.assign(new Error(code), { code });

/**
 * Studio staff sign-in. Sessions live in the session table keyed by the sha256 of the cookie token (the token itself is never stored).
 * Failed sign-ins are counted per address hash in this process (a first line of defence; the gateway is the real one) and logged only as that hash.
 */
function createAuth({ pool, secureCookies = true, sessionHours = 8, now = Date.now, log = (m) => console.warn(m) }) {
  const failures = new Map();
  // a hash of nothing anyone knows, at the real cost, so an unknown address takes as long to refuse as a wrong password
  let dummy;
  const dummyHash = () => (dummy ||= hashPassword(crypto.randomBytes(24).toString('base64url')));

  function sweep(t) {
    for (const [k, v] of failures) if (t - v.start >= WINDOW_MS) failures.delete(k);
    while (failures.size > MAX_TRACKED) failures.delete(failures.keys().next().value);
  }

  const permissionsOf = async (role) => (await pool.query('SELECT permission FROM role_permission WHERE role = $1 ORDER BY permission', [role])).rows.map((r) => r.permission);

  async function login(email, password) {
    const address = sha256(normaliseEmail(email)).slice(0, 16);
    const t = now();
    if (failures.size > MAX_TRACKED / 2) sweep(t);
    let entry = failures.get(address);
    if (!entry || t - entry.start >= WINDOW_MS) { entry = { start: t, count: 0 }; failures.set(address, entry); }
    if (entry.count >= MAX_FAILURES) throw Object.assign(authError('TOO_MANY_ATTEMPTS'), { retryAfter: Math.max(1, Math.ceil((entry.start + WINDOW_MS - t) / 1000)) });
    entry.count += 1;      // counted before the slow hash so parallel guesses cannot all slip under the limit; given back on success

    const row = (await pool.query('SELECT user_id, email, password_hash, role, active FROM staff WHERE email = $1', [normaliseEmail(email)])).rows[0];
    const matched = await verifyPassword(String(password), row ? row.password_hash : await dummyHash());
    if (!row || !row.active || !matched) {
      log(line('warn', { event: 'failed_sign_in', id: address }));
      throw authError('INVALID_CREDENTIALS');
    }
    entry.count -= 1;

    const token = crypto.randomBytes(32).toString('base64url');
    const csrf = crypto.randomBytes(32).toString('base64url');
    await pool.query('DELETE FROM session WHERE expires_at <= now()');
    await pool.query("INSERT INTO session (token_hash, user_id, csrf, expires_at) VALUES ($1,$2,$3, now() + make_interval(hours => $4))", [sha256(token), row.user_id, csrf, sessionHours]);
    return { token, csrf, user: { userId: row.user_id, email: row.email, role: row.role, permissions: await permissionsOf(row.role) } };
  }

  async function logout(token) {
    if (typeof token === 'string' && TOKEN_SHAPE.test(token)) await pool.query('DELETE FROM session WHERE token_hash = $1', [sha256(token)]);
  }

  const sessionCookie = (value, maxAgeSeconds) => `${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSeconds}${secureCookies ? '; Secure' : ''}`;

  /** Sets req.staff = {userId, email, role}, req.sessionToken and req.csrf. State-changing methods must also send the session's x-csrf-token. */
  async function requireSession(req, res, next) {
    try {
      const token = readCookie(req.get('Cookie'), COOKIE);
      if (!token || !TOKEN_SHAPE.test(token)) return res.status(401).json({ error: 'UNAUTHENTICATED' });
      const row = (await pool.query(
        'SELECT s.csrf, st.user_id, st.email, st.role FROM session s JOIN staff st ON st.user_id = s.user_id WHERE s.token_hash = $1 AND s.expires_at > now() AND st.active',
        [sha256(token)],
      )).rows[0];
      if (!row) return res.status(401).json({ error: 'UNAUTHENTICATED' });
      if (!SAFE_METHODS.has(req.method) && !sameSecret(req.get('x-csrf-token'), row.csrf)) return res.status(403).json({ error: 'CSRF' });
      req.staff = { userId: row.user_id, email: row.email, role: row.role };
      req.sessionToken = token;
      req.csrf = row.csrf;
      next();
    } catch (e) { next(e); }
  }

  const requirePermission = (code) => async (req, res, next) => {
    try {
      if (!req.staff) return res.status(401).json({ error: 'UNAUTHENTICATED' });
      const { rowCount } = await pool.query('SELECT 1 FROM role_permission WHERE role = $1 AND permission = $2', [req.staff.role, code]);
      if (!rowCount) return res.status(403).json({ error: 'FORBIDDEN' });
      next();
    } catch (e) { next(e); }
  };

  return { login, logout, requireSession, requirePermission, permissionsOf, sessionCookie, sessionHours };
}

/**
 * The three sign-in routes, to be mounted under /v1/studio behind a JSON body parser. The strict `limiter` is applied per route, before the
 * session check, so it holds however the request path is spelled (a mount-level limiter is skipped by /v1/studio//auth/...).
 */
function authRouter(auth, { limiter = (_req, _res, next) => next() } = {}) {
  const router = express.Router();
  const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
  router.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

  router.post('/auth/login', limiter, wrap(async (req, res) => {
    const { email, password } = req.body || {};
    if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) return res.status(400).json({ error: 'BAD_REQUEST' });
    try {
      const { token, csrf, user } = await auth.login(email, password);
      res.set('Set-Cookie', auth.sessionCookie(token, auth.sessionHours * 3600));
      res.json({ email: user.email, role: user.role, permissions: user.permissions, csrf });
    } catch (e) {
      if (e.code === 'TOO_MANY_ATTEMPTS') { res.set('Retry-After', String(e.retryAfter)); return res.status(429).json({ error: 'TOO_MANY_ATTEMPTS' }); }
      if (e.code === 'INVALID_CREDENTIALS') return res.status(401).json({ error: 'INVALID_CREDENTIALS' });
      throw e;
    }
  }));

  router.post('/auth/logout', limiter, auth.requireSession, wrap(async (req, res) => {
    await auth.logout(req.sessionToken);
    res.set('Set-Cookie', auth.sessionCookie('', 0));
    res.json({ ok: true });
  }));

  router.get('/auth/me', limiter, auth.requireSession, wrap(async (req, res) => {
    res.json({ email: req.staff.email, role: req.staff.role, permissions: await auth.permissionsOf(req.staff.role), csrf: req.csrf });
  }));

  // Any other spelling of an auth path (extra slashes, a wrong method) that no route above answered still takes one strict token, then 404s.
  router.use(/^\/+auth(?=\/|$)/i, limiter, (_req, res) => res.status(404).json({ error: 'NOT_FOUND' }));

  return router;
}

module.exports = { createAuth, authRouter };
