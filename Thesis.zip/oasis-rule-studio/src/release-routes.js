'use strict';
const express = require('express');

const CHANNELS = ['beta', 'stable'];
const reasonOk = (v) => typeof v === 'string' && v.trim().length > 0;
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const send = (res, status, error, extra = {}) => res.status(status).json({ error, ...extra });
const releaseNo = (v) => (typeof v === 'string' || typeof v === 'number') && /^[1-9]\d{0,14}$/.test(String(v)) ? Number(v) : null;

/**
 * The Studio release routes (list, diff, build a candidate, publish, roll back), mounted under /v1/studio after requireSession.
 * Thin handlers over the releases repo. The repo's INVALID refusals (stable before beta, retired or unpublished release) are
 * state conflicts here: the request itself is checked first, so by then they are 409.
 */
function createReleaseRoutes({ auth, releases }) {
  const router = express.Router();
  const can = auth.requirePermission;
  const ctx = (req) => ({ actor: String(req.staff.email).toLowerCase(), reason: req.body.reason });
  const needReason = (req, res, next) => (reasonOk(req.body && req.body.reason) ? next() : send(res, 400, 'REASON_REQUIRED', { message: 'a reason is required' }));
  const badNo = (res) => send(res, 400, 'INVALID', { message: 'the release number must be a positive whole number' });
  const badChannel = (res) => send(res, 400, 'INVALID', { message: `channel must be one of ${CHANNELS.join(', ')}` });

  router.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

  router.get('/releases', can('release.read'), wrap(async (_req, res) => res.json(await releases.list())));

  router.get('/releases/:no/diff', can('release.read'), wrap(async (req, res) => {
    const no = releaseNo(req.params.no);
    if (no === null) return badNo(res);
    res.json(await releases.diff(no));
  }));

  router.post('/releases/candidate', can('release.publish'), needReason, wrap(async (req, res) => {
    try {
      const out = await releases.buildCandidate(ctx(req));
      res.status(201).json({
        releaseNo: out.releaseNo,
        summary: { packs: out.manifest.packs.map((p) => p.packId), rules: Object.keys(out.manifest.ruleVersions).length, skippedNoFixture: out.skippedNoFixture },
      });
    } catch (e) {
      if (e && e.code === 'FIXTURE_FAILED') return send(res, 422, 'FIXTURE_FAILED', { message: e.message, failures: e.failures.map((f) => f.ruleId) });
      throw e;
    }
  }));

  router.post('/releases/rollback', can('release.rollback'), needReason, wrap(async (req, res) => {
    const { channel, toReleaseNo } = req.body;
    if (!CHANNELS.includes(channel)) return badChannel(res);
    const no = releaseNo(toReleaseNo);
    if (no === null) return badNo(res);
    res.json(await releases.rollback(channel, no, ctx(req)));
  }));

  router.post('/releases/:no/publish', can('release.publish'), needReason, wrap(async (req, res) => {
    const no = releaseNo(req.params.no);
    if (no === null) return badNo(res);
    if (!CHANNELS.includes(req.body.channel)) return badChannel(res);
    res.json(await releases.publish(no, req.body.channel, ctx(req)));
  }));

  // eslint-disable-next-line no-unused-vars
  router.use((err, _req, res, next) => {
    if (err && err.code === 'NOT_FOUND') return send(res, 404, 'NOT_FOUND', { message: err.message });
    if (err && err.code === 'INVALID') return send(res, 409, 'CONFLICT', { message: err.message });
    next(err);
  });
  return router;
}

module.exports = { createReleaseRoutes };
