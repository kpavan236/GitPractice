'use strict';
const yaml = require('js-yaml');
const { validateRule } = require('oasis-rule-server');

const MAX_TEXT = 2 * 1024 * 1024;
const MAX_RULES = 500;
const TEST_CONCURRENCY = 4;
const bad = (message) => Object.assign(new Error(message), { code: 'BAD_IMPORT' });

/** Parses a JSON or YAML import file (a list of rules, or {rules: [...]}). YAML uses the JSON schema only, so it cannot build anything but plain data. */
function parseImport(format, text) {
  if (format !== 'json' && format !== 'yaml') throw bad('format must be json or yaml');
  if (typeof text !== 'string' || !text.trim()) throw bad('text is required');
  if (text.length > MAX_TEXT) throw bad('the file is larger than 2 MB');
  let data;
  try { data = format === 'json' ? JSON.parse(text) : yaml.load(text, { schema: yaml.JSON_SCHEMA }); }
  catch (e) { throw bad(`the file is not valid ${format.toUpperCase()}${e && e.mark ? ` (line ${e.mark.line + 1})` : ''}`); }
  const rules = Array.isArray(data) ? data : data && Array.isArray(data.rules) ? data.rules : null;
  if (!rules) throw bad('expected a list of rules, or an object with a "rules" list');
  if (rules.length > MAX_RULES) throw bad(`more than ${MAX_RULES} rules in one file`);
  return rules;
}

function serialize(format, rules) {
  return format === 'yaml' ? yaml.dump({ rules }, { schema: yaml.JSON_SCHEMA, noRefs: true, lineWidth: -1 }) : `${JSON.stringify({ rules }, null, 2)}\n`;
}

async function mapLimited(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) { const i = next++; out[i] = await fn(items[i], i); }
  }));
  return out;
}

/**
 * Decides what each rule in the file would do. Nothing is written. A row is `invalid` when the rule fails validation, repeats an id,
 * replaces a seeded rule, or replaces a rule that is not a draft or active; `testOk` is the fixture result for the others.
 * Returns {rows, plan} where plan[i] is the rule body to write (null for invalid rows) with its action.
 */
async function planImport({ format, text, repo, languages, tester }) {
  const rules = parseImport(format, text);
  const known = await languages();
  const seen = new Set();
  const rows = await mapLimited(rules, TEST_CONCURRENCY, async (rule, i) => {
    if (!rule || typeof rule !== 'object' || Array.isArray(rule)) return { row: { id: `#${i + 1}`, action: 'invalid', problem: 'a rule must be an object' } };
    const { status, ...body } = rule;      // lifecycle is never taken from a file
    const id = typeof body.id === 'string' && body.id ? body.id : `#${i + 1}`;
    const problem = validateRule(body, { languages: known });
    if (problem) return { row: { id, action: 'invalid', problem } };
    if (seen.has(id)) return { row: { id, action: 'invalid', problem: `${id}: the id appears twice in the file` } };
    seen.add(id);
    let existing = null;
    try { existing = await repo.get(id); } catch (e) { if (e.code !== 'NOT_FOUND') throw e; }
    if (existing && existing.origin !== 'user') return { row: { id, action: 'invalid', problem: `${id}: a seeded rule cannot be replaced by an import (clone it instead)` } };
    if (existing && existing.status !== 'draft' && existing.status !== 'active') return { row: { id, action: 'invalid', problem: `${id}: a ${existing.status} rule cannot be edited` } };
    const result = await tester(body);
    return { row: { id, action: existing ? 'update' : 'add', testOk: result.ok === true }, body, existing };
  });
  return { rows: rows.map((r) => r.row), items: rows };
}

module.exports = { parseImport, serialize, planImport, MAX_TEXT, MAX_RULES };
