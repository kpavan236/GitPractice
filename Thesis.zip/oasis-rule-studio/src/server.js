'use strict';
const path = require('node:path');
const https = require('node:https');
const log = require('./log');
const { createPool, createRulesRepo, testRule, createReleases, createBlobStore } = require('oasis-rule-server');
const { loadStudioConfig } = require('./config');
const { createAuth } = require('./auth');
const { createStudioRoutes } = require('./routes');
const { createReleaseRoutes } = require('./release-routes');
const { createStudioApp } = require('./app');

/** Builds the whole object graph from the checked config and the two pools; start() and the tests share it. */
function createStudioServices(config, { rulesPool, identityPool }) {
  const blobs = createBlobStore(config.packDir);
  const languages = async () => (await rulesPool.query('SELECT id FROM language ORDER BY id')).rows.map((r) => r.id);
  const repo = createRulesRepo({ pool: rulesPool, languages });
  const releases = createReleases({
    pool: rulesPool, blobs, rules: repo, tester: { testRule },
    sign: { privateKeyPem: config.signingKeyPem, keyId: config.signingKeyId },
    analyzerDir: config.analyzerDir, grammarDir: config.grammarDir,
  });
  const auth = createAuth({ pool: identityPool, secureCookies: config.secureCookies, sessionHours: config.sessionHours });
  const routes = createStudioRoutes({ auth, repo, tester: testRule, pool: rulesPool, sampleCorpusDir: config.sampleCorpusDir });
  const releaseRoutes = createReleaseRoutes({ auth, releases });
  return { blobs, repo, releases, auth, routes, releaseRoutes };
}

// The message names the database, the setting to check and, when the driver gave one, its error code. It never echoes the driver's own
// text: that can carry the host, the user or the whole connection string (which holds the password).
async function check(pool, what) {
  try { await pool.query('SELECT 1'); } catch (err) {
    const setting = what === 'identity database' ? 'STUDIO_DATABASE_URL' : 'RULES_DATABASE_URL';
    throw new Error(`Cannot reach the ${what}${err && err.code ? ` (${err.code})` : ''}. Check ${setting}.`);
  }
}

// deps.createPool is a test seam (spy pools); the default is the library's.
async function start(env = process.env, deps = {}) {
  const config = loadStudioConfig(env);
  const makePool = deps.createPool || createPool;
  const rulesPool = makePool(config.rulesDatabaseUrl);
  const identityPool = makePool(config.studioDatabaseUrl);
  let ended;
  const endPools = () => { ended = ended || Promise.allSettled([rulesPool.end(), identityPool.end()]); return ended; };
  try {
    await check(identityPool, 'identity database');
    await check(rulesPool, 'rules database');
  } catch (err) { await endPools(); throw err; }
  const { auth, routes, releaseRoutes } = createStudioServices(config, { rulesPool, identityPool });
  const app = createStudioApp({ auth, routes: [routes, releaseRoutes], trustProxy: config.trustProxy, hsts: config.hsts, pool: rulesPool, publicDir: path.join(__dirname, '..', 'public') });
  return new Promise((resolve, reject) => {
    const server = config.tls ? https.createServer(config.tls, app).listen(config.port) : app.listen(config.port);
    // Created up front so a signal can never await it before it exists; settles once the server has drained and both pools have ended.
    let stopping = false;
    let finished;
    const shutdown = new Promise((r) => { finished = r; });
    const stop = async () => {
      if (stopping) return;        // a second signal while draining changes nothing
      stopping = true;
      server.close();              // stop accepting; in-flight requests finish first
      server.closeIdleConnections();
      await shutdown;
      process.exit(0);
    };
    server.once('error', async (err) => { await endPools(); reject(err); });
    server.once('close', async () => {
      process.off('SIGTERM', stop);
      process.off('SIGINT', stop);
      await endPools();
      finished();
    });
    server.once('listening', () => {
      log.info({ event: 'listening', port: config.port, tls: Boolean(config.tls) });
      process.on('SIGTERM', stop);
      process.on('SIGINT', stop);
      resolve(server);
    });
  });
}

module.exports = { start, createStudioServices };

if (require.main === module) {
  start().catch((err) => { console.error(err.message); process.exit(1); });
}
