'use strict';
const crypto = require('node:crypto');
const { createPool, createAudit } = require('oasis-rule-server');
const { hashPassword, passwordProblem } = require('./password');

const ROLES = ['author', 'admin'];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Adds a staff member. The password is checked against the policy and stored hashed; it is never logged or audited. */
async function createStaff({ pool, auditPool, email, role, password }) {
  if (!auditPool) throw new Error('auditPool is required.');
  if (!ROLES.includes(role)) throw new Error(`Role must be author or admin.`);
  const address = String(email).trim().toLowerCase();
  if (!EMAIL.test(address)) throw new Error('Enter a valid email address.');
  const problem = passwordProblem(password, address);
  if (problem) throw new Error(problem);
  const userId = crypto.randomUUID();
  const hash = await hashPassword(password);
  try {
    await pool.query('INSERT INTO staff (user_id, email, password_hash, role) VALUES ($1,$2,$3,$4)', [userId, address, hash, role]);
  } catch (e) {
    if (e.code === '23505') throw new Error('A staff member with that email already exists.');
    throw e;
  }
  await createAudit({ pool: auditPool }).record({ actor: 'cli', action: 'staff.create', subject: address, detail: { role } });
  return userId;
}

/** Reads a line from a terminal without echoing it, or the first line of piped input. Never prints what was typed. */
function readSecret(prompt, { stdin = process.stdin, stderr = process.stderr } = {}) {
  return new Promise((resolve, reject) => {
    if (!stdin.isTTY) {
      let data = '';
      stdin.setEncoding('utf8');
      stdin.on('data', (d) => { data += d; });
      stdin.on('end', () => resolve(data.split(/\r?\n/)[0]));
      stdin.on('error', reject);
      return;
    }
    stderr.write(prompt);
    let value = '';
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding('utf8');
    const done = (fn, arg) => { stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData); stderr.write('\n'); fn(arg); };
    function onData(chunk) {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n' || ch === '\u0004') return done(resolve, value);
        if (ch === '\u0003') return done(reject, new Error('Cancelled.'));
        if (ch === '\u007f' || ch === '\b') value = [...value].slice(0, -1).join('');
        else if (ch >= ' ') value += ch;
      }
    }
    stdin.on('data', onData);
  });
}

async function main(argv = process.argv.slice(2), env = process.env) {
  if (argv.length !== 2 || !ROLES.includes(argv[1])) {
    console.error('Usage: npm run create-staff -- <email> <author|admin>\nThe password is asked for on standard input; it is never taken on the command line.');
    return 1;
  }
  if (!env.STUDIO_DATABASE_URL) { console.error('STUDIO_DATABASE_URL is required.'); return 1; }
  if (!env.RULES_DATABASE_URL) { console.error('RULES_DATABASE_URL is required.'); return 1; }
  const password = await readSecret('Password (at least 12 characters, not shown): ');
  if (process.stdin.isTTY) {
    const again = await readSecret('Repeat the password: ');
    if (again !== password) { console.error('The passwords do not match.'); return 1; }
  }
  const identityPool = createPool(env.STUDIO_DATABASE_URL);
  const rulesPool = createPool(env.RULES_DATABASE_URL);
  try {
    await createStaff({ pool: identityPool, auditPool: rulesPool, email: argv[0], role: argv[1], password });
    console.log(`Created ${argv[1]} ${argv[0].trim().toLowerCase()}.`);
    return 0;
  } catch (e) {
    console.error(e.message);
    return 1;
  } finally { await identityPool.end(); await rulesPool.end(); }
}

module.exports = { createStaff, readSecret, main };

if (require.main === module) main().then((code) => process.exit(code), (e) => { console.error(e.message); process.exit(1); });
