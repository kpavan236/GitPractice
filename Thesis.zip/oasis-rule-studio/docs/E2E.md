# Real engine, end to end, on your local stack

What this proves: a release built in the Studio from the REAL analyzer (`oasis-analyzer`) and the rules in `rules_db`, signed with the local
signing key, served by the public rules service, installed by OASIS, and used by a scan (`OASIS_ENGINE=installed`), with the Security > Rules
tab showing it. Local development only. The development key setting is a developer convenience, not the production trust path: the app ignores
it when it runs as a packaged desktop app, and a release trusted through it is labelled "Development key" wherever the release is shown.

The services below are the ones `iready-oasis/tools/oasis-services.sh` already runs: Studio on 4050 (`rules_db`, packs in
`~/.oasis-local-stack/rule-packs`, signing key `~/.oasis-local-stack/rules-release-signing.pem`, key id `dev-1`).
All paths assume the repositories sit side by side under `~/dev/projects/iready`.

## 0. Try it on a throwaway stack first (no effect on your stack)

    cd ~/dev/projects/iready/oasis-rule-studio
    npm run prove-real-engine

It creates its own database and key, builds, serves, installs and compares a scan on the installed engine with one on the bundled engine, then
removes everything it made. `E2E_REPO=/path/to/repo npm run prove-real-engine` scans an existing repository (read only) instead of the generated sample.
It ends with `e2e-real-engine: OK` only when the findings (rule id, file, lines, severity, title, description, CWE) are identical on both engines.

## 1. Check the rules database

The Studio's `rules_db` must hold the schema and active rules. If you have never seeded it:

    cd ~/dev/projects/iready/oasis-rule-server
    export RULES_DATABASE_URL="$(grep '^RULES_DATABASE_URL=' ../oasis-rule-studio/.env | cut -d= -f2- | tr -d "'\"")"
    npm run migrate:central
    npm run seed:central        # safe to repeat; rules edited in Studio are left alone and reported as skippedEdited

(`export ... "$(grep ...)"` keeps the password out of your terminal output.)

One registry fix shipped with this work: the `tsql` language now also lists the `.tsql` extension (`seed/languages.json`), so the client selects
the T-SQL pack for `.tsql` files. To apply it to `rules_db` run `node scripts/seed-languages.js` in `oasis-rule-server` with the same
`RULES_DATABASE_URL`. That script upserts ALL 48 registry rows from the seed file, so any language you changed by hand in the Studio is reset;
if you did, edit `tsql` in the Studio's Languages view instead.

## 2. Build the candidate and promote it to beta

In the Studio (http://127.0.0.1:4050, sign in as an admin): **Releases > Build candidate** (every rule with an example is tested first), then on the new
row **Publish to beta**. Both need a reason. The release is signed with `rules-release-signing.pem` as key `dev-1` and its blobs are written to
`~/.oasis-local-stack/rule-packs`. The candidate lists `core` (the analyzer's `src`, its production dependencies, `package.json`) and one
`lang-<id>` pack per language (rules, `pack.json`, and the `.wasm` grammar for java, javascript, python and typescript).

Without the UI, the same code runs from the command line (same settings as the Studio; reads them from its `.env`, prints no secret):

    cd ~/dev/projects/iready/oasis-rule-studio
    node --env-file=.env scripts/build-release.js --channel beta --actor you@example.test --reason "local e2e"

Use `--channel stable` to also promote it to stable (it goes through beta first).

## 3. Start the public rules service (port 5091)

`oasis-services.sh` does not manage this service yet. Give it only the two settings it reads (never the signing key or the Studio's settings):

    cd ~/dev/projects/iready/oasis-rule-server
    export RULES_DATABASE_URL="$(grep '^RULES_DATABASE_URL=' ../oasis-rule-studio/.env | cut -d= -f2- | tr -d "'\"")"
    export PACK_DIR="$(grep '^PACK_DIR=' ../oasis-rule-studio/.env | cut -d= -f2- | tr -d "'\"")"
    PORT=5091 nohup node src/central-server.js > ~/.oasis-local-stack/logs/central.log 2>&1 &
    echo $! > ~/.oasis-local-stack/central.pid
    sleep 1; curl -s http://127.0.0.1:5091/v1/health            # {"status":"ok"}
    curl -s "http://127.0.0.1:5091/v1/releases/latest?channel=beta" | head -c 200

Stop it later with `kill "$(cat ~/.oasis-local-stack/central.pid)"`. It must read the same `PACK_DIR` the Studio writes.

## 4. Trust the signing key in OASIS (public key only)

OASIS pins no production keys yet, so for development it trusts a public key from a file (`OASIS_DEV_RULES_PUBLIC_KEYS`). Derive the PUBLIC key from
the existing signing key. This reads the private key file but writes and prints only the public half:

    node -e "const c=require('crypto'),fs=require('fs');const [src,dst]=process.argv.slice(1);fs.writeFileSync(dst,JSON.stringify({'dev-1':c.createPublicKey(fs.readFileSync(src)).export({type:'spki',format:'pem'})})+'\n')" \
      ~/.oasis-local-stack/rules-release-signing.pem ~/.oasis-local-stack/dev-rules-public-keys.json
    grep -c PRIVATE ~/.oasis-local-stack/dev-rules-public-keys.json     # must print 0

The key id (`dev-1`) must be the Studio's `RELEASE_SIGNING_KEY_ID`. The loader refuses a file that contains a private key, a key that is not Ed25519,
and an id that is already pinned in `keys.js`.

## 5. Run OASIS on the installed engine

    cd ~/dev/projects/iready/iready-oasis
    OASIS_ENGINE=installed \
    OASIS_RULE_SERVER_URL=http://127.0.0.1:5091 \
    OASIS_DEV_RULES_PUBLIC_KEYS=$HOME/.oasis-local-stack/dev-rules-public-keys.json \
    OASIS_RULES_CHANNEL=beta \
    npm start

- `OASIS_RULES_CHANNEL=beta` because step 2 stopped at beta. Promote to stable in the Studio (Releases > Promote to stable) and leave the variable out to follow stable instead.
- The log shows `DEV rules signing key in use (dev-1): releases are trusted from a local file, not the pinned production keys` once, then `security: rules updated to release-N`.
- The release is installed under `~/.oasis-security/rules` (only that app copy; the Studio's data is untouched). A later release replaces it on the next launch or six-hourly check.
- Node 25 or later (the system Node 26 is fine) enforces "no network" for the engine. A Node without it (Electron 32's Node 20 under `npm run start:desktop`) needs
  `OASIS_ALLOW_OPEN_NETWORK_ENGINE=1`, which accepts a network-open engine. The dev key file is honoured by `electron .` but ignored by a packaged build.

## 6. Verify

1. Open the **Security** tab > **Rules**. The banner reads "Using rules from release N, updated <time>. Development key (dev-1): this release is trusted from a local file, not the pinned production keys." The table lists the rules of the release; changes made there are per-project overrides.
2. Or from a terminal: `curl -s http://127.0.0.1:3000/api/security/rules/installed | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{const v=JSON.parse(s);console.log(v.mode,v.release&&v.release.number,v.release&&v.release.channel,v.devKeys,v.rules.length)})"` should print `installed N beta [ 'dev-1' ] <rule count>`.
3. Run a scan of any repository. In the scan result the rule set reads `release-N` with source `rules-service`, and findings carry `metadata.ruleSetVersion` `release-N`.
4. Change a rule in the Studio, build a candidate, publish to beta, and relaunch OASIS (or wait for the six-hourly check): the banner moves to release N+1.

For a scripted check against this running stack instead of a throwaway one, run the proof driver with the same settings (use a throwaway HOME so
your `~/.oasis-security` is not used):

    cd ~/dev/projects/iready/iready-oasis
    mkdir -p /tmp/oasis-e2e-home
    HOME=/tmp/oasis-e2e-home OASIS_RULE_SERVER_URL=http://127.0.0.1:5091 OASIS_RULES_CHANNEL=beta \
      OASIS_DEV_RULES_PUBLIC_KEYS=$HOME/.oasis-local-stack/dev-rules-public-keys.json node tools/e2e-installed-rules.js

(`$HOME` in the last line is expanded by your shell before the `HOME=` override applies to the command.)

## What can go wrong

| You see | Cause |
|---|---|
| `NO_PINNED_KEYS` in the log or the Rules tab | `OASIS_DEV_RULES_PUBLIC_KEYS` is not set, or the app is packaged (the variable is ignored there; the log says so). |
| `UNKNOWN_KEY` | The file's key id is not the id the release was signed with (`RELEASE_SIGNING_KEY_ID`). |
| `BAD_SIGNATURE` | The file holds the public key of a different key pair than the one the Studio signs with. |
| `DEV_KEY_PRIVATE`, `DEV_KEY_INVALID`, `DEV_KEYS_BAD_FILE`, `DEV_KEY_ID_PINNED` | The key file is wrong; the message says how. |
| The service answers 404 `NOT_FOUND` for `latest` | Nothing is published on that channel yet (step 2), or `OASIS_RULES_CHANNEL` names the other channel. |
| A scan says `NETWORK_DENIAL_UNAVAILABLE` | Node before 25: use Node 25 or later, or set `OASIS_ALLOW_OPEN_NETWORK_ENGINE=1`. |
