# oasis-rule-studio

Rule Studio for the OASIS rules service: staff sign-in, the Studio API (under `/v1/studio`) and the Studio UI (at `/`).
Rule authors and admins use it to write, test, review and release the rules that the OASIS scanner loads.

Design: `iready-oasis/docs/superpowers/specs/2026-10-13-rule-studio-separation-design.md`.

## What it is, and what it is not

- It is the internal, staff-only editing side: sign-in, rule and version management, testing, impact checks, and building and signing releases.
- It is not the public service. The release API that scanners fetch from, and the rules core (rules, versions, releases, audit), stay in the sibling project `oasis-rule-server`. The Studio uses that project as a library (`require('oasis-rule-server')` and `oasis-rule-server/testing`; its `package.json` `exports` blocks every other path).
- It does not replace people. Rule and release changes each carry an actor and a reason and are audited in the rules database. Sign-ins are not audited (failures are logged, never with the password or email). `create-staff` writes a `staff.create` audit row with actor `cli`.

## The two databases

| Database | Setting | Holds |
|---|---|---|
| Identity | `STUDIO_DATABASE_URL` | `staff`, `session`, `role_permission` (permissions are data), `schema_migration` |
| Rules | `RULES_DATABASE_URL` | `language`, `rule`, `rule_version`, `pack`, `release`, `channel`, `audit`, `schema_migration` |

The Studio never queries identity tables through the rules connection or the reverse. The audit rows (rule and release changes, staff creation) go to the rules database. The public service in `oasis-rule-server` connects to the rules database only.

## Settings

Read once at start-up; a missing or malformed required setting stops the process with a message naming it. Copy `.env.example` to `.env` (never commit it). Nothing loads `.env` by itself: `npm start` does NOT read it (export the settings yourself), while `npm run start:local` does (`node --env-file=.env src/server.js`).

| Setting | Required | Default | Meaning |
|---|---|---|---|
| `STUDIO_DATABASE_URL` | yes | none | Identity database connection string. |
| `RULES_DATABASE_URL` | yes | none | Rules database connection string. |
| `PACK_DIR` | yes | none | Folder of pack blobs. Must be the same folder the public service reads (see below). |
| `RELEASE_SIGNING_KEY_FILE` | yes | none | Path of the PEM private key that signs releases. |
| `RELEASE_SIGNING_KEY_ID` | yes | none | Identifier published with the matching public key. |
| `ANALYZER_DIR` | no | sibling `../oasis-analyzer` | The analyzer the core pack is built from. |
| `GRAMMAR_DIR` | no | `<ANALYZER_DIR>/src/ast/grammars` | The analyzer's wasm grammars. |
| `SAMPLE_CORPUS_DIR` | no | unset | Existing directory of sample code for impact checks. |
| `SESSION_HOURS` | no | `8` | Sign-in lifetime, whole hours 1 to 24. |
| `COOKIE_SECURE` | no | `true` | `true` or `false`; `false` only for plain-http local use. |
| `TLS_CERT_FILE` | production (with `TLS_KEY_FILE`) | unset | Path of the PEM certificate chain. Set together with `TLS_KEY_FILE` (one without the other stops start-up); the Studio then serves https itself, forces secure cookies and sends HSTS. |
| `TLS_KEY_FILE` | production (with `TLS_CERT_FILE`) | unset | Path of the PEM private key for that certificate. Never commit it. |
| `ALLOW_PLAIN_HTTP` | no | unset | `1` lets `NODE_ENV=production` start without TLS files. Only for a hosting platform that ends TLS itself; otherwise production without TLS stops start-up. |
| `PORT` | no | `4050` | Listen port. |
| `TRUST_PROXY` | production | `0` | Number of proxies in front of the Studio. Required when `NODE_ENV=production`, otherwise every caller appears to come from the proxy. |

Logs are one JSON line per request (`ts`, `level`, `method`, `path`, `status`, `ms`) plus start-up and error events. They never contain request bodies, query strings, emails or client addresses; a failed sign-in logs only a short hash.

Use throwaway keys and passwords for local work; do not put real credentials in `.env.example`.

## First-time setup

1. `npm install`. The Studio has two `file:` dependencies, so the sibling checkouts `oasis-rule-server` and `oasis-analyzer` must sit next to this folder first.
2. Create the identity database (an empty PostgreSQL database), and have the rules database ready: migrate it from `oasis-rule-server` with `RULES_DATABASE_URL=... npm run migrate:central` (there, not here; this folder's `npm run migrate` only touches the identity database).
3. `npm run migrate` applies `db/identity/*.sql` to `STUDIO_DATABASE_URL`, once each, with checksums.
4. Create the first staff member with both database URLs set:

       STUDIO_DATABASE_URL=... RULES_DATABASE_URL=... npm run create-staff -- you@example.test admin

   The role is `author` or `admin`. The password is asked for on standard input; it is never taken on the command line.
   Creating the staff row (identity database) and its `staff.create` audit row (rules database) are two separate writes in two databases, so they are not atomic: if the second fails after the first succeeded, the staff member exists without an audit row.

## Running

    npm run start:local   # reads .env; http://127.0.0.1:4050/
    npm start             # same server, but does NOT read .env: the settings must already be in the environment

The server binds all interfaces on `PORT`, not only loopback.

Health checks: `GET /healthz` is liveness only: it answers `{"status":"ok"}` while the process runs, needs no database, and sits outside the rate limiter. `GET /readyz` is readiness: it runs `SELECT 1` on the rules database (HTTP 500 `INTERNAL` when that fails) and is behind the strict per-address limiter (60 per minute), so poll `/healthz` from a supervisor and use `/readyz` for a one-off "is it wired up" check.

For local services next to the others, `iready-oasis/tools/oasis-services.sh` manages a `studio` service on port 4050 (it runs the server with this folder's `.env`).

## The same PACK_DIR

The Studio writes pack blobs; the public service serves them. They must see the same `PACK_DIR`. Locally that is one folder. In production it needs shared storage: OPEN ITEM, not solved yet.

## Tests

    npm test         # unit and integration tests; needs the oasis-pg container (port 5433) for the database ones
    npm run smoke    # end to end, see below

`npm run smoke` starts the Studio and the public service as separate processes (the public one gets no Studio or signing setting), signs in, builds and signs a release, checks every served blob against the manifest (hash and size), and runs the OASIS loader's verifier on the result. It uses throwaway databases and a throwaway key.

Prerequisites: the `oasis-pg` container on port 5433 (or `RULES_TEST_DATABASE_URL`), and the sibling checkouts `oasis-rule-server` and `oasis-analyzer`. The loader step needs the `iready-oasis` checkout (`SMOKE_OASIS_DIR` overrides where it is looked for). If it is missing that step is SKIPPED and the last line says so (`smoke: OK (loader verification SKIPPED ...)`), which is not a full pass.

`SMOKE_FAULT=wrong-key`, `tamper-blob`, `truncate-blob` or `no-studio` deliberately breaks one step to prove the script can fail (it must then print `smoke: FAILED:` and exit 1).

`npm run prove-real-engine` is the proof with the REAL engine: on a throwaway database, key and `HOME` it seeds the rules, builds the core pack from `oasis-analyzer` and the language packs (rules and grammars), signs and publishes to beta (`scripts/build-release.js`, which runs the Studio's own release code and is also usable on its own: `npm run build-release -- --channel beta`), serves it with the public service, has the OASIS loader install it, and checks that a scan on the installed engine and one on the bundled engine report identical findings. It removes everything it created. `docs/E2E.md` is the runbook for doing the same on the local stack (`~/.oasis-local-stack`).

## Behaviour carried over unchanged from the original Studio

These rulings moved with the code and must not change silently:

- Editing an active rule returns it to draft.
- Seeded rules only allow changes to severity, pillar and tags.
- Rate limit tiers (per window, 60 / 1200 / 600): 60 per address for sign-in and any path outside the Studio API, 1200 per address before the session check on Studio routes, 600 per signed-in staff member after it.
- Permissions are the rows of `role_permission`; actor strings in the audit are lower-cased emails.
- Strict content security policy: `default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'`.

## Owner follow-ups

1. Create the `oasis-rule-studio` repository and commit (this folder is not a git repository yet).
2. Create the Studio `.env` (from `.env.example`) and the databases first: the identity database, then `npm run migrate`.
3. Then run `tools/oasis-services.sh install` in `iready-oasis`. It restarts all five local services, not only the Studio.

## Open items

- Shared `PACK_DIR` storage in production.
- Confirmation of the project name and the port 4050.
- A read-only database role for the public service is recommended.
