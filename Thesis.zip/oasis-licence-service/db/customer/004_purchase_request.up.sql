-- Customer database, migration 004: purchase requests.
--
-- A person using the OASIS app fills in the Buy form (organization, number of employees, email, contact
-- name). The app sends it to the licence service's API; the service writes this row. The app never touches
-- the database. Support then contacts the person BY EMAIL, and records how it went here.
--
-- A request comes before a customer exists, so it lives beside `customer` rather than inside it. When
-- support agrees a licence they link the request to the customer they create (customer_id), which is a
-- plain foreign key because both tables are in this database.
--
-- Normal forms: the status label lives once in purchase_request_status; the allowed moves live once in
-- purchase_request_status_transition; the history is a separate append-only table; the email's domain and
-- the employee band are derived in the view, not stored beside the values they come from.
--
-- Run after 001 and 002. Safe to run once; 004_purchase_request.down.sql undoes it.

BEGIN;

CREATE TABLE purchase_request_status (
  status_code text PRIMARY KEY,
  label       text NOT NULL,
  sort_order  smallint NOT NULL,
  is_closed   boolean NOT NULL                                                  -- no further work expected
);

CREATE TABLE purchase_request_status_transition (
  from_status_code text NOT NULL REFERENCES purchase_request_status (status_code),
  to_status_code   text NOT NULL REFERENCES purchase_request_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code),
  CHECK (from_status_code <> to_status_code)
);

INSERT INTO purchase_request_status (status_code, label, sort_order, is_closed) VALUES
  ('NEW',       'New',                     1, false),
  ('CONTACTED', 'Support has been in touch', 2, false),
  ('AGREED',    'Licence agreed',          3, true),
  ('DECLINED',  'Not going ahead',         4, true),
  ('DUPLICATE', 'Duplicate of another request', 5, true);

INSERT INTO purchase_request_status_transition (from_status_code, to_status_code) VALUES
  ('NEW', 'CONTACTED'), ('NEW', 'DUPLICATE'), ('NEW', 'DECLINED'),
  ('CONTACTED', 'AGREED'), ('CONTACTED', 'DECLINED'), ('CONTACTED', 'DUPLICATE');

CREATE SEQUENCE purchase_request_number_seq;

CREATE TABLE purchase_request (
  purchase_request_id uuid PRIMARY KEY,
  reference           text NOT NULL UNIQUE
                      DEFAULT 'PR-' || lpad(nextval('purchase_request_number_seq')::text, 6, '0'),   -- what the customer is shown
  idempotency_key     text UNIQUE CHECK (idempotency_key IS NULL OR char_length(idempotency_key) BETWEEN 8 AND 100),
                      -- the app sends one per submit, so a retry after a dropped connection finds the same row
  organization_name   text NOT NULL CHECK (char_length(btrim(organization_name)) BETWEEN 1 AND 200),
  employee_count      integer NOT NULL CHECK (employee_count BETWEEN 1 AND 1000000),
  contact_name        text NOT NULL CHECK (char_length(btrim(contact_name)) BETWEEN 1 AND 150),     -- PII
  email               text NOT NULL CHECK (char_length(email) <= 254 AND email = lower(email)
                                           AND email ~ '^[^@[:space:],;<>]+@[^@[:space:],;<>]+\.[^@[:space:],;<>]{2,}$'),   -- PII; no phone is collected anywhere
  source_code         text NOT NULL DEFAULT 'oasis-app' CHECK (source_code IN ('oasis-app', 'website', 'support')),
  app_version         text CHECK (app_version IS NULL OR char_length(app_version) <= 20),
  status_code         text NOT NULL DEFAULT 'NEW' REFERENCES purchase_request_status (status_code),
  status_changed_at   timestamptz NOT NULL DEFAULT clock_timestamp(),
  assigned_to_user_id uuid,                                                     -- a staff user in the identity service; no cross-database FK
  customer_id         uuid REFERENCES customer (customer_id),                   -- set when support has created the customer
  support_notes       text CHECK (support_notes IS NULL OR char_length(support_notes) <= 4000),
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  row_version         int NOT NULL DEFAULT 1,
  CHECK (customer_id IS NULL OR status_code = 'AGREED')                         -- only an agreed request becomes a customer
);
CREATE INDEX purchase_request_open       ON purchase_request (created_at) WHERE status_code IN ('NEW', 'CONTACTED');
CREATE INDEX purchase_request_email      ON purchase_request (email, created_at);   -- "have we heard from this address?" and the API's rate limit
CREATE INDEX purchase_request_assignee   ON purchase_request (assigned_to_user_id) WHERE assigned_to_user_id IS NOT NULL;
CREATE INDEX purchase_request_customer   ON purchase_request (customer_id) WHERE customer_id IS NOT NULL;

-- Every status a request has had, who moved it and why. Append-only, written by the trigger below.
CREATE TABLE purchase_request_status_history (
  history_id          uuid PRIMARY KEY,
  purchase_request_id uuid NOT NULL REFERENCES purchase_request (purchase_request_id),
  from_status_code    text REFERENCES purchase_request_status (status_code),    -- null for the first status
  to_status_code      text NOT NULL REFERENCES purchase_request_status (status_code),
  changed_at          timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id  uuid,                                                      -- null when the system made it (a new request)
  reason              text CHECK (reason IS NULL OR char_length(reason) <= 500)
);
CREATE INDEX purchase_request_history_request ON purchase_request_status_history (purchase_request_id, changed_at);
CREATE TRIGGER purchase_request_history_append_only BEFORE UPDATE OR DELETE ON purchase_request_status_history
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Same convention as customer: set app.actor_id and app.reason inside the transaction before a status change.
CREATE FUNCTION purchase_request_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM purchase_request_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A purchase request cannot go from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A purchase request status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  -- The submitted details are what the customer asked for: support adds notes and moves the status, nothing else.
  IF NEW.organization_name IS DISTINCT FROM OLD.organization_name OR NEW.employee_count IS DISTINCT FROM OLD.employee_count
     OR NEW.contact_name IS DISTINCT FROM OLD.contact_name OR NEW.email IS DISTINCT FROM OLD.email
     OR NEW.reference IS DISTINCT FROM OLD.reference OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'The details of a submitted purchase request cannot be edited.' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER purchase_request_before_update BEFORE UPDATE ON purchase_request
  FOR EACH ROW EXECUTE FUNCTION purchase_request_before_update();

CREATE FUNCTION purchase_request_write_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO purchase_request_status_history (history_id, purchase_request_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.purchase_request_id,
            CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END,
            NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid,
            CASE WHEN TG_OP = 'INSERT' THEN 'Submitted' ELSE nullif(btrim(current_setting('app.reason', true)), '') END);
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER purchase_request_history_write AFTER INSERT OR UPDATE ON purchase_request
  FOR EACH ROW EXECUTE FUNCTION purchase_request_write_history();

-- What the support team's list shows. Email is the only way to reach the person.
CREATE VIEW v_purchase_request AS
SELECT
  p.purchase_request_id, p.reference,
  p.organization_name, p.employee_count,
  b.label                         AS size_band,
  p.contact_name, p.email,
  split_part(p.email, '@', 2)     AS email_domain,
  s.label                         AS status, s.is_closed,
  p.status_changed_at, p.assigned_to_user_id, p.customer_id,
  p.source_code, p.app_version,
  p.created_at,
  round(extract(epoch FROM (CASE WHEN s.is_closed THEN p.status_changed_at ELSE now() END - p.created_at)) / 3600.0, 1) AS hours_open_or_to_close
FROM purchase_request p
JOIN purchase_request_status s ON s.status_code = p.status_code
LEFT JOIN company_size_band b ON b.size_band_code = CASE
    WHEN p.employee_count <= 10 THEN '1-10' WHEN p.employee_count <= 50 THEN '11-50'
    WHEN p.employee_count <= 200 THEN '51-200' WHEN p.employee_count <= 1000 THEN '201-1000' ELSE '1000+' END;

COMMIT;
