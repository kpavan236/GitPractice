-- Fixed reference data the application relies on. Safe to run more than once.
INSERT INTO customer_status (status_code, label, sort_order) VALUES
  ('PROSPECT', 'Prospect', 1), ('TRIAL', 'Trial', 2), ('ACTIVE', 'Active', 3), ('SUSPENDED', 'Suspended', 4), ('CHURNED', 'Churned', 5)
ON CONFLICT DO NOTHING;

INSERT INTO company_size_band (size_band_code, label, sort_order) VALUES
  ('1-10', '1 to 10 people', 1), ('11-50', '11 to 50 people', 2), ('51-200', '51 to 200 people', 3),
  ('201-1000', '201 to 1,000 people', 4), ('1000+', 'More than 1,000 people', 5)
ON CONFLICT DO NOTHING;

INSERT INTO acquisition_source (source_code, label) VALUES
  ('website', 'Website'), ('sales', 'Sales team'), ('partner', 'Partner'), ('referral', 'Referral'), ('trial', 'Free trial'), ('other', 'Other')
ON CONFLICT DO NOTHING;

INSERT INTO contact_type (contact_type_code, label) VALUES
  ('primary', 'Primary contact'), ('billing', 'Billing contact'), ('support', 'Support contact'), ('technical', 'Technical contact')
ON CONFLICT DO NOTHING;

INSERT INTO address_type (address_type_code, label) VALUES ('legal', 'Legal address'), ('billing', 'Billing address')
ON CONFLICT DO NOTHING;

INSERT INTO industry (industry_code, label) VALUES
  ('software', 'Software and technology'), ('education', 'Education'), ('healthcare', 'Healthcare'), ('finance', 'Finance'),
  ('retail', 'Retail'), ('government', 'Government'), ('manufacturing', 'Manufacturing'), ('other', 'Other')
ON CONFLICT DO NOTHING;

INSERT INTO country_region (region_code, name) VALUES
  ('NA', 'North America'), ('LATAM', 'Latin America'), ('EMEA', 'Europe, Middle East and Africa'), ('APAC', 'Asia Pacific')
ON CONFLICT DO NOTHING;

-- Countries are loaded from the full ISO 3166-1 list by the deployment's import
-- job (INSERT ... ON CONFLICT DO NOTHING). These rows are the minimum the tests
-- and first run need.
INSERT INTO country (country_code, name, region_code) VALUES
  ('US', 'United States', 'NA'), ('CA', 'Canada', 'NA'), ('MX', 'Mexico', 'LATAM'), ('BR', 'Brazil', 'LATAM'),
  ('GB', 'United Kingdom', 'EMEA'), ('DE', 'Germany', 'EMEA'), ('FR', 'France', 'EMEA'),
  ('IN', 'India', 'APAC'), ('AU', 'Australia', 'APAC'), ('SG', 'Singapore', 'APAC')
ON CONFLICT DO NOTHING;
