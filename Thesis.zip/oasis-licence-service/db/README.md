Copies of the schemas this service owns, from `iready-oasis/docs/superpowers/db/` (customer: 001, 002, 004; license: 001, 002; later numbered files are
added here). `npm run migrate` applies them in order, once each, and stops if an applied file has been edited. Change the schema
by adding a new numbered file, never by editing an old one. The sample-data files are deliberately not copied.

`db/setup/` holds one-file-per-database setup scripts (generated from these folders by `npm run db:setup:build`), the database and role
creation script, optional synthetic development data, and a README on running and verifying them.
