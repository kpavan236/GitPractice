-- Fixed reference data the application relies on. Safe to run more than once.
INSERT INTO entitlement_type (entitlement_type_code, label) VALUES
  ('boolean', 'On or off'), ('quantity', 'A count (for example users)'), ('quota', 'A quota per period')
ON CONFLICT DO NOTHING;

INSERT INTO license_kind (kind_code, label) VALUES ('paid', 'Paid'), ('enterprise', 'Enterprise'), ('pilot', 'Pilot') ON CONFLICT DO NOTHING;

INSERT INTO license_status (status_code, label, sort_order) VALUES
  ('DRAFT', 'Draft', 1), ('PENDING_ACTIVATION', 'Pending activation', 2), ('ACTIVE', 'Active', 3),
  ('SUSPENDED', 'Suspended', 4), ('EXPIRED', 'Expired', 5), ('CANCELLED', 'Cancelled', 6)
ON CONFLICT DO NOTHING;

-- The allowed moves. EXPIRED -> ACTIVE (renewing a licence that has lapsed) is an
-- addition to the original diagram; it is one row and easy to remove.
INSERT INTO license_status_transition (from_status_code, to_status_code) VALUES
  ('DRAFT', 'PENDING_ACTIVATION'), ('DRAFT', 'CANCELLED'),
  ('PENDING_ACTIVATION', 'ACTIVE'), ('PENDING_ACTIVATION', 'CANCELLED'),
  ('ACTIVE', 'SUSPENDED'), ('ACTIVE', 'EXPIRED'), ('ACTIVE', 'CANCELLED'),
  ('SUSPENDED', 'ACTIVE'), ('SUSPENDED', 'EXPIRED'), ('SUSPENDED', 'CANCELLED'),
  ('EXPIRED', 'ACTIVE')
ON CONFLICT DO NOTHING;

INSERT INTO trial_status (status_code, label, sort_order) VALUES ('ACTIVE', 'Active', 1), ('EXPIRED', 'Expired', 2), ('CONVERTED', 'Converted to a licence', 3) ON CONFLICT DO NOTHING;
-- A trial that has expired can still be converted: buying after the trial is the main path.
INSERT INTO trial_status_transition (from_status_code, to_status_code) VALUES ('ACTIVE', 'EXPIRED'), ('ACTIVE', 'CONVERTED'), ('EXPIRED', 'CONVERTED') ON CONFLICT DO NOTHING;

INSERT INTO trial_source (source_code, label) VALUES ('oasis-app', 'The OASIS app'), ('web', 'The website') ON CONFLICT DO NOTHING;
INSERT INTO term_source (source_code, label) VALUES ('purchase', 'Purchase'), ('renewal', 'Renewal'), ('manual', 'Entered by hand') ON CONFLICT DO NOTHING;
INSERT INTO seat_release_reason (reason_code, label) VALUES ('user', 'Released by the user'), ('reclaimed', 'Reclaimed after inactivity'), ('revoked', 'Revoked with the licence') ON CONFLICT DO NOTHING;

INSERT INTO fingerprint_source (source_code, label, is_weak) VALUES
  ('darwin', 'macOS hardware id', false), ('win32', 'Windows machine id', false), ('linux', 'Linux machine id', false),
  ('fallback', 'Hostname and home directory', true), ('unknown', 'Not reported', true)
ON CONFLICT DO NOTHING;

INSERT INTO check_in_kind (kind_code, label) VALUES ('trial', 'Trial start'), ('activate', 'Activation'), ('revalidate', 'Revalidation') ON CONFLICT DO NOTHING;

INSERT INTO review_flag (flag_code, label) VALUES
  ('weak_fingerprint', 'The machine id is weak, so the trial may be a repeat'),
  ('many_first_trials_from_one_source', 'Many first trials arrived from one source')
ON CONFLICT DO NOTHING;

-- The two features sold today. Both are on/off.
INSERT INTO feature (feature_code, name, description, entitlement_type_code, limit_unit) VALUES
  ('version-watch', 'Version Watch', 'Dependency and version tracking', 'boolean', NULL),
  ('security', 'Security', 'Security scanning and findings', 'boolean', NULL)
ON CONFLICT DO NOTHING;

-- The plans the app sells today (see server/licensing/tiers.js).
INSERT INTO plan (plan_code, label, default_seat_limit, default_term_days, default_grace_days, offline_allowed) VALUES
  ('trial', 'Trial', 1, 7, 0, false),
  ('viewer', 'Version Viewer', 10, 365, 14, false),
  ('viewer-security', 'Version Viewer + Security', 10, 365, 14, false),
  ('individual', 'Individual', 1, 365, 14, false),
  ('team', 'Team', 10, 365, 14, false),
  ('enterprise', 'Enterprise', NULL, 365, 30, true)
ON CONFLICT DO NOTHING;

-- Enterprise includes every feature. When a feature is added, add its enterprise row.
INSERT INTO plan_feature_default (plan_code, feature_code) VALUES
  ('viewer', 'version-watch'),
  ('viewer-security', 'version-watch'), ('viewer-security', 'security'),
  ('team', 'version-watch'),
  ('enterprise', 'version-watch'), ('enterprise', 'security')
ON CONFLICT DO NOTHING;
