-- Activation support (licence database): the one-time email codes behind "Activate licence", and the block list.
--
-- email_challenge: a code is issued before any user exists, so it is keyed by a HASH of the email address. The address itself and
-- the code itself are never stored: both are HMACs made with a server secret (HASH_PEPPER), so a copy of this table reveals neither.
-- access_block: a flag per machine, per email address or per email domain. Checked on every API call. A block is never deleted:
-- lifting sets lifted_at.
--
-- The plan (docs/plans/2026-10-08-activation-blocking-support-plan.md) puts both in a separate common service. Until that service
-- exists they live here, behind src/otp.js and src/access.js, so moving them out later changes those two modules and nothing else.

BEGIN;

CREATE TABLE email_challenge (
  challenge_id  uuid PRIMARY KEY,
  email_hash    text NOT NULL CHECK (email_hash   ~ '^[0-9a-f]{64}$'),
  machine_hash  text NOT NULL CHECK (machine_hash ~ '^[0-9a-f]{64}$'),
  code_hmac     text NOT NULL CHECK (code_hmac    ~ '^[0-9a-f]{64}$'),
  created_at    timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL,
  attempts      int NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  closed_at     timestamptz,
  closed_reason text CHECK (closed_reason IN ('verified', 'replaced', 'expired')),
  CHECK (expires_at > created_at),
  CHECK ((closed_at IS NULL) = (closed_reason IS NULL))
);
-- One live code per address: asking again replaces it.
CREATE UNIQUE INDEX email_challenge_one_open ON email_challenge (email_hash) WHERE closed_at IS NULL;
CREATE INDEX email_challenge_by_email   ON email_challenge (email_hash, created_at);
CREATE INDEX email_challenge_by_machine ON email_challenge (machine_hash, created_at);

CREATE TABLE block_reason (reason_code text PRIMARY KEY, label text NOT NULL);
INSERT INTO block_reason (reason_code, label) VALUES
  ('abuse', 'Abuse'), ('licence_revoked', 'Licence revoked'), ('payment', 'Payment'), ('security', 'Security'), ('support_request', 'Support request')
ON CONFLICT DO NOTHING;

CREATE TABLE access_block (
  block_id           uuid PRIMARY KEY,
  subject_type       text NOT NULL CHECK (subject_type IN ('machine', 'email', 'email_domain')),
  subject_hash       text NOT NULL CHECK (subject_hash ~ '^[0-9a-f]{64}$'),      -- HMAC; the raw machine id or address is never kept
  reason_code        text NOT NULL REFERENCES block_reason (reason_code),
  note               text CHECK (note IS NULL OR char_length(note) <= 500),       -- internal; never shown to the customer
  blocked_at         timestamptz NOT NULL DEFAULT now(),
  blocked_by_user_id uuid,
  expires_at         timestamptz,
  lifted_at          timestamptz,
  lifted_by_user_id  uuid,
  CHECK (expires_at IS NULL OR expires_at > blocked_at)
);
-- One open block per subject.
CREATE UNIQUE INDEX access_block_one_open ON access_block (subject_type, subject_hash) WHERE lifted_at IS NULL;

-- Blocks are never deleted, and the only change allowed to one is lifting it, once.
CREATE FUNCTION access_block_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'blocks are never deleted; lift them instead' USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.lifted_at IS NOT NULL
     OR (NEW.block_id, NEW.subject_type, NEW.subject_hash, NEW.reason_code, NEW.note, NEW.blocked_at, NEW.blocked_by_user_id, NEW.expires_at)
        IS DISTINCT FROM
        (OLD.block_id, OLD.subject_type, OLD.subject_hash, OLD.reason_code, OLD.note, OLD.blocked_at, OLD.blocked_by_user_id, OLD.expires_at) THEN
    RAISE EXCEPTION 'a block can only be lifted, once' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER access_block_guard BEFORE UPDATE OR DELETE ON access_block FOR EACH ROW EXECUTE FUNCTION access_block_guard();

COMMIT;
