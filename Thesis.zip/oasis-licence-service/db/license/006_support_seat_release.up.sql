-- Licence database, migration 006: a seat released by the support team.
--
-- Support can free one seat on a licence from the support portal (for example a laptop that was lost, or a person who left). That release needs its own reason, separate from
-- "released by the user" (the app), "reclaimed after inactivity" (the service) and "revoked with the licence".
BEGIN;
INSERT INTO seat_release_reason (reason_code, label) VALUES ('support', 'Released by the support team') ON CONFLICT DO NOTHING;
COMMIT;
