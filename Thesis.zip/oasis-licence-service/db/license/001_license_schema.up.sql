-- Licence database (PostgreSQL 16).
--
-- Owns trials, licences, the features and limits each customer is entitled to,
-- which machines hold a seat, and every check-in from an installed copy. Customer
-- details live in the customer database, users in the identity database, invoices
-- in billing: this database points at them with plain ids and NO cross-database FK.
--
-- Normal forms are explained in README.md. Conventions: uuid keys (UUIDv7, made by
-- the application); times are timestamptz (UTC); columns holding personal data are
-- marked -- PII (this database has almost none: no hostnames, usernames or IPs).
-- The outbox/inbox tables for events come from the shared library's migration.
--
-- Needs the btree_gist extension (standard PostgreSQL contrib) for the
-- "no overlapping periods" constraints.

BEGIN;

CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ── Shared helpers ──────────────────────────────────────────────────────────

CREATE FUNCTION touch_row() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  RETURN NEW;
END $$;

CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

CREATE FUNCTION ensure_month_partition(parent regclass, month date) RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  start_d date := date_trunc('month', month)::date;
  end_d   date := (date_trunc('month', month) + interval '1 month')::date;
  part    text := format('%s_%s', parent::text, to_char(start_d, 'YYYY_MM'));
BEGIN
  EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %s FOR VALUES FROM (%L) TO (%L)', part, parent, start_d, end_d);
END $$;

-- ── Reference (lookup) tables ───────────────────────────────────────────────

CREATE TABLE entitlement_type  (entitlement_type_code text PRIMARY KEY, label text NOT NULL);   -- boolean, quantity, quota
CREATE TABLE license_kind      (kind_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE license_status    (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);
CREATE TABLE trial_status      (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);
CREATE TABLE trial_source      (source_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE term_source       (source_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE seat_release_reason (reason_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE fingerprint_source (source_code text PRIMARY KEY, label text NOT NULL, is_weak boolean NOT NULL);
CREATE TABLE check_in_kind     (kind_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE review_flag       (flag_code text PRIMARY KEY, label text NOT NULL);

-- The allowed status moves are DATA, so the state machine is enforced by the
-- database and a new move is an INSERT, not a code change.
CREATE TABLE license_status_transition (
  from_status_code text NOT NULL REFERENCES license_status (status_code),
  to_status_code   text NOT NULL REFERENCES license_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code),
  CHECK (from_status_code <> to_status_code)
);
CREATE TABLE trial_status_transition (
  from_status_code text NOT NULL REFERENCES trial_status (status_code),
  to_status_code   text NOT NULL REFERENCES trial_status (status_code),
  PRIMARY KEY (from_status_code, to_status_code),
  CHECK (from_status_code <> to_status_code)
);

-- ── Catalogue: features and plans ───────────────────────────────────────────
-- Whether a feature is on/off or has a number, and what that number counts, is a
-- fact about the FEATURE, so it is stored once here, not on every entitlement.

CREATE TABLE feature (
  feature_code         text PRIMARY KEY CHECK (feature_code ~ '^[A-Za-z0-9_-]+$'),   -- e.g. version-watch, security
  name                 text NOT NULL,
  description          text,
  entitlement_type_code text NOT NULL REFERENCES entitlement_type (entitlement_type_code),
  limit_unit           text,                                                          -- what a quantity or quota counts: users, days, calls
  status               text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'RETIRED')),
  created_at           timestamptz NOT NULL DEFAULT now(),
  CHECK ((entitlement_type_code = 'boolean') = (limit_unit IS NULL))
);

CREATE TABLE plan (
  plan_code          text PRIMARY KEY CHECK (plan_code ~ '^[a-z0-9-]+$'),
  label              text NOT NULL,
  default_seat_limit int CHECK (default_seat_limit IS NULL OR default_seat_limit > 0),   -- null = uncounted
  default_term_days  int NOT NULL CHECK (default_term_days > 0),
  default_grace_days int NOT NULL DEFAULT 0 CHECK (default_grace_days >= 0),
  offline_allowed    boolean NOT NULL DEFAULT false,
  is_active          boolean NOT NULL DEFAULT true,
  created_at         timestamptz NOT NULL DEFAULT now()
);

-- What a plan includes by default. Copied onto a licence when it is issued, so
-- editing a plan never changes a licence already sold.
CREATE TABLE plan_feature_default (
  plan_code     text NOT NULL REFERENCES plan (plan_code),
  feature_code  text NOT NULL REFERENCES feature (feature_code),
  enabled       boolean NOT NULL DEFAULT true,
  limit_value   numeric CHECK (limit_value IS NULL OR limit_value >= 0),
  PRIMARY KEY (plan_code, feature_code)
);

-- A boolean feature has no number; a counted feature that is switched on must have
-- one. Used by plan defaults and by entitlements.
CREATE FUNCTION limit_matches_feature() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE kind text;
BEGIN
  SELECT entitlement_type_code INTO kind FROM feature WHERE feature_code = NEW.feature_code;
  IF kind = 'boolean' AND NEW.limit_value IS NOT NULL THEN
    RAISE EXCEPTION 'Feature % is on/off and takes no limit.', NEW.feature_code USING ERRCODE = 'check_violation';
  END IF;
  IF kind IS DISTINCT FROM 'boolean' AND NEW.enabled AND NEW.limit_value IS NULL THEN
    RAISE EXCEPTION 'Feature % is counted and needs a limit when switched on.', NEW.feature_code USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER plan_feature_default_limit BEFORE INSERT OR UPDATE ON plan_feature_default FOR EACH ROW EXECUTE FUNCTION limit_matches_feature();

-- ── Installations (a machine running the app) ───────────────────────────────
-- Only facts needed to count seats and plan support: no hostname, username or IP.

CREATE TABLE installation (
  installation_id        uuid PRIMARY KEY,
  fingerprint            text NOT NULL UNIQUE CHECK (char_length(fingerprint) BETWEEN 16 AND 64),
  fingerprint_source_code text NOT NULL DEFAULT 'unknown' REFERENCES fingerprint_source (source_code),
  platform               text CHECK (platform IS NULL OR char_length(platform) <= 20),
  arch                   text CHECK (arch IS NULL OR char_length(arch) <= 20),
  app_version            text CHECK (app_version IS NULL OR char_length(app_version) <= 20),   -- latest reported; set by trigger
  customer_id            uuid,                                                 -- customer database; null until known
  first_seen_at          timestamptz NOT NULL DEFAULT now(),
  last_seen_at           timestamptz NOT NULL DEFAULT now()                    -- set by trigger from check-ins
);
CREATE INDEX installation_customer  ON installation (customer_id);
CREATE INDEX installation_last_seen ON installation (last_seen_at);

-- ── Licences ────────────────────────────────────────────────────────────────

CREATE TABLE license (
  license_id        uuid PRIMARY KEY,
  customer_id       uuid NOT NULL,                                             -- customer database
  plan_code         text NOT NULL REFERENCES plan (plan_code),
  license_key_hash  text NOT NULL UNIQUE CHECK (license_key_hash ~ '^[0-9a-f]{64}$'),   -- the key is shown once, at issue
  key_hint          text NOT NULL CHECK (char_length(key_hint) = 4),
  kind_code         text NOT NULL REFERENCES license_kind (kind_code),
  status_code       text NOT NULL DEFAULT 'DRAFT' REFERENCES license_status (status_code),
  status_changed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  seat_limit        int CHECK (seat_limit IS NULL OR seat_limit > 0),          -- null = uncounted (enterprise only)
  grace_days        int NOT NULL DEFAULT 0 CHECK (grace_days >= 0),            -- terms as sold: copied from the plan, then free to differ
  offline_allowed   boolean NOT NULL DEFAULT false,
  created_by_user_id uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  row_version       int NOT NULL DEFAULT 1,
  CHECK (seat_limit IS NOT NULL OR kind_code = 'enterprise'),
  CHECK (NOT offline_allowed OR kind_code = 'enterprise')
);
CREATE INDEX license_customer ON license (customer_id, status_code);
CREATE INDEX license_by_status ON license (status_code);
CREATE INDEX license_plan     ON license (plan_code);

-- The period a licence covers. This is the ONLY place dates live: a licence's start
-- and expiry are the earliest start and latest end of its terms (see v_license), so
-- they can never disagree with the renewal history.
CREATE TABLE license_term (
  term_id    uuid PRIMARY KEY,
  license_id uuid NOT NULL REFERENCES license (license_id),
  term_no    int NOT NULL CHECK (term_no >= 1),
  starts_at  timestamptz NOT NULL,
  ends_at    timestamptz NOT NULL,
  source_code text NOT NULL REFERENCES term_source (source_code),
  reference  text,                                                             -- PO or invoice number; the invoice itself is in billing
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (license_id, term_no),
  CHECK (ends_at > starts_at),
  EXCLUDE USING gist (license_id WITH =, tstzrange(starts_at, ends_at) WITH &&)       -- terms never overlap
);
CREATE INDEX license_term_expiry ON license_term (license_id, ends_at DESC);
CREATE TRIGGER license_term_append_only BEFORE UPDATE OR DELETE ON license_term FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE license_status_history (
  history_id         uuid PRIMARY KEY,
  license_id         uuid NOT NULL REFERENCES license (license_id),
  from_status_code   text REFERENCES license_status (status_code),
  to_status_code     text NOT NULL REFERENCES license_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,
  reason             text NOT NULL CHECK (char_length(reason) BETWEEN 1 AND 500)    -- every licence change is explained
);
CREATE INDEX license_status_history_license ON license_status_history (license_id, changed_at);
CREATE INDEX license_status_history_to      ON license_status_history (to_status_code, changed_at);
CREATE TRIGGER license_status_history_append_only BEFORE UPDATE OR DELETE ON license_status_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A status move must be an allowed one, must carry a reason (app.reason, set inside
-- the transaction as in the other databases), and a licence cannot be pending or
-- active without at least one term.
CREATE FUNCTION license_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.license_key_hash IS DISTINCT FROM OLD.license_key_hash THEN
    RAISE EXCEPTION 'A licence''s customer and key cannot change.' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM license_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A licence cannot move from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A licence status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.status_code IN ('PENDING_ACTIVATION', 'ACTIVE') AND NOT EXISTS (SELECT 1 FROM license_term WHERE license_id = NEW.license_id) THEN
      RAISE EXCEPTION 'A licence needs at least one term before it can be %.', NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER license_before_update BEFORE UPDATE ON license FOR EACH ROW EXECUTE FUNCTION license_before_update();

CREATE FUNCTION license_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO license_status_history (history_id, license_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.license_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid,
            coalesce(nullif(btrim(current_setting('app.reason', true)), ''), 'Licence created'));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER license_status_history_write AFTER INSERT OR UPDATE ON license FOR EACH ROW EXECUTE FUNCTION license_write_status_history();

-- ── Entitlements: what a licence includes, versioned ────────────────────────
-- Never edited. A change closes the current row (sets effective_until) and inserts a
-- new one, so "what did this customer have on 1 March?" is always answerable. The
-- customer is found through the licence, not copied here.

CREATE TABLE entitlement (
  entitlement_id     uuid PRIMARY KEY,
  license_id         uuid NOT NULL REFERENCES license (license_id),
  feature_code       text NOT NULL REFERENCES feature (feature_code),
  enabled            boolean NOT NULL,
  limit_value        numeric CHECK (limit_value IS NULL OR limit_value >= 0),
  effective_from     timestamptz NOT NULL DEFAULT now(),
  effective_until    timestamptz,
  reason             text NOT NULL CHECK (char_length(btrim(reason)) BETWEEN 1 AND 500),
  created_by_user_id uuid,
  created_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_until IS NULL OR effective_until > effective_from),
  EXCLUDE USING gist (license_id WITH =, feature_code WITH =, tstzrange(effective_from, effective_until) WITH &&)   -- one version at a time
);
CREATE INDEX entitlement_feature ON entitlement (feature_code, effective_from);
CREATE TRIGGER entitlement_limit BEFORE INSERT ON entitlement FOR EACH ROW EXECUTE FUNCTION limit_matches_feature();

-- The only change allowed to an entitlement is closing it, once.
CREATE FUNCTION entitlement_only_close() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'entitlement rows are never deleted; close them instead' USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.effective_until IS NOT NULL
     OR (NEW.entitlement_id, NEW.license_id, NEW.feature_code, NEW.enabled, NEW.limit_value, NEW.effective_from, NEW.reason, NEW.created_by_user_id, NEW.created_at)
        IS DISTINCT FROM
        (OLD.entitlement_id, OLD.license_id, OLD.feature_code, OLD.enabled, OLD.limit_value, OLD.effective_from, OLD.reason, OLD.created_by_user_id, OLD.created_at) THEN
    RAISE EXCEPTION 'an entitlement can only be closed, once; insert a new version instead' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER entitlement_only_close BEFORE UPDATE OR DELETE ON entitlement FOR EACH ROW EXECUTE FUNCTION entitlement_only_close();

-- ── Trials ──────────────────────────────────────────────────────────────────

CREATE TABLE trial (
  trial_id             uuid PRIMARY KEY,
  installation_id      uuid NOT NULL UNIQUE REFERENCES installation (installation_id),   -- one trial per installation, ever
  customer_id          uuid,                                                   -- customer database; null until known
  user_id              uuid,                                                   -- identity database
  started_at           timestamptz NOT NULL DEFAULT now(),
  expires_at           timestamptz NOT NULL,
  extended_until       timestamptz,
  extended_by_user_id  uuid,
  status_code          text NOT NULL DEFAULT 'ACTIVE' REFERENCES trial_status (status_code),
  status_changed_at    timestamptz NOT NULL DEFAULT clock_timestamp(),
  source_code          text NOT NULL DEFAULT 'oasis-app' REFERENCES trial_source (source_code),
  converted_license_id uuid REFERENCES license (license_id),
  converted_at         timestamptz,
  CHECK (expires_at > started_at),
  CHECK (extended_until IS NULL OR extended_until > expires_at),
  CHECK ((extended_until IS NULL) = (extended_by_user_id IS NULL)),
  CHECK ((status_code = 'CONVERTED') = (converted_license_id IS NOT NULL)),
  CHECK ((converted_license_id IS NULL) = (converted_at IS NULL))
);
CREATE INDEX trial_status_expiry ON trial (status_code, expires_at);
CREATE INDEX trial_customer      ON trial (customer_id);

-- The non-secret facts the customer gave when the trial began. There are NO token
-- or password columns, by design: credentials stay on the customer's machine.
CREATE TABLE trial_integration (
  trial_id     uuid PRIMARY KEY REFERENCES trial (trial_id),
  jenkins_url  text CHECK (jenkins_url IS NULL OR jenkins_url ~ '^https?://[^\s]+$'),
  github_url   text CHECK (github_url IS NULL OR github_url ~ '^https?://[^\s]+$'),
  github_org   text CHECK (github_org IS NULL OR github_org ~ '^[A-Za-z0-9][A-Za-z0-9-]{0,38}$'),
  provided_at  timestamptz NOT NULL DEFAULT now()
);

-- Trials the service thinks a person should look at. One row per flag, not a list.
CREATE TABLE trial_review_flag (
  trial_id            uuid NOT NULL REFERENCES trial (trial_id),
  flag_code           text NOT NULL REFERENCES review_flag (flag_code),
  flagged_at          timestamptz NOT NULL DEFAULT now(),
  reviewed_at         timestamptz,
  reviewed_by_user_id uuid,
  review_note         text,
  PRIMARY KEY (trial_id, flag_code),
  CHECK ((reviewed_at IS NULL) = (reviewed_by_user_id IS NULL))
);

CREATE TABLE trial_status_history (
  history_id         uuid PRIMARY KEY,
  trial_id           uuid NOT NULL REFERENCES trial (trial_id),
  from_status_code   text REFERENCES trial_status (status_code),
  to_status_code     text NOT NULL REFERENCES trial_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,
  reason             text CHECK (reason IS NULL OR char_length(reason) <= 500)
);
CREATE INDEX trial_status_history_trial ON trial_status_history (trial_id, changed_at);
CREATE INDEX trial_status_history_to    ON trial_status_history (to_status_code, changed_at);
CREATE TRIGGER trial_status_history_append_only BEFORE UPDATE OR DELETE ON trial_status_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE FUNCTION trial_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.installation_id IS DISTINCT FROM OLD.installation_id OR NEW.started_at IS DISTINCT FROM OLD.started_at THEN
    RAISE EXCEPTION 'A trial''s installation and start time never change.' USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.expires_at IS DISTINCT FROM OLD.expires_at THEN
    RAISE EXCEPTION 'A trial''s original expiry never changes; extend it with extended_until.' USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF NOT EXISTS (SELECT 1 FROM trial_status_transition WHERE from_status_code = OLD.status_code AND to_status_code = NEW.status_code) THEN
      RAISE EXCEPTION 'A trial cannot move from % to %.', OLD.status_code, NEW.status_code USING ERRCODE = 'check_violation';
    END IF;
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A trial status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trial_before_update BEFORE UPDATE ON trial FOR EACH ROW EXECUTE FUNCTION trial_before_update();

CREATE FUNCTION trial_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO trial_status_history (history_id, trial_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.trial_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid, nullif(btrim(current_setting('app.reason', true)), ''));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER trial_status_history_write AFTER INSERT OR UPDATE ON trial FOR EACH ROW EXECUTE FUNCTION trial_write_status_history();

-- ── Seats ───────────────────────────────────────────────────────────────────

CREATE TABLE activation (
  activation_id   uuid PRIMARY KEY,
  license_id      uuid NOT NULL REFERENCES license (license_id),
  installation_id uuid NOT NULL REFERENCES installation (installation_id),
  user_id         uuid,                                                        -- identity database; reserved for named seats later
  activated_at    timestamptz NOT NULL DEFAULT now(),
  last_seen_at    timestamptz NOT NULL DEFAULT now(),                          -- set by trigger from check-ins
  released_at     timestamptz,
  release_reason_code text REFERENCES seat_release_reason (reason_code),
  CHECK ((released_at IS NULL) = (release_reason_code IS NULL)),
  CHECK (released_at IS NULL OR released_at >= activated_at)
);
CREATE UNIQUE INDEX activation_one_open ON activation (license_id, installation_id) WHERE released_at IS NULL;
CREATE INDEX activation_license_open ON activation (license_id) WHERE released_at IS NULL;
CREATE INDEX activation_installation ON activation (installation_id);

-- The seat limit is enforced HERE, not trusted to the application: the licence row
-- is locked, open seats are counted, and a new one is refused when the licence is
-- full. Two machines asking for the last seat at once cannot both get it.
CREATE FUNCTION activation_enforce_seat_limit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE lic record; used int;
BEGIN
  SELECT status_code, seat_limit INTO lic FROM license WHERE license_id = NEW.license_id FOR UPDATE;
  IF lic.status_code IS DISTINCT FROM 'ACTIVE' THEN
    RAISE EXCEPTION 'This licence is not active.' USING ERRCODE = 'check_violation';
  END IF;
  IF lic.seat_limit IS NOT NULL THEN
    SELECT count(*) INTO used FROM activation WHERE license_id = NEW.license_id AND released_at IS NULL;
    IF used >= lic.seat_limit THEN
      RAISE EXCEPTION 'All % seats on this licence are in use.', lic.seat_limit USING ERRCODE = 'check_violation';
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER activation_enforce_seat_limit BEFORE INSERT ON activation FOR EACH ROW EXECUTE FUNCTION activation_enforce_seat_limit();

-- A seat's identity never changes, and a released seat stays released (a returning
-- machine gets a new row, so the history of who held it is complete).
CREATE FUNCTION activation_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'activation rows are never deleted' USING ERRCODE = 'restrict_violation';
  END IF;
  IF (NEW.license_id, NEW.installation_id, NEW.user_id, NEW.activated_at)
     IS DISTINCT FROM (OLD.license_id, OLD.installation_id, OLD.user_id, OLD.activated_at)
     OR (OLD.released_at IS NOT NULL AND (NEW.released_at, NEW.release_reason_code) IS DISTINCT FROM (OLD.released_at, OLD.release_reason_code)) THEN
    RAISE EXCEPTION 'A seat can only be released, once.' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER activation_guard BEFORE UPDATE OR DELETE ON activation FOR EACH ROW EXECUTE FUNCTION activation_guard();

-- ── Check-ins and tokens (large, append-only, monthly partitions) ───────────

CREATE TABLE installation_check_in (
  check_in_id     uuid NOT NULL,
  installation_id uuid NOT NULL REFERENCES installation (installation_id),
  license_id      uuid REFERENCES license (license_id),
  trial_id        uuid REFERENCES trial (trial_id),
  kind_code       text NOT NULL REFERENCES check_in_kind (kind_code),
  app_version     text,
  seen_at         timestamptz NOT NULL,
  PRIMARY KEY (check_in_id, seen_at),
  CHECK ((kind_code = 'trial') = (trial_id IS NOT NULL)),
  CHECK ((kind_code <> 'trial') = (license_id IS NOT NULL))
) PARTITION BY RANGE (seen_at);
CREATE TABLE installation_check_in_default PARTITION OF installation_check_in DEFAULT;
CREATE INDEX installation_check_in_license      ON installation_check_in (license_id, seen_at);
CREATE INDEX installation_check_in_installation ON installation_check_in (installation_id, seen_at);
CREATE TRIGGER installation_check_in_append_only BEFORE UPDATE OR DELETE ON installation_check_in FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Check-ins are purged after 13 months, but "when was this machine last seen" and
-- "which version is it on" must outlive them, so a trigger keeps those up to date.
CREATE FUNCTION check_in_update_state() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  UPDATE installation
     SET app_version = CASE WHEN NEW.seen_at >= last_seen_at THEN coalesce(NEW.app_version, app_version) ELSE app_version END,
         last_seen_at = GREATEST(last_seen_at, NEW.seen_at)
   WHERE installation_id = NEW.installation_id;
  IF NEW.license_id IS NOT NULL THEN
    UPDATE activation SET last_seen_at = GREATEST(last_seen_at, NEW.seen_at)
     WHERE license_id = NEW.license_id AND installation_id = NEW.installation_id AND released_at IS NULL;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER installation_check_in_update_state AFTER INSERT ON installation_check_in FOR EACH ROW EXECUTE FUNCTION check_in_update_state();

CREATE TABLE signing_key (
  kid          text PRIMARY KEY,
  public_pem   text NOT NULL,                                                  -- the private key lives in a KMS or secret store, never here
  status       text NOT NULL CHECK (status IN ('active', 'retiring', 'retired')),
  activates_at timestamptz NOT NULL,
  retires_at   timestamptz,
  CHECK (retires_at IS NULL OR retires_at > activates_at)
);

CREATE TABLE token_issue (
  jti             uuid NOT NULL,
  license_id      uuid REFERENCES license (license_id),
  trial_id        uuid REFERENCES trial (trial_id),
  installation_id uuid NOT NULL REFERENCES installation (installation_id),
  kid             text NOT NULL REFERENCES signing_key (kid),
  issued_at       timestamptz NOT NULL,
  expires_at      timestamptz NOT NULL,
  PRIMARY KEY (jti, issued_at),
  CHECK (expires_at > issued_at),
  CHECK ((license_id IS NULL) <> (trial_id IS NULL))                           -- a token is for a licence or a trial
) PARTITION BY RANGE (issued_at);
CREATE TABLE token_issue_default PARTITION OF token_issue DEFAULT;
CREATE INDEX token_issue_license ON token_issue (license_id, issued_at);
CREATE TRIGGER token_issue_append_only BEFORE UPDATE OR DELETE ON token_issue FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE offline_activation (                                              -- enterprise only
  offline_activation_id uuid PRIMARY KEY,
  license_id      uuid NOT NULL REFERENCES license (license_id),
  installation_id uuid NOT NULL REFERENCES installation (installation_id),
  request_nonce   text NOT NULL,
  issued_at       timestamptz NOT NULL DEFAULT now(),
  expires_at      timestamptz NOT NULL,
  UNIQUE (license_id, installation_id),
  CHECK (expires_at > issued_at)
);

-- ── Seat usage per period (for billing and utilisation) ─────────────────────
-- Built by a scheduled job from check-ins, then locked, so a billed period never
-- changes afterwards. seat_limit is the limit AS IT WAS in that period.

CREATE TABLE license_usage_period (
  usage_period_id        uuid PRIMARY KEY,
  license_id             uuid NOT NULL REFERENCES license (license_id),
  period_start           date NOT NULL,
  period_end             date NOT NULL,
  distinct_installations int NOT NULL CHECK (distinct_installations >= 0),
  distinct_users         int NOT NULL CHECK (distinct_users >= 0),
  seat_limit             int,
  locked_at              timestamptz,
  UNIQUE (license_id, period_start),
  CHECK (period_end >= period_start)
);
CREATE FUNCTION usage_period_locked() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' OR OLD.locked_at IS NOT NULL THEN
    RAISE EXCEPTION 'A locked usage period cannot change.' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER usage_period_locked BEFORE UPDATE OR DELETE ON license_usage_period FOR EACH ROW EXECUTE FUNCTION usage_period_locked();

-- ── Read views ──────────────────────────────────────────────────────────────

-- A licence with its dates (from its terms), plan, and seats in use.
CREATE VIEW v_license AS
SELECT
  l.license_id, l.customer_id, p.label AS plan, k.label AS kind, s.label AS status, l.status_changed_at,
  t.starts_at, t.expires_at,
  (t.expires_at::date - CURRENT_DATE) AS days_to_expiry,
  l.seat_limit,
  (SELECT count(*) FROM activation a WHERE a.license_id = l.license_id AND a.released_at IS NULL) AS seats_in_use,
  l.grace_days, l.offline_allowed, l.key_hint, l.created_at
FROM license l
JOIN plan p ON p.plan_code = l.plan_code
JOIN license_kind k ON k.kind_code = l.kind_code
JOIN license_status s ON s.status_code = l.status_code
LEFT JOIN LATERAL (SELECT min(starts_at) AS starts_at, max(ends_at) AS expires_at FROM license_term WHERE license_id = l.license_id) t ON true;

-- What a licence includes right now.
CREATE VIEW entitlement_current AS
SELECT e.* FROM entitlement e
WHERE e.effective_from <= now() AND (e.effective_until IS NULL OR e.effective_until > now());

-- A trial with its machine, status and open review flags.
CREATE VIEW v_trial AS
SELECT
  t.trial_id, t.customer_id, s.label AS status, t.started_at, t.expires_at, t.extended_until,
  coalesce(t.extended_until, t.expires_at) AS effective_expiry,
  (coalesce(t.extended_until, t.expires_at) <= now()) AS has_ended,
  src.label AS source, i.platform, i.arch, i.app_version, fs.label AS fingerprint_source,
  ti.jenkins_url, ti.github_url, ti.github_org,
  (SELECT count(*) FROM trial_review_flag f WHERE f.trial_id = t.trial_id AND f.reviewed_at IS NULL) AS open_review_flags,
  t.converted_license_id, t.converted_at,
  (t.converted_at::date - t.started_at::date) AS days_to_convert
FROM trial t
JOIN trial_status s ON s.status_code = t.status_code
JOIN trial_source src ON src.source_code = t.source_code
JOIN installation i ON i.installation_id = t.installation_id
JOIN fingerprint_source fs ON fs.source_code = i.fingerprint_source_code
LEFT JOIN trial_integration ti ON ti.trial_id = t.trial_id;

COMMIT;
