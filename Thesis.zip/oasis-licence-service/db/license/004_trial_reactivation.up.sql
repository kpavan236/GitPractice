-- Licence database, migration 004: support may give an ended trial more time.
--
-- Until now a trial could only go ACTIVE -> EXPIRED -> CONVERTED. Extending a trial that has already ended (the usual reason to ask) means
-- moving it back to ACTIVE, with a reason. The database still insists on a reason for every status move and still records who and why in
-- trial_status_history. A CONVERTED trial never moves again.

BEGIN;
INSERT INTO trial_status_transition (from_status_code, to_status_code) VALUES ('EXPIRED', 'ACTIVE') ON CONFLICT DO NOTHING;
COMMIT;
