-- Licence database, migration 005: a block can say which licence it was made for.
--
-- When support revokes a licence and blocks the machines that held its seats, every one of those blocks points back at the licence. That lets
-- support list them, and lift them all at once if the revocation was a mistake. The machine ids themselves are never shown to staff: the
-- blocks hold only keyed hashes (see access_block.subject_hash).

BEGIN;
ALTER TABLE access_block ADD COLUMN license_id uuid REFERENCES license (license_id);
CREATE INDEX access_block_by_licence ON access_block (license_id) WHERE license_id IS NOT NULL;

-- As before, a block is never deleted and the only change allowed is lifting it, once. The new column is part of "what a block is".
CREATE OR REPLACE FUNCTION access_block_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'blocks are never deleted; lift them instead' USING ERRCODE = 'restrict_violation';
  END IF;
  IF OLD.lifted_at IS NOT NULL
     OR (NEW.block_id, NEW.subject_type, NEW.subject_hash, NEW.reason_code, NEW.note, NEW.blocked_at, NEW.blocked_by_user_id, NEW.expires_at, NEW.license_id)
        IS DISTINCT FROM
        (OLD.block_id, OLD.subject_type, OLD.subject_hash, OLD.reason_code, OLD.note, OLD.blocked_at, OLD.blocked_by_user_id, OLD.expires_at, OLD.license_id) THEN
    RAISE EXCEPTION 'a block can only be lifted, once' USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END $$;
COMMIT;
