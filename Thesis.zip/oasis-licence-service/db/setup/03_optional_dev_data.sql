-- ============================================================================
-- DEV ONLY. SYNTHETIC SAMPLE DATA FOR LOCAL DEVELOPMENT. NEVER LOAD INTO A SHARED, STAGING OR PRODUCTION DATABASE.
-- ============================================================================
-- Every name is invented and every address is on example.test (reserved, never delivered). Nothing here is a real person,
-- customer or licence.
--
-- Run AFTER 01 and 02, connected to the maintenance database (it switches to each database itself):
--   psql "postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432/postgres" -v ON_ERROR_STOP=1 -f db/setup/03_optional_dev_data.sql
--
-- Licence key: a licence key is a secret shown once at issue and only its HMAC hash is stored. The hash below is an OBVIOUSLY FAKE
-- value (0123456789abcdef repeated); no key produces it, so this licence cannot be activated with a key. To get a usable licence on a
-- developer machine, run `npm run issue-licence -- --customer 00000000-0000-4000-8000-0000000000c1 --plan team --seats 3 --days 30`
-- (it prints a real key for YOUR local HASH_PEPPER).
--
-- Safe to re-run: every row has a fixed id and is skipped if it exists.

\set ON_ERROR_STOP on

-- ── Customer database ───────────────────────────────────────────────────────
\connect customer_db

BEGIN;
INSERT INTO customer (customer_id, name, legal_name, slug, website, industry_code, size_band_code, country_code, status_code, source_code)
VALUES ('00000000-0000-4000-8000-0000000000c1', 'Example School District (DEV)', 'Example School District Inc.', 'example-school-district-dev',
        'https://www.example.test', 'education', '51-200', 'US', 'ACTIVE', 'sales')
ON CONFLICT DO NOTHING;

-- The fake hash stands in for the domain verification token (never a real token).
INSERT INTO customer_domain (domain_id, customer_id, domain, verification_token_hash, verified_at)
VALUES ('00000000-0000-4000-8000-0000000000d1', '00000000-0000-4000-8000-0000000000c1', 'example.test',
        '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef', now())
ON CONFLICT DO NOTHING;

-- A Buy-form request, status NEW (the status-history trigger records it as "Submitted").
INSERT INTO purchase_request (purchase_request_id, idempotency_key, organization_name, employee_count, contact_name, email, source_code, app_version)
VALUES ('00000000-0000-4000-8000-0000000000e1', 'dev-sample-request-0001', 'Sample Learning Center (DEV)', 25, 'Alex Sample', 'alex.sample@example.test', 'oasis-app', '0.0.0-dev')
ON CONFLICT DO NOTHING;
COMMIT;

-- ── Licence database ────────────────────────────────────────────────────────
\connect license_db

BEGIN;
-- A licence for the customer above (customer_id is a plain id: there is no cross-database foreign key).
INSERT INTO license (license_id, customer_id, plan_code, license_key_hash, key_hint, kind_code, seat_limit, grace_days)
VALUES ('00000000-0000-4000-8000-0000000000a1', '00000000-0000-4000-8000-0000000000c1', 'team',
        '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',   -- FAKE hash: matches no real key
        'FAKE', 'paid', 3, 14)
ON CONFLICT DO NOTHING;

INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code)
VALUES ('00000000-0000-4000-8000-0000000000b1', '00000000-0000-4000-8000-0000000000a1', 1, now(), now() + interval '30 days', 'manual')
ON CONFLICT DO NOTHING;

-- Features copied from the plan, as src/issue-licence.js does.
INSERT INTO entitlement (entitlement_id, license_id, feature_code, enabled, limit_value, reason)
SELECT gen_random_uuid(), '00000000-0000-4000-8000-0000000000a1', feature_code, enabled, limit_value, 'Included in the plan'
  FROM plan_feature_default
 WHERE plan_code = 'team'
   AND NOT EXISTS (SELECT 1 FROM entitlement WHERE license_id = '00000000-0000-4000-8000-0000000000a1');

-- A status change needs a reason (app.reason), set for this transaction only.
SET LOCAL app.reason = 'DEV sample data: ready for activation';
UPDATE license SET status_code = 'PENDING_ACTIVATION'
 WHERE license_id = '00000000-0000-4000-8000-0000000000a1' AND status_code = 'DRAFT';
COMMIT;
