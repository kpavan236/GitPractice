-- OASIS licence service: databases, application role, extensions.
--
-- Run ONCE, as a PostgreSQL administrator (a role that can CREATE DATABASE and CREATE ROLE), connected to the maintenance database:
--   psql "postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432/postgres" -v ON_ERROR_STOP=1 -f db/setup/00_create_databases_and_roles.sql
--
-- Names match .env.example: customer_db and license_db. The licence service is the only thing that writes them.
-- Safe to re-run: existing databases and the role are left as they are.
--
-- SECURITY: the password below is a PLACEHOLDER. Replace it (ALTER ROLE ... PASSWORD) with a value from your secret manager, and
-- never commit the real one. The application role gets data access only: no CREATE, no DROP, not a superuser.

\set ON_ERROR_STOP on

-- Application role (data access only).
SELECT 'CREATE ROLE oasis_licence_app LOGIN PASSWORD ''CHANGE_ME_use_a_secret_manager'' NOSUPERUSER NOCREATEDB NOCREATEROLE'
 WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'oasis_licence_app')
\gexec

-- Databases. CREATE DATABASE cannot run inside a DO block, so it is generated and executed with \gexec.
SELECT 'CREATE DATABASE customer_db ENCODING ''UTF8'''
 WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'customer_db')
\gexec
SELECT 'CREATE DATABASE license_db ENCODING ''UTF8'''
 WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'license_db')
\gexec

-- Nobody but the owner and the application role may connect.
REVOKE ALL ON DATABASE customer_db FROM PUBLIC;
REVOKE ALL ON DATABASE license_db  FROM PUBLIC;
GRANT CONNECT ON DATABASE customer_db TO oasis_licence_app;
GRANT CONNECT ON DATABASE license_db  TO oasis_licence_app;

-- Customer database: default privileges, so tables created later by this administrator (migrations) are usable by the application role.
-- The privileges on the tables that exist are granted at the end of 01_customer_schema_and_seed.sql.
\connect customer_db
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO oasis_licence_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO oasis_licence_app;
-- Required extensions: none. gen_random_uuid() is built into PostgreSQL 13 and later, so pgcrypto is NOT needed.

-- Licence database.
\connect license_db
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO oasis_licence_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO oasis_licence_app;
-- btree_gist (PostgreSQL contrib, a "trusted" extension since version 13) backs the "no overlapping periods" constraints.
-- db/license/001 also runs CREATE EXTENSION IF NOT EXISTS, so this line only makes the requirement visible.
CREATE EXTENSION IF NOT EXISTS btree_gist;
