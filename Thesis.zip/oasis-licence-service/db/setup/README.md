# Database setup (customer and licence databases)

One-time SQL to stand up the two PostgreSQL 16 databases this service owns: `customer_db` and `license_db` (the names in `.env.example`).
Use it for a new local or shared environment. Everything is plain SQL for `psql`; no placeholders below are real credentials.

| File | What it does | Generated? |
|---|---|---|
| `00_create_databases_and_roles.sql` | Creates `customer_db`, `license_db` and the login role `oasis_licence_app` (data access only), connect rights, default privileges, and `btree_gist` | hand-written |
| `01_customer_schema_and_seed.sql` | The whole customer database: db/customer migrations 001, 002, 004 in order, then migration bookkeeping and grants | **generated** |
| `02_license_schema_and_seed.sql` | The whole licence database: db/license migrations 001 to 006 in order, then bookkeeping and grants | **generated** |
| `03_optional_dev_data.sql` | DEV ONLY synthetic rows (example.test addresses, invented names, a fake key hash) | hand-written |

Do not edit 01 or 02. Change `db/customer` or `db/license` (by adding a new numbered file, never by editing an applied one) and run
`npm run db:setup:build`. `node scripts/build-db-setup.js --check` exits 1 if either file is out of date.

## Run

Replace the placeholders. Run as a PostgreSQL administrator, in this order, stopping at the first error (`ON_ERROR_STOP`):

```bash
ADMIN="postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432"

psql "$ADMIN/postgres"    -v ON_ERROR_STOP=1 -f db/setup/00_create_databases_and_roles.sql
psql "$ADMIN/customer_db" -v ON_ERROR_STOP=1 -f db/setup/01_customer_schema_and_seed.sql
psql "$ADMIN/license_db"  -v ON_ERROR_STOP=1 -f db/setup/02_license_schema_and_seed.sql
psql "$ADMIN/postgres"    -v ON_ERROR_STOP=1 -f db/setup/03_optional_dev_data.sql   # optional, development only
```

Then set the application role's password from your secret manager. The file ships a placeholder (`CHANGE_ME_use_a_secret_manager`):

```sql
ALTER ROLE oasis_licence_app PASSWORD '<from your secret manager>';
```

Point the service at the role in `.env`:
`CUSTOMER_DATABASE_URL=postgres://oasis_licence_app:<password>@HOST:5432/customer_db` and the same for `LICENSE_DATABASE_URL` / `license_db`.

Notes:

- Run 01 and 02 against **empty** databases. They are not re-runnable (the migrations create tables without `IF NOT EXISTS`).
- 00 and 03 can be re-run: existing databases, the role and the sample rows are skipped.
- `npm run migrate` and `npm run issue-licence` change schema or write as the URLs you give them. Run `npm run migrate` with an
  administrator or owner URL (it creates tables); the running service only needs the data-access role.
- 01 and 02 end with the same bookkeeping `npm run migrate` does: a `schema_migration` row per file with its SHA-256 checksum. So
  `npm run migrate` afterwards reports "up to date", and applies only migrations added later. If you edit an applied migration file,
  the migrator stops (by design); add a new numbered file instead.
- The final block of 01 and 02 grants the application role its privileges, but only if a role named `oasis_licence_app` exists. If your
  platform creates roles differently, grant `SELECT, INSERT, UPDATE, DELETE` on all tables and `USAGE, SELECT` on all sequences in schema
  `public` to your own role.
- No `pgcrypto`: `gen_random_uuid()` is built into PostgreSQL 13 and later. `btree_gist` is the only extension (licence database).
- `03_optional_dev_data.sql` uses a fake licence key hash that matches no key. Use `npm run issue-licence` for a key that works locally.
  Never load it outside a developer machine.

## Verify

```sql
-- in customer_db
SELECT count(*) AS tables FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE';   -- 22 (incl. schema_migration)
SELECT filename FROM schema_migration ORDER BY filename;     -- 001, 002, 004
SELECT count(*) FROM customer_status;                        -- 5
SELECT count(*) FROM purchase_request_status;                -- 5

-- in license_db
SELECT count(*) AS tables FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE';   -- 39 (incl. schema_migration and the two default partitions)
SELECT filename FROM schema_migration ORDER BY filename;     -- 001 to 006
SELECT plan_code FROM plan ORDER BY plan_code;               -- 6 plans
SELECT extname FROM pg_extension WHERE extname = 'btree_gist';
```

Counts above come from a verified run on PostgreSQL 16 (schema only, without 03). From the repository, `npm run migrate` against the same
URLs should print `customer: up to date` and `license: up to date`.

## Reset (development only)

This destroys all data in both databases. Never run it against a shared or production server.

```bash
psql "$ADMIN/postgres" -c "DROP DATABASE IF EXISTS customer_db WITH (FORCE)" -c "DROP DATABASE IF EXISTS license_db WITH (FORCE)"
# optional: -c "DROP ROLE IF EXISTS oasis_licence_app"
```

Then run the steps in "Run" again. (`npm test` does not use these files: it creates and drops its own throwaway databases.)
