# oasis-licence-service

The cloud licence service for i-Ready OASIS. The OASIS desktop app runs on the user's machine and **never touches a database**: it calls
this service over HTTPS, and this service is the only thing that writes the customer and licence databases.

Contract: `iready-oasis/docs/superpowers/specs/2026-10-08-licence-service-api-contract.md`.

> Not to be confused with `oasis-license-service` (the earlier SQLite build). This one uses the PostgreSQL designs.

## Overview

What it does: starts and resumes the 7-day trial (one per machine), activates a licence (by emailed one-time code for a verified
company domain, or by a support-issued licence key), takes a seat for the machine, keeps licences current (revalidate), frees seats
(deactivate), takes "Buy" requests from the app, and refuses blocked machines, addresses and domains. It signs short-lived tokens
(Ed25519) that the app keeps and presents.

Who calls it:

- **The OASIS desktop app** calls every `/v1` route over HTTPS. It sends a machine id and, where needed, an email address, a code, a licence key or a token.
- **`oasis-support-portal`** (staff) is the other caller. Support routes (purchase-request list, licence issue, blocks for a revoked licence's
  machines) are not in this repo; they live in that portal, which works with the databases this service owns. This service has no HTTP route for staff.
  This README does not document the portal.

## Tech stack

Node.js 22 or later (`engines` in `package.json`), Express 4, `pg` 8 (PostgreSQL 16), `node:test` for tests. Runtime dependencies are only
`express` and `pg` (both MIT). Ed25519 signing, HMAC hashing and UUIDv7 use Node's built-in `crypto`.

## Prerequisites

- Node.js 22 or later and npm.
- PostgreSQL 16 with two empty databases (see "Database" below); the `btree_gist` extension (PostgreSQL contrib, trusted since 13).
- `openssl` (or any tool that makes an Ed25519 private key in PEM form) for a local signing key.
- Docker, only if you want the throwaway PostgreSQL the tests expect on port 5433.

## Quick start

```bash
npm install
docker run -d --name oasis-pg -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16     # local development only
# create the databases: see db/setup/README.md (or let the scripts there do it)
cp .env.example .env            # fill in; never commit .env
openssl genpkey -algorithm ed25519 -out private.pem                                           # dev key; *.pem is git-ignored
export $(grep -v '^#' .env | xargs)
npm run migrate                 # applies db/customer and db/license, once each, with checksums
npm start                       # listens on PORT (default 4020); check http://localhost:4020/readyz
```

In `.env` use placeholders you replace locally, for example `HASH_PEPPER` of at least 32 random characters (`openssl rand -hex 32`),
`LICENCE_SIGNING_KEY_FILE=./private.pem`, and database URLs for your local server. Do not reuse local values anywhere shared.

Issue a licence (until the support routes exist). The customer and its verified email domain must already be in the customer database:

```bash
npm run issue-licence -- --customer <customer uuid> --plan team --seats 10 --days 365
# prints the key ONCE; only its hash is stored. Options: --kind paid|enterprise|pilot, --seats N|none
```

No email provider is approved yet, so codes go to a fake sender. To complete "Activate licence" on a developer machine, start with
`DEV_PRINT_CODES=1` and the code is printed to the terminal. The service refuses to start with it (or the fake sender) when
`NODE_ENV=production`.

In production the signing key comes from a secret store. The service records only the PUBLIC key (table `signing_key`) and refuses to start
if a key id is reused with a different key.

Point the OASIS app at it with `OASIS_LICENSE_URL=https://<host>/v1` (a setting of the OASIS app, not of this service).

## Configuration

Read once at start-up by `src/config.js`; a missing or malformed value stops the service with a clear message. `npm run issue-licence` reads only
`LICENSE_DATABASE_URL` and `HASH_PEPPER`; `npm run migrate` reads both database URLs.

| Variable | Required | Default | Meaning |
|---|---|---|---|
| `PORT` | no | `4020` | HTTP port, whole number 1 to 65535 |
| `CUSTOMER_DATABASE_URL` | yes | none | PostgreSQL URL of the customer database (`customer_db` in the examples) |
| `LICENSE_DATABASE_URL` | yes | none | PostgreSQL URL of the licence database (`license_db`) |
| `LICENCE_SIGNING_KEY_FILE` | yes (or the PEM variable below) | none | Path to the Ed25519 private key (PEM) tokens are signed with. Keep it in a secret store |
| `LICENCE_SIGNING_KEY_PEM` | alternative | none | The same key as PEM text. Read by `src/config.js` but not listed in `.env.example`; takes precedence over the file |
| `LICENCE_SIGNING_KID` | no | `dev` | Key id recorded with the public key; use a new id for a new key |
| `TRIAL_DURATION_DAYS` | no | `7` | Trial length, whole number 1 to 90 |
| `TRUST_PROXY` | no (required when `NODE_ENV=production`) | `0` | Number of proxies in front of the service, 0 to 10, so the caller's address is the real one |
| `HASH_PEPPER` | yes | none | At least 32 random characters. Keys licence keys, email addresses, codes and block-list entries into one-way hashes. If it is lost every stored hash stops matching: back it up with the signing key |
| `NOTIFIER` | no | `fake` | Email sender. Only `fake` exists until a provider is approved (IT Helpdesk, cainc.service-now.com); production refuses it |
| `DEV_PRINT_CODES` | no | `0` | `1` prints each one-time code to the terminal. Development only; refused when `NODE_ENV=production` |
| `EXTRA_BLOCKED_EMAIL_DOMAINS` | no | unset | Comma-separated extra personal-email domains the Buy form refuses, on top of the built-in list (`src/free-email-domains.js`) |
| `SUPPORT_MAILBOX` | no | unset | Address that is told of a new Buy-form request. Unset means no email (the support list still shows every request) |
| `TLS_CERT_FILE` | with `TLS_KEY_FILE` | unset | Path to the TLS certificate (PEM). When both TLS files are set the service serves HTTPS itself (files read at start-up) and sends `Strict-Transport-Security`. Setting only one stops start-up |
| `TLS_KEY_FILE` | with `TLS_CERT_FILE` | unset | Path to the TLS private key (PEM). Keep it in a secret store |
| `ALLOW_PLAIN_HTTP` | no | unset | `1` lets `NODE_ENV=production` start without TLS files. Only for a deployment where the platform terminates TLS before traffic reaches the service; no HSTS header is sent by the service in that case |
| `SHUTDOWN_TIMEOUT_MS` | no | `10000` | On SIGTERM/SIGINT the service stops accepting, lets in-flight requests finish, ends the database pools and exits; after this many milliseconds remaining connections are closed and it exits with code 1 |
| `NODE_ENV` | no | unset | `production` turns on the refusals above (fake sender, `DEV_PRINT_CODES`, missing `TRUST_PROXY`, no TLS files without `ALLOW_PLAIN_HTTP=1`) |
| `TEST_PG_ADMIN_URL` | tests only | `postgres://postgres:local-dev-only@localhost:5433/postgres` | Admin connection the tests use to create and drop throwaway databases |

## Project structure

```
src/
  server.js            start-up: config, pools, signing key, listen, graceful stop
  app.js               builds the Express app; every route and middleware is wired here
  config.js            reads and validates environment settings
  db.js                connection pools and the transaction helper
  migrate.js           applies db/<database>/*.sql with checksums (npm run migrate)
  issue-cli.js         command line for issuing a licence (npm run issue-licence)
  issue-licence.js     creates a licence, its term and entitlements, and returns the key once
  routes/              purchase-request.js, trial.js, domain.js, activation.js (activate, revalidate, deactivate)
  access.js            block list (machine, email address, email domain), checked before every /v1 route
  otp.js               one-time email codes
  licences.js          licence check and seat taking
  trials.js, trial-review.js, entitlement.js, integration.js, machine.js
  token.js, signing-key.js, secrets.js    signed tokens, signing key, keyed hashing
  rate-limit.js, errors.js, forms.js, notifier.js, uuid.js
db/
  customer/            customer database migrations (001, 002, 004)
  license/             licence database migrations (001 to 006)
  setup/               one-time setup SQL and its README (see "Database")
docs/                  fakes.md (what is faked until IT approves it), plans/
scripts/               build-db-setup.js
test/                  node:test suites and helpers (real PostgreSQL)
```

## API endpoints

| Route | What it does | Writes (database: tables) |
|---|---|---|
| `POST /v1/purchase-request/otp` | Buy form, step 1: emails a 6-digit code to a **work** address. Personal providers (Gmail, Yahoo and similar) answer 400 `not_corporate_email` and nothing is sent | license: `email_challenge` |
| `POST /v1/purchase-request/verify` | Buy form, step 2: checks the code and answers `verificationToken`, a keyed hash of address, machine and expiry (30 minutes) | license: `email_challenge` |
| `POST /v1/purchase-request` | The Buy form. **Needs `machineId` and the `verificationToken` for that address and machine** (400 `email_not_verified` otherwise). Validates, rate-limits per email, safe to retry with `Idempotency-Key`; emails the support mailbox (`SUPPORT_MAILBOX`) once for a new request, through the **fake** sender | customer: `purchase_request`, `purchase_request_status_history` |
| `POST /v1/trial` | Starts or resumes the 7-day trial; one per machine; original expiry on repeat; returns a signed token | license: `installation`, `trial`, `trial_integration`, `trial_review_flag`, `installation_check_in`, `token_issue` |
| `POST /v1/domain/otp` | "Activate licence", step 1: emails a 6-digit code to an address whose verified domain has a licence | license: `email_challenge` |
| `POST /v1/domain/activate` | Step 2: the code, then the licence check (revoked, suspended, ended, seats), a seat for the machine, a token | license: `email_challenge`, `installation`, `activation`, `trial` (closed as converted), `installation_check_in`, `token_issue` |
| `POST /v1/activate` | Activate with a support-issued licence key (looked up by hash) | the same as `/domain/activate` |
| `POST /v1/revalidate` | Keeps a licence or trial current; fresh token and grace window; refuses revoked, suspended, ended, not-activated | `installation_check_in`, `token_issue` |
| `POST /v1/deactivate` | Frees this machine's seat; safe to repeat | `activation.released_at` |
| `GET /healthz`, `GET /readyz` | Liveness; readiness (both databases answer) | none |

All routes are mounted in `src/app.js`; there are no others (anything else is 404 `not_found`). Request and response bodies are JSON (16 KB limit).

Every `/v1` route first passes the **block list** (`src/access.js`; blocks for a revoked licence's machines are made from `oasis-support-portal`): a blocked machine, email address or email domain gets 403
`blocked` with one fixed message, whatever the internal note says.

Limits: every `/v1` route except `/revalidate` and `/deactivate` is limited to 60 requests a minute per caller address, in this process (`src/rate-limit.js`; the gateway is meant to be the real limiter). The Buy form also allows 5 requests per email address per hour, and `/domain/otp` three codes per address per fifteen minutes. Responses carry `X-Request-Id`, `X-Content-Type-Options: nosniff` and `Cache-Control: no-store`.

Not built yet (in the contract or the plan): `GET /rules/latest` (the support routes live in `oasis-support-portal`),
the idle-seat reclaim job, offline activation, the monthly partition job, and a gateway. See "Decisions I made" below.

## Scripts

| Command | What it does |
|---|---|
| `npm start` | Runs `src/server.js` (settings from the environment). |
| `npm run start:local` | The same, loading `.env` with `node --env-file=.env`. |
| `npm run migrate` | Applies `db/customer` and `db/license` migrations, once each, recording checksums in `schema_migration` |
| `npm run issue-licence -- --customer <uuid> --plan <plan> ...` | Issues a licence and prints its key once |
| `npm run db:setup:build` | Regenerates `db/setup/01_*.sql` and `02_*.sql` from `db/`; add `--check` (`node scripts/build-db-setup.js --check`) to only verify they are current |
| `npm test` | Runs every `test/**/*.test.js` with `node --test` |

## Testing

```bash
npm test
```

Tests run against **real PostgreSQL** (the rules that matter live in the database). Each run creates two throwaway databases on the
server in `TEST_PG_ADMIN_URL` (default `postgres://postgres:local-dev-only@localhost:5433/postgres`, the local dev container:
`docker run -d -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16`), applies `db/customer` and `db/license` with the migrator, and drops them afterwards.
They do not use `db/setup/`. If PostgreSQL is not reachable the run fails with "Cannot reach PostgreSQL for the tests".

## Database

This service **owns and migrates two PostgreSQL databases**. They point at each other (and at identity and billing) by plain ids only; there
is no cross-database foreign key.

- **Customer database** (`customer_db` in the examples): customers, contacts, addresses, verified email domains, and Buy-form purchase requests
  with their status history. Migrations: `db/customer/`.
- **Licence database** (`license_db`): plans and features, licences with terms and entitlements, installations and seats (activations), trials,
  one-time email challenges, the block list, signing keys (public half only), and check-in and token-issue records (monthly range
  partitions, default partition today). Migrations: `db/license/`.

Two ways to create them:

1. `npm run migrate`: applies the migrations to empty databases, recording each file and its SHA-256 in `schema_migration`.
2. **`db/setup/`**: plain SQL for `psql`. `00_create_databases_and_roles.sql` (databases, a data-access role, `btree_gist`), then
   `01_customer_schema_and_seed.sql` and `02_license_schema_and_seed.sql` (each database in one file, generated from `db/`, with the same
   bookkeeping rows so the migrator sees them as applied), and an optional `03_optional_dev_data.sql` of synthetic, example.test-only rows for local
   development. See `db/setup/README.md` for the run order, verification queries and reset. Never edit the generated files: run
   `npm run db:setup:build`.

Change the schema by adding a new numbered migration file, never by editing an applied one (the migrator stops if it sees a changed file).
Status changes (customer, licence, trial, purchase request) need a reason set for the transaction (`app.reason`), and history tables are append-only; these are enforced by database triggers.

## Security notes

The list under "Rules this code keeps" below is what the code does. In addition:

- Responses never reveal why a caller is blocked: one fixed 403 message.
- `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`, and no `X-Powered-By` header on every response.
- Request bodies are capped at 16 KB; per-address rate limits count an IPv6 caller by its /64. `TRUST_PROXY` must equal the number of proxies in front of the service.
- Tokens are Ed25519-signed; the private key is never stored in the database, only the public key and its id.
- Production refuses to start with the fake email sender, with `DEV_PRINT_CODES=1`, without `TRUST_PROXY`, or without TLS files (unless `ALLOW_PLAIN_HTTP=1`).
- Every response carries `Referrer-Policy: no-referrer`; `Strict-Transport-Security` is added when the service itself serves TLS.
- Keep `.env` and `*.pem` out of git (both are in `.gitignore`). Secrets (`HASH_PEPPER`, the signing key, database passwords) belong in a secret manager; the values in `.env.example` and `db/setup/` are placeholders.
- Data handling: contact name and email on a purchase request are personal data (CA confidential). Use synthetic data in development, and never paste real customer data into tickets, logs or AI tools.

## Decisions I made (open questions in `docs/plans/2026-10-08-activation-blocking-support-plan.md` section 8)

Each is easy to change; none needs a schema change except the first.

1. **Seats count machines**, as the existing schema does (`activation` is one row per machine, enforced by a trigger under a row
   lock). "Distinct users with a cap of machines per user" needs an identity service that does not exist yet.
2. **The one-time code and the block list live in this service** (`email_challenge`, `access_block`, migration 003) behind `src/otp.js`
   and `src/access.js`, instead of a separate common service. The contract's mention of `otp_challenge` in the identity database
   becomes `email_challenge` here, because a code is issued before any user exists. Moving them out later changes those two modules.
3. **A blocked caller is refused (403) on every route**, including `/revalidate` (the app locks) and `/deactivate`. Because the check
   runs in this process, the plan's fail-open/fail-closed question does not arise: if the database is down the answer is 5xx, which the
   app treats as an outage and keeps its grace period.
4. **`/domain/otp` answers 404 `no_domain_licence`** when the domain has none (contract question 1 left as written).
5. **`/revalidate` follows the licence's term, not its grace period.** `graceUntil` in the token is how long the APP may work offline;
   a term that has ended is refused (`expired`). A lapsed licence that has since been renewed works again, and its recorded status is corrected.
6. **Activating converts the machine's trial** (it never refuses because of the trial's state). A converted machine cannot start a trial again.
7. **`GET /rules/latest` is not built.** The contract calls it "unchanged", nothing in the OASIS app calls it, and no body is defined.
   Rule distribution lives in `oasis-rule-server`.
8. **Refused attempts are recorded** as check-ins (kind `activate` or `revalidate`) so support can see them, but never with the
   machine id, address, code or token in a log line.
9. **Blocks by email address or domain act at activation and purchase only.** `/revalidate` and `/deactivate` carry only a machine id, so
   to cut off a customer already seated, block its machines or revoke the licence (which refuses at the next revalidation).
10. **A code is bound to the machine that asked for it**, and a refused activation leaves the code good. There is no per-address
    cooldown beyond three codes per fifteen minutes, so someone can still keep replacing a colleague's code; add a cooldown or a
    gateway rule if that matters.
11. **`/revalidate` and `/deactivate` are not limited per address** (a school behind one address would lock itself out); the other routes are.
    Production refuses to start unless `TRUST_PROXY` is set.
12. **Known limits, not fixed:** a customer with two current licences is tried against one only (the newest current one); `/revalidate`
    treats a token signed by a retired key as a refusal; the machine limit on codes is not serialised, so a burst can slightly exceed ten.
13. **Idle-seat reclaim is not built**: the threshold (plan section 8, question 4) is still open.

## Faked until IT approves them

The email sender is a fake (codes and the support-mailbox notice are kept in memory, never delivered). Every flow works and is tested; production
refuses to start with the fake. **`docs/fakes.md` lists each fake, its swap point and what the real one must do.**

## Rules this code keeps

- Time, expiry and status come from the database clock; nothing the app sends can move them.
- A business refusal is 4xx. Anything unexpected is 500 with a generic message, so the app treats it as an outage.
- Logs hold method, path, status, time and a request id. **Never** a body, email, machine id, token, code or caller address.
- Licence keys, email addresses, one-time codes and block-list machine ids are stored only as HMAC-SHA-256 hashes made with `HASH_PEPPER` (never in the database).
- The one-time code goes to the sender and nowhere else: not a response, not a log, not the database.
- The licence row is locked while a seat is taken or a token is issued, so two machines cannot take the last seat together.
- Personal data stored: contact name and email on a purchase request. Email addresses for activation are stored only as hashes. No phone, hostname, username or IP anywhere.
- Credentials never arrive in setup addresses: they are rebuilt from scheme, host and path only.

## Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| `X is required.` at start | A required variable is missing (see Configuration). `export $(grep -v '^#' .env | xargs)` loads `.env` into the shell; the service does not read `.env` itself |
| `HASH_PEPPER must be at least 32 characters.` | Use a longer random value, for example `openssl rand -hex 32` |
| `The signing key must be an Ed25519 key.` / key file error | Generate one with `openssl genpkey -algorithm ed25519 -out private.pem` and check `LICENCE_SIGNING_KEY_FILE` |
| `Signing key "dev" is already recorded with a different public key.` | The database already holds a different key under that id. Set a new `LICENCE_SIGNING_KID`, or use the original key |
| `NOTIFIER must be "fake"` | No email provider is approved yet; leave `NOTIFIER=fake` (new services go through the IT Helpdesk, cainc.service-now.com) |
| Service refuses to start in production | Production needs `TRUST_PROXY` set, no `DEV_PRINT_CODES`, and (not yet possible) a real email sender; see `docs/fakes.md` |
| `<file> was applied and has since changed.` | An applied migration was edited. Restore it and add a new numbered migration instead |
| `/readyz` returns 503 | One of the two databases does not answer; check both URLs and that the role may connect |
| "Cannot reach PostgreSQL for the tests" | Start the dev container (see Testing) or set `TEST_PG_ADMIN_URL` |
| A status change fails with "needs a reason" | Set `app.reason` in the same transaction before changing a status (`SELECT set_config('app.reason', '<why>', true)`) |
| `/domain/otp` answers 404 `no_domain_licence` | The email's domain has no verified customer domain with a licence in the databases |
| A one-time code never arrives | Nothing is delivered yet (fake sender). Start with `DEV_PRINT_CODES=1` on a developer machine |
| 429 `too_many_requests` | A per-address limit (see API endpoints); wait for `retryAfterSeconds` |

## Before this goes anywhere real

- `db/` holds **copies** of the schemas from `iready-oasis/docs/superpowers/db/`. Pick one home for them before the first deployment.
- TLS, a gateway rate limiter, deployment, an owner, CI with scanning, and CA review of customer-facing messages.
- Email to the support mailbox needs a provider approved through the IT Helpdesk (cainc.service-now.com).
- Partitions: `installation_check_in` and `token_issue` use their default partition until a monthly job creates the others.
- Dependencies: `express` and `pg` (both MIT).
- `email_challenge` rows are never purged yet; add a retention job (the plan says retention is still to be set).

## Email (SMTP) placeholder

Email sending is not implemented. `NOTIFIER=fake` is the only accepted value, and production refuses it until a provider is approved (IT Helpdesk, cainc.service-now.com). `.env.example` reserves the names `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD` and `SMTP_FROM`, commented out and blank. Nothing reads them yet. The owner configures SMTP later; real values belong in the untracked `.env` or a secret store, never in the repository.
