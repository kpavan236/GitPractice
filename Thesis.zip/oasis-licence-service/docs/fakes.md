# Faked integrations (waiting on the IT Helpdesk)

Anything that needs a new external service is **faked** until IT approves it (cainc.service-now.com, IT Helpdesk first). A fake does the
whole job in memory, so every flow works and is tested; going live means writing the real implementation behind the same interface.
Nothing else in the code changes.

| Integration | Interface (the swap point) | What the fake does | What the real one must do |
|---|---|---|---|
| **Email sender** | `src/notifier.js`: `send({ to, code, expiresInMinutes })` and `notifySupport({ to, reference, organization, employees, contactName, email })` | Keeps each message in memory (last 1,000) for tests. `DEV_PRINT_CODES=1` prints the one-time code, and only the reference of a support notice, to the terminal. | Deliver the email. Reject (throw) on failure: both callers already treat a failure correctly (see below). Use CA-reviewed wording. |

## Where the fake is wired, and the rules the real one inherits

- `src/server.js` builds the notifier from `NOTIFIER` (only `fake` is accepted today). The real provider adds a value there and a class beside the fake.
- **Production refuses the fake.** `src/config.js` stops the service in production with `NOTIFIER=fake` and with `DEV_PRINT_CODES=1`, so a fake can never be
  deployed by accident. Remove the first check only when a real sender exists.
- **One-time codes** (`/v1/domain/otp`): the code goes to the sender and nowhere else, never a response or a log. A send failure answers 500, so the app treats it as an
  outage. The real sender must not log the message body.
- **Buy-form codes** (`/v1/purchase-request/otp`): the same sender and the same rules as above, with `purpose: 'purchase'` in the message so the real sender can word it for a purchase, not an activation. The wording needs CA employee review.
- **Support notice** (`POST /v1/purchase-request`): sent once, after the request is stored, only for a new request (never a replay, a refusal or a rate-limited call).
  A failure is logged (reference only) and **never** fails the request: the support list shows every request either way. The notice holds a customer's name and
  email address (CA confidential, PII): the real sender must send it only to `SUPPORT_MAILBOX` and keep it out of logs and analytics.
- The email text (the code email, the support notice) needs **CA employee review** before release.

## Fakes this service does NOT need yet

Payments (deferred, no provider), a secret store or KMS for the signing key (the key is read from `LICENCE_SIGNING_KEY_FILE` / `LICENCE_SIGNING_KEY_PEM`; in production it must come from
the secret store IT approves), and a message broker (none is used).
