# Activation, seat limits, blocking, feedback and support: plan

Status: plan only, for review. Implementation comes later. Date: 2026-10-08.
Lives outside `iready-oasis`: none of this is built in the OASIS app repository.

Builds on: `iready-oasis/docs/superpowers/specs/2026-10-08-licence-service-api-contract.md` (the contract) and the first slice in this repo
(`POST /v1/trial`, `POST /v1/purchase-request`).

## 1. Answers to your three questions (about what exists today)

**Do we store the machine details when the user starts the trial?** Yes. The app calls `POST /v1/trial` when setup finishes, which is after
the GitHub and Jenkins details have been validated on the user's machine. The service then writes, in one transaction:
`installation` (machine id, where the id came from, platform, architecture, app version, first and last seen), `trial` (start and expiry from the
database clock), `trial_integration` (the Jenkins and GitHub addresses and organization name, never tokens), `trial_review_flag`,
`installation_check_in` and `token_issue`. No hostname, username or IP address is stored.

**Do we check validity and machine details before starting the trial?** Partly.

| Check | Today |
|---|---|
| Machine id well-formed (16 to 64 safe characters) | Yes |
| One trial per machine; a returning machine gets its ORIGINAL expiry | Yes |
| Trial still valid; if over, refuse with `trial_ended` and mark it expired | Yes |
| Trial already converted to a licence, so "activate instead" | Yes |
| The GitHub/Jenkins tokens are valid | Only on the user's machine, before the call. The service never sees the tokens, by design |
| Weak machine id or many first trials from one address | Flagged for a person, not refused |
| **A block on this machine or user** | **No. This is new work (section 4)** |

When the trial is over the app already shows the lock screen with **Activate licence** and **Buy a licence**.

**Activating a licence** is not built in this repo yet. The dev stand-in in `iready-oasis` has a simplified version, and this plan builds the real one.

## 2. Rules you gave, as requirements

| # | Rule | Where it is delivered |
|---|---|---|
| R1 | First trial start: after valid tokens and the app opens, store the machine details | Done (`/v1/trial`) |
| R2 | Same machine again: validate machine details and trial validity, then proceed | Done; extended with the block check (T4) |
| R3 | Trial over: show Buy or Activate | App already does; the service answers `trial_ended` |
| R4 | Activating a licence: do **not** validate the machine, only the licence expiry | T3 |
| R5 | Licence for N users: only N may activate; check expiry and the active count; clear messages | T3 |
| R6 | A flag per user and per machine to block API calls, checked on **every** API call | T4 |
| R7 | APIs for feedback and "contact support", stored in the database | T6 |
| R8 | Common APIs combined in one service; separate services for the rest; nothing in `iready-oasis` | Section 3 |

Two interpretations to confirm are in section 8 (what "users" means for the count, and what "do not validate the machine" covers).

## 3. Services

All new code goes in separate repositories next to `iready-oasis`. The OASIS app keeps one base URL (`OASIS_LICENSE_URL`); a gateway
routes `/v1/...` to the right service so the app never learns the split.

| Service (repository) | Owns | Routes the app can call |
|---|---|---|
| **oasis-common-service** | Email one-time codes, notifications (email sending), the **block flags and the access check**, the audit trail | `POST /v1/email-code`, `POST /v1/email-code/verify` |
| **oasis-licence-service-cloud** (exists) | Trials, licences, seats, installations, token issuing | `/v1/trial`, `/v1/domain/activate`, `/v1/activate`, `/v1/revalidate`, `/v1/deactivate`, `/v1/rules/latest` |
| **oasis-customer-service** (new) | Customers, domains, contacts, purchase requests | `/v1/purchase-request` |
| **oasis-support-service** (new) | Feedback and contact-support messages | `/v1/feedback`, `/v1/support-request` |
| **oasis-api-gateway** (new, thin) | TLS entry, routing, per-address rate limit, request ids, calls the access check for every request | none of its own |

Rules between services:
- A service **never reads another service's database.** It calls the other service's internal API. Internal routes live under `/internal/...`, are
  not routed by the gateway, and need a service-to-service credential (a short-lived signed token).
- `purchase-request` moves from this repository to the customer service (it writes the customer database). This repository keeps trials and licences.
- Each service has its own repository, tests against real PostgreSQL, migrations, README, health and readiness routes, and the same logging rule
  (never a body, email, machine id, token or code).
- The common service exposes a small client library (`@oasis/common-client`) so every service calls the access check and the audit trail the same way.
  It is published privately, never copied between repositories (the first slice copied `forms.js` and the schemas; that stops here).

## 4. Blocking: one flag, checked on every call (R6)

**Table** (common service database `access_db`):

`access_block(block_id, subject_type ('machine' | 'user' | 'email_domain'), subject_key, reason_code, note, blocked_at, blocked_by_user_id, expires_at NULL, lifted_at NULL, lifted_by_user_id NULL)`
- `subject_key` for a machine is the **hash** of the machine id (never the raw id); for a user it is the user id; for a domain it is the domain.
- One open block per subject (partial unique index). Blocks are never deleted: lifting sets `lifted_at`. Every block and lift writes an audit row and needs a reason.
- Reason codes (lookup table): `abuse`, `licence_revoked`, `payment`, `security`, `support_request`. The customer sees a fixed message per code, never the internal note.

**The check** (`POST /internal/access/check`, called by the gateway before routing and by each service as a second line):
input: machine hash, user id or email if known, domain if known. Output: `{allowed: true}` or `{allowed: false, reason}`.
- Answered from a short in-memory cache (seconds) so a block takes effect within moments and the check adds almost no delay.
- If the common service is unreachable the gateway **fails open for read-only token refresh** (so an outage never locks every customer out) and **fails closed for new activations, trials and purchase requests**. This is the one place the "outage must not lock customers out" rule has a deliberate exception, and it needs your sign-off.
- Refusal to the app: HTTP 403 with `reason: "blocked"` and the fixed message ("This machine can't use the licence. Contact support."). The app locks and shows Contact support.
- Per-user flag also reflects in the identity data: a disabled user (`app_user.status = DISABLED`) is treated as blocked.

**Test gate:** every route registered in every service must appear in a test that sends a request from a blocked machine and from a blocked user and expects 403. A route added without that test fails CI (the same idea as the tenant-isolation harness in the platform plan).

## 5. Activation by email (the routes you asked for next)

Flow: user enters a work email, gets a six-digit code, enters it, and the licence is checked.

### Routes (contract section "Routes the app calls", unchanged)
`POST /v1/domain/otp` and `POST /v1/domain/activate` as written in the contract. Internally:

1. **`/domain/otp`** (gateway then licence service):
   1. Validate the email and machine id; access check on machine and domain.
   2. Ask the customer service whether the domain has a licensed customer (`GET /internal/domains/{domain}`), then the licence service's own table for a licence whose status is `ACTIVE` or in its grace period.
   3. None: 404 `no_domain_licence` (open question Q1 in the contract: whether to answer the same either way).
   4. Ask the common service to send a code (`POST /internal/email-code`), which applies the limits (3 per address and 10 per machine per 15 minutes).
2. **`/domain/activate`**:
   1. Ask the common service to verify the code (`POST /internal/email-code/verify`): wrong code with attempts left, no code, expired, too many attempts.
   2. On success the common service finds or creates the **user** for that email (identity data) and returns the user id. The user is created **only after the code is verified**, so typing someone's address creates nothing.
   3. Validate the licence (section 6) and take a seat (section 6). Issue the token.

### Where the one-time code lives
The identity schema's `otp_challenge` is keyed by `user_id`, which does not exist yet at request time. Plan: a new `email_challenge` table in the common service
(email hash, HMAC of the code with a server pepper, expiry, attempts, closed reason) so a code can be issued before any user exists. The code is stored only as an HMAC and never logged.
The existing `otp_challenge` stays for later sign-in to the customer portal.

### Sending email
A notification provider interface with a **fake** that records messages for tests. The real sender needs an email provider approved through the IT Helpdesk
(cainc.service-now.com) and CA review of the email text. Until then no real email is sent, and the development setup prints the code in the fake's output only.

## 6. Validating the licence and counting seats (R4, R5)

"Validate the licence, not the machine" means: when activating, the service does **not** require a trial or a prior machine record, and does not compare the machine against history.
It still records the machine (needed to count seats) and still applies the machine and user block checks (section 4).

**Checks, in this order, each with its own message** (messages need CA employee review):

| Order | Check | Refusal |
|---|---|---|
| 1 | Access check (machine, user, domain) | 403 `blocked` |
| 2 | Licence exists for the domain | 404 `no_domain_licence` |
| 3 | Licence not revoked, suspended or cancelled | 403 `revoked` / `suspended` |
| 4 | Licence term not over (`ends_at` > database clock; grace period honoured only for `/revalidate`, not for new activations) | 403 `expired`, with the expiry date |
| 5 | Seat available, or this machine already holds one | 403 `seats_full`: "All 50 seats on this licence are in use. Ask your administrator to free one." |

- **Already seated machine activating again** gets a fresh token and consumes no extra seat.
- **Seat limit** `license.seat_limit` (null means uncounted, for enterprise). It is already enforced inside the database with a row lock
  (`SELECT ... FOR UPDATE` trigger on `activation`), so two machines cannot take the last seat together. The route only turns the database refusal into the message above.
- A seat is freed by `/deactivate`, by support (revoke), or by the inactivity reclaim job (planned: 90 days without a check-in; threshold to be confirmed).
- Every refusal and every success writes `installation_check_in` and an audit row, with no email or machine id in logs.

## 7. Feedback and contact support (R7)

**Routes** (support service): both are anonymous-capable (the user may not be licensed) and carry the same protections as the Buy form: validation, per-address
rate limit, `Idempotency-Key`, access check, no bodies in logs.

| Route | Body | Result |
|---|---|---|
| `POST /v1/feedback` | `category` (`bug`, `idea`, `praise`, `other`), `message` (1 to 4,000), optional `email`, optional `rating` (1 to 5), `appVersion`, optional `screen` (which tab) | `{ok, reference: "FB-000123"}` |
| `POST /v1/support-request` | `subject` (1 to 150), `message` (1 to 4,000), `email` (required, the only way to reply), `contactName` (1 to 150), `appVersion`; machine id optional | `{ok, reference: "SR-000123"}` |

**Tables** (support service database `support_db`), normalised like the others:
- `feedback_category`, `request_status` (`NEW`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`) and their allowed-moves table.
- `feedback(feedback_id, reference UNIQUE, idempotency_key UNIQUE, category_code, rating, message, email NULL, app_version, screen, installation_ref NULL, created_at)`: append-only; support adds notes elsewhere.
- `support_request(support_request_id, reference UNIQUE, idempotency_key UNIQUE, subject, message, contact_name, email, app_version, installation_ref NULL, status_code, assigned_to_user_id, customer_ref NULL, created_at, ...)` plus `support_request_status_history` (append-only, reason required), `support_note`.
- Views `v_support_request` and `v_feedback` for the support team's list (their screens are later work).
- Personal data: email, name, free text (may contain anything). Flagged PII; the free text is never logged; retention period to be set; an export/delete path for a person's own data is planned.
- Contact is **by email only**; no phone field anywhere.

Support gets notified of a new request by email through the common service's notification interface (fake until the provider is approved).

## 8. Decisions I need from you before building

1. **"Users" versus machines for the 50 limit.** The agreed design (earlier) counts **machines (installations)** as seats. You wrote "50 users". If one person can use two machines, do they take two seats? Recommended: count **distinct users** (verified email addresses) with at most N, and cap machines per user (default 3) so one account cannot be shared by many machines. This changes `activation` to link a user. Confirm.
2. **Fail open or closed** when the common service cannot answer the access check (section 4). Recommended: open for token refresh, closed for new activations.
3. **Service split.** Is the five-part split in section 3 what you want (common, licence, customer, support, gateway), or should customer and support be one service?
4. **Reclaim threshold** for idle seats (section 6): 90 days?
5. **Open question Q1 in the contract:** whether `/domain/otp` should answer the same whether or not the domain has a licence.
6. **Who can block**, and does a block need a second person's approval? Recommended: Support proposes, Platform Admin applies (as in the platform plan).

## 9. Tasks and order

Each task ends with an independently testable result, uses real PostgreSQL in tests, and gets its own detailed step-by-step plan when it starts.

| Task | Repository | Result | Depends on |
|---|---|---|---|
| T1 | oasis-common-service (new) | Scaffold, config, logging, migrations, health; `email_challenge`; the fake notification sender; `/internal/email-code` and `/verify` with limits | none |
| T2 | oasis-common-service | `access_block`, `/internal/access/check`, block and lift (internal), audit trail, `@oasis/common-client` | T1 |
| T3 | oasis-licence-service-cloud | `/v1/domain/otp`, `/v1/domain/activate`, `/v1/activate`, `/v1/revalidate`, `/v1/deactivate`; seat counting and messages; licence lookup by domain | T1, T2, customer service domain lookup |
| T4 | oasis-licence-service-cloud | Access check on `/v1/trial` and every other route; the "blocked machine/user on every route" test harness | T2 |
| T5 | oasis-customer-service (new) | Move `purchase-request` here; `GET /internal/domains/{domain}`; contacts | T2 |
| T6 | oasis-support-service (new) | `support_db`, `/v1/feedback`, `/v1/support-request`, notifications | T1, T2 |
| T7 | oasis-api-gateway (new) | Routing, TLS, rate limit, access check on every request, request ids | T2 to T6 |
| T8 | iready-oasis (app, minimal) | Add a "Contact support" and "Send feedback" form calling the new routes; show the `blocked` message; send `Idempotency-Key`. This is the only change in the app repository, and only the client side | T6, T7 |
| T9 | all | Contract updated; end-to-end test through the gateway; security review; CA review of messages; deployment, secrets, monitoring and backup drills | all |

## 10. Cross-cutting rules (apply to every task)

- The app never connects to a database; it only calls APIs (stored as a standing project rule).
- Time, expiry, status and seat counts come from the server; nothing the app sends can change them.
- 4xx only for business refusals; 5xx for our faults; the app treats 5xx as "unavailable". The one deliberate exception is the fail-closed rule in section 4, pending your decision.
- No secrets, codes, tokens, bodies, emails or machine ids in logs or error messages. Machine ids are stored hashed where a block list is concerned.
- Data classification: customer names and emails and revenue data are CA confidential PII; use invented data in tests and docs (`.example.test`).
- Customer-facing messages and emails need CA employee review; AI-assisted code goes through the standard review, CI and scanning.
- New email or other external services go through the IT Helpdesk (cainc.service-now.com) first.

## 11. What is explicitly not in this plan

The support team's screens, payment processing, the customer portal sign-in, reporting, and the license-key box (removed from the app on purpose).
