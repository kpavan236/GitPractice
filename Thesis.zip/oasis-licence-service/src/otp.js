'use strict';
const crypto = require('node:crypto');
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { safeEqualHex } = require('./secrets');

const TTL_MINUTES = 10;
const WINDOW_MINUTES = 15;
const MAX_ATTEMPTS = 5;
const MAX_PER_ADDRESS = 3;
const MAX_PER_MACHINE = 10;

const maskEmail = e => e.replace(/^(.)[^@]*(@.*)$/, '$1***$2');

/**
 * One-time email codes for "Activate licence": six digits, valid ten minutes, five tries, one live code per address (asking again
 * replaces it). At most three requests per address and ten per machine per fifteen minutes. The address and the code are stored
 * only as keyed hashes, and the code goes to the notifier and nowhere else: not to a log, not into a response.
 */
function createOtp({ licenseDb, hash, notifier, randomCode = () => String(crypto.randomInt(0, 1_000_000)).padStart(6, '0') }) {
  const codeHmac = (emailHash, code) => hash('code', `${emailHash}:${code}`);

  async function request({ email, machineId, purpose = 'activation' }) {
    const emailHash = hash('email', email), machineHash = hash('machine', machineId);
    const code = randomCode();

    await tx(licenseDb, async db => {
      // Two requests for the same address at once must not both pass the limit.
      await db.query('SELECT pg_advisory_xact_lock(hashtext($1))', [emailHash]);
      for (const [column, value, limit] of [['email_hash', emailHash, MAX_PER_ADDRESS], ['machine_hash', machineHash, MAX_PER_MACHINE]]) {
        const { rows } = await db.query(
          `SELECT count(*)::int AS n, EXTRACT(EPOCH FROM (min(created_at) + make_interval(mins => $2) - now()))::int AS wait
             FROM email_challenge WHERE ${column} = $1 AND created_at > now() - make_interval(mins => $2)`, [value, WINDOW_MINUTES]);
        if (rows[0].n >= limit) {
          const retryAfterSeconds = Math.max(1, rows[0].wait);
          const mins = Math.ceil(retryAfterSeconds / 60);
          throw refuse(`Too many codes have been requested. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`, 'too_many_requests', { retryAfterSeconds }, 429);
        }
      }
      await db.query(`UPDATE email_challenge SET closed_at = now(), closed_reason = 'replaced' WHERE email_hash = $1 AND closed_at IS NULL`, [emailHash]);
      await db.query(
        `INSERT INTO email_challenge (challenge_id, email_hash, machine_hash, code_hmac, expires_at) VALUES ($1, $2, $3, $4, now() + make_interval(mins => $5))`,
        [uuidv7(), emailHash, machineHash, codeHmac(emailHash, code), TTL_MINUTES]);
    });

    await notifier.send({ to: email, code, expiresInMinutes: TTL_MINUTES, purpose });
    return { ok: true, sentTo: maskEmail(email), expiresInMinutes: TTL_MINUTES };
  }

  /**
   * Checks a code. A wrong guess is counted even though the caller is refused, so the count is committed first and the refusal
   * thrown afterwards. A right code is used up.
   */
  async function verify({ email, code, machineId, consume = true }) {
    const emailHash = hash('email', email), machineHash = hash('machine', machineId);
    const given = typeof code === 'string' ? code.trim() : '';
    const outcome = await tx(licenseDb, async db => {
      const { rows } = await db.query(
        `SELECT challenge_id, code_hmac, machine_hash, attempts, (expires_at <= now()) AS expired FROM email_challenge WHERE email_hash = $1 AND closed_at IS NULL FOR UPDATE`, [emailHash]);
      if (!rows.length) return { reason: 'no_code' };
      const c = rows[0];
      // Only the machine that asked can use the code, so someone elsewhere cannot burn its five tries.
      if (!safeEqualHex(c.machine_hash, machineHash)) return { reason: 'no_code' };
      if (c.expired) {
        await db.query(`UPDATE email_challenge SET closed_at = now(), closed_reason = 'expired' WHERE challenge_id = $1`, [c.challenge_id]);
        return { reason: 'expired' };
      }
      if (c.attempts >= MAX_ATTEMPTS) return { reason: 'too_many_attempts' };
      if (/^\d{6}$/.test(given) && safeEqualHex(codeHmac(emailHash, given), c.code_hmac)) {
        if (consume) await db.query(`UPDATE email_challenge SET closed_at = now(), closed_reason = 'verified' WHERE challenge_id = $1`, [c.challenge_id]);
        return { ok: true };
      }
      await db.query('UPDATE email_challenge SET attempts = attempts + 1 WHERE challenge_id = $1', [c.challenge_id]);
      const left = MAX_ATTEMPTS - (c.attempts + 1);
      return left > 0 ? { reason: 'wrong_code', left } : { reason: 'too_many_attempts' };
    });
    if (outcome.ok) return;

    const say = {
      no_code: 'There is no code waiting for this address. Ask for a new one.',
      expired: 'That code has expired. Ask for a new one.',
      too_many_attempts: 'Too many wrong codes. Ask for a new one.',
      wrong_code: `That code is not right. ${outcome.left} ${outcome.left === 1 ? 'try' : 'tries'} left.`,
    };
    throw refuse(say[outcome.reason], outcome.reason);
  }

  /** Uses a code up, once the thing it was for has succeeded. (A refused activation leaves the code good, so the person need not start again.) */
  async function consume({ email }) {
    await licenseDb.query(`UPDATE email_challenge SET closed_at = now(), closed_reason = 'verified' WHERE email_hash = $1 AND closed_at IS NULL`, [hash('email', email)]);
  }

  return { request, verify, consume };
}

module.exports = { createOtp, maskEmail, MAX_ATTEMPTS };
