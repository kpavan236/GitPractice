'use strict';
const { uuidv7 } = require('./uuid');

const MACHINE_ID = /^[A-Za-z0-9_-]{16,64}$/;
const FINGERPRINT_SOURCES = new Set(['darwin', 'win32', 'linux', 'fallback', 'unknown']);
const short = (v, max) => (typeof v === 'string' && /^[0-9A-Za-z._+-]{1,20}$/.test(v) ? v.slice(0, max) : null);

/** The machine details a request may carry, tidied. A missing or malformed optional field becomes null, never an error. */
function machineDetails(body) {
  return {
    fingerprintSource: FINGERPRINT_SOURCES.has(body.fingerprintSource) ? body.fingerprintSource : 'unknown',
    platform: short(body.platform, 20), arch: short(body.arch, 20), appVersion: short(body.appVersion, 20),
  };
}

/** Finds the installation for a machine id, or records it. Safe when two requests for a new machine arrive together. */
async function upsertInstallation(db, machineId, { fingerprintSource, platform, arch, appVersion }) {
  const { rows } = await db.query(
    `INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code, platform, arch, app_version)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (fingerprint) DO UPDATE SET platform = coalesce(EXCLUDED.platform, installation.platform),
       arch = coalesce(EXCLUDED.arch, installation.arch), app_version = coalesce(EXCLUDED.app_version, installation.app_version)
     RETURNING installation_id`,
    [uuidv7(), machineId, fingerprintSource, platform, arch, appVersion]
  );
  return rows[0].installation_id;
}

module.exports = { MACHINE_ID, machineDetails, upsertInstallation };
