'use strict';
const fs = require('node:fs');
const { normaliseEmail } = require('./forms');

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Both TLS files or neither. Read once at start-up so a bad path stops the service rather than the first request. */
function loadTls(env) {
  const certFile = env.TLS_CERT_FILE, keyFile = env.TLS_KEY_FILE;
  if (!certFile && !keyFile) return null;
  if (!certFile) throw new Error('TLS_KEY_FILE is set but TLS_CERT_FILE is not; set both or neither.');
  if (!keyFile) throw new Error('TLS_CERT_FILE is set but TLS_KEY_FILE is not; set both or neither.');
  const read = (name, file) => { try { return fs.readFileSync(file); } catch (e) { throw new Error(`${name} could not be read (${e.code || 'error'}).`); } };
  return { cert: read('TLS_CERT_FILE', certFile), key: read('TLS_KEY_FILE', keyFile) };
}

/** Reads and checks the settings once, at start-up. A missing or malformed setting stops the service with a clear message. */
function loadConfig(env = process.env) {
  const need = name => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  const keyFile = env.LICENCE_SIGNING_KEY_FILE;
  const signingKeyPem = env.LICENCE_SIGNING_KEY_PEM || (keyFile ? fs.readFileSync(keyFile, 'utf8') : null);
  if (!signingKeyPem) throw new Error('LICENCE_SIGNING_KEY_FILE (or LICENCE_SIGNING_KEY_PEM) is required.');
  const hashPepper = need('HASH_PEPPER');
  if (hashPepper.length < 32) throw new Error('HASH_PEPPER must be at least 32 characters.');
  if (env.NODE_ENV === 'production' && (env.TRUST_PROXY === undefined || env.TRUST_PROXY === '')) throw new Error('TRUST_PROXY must be set in production (the number of proxies in front of the service; 0 if none), or every customer appears to come from the proxy\'s address.');
  const tls = loadTls(env);
  const allowPlainHttp = env.ALLOW_PLAIN_HTTP === '1';
  if (env.NODE_ENV === 'production' && !tls && !allowPlainHttp) throw new Error('Production needs TLS: set TLS_CERT_FILE and TLS_KEY_FILE, or set ALLOW_PLAIN_HTTP=1 only where the platform terminates TLS before traffic reaches this service.');
  const notifier = env.NOTIFIER || 'fake';
  if (notifier !== 'fake') throw new Error('NOTIFIER must be "fake": no email provider has been approved yet (IT Helpdesk, cainc.service-now.com).');
  const printCodes = env.DEV_PRINT_CODES === '1';
  if (notifier === 'fake' && env.NODE_ENV === 'production') throw new Error('Production needs an approved email sender; the fake one would never deliver a code.');
  if (printCodes && env.NODE_ENV === 'production') throw new Error('DEV_PRINT_CODES must not be set in production: a one-time code must not reach a log.');
  // Where a new Buy-form request is announced. Optional: unset means no email (the support list still shows every request).
  let supportMailbox = null;
  if (env.SUPPORT_MAILBOX) {
    supportMailbox = normaliseEmail(env.SUPPORT_MAILBOX);
    if (!supportMailbox) throw new Error('SUPPORT_MAILBOX must be one email address.');
  }
  // Extra personal-email domains the Buy form refuses, on top of the built-in list. Optional, comma separated.
  const blockedEmailDomains = (env.EXTRA_BLOCKED_EMAIL_DOMAINS || '').split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
  return {
    hashPepper, supportMailbox, blockedEmailDomains, tls, allowPlainHttp,
    shutdownTimeoutMs: whole(env, 'SHUTDOWN_TIMEOUT_MS', { min: 1, max: 600_000, fallback: 10_000 }), notifier, printCodes,
    port: whole(env, 'PORT', { min: 1, max: 65535, fallback: 4020 }),
    customerDatabaseUrl: need('CUSTOMER_DATABASE_URL'),
    licenseDatabaseUrl: need('LICENSE_DATABASE_URL'),
    signingKeyPem,
    signingKid: env.LICENCE_SIGNING_KID || 'dev',
    trialDays: whole(env, 'TRIAL_DURATION_DAYS', { min: 1, max: 90, fallback: 7 }),
    trustProxy: whole(env, 'TRUST_PROXY', { min: 0, max: 10, fallback: 0 }),
  };
}

module.exports = { loadConfig };
