'use strict';
const crypto = require('node:crypto');

// Decides whether a NEW trial deserves a human look. It never refuses one: a lab of machines behind one address is not an
// attack. The caller's address is held only as a salted hash that exists in this process, only until its window passes, and
// is never written anywhere, so an address cannot be recovered from this service or matched against an earlier run.

const WEAK_FINGERPRINT = 'weak_fingerprint';
const MANY_FROM_ONE_SOURCE = 'many_first_trials_from_one_source';

function createTrialReviewer({ now = Date.now, windowMs = 24 * 60 * 60 * 1000, maxPerSource = 3 } = {}) {
  const salt = crypto.randomBytes(16);
  const seen = new Map();
  const keyFor = source => crypto.createHash('sha256').update(salt).update(String(source || '')).digest('hex').slice(0, 24);

  function review({ source, fingerprintSource } = {}) {
    const t = now();
    for (const [key, stamps] of seen) {
      const kept = stamps.filter(s => t - s < windowMs);
      if (kept.length) seen.set(key, kept); else seen.delete(key);
    }
    const reasons = [];
    if (!fingerprintSource || fingerprintSource === 'fallback' || fingerprintSource === 'unknown') reasons.push(WEAK_FINGERPRINT);
    const key = keyFor(source);
    const stamps = seen.get(key) || [];
    if (stamps.length >= maxPerSource) reasons.push(MANY_FROM_ONE_SOURCE);
    seen.set(key, [...stamps, t]);
    return { flagged: reasons.length > 0, reasons };
  }
  return { review, heldKeys: () => [...seen.keys()] };
}

module.exports = { createTrialReviewer, WEAK_FINGERPRINT, MANY_FROM_ONE_SOURCE };
