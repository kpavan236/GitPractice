'use strict';
const { safeEqualHex } = require('./secrets');

/**
 * Proof that a Buy-form email address was confirmed with a one-time code. It is a keyed hash over the address, the machine and an
 * expiry, so it cannot be moved to another address or machine, cannot be given a longer life, and needs no table. The Buy form
 * submit refuses a request without a proof, so the check cannot be skipped by changing the app.
 */
function createPurchaseProof({ hash, ttlMinutes = 30, now = Date.now }) {
  const sign = (email, machineId, expires) => hash('purchase-proof', `${email}\u0000${machineId}\u0000${expires}`);

  function issue({ email, machineId }) {
    const expires = now() + ttlMinutes * 60 * 1000;
    return `${expires}.${sign(email, machineId, expires)}`;
  }

  function check({ token, email, machineId }) {
    if (typeof token !== 'string' || typeof email !== 'string' || typeof machineId !== 'string') return false;
    const m = /^(\d{1,15})\.([0-9a-f]{64})$/.exec(token);
    if (!m) return false;
    const expires = Number(m[1]);
    if (!(expires > now())) return false;
    return safeEqualHex(sign(email, machineId, expires), m[2]);
  }

  return { issue, check };
}

module.exports = { createPurchaseProof };
