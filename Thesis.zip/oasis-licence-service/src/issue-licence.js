'use strict';
const crypto = require('node:crypto');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { normaliseKey } = require('./secrets');

// No 0, O, 1, I or L: a key read over the phone or typed from a PDF is not misread.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/** A new licence key such as OASIS-7K3M-2QX9-HDV4. Shown to the person once, at issue; only its hash is kept. */
function newLicenceKey() {
  const group = () => Array.from(crypto.randomBytes(4), b => ALPHABET[b % ALPHABET.length]).join('');
  return `OASIS-${group()}-${group()}-${group()}`;
}

/**
 * Creates a licence for a customer and returns its key (the only time it can be seen). The licence starts "pending activation"
 * and becomes active when the first machine activates. Its features are copied from the plan, so editing a plan later never
 * changes a licence already sold. This is what support's "create licence" will call; until those routes exist it is run from
 * `npm run issue-licence`.
 */
async function issueLicence({ licenseDb, hash }, { customerId, planCode, kind = 'paid', seatLimit, termDays, startsAt = null, graceDays = null, reason = 'Issued by support' }) {
  const key = newLicenceKey();
  const licenseId = uuidv7();
  await tx(licenseDb, async db => {
    const { rows: [plan] } = await db.query('SELECT default_seat_limit, default_term_days, default_grace_days, offline_allowed FROM plan WHERE plan_code = $1 AND is_active', [planCode]);
    if (!plan) throw new Error(`Unknown or inactive plan "${planCode}".`);
    const seats = seatLimit === undefined ? plan.default_seat_limit : seatLimit;
    await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await db.query(
      `INSERT INTO license (license_id, customer_id, plan_code, license_key_hash, key_hint, kind_code, seat_limit, grace_days, offline_allowed)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [licenseId, customerId, planCode, hash('licence-key', normaliseKey(key)), key.slice(-4), kind, seats, graceDays === null ? plan.default_grace_days : graceDays, plan.offline_allowed && kind === 'enterprise']);
    await db.query(
      `INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code)
       VALUES ($1, $2, 1, coalesce($3::timestamptz, now()), coalesce($3::timestamptz, now()) + make_interval(days => $4), 'purchase')`,
      [uuidv7(), licenseId, startsAt, termDays === undefined ? plan.default_term_days : termDays]);
    await db.query(
      `INSERT INTO entitlement (entitlement_id, license_id, feature_code, enabled, limit_value, reason)
       SELECT gen_random_uuid(), $1, feature_code, enabled, limit_value, 'Included in the plan' FROM plan_feature_default WHERE plan_code = $2`,
      [licenseId, planCode]);
    await db.query(`UPDATE license SET status_code = 'PENDING_ACTIVATION' WHERE license_id = $1`, [licenseId]);
  });
  return { licenseId, licenceKey: key };
}

module.exports = { issueLicence, newLicenceKey };
