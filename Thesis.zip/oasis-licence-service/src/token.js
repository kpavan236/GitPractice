'use strict';
const crypto = require('node:crypto');

// The licence token the OASIS app verifies: an Ed25519 JWS. The algorithm is fixed here and pinned again in the app,
// never read from the token. The format must stay identical to server/licensing/token.js in the OASIS app.
const b64url = buf => Buffer.from(buf).toString('base64url');
const segment = obj => b64url(Buffer.from(JSON.stringify(obj), 'utf8'));

function signToken(payload, privateKey, { kid = null } = {}) {
  const header = { alg: 'EdDSA', typ: 'JWT' };
  if (kid) header.kid = kid;
  const input = `${segment(header)}.${segment(payload)}`;
  return `${input}.${b64url(crypto.sign(null, Buffer.from(input, 'ascii'), privateKey))}`;
}

/** The public half, as PEM, derived from the private key so there is no second file to keep in step. */
const publicPemOf = privateKey => crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'pem' });

/**
 * Reads back a token this service signed: the payload if the signature checks out against one of `keys` ([{ kid, pem }]), else
 * null. The algorithm is fixed here and never taken from the token, and an unknown key id is a refusal, not a search through
 * every key. Expiry is NOT checked: a token the app still holds after it lapsed is how it proves which licence to revalidate,
 * and the server decides from its own records whether that licence is still good.
 */
function readOwnToken(token, keys) {
  if (typeof token !== 'string' || token.length > 4096) return null;
  const parts = token.split('.');
  if (parts.length !== 3 || parts.some(p => !p)) return null;
  try {
    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    if (!header || header.alg !== 'EdDSA') return null;
    const key = keys.find(k => k.kid === header.kid);
    if (!key) return null;
    const ok = crypto.verify(null, Buffer.from(`${parts[0]}.${parts[1]}`, 'ascii'), key.pem, Buffer.from(parts[2], 'base64url'));
    if (!ok) return null;
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : null;
  } catch (_) { return null; }
}

module.exports = { signToken, publicPemOf, readOwnToken };
