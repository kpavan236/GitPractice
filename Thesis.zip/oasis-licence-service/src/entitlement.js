'use strict';
const { signToken } = require('./token');

const DAY = 86_400_000;

/** The licence id a trial token carries. The same text is checked again when the app revalidates the trial. */
const trialLicenseId = machineId => `trial_${machineId.slice(0, 8)}`;

/**
 * The claims the OASIS app reads (server/licensing/token.js there): licenseId, tier, exp and issuedAt are required, the rest
 * says what the licence unlocks. `exp` is when the licence ends; `graceUntil` is how long the app may keep working offline.
 */
function trialClaims({ machineId, jti, issuedAt, exp }) {
  return { licenseId: trialLicenseId(machineId), jti, tier: 'trial', customer: null, seats: 1, features: [], issuedAt, exp };
}

function licenceClaims({ license, customerName, features, jti, issuedAt, exp }) {
  return {
    licenseId: license.license_id, jti, tier: license.plan_code, customer: customerName, seats: license.seat_limit,
    features, issuedAt, exp, graceUntil: issuedAt + license.grace_days * DAY,
  };
}

const sign = (claims, signer) => signToken(claims, signer.privateKey, { kid: signer.kid });

module.exports = { DAY, trialLicenseId, trialClaims, licenceClaims, sign };
