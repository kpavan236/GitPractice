'use strict';
const { refuse } = require('./errors');

/**
 * A fixed-window limit per caller, in this process. It is a first line of defence; the gateway in front of the service is the real one.
 *
 * The caller is the proxy-aware req.ip, so TRUST_PROXY must be exactly the number of proxies in front of the service: too low and every caller shares
 * one bucket, too high and a caller can invent addresses with X-Forwarded-For. An IPv6 address is counted by its /64, because one subscriber holds a whole
 * /64 and could otherwise use billions of "different" addresses. Memory is bounded: expired entries are swept on a timer, never on the request path, and
 * past `maxKeys` the oldest are dropped rather than the process growing without limit.
 */
function callerKey(ip) {
  if (!ip) return 'unknown';
  const v4 = ip.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/i);      // an IPv4 address carried inside IPv6
  if (v4) return v4[1];
  if (!ip.includes(':')) return ip;
  const groups = ip.toLowerCase().split('::');
  const head = groups[0] ? groups[0].split(':') : [];
  const tail = groups.length > 1 && groups[1] ? groups[1].split(':') : [];
  const full = [...head, ...Array(Math.max(0, 8 - head.length - tail.length)).fill('0'), ...tail];
  return `${full.slice(0, 4).map(g => g.padStart(4, '0')).join(':')}::/64`;
}

function rateLimit({ windowMs = 60_000, max = 60, maxKeys = 50_000, now = Date.now } = {}) {
  const hits = new Map();
  let nextSweep = now() + windowMs;
  const sweep = t => {
    nextSweep = t + windowMs;
    for (const [k, v] of hits) if (t - v.start >= windowMs) hits.delete(k);
    while (hits.size > maxKeys) hits.delete(hits.keys().next().value);        // a Map iterates in insertion order: the oldest go first
  };
  return (req, _res, next) => {
    const t = now();
    if (t >= nextSweep || hits.size > maxKeys * 2) sweep(t);
    const key = callerKey(req.ip);
    const entry = hits.get(key);
    if (!entry || t - entry.start >= windowMs) { hits.set(key, { start: t, count: 1 }); return next(); }
    if (++entry.count > max) {
      const retryAfterSeconds = Math.ceil((entry.start + windowMs - t) / 1000);
      return next(refuse('Too many requests. Please wait a moment and try again.', 'too_many_requests', { retryAfterSeconds }, 429));
    }
    next();
  };
}

module.exports = { rateLimit, callerKey };
