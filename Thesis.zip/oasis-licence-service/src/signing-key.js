'use strict';
const crypto = require('node:crypto');
const { publicPemOf } = require('./token');

/**
 * Loads the private key and records its PUBLIC half in the licence database (token_issue points at it by key id). The private key
 * never goes to the database. If this key id is already recorded with a different public key, the service stops rather than sign
 * tokens that older records would describe wrongly.
 */
async function prepareSigner(licenseDb, { signingKeyPem, signingKid }) {
  const privateKey = crypto.createPrivateKey(signingKeyPem);
  if (privateKey.asymmetricKeyType !== 'ed25519') throw new Error('The signing key must be an Ed25519 key.');
  const publicPem = publicPemOf(privateKey);
  await licenseDb.query(
    `INSERT INTO signing_key (kid, public_pem, status, activates_at) VALUES ($1, $2, 'active', now()) ON CONFLICT (kid) DO NOTHING`,
    [signingKid, publicPem]
  );
  const { rows } = await licenseDb.query('SELECT public_pem FROM signing_key WHERE kid = $1', [signingKid]);
  if (rows[0].public_pem.trim() !== publicPem.trim()) throw new Error(`Signing key "${signingKid}" is already recorded with a different public key. Use a new LICENCE_SIGNING_KID.`);
  return { privateKey, kid: signingKid };
}

module.exports = { prepareSigner };
