'use strict';
const { ApiError } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { licenceClaims, sign } = require('./entitlement');
const { upsertInstallation } = require('./machine');

const refusal = (status, message, reason, extra) => new ApiError(status, message, reason, extra);
const dateOf = d => d.toISOString().slice(0, 10);

/**
 * Looking up a licence, deciding whether it may be used, seating a machine on it, and issuing the token. Everything that decides
 * (is it current, is there a seat) uses the DATABASE clock, so nothing the app sends can move a date.
 *
 * Both entry points (activate, revalidate) run in ONE transaction that locks the licence row, so two machines cannot take the last
 * seat together. A refusal is returned from the transaction rather than thrown inside it, so the check-in that records the
 * attempt is kept; the route throws it after the commit.
 */
function createLicences({ customerDb, licenseDb, signer }) {
  /** The licence for an email domain: the customer that has verified the domain, then its best licence (current ones first). */
  async function findByDomain(domain) {
    const customers = await customerDb.query(
      `SELECT d.customer_id FROM customer_domain d JOIN customer c USING (customer_id)
        WHERE d.domain = $1 AND d.verified_at IS NOT NULL AND c.deleted_at IS NULL`, [domain]);
    if (!customers.rowCount) return null;
    const { rows } = await licenseDb.query(
      `SELECT l.license_id FROM license l
        WHERE l.customer_id = ANY($1) AND l.status_code <> 'DRAFT'
        ORDER BY (l.status_code IN ('ACTIVE', 'PENDING_ACTIVATION')) DESC,
                 (SELECT max(ends_at) FROM license_term t WHERE t.license_id = l.license_id) DESC NULLS LAST
        LIMIT 1`, [customers.rows.map(r => r.customer_id)]);
    return rows.length ? rows[0].license_id : null;
  }

  async function findByKeyHash(keyHash) {
    const { rows } = await licenseDb.query(`SELECT license_id FROM license WHERE license_key_hash = $1 AND status_code <> 'DRAFT'`, [keyHash]);
    return rows.length ? rows[0].license_id : null;
  }

  async function lockLicense(db, licenseId) {
    const { rows } = await db.query(
      `SELECT l.license_id, l.customer_id, l.plan_code, l.status_code, l.seat_limit, l.grace_days, t.starts_at, t.ends_at, t.last_ended, t.covered, now() AS db_now
         FROM license l LEFT JOIN LATERAL (SELECT min(starts_at) AS starts_at, max(ends_at) AS ends_at, max(ends_at) FILTER (WHERE ends_at <= now()) AS last_ended,
                              coalesce(bool_or(starts_at <= now() AND ends_at > now()), false) AS covered FROM license_term WHERE license_id = l.license_id) t ON true
        WHERE l.license_id = $1 FOR UPDATE OF l`, [licenseId]);
    return rows[0];
  }

  /**
   * Is this licence usable right now? Returns { error } for a refusal, { move } when its recorded status is out of step with its
   * terms and must be corrected (a licence waiting for its first activation, or one that lapsed and has since been renewed), or {}.
   * Order: revoked, suspended, not current, expired. (The activation also checks seats, after this.)
   */
  function judge(lic, { activating }) {
    if (lic.status_code === 'CANCELLED') return { error: refusal(403, 'This licence has been revoked. Contact support.', 'revoked') };
    if (lic.status_code === 'SUSPENDED') return { error: refusal(403, 'This licence is suspended. Contact support.', 'suspended') };
    if (lic.status_code === 'DRAFT' || !lic.ends_at) return { error: refusal(403, 'This licence is not active yet. Contact support.', 'not_active') };
    if (!lic.covered) {       // no term covers now: not begun yet, or over (a gap between terms counts as over)
      if (lic.starts_at > lic.db_now) return { error: refusal(403, `This licence starts on ${dateOf(lic.starts_at)}.`, 'not_started', { startsOn: dateOf(lic.starts_at) }) };
      const expiredOn = dateOf(lic.last_ended);
      return { error: refusal(403, `This licence ended on ${expiredOn}. Contact support to renew it.`, 'expired', { expiredOn }) };
    }
    if (lic.status_code === 'PENDING_ACTIVATION') return activating ? { move: 'First activation' } : { error: refusal(403, 'This machine is not activated on any licence.', 'not_activated') };
    if (lic.status_code === 'EXPIRED') return { move: 'A renewed term is in effect' };
    return {};
  }

  async function moveToActive(db, licenseId, reason) {
    await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await db.query(`UPDATE license SET status_code = 'ACTIVE' WHERE license_id = $1`, [licenseId]);
  }

  /** What the licence unlocks: its own entitlements if it has any, else its plan's defaults. Enterprise is everything ('*'). */
  async function featuresOf(db, lic) {
    if (lic.plan_code === 'enterprise') return '*';
    const { rows: [any] } = await db.query('SELECT EXISTS (SELECT 1 FROM entitlement WHERE license_id = $1) AS has', [lic.license_id]);
    const { rows } = any.has
      ? await db.query('SELECT feature_code FROM entitlement_current WHERE license_id = $1 AND enabled ORDER BY feature_code', [lic.license_id])
      : await db.query('SELECT feature_code FROM plan_feature_default WHERE plan_code = $1 AND enabled ORDER BY feature_code', [lic.plan_code]);
    return rows.map(r => r.feature_code);
  }

  async function record(db, lic, installationId, kind, appVersion) {
    await db.query(
      `INSERT INTO installation_check_in (check_in_id, installation_id, license_id, kind_code, app_version, seen_at) VALUES ($1, $2, $3, $4, $5, now())`,
      [uuidv7(), installationId, lic.license_id, kind, appVersion]);
  }

  async function issue(db, lic, installationId) {
    const jti = uuidv7();
    await db.query(
      `INSERT INTO token_issue (jti, license_id, installation_id, kid, issued_at, expires_at) VALUES ($1, $2, $3, $4, $5, $6)`,
      [jti, lic.license_id, installationId, signer.kid, lic.db_now, lic.ends_at]);
    return { lic, jti, features: await featuresOf(db, lic) };
  }

  /** Signs the answer. The customer's name comes from the customer database, after the licence transaction has finished. */
  async function sealToken({ lic, jti, features }) {
    const { rows } = await customerDb.query('SELECT name FROM customer WHERE customer_id = $1', [lic.customer_id]);
    const claims = licenceClaims({ license: lic, customerName: rows.length ? rows[0].name : null, features, jti, issuedAt: lic.db_now.getTime(), exp: lic.ends_at.getTime() });
    return sign(claims, signer);
  }

  /** A machine takes a seat (or already has one) and gets a token. Throws the refusal after recording the attempt. */
  async function activate({ licenseId, machineId, machine }) {
    const outcome = await tx(licenseDb, async db => {
      const installationId = await upsertInstallation(db, machineId, machine);
      const lic = await lockLicense(db, licenseId);
      if (!lic) return { error: refusal(403, 'This licence is not active yet. Contact support.', 'not_active') };

      const verdict = judge(lic, { activating: true });
      let error = verdict.error;
      if (!error) {
        if (verdict.move) await moveToActive(db, licenseId, verdict.move);
        const held = await db.query('SELECT 1 FROM activation WHERE license_id = $1 AND installation_id = $2 AND released_at IS NULL', [licenseId, installationId]);
        if (!held.rowCount) {
          const used = lic.seat_limit === null ? 0 : Number((await db.query('SELECT count(*) AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [licenseId])).rows[0].n);
          if (lic.seat_limit !== null && used >= lic.seat_limit) {
            error = refusal(403, `All ${lic.seat_limit} seats on this licence are in use. Ask your administrator to free one.`, 'seats_full', { seats: lic.seat_limit });
          } else {
            await db.query('INSERT INTO activation (activation_id, license_id, installation_id) VALUES ($1, $2, $3)', [uuidv7(), licenseId, installationId]);
          }
        }
      }
      await record(db, lic, installationId, 'activate', machine.appVersion);
      if (error) return { error };

      // A trial on this machine has done its job. This never refuses: activating checks the licence, not the machine's history.
      await db.query(`SELECT set_config('app.reason', 'A licence was activated on this machine', true)`);
      await db.query(
        `UPDATE trial SET status_code = 'CONVERTED', converted_license_id = $1, converted_at = now() WHERE installation_id = $2 AND status_code IN ('ACTIVE', 'EXPIRED')`,
        [licenseId, installationId]);
      return { issued: await issue(db, lic, installationId) };
    });
    if (outcome.error) throw outcome.error;
    return sealToken(outcome.issued);
  }

  /** Keeps a licence current: the machine must still hold a seat on it. Throws the refusal after recording the attempt. */
  async function revalidate({ licenseId, machineId, machine }) {
    const outcome = await tx(licenseDb, async db => {
      const installationId = await upsertInstallation(db, machineId, machine);
      const lic = await lockLicense(db, licenseId);
      if (!lic) return { error: refusal(403, 'This machine is not activated on any licence.', 'not_activated') };

      let error = judge(lic, { activating: false }).error;
      if (!error) {
        const held = await db.query('SELECT 1 FROM activation WHERE license_id = $1 AND installation_id = $2 AND released_at IS NULL', [licenseId, installationId]);
        if (!held.rowCount) error = refusal(403, 'This machine is not activated on any licence.', 'not_activated');
      }
      await record(db, lic, installationId, 'revalidate', machine.appVersion);
      if (error) return { error };
      if (lic.status_code === 'EXPIRED') await moveToActive(db, licenseId, 'A renewed term is in effect');
      return { issued: await issue(db, lic, installationId) };
    });
    if (outcome.error) throw outcome.error;
    return sealToken(outcome.issued);
  }

  /**
   * Frees a machine's seat. The token must have been issued TO that machine (its jti is looked up), so a token from one machine plus
   * another machine's id frees nothing. Safe to repeat: no open seat is not an error.
   */
  async function deactivate({ licenseId, machineId, jti }) {
    await tx(licenseDb, async db => {
      await db.query(
        `UPDATE activation SET released_at = clock_timestamp(), release_reason_code = 'user'
          WHERE license_id = $1 AND released_at IS NULL
            AND installation_id = (SELECT i.installation_id FROM token_issue t JOIN installation i USING (installation_id) WHERE t.jti = $3 AND i.fingerprint = $2)`,
        [licenseId, machineId, jti]);
    });
  }

  return { findByDomain, findByKeyHash, activate, revalidate, deactivate };
}

module.exports = { createLicences };
