'use strict';

// Input rules for the two forms on the licence page: activating by email, and asking to buy
// (organization, number of employees, email, contact name).
//
// The app server and the dev licence service both apply these, so neither trusts the other (or
// the page) to have checked. They return tidied values, never the raw input: control characters
// are removed, unexpected fields are dropped, and a number arrives as a number.

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/;
const MAX_EMAIL = 254;

// Removes control characters; a line break or tab becomes a space.
function stripControl(text) {
  // eslint-disable-next-line no-control-regex
  return String(text).replace(/[\r\n\t]+/g, ' ').replace(/[\u0000-\u001f\u007f]/g, '').replace(/[ ]{2,}/g, ' ').trim();
}

/** The address, trimmed and lower-cased, or null when it is not exactly one email address. */
function normaliseEmail(value) {
  if (typeof value !== 'string') return null;
  const s = value.trim().toLowerCase();
  if (!s || s.length > MAX_EMAIL || /[\s,;<>\u0000-\u001f\u007f\u0085\u2028\u2029\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/.test(s)) return null;
  if ((s.match(/@/g) || []).length !== 1 || !EMAIL.test(s)) return null;
  return s;
}

/** The part after the @, or null. */
function domainOf(value) {
  const email = normaliseEmail(value);
  return email ? email.split('@')[1] : null;
}

function text(input, label, { min = 1, max } = {}) {
  if (typeof input !== 'string') return { error: `Enter ${label}.` };
  const value = stripControl(input);
  if (value.length < min) return { error: `Enter ${label}.` };
  if (value.length > max) return { error: `Keep ${label} under ${max} characters.` };
  return { value };
}

function wholeNumber(input, { min, max }) {
  const s = typeof input === 'number' ? (Number.isFinite(input) ? String(input) : '') : typeof input === 'string' ? input.trim() : '';
  if (!/^\d+$/.test(s)) return null;
  const n = Number(s);
  return n >= min && n <= max ? n : null;
}

/**
 * @returns { ok: true, value } | { ok: false, errors: { field: message } }
 */
function validatePurchaseRequest(input) {
  const src = input && typeof input === 'object' ? input : {};
  const errors = {};
  const value = {};

  const org = text(src.organization, 'your organization\'s name', { max: 200 });
  if (org.error) errors.organization = org.error; else value.organization = org.value;

  const employees = wholeNumber(src.employees, { min: 1, max: 1000000 });
  if (employees === null) errors.employees = 'Enter the number of employees, a whole number from 1 to 1,000,000.';
  else value.employees = employees;

  const email = normaliseEmail(src.email);
  if (!email) errors.email = 'Enter a valid email address.'; else value.email = email;

  const name = text(src.contactName, 'a contact name', { max: 150 });
  if (name.error) errors.contactName = name.error; else value.contactName = name.value;

  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, value };
}

/**
 * An Idempotency-Key the app or a caller sent, or null when it is missing or not 8 to 100 letters, digits,
 * hyphens or underscores. A bad key is ignored rather than refused: the request still goes through, it just
 * cannot be safely retried.
 */
function cleanIdempotencyKey(value) {
  const s = Array.isArray(value) ? value[0] : value;
  return typeof s === 'string' && /^[A-Za-z0-9_-]{8,100}$/.test(s) ? s : null;
}

module.exports = { cleanIdempotencyKey, normaliseEmail, domainOf, validatePurchaseRequest, stripControl };
