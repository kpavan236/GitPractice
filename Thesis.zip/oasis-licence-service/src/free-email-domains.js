'use strict';

/**
 * Personal email providers. The Buy form asks for a work address (a licence belongs to an organisation), so these are refused.
 * A list cannot know every personal or private domain; it catches the common ones. EXTRA_BLOCKED_EMAIL_DOMAINS adds more.
 */
const FREE_EMAIL_DOMAINS = new Set([
  'gmail.com', 'googlemail.com',
  'yahoo.com', 'yahoo.co.uk', 'yahoo.co.in', 'yahoo.ca', 'yahoo.fr', 'yahoo.de', 'ymail.com', 'rocketmail.com',
  'outlook.com', 'hotmail.com', 'hotmail.co.uk', 'live.com', 'msn.com', 'passport.com',
  'icloud.com', 'me.com', 'mac.com',
  'aol.com', 'aim.com',
  'proton.me', 'protonmail.com', 'pm.me',
  'gmx.com', 'gmx.net', 'gmx.de', 'mail.com', 'zoho.com', 'yandex.com', 'yandex.ru', 'mail.ru',
  'fastmail.com', 'tutanota.com', 'tuta.io', 'hey.com', 'qq.com', '163.com', '126.com',
]);

/** True when the domain, or a parent of it (mail.gmail.com), is a personal provider or in `extra`. Anything that is not a string is not "free". */
function isFreeEmailDomain(domain, extra = []) {
  if (typeof domain !== 'string' || !domain) return false;
  const blocked = new Set([...FREE_EMAIL_DOMAINS, ...extra.map(d => String(d).trim().toLowerCase()).filter(Boolean)]);
  const parts = domain.trim().toLowerCase().split('.');
  for (let i = 0; i < parts.length - 1; i++) if (blocked.has(parts.slice(i).join('.'))) return true;
  return false;
}

module.exports = { isFreeEmailDomain, FREE_EMAIL_DOMAINS };
