'use strict';
const http = require('node:http');
const https = require('node:https');
const { createShutdown } = require('./shutdown');
const { loadConfig } = require('./config');
const { createPool } = require('./db');
const { prepareSigner } = require('./signing-key');
const { createApp } = require('./app');
const { createFakeNotifier } = require('./notifier');

async function main() {
  const config = loadConfig();
  const customerDb = createPool(config.customerDatabaseUrl);
  const licenseDb = createPool(config.licenseDatabaseUrl);
  const signer = await prepareSigner(licenseDb, config);
  const notifier = createFakeNotifier({ print: config.printCodes });
  const app = createApp({ customerDb, licenseDb, signer, hashPepper: config.hashPepper, supportMailbox: config.supportMailbox, blockedEmailDomains: config.blockedEmailDomains, notifier, trialDays: config.trialDays, trustProxy: config.trustProxy, hsts: Boolean(config.tls) });
  const server = config.tls ? https.createServer(config.tls, app) : http.createServer(app);
  server.listen(config.port, () => console.log(JSON.stringify({ level: 'info', msg: 'listening', port: config.port, tls: Boolean(config.tls) })));

  const stop = createShutdown({ server, pools: [customerDb, licenseDb], timeoutMs: config.shutdownTimeoutMs });
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch(err => { console.error(JSON.stringify({ level: 'fatal', error: err.message })); process.exit(1); });
