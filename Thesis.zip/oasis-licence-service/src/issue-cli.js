'use strict';
// Issues a licence from the command line and prints its key ONCE.
//   node src/issue-cli.js --customer <customer uuid> --plan team [--seats 10] [--days 365] [--kind paid|enterprise|pilot]
// Needs LICENSE_DATABASE_URL and HASH_PEPPER (the same values the service runs with). The customer and its email domain must already
// exist in the customer database.
const { createPool } = require('./db');
const { createHasher } = require('./secrets');
const { issueLicence } = require('./issue-licence');

function args(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    if (!argv[i].startsWith('--') || argv[i + 1] === undefined) throw new Error(`Unexpected argument "${argv[i]}".`);
    out[argv[i].slice(2)] = argv[i + 1];
  }
  return out;
}

(async () => {
  const a = args(process.argv.slice(2));
  if (!a.customer || !a.plan) throw new Error('Usage: node src/issue-cli.js --customer <uuid> --plan <plan> [--seats N|none] [--days N] [--kind paid|enterprise|pilot]');
  for (const name of ['LICENSE_DATABASE_URL', 'HASH_PEPPER']) if (!process.env[name]) throw new Error(`${name} is required.`);
  const licenseDb = createPool(process.env.LICENSE_DATABASE_URL);
  try {
    const result = await issueLicence({ licenseDb, hash: createHasher(process.env.HASH_PEPPER) }, {
      customerId: a.customer, planCode: a.plan, kind: a.kind || 'paid',
      seatLimit: a.seats === undefined ? undefined : a.seats === 'none' ? null : Number(a.seats),
      termDays: a.days === undefined ? undefined : Number(a.days),
    });
    console.log(`Licence ${result.licenseId}\nKey (shown once, keep it safe): ${result.licenceKey}`);
  } finally { await licenseDb.end(); }
})().catch(err => { console.error(err.message); process.exit(1); });
