'use strict';

/**
 * The email sender, behind two methods. No real provider is approved yet (new email services go through the IT Helpdesk,
 * cainc.service-now.com, first, and the wording needs CA employee review), so the only implementation is a FAKE that keeps what it was
 * asked to send, in memory, for tests and for a developer to look at. docs/fakes.md says what the real one must do.
 *
 *   send({ to, code, expiresInMinutes, purpose })                          a one-time code; purpose is 'activation' (Activate licence) or 'purchase' (Buy form)
 *   notifySupport({ to, reference, organization, employees, contactName, email })   a new Buy-form request, to the support mailbox
 *
 * `print` is for a developer without a mailbox: it writes the code to the terminal (and, for a support notice, only the reference). It is
 * never turned on by default and config.js refuses it in production, because a one-time code must not reach a log.
 */
function createFakeNotifier({ print = false, out = line => console.log(line) } = {}) {
  const sent = [];            // one-time codes
  const supportNotices = [];  // new purchase requests
  const keep = (list, item) => { list.push(item); if (list.length > 1000) list.shift(); };      // a fake that runs for weeks must not grow without limit
  return {
    kind: 'fake',
    sent,
    supportNotices,
    async send(message) {
      keep(sent, { ...message, at: Date.now() });
      if (print) out(`(development only) one-time code for ${message.to}: ${message.code}`);
    },
    async notifySupport(notice) {
      keep(supportNotices, { ...notice, at: Date.now() });
      if (print) out(`(development only) support notice sent to ${notice.to}: new purchase request ${notice.reference}`);
    },
    last: () => sent[sent.length - 1] || null,
    lastSupportNotice: () => supportNotices[supportNotices.length - 1] || null,
  };
}

module.exports = { createFakeNotifier };
