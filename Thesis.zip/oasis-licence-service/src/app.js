'use strict';
const crypto = require('node:crypto');
const express = require('express');
const { errorHandler } = require('./errors');
const { rateLimit } = require('./rate-limit');
const { createTrialReviewer } = require('./trial-review');
const { purchaseRequestRoutes } = require('./routes/purchase-request');
const { trialRoutes } = require('./routes/trial');
const { domainRoutes } = require('./routes/domain');
const { activationRoutes } = require('./routes/activation');
const { createHasher } = require('./secrets');
const { createAccess } = require('./access');
const { createOtp } = require('./otp');
const { createPurchaseProof } = require('./purchase-proof');
const { createLicences } = require('./licences');
const { createTrialRevalidate } = require('./trials');
const { createFakeNotifier } = require('./notifier');

/**
 * Builds the HTTP app. Everything it needs is passed in, so tests hand it throwaway databases.
 * Logging: one line per request (method, path, status, time, request id). The body is NEVER logged, because it can hold an
 * email address, and tokens and one-time codes must not reach a log.
 */
function createApp({ customerDb, licenseDb, signer, hashPepper, notifier = createFakeNotifier(), supportMailbox = null, blockedEmailDomains = [], trialDays = 7, trustProxy = 0, hsts = false, reviewer = createTrialReviewer(), limiter = rateLimit(), log = line => console.log(JSON.stringify(line)) }) {
  const hash = createHasher(hashPepper);
  const access = createAccess({ licenseDb, hash });
  const licences = createLicences({ customerDb, licenseDb, signer });
  const otp = createOtp({ licenseDb, hash, notifier });
  const purchaseProof = createPurchaseProof({ hash });

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);

  app.use((req, res, next) => {
    const inbound = req.get('X-Request-Id');
    req.id = inbound && /^[A-Za-z0-9_-]{8,64}$/.test(inbound) ? inbound : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Cache-Control', 'no-store');
    res.set('Referrer-Policy', 'no-referrer');
    if (hsts) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    const started = Date.now();
    res.on('finish', () => log({ level: 'info', requestId: req.id, method: req.method, path: req.path, status: res.statusCode, ms: Date.now() - started }));
    next();
  });

  app.get('/healthz', (_req, res) => res.json({ ok: true }));
  app.get('/readyz', async (_req, res) => {
    try { await Promise.all([customerDb.query('SELECT 1'), licenseDb.query('SELECT 1')]); res.json({ ok: true }); }
    catch (_) { res.status(503).json({ ok: false }); }
  });

  const v1 = express.Router();
  // /revalidate and /deactivate need a token this service signed, and a whole school can start many machines at once behind one
  // address; counting them per address would turn a Monday morning into an outage. Everything else is limited per address.
  v1.use((req, res, next) => (req.path === '/revalidate' || req.path === '/deactivate' ? next() : limiter(req, res, next)));
  v1.use(express.json({ limit: '16kb' }));
  v1.use(access.middleware);         // a blocked machine, address or domain is refused before ANY route runs
  v1.use(purchaseRequestRoutes({ customerDb, notifier, otp, proof: purchaseProof, blockedEmailDomains, supportMailbox, log }));
  v1.use(trialRoutes({ licenseDb, signer, trialDays, reviewer }));
  v1.use(domainRoutes({ licences, otp }));
  v1.use(activationRoutes({ licenseDb, licences, hash, trialRevalidate: createTrialRevalidate({ licenseDb, signer }) }));
  app.use('/v1', v1);

  app.use((req, res) => res.status(404).json({ error: 'not_found', message: 'No such route.', requestId: req.id }));
  app.use(errorHandler(log));
  return app;
}

module.exports = { createApp };
