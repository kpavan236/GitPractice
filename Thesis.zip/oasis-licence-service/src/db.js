'use strict';
const { Pool } = require('pg');

// Two databases, two pools: customer details and licences are separate databases that point at each other by id only.
function createPool(connectionString) {
  const pool = new Pool({ connectionString, max: 10, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000 });
  pool.on('error', () => {});        // an idle client that drops must not crash the service; the next query reconnects
  return pool;
}

/** Runs fn inside one transaction on one connection; commits if it returns, rolls back if it throws. */
async function tx(pool, fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { createPool, tx };
