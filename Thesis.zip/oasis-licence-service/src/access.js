'use strict';
const { refuse } = require('./errors');
const { uuidv7 } = require('./uuid');
const { normaliseEmail, domainOf } = require('./forms');

const BLOCKED_MESSAGE = 'This machine cannot use the licence. Contact support.';

/**
 * The block list: one flag per machine, per email address or per email domain, checked on EVERY call (see app.js, which runs
 * `middleware` before any route). A refusal is always the same fixed message, whatever the internal note says, so a customer
 * learns nothing about why. Subjects are stored as keyed hashes, never as the raw machine id or address.
 */
function createAccess({ licenseDb, hash }) {
  const subjectsOf = ({ machineId, email }) => {
    const subjects = [];
    if (typeof machineId === 'string' && machineId.length <= 200) subjects.push(['machine', hash('machine', machineId)]);
    const address = normaliseEmail(email);
    if (address) {
      subjects.push(['email', hash('email', address)]);
      subjects.push(['email_domain', hash('domain', domainOf(address))]);
    }
    return subjects;
  };

  const hashOf = (type, value) => (type === 'machine' ? hash('machine', value) : type === 'email' ? hash('email', normaliseEmail(value)) : hash('domain', String(value).toLowerCase()));

  /** The reason code of the first open block that matches, or null. */
  async function check(who, db = licenseDb) {
    const subjects = subjectsOf(who);
    if (!subjects.length) return null;
    const { rows } = await db.query(
      `SELECT reason_code FROM access_block
        WHERE lifted_at IS NULL AND (expires_at IS NULL OR expires_at > now())
          AND (subject_type, subject_hash) IN (SELECT * FROM unnest($1::text[], $2::text[]))
        LIMIT 1`,
      [subjects.map(s => s[0]), subjects.map(s => s[1])]
    );
    return rows.length ? rows[0].reason_code : null;
  }

  /** Express middleware: refuses a blocked caller with 403 `blocked` before the route runs. */
  const middleware = async (req, _res, next) => {
    try {
      const body = req.body && typeof req.body === 'object' ? req.body : {};
      if (await check(body)) return next(refuse(BLOCKED_MESSAGE, 'blocked', {}, 403));
      next();
    } catch (err) { next(err); }
  };

  /** Blocks a machine id, an email address or an email domain. Needs a reason code; blocking twice is a no-op. */
  async function block({ type, value, reason, note = null, byUserId = null, expiresAt = null }) {
    const subjectHash = hashOf(type, value);
    // A block that has run out is still "open" as far as the one-open-block rule goes; close it so a new one can be recorded.
    await licenseDb.query(
      `UPDATE access_block SET lifted_at = now() WHERE subject_type = $1 AND subject_hash = $2 AND lifted_at IS NULL AND expires_at <= now()`, [type, subjectHash]);
    await licenseDb.query(
      `INSERT INTO access_block (block_id, subject_type, subject_hash, reason_code, note, blocked_by_user_id, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT DO NOTHING`,
      [uuidv7(), type, subjectHash, reason, note, byUserId, expiresAt]
    );
  }

  async function lift({ type, value, byUserId = null }) {
    const subjectHash = hashOf(type, value);
    const { rowCount } = await licenseDb.query(
      `UPDATE access_block SET lifted_at = now(), lifted_by_user_id = $3 WHERE subject_type = $1 AND subject_hash = $2 AND lifted_at IS NULL`,
      [type, subjectHash, byUserId]
    );
    return rowCount;
  }

  return { check, middleware, block, lift };
}

module.exports = { createAccess, BLOCKED_MESSAGE };
