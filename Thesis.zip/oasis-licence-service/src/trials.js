'use strict';
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { trialLicenseId, trialClaims, sign } = require('./entitlement');

const readTrial = async (db, installationId) => (await db.query(
  `SELECT trial_id, status_code, coalesce(extended_until, expires_at) AS ends_at, (coalesce(extended_until, expires_at) <= now()) AS over
     FROM trial WHERE installation_id = $1`, [installationId])).rows[0];

/**
 * Why this trial may not continue, as [message, reason], or null if it may. A trial found to be over is recorded as expired
 * here, so that stays true even though the call that found it is refused.
 */
async function trialRefusal(db, trial) {
  if (trial.status_code === 'CONVERTED') return ['This machine already has a licence. Activate it instead.', 'trial_converted'];
  if (trial.status_code === 'ACTIVE' && trial.over) {
    await db.query(`SELECT set_config('app.reason', 'Trial ended', true)`);
    await db.query(`UPDATE trial SET status_code = 'EXPIRED' WHERE trial_id = $1`, [trial.trial_id]);
    return ['Your trial has already ended.', 'trial_ended'];
  }
  if (trial.status_code !== 'ACTIVE' || trial.over) return ['Your trial has already ended.', 'trial_ended'];
  return null;
}

const recordTrialCheckIn = (db, installationId, trialId, appVersion) => db.query(
  `INSERT INTO installation_check_in (check_in_id, installation_id, trial_id, kind_code, app_version, seen_at) VALUES ($1, $2, $3, 'trial', $4, now())`,
  [uuidv7(), installationId, trialId, appVersion]);

/** Records a token for the trial and returns what is needed to sign it. The expiry is the trial's effective end, extensions included. */
async function issueTrial(db, { trial, installationId, signer }) {
  const jti = uuidv7();
  const { rows: [t] } = await db.query(
    `INSERT INTO token_issue (jti, trial_id, installation_id, kid, issued_at, expires_at) VALUES ($1, $2, $3, $4, now(), $5)
     RETURNING (extract(epoch FROM issued_at) * 1000)::bigint AS issued_ms`,
    [jti, trial.trial_id, installationId, signer.kid, trial.ends_at]);
  return { jti, issuedAt: Number(t.issued_ms), exp: trial.ends_at.getTime() };
}

const signTrial = (machineId, issued, signer) => sign(trialClaims({ machineId, ...issued }), signer);

/**
 * /revalidate for a trial token. The token only says which machine it was made for; the trial's state is read from the database,
 * and a fresh token is issued with the effective expiry, so an extension given by support takes effect at the next check.
 */
function createTrialRevalidate({ licenseDb, signer }) {
  return async function revalidateTrial({ machineId, claims, machine }) {
    const notActivated = () => refuse('This machine is not activated on any licence.', 'not_activated', {}, 403);
    if (claims.licenseId !== trialLicenseId(machineId)) throw notActivated();

    const outcome = await tx(licenseDb, async db => {
      const { rows: [inst] } = await db.query('SELECT installation_id FROM installation WHERE fingerprint = $1', [machineId]);
      const trial = inst && await readTrial(db, inst.installation_id);
      if (!trial) return { error: notActivated() };
      await recordTrialCheckIn(db, inst.installation_id, trial.trial_id, machine.appVersion);
      const why = await trialRefusal(db, trial);
      if (why) return { error: refuse(why[0], why[1], {}, 403) };
      return { issued: await issueTrial(db, { trial, installationId: inst.installation_id, signer }) };
    });
    if (outcome.error) throw outcome.error;
    return { token: signTrial(machineId, outcome.issued, signer), serverTime: Date.now() };
  };
}

module.exports = { readTrial, trialRefusal, recordTrialCheckIn, issueTrial, signTrial, createTrialRevalidate };
