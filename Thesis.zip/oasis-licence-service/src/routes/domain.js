'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');
const { normaliseEmail, domainOf } = require('../forms');
const { MACHINE_ID, machineDetails } = require('../machine');

/**
 * The two steps of "Activate licence" (email a code, then check it and the licence).
 *
 * The code is proof the person can read mail at that address; the licence belongs to the company that owns the domain. A user
 * record is NOT created here: there is no identity service yet, so the seat is taken by the machine (see the plan, section 8,
 * question 1).
 */
function domainRoutes({ licences, otp }) {
  const router = express.Router();

  const read = body => {
    const email = normaliseEmail(body.email);
    if (!email) throw refuse('Enter a valid email address.', 'bad_email');
    if (typeof body.machineId !== 'string' || !MACHINE_ID.test(body.machineId)) throw refuse('machineId is required.', 'bad_machine_id');
    return { email, machineId: body.machineId };
  };
  const bodyOf = req => (req.body && typeof req.body === 'object' ? req.body : {});
  const noLicence = domain => refuse(`No licence was found for ${domain}.`, 'no_domain_licence', { domain }, 404);

  router.post('/domain/otp', wrap(async (req, res) => {
    const { email, machineId } = read(bodyOf(req));
    const domain = domainOf(email);
    if (!await licences.findByDomain(domain)) throw noLicence(domain);
    res.json(await otp.request({ email, machineId }));
  }));

  router.post('/domain/activate', wrap(async (req, res) => {
    const body = bodyOf(req);
    const { email, machineId } = read(body);
    await otp.verify({ email, code: body.code, machineId, consume: false });
    const domain = domainOf(email);
    const licenseId = await licences.findByDomain(domain);
    if (!licenseId) throw noLicence(domain);
    const token = await licences.activate({ licenseId, machineId, machine: machineDetails(body) });
    await otp.consume({ email });
    res.json({ token, serverTime: Date.now() });
  }));

  return router;
}

module.exports = { domainRoutes };
