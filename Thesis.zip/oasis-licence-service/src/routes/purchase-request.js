'use strict';
const express = require('express');
const { validatePurchaseRequest, cleanIdempotencyKey } = require('../forms');
const { refuse, wrap } = require('../errors');
const { uuidv7 } = require('../uuid');
const { normaliseEmail, domainOf } = require('../forms');
const { isFreeEmailDomain } = require('../free-email-domains');
const { MACHINE_ID } = require('../machine');

const MAX_PER_ADDRESS_PER_HOUR = 5;

// "1.2.3-beta" style only; anything else is dropped rather than stored.
const cleanVersion = v => (typeof v === 'string' && /^[0-9A-Za-z.+-]{1,20}$/.test(v) ? v : null);

/** POST /v1/purchase-request: the Buy form. Writes one purchase_request row (customer database) and tells the support mailbox. */
function purchaseRequestRoutes({ customerDb, notifier, otp, proof, blockedEmailDomains = [], supportMailbox = null, log = () => {} }) {
  const router = express.Router();
  const bodyOf = req => (req.body && typeof req.body === 'object' ? req.body : {});
  const notWork = () => refuse('Use your work email address. Personal addresses such as Gmail or Yahoo cannot be used.', 'not_corporate_email');

  const read = body => {
    const email = normaliseEmail(body.email);
    if (!email) throw refuse('Enter a valid email address.', 'bad_email');
    if (typeof body.machineId !== 'string' || !MACHINE_ID.test(body.machineId)) throw refuse('machineId is required.', 'bad_machine_id');
    if (isFreeEmailDomain(domainOf(email), blockedEmailDomains)) throw notWork();
    return { email, machineId: body.machineId };
  };

  /** Step 1 of the Buy form: email a one-time code to a work address. */
  router.post('/purchase-request/otp', wrap(async (req, res) => {
    const { email, machineId } = read(bodyOf(req));
    res.json(await otp.request({ email, machineId, purpose: 'purchase' }));
  }));

  /** Step 2: check the code. The answer is a short-lived proof the submit must carry. */
  router.post('/purchase-request/verify', wrap(async (req, res) => {
    const body = bodyOf(req);
    const { email, machineId } = read(body);
    await otp.verify({ email, code: body.code, machineId });
    res.json({ ok: true, verificationToken: proof.issue({ email, machineId }) });
  }));

  const replay = (res, reference) => { res.set('Idempotent-Replay', 'true'); return res.json({ ok: true, reference }); };

  router.post('/purchase-request', wrap(async (req, res) => {
    const checked = validatePurchaseRequest(req.body);
    if (!checked.ok) throw refuse('Some details need fixing.', 'invalid', { errors: checked.errors });
    const d = checked.value;
    if (isFreeEmailDomain(domainOf(d.email), blockedEmailDomains)) throw refuse('Some details need fixing.', 'invalid', { errors: { email: 'Use your work email address.' } });
    const body = bodyOf(req);
    if (!proof.check({ token: body.verificationToken, email: d.email, machineId: body.machineId })) {
      throw refuse('Verify your email address with the code we send you before submitting.', 'email_not_verified');
    }
    const key = cleanIdempotencyKey(req.get('Idempotency-Key'));

    // The same submit again (a dropped connection, a double click) gets the first answer, whatever the limit says now.
    if (key) {
      const earlier = await customerDb.query('SELECT reference FROM purchase_request WHERE idempotency_key = $1', [key]);
      if (earlier.rowCount) return replay(res, earlier.rows[0].reference);
    }

    const recent = await customerDb.query(`SELECT count(*)::int AS n FROM purchase_request WHERE email = $1 AND created_at > now() - interval '1 hour'`, [d.email]);
    if (recent.rows[0].n >= MAX_PER_ADDRESS_PER_HOUR) throw refuse('Too many requests from this address. Our team will be in touch.', 'too_many_requests', {}, 429);

    const inserted = await customerDb.query(
      `INSERT INTO purchase_request (purchase_request_id, idempotency_key, organization_name, employee_count, contact_name, email, source_code, app_version)
       VALUES ($1, $2, $3, $4, $5, $6, 'oasis-app', $7)
       ON CONFLICT (idempotency_key) DO NOTHING
       RETURNING reference`,
      [uuidv7(), key, d.organization, d.employees, d.contactName, d.email, cleanVersion(req.body && req.body.appVersion)]
    );
    if (inserted.rowCount) {
      const reference = inserted.rows[0].reference;
      // Tell the support team. Best effort and AFTER the request is stored: a mail fault must never lose a customer's request or make the
      // app think it failed (the support list shows every request whether or not the email went). Only a NEW request notifies, never a replay.
      if (supportMailbox) {
        await notifier.notifySupport({ to: supportMailbox, reference, organization: d.organization, employees: d.employees, contactName: d.contactName, email: d.email })
          .catch(err => log({ level: 'error', requestId: req.id, msg: 'support notice not sent', reference, error: err && err.name }));
      }
      return res.json({ ok: true, reference });
    }

    // Two copies of the same submit arrived together and the other won: answer with its row.
    const winner = await customerDb.query('SELECT reference FROM purchase_request WHERE idempotency_key = $1', [key]);
    return replay(res, winner.rows[0].reference);
  }));

  return router;
}

module.exports = { purchaseRequestRoutes, MAX_PER_ADDRESS_PER_HOUR };
