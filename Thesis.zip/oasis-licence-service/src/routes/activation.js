'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');
const { normaliseKey } = require('../secrets');
const { readOwnToken } = require('../token');
const { MACHINE_ID, machineDetails } = require('../machine');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' ? req.body : {});

/**
 * Activate with a licence key (kept for support-issued keys), revalidate, deactivate. The trial's own revalidation is in
 * routes/trial-revalidate.js; /revalidate hands it the tokens whose tier is "trial".
 */
function activationRoutes({ licenseDb, licences, hash, trialRevalidate }) {
  const router = express.Router();

  const machineIdOf = body => {
    if (typeof body.machineId !== 'string' || !MACHINE_ID.test(body.machineId)) throw refuse('machineId is required.', 'bad_machine_id');
    return body.machineId;
  };

  /** The payload of a token this service signed, or a refusal. The public keys come from the database, so a rotated key keeps working. */
  async function ownToken(token) {
    const { rows } = await licenseDb.query(`SELECT kid, public_pem AS pem FROM signing_key WHERE status IN ('active', 'retiring')`);
    const payload = readOwnToken(token, rows);
    if (!payload) throw refuse('That licence token was not recognised. Activate again.', 'bad_token');
    return payload;
  }

  router.post('/activate', wrap(async (req, res) => {
    const body = bodyOf(req);
    const machineId = machineIdOf(body);
    const key = normaliseKey(body.licenseKey);
    if (!key || key.length > 100) throw refuse('That licence key was not recognised.', 'unknown_key');
    const licenseId = await licences.findByKeyHash(hash('licence-key', key));
    if (!licenseId) throw refuse('That licence key was not recognised.', 'unknown_key');
    const token = await licences.activate({ licenseId, machineId, machine: machineDetails(body) });
    res.json({ token, serverTime: Date.now() });
  }));

  router.post('/revalidate', wrap(async (req, res) => {
    const body = bodyOf(req);
    const machineId = machineIdOf(body);
    const claims = await ownToken(body.token);
    if (claims.tier === 'trial') return res.json(await trialRevalidate({ machineId, claims, machine: machineDetails(body) }));
    if (typeof claims.licenseId !== 'string' || !UUID.test(claims.licenseId)) throw refuse('That licence token was not recognised. Activate again.', 'bad_token');
    const token = await licences.revalidate({ licenseId: claims.licenseId, machineId, machine: machineDetails(body) });
    res.json({ token, serverTime: Date.now() });
  }));

  router.post('/deactivate', wrap(async (req, res) => {
    const body = bodyOf(req);
    const machineId = machineIdOf(body);
    const claims = await ownToken(body.token);
    if (typeof claims.licenseId === 'string' && UUID.test(claims.licenseId) && typeof claims.jti === 'string' && UUID.test(claims.jti)) {
      await licences.deactivate({ licenseId: claims.licenseId, machineId, jti: claims.jti });
    }
    res.json({ ok: true, serverTime: Date.now() });
  }));

  return router;
}

module.exports = { activationRoutes };
