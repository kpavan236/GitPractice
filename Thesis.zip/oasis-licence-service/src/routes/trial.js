'use strict';
const express = require('express');
const { sanitizeIntegration } = require('../integration');
const { refuse, wrap } = require('../errors');
const { tx } = require('../db');
const { uuidv7 } = require('../uuid');
const { MACHINE_ID, machineDetails, upsertInstallation } = require('../machine');
const { readTrial, trialRefusal, recordTrialCheckIn, issueTrial, signTrial } = require('../trials');

/**
 * POST /v1/trial: start the trial, or resume it. One trial per machine, ever: a machine seen before gets its ORIGINAL expiry back.
 * Start and expiry are this database's clock; nothing the app sends can move them. Writes installation, trial, trial_integration,
 * trial_review_flag, installation_check_in and token_issue (licence database) in one transaction.
 */
function trialRoutes({ licenseDb, signer, trialDays, reviewer }) {
  const router = express.Router();

  router.post('/trial', wrap(async (req, res) => {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (typeof body.machineId !== 'string' || !MACHINE_ID.test(body.machineId)) throw refuse('machineId is required.', 'bad_machine_id');
    const machine = machineDetails(body);
    const { fingerprintSource, appVersion } = machine;
    const details = sanitizeIntegration(body.integration);

    const outcome = await tx(licenseDb, async db => {
      const installationId = await upsertInstallation(db, body.machineId, machine);

      // A first request creates the trial. If two arrive together, the loser inserts nothing and reads the winner's row.
      const created = await db.query(
        `INSERT INTO trial (trial_id, installation_id, started_at, expires_at)
         VALUES ($1, $2, now(), now() + make_interval(days => $3))
         ON CONFLICT (installation_id) DO NOTHING RETURNING trial_id`,
        [uuidv7(), installationId, trialDays]
      );
      const isNew = created.rowCount === 1;
      const trial = await readTrial(db, installationId);

      // Only a NEW trial is reviewed, and it is flagged for a person to look at, never refused.
      if (isNew) {
        const verdict = reviewer.review({ source: req.ip, fingerprintSource });
        for (const flag of verdict.reasons) await db.query('INSERT INTO trial_review_flag (trial_id, flag_code) VALUES ($1, $2) ON CONFLICT DO NOTHING', [trial.trial_id, flag]);
      }
      // The addresses given at setup are kept from the first time they arrive, so a later request cannot rewrite them.
      if (details) {
        await db.query(
          `INSERT INTO trial_integration (trial_id, jenkins_url, github_url, github_org) VALUES ($1, $2, $3, $4) ON CONFLICT (trial_id) DO NOTHING`,
          [trial.trial_id, details.jenkinsUrl || null, details.githubUrl || null, details.githubOrg || null]);
      }
      await recordTrialCheckIn(db, installationId, trial.trial_id, appVersion);

      const why = await trialRefusal(db, trial);     // a refusal is returned, not thrown, so the check-in above is kept
      if (why) return { refusal: why };
      return { issued: await issueTrial(db, { trial, installationId, signer }) };
    });

    if (outcome.refusal) throw refuse(outcome.refusal[0], outcome.refusal[1]);
    res.json({ token: signTrial(body.machineId, outcome.issued, signer), serverTime: Date.now() });
  }));

  return router;
}

module.exports = { trialRoutes };
