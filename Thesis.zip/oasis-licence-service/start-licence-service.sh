#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# Starts the licence service on its own, for local development.
#
# It does not start OASIS. Run that separately, with the two lines this script
# prints at the end (OASIS_LICENSE_URL and OASIS_LICENSE_PUBLIC_KEY).
#
# What it does, each step skipped when already done:
#   1. starts (or creates) the local PostgreSQL container, oasis-pg, on port 5433
#   2. creates the customer and licence databases in it if they are missing
#   3. makes a dev Ed25519 signing key and a hash pepper, kept in ~/.oasis-licence-dev
#   4. applies the migrations (npm run migrate)
#   5. starts the service in the foreground and waits for /readyz
#
# Local development only. The values below are placeholders for a throwaway
# container; none of them are for a shared or real environment.

PORT=${PORT:-4020}
PG_CONTAINER=${PG_CONTAINER:-oasis-pg}
PG_PORT=${PG_PORT:-5433}
PG_PASSWORD=${PG_PASSWORD:-local-dev-only}
CUSTOMER_DB=${CUSTOMER_DB:-customer_db}
LICENSE_DB=${LICENSE_DB:-license_db}
STATE_DIR=${OASIS_LICENCE_DEV_DIR:-$HOME/.oasis-licence-dev}
PRIVATE_KEY="$STATE_DIR/private.pem"
PUBLIC_KEY="$STATE_DIR/public.pem"
PEPPER_FILE="$STATE_DIR/hash-pepper"
RESET=0

usage() {
  cat <<'EOF'

  ./start-licence-service.sh [options]

    --reset    drop and recreate the two databases first (all trials,
               licences and purchase requests are gone)
    -h, --help this

  Environment: PORT (default 4020), CUSTOMER_DB, LICENSE_DB, PG_CONTAINER, PG_PORT, PG_PASSWORD,
  OASIS_LICENCE_DEV_DIR (default ~/.oasis-licence-dev), DEV_PRINT_CODES (default 1)

EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --reset)   RESET=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1 — try --help" >&2; exit 1 ;;
  esac
done

need() {
  command -v "$1" > /dev/null 2>&1 || { echo "$1 is required but not installed." >&2; exit 1; }
}
need docker
need openssl
need node
need curl

if lsof -ti :"$PORT" -sTCP:LISTEN > /dev/null 2>&1; then
  echo "Port $PORT is already in use (PID $(lsof -ti :"$PORT" -sTCP:LISTEN | head -1)). Stop it, or set PORT." >&2
  exit 1
fi

# ── 1. PostgreSQL ──────────────────────────────────────────────────────────
if docker ps --format '{{.Names}}' | grep -qx "$PG_CONTAINER"; then
  :
elif docker ps -a --format '{{.Names}}' | grep -qx "$PG_CONTAINER"; then
  echo "Starting the existing ${PG_CONTAINER} container…"
  docker start "$PG_CONTAINER" > /dev/null
else
  echo "Creating the ${PG_CONTAINER} container (postgres:16 on port ${PG_PORT})…"
  docker run -d --name "$PG_CONTAINER" -p "${PG_PORT}:5432" \
    -e POSTGRES_PASSWORD="$PG_PASSWORD" postgres:16 > /dev/null
fi

psql_admin() {
  docker exec -i "$PG_CONTAINER" psql -U postgres -v ON_ERROR_STOP=1 -At "$@"
}

for _ in $(seq 1 60); do
  docker exec "$PG_CONTAINER" pg_isready -U postgres > /dev/null 2>&1 && break
  sleep 0.5
done
if ! docker exec "$PG_CONTAINER" pg_isready -U postgres > /dev/null 2>&1; then
  echo "PostgreSQL in ${PG_CONTAINER} did not become ready." >&2
  exit 1
fi

# ── 2. The two databases ───────────────────────────────────────────────────
for db in "$CUSTOMER_DB" "$LICENSE_DB"; do
  if [ "$RESET" -eq 1 ]; then
    psql_admin -c "DROP DATABASE IF EXISTS ${db} WITH (FORCE)" > /dev/null
    echo "Dropped ${db}."
  fi
  exists=$(psql_admin -c "SELECT 1 FROM pg_database WHERE datname = '${db}'")
  if [ -z "$exists" ]; then
    psql_admin -c "CREATE DATABASE ${db}" > /dev/null
    echo "Created ${db}."
  fi
done

# ── 3. Signing key and pepper ──────────────────────────────────────────────
# Kept between runs on purpose. A new signing key would make every token issued
# before it fail verification in OASIS, and a new pepper would make every stored
# hash (licence keys, emails, machines) stop matching.
mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"
if [ ! -f "$PRIVATE_KEY" ]; then
  openssl genpkey -algorithm ed25519 -out "$PRIVATE_KEY" 2> /dev/null
  chmod 600 "$PRIVATE_KEY"
  echo "Made a dev signing key at ${PRIVATE_KEY}."
fi
openssl pkey -in "$PRIVATE_KEY" -pubout -out "$PUBLIC_KEY" 2> /dev/null
if [ ! -f "$PEPPER_FILE" ]; then
  openssl rand -hex 32 > "$PEPPER_FILE"
  chmod 600 "$PEPPER_FILE"
fi

if [ ! -d node_modules ]; then
  echo "Installing dependencies…"
  npm install --no-audit --no-fund
fi

# ── 4. Migrations ──────────────────────────────────────────────────────────
export CUSTOMER_DATABASE_URL="postgres://postgres:${PG_PASSWORD}@localhost:${PG_PORT}/${CUSTOMER_DB}"
export LICENSE_DATABASE_URL="postgres://postgres:${PG_PASSWORD}@localhost:${PG_PORT}/${LICENSE_DB}"
export HASH_PEPPER="$(cat "$PEPPER_FILE")"
export LICENCE_SIGNING_KEY_FILE="$PRIVATE_KEY"
export LICENCE_SIGNING_KID="${LICENCE_SIGNING_KID:-dev}"
export NOTIFIER=fake
# One-time codes go to this terminal, because no email provider is approved yet.
export DEV_PRINT_CODES="${DEV_PRINT_CODES:-1}"
export PORT

# A database stood up some other way (db/setup run by hand, a restored copy) can hold tables
# with no migration record. The migrator would try to create them again and fail, and the
# schema may be older than db/ (a missing table only shows up later as a 500). Stop rather
# than guess: --reset rebuilds both databases, and this script never drops one unasked.
unrecorded=""
for db in "$CUSTOMER_DB" "$LICENSE_DB"; do
  tables=$(psql_admin -d "$db" -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public' AND table_name <> 'schema_migration'")
  recorded=0
  if [ -n "$(psql_admin -d "$db" -c "SELECT to_regclass('public.schema_migration')")" ]; then
    recorded=$(psql_admin -d "$db" -c "SELECT count(*) FROM schema_migration")
  fi
  if [ "$tables" -gt 0 ] && [ "$recorded" -eq 0 ]; then
    unrecorded="$unrecorded $db"
  fi
done
if [ -n "$unrecorded" ]; then
  echo "${unrecorded# } already has tables but no migration record, so it may be out of date." >&2
  echo "Re-run with --reset to rebuild both databases (this deletes their data)," >&2
  echo "or use fresh databases: CUSTOMER_DB=customer_dev LICENSE_DB=license_dev ./start-licence-service.sh" >&2
  exit 1
fi
npm run --silent migrate

# ── 5. Start ───────────────────────────────────────────────────────────────
cat <<EOF

Licence service: http://localhost:${PORT}/v1   (Ctrl-C to stop)

To run OASIS against it, in another terminal:

  export OASIS_LICENSE_URL=http://localhost:${PORT}/v1
  export OASIS_LICENSE_PUBLIC_KEY=${PUBLIC_KEY}

EOF

node src/server.js &
SERVICE_PID=$!
trap 'kill "$SERVICE_PID" 2>/dev/null || true' EXIT INT TERM

for _ in $(seq 1 40); do
  curl -sf -o /dev/null "http://localhost:${PORT}/readyz" 2> /dev/null && break
  kill -0 "$SERVICE_PID" 2> /dev/null || break
  sleep 0.25
done
if curl -sf -o /dev/null "http://localhost:${PORT}/readyz" 2> /dev/null; then
  echo "Ready: http://localhost:${PORT}/readyz"
else
  echo "The service did not become ready." >&2
fi

wait "$SERVICE_PID" || true
