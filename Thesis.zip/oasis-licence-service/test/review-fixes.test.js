'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService, verifyToken } = require('./helpers/server');
const { machine, unique, createCustomer, createLicence, codeFor, q } = require('./helpers/fixtures');
const { createAccess } = require('../src/access');
const { createHasher } = require('../src/secrets');
const { loadConfig } = require('../src/config');
const { rateLimit } = require('../src/rate-limit');

let svc, access;
test.before(async () => { svc = await startService(); access = createAccess({ licenseDb: svc.licenseDb, hash: createHasher(svc.hashPepper) }); });
test.after(async () => { await svc.close(); });

test('a block that has lapsed can be put back', async () => {
  const m = machine();
  await access.block({ type: 'machine', value: m, reason: 'abuse', expiresAt: new Date(Date.now() + 1000) });
  await new Promise(r => setTimeout(r, 1200));
  assert.equal(await access.check({ machineId: m }), null);
  await access.block({ type: 'machine', value: m, reason: 'security' });
  assert.equal(await access.check({ machineId: m }), 'security', 'the second block took effect');
});

test('a token plus someone else\'s machine id cannot free that machine\'s seat', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c, { seats: 5 });
  const [a, b] = [machine(), machine()];
  const ta = (await svc.post('/v1/activate', { machineId: a, licenseKey: lic.licenceKey })).body.token;
  await svc.post('/v1/activate', { machineId: b, licenseKey: lic.licenceKey });
  await svc.post('/v1/deactivate', { machineId: b, token: ta });     // A's token, B's machine id
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [lic.licenseId]))[0].n, 2);
  await svc.post('/v1/deactivate', { machineId: a, token: ta });      // A's own token frees A's own seat
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [lic.licenseId]))[0].n, 1);
});

test('a refused activation does not use up the code: fix the cause and the same code works', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c, { seats: 1 });
  assert.equal((await svc.post('/v1/activate', { machineId: machine(), licenseKey: lic.licenceKey })).status, 200);
  const email = `pat@${c.domain}`, m = machine();
  const code = await codeFor(svc, email, m);
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code })).body.reason, 'seats_full');
  await svc.licenseDb.query('UPDATE license SET seat_limit = 2 WHERE license_id = $1', [lic.licenseId]);
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code })).status, 200, 'the code was still good');
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code })).body.reason, 'no_code', 'and is used up by the success');
});

test('wrong guesses from another machine do not burn the code of the machine that asked', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = `pat@${c.domain}`, mine = machine();
  const code = await codeFor(svc, email, mine);
  const bad = code === '000000' ? '111111' : '000000';
  for (let i = 0; i < 8; i++) assert.equal((await svc.post('/v1/domain/activate', { machineId: machine(), email, code: bad })).status, 400);
  assert.equal((await svc.post('/v1/domain/activate', { machineId: mine, email, code })).status, 200);
});

test('a licence with a gap between its terms is not current during the gap', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c, { days: 30 });
  await svc.licenseDb.query(
    `INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code)
     SELECT gen_random_uuid(), license_id, 2, max(ends_at) + interval '60 days', max(ends_at) + interval '425 days', 'renewal' FROM license_term WHERE license_id = $1 GROUP BY license_id`, [lic.licenseId]);
  await svc.licenseDb.query('ALTER TABLE license_term DISABLE TRIGGER license_term_append_only');
  await svc.licenseDb.query(`UPDATE license_term SET starts_at = now() - interval '40 days', ends_at = now() - interval '10 days' WHERE license_id = $1 AND term_no = 1`, [lic.licenseId]);
  await svc.licenseDb.query('ALTER TABLE license_term ENABLE TRIGGER license_term_append_only');
  const r = await svc.post('/v1/activate', { machineId: machine(), licenseKey: lic.licenceKey });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'expired');
});

test('a trial token\'s issue time comes from the database clock, so it is never at or after its expiry', async () => {
  const m = machine();
  await svc.post('/v1/trial', { machineId: m });
  const rows = await q(svc, `SELECT issued_at, expires_at FROM token_issue t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  assert.ok(rows[0].expires_at > rows[0].issued_at);
  const claims = verifyToken((await svc.post('/v1/revalidate', { machineId: m, token: (await svc.post('/v1/trial', { machineId: m })).body.token })).body.token, svc.publicKey).payload;
  assert.ok(claims.exp > claims.issuedAt);
});

test('a request body the parser cannot read is a 400, not an outage', async () => {
  const res = await fetch(`${svc.base}/v1/trial`, { method: 'POST', headers: { 'content-type': 'application/json; charset=utf-7' }, body: '{}' });
  assert.equal(res.status, 400);
});

test('revalidate and deactivate are not counted against a shared address; the other routes still are', async () => {
  const limited = await startService({ limiter: rateLimit({ max: 3 }) });
  try {
    const m = machine();
    const statuses = [];
    for (let i = 0; i < 6; i++) statuses.push((await limited.post('/v1/revalidate', { machineId: m, token: 'x' })).status);
    assert.ok(statuses.every(s => s === 400), `never 429: ${statuses}`);
    const other = [];
    for (let i = 0; i < 6; i++) other.push((await limited.post('/v1/activate', { machineId: m, licenseKey: 'x' })).status);
    assert.ok(other.includes(429));
  } finally { await limited.close(); }
});

test('production must say how many proxies stand in front, or every customer shares one address', () => {
  const base = { CUSTOMER_DATABASE_URL: 'a', LICENSE_DATABASE_URL: 'b', LICENCE_SIGNING_KEY_PEM: 'pem', HASH_PEPPER: 'p'.repeat(32) };
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1' }), /TRUST_PROXY/);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', TRUST_PROXY: '1' }), /approved email sender/, 'then the sender check');
});
