'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { rateLimit, callerKey } = require('../src/rate-limit');

const run = (limiter, ip) => { let out; limiter({ ip }, {}, err => { out = err || null; }); return out; };

test('the limit counts per caller in a window, then lets the window go', () => {
  let t = 1_000_000;
  const limiter = rateLimit({ max: 3, windowMs: 1000, now: () => t });
  for (let i = 0; i < 3; i++) assert.equal(run(limiter, '203.0.113.7'), null);
  const over = run(limiter, '203.0.113.7');
  assert.equal(over.status, 429); assert.equal(over.reason, 'too_many_requests'); assert.ok(over.extra.retryAfterSeconds >= 1);
  assert.equal(run(limiter, '203.0.113.8'), null, 'another caller is unaffected');
  t += 1001;
  assert.equal(run(limiter, '203.0.113.7'), null, 'a new window');
});

test('an IPv6 address is counted by its /64: one subscriber cannot have billions of buckets', () => {
  assert.equal(callerKey('2001:db8:1:2:aaaa:bbbb:cccc:dddd'), callerKey('2001:db8:1:2::1'));
  assert.equal(callerKey('2001:DB8:1:2:0:0:0:9'), callerKey('2001:db8:1:2::9'));
  assert.notEqual(callerKey('2001:db8:1:3::1'), callerKey('2001:db8:1:2::1'));
  assert.equal(callerKey('::ffff:203.0.113.7'), '203.0.113.7', 'an IPv4 address inside IPv6 is the IPv4 address');
  assert.equal(callerKey('203.0.113.7'), '203.0.113.7');
  assert.equal(callerKey(undefined), 'unknown');
  const limiter = rateLimit({ max: 2 });
  assert.equal(run(limiter, '2001:db8:1:2::1'), null); assert.equal(run(limiter, '2001:db8:1:2::2'), null);
  assert.equal(run(limiter, '2001:db8:1:2:ffff::3').status, 429, 'three addresses in one /64 share the limit');
});

test('memory is bounded: a flood of new callers does not grow it without limit and does not slow each request to a crawl', () => {
  let t = 5_000_000;
  const limiter = rateLimit({ max: 5, windowMs: 60_000, maxKeys: 1000, now: () => t });
  const started = process.hrtime.bigint();
  for (let i = 0; i < 20_000; i++) { t += 1; run(limiter, `198.51.${(i >> 8) & 255}.${i & 255}`); }
  const ms = Number(process.hrtime.bigint() - started) / 1e6;
  assert.ok(ms < 1500, `20,000 distinct callers took ${ms} ms`);
});
