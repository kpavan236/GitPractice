'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService, verifyToken } = require('./helpers/server');
const { createTrialReviewer } = require('../src/trial-review');

let svc;
const DAY = 24 * 60 * 60 * 1000;
test.before(async () => { svc = await startService({ reviewer: createTrialReviewer({ maxPerSource: 3 }) }); });
test.after(async () => { await svc.close(); });

const machine = () => crypto.randomBytes(16).toString('hex');
const q = (sql, params) => svc.licenseDb.query(sql, params).then(r => r.rows);
const start = (m, extra = {}) => svc.post('/v1/trial', { machineId: m, fingerprintSource: 'darwin', platform: 'darwin', arch: 'arm64', appVersion: '2.0.1', ...extra });

test('a new machine gets a signed 7-day trial token the app can verify', async () => {
  const m = machine();
  const before = Date.now();
  const r = await start(m);
  assert.equal(r.status, 200);
  const { ok, header, payload } = verifyToken(r.body.token, svc.publicKey);
  assert.ok(ok, 'signature verifies with the public key');
  assert.equal(header.alg, 'EdDSA');
  assert.match(header.kid, /^test-/);
  assert.equal(payload.tier, 'trial');
  assert.equal(payload.seats, 1);
  assert.deepEqual(payload.features, []);
  assert.equal(payload.customer, null);
  assert.ok(Math.abs(payload.exp - (before + 7 * DAY)) < 5000, 'expires seven days from the server clock');
  assert.ok(Math.abs(r.body.serverTime - Date.now()) < 5000);
});

test('the trial, the installation and the check-in are stored; the token itself is not', async () => {
  const m = machine();
  const r = await start(m);
  const [inst] = await q('SELECT * FROM installation WHERE fingerprint = $1', [m]);
  assert.equal(inst.fingerprint_source_code, 'darwin');
  assert.equal(inst.platform, 'darwin');
  assert.equal(inst.app_version, '2.0.1');
  const [trial] = await q('SELECT * FROM trial WHERE installation_id = $1', [inst.installation_id]);
  assert.equal(trial.status_code, 'ACTIVE');
  assert.equal(trial.source_code, 'oasis-app');
  assert.equal((await q('SELECT count(*)::int AS n FROM installation_check_in WHERE trial_id = $1 AND kind_code = \'trial\'', [trial.trial_id]))[0].n, 1);
  assert.equal((await q('SELECT count(*)::int AS n FROM trial_status_history WHERE trial_id = $1', [trial.trial_id]))[0].n, 1);
  const issued = await q('SELECT * FROM token_issue WHERE trial_id = $1', [trial.trial_id]);
  assert.equal(issued.length, 1);
  assert.ok(!JSON.stringify(issued).includes(r.body.token.slice(20, 60)), 'only the id of the token is recorded');
  const cols = (await q(`SELECT column_name FROM information_schema.columns WHERE table_name IN ('installation','trial','token_issue','trial_integration')`)).map(c => c.column_name);
  for (const bad of ['hostname', 'username', 'ip', 'ip_address', 'token', 'password', 'phone']) assert.ok(!cols.includes(bad), `no ${bad} column`);
});

test('asking again returns the ORIGINAL expiry: reinstalling buys nothing', async () => {
  const m = machine();
  const first = verifyToken((await start(m)).body.token, svc.publicKey).payload;
  await new Promise(r => setTimeout(r, 1100));
  const again = verifyToken((await start(m)).body.token, svc.publicKey).payload;
  assert.equal(again.exp, first.exp);
  assert.equal((await q('SELECT count(*)::int AS n FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1', [m]))[0].n, 1);
});

test('nothing the app sends can set the start or the expiry', async () => {
  const m = machine();
  const r = await start(m, { startedAt: 1, exp: Date.now() + 900 * DAY, expiresAt: '2099-01-01', trialDays: 900, tier: 'enterprise', features: ['security'] });
  const { payload } = verifyToken(r.body.token, svc.publicKey);
  assert.ok(payload.exp < Date.now() + 8 * DAY);
  assert.equal(payload.tier, 'trial');
  assert.deepEqual(payload.features, []);
});

test('ten first requests at once make one trial', async () => {
  const m = machine();
  const answers = await Promise.all(Array.from({ length: 10 }, () => start(m)));
  assert.ok(answers.every(a => a.status === 200), JSON.stringify(answers.map(a => a.status)));
  assert.equal(new Set(answers.map(a => verifyToken(a.body.token, svc.publicKey).payload.exp)).size, 1);
  assert.equal((await q('SELECT count(*)::int AS n FROM installation WHERE fingerprint = $1', [m]))[0].n, 1);
  assert.equal((await q('SELECT count(*)::int AS n FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1', [m]))[0].n, 1);
});

test('a missing or odd machine id is refused', async () => {
  for (const machineId of [undefined, '', 'short', 'x'.repeat(65), 'has spaces in it xxxxxxxx', 12345, { a: 1 }]) {
    const r = await svc.post('/v1/trial', { machineId });
    assert.equal(r.status, 400, JSON.stringify(machineId));
    assert.equal(r.body.reason, 'bad_machine_id');
  }
});

test('setup addresses are kept without credentials, and the first ones stay', async () => {
  const m = machine();
  await start(m, { integration: { jenkinsUrl: 'https://user:s3cr3t-token@jenkins.acme.example.test/job/x?token=abc#frag', githubUrl: 'https://github.acme.example.test/', org: 'acme-eng', token: 'ghp_shouldneverbehere' } });
  await start(m, { integration: { jenkinsUrl: 'https://elsewhere.example.test', org: 'someone-else' } });
  const [row] = await q(`SELECT ti.* FROM trial_integration ti JOIN trial t USING (trial_id) JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  assert.equal(row.jenkins_url, 'https://jenkins.acme.example.test/job/x');
  assert.equal(row.github_url, 'https://github.acme.example.test');
  assert.equal(row.github_org, 'acme-eng');
  assert.ok(!JSON.stringify(row).includes('s3cr3t') && !JSON.stringify(row).includes('ghp_'));
});

test('a weak machine id is flagged for review, a normal one is not; neither is refused', async () => {
  const weak = await start(machine(), { fingerprintSource: 'fallback' });
  const missing = await start(machine(), { fingerprintSource: undefined });
  const strong = await start(machine(), { fingerprintSource: 'linux' });
  assert.deepEqual([weak.status, missing.status, strong.status], [200, 200, 200]);
  const flags = await q(`SELECT i.fingerprint_source_code AS src, f.flag_code FROM trial_review_flag f JOIN trial t USING (trial_id) JOIN installation i USING (installation_id)`);
  assert.ok(flags.some(f => f.src === 'fallback' && f.flag_code === 'weak_fingerprint'));
  assert.ok(flags.some(f => f.src === 'unknown' && f.flag_code === 'weak_fingerprint'));
  assert.ok(!flags.some(f => f.src === 'linux' && f.flag_code === 'weak_fingerprint'), 'a real hardware id is not called weak');
});

test('many first trials from one address are flagged, not refused, and the address is never stored', async () => {
  const other = await startService({ reviewer: createTrialReviewer({ maxPerSource: 2 }) });
  try {
    const answers = [];
    for (let i = 0; i < 4; i++) answers.push(await other.post('/v1/trial', { machineId: machine(), fingerprintSource: 'darwin' }));
    assert.ok(answers.every(a => a.status === 200));
    const flagged = (await other.licenseDb.query(`SELECT count(*)::int AS n FROM trial_review_flag WHERE flag_code = 'many_first_trials_from_one_source'`)).rows[0].n;
    assert.equal(flagged, 2, 'the third and fourth');
    const dump = JSON.stringify((await other.licenseDb.query('SELECT * FROM installation')).rows) + JSON.stringify(other.logs);
    assert.ok(!dump.includes('127.0.0.1'), 'the caller address is in no row and no log line');
  } finally { await other.close(); }
});

test('an ended trial is refused, and recorded as expired with a reason', async () => {
  const m = machine();
  const instId = crypto.randomUUID(), trialId = crypto.randomUUID();
  await q(`INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code) VALUES ($1, $2, 'darwin')`, [instId, m]);
  await q(`INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '10 days', now() - interval '3 days')`, [trialId, instId]);
  const r = await start(m);
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'trial_ended');
  assert.equal(r.body.token, undefined);
  const [t] = await q('SELECT status_code FROM trial WHERE trial_id = $1', [trialId]);
  assert.equal(t.status_code, 'EXPIRED', 'the refusal still leaves the record honest');
  assert.equal((await q(`SELECT count(*)::int AS n FROM trial_status_history WHERE trial_id = $1 AND to_status_code = 'EXPIRED' AND reason = 'Trial ended'`, [trialId]))[0].n, 1);
  assert.equal((await q('SELECT count(*)::int AS n FROM token_issue WHERE trial_id = $1', [trialId]))[0].n, 0, 'no token for an ended trial');
  assert.equal((await start(m)).body.reason, 'trial_ended', 'and it stays refused');
});

test('an extension given by support is honoured', async () => {
  const m = machine();
  const first = await start(m);
  const [t] = await q(`SELECT t.trial_id, t.expires_at FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  await q(`UPDATE trial SET extended_until = expires_at + interval '14 days', extended_by_user_id = $2 WHERE trial_id = $1`, [t.trial_id, crypto.randomUUID()]);
  const again = verifyToken((await start(m)).body.token, svc.publicKey).payload;
  assert.ok(again.exp > verifyToken(first.body.token, svc.publicKey).payload.exp + 13 * DAY);
});

test('a machine whose trial became a licence is told to activate it', async () => {
  const m = machine();
  await start(m);
  const [t] = await q(`SELECT t.trial_id FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  const lic = crypto.randomUUID();
  await q(`INSERT INTO license (license_id, customer_id, plan_code, license_key_hash, key_hint, kind_code, seat_limit) VALUES ($1, $2, 'team', $3, 'T001', 'paid', 10)`, [lic, crypto.randomUUID(), crypto.randomBytes(32).toString('hex')]);
  const c = await svc.licenseDb.connect();
  try {
    await c.query('BEGIN');
    await c.query(`SELECT set_config('app.reason', 'Customer bought a licence', true)`);
    await c.query(`UPDATE trial SET status_code = 'CONVERTED', converted_license_id = $2, converted_at = now() WHERE trial_id = $1`, [t.trial_id, lic]);
    await c.query('COMMIT');
  } finally { c.release(); }
  const r = await start(m);
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'trial_converted');
});

test('the trial length comes from configuration', async () => {
  const other = await startService({ trialDays: 30 });
  try {
    const { payload } = verifyToken((await other.post('/v1/trial', { machineId: machine(), fingerprintSource: 'darwin' })).body.token, other.publicKey);
    assert.ok(Math.abs(payload.exp - (Date.now() + 30 * DAY)) < 5000);
  } finally { await other.close(); }
});

test('no token, machine id or address appears in any log line', async () => {
  const m = machine();
  const r = await start(m, { integration: { jenkinsUrl: 'https://jenkins.canary.example.test' } });
  const all = JSON.stringify(svc.logs);
  assert.ok(!all.includes(r.body.token.slice(10, 50)));
  assert.ok(!all.includes(m));
  assert.ok(!all.includes('canary'));
});

test('an ended trial that support extends (EXPIRED back to ACTIVE, with a reason) gets a token again, and a converted one never moves', async () => {
  const m = machine();
  const instId = crypto.randomUUID(), trialId = crypto.randomUUID();
  await q(`INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code) VALUES ($1, $2, 'darwin')`, [instId, m]);
  await q(`INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '10 days', now() - interval '3 days')`, [trialId, instId]);
  assert.equal((await start(m)).body.reason, 'trial_ended');                       // recorded as EXPIRED
  await q(`WITH r AS (SELECT set_config('app.reason', 'Support extended the trial', true)) UPDATE trial SET status_code = 'ACTIVE', extended_until = now() + interval '5 days', extended_by_user_id = gen_random_uuid() FROM r WHERE trial_id = $1`, [trialId]);
  const again = await start(m);
  assert.equal(again.status, 200);
  assert.ok(Math.abs(verifyToken(again.body.token, svc.publicKey).payload.exp - (Date.now() + 5 * DAY)) < 10_000);
  const moves = (await q(`SELECT from_status_code || '>' || to_status_code AS m FROM trial_status_transition`)).map(r => r.m);
  assert.ok(moves.includes('EXPIRED>ACTIVE'));
  assert.ok(!moves.some(m => m.startsWith('CONVERTED>')), 'a converted trial never moves again');
});
