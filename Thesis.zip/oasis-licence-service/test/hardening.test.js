'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { loadConfig } = require('../src/config');
const { createShutdown } = require('../src/shutdown');
const { startService } = require('./helpers/server');

const base = { CUSTOMER_DATABASE_URL: 'postgres://x/c', LICENSE_DATABASE_URL: 'postgres://x/l', LICENCE_SIGNING_KEY_PEM: 'pem', HASH_PEPPER: 'p'.repeat(32) };
const prod = { ...base, NODE_ENV: 'production', TRUST_PROXY: '0', NOTIFIER: 'fake' };

test('TLS settings: both or neither; files are read at start-up', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tls-'));
  const cert = path.join(dir, 'c.pem'), key = path.join(dir, 'k.pem');
  fs.writeFileSync(cert, 'synthetic-cert'); fs.writeFileSync(key, 'synthetic-key');
  const c = loadConfig({ ...base, TLS_CERT_FILE: cert, TLS_KEY_FILE: key });
  assert.equal(c.tls.cert.toString(), 'synthetic-cert');
  assert.equal(c.tls.key.toString(), 'synthetic-key');
  assert.equal(loadConfig(base).tls, null);
  assert.throws(() => loadConfig({ ...base, TLS_CERT_FILE: cert }), /TLS_KEY_FILE/);
  assert.throws(() => loadConfig({ ...base, TLS_KEY_FILE: key }), /TLS_CERT_FILE/);
  assert.throws(() => loadConfig({ ...base, TLS_CERT_FILE: cert, TLS_KEY_FILE: path.join(dir, 'missing') }), /TLS_KEY_FILE/);
  fs.rmSync(dir, { recursive: true });
});

test('production needs TLS unless ALLOW_PLAIN_HTTP=1 is set on purpose', () => {
  // Production also refuses the fake notifier, so the TLS refusal is checked by its own message appearing first.
  assert.throws(() => loadConfig(prod), /TLS_CERT_FILE and TLS_KEY_FILE|ALLOW_PLAIN_HTTP/);
  assert.throws(() => loadConfig({ ...prod, ALLOW_PLAIN_HTTP: '0' }), /ALLOW_PLAIN_HTTP/);
  assert.throws(() => loadConfig({ ...prod, ALLOW_PLAIN_HTTP: '1' }), /approved email sender/, 'passes the TLS check, then hits the next production rule');
  assert.equal(loadConfig({ ...base, ALLOW_PLAIN_HTTP: '1' }).allowPlainHttp, true);
  assert.equal(loadConfig(base).allowPlainHttp, false);
});

test('shutdown timeout setting', () => {
  assert.equal(loadConfig(base).shutdownTimeoutMs, 10_000);
  assert.equal(loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: '500' }).shutdownTimeoutMs, 500);
  assert.throws(() => loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: 'x' }), /SHUTDOWN_TIMEOUT_MS/);
});

function fakeServer({ closes = true } = {}) {
  const s = new EventEmitter();
  s.calls = [];
  s.close = cb => { s.calls.push('close'); if (closes) setImmediate(cb); };
  s.closeIdleConnections = () => s.calls.push('closeIdle');
  s.closeAllConnections = () => s.calls.push('closeAll');
  return s;
}

test('shutdown: stops accepting, closes idle connections, ends both pools, exits 0', async () => {
  const server = fakeServer(), ended = [], exits = [];
  const stop = createShutdown({ server, pools: [{ end: async () => ended.push('a') }, { end: async () => ended.push('b') }], timeoutMs: 1000, exit: c => exits.push(c), log: () => {} });
  await stop('SIGTERM');
  assert.deepEqual(server.calls.slice(0, 2), ['close', 'closeIdle']);
  assert.deepEqual(ended.sort(), ['a', 'b']);
  assert.deepEqual(exits, [0]);
});

test('shutdown: a second signal does nothing; a failing pool does not block exit', async () => {
  const server = fakeServer(), exits = [];
  const stop = createShutdown({ server, pools: [{ end: async () => { throw new Error('x'); } }], timeoutMs: 1000, exit: c => exits.push(c), log: () => {} });
  await Promise.all([stop('SIGTERM'), stop('SIGINT')]);
  assert.equal(server.calls.filter(c => c === 'close').length, 1);
  assert.deepEqual(exits, [0]);
});

test('shutdown: connections that will not drain are force-closed at the timeout and the exit code is 1', async () => {
  const server = fakeServer({ closes: false }), exits = [];
  const stop = createShutdown({ server, pools: [], timeoutMs: 20, exit: c => exits.push(c), log: () => {} });
  await stop('SIGTERM');
  assert.ok(server.calls.includes('closeAll'));
  assert.deepEqual(exits, [1]);
});

test('every answer says no-referrer; HSTS only when TLS is on', async () => {
  const plain = await startService();
  const tls = await startService({ hsts: true });
  try {
    const a = await plain.get('/healthz'), b = await tls.get('/healthz');
    assert.equal(a.headers.get('referrer-policy'), 'no-referrer');
    assert.equal(a.headers.get('strict-transport-security'), null);
    assert.equal(b.headers.get('referrer-policy'), 'no-referrer');
    assert.match(b.headers.get('strict-transport-security'), /max-age=\d+/);
  } finally { await plain.close(); await tls.close(); }
});
