'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { isFreeEmailDomain } = require('../src/free-email-domains');

test('common personal providers are free-email domains', () => {
  for (const d of ['gmail.com', 'googlemail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'live.com', 'icloud.com', 'proton.me', 'protonmail.com', 'aol.com']) {
    assert.equal(isFreeEmailDomain(d), true, d);
  }
});

test('matching ignores case and also covers subdomains of a free provider', () => {
  assert.equal(isFreeEmailDomain('GMAIL.COM'), true);
  assert.equal(isFreeEmailDomain('mail.gmail.com'), true);
});

test('a company domain is not a free-email domain, and a look-alike suffix does not match', () => {
  assert.equal(isFreeEmailDomain('acme.example.test'), false);
  assert.equal(isFreeEmailDomain('notgmail.com'), false);
  assert.equal(isFreeEmailDomain('gmail.com.example.test'), false);
});

test('extra domains from the settings are blocked too', () => {
  assert.equal(isFreeEmailDomain('mailbox.example.test', ['mailbox.example.test']), true);
  assert.equal(isFreeEmailDomain('acme.example.test', ['mailbox.example.test']), false);
});

test('a missing or non-string domain is treated as not usable, not as free', () => {
  assert.equal(isFreeEmailDomain(null), false);
  assert.equal(isFreeEmailDomain(undefined), false);
});
