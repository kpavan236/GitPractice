'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Pool } = require('pg');
const { startService } = require('./helpers/server');
const { verifiedForm } = require('./helpers/purchase');
const { MAX_PER_ADDRESS_PER_HOUR } = require('../src/routes/purchase-request');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const form = (over = {}) => ({ organization: 'Acme Example Ltd', employees: 120, email: 'Pat@Acme.Example.Test', contactName: 'Pat Example', appVersion: '2.0.1', ...over });
const rows = (sql, params) => svc.customerDb.query(sql, params).then(r => r.rows);
const vform = (over, service = svc) => verifiedForm(service, form(over));
let n = 0;
const key = () => `test-key-${++n}-${Date.now()}`;

test('a valid request is stored, with a reference, and only the four fields the form asks for', async () => {
  const r = await svc.post('/v1/purchase-request', { ...(await vform({ email: 'a1@acme.example.test' })), status: 'AGREED', customer_id: '00000000-0000-0000-0000-000000000001', phone: '555 0100' }, { 'Idempotency-Key': key() });
  assert.equal(r.status, 200);
  assert.match(r.body.reference, /^PR-\d{6}$/);
  const [row] = await rows('SELECT * FROM purchase_request WHERE reference = $1', [r.body.reference]);
  assert.equal(row.organization_name, 'Acme Example Ltd');
  assert.equal(row.employee_count, 120);
  assert.equal(row.email, 'a1@acme.example.test', 'stored lower-case');
  assert.equal(row.contact_name, 'Pat Example');
  assert.equal(row.status_code, 'NEW', 'a customer cannot set the status');
  assert.equal(row.customer_id, null, 'or link themselves to a customer');
  assert.equal(row.source_code, 'oasis-app');
  assert.equal(row.app_version, '2.0.1');
  const history = await rows('SELECT to_status_code FROM purchase_request_status_history WHERE purchase_request_id = $1', [row.purchase_request_id]);
  assert.deepEqual(history.map(h => h.to_status_code), ['NEW']);
});

test('a request with problems is refused with a message per field, and nothing is stored', async () => {
  const before = (await rows('SELECT count(*)::int AS n FROM purchase_request'))[0].n;
  const r = await svc.post('/v1/purchase-request', { organization: '', employees: 'lots', email: 'not-an-email', contactName: '' });
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'invalid');
  for (const f of ['organization', 'employees', 'email', 'contactName']) assert.ok(r.body.errors[f], `a message for ${f}`);
  assert.ok(r.body.requestId);
  assert.equal((await rows('SELECT count(*)::int AS n FROM purchase_request'))[0].n, before);
});

test('the same Idempotency-Key twice is one request with the first reference', async () => {
  const k = key();
  const body = await vform({ email: 'idem@acme.example.test' });
  const first = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': k });
  const again = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': k });
  assert.equal(again.status, 200);
  assert.equal(again.body.reference, first.body.reference);
  assert.equal(again.headers.get('idempotent-replay'), 'true');
  assert.equal(first.headers.get('idempotent-replay'), null);
  assert.equal((await rows('SELECT count(*)::int AS n FROM purchase_request WHERE email = $1', ['idem@acme.example.test']))[0].n, 1);
  const other = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': key() });
  assert.notEqual(other.body.reference, first.body.reference, 'a different key is a different request');
});

test('copies of the same submit arriving together make one row', async () => {
  const k = key();
  const body = await vform({ email: 'race@acme.example.test' });
  const answers = await Promise.all(Array.from({ length: 8 }, () => svc.post('/v1/purchase-request', body, { 'Idempotency-Key': k })));
  assert.ok(answers.every(a => a.status === 200), JSON.stringify(answers.map(a => a.status)));
  assert.equal(new Set(answers.map(a => a.body.reference)).size, 1);
  assert.equal((await rows('SELECT count(*)::int AS n FROM purchase_request WHERE email = $1', ['race@acme.example.test']))[0].n, 1);
});

test('a malformed key is ignored, not refused, and never stored', async () => {
  const r = await svc.post('/v1/purchase-request', await vform({ email: 'badkey@acme.example.test' }), { 'Idempotency-Key': 'short' });
  assert.equal(r.status, 200);
  const [row] = await rows('SELECT idempotency_key FROM purchase_request WHERE reference = $1', [r.body.reference]);
  assert.equal(row.idempotency_key, null);
});

test('one address is limited per hour, but a genuine retry of an earlier submit still gets its answer', async () => {
  const email = 'flood@acme.example.test';
  const body = await vform({ email });     // one proof serves every submit: asking for a code is itself limited per address
  const keys = [];
  for (let i = 0; i < MAX_PER_ADDRESS_PER_HOUR; i++) {
    keys.push(key());
    assert.equal((await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': keys[i] })).status, 200);
  }
  const over = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': key() });
  assert.equal(over.status, 429);
  assert.equal(over.body.reason, 'too_many_requests');
  const retry = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': keys[0] });
  assert.equal(retry.status, 200, 'the retry is not a new request, so the limit does not apply');
  assert.equal((await rows('SELECT count(*)::int AS n FROM purchase_request WHERE email = $1', [email]))[0].n, MAX_PER_ADDRESS_PER_HOUR);
});

test('quotes, markup and control characters are stored as text, never executed or kept as line breaks', async () => {
  const r = await svc.post('/v1/purchase-request', await vform({ email: 'x@acme.example.test', organization: "Acme'); DROP TABLE purchase_request;--\r\n<b>x</b>", contactName: 'Pat\u0000 Example' }), { 'Idempotency-Key': key() });
  assert.equal(r.status, 200);
  const [row] = await rows('SELECT organization_name, contact_name FROM purchase_request WHERE reference = $1', [r.body.reference]);
  assert.equal(row.organization_name, "Acme'); DROP TABLE purchase_request;-- <b>x</b>");
  assert.equal(row.contact_name, 'Pat Example');
  assert.ok((await rows('SELECT count(*)::int AS n FROM purchase_request'))[0].n > 0);
});

test('oversized and malformed bodies are refused cleanly', async () => {
  const big = await svc.post('/v1/purchase-request', { ...form(), organization: 'x'.repeat(40_000) });
  assert.equal(big.status, 413);
  const bad = await svc.post('/v1/purchase-request', '{"organization": ');
  assert.equal(bad.status, 400);
  assert.equal(bad.body.reason, 'bad_json');
  const none = await fetch(`${svc.base}/v1/purchase-request`, { method: 'POST' });
  assert.equal(none.status, 400, 'an empty body is a refusal, not a crash');
});

test('no email, name or organization is ever written to a log line', async () => {
  const email = 'secretlog@acme.example.test';
  await svc.post('/v1/purchase-request', await vform({ email, organization: 'LogCanaryOrg', contactName: 'LogCanaryName' }), { 'Idempotency-Key': key() });
  const all = JSON.stringify(svc.logs);
  for (const s of [email, 'LogCanaryOrg', 'LogCanaryName']) assert.ok(!all.includes(s), `${s} must not appear in logs`);
});

test('a database failure is a 500 that says nothing about the cause', async () => {
  const broken = new Pool({ connectionString: 'postgres://nobody:wrong@127.0.0.1:1/none', max: 1, connectionTimeoutMillis: 500 });
  broken.on('error', () => {});
  const other = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb }, customerDb: broken });
  try {
    const r = await other.post('/v1/purchase-request', await vform({ email: 'down@acme.example.test' }), { 'Idempotency-Key': key() });
    assert.equal(r.status, 500, 'a fault on our side is never a refusal, so the app does not lock anyone out');
    assert.equal(r.body.error, 'internal');
    assert.ok(!/127\.0\.0\.1|nobody|ECONN/i.test(JSON.stringify(r.body)));
    assert.ok(other.logs.some(l => l.level === 'error'));
  } finally { await other.close(); await broken.end().catch(() => {}); }
});

// ── The support mailbox (fake sender until an email provider is approved) ────

test('a new request tells the support mailbox once, with what support needs to reply', async () => {
  const before = svc.notifier.supportNotices.length;
  const r = await svc.post('/v1/purchase-request', await vform({ email: 'notice1@acme.example.test', organization: 'Notice Example Ltd', employees: 42, contactName: 'Nia Example' }), { 'Idempotency-Key': key() });
  assert.equal(r.status, 200);
  assert.equal(svc.notifier.supportNotices.length, before + 1);
  assert.deepEqual(svc.notifier.lastSupportNotice(), { to: 'support@support.example.test', reference: r.body.reference, organization: 'Notice Example Ltd', employees: 42, contactName: 'Nia Example', email: 'notice1@acme.example.test', at: svc.notifier.lastSupportNotice().at });
});

test('a replay, a refused request and a request over the limit send nothing', async () => {
  const k = key(), body = await vform({ email: 'notice2@acme.example.test' });
  await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': k });
  const after = svc.notifier.supportNotices.length;
  const replay = await svc.post('/v1/purchase-request', body, { 'Idempotency-Key': k });
  assert.equal(replay.headers.get('idempotent-replay'), 'true');
  assert.equal((await svc.post('/v1/purchase-request', { organization: '', employees: 'x', email: 'bad', contactName: '' })).status, 400);
  assert.equal(svc.notifier.supportNotices.length, after, 'neither a replay nor an invalid form announces anything');
  const busy = await vform({ email: 'busy@acme.example.test' });
  for (let i = 0; i < MAX_PER_ADDRESS_PER_HOUR; i++) await svc.post('/v1/purchase-request', busy, { 'Idempotency-Key': key() });
  const count = svc.notifier.supportNotices.length;
  assert.equal((await svc.post('/v1/purchase-request', busy, { 'Idempotency-Key': key() })).status, 429);
  assert.equal(svc.notifier.supportNotices.length, count);
});

test('if the email cannot be sent the request is still stored and the app is told it worked; the fault is logged without the details', async () => {
  const failing = await startService();
  try {
    failing.notifier.notifySupport = async () => { throw new Error('provider down: contact failing@acme.example.test'); };
    const r = await failing.post('/v1/purchase-request', await vform({ email: 'failing@acme.example.test' }, failing), { 'Idempotency-Key': key() });
    assert.equal(r.status, 200);
    assert.match(r.body.reference, /^PR-\d{6}$/);
    assert.equal((await failing.customerDb.query('SELECT count(*)::int AS n FROM purchase_request WHERE reference = $1', [r.body.reference])).rows[0].n, 1);
    const line = failing.logs.find(l => l.msg === 'support notice not sent');
    assert.ok(line && line.reference === r.body.reference);
    assert.ok(!JSON.stringify(failing.logs).includes('failing@acme.example.test'));
  } finally { await failing.close(); }
});

test('with no support mailbox configured nothing is sent, and the request works as before', async () => {
  const quiet = await startService({ supportMailbox: null });
  try {
    const r = await quiet.post('/v1/purchase-request', await vform({ email: 'quiet@acme.example.test' }, quiet), { 'Idempotency-Key': key() });
    assert.equal(r.status, 200);
    assert.equal(quiet.notifier.supportNotices.length, 0);
  } finally { await quiet.close(); }
});

test('the support notice (which holds a customer\'s name and address) never appears in a log line', async () => {
  await svc.post('/v1/purchase-request', await vform({ email: 'lognotice@acme.example.test', contactName: 'Logan Example' }), { 'Idempotency-Key': key() });
  const text = JSON.stringify(svc.logs);
  assert.ok(!text.includes('lognotice@') && !text.includes('Logan Example'));
});

test('an email address with a control or hidden character is a refusal on the form, never a 500', async () => {
  for (const email of ['a\u0000b@acme.example.test', 'a​b@acme.example.test', 'a‮b@acme.example.test', 'a﻿b@acme.example.test', 'a\u0085b@acme.example.test']) {
    const r = await svc.post('/v1/purchase-request', form({ email }), { 'Idempotency-Key': key() });
    assert.equal(r.status, 400, JSON.stringify(email)); assert.ok(r.body.errors.email);
  }
});
