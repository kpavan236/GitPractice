'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService, verifyToken } = require('./helpers/server');
const { signToken } = require('../src/token');
const { DAY, machine, createCustomer, createLicence, q } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const post = (route, body) => svc.post(`/v1/${route}`, { appVersion: '2.0.2', ...body });
async function activated(opts = {}) {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c, opts);
  const m = machine();
  const r = await post('activate', { machineId: m, licenseKey: lic.licenceKey });
  assert.equal(r.status, 200);
  return { c, lic, m, token: r.body.token };
}
const setStatus = (id, status) => svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = $2 FROM r WHERE license_id = $1`, [id, status]);

test('revalidating returns a fresh token with a new grace window, and records the check-in', async () => {
  const { lic, m, token } = await activated({ plan: 'team' });
  const old = verifyToken(token, svc.publicKey).payload;
  await new Promise(r => setTimeout(r, 1100));
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(r.status, 200);
  const fresh = verifyToken(r.body.token, svc.publicKey);
  assert.ok(fresh.ok);
  assert.equal(fresh.payload.licenseId, old.licenseId);
  assert.equal(fresh.payload.exp, old.exp);
  assert.ok(fresh.payload.issuedAt > old.issuedAt);
  assert.ok(fresh.payload.graceUntil > old.graceUntil, 'each success starts a fresh grace window');
  assert.notEqual(fresh.payload.jti, old.jti);
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM installation_check_in WHERE license_id = $1 AND kind_code = 'revalidate'`, [lic.licenseId]))[0].n, 1);
  const [inst] = await q(svc, 'SELECT app_version FROM installation WHERE fingerprint = $1', [m]);
  assert.equal(inst.app_version, '2.0.2', 'the version the machine runs is kept current');
});

test('revalidation still works after the token itself has expired: the server decides, not the token', async () => {
  const { lic, m, token } = await activated();
  const claims = verifyToken(token, svc.publicKey).payload;
  const lapsed = signToken({ ...claims, issuedAt: claims.issuedAt - 400 * DAY, exp: Date.now() - DAY, graceUntil: Date.now() - DAY }, svc.privateKey, { kid: svc.kid });
  const r = await post('revalidate', { machineId: m, token: lapsed });
  assert.equal(r.status, 200);
  const fresh = verifyToken(r.body.token, svc.publicKey).payload;
  assert.equal(fresh.licenseId, lic.licenseId);
  assert.ok(fresh.exp > Date.now(), 'the new token carries the licence\'s real expiry');
});

test('a token from another machine cannot keep this machine alive', async () => {
  const { token } = await activated({ seats: 5 });
  const other = machine();
  const r = await post('revalidate', { machineId: other, token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'not_activated');
  assert.equal(r.body.token, undefined);
});

test('after deactivation the machine is no longer activated, and repeating is harmless', async () => {
  const { lic, m, token } = await activated({ seats: 1 });
  const d = await post('deactivate', { machineId: m, token });
  assert.equal(d.status, 200);
  assert.equal(d.body.ok, true);
  assert.ok(Math.abs(d.body.serverTime - Date.now()) < 5000);
  assert.equal((await post('deactivate', { machineId: m, token })).status, 200, 'safe to repeat');
  const [seat] = await q(svc, `SELECT released_at, release_reason_code FROM activation WHERE license_id = $1`, [lic.licenseId]);
  assert.ok(seat.released_at);
  assert.equal(seat.release_reason_code, 'user');

  const r = await post('revalidate', { machineId: m, token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'not_activated');
});

test('the freed seat can be taken by another machine, and the first can come back only if there is room', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c, { seats: 1 });
  const [a, b] = [machine(), machine()];
  const first = await post('activate', { machineId: a, licenseKey: lic.licenceKey });
  assert.equal((await post('activate', { machineId: b, licenseKey: lic.licenceKey })).body.reason, 'seats_full');
  await post('deactivate', { machineId: a, token: first.body.token });
  assert.equal((await post('activate', { machineId: b, licenseKey: lic.licenceKey })).status, 200);
  assert.equal((await post('activate', { machineId: a, licenseKey: lic.licenceKey })).body.reason, 'seats_full');
});

test('deactivating with a token never frees someone else\'s seat', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c, { seats: 5 });
  const [a, b] = [machine(), machine()];
  const ta = (await post('activate', { machineId: a, licenseKey: lic.licenceKey })).body.token;
  await post('activate', { machineId: b, licenseKey: lic.licenceKey });
  await post('deactivate', { machineId: crypto.randomBytes(16).toString('hex'), token: ta });
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [lic.licenseId]))[0].n, 2);
});

test('a revoked, suspended or ended licence is refused at the next revalidation, with its reason', async () => {
  for (const [status, reason] of [['CANCELLED', 'revoked'], ['SUSPENDED', 'suspended']]) {
    const { lic, m, token } = await activated();
    await setStatus(lic.licenseId, status);
    const r = await post('revalidate', { machineId: m, token });
    assert.equal(r.status, 403, status);
    assert.equal(r.body.reason, reason);
  }
  const { lic, m, token } = await activated();
  await svc.licenseDb.query('ALTER TABLE license_term DISABLE TRIGGER license_term_append_only');
  await svc.licenseDb.query(`UPDATE license_term SET starts_at = now() - interval '400 days', ends_at = now() - interval '1 day' WHERE license_id = $1`, [lic.licenseId]);
  await svc.licenseDb.query('ALTER TABLE license_term ENABLE TRIGGER license_term_append_only');
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'expired');
  assert.equal(r.body.token, undefined);
});

test('a renewal (a new term) is picked up at the next revalidation', async () => {
  const { lic, m, token } = await activated({ days: 30 });
  const before = verifyToken(token, svc.publicKey).payload.exp;
  await svc.licenseDb.query(
    `INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code)
     SELECT gen_random_uuid(), license_id, 2, max(ends_at), max(ends_at) + interval '365 days', 'renewal' FROM license_term WHERE license_id = $1 GROUP BY license_id`, [lic.licenseId]);
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(verifyToken(r.body.token, svc.publicKey).payload.exp - before, 365 * DAY);
});

test('a garbage, truncated, tampered, alg-none or foreign-key token is a refusal, never an error', async () => {
  const { token, m } = await activated();
  const [h, p, s] = token.split('.');
  const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
  const payload = JSON.parse(Buffer.from(p, 'base64url').toString());
  const foreign = crypto.generateKeyPairSync('ed25519').privateKey;
  const forge = (header, body, key) => { const input = `${b64(header)}.${b64(body)}`; return `${input}.${crypto.sign(null, Buffer.from(input), key).toString('base64url')}`; };
  const kid = JSON.parse(Buffer.from(h, 'base64url').toString()).kid;
  const bad = [
    undefined, null, '', 'abc', 'a.b.c', 12345, { a: 1 }, 'x'.repeat(5000), token.slice(0, -4),
    `${h}.${b64({ ...payload, tier: 'enterprise' })}.${s}`,
    `${b64({ alg: 'none', typ: 'JWT', kid })}.${p}.`,
    `${b64({ alg: 'HS256', typ: 'JWT', kid })}.${p}.${s}`,
    forge({ alg: 'EdDSA', typ: 'JWT', kid }, payload, foreign),
    forge({ alg: 'EdDSA', typ: 'JWT', kid: 'nope' }, payload, foreign),
  ];
  for (const t of bad) {
    for (const route of ['revalidate', 'deactivate']) {
      const r = await post(route, { machineId: m, token: t });
      assert.equal(r.status, 400, `${route}: ${String(t).slice(0, 30)}`);
      assert.equal(r.body.reason, 'bad_token');
    }
  }
});

test('a token we signed whose licence id is not an id is a refusal too', async () => {
  const { m, token } = await activated();
  const claims = verifyToken(token, svc.publicKey).payload;
  for (const licenseId of ['not-a-uuid', 42, null, "' OR 1=1 --"]) {
    const t = signToken({ ...claims, licenseId }, svc.privateKey, { kid: svc.kid });
    for (const route of ['revalidate', 'deactivate']) {
      const r = await post(route, { machineId: m, token: t });
      assert.equal(r.status, route === 'deactivate' ? 200 : 400, `${route} ${licenseId}`);
    }
  }
  assert.equal((await post('revalidate', { machineId: m, token })).status, 200, 'the real token still works');
});

// ── Trials ──────────────────────────────────────────────────────────────────────
const trial = async () => {
  const m = machine();
  const r = await svc.post('/v1/trial', { machineId: m, fingerprintSource: 'darwin' });
  return { m, token: r.body.token };
};

test('a running trial is revalidated with a new token for the same expiry', async () => {
  const { m, token } = await trial();
  const first = verifyToken(token, svc.publicKey).payload;
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(r.status, 200);
  const next = verifyToken(r.body.token, svc.publicKey).payload;
  assert.equal(next.tier, 'trial');
  assert.equal(next.exp, first.exp);
  assert.equal(next.licenseId, first.licenseId);
  assert.notEqual(next.jti, first.jti);
});

test('an extension given by support reaches the app at its next revalidation', async () => {
  const { m, token } = await trial();
  const first = verifyToken(token, svc.publicKey).payload;
  await svc.licenseDb.query(
    `UPDATE trial SET extended_until = expires_at + interval '7 days', extended_by_user_id = gen_random_uuid() WHERE installation_id = (SELECT installation_id FROM installation WHERE fingerprint = $1)`, [m]);
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(verifyToken(r.body.token, svc.publicKey).payload.exp - first.exp, 7 * DAY);
});

test('an ended trial is refused (403 trial_ended) and a trial token cannot be used by another machine', async () => {
  const { m, token } = await trial();
  const r0 = await post('revalidate', { machineId: machine(), token });
  assert.equal(r0.status, 403);
  assert.equal(r0.body.reason, 'not_activated');

  await svc.licenseDb.query('ALTER TABLE trial DISABLE TRIGGER trial_before_update');
  await svc.licenseDb.query(`UPDATE trial SET started_at = now() - interval '30 days', expires_at = now() - interval '23 days' WHERE installation_id = (SELECT installation_id FROM installation WHERE fingerprint = $1)`, [m]);
  await svc.licenseDb.query('ALTER TABLE trial ENABLE TRIGGER trial_before_update');
  const r = await post('revalidate', { machineId: m, token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'trial_ended');
  const [t] = await q(svc, `SELECT status_code FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  assert.equal(t.status_code, 'EXPIRED');
});

test('a trial token presented by a machine the service has never seen is refused, not an error', async () => {
  const a = await trial();
  const r = await post('revalidate', { machineId: 'z'.repeat(20), token: a.token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'not_activated');
});
