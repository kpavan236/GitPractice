'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService, verifyToken } = require('./helpers/server');
const { machine, createCustomer, createLicence, q } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const activate = (body, headers) => svc.post('/v1/activate', { appVersion: '2.0.1', ...body }, headers);

test('a support-issued key activates, however it was typed: lower case, spaces, padded', async () => {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c, { plan: 'team', seats: 3 });
  for (const typed of [lic.licenceKey, lic.licenceKey.toLowerCase(), `  ${lic.licenceKey}  `]) {
    const r = await activate({ machineId: machine(), licenseKey: typed });
    assert.equal(r.status, 200, `${JSON.stringify(typed)} -> ${JSON.stringify(r.body)}`);
    const { ok, payload } = verifyToken(r.body.token, svc.publicKey);
    assert.ok(ok);
    assert.equal(payload.licenseId, lic.licenseId);
    assert.equal(payload.tier, 'team');
    assert.deepEqual(payload.features, ['version-watch']);
  }
});

test('the key is returned once and stored only as a hash and a four-character hint', async () => {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c);
  const rows = await q(svc, 'SELECT * FROM license WHERE license_id = $1', [lic.licenseId]);
  assert.ok(!JSON.stringify(rows).includes(lic.licenceKey));
  assert.match(rows[0].license_key_hash, /^[0-9a-f]{64}$/);
  assert.equal(rows[0].key_hint, lic.licenceKey.slice(-4));
  assert.match(lic.licenceKey, /^OASIS-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
});

test('an unknown, empty or awkward key is a plain refusal, never an error', async () => {
  const awkward = ['OASIS-AAAA-BBBB-CCCC', '', '   ', 'x'.repeat(10_000), "'; DROP TABLE license; --", null, 42, { a: 1 }, ['OASIS']];
  for (const licenseKey of awkward) {
    const r = await activate({ machineId: machine(), licenseKey });
    assert.equal(r.status, 400, JSON.stringify(licenseKey).slice(0, 40));
    assert.equal(r.body.reason, 'unknown_key');
  }
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM license'))[0].n >= 0, true, 'the table is still there');
});

test('machine ids that are empty, too short, too long or not text are refused', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c);
  for (const machineId of [undefined, '', 'short', 'x'.repeat(10_000), 'a'.repeat(64) + '!', 12345678901234567, ['a'.repeat(20)]]) {
    const r = await activate({ machineId, licenseKey: lic.licenceKey });
    assert.equal(r.status, 400);
    assert.equal(r.body.reason, 'bad_machine_id');
  }
});

test('an ended licence is refused as expired, and a cancelled one as revoked', async () => {
  const c = await createCustomer(svc);
  const ended = await createLicence(svc, c, { ended: true });
  const r = await activate({ machineId: machine(), licenseKey: ended.licenceKey });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'expired');

  const cancelled = await createLicence(svc, c);
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = 'CANCELLED' FROM r WHERE license_id = $1`, [cancelled.licenseId]);
  const r2 = await activate({ machineId: machine(), licenseKey: cancelled.licenceKey });
  assert.equal(r2.status, 403);
  assert.equal(r2.body.reason, 'revoked');
});

test('the seat race through keys: ten machines, three seats, exactly three win', async () => {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c, { seats: 3 });
  const results = await Promise.all(Array.from({ length: 10 }, () => activate({ machineId: machine(), licenseKey: lic.licenceKey })));
  assert.equal(results.filter(r => r.status === 200).length, 3);
  assert.ok(results.filter(r => r.status !== 200).every(r => r.status === 403 && r.body.reason === 'seats_full'));
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [lic.licenseId]))[0].n, 3);
});

test('the same machine asking twice at once takes one seat', async () => {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c, { seats: 5 });
  const m = machine();
  const results = await Promise.all(Array.from({ length: 6 }, () => activate({ machineId: m, licenseKey: lic.licenceKey })));
  assert.ok(results.every(r => r.status === 200));
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [lic.licenseId]))[0].n, 1);
});
