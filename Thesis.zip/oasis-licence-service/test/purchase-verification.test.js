'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { machine } = require('./helpers/fixtures');
const { verifiedForm } = require('./helpers/purchase');

let svc;
test.before(async () => { svc = await startService({ blockedEmailDomains: ['mailbox.example.test'] }); });
test.after(async () => { await svc.close(); });

const form = (over = {}) => ({ organization: 'Acme Example Ltd', employees: 120, email: 'pat@acme.example.test', contactName: 'Pat Example', ...over });
const count = () => svc.customerDb.query('SELECT count(*)::int AS n FROM purchase_request').then(r => r.rows[0].n);

test('a code is refused for a personal-provider address, and nothing is sent', async () => {
  const before = svc.notifier.sent.length;
  for (const email of ['pat@gmail.com', 'PAT@Yahoo.com', 'pat@mail.gmail.com', 'pat@mailbox.example.test']) {
    const r = await svc.post('/v1/purchase-request/otp', { email, machineId: machine() });
    assert.equal(r.status, 400, email);
    assert.equal(r.body.reason, 'not_corporate_email', email);
    assert.match(r.body.message, /work email/i);
  }
  assert.equal(svc.notifier.sent.length, before, 'no code was sent');
});

test('a code is sent for a work address; the response never carries it and the message says what it is for', async () => {
  const r = await svc.post('/v1/purchase-request/otp', { email: 'Pat@Acme.Example.Test', machineId: machine() });
  assert.equal(r.status, 200);
  assert.deepEqual(Object.keys(r.body).sort(), ['expiresInMinutes', 'ok', 'sentTo']);
  const sent = svc.notifier.last();
  assert.equal(sent.to, 'pat@acme.example.test');
  assert.equal(sent.purpose, 'purchase');
  assert.match(sent.code, /^\d{6}$/);
  assert.ok(!JSON.stringify(r.body).includes(sent.code));
});

test('a code needs a valid address and machine id', async () => {
  assert.equal((await svc.post('/v1/purchase-request/otp', { email: 'nope', machineId: machine() })).body.reason, 'bad_email');
  assert.equal((await svc.post('/v1/purchase-request/otp', { email: 'pat@acme.example.test' })).body.reason, 'bad_machine_id');
});

test('verifying: a wrong code is refused with no token, the right code returns a token', async () => {
  const machineId = machine();
  await svc.post('/v1/purchase-request/otp', { email: 'v1@acme.example.test', machineId });
  const code = svc.notifier.last().code;
  const wrong = await svc.post('/v1/purchase-request/verify', { email: 'v1@acme.example.test', machineId, code: code === '000000' ? '111111' : '000000' });
  assert.equal(wrong.status, 400);
  assert.equal(wrong.body.reason, 'wrong_code');
  assert.equal(wrong.body.verificationToken, undefined);
  const right = await svc.post('/v1/purchase-request/verify', { email: 'v1@acme.example.test', machineId, code });
  assert.equal(right.status, 200);
  assert.equal(typeof right.body.verificationToken, 'string');
});

test('a code requested on one machine cannot be verified from another', async () => {
  await svc.post('/v1/purchase-request/otp', { email: 'v2@acme.example.test', machineId: machine() });
  const r = await svc.post('/v1/purchase-request/verify', { email: 'v2@acme.example.test', machineId: machine(), code: svc.notifier.last().code });
  assert.equal(r.status, 400);
  assert.equal(r.body.verificationToken, undefined);
});

test('submitting without a verification is refused and nothing is stored', async () => {
  const before = await count();
  const r = await svc.post('/v1/purchase-request', form({ email: 'p1@acme.example.test' }));
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'email_not_verified');
  assert.equal(await count(), before);
});

test('a proof for a different email, a different machine, or an edited token is refused', async () => {
  const good = await verifiedForm(svc, form({ email: 'p2@acme.example.test' }));
  const before = await count();
  const tries = [
    { ...good, email: 'someone.else@acme.example.test' },
    { ...good, machineId: machine() },
    { ...good, verificationToken: good.verificationToken.slice(0, -2) + (good.verificationToken.endsWith('00') ? '11' : '00') },
    { ...good, verificationToken: undefined },
  ];
  for (const body of tries) {
    const r = await svc.post('/v1/purchase-request', body);
    assert.equal(r.status, 400);
    assert.equal(r.body.reason, 'email_not_verified');
  }
  assert.equal(await count(), before);
});

test('a verified work address submits and is stored', async () => {
  const body = await verifiedForm(svc, form({ email: 'p3@acme.example.test' }));
  const r = await svc.post('/v1/purchase-request', body);
  assert.equal(r.status, 200);
  assert.match(r.body.reference, /^PR-\d{6}$/);
  const { rows } = await svc.customerDb.query('SELECT email FROM purchase_request WHERE reference = $1', [r.body.reference]);
  assert.equal(rows[0].email, 'p3@acme.example.test');
});

test('a personal-provider address is refused at submit even with a proof made for it', async () => {
  const machineId = machine();
  const token = svc.purchaseProof.issue({ email: 'pat@gmail.com', machineId });
  const before = await count();
  const r = await svc.post('/v1/purchase-request', form({ email: 'pat@gmail.com', machineId, verificationToken: token }));
  assert.equal(r.status, 400);
  assert.equal(r.body.reason, 'invalid');
  assert.match(r.body.errors.email, /work email/i);
  assert.equal(await count(), before);
});

test('a retry of the same verified submit gets the first answer, as before', async () => {
  const body = await verifiedForm(svc, form({ email: 'p4@acme.example.test' }));
  const headers = { 'Idempotency-Key': 'verified-retry-key-0001' };
  const first = await svc.post('/v1/purchase-request', body, headers);
  const second = await svc.post('/v1/purchase-request', body, headers);
  assert.equal(second.status, 200);
  assert.equal(second.body.reference, first.body.reference);
  assert.equal(second.headers.get('idempotent-replay'), 'true');
});
