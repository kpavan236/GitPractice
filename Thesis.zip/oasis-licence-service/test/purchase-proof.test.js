'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createHasher } = require('../src/secrets');
const { createPurchaseProof } = require('../src/purchase-proof');

const PEPPER = 'test-pepper-test-pepper-test-pepper-0123';
const MACHINE = 'm'.repeat(32);

test('a proof is valid for the same email and machine', () => {
  const proof = createPurchaseProof({ hash: createHasher(PEPPER) });
  const token = proof.issue({ email: 'pat@acme.example.test', machineId: MACHINE });
  assert.equal(proof.check({ token, email: 'pat@acme.example.test', machineId: MACHINE }), true);
});

test('a proof is refused for another email, another machine, or a changed token', () => {
  const proof = createPurchaseProof({ hash: createHasher(PEPPER) });
  const token = proof.issue({ email: 'pat@acme.example.test', machineId: MACHINE });
  assert.equal(proof.check({ token, email: 'sam@acme.example.test', machineId: MACHINE }), false);
  assert.equal(proof.check({ token, email: 'pat@acme.example.test', machineId: 'x'.repeat(32) }), false);
  assert.equal(proof.check({ token: token.slice(0, -2) + '00', email: 'pat@acme.example.test', machineId: MACHINE }), false);
  assert.equal(proof.check({ token: token.replace(/^\d+/, n => String(Number(n) + 100000)), email: 'pat@acme.example.test', machineId: MACHINE }), false, 'a longer expiry cannot be written in');
});

test('a proof expires after its lifetime', () => {
  let now = 1_000_000;
  const proof = createPurchaseProof({ hash: createHasher(PEPPER), ttlMinutes: 30, now: () => now });
  const token = proof.issue({ email: 'pat@acme.example.test', machineId: MACHINE });
  now += 29 * 60 * 1000;
  assert.equal(proof.check({ token, email: 'pat@acme.example.test', machineId: MACHINE }), true);
  now += 2 * 60 * 1000;
  assert.equal(proof.check({ token, email: 'pat@acme.example.test', machineId: MACHINE }), false);
});

test('a proof made with a different server secret is refused, and junk is refused without throwing', () => {
  const a = createPurchaseProof({ hash: createHasher(PEPPER) });
  const b = createPurchaseProof({ hash: createHasher('other-pepper-other-pepper-other-pepper-99') });
  const token = a.issue({ email: 'pat@acme.example.test', machineId: MACHINE });
  assert.equal(b.check({ token, email: 'pat@acme.example.test', machineId: MACHINE }), false);
  for (const junk of [undefined, null, '', 'abc', '1.2.3', 42, {}, '123.zz']) {
    assert.equal(a.check({ token: junk, email: 'pat@acme.example.test', machineId: MACHINE }), false, String(junk));
  }
});
