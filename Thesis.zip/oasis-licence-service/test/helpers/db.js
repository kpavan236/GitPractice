'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { migrate } = require('../../src/migrate');

// Tests run against REAL PostgreSQL, because the rules that matter (one trial per machine, append-only history, status moves) live
// in the database. Each run makes two throwaway databases on the server named by TEST_PG_ADMIN_URL and drops them afterwards.
// Default: the local development container (docker run -p 5433:5432 postgres:16).
const ADMIN_URL = process.env.TEST_PG_ADMIN_URL || 'postgres://postgres:local-dev-only@localhost:5433/postgres';

function urlFor(name) { const u = new URL(ADMIN_URL); u.pathname = `/${name}`; return u.toString(); }

async function createTestDatabases() {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try { await admin.query('SELECT 1'); }
  catch (err) { await admin.end().catch(() => {}); throw new Error(`Cannot reach PostgreSQL for the tests (${err.message}). Start one, or set TEST_PG_ADMIN_URL.`); }
  const id = crypto.randomBytes(4).toString('hex');
  const names = { customer: `t_${id}_customer`, license: `t_${id}_license` };
  for (const n of Object.values(names)) await admin.query(`CREATE DATABASE ${n}`);
  await migrate(urlFor(names.customer), path.join(__dirname, '..', '..', 'db', 'customer'));
  await migrate(urlFor(names.license), path.join(__dirname, '..', '..', 'db', 'license'));
  const customerDb = new Pool({ connectionString: urlFor(names.customer), max: 10 });
  const licenseDb = new Pool({ connectionString: urlFor(names.license), max: 10 });
  for (const pool of [customerDb, licenseDb]) pool.on('error', () => {});     // as in src/db.js: a connection dropped when the database is dropped is not a test failure
  return {
    customerDb, licenseDb,
    async drop() {
      await Promise.all([customerDb.end(), licenseDb.end()]);
      for (const n of Object.values(names)) await admin.query(`DROP DATABASE IF EXISTS ${n} WITH (FORCE)`);
      await admin.end();
    },
  };
}

module.exports = { createTestDatabases };
