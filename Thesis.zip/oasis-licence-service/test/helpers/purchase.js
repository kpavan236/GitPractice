'use strict';
const assert = require('node:assert/strict');
const { machine } = require('./fixtures');

/** A Buy-form body whose email has been proved with a code, the way the app does it: ask for a code, read it from the fake sender, verify it. */
async function verifiedForm(svc, body) {
  const machineId = machine();
  const asked = await svc.post('/v1/purchase-request/otp', { email: body.email, machineId });
  assert.equal(asked.status, 200, `code requested: ${JSON.stringify(asked.body)}`);
  const verified = await svc.post('/v1/purchase-request/verify', { email: body.email, machineId, code: svc.notifier.last().code });
  assert.equal(verified.status, 200, `code verified: ${JSON.stringify(verified.body)}`);
  return { ...body, machineId, verificationToken: verified.body.verificationToken };
}

module.exports = { verifiedForm };
