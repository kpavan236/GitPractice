'use strict';
const crypto = require('node:crypto');
const { createApp } = require('../../src/app');
const { prepareSigner } = require('../../src/signing-key');
const { createTestDatabases } = require('./db');
const { createTrialReviewer } = require('../../src/trial-review');
const { rateLimit } = require('../../src/rate-limit');
const { createFakeNotifier } = require('../../src/notifier');
const { createHasher } = require('../../src/secrets');
const { createPurchaseProof } = require('../../src/purchase-proof');

const PEPPER = 'test-pepper-test-pepper-test-pepper-0123';

/** A running service on a free port, on throwaway databases. `logs` collects every log line so tests can check what was (not) logged. */
async function startService(options = {}) {
  const dbs = options.dbs || await createTestDatabases();
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
  const signer = await prepareSigner(dbs.licenseDb, { signingKeyPem: pem, signingKid: `test-${crypto.randomBytes(3).toString('hex')}` });
  const logs = [];
  const notifier = createFakeNotifier();
  const app = createApp({
    customerDb: options.customerDb || dbs.customerDb, licenseDb: dbs.licenseDb, signer, hashPepper: PEPPER, notifier, supportMailbox: options.supportMailbox === undefined ? 'support@support.example.test' : options.supportMailbox, blockedEmailDomains: options.blockedEmailDomains || [],
    trialDays: options.trialDays || 7, reviewer: options.reviewer || createTrialReviewer(),
    limiter: options.limiter || rateLimit({ max: 10_000 }), hsts: options.hsts, log: line => logs.push(line),
  });
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, route, body, headers = {}) => {
    const res = await fetch(`${base}${route}`, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    return { status: res.status, headers: res.headers, body: await res.json().catch(() => ({})) };
  };
  return {
    ...dbs, app, base, logs, publicKey, privateKey, kid: signer.kid, call, notifier, hashPepper: PEPPER, purchaseProof: createPurchaseProof({ hash: createHasher(PEPPER) }),
    post: (route, body, headers) => call('POST', route, body, headers),
    get: route => call('GET', route),
    async close() { await new Promise(r => server.close(r)); if (!options.dbs) await dbs.drop(); },
  };
}

/** Checks a token the way the OASIS app does: EdDSA only, signature over the first two segments. */
function verifyToken(token, publicKey) {
  const [h, p, s] = token.split('.');
  const header = JSON.parse(Buffer.from(h, 'base64url').toString());
  const ok = crypto.verify(null, Buffer.from(`${h}.${p}`, 'ascii'), publicKey, Buffer.from(s, 'base64url'));
  return { ok, header, payload: JSON.parse(Buffer.from(p, 'base64url').toString()) };
}

module.exports = { startService, verifyToken };
