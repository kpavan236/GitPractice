'use strict';
const crypto = require('node:crypto');
const { createHasher } = require('../../src/secrets');
const { issueLicence } = require('../../src/issue-licence');
const { uuidv7 } = require('../../src/uuid');

const DAY = 24 * 60 * 60 * 1000;
let n = 0;
const unique = () => `${Date.now().toString(36)}${(++n).toString(36)}`;

const machine = () => crypto.randomBytes(16).toString('hex');

/** A customer with a verified email domain (synthetic: example.test). Returns { customerId, domain, name }. */
async function createCustomer(svc, { name = null, domain = null, verified = true } = {}) {
  const id = unique();
  const customerId = uuidv7();
  const cname = name || `Acme ${id} Ltd`;
  const dom = domain || `acme-${id}.example.test`;
  await svc.customerDb.query(`INSERT INTO customer (customer_id, name, slug, status_code) VALUES ($1, $2, $3, 'ACTIVE')`, [customerId, cname, `acme-${id}`]);
  await svc.customerDb.query(
    `INSERT INTO customer_domain (domain_id, customer_id, domain, verification_token_hash, verified_at) VALUES ($1, $2, $3, $4, ${verified ? 'now()' : 'NULL'})`,
    [uuidv7(), customerId, dom, crypto.randomBytes(32).toString('hex')]);
  return { customerId, domain: dom, name: cname };
}

/** A licence for that customer. Returns { licenseId, licenceKey }. `ended: true` makes one whose term is already over. */
async function createLicence(svc, customer, { plan = 'team', seats, days = 365, ended = false, kind = 'paid' } = {}) {
  const hash = createHasher(svc.hashPepper);
  return issueLicence({ licenseDb: svc.licenseDb, hash }, {
    customerId: customer.customerId, planCode: plan, kind, seatLimit: seats, termDays: ended ? 10 : days,
    startsAt: ended ? new Date(Date.now() - 40 * DAY) : undefined,
  });
}

/** Asks for a code for an address and returns it (read from the fake sender, as a person would from their mailbox). */
async function codeFor(svc, email, machineId) {
  const r = await svc.post('/v1/domain/otp', { machineId, email });
  if (r.status !== 200) throw new Error(`otp failed: ${r.status} ${JSON.stringify(r.body)}`);
  return svc.notifier.sent.findLast(m => m.to === email).code;     // by recipient, so concurrent requests do not mix up
}

/** The whole "Activate licence" flow for one person on one machine. */
async function activateByEmail(svc, email, machineId, extra = {}) {
  const code = await codeFor(svc, email, machineId);
  return svc.post('/v1/domain/activate', { machineId, email, code, appVersion: '2.0.1', ...extra });
}

const q = (svc, sql, params) => svc.licenseDb.query(sql, params).then(r => r.rows);

module.exports = { DAY, unique, machine, createCustomer, createLicence, codeFor, activateByEmail, q };
