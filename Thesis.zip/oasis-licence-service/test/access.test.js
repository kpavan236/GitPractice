'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { machine, unique, createCustomer, createLicence, activateByEmail, q } = require('./helpers/fixtures');
const { createAccess, BLOCKED_MESSAGE } = require('../src/access');
const { createHasher } = require('../src/secrets');

let svc, access;
test.before(async () => {
  svc = await startService();
  access = createAccess({ licenseDb: svc.licenseDb, hash: createHasher(svc.hashPepper) });
});
test.after(async () => { await svc.close(); });

/** Every route the app registers under /v1, as "METHOD /v1/path". Found by walking the router, so a route added later is included. */
function v1Routes(app) {
  const found = [];
  const walk = (stack, prefix) => {
    for (const layer of stack) {
      if (layer.route) for (const method of Object.keys(layer.route.methods)) found.push(`${method.toUpperCase()} ${prefix}${layer.route.path}`);
      else if (layer.name === 'router' && layer.handle.stack) walk(layer.handle.stack, prefix + (layer.regexp.source.includes('v1') ? '/v1' : ''));
    }
  };
  walk(app._router.stack, '');
  return found.filter(r => r.includes('/v1/'));
}

test('a blocked machine is refused with 403 "blocked" on EVERY route the service has', async () => {
  const routes = v1Routes(svc.app);
  assert.ok(routes.length >= 7, `found ${routes.length} routes: ${routes.join(', ')}`);
  for (const expected of ['/v1/trial', '/v1/activate', '/v1/revalidate', '/v1/deactivate', '/v1/domain/otp', '/v1/domain/activate', '/v1/purchase-request']) {
    assert.ok(routes.includes(`POST ${expected}`), `${expected} is registered`);
  }
  const m = machine();
  await access.block({ type: 'machine', value: m, reason: 'abuse', note: 'internal note: never shown' });
  for (const route of routes) {
    assert.ok(route.startsWith('POST '), `${route}: every route today is a POST; add a case here if that changes`);
    const r = await svc.post(route.slice(5), { machineId: m, email: 'pat@acme.example.test', licenseKey: 'OASIS-AAAA-BBBB-CCCC', token: 'x', code: '123456', organization: 'Acme', employees: 5, contactName: 'Pat' });
    assert.equal(r.status, 403, route);
    assert.equal(r.body.reason, 'blocked', route);
    assert.equal(r.body.message, BLOCKED_MESSAGE);
    assert.ok(!JSON.stringify(r.body).includes('internal note'), 'the note is never shown');
  }
});

test('a blocked email address and a blocked domain are refused on the routes that carry an address', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const bad = `bad@${c.domain}`, fine = `fine@${c.domain}`;
  await access.block({ type: 'email', value: bad, reason: 'security' });
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: bad.toUpperCase() })).body.reason, 'blocked');
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: fine })).status, 200, 'a colleague is not affected');

  await access.block({ type: 'email_domain', value: c.domain, reason: 'payment' });
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: fine })).body.reason, 'blocked');
  assert.equal((await svc.post('/v1/purchase-request', { organization: 'Acme', employees: 5, email: fine, contactName: 'Pat' })).status, 403);
});

test('a block on a machine that holds a seat stops its revalidation: the app locks', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c);
  const m = machine();
  const first = await svc.post('/v1/activate', { machineId: m, licenseKey: lic.licenceKey });
  assert.equal(first.status, 200);
  await access.block({ type: 'machine', value: m, reason: 'licence_revoked' });
  const r = await svc.post('/v1/revalidate', { machineId: m, token: first.body.token });
  assert.equal(r.status, 403);
  assert.equal(r.body.reason, 'blocked');
  assert.equal(await access.lift({ type: 'machine', value: m }), 1);
  assert.equal((await svc.post('/v1/revalidate', { machineId: m, token: first.body.token })).status, 200, 'lifting restores it at once');
});

test('a block can expire by itself', async () => {
  const m = machine();
  await access.block({ type: 'machine', value: m, reason: 'abuse', expiresAt: new Date(Date.now() + 1000) });
  assert.equal(await access.check({ machineId: m }), 'abuse');
  await new Promise(r => setTimeout(r, 1200));
  assert.equal(await access.check({ machineId: m }), null);
});

test('blocks are stored as hashes, are never deleted, and lifting changes only the lifted columns', async () => {
  const m = machine(), email = `${unique()}@acme.example.test`;
  await access.block({ type: 'machine', value: m, reason: 'support_request' });
  await access.block({ type: 'email', value: email, reason: 'support_request' });
  await access.block({ type: 'machine', value: m, reason: 'abuse' });       // blocking twice is a no-op
  const rows = await q(svc, `SELECT * FROM access_block WHERE reason_code = 'support_request' OR reason_code = 'abuse'`);
  const dump = JSON.stringify(rows);
  assert.ok(!dump.includes(m) && !dump.includes(email), 'neither the machine id nor the address is stored');
  assert.equal(rows.filter(r => r.subject_type === 'machine' && r.lifted_at === null && r.reason_code === 'support_request').length, 1);

  await assert.rejects(svc.licenseDb.query(`DELETE FROM access_block`), /never deleted/);
  await assert.rejects(svc.licenseDb.query(`UPDATE access_block SET reason_code = 'abuse', note = 'edited'`), /can only be lifted/);
  await access.lift({ type: 'machine', value: m });
  await assert.rejects(svc.licenseDb.query(`UPDATE access_block SET lifted_at = NULL WHERE lifted_at IS NOT NULL`), /can only be lifted/);
});

test('a block needs a known reason code', async () => {
  await assert.rejects(access.block({ type: 'machine', value: machine(), reason: 'because' }), /violates foreign key/);
});

test('a caller who is not blocked, and a request with nothing to check, go through', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  assert.equal((await activateByEmail(svc, `ok@${c.domain}`, machine())).status, 200);
  assert.equal(await access.check({}), null);
  assert.equal(await access.check({ machineId: 12345, email: ['a@b.test'] }), null, 'values of the wrong type are ignored, not trusted');
  assert.equal((await svc.post('/v1/trial', 'not json at all')).status, 400);
});

test('a block can point at the licence it was made for, and that link cannot be changed afterwards', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c);
  const other = await createLicence(svc, c);
  const m = machine();
  await access.block({ type: 'machine', value: m, reason: 'licence_revoked' });
  await svc.licenseDb.query(`UPDATE access_block SET license_id = $1 WHERE license_id IS NULL AND reason_code = 'licence_revoked' AND subject_type = 'machine'`, [lic.licenseId]).then(
    () => assert.fail('the link is part of the block and cannot be edited'), err => assert.match(err.message, /can only be lifted/));
  await svc.licenseDb.query(`INSERT INTO access_block (block_id, subject_type, subject_hash, reason_code, license_id) VALUES (gen_random_uuid(), 'machine', $1, 'licence_revoked', $2)`, ['b'.repeat(64), lic.licenseId]);
  await assert.rejects(svc.licenseDb.query(`UPDATE access_block SET license_id = $1 WHERE subject_hash = $2`, [other.licenseId, 'b'.repeat(64)]), /can only be lifted/);
  await svc.licenseDb.query(`UPDATE access_block SET lifted_at = now() WHERE subject_hash = $1`, ['b'.repeat(64)]);
  assert.equal((await q(svc, 'SELECT license_id FROM access_block WHERE subject_hash = $1', ['b'.repeat(64)]))[0].license_id, lic.licenseId);
});
