'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Pool } = require('pg');
const { startService } = require('./helpers/server');
const { verifiedForm } = require('./helpers/purchase');
const { rateLimit } = require('../src/rate-limit');
const { loadConfig } = require('../src/config');
const { uuidv7 } = require('../src/uuid');
const { prepareSigner } = require('../src/signing-key');
const crypto = require('node:crypto');

let svc;
test.before(async () => { svc = await startService({ limiter: rateLimit({ max: 3, windowMs: 60_000 }) }); });
test.after(async () => { await svc.close(); });

test('health is open, readiness checks both databases', async () => {
  assert.equal((await svc.get('/healthz')).status, 200);
  assert.equal((await svc.get('/readyz')).status, 200);
});

test('readiness fails when a database is down', async () => {
  const broken = new Pool({ connectionString: 'postgres://nobody:wrong@127.0.0.1:1/none', max: 1, connectionTimeoutMillis: 500 });
  broken.on('error', () => {});
  const other = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb }, customerDb: broken });
  try { assert.equal((await other.get('/readyz')).status, 503); } finally { await other.close(); await broken.end().catch(() => {}); }
});

test('unknown routes answer in JSON; the framework is not advertised; every answer carries a request id', async () => {
  const r = await svc.get('/v1/nothing');
  assert.equal(r.status, 404);
  assert.equal(r.body.error, 'not_found');
  assert.equal(r.headers.get('x-powered-by'), null);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('cache-control'), 'no-store');
  assert.ok(r.headers.get('x-request-id'));
});

test('a sensible inbound request id is kept; an unsafe one is replaced', async () => {
  const kept = await svc.call('GET', '/healthz', undefined, { 'X-Request-Id': 'trace-abcdef12' });
  assert.equal(kept.headers.get('x-request-id'), 'trace-abcdef12');
  const swapped = await svc.call('GET', '/healthz', undefined, { 'X-Request-Id': 'a b\tc <script>' });
  assert.notEqual(swapped.headers.get('x-request-id'), 'a b\tc <script>');
});

test('the per-address limit answers 429 with a wait time', async () => {
  const limited = await startService({ limiter: rateLimit({ max: 2, windowMs: 60_000 }) });
  try {
    const statuses = [];
    let last;
    for (let i = 0; i < 4; i++) { last = await limited.post('/v1/purchase-request', {}); statuses.push(last.status); }
    assert.deepEqual(statuses, [400, 400, 429, 429]);
    assert.equal(last.body.reason, 'too_many_requests');
    assert.ok(last.body.retryAfterSeconds > 0);
  } finally { await limited.close(); }
});

test('the limit window resets', () => {
  let t = 0;
  const limit = rateLimit({ max: 1, windowMs: 1000, now: () => t });
  const run = () => { let err; limit({ ip: '1.1.1.1' }, {}, e => { err = e; }); return err; };
  assert.equal(run(), undefined);
  assert.equal(run().status, 429);
  t = 1001;
  assert.equal(run(), undefined);
});

test('configuration: required settings, ranges and the key file', () => {
  const base = { CUSTOMER_DATABASE_URL: 'postgres://x/c', LICENSE_DATABASE_URL: 'postgres://x/l', LICENCE_SIGNING_KEY_PEM: 'pem', HASH_PEPPER: 'p'.repeat(32) };
  assert.equal(loadConfig(base).trialDays, 7);
  assert.equal(loadConfig(base).port, 4020);
  assert.throws(() => loadConfig({ ...base, CUSTOMER_DATABASE_URL: '' }), /CUSTOMER_DATABASE_URL/);
  assert.throws(() => loadConfig({ CUSTOMER_DATABASE_URL: 'a', LICENSE_DATABASE_URL: 'b' }), /LICENCE_SIGNING_KEY/);
  assert.throws(() => loadConfig({ ...base, TRIAL_DURATION_DAYS: '0' }), /TRIAL_DURATION_DAYS/);
  assert.throws(() => loadConfig({ ...base, TRIAL_DURATION_DAYS: '91' }), /TRIAL_DURATION_DAYS/);
  assert.throws(() => loadConfig({ ...base, PORT: 'abc' }), /PORT/);
  assert.throws(() => loadConfig({ ...base, HASH_PEPPER: '' }), /HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, HASH_PEPPER: 'short' }), /HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, NOTIFIER: 'smtp' }), /NOTIFIER/);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', TRUST_PROXY: '0' }), /approved email sender/);
  assert.throws(() => loadConfig({ ...base, DEV_PRINT_CODES: '1', NODE_ENV: 'production', ALLOW_PLAIN_HTTP: '1', TRUST_PROXY: '0' }), /DEV_PRINT_CODES|approved email sender/);
  assert.equal(loadConfig({ ...base, DEV_PRINT_CODES: '1' }).printCodes, true);
  assert.equal(loadConfig(base).printCodes, false, 'codes are never printed unless asked');
  assert.equal(loadConfig(base).supportMailbox, null);
  assert.equal(loadConfig({ ...base, SUPPORT_MAILBOX: ' Support@Example.test ' }).supportMailbox, 'support@example.test');
  assert.throws(() => loadConfig({ ...base, SUPPORT_MAILBOX: 'a@b.test, c@d.test' }), /SUPPORT_MAILBOX/);
});

test('ids are version-7 UUIDs that sort by time', () => {
  const a = uuidv7(1_000_000_000_000), b = uuidv7(1_000_000_001_000);
  assert.match(a, /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
  assert.ok(a < b);
});

test('the signer refuses a non-Ed25519 key, and a key id already used with a different key', async () => {
  const rsa = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey.export({ type: 'pkcs8', format: 'pem' });
  await assert.rejects(prepareSigner(svc.licenseDb, { signingKeyPem: rsa, signingKid: 'rsa-1' }), /Ed25519/);
  const ed = () => crypto.generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' });
  await prepareSigner(svc.licenseDb, { signingKeyPem: ed(), signingKid: 'same-kid' });
  await assert.rejects(prepareSigner(svc.licenseDb, { signingKeyPem: ed(), signingKid: 'same-kid' }), /different public key/);
});

test('an internal fault is logged by its kind and code only: the message (which can carry a host address or a value) never reaches a log', async () => {
  const broken = await startService({ customerDb: { query: async () => { throw Object.assign(new Error('connection refused to 10.0.0.5:5432 for pat@acme.example.test'), { code: 'ECONNREFUSED' }); } } });
  try {
    const r = await broken.post('/v1/purchase-request', await verifiedForm(broken, { organization: 'Acme Example Ltd', employees: 5, email: 'pat@acme.example.test', contactName: 'Pat' }));
    assert.equal(r.status, 500);
    const text = JSON.stringify(broken.logs);
    assert.ok(!text.includes('10.0.0.5') && !text.includes('pat@acme'));
    assert.ok(broken.logs.some(l => l.level === 'error' && l.code === 'ECONNREFUSED'));
  } finally { await broken.close(); }
});
