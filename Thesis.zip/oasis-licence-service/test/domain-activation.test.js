'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService, verifyToken } = require('./helpers/server');
const { DAY, unique, machine, createCustomer, createLicence, codeFor, activateByEmail, q } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const person = (customer, who = unique()) => `${who}@${customer.domain}`;

test('step 1: a code is sent for an address whose domain has a licence, and the response never carries it', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c, 'pat');
  const r = await svc.post('/v1/domain/otp', { machineId: machine(), email: email.toUpperCase() });
  assert.equal(r.status, 200);
  assert.deepEqual(Object.keys(r.body).sort(), ['expiresInMinutes', 'ok', 'sentTo']);
  assert.equal(r.body.expiresInMinutes, 10);
  assert.match(r.body.sentTo, /^p\*\*\*@/);
  const sent = svc.notifier.last();
  assert.equal(sent.to, email, 'sent to the lower-cased address');
  assert.match(sent.code, /^\d{6}$/);
  assert.ok(!JSON.stringify(r.body).includes(sent.code));
});

test('step 1 refusals: no licence for the domain, an unverified domain, a bad address, a bad machine id', async () => {
  const none = await svc.post('/v1/domain/otp', { machineId: machine(), email: 'x@nobody-here.example.test' });
  assert.equal(none.status, 404);
  assert.equal(none.body.reason, 'no_domain_licence');
  assert.equal(none.body.error, 'rejected');

  const unverified = await createCustomer(svc, { verified: false }); await createLicence(svc, unverified);
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: person(unverified) })).status, 404, 'a domain nobody has proved they own grants nothing');

  const noLicence = await createCustomer(svc);
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: person(noLicence) })).body.reason, 'no_domain_licence');

  const c = await createCustomer(svc); await createLicence(svc, c);
  assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email: 'not-an-email' })).body.reason, 'bad_email');
  assert.equal((await svc.post('/v1/domain/otp', { machineId: 'short', email: person(c) })).body.reason, 'bad_machine_id');
  assert.equal((await svc.post('/v1/domain/otp', { email: person(c) })).status, 400);
});

test('the address and the code are stored only as keyed hashes', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c, 'hashcheck'), m = machine();
  const code = await codeFor(svc, email, m);
  const rows = await q(svc, 'SELECT * FROM email_challenge ORDER BY created_at DESC LIMIT 1');
  const dump = JSON.stringify(rows);
  for (const secret of [email, code, m, email.split('@')[1]]) assert.ok(!dump.includes(secret), `${secret} is not stored`);
  assert.match(rows[0].email_hash, /^[0-9a-f]{64}$/);
});

test('limits: three codes per address and ten per machine in fifteen minutes, with a retry time', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c, 'limit'), m = machine();
  for (let i = 0; i < 3; i++) assert.equal((await svc.post('/v1/domain/otp', { machineId: m, email })).status, 200);
  const fourth = await svc.post('/v1/domain/otp', { machineId: m, email });
  assert.equal(fourth.status, 429);
  assert.equal(fourth.body.reason, 'too_many_requests');
  assert.ok(fourth.body.retryAfterSeconds > 0 && fourth.body.retryAfterSeconds <= 900);

  const busy = machine();
  for (let i = 0; i < 10; i++) assert.equal((await svc.post('/v1/domain/otp', { machineId: busy, email: person(c) })).status, 200);
  assert.equal((await svc.post('/v1/domain/otp', { machineId: busy, email: person(c) })).status, 429, 'ten per machine, whoever the address');
});

test('asking again replaces the code: only the newest works', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c), m = machine();
  const first = await codeFor(svc, email, m);
  const second = await codeFor(svc, email, m);
  const wrong = first === second ? '000000' : first;
  const r = await svc.post('/v1/domain/activate', { machineId: m, email, code: wrong });
  if (first !== second) assert.equal(r.body.reason, 'wrong_code');
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code: second })).status, 200);
});

test('step 2: a right code activates, issues a token the app can verify, and takes one seat', async () => {
  const c = await createCustomer(svc);
  const lic = await createLicence(svc, c, { plan: 'viewer-security', seats: 5 });
  const email = person(c), m = machine();
  const before = Date.now();
  const r = await activateByEmail(svc, email, m);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const { ok, header, payload } = verifyToken(r.body.token, svc.publicKey);
  assert.ok(ok);
  assert.equal(header.alg, 'EdDSA');
  assert.equal(payload.licenseId, lic.licenseId);
  assert.equal(payload.tier, 'viewer-security');
  assert.equal(payload.customer, c.name);
  assert.equal(payload.seats, 5);
  assert.deepEqual(payload.features, ['security', 'version-watch']);
  assert.ok(Math.abs(payload.exp - (before + 365 * DAY)) < 10_000, 'expires when the licence term ends');
  assert.ok(Math.abs(payload.graceUntil - (payload.issuedAt + 14 * DAY)) < 1000, 'the plan\'s 14 days of grace');
  assert.ok(Math.abs(r.body.serverTime - Date.now()) < 5000);

  const [licence] = await q(svc, 'SELECT status_code FROM license WHERE license_id = $1', [lic.licenseId]);
  assert.equal(licence.status_code, 'ACTIVE', 'the first activation makes a pending licence active');
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL`, [lic.licenseId]))[0].n, 1);
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM installation_check_in WHERE license_id = $1 AND kind_code = 'activate'`, [lic.licenseId]))[0].n, 1);
  assert.equal((await q(svc, 'SELECT count(*)::int AS n FROM token_issue WHERE license_id = $1', [lic.licenseId]))[0].n, 1);
});

test('an enterprise licence is uncounted and carries every feature', async () => {
  const c = await createCustomer(svc);
  await createLicence(svc, c, { plan: 'enterprise', kind: 'enterprise', seats: null });
  const r = await activateByEmail(svc, person(c), machine());
  const { payload } = verifyToken(r.body.token, svc.publicKey);
  assert.equal(payload.seats, null);
  assert.equal(payload.features, '*');
  assert.ok(await activateByEmail(svc, person(c), machine()).then(x => x.status === 200), 'any number of machines');
});

test('a code works once, and wrong codes are counted: five and it is locked, even for the right code', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c), m = machine();
  const code = await codeFor(svc, email, m);
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code })).status, 200);
  const again = await svc.post('/v1/domain/activate', { machineId: m, email, code });
  assert.equal(again.status, 400);
  assert.equal(again.body.reason, 'no_code');

  const e2 = person(c), good = await codeFor(svc, e2, m);
  const bad = good === '123456' ? '654321' : '123456';
  const first = await svc.post('/v1/domain/activate', { machineId: m, email: e2, code: bad });
  assert.equal(first.body.reason, 'wrong_code');
  assert.match(first.body.message, /4 tries left/);
  for (let i = 0; i < 3; i++) await svc.post('/v1/domain/activate', { machineId: m, email: e2, code: bad });
  const last = await svc.post('/v1/domain/activate', { machineId: m, email: e2, code: bad });
  assert.equal(last.body.reason, 'too_many_attempts');
  const locked = await svc.post('/v1/domain/activate', { machineId: m, email: e2, code: good });
  assert.equal(locked.body.reason, 'too_many_attempts', 'the right code no longer works');
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM activation a JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]))[0].n, 1, 'only the first activation took a seat');
});

test('an expired code is refused and closed', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c), m = machine();
  const code = await codeFor(svc, email, m);
  await svc.licenseDb.query(`UPDATE email_challenge SET expires_at = now() - interval '1 second', created_at = now() - interval '11 minutes' WHERE closed_at IS NULL AND expires_at > now()`);
  const r = await svc.post('/v1/domain/activate', { machineId: m, email, code });
  assert.equal(r.body.reason, 'expired');
  assert.equal((await svc.post('/v1/domain/activate', { machineId: m, email, code })).body.reason, 'no_code');
});

test('a malformed code is a wrong code, not an error', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c);
  const email = person(c), m = machine();
  await codeFor(svc, email, m);
  for (const code of [undefined, null, 123456, '12345', '1234567', 'abcdef', { $ne: 1 }, ['123456']]) {
    const r = await svc.post('/v1/domain/activate', { machineId: m, email, code });
    assert.ok(r.status === 400 && ['wrong_code', 'too_many_attempts'].includes(r.body.reason), `${JSON.stringify(code)} -> ${r.status} ${r.body.reason}`);
  }
});

test('the seat limit: the last seat goes to one machine, a returning machine takes no second seat', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c, { seats: 2 });
  const [a, b, third] = [machine(), machine(), machine()];
  assert.equal((await activateByEmail(svc, person(c), a)).status, 200);
  assert.equal((await activateByEmail(svc, person(c), b)).status, 200);
  assert.equal((await activateByEmail(svc, person(c), a)).status, 200, 'machine A again: still two seats in use');
  const full = await activateByEmail(svc, person(c), third);
  assert.equal(full.status, 403);
  assert.equal(full.body.reason, 'seats_full');
  assert.match(full.body.message, /All 2 seats on this licence are in use/);
  assert.equal(full.body.seats, 2);
});

test('the seat race: eight machines ask for the last seat at once, exactly one wins', async () => {
  const c = await createCustomer(svc); await createLicence(svc, c, { seats: 1 });
  const results = await Promise.all(Array.from({ length: 8 }, () => {
    const email = person(c), m = machine();
    return codeFor(svc, email, m).then(code => ({ m, email, code }));
  }).map(p => p.then(x => svc.post('/v1/domain/activate', { machineId: x.m, email: x.email, code: x.code }))));
  assert.equal(results.filter(r => r.status === 200).length, 1);
  assert.deepEqual([...new Set(results.filter(r => r.status !== 200).map(r => r.body.reason))], ['seats_full']);
});

test('a revoked, suspended or ended licence is refused with its own reason, and the refusal is recorded', async () => {
  const revoked = await createCustomer(svc); const rl = await createLicence(svc, revoked);
  await svc.licenseDb.query(`SELECT set_config('app.reason', 'test', false)`);
  const set = (id, status) => svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = $2 FROM r WHERE license_id = $1`, [id, status]);
  await set(rl.licenseId, 'CANCELLED');
  const r1 = await activateByEmail(svc, person(revoked), machine());
  assert.equal(r1.status, 403); assert.equal(r1.body.reason, 'revoked');
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM installation_check_in WHERE license_id = $1`, [rl.licenseId]))[0].n, 1, 'the attempt is on record');
  assert.equal((await q(svc, `SELECT count(*)::int AS n FROM activation WHERE license_id = $1`, [rl.licenseId]))[0].n, 0);

  const suspended = await createCustomer(svc); const sl = await createLicence(svc, suspended);
  assert.equal((await activateByEmail(svc, person(suspended), machine())).status, 200);
  await set(sl.licenseId, 'SUSPENDED');
  const r2 = await activateByEmail(svc, person(suspended), machine());
  assert.equal(r2.status, 403); assert.equal(r2.body.reason, 'suspended');

  const ended = await createCustomer(svc); await createLicence(svc, ended, { ended: true });
  const r3 = await activateByEmail(svc, person(ended), machine());
  assert.equal(r3.status, 403); assert.equal(r3.body.reason, 'expired');
  assert.match(r3.body.expiredOn, /^\d{4}-\d{2}-\d{2}$/);
  assert.ok(r3.body.message.includes(r3.body.expiredOn));
});

test('a licence that lapsed and was renewed works again', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c);
  assert.equal((await activateByEmail(svc, person(c), machine())).status, 200);
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = 'EXPIRED' FROM r WHERE license_id = $1`, [lic.licenseId]);
  const again = await activateByEmail(svc, person(c), machine());
  assert.equal(again.status, 200, 'its term is still running, so the recorded status is corrected');
  assert.equal((await q(svc, 'SELECT status_code FROM license WHERE license_id = $1', [lic.licenseId]))[0].status_code, 'ACTIVE');
});

test('activating does not look at the machine\'s history: an ended trial does not stop it, and the trial is closed as converted', async () => {
  const c = await createCustomer(svc); const lic = await createLicence(svc, c);
  const m = machine();
  const instId = crypto.randomUUID();
  await q(svc, `INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code) VALUES ($1, $2, 'darwin')`, [instId, m]);
  await q(svc, `INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '30 days', now() - interval '23 days')`, [crypto.randomUUID(), instId]);
  assert.equal((await activateByEmail(svc, person(c), m)).status, 200);
  const [t] = await q(svc, `SELECT status_code, converted_license_id FROM trial t JOIN installation i USING (installation_id) WHERE i.fingerprint = $1`, [m]);
  assert.equal(t.status_code, 'CONVERTED');
  assert.equal(t.converted_license_id, lic.licenseId);
  const trialAgain = await svc.post('/v1/trial', { machineId: m });
  assert.equal(trialAgain.body.reason, 'trial_converted');
});

test('two licences for one customer: the current one is used, not an old cancelled one', async () => {
  const c = await createCustomer(svc);
  const old = await createLicence(svc, c, { ended: true });
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = 'CANCELLED' FROM r WHERE license_id = $1`, [old.licenseId]);
  const current = await createLicence(svc, c);
  const r = await activateByEmail(svc, person(c), machine());
  assert.equal(r.status, 200);
  assert.equal(verifyToken(r.body.token, svc.publicKey).payload.licenseId, current.licenseId);
});

test('a database fault is a 5xx, never a refusal: an outage must not lock customers out', async () => {
  const broken = await startService({ dbs: { customerDb: { query: async () => { throw new Error('connection refused'); } }, licenseDb: svc.licenseDb } });
  try {
    const r = await broken.post('/v1/domain/otp', { machineId: machine(), email: 'a@acme.example.test' });
    assert.equal(r.status, 500);
    assert.equal(r.body.error, 'internal');
    assert.ok(!JSON.stringify(r.body).includes('connection refused'));
  } finally { await broken.close(); }
});

test('no code, address, machine id or token appears in any log line', async () => {
  const text = JSON.stringify(svc.logs);
  assert.ok(svc.logs.length > 20);
  for (const m of svc.notifier.sent) { assert.ok(!text.includes(m.code) || m.code.length < 6, 'a code'); assert.ok(!text.includes(m.to), 'an address'); }
  assert.ok(!/eyJ[A-Za-z0-9_-]{10,}/.test(text), 'a token');
  assert.ok(!/[0-9a-f]{32}/.test(text), 'a machine id');
});

test('an email address with a control or hidden character is bad_email on both steps, never a 500', async () => {
  for (const email of ['a\u0000b@acme.example.test', 'a​b@acme.example.test', 'a‮b@acme.example.test']) {
    assert.equal((await svc.post('/v1/domain/otp', { machineId: machine(), email })).body.reason, 'bad_email', JSON.stringify(email));
    assert.equal((await svc.post('/v1/domain/activate', { machineId: machine(), email, code: '123456' })).body.reason, 'bad_email');
  }
});
