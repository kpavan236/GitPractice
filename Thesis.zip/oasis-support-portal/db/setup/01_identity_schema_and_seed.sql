-- GENERATED FILE: do not edit. Rebuild with `npm run db:setup:build` (scripts/build-db-setup.js) from db/identity/*.sql.
--
-- Complete setup of the IDENTITY database (identity_db), the one database this repo owns: every table, index, trigger and function,
-- plus the reference data (roles, permissions and the like). Run it ONCE, on an EMPTY database, after 00_create_databases_and_roles.sql:
--
--   psql "postgres://APP_USER:PASSWORD@HOST:5432/identity_db" -v ON_ERROR_STOP=1 -f db/setup/01_identity_schema_and_seed.sql
--
-- Contains: 001_identity_schema.up.sql, 002_reference_data.sql, 003_admin_audit.up.sql, 004_domain_attach_permission.up.sql, 005_block_manage_permission.up.sql, 006_support_message_permissions.up.sql, 007_portal_roles.up.sql, 008_unlimited_licences.up.sql, 009_report_read_admin_only.up.sql, 010_staff_passwords.up.sql, 011_staff_links.up.sql, 012_admin_tools.up.sql, 013_invoice_permissions.up.sql.
-- The last statement records each file in schema_migration with its sha256 checksum, exactly as src/migrate.js does, so a later
-- `npm run migrate` treats them as already applied. If you edit a migration after running this file, migrate stops with an error
-- (an applied file must not change); add a new migration instead and rebuild this file.
-- Psql meta-command used: \set ON_ERROR_STOP (stop at the first error).

\set ON_ERROR_STOP on

CREATE TABLE IF NOT EXISTS schema_migration (filename text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now());

-- ============================================================================
-- Source: db/identity/001_identity_schema.up.sql
-- ============================================================================

-- Identity database (PostgreSQL 16).
--
-- Owns people and how they get in: user accounts, roles and permissions, one-time
-- codes (OTP), sessions, invitations, sign-in history, and what users do in the
-- product. Customer details live in the customer database; a user points at their
-- customer by customer_id with NO foreign key across databases.
--
-- Normal forms are explained in README.md. Conventions: uuid keys (UUIDv7, made by
-- the application); times are timestamptz (UTC); columns holding personal data are
-- marked -- PII. The outbox/inbox tables for events come from the shared library's
-- migration, not from this file.

BEGIN;

-- ── Shared helpers ──────────────────────────────────────────────────────────

CREATE FUNCTION touch_row() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  RETURN NEW;
END $$;

CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

-- Creates the partition for one month; safe to call repeatedly. A scheduled job
-- calls it for the next three months so rows never land in the default partition.
CREATE FUNCTION ensure_month_partition(parent regclass, month date) RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  start_d date := date_trunc('month', month)::date;
  end_d   date := (date_trunc('month', month) + interval '1 month')::date;
  part    text := format('%s_%s', parent::text, to_char(start_d, 'YYYY_MM'));
BEGIN
  EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %s FOR VALUES FROM (%L) TO (%L)', part, parent, start_d, end_d);
END $$;

-- ── Reference (lookup) tables ───────────────────────────────────────────────
-- Values that reports group by get a lookup table, so a label is stored once and a
-- typo is rejected. Small closed lists used only inside the service use a CHECK.

CREATE TABLE user_type   (user_type_code text PRIMARY KEY, label text NOT NULL);      -- customer, staff
CREATE TABLE user_status (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);
CREATE TABLE login_outcome (outcome_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE activity_event_type (event_type_code text PRIMARY KEY, label text NOT NULL, description text);

CREATE TABLE role (
  role_code      text PRIMARY KEY,
  label          text NOT NULL,
  user_type_code text NOT NULL REFERENCES user_type (user_type_code)      -- who may hold this role
);

CREATE TABLE permission (
  permission_code text PRIMARY KEY CHECK (permission_code ~ '^[A-Z][A-Z_]+$'),
  description     text NOT NULL
);

CREATE TABLE role_permission (
  role_code       text NOT NULL REFERENCES role (role_code),
  permission_code text NOT NULL REFERENCES permission (permission_code),
  PRIMARY KEY (role_code, permission_code)
);
CREATE INDEX role_permission_permission ON role_permission (permission_code);

-- ── Users ───────────────────────────────────────────────────────────────────

CREATE TABLE app_user (                                                        -- PII
  user_id           uuid PRIMARY KEY,
  customer_id       uuid NOT NULL,                                             -- customer database; staff use the platform's own customer row
  user_type_code    text NOT NULL REFERENCES user_type (user_type_code),
  email             text NOT NULL UNIQUE CHECK (email = lower(email) AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$'),
  display_name      text CHECK (display_name IS NULL OR char_length(btrim(display_name)) BETWEEN 1 AND 150),
  status_code       text NOT NULL DEFAULT 'INVITED' REFERENCES user_status (status_code),
  status_changed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  first_login_at    timestamptz,                                               -- kept after sign-in history is purged; set by trigger
  last_login_at     timestamptz,                                               -- set by trigger
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  row_version       int NOT NULL DEFAULT 1,
  deleted_at        timestamptz,
  CHECK (first_login_at IS NULL OR last_login_at IS NULL OR last_login_at >= first_login_at)
);
CREATE INDEX app_user_customer ON app_user (customer_id, status_code) WHERE deleted_at IS NULL;
CREATE INDEX app_user_status   ON app_user (status_code);

CREATE TABLE user_status_history (
  history_id         uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),
  from_status_code   text REFERENCES user_status (status_code),                -- null for the first status
  to_status_code     text NOT NULL REFERENCES user_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,                                                     -- null for the system
  reason             text CHECK (reason IS NULL OR char_length(reason) <= 500)
);
CREATE INDEX user_status_history_user ON user_status_history (user_id, changed_at);
CREATE INDEX user_status_history_to   ON user_status_history (to_status_code, changed_at);
CREATE TRIGGER user_status_history_append_only BEFORE UPDATE OR DELETE ON user_status_history
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- As in the customer database: a status change needs a reason, supplied inside the
-- transaction with set_config('app.reason', '<why>', true) (and 'app.actor_id').
-- A user's customer and type never change; to move someone, create a new account.
CREATE FUNCTION app_user_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.user_type_code IS DISTINCT FROM OLD.user_type_code THEN
    RAISE EXCEPTION 'A user''s customer and type cannot change.' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A user status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER app_user_before_update BEFORE UPDATE ON app_user FOR EACH ROW EXECUTE FUNCTION app_user_before_update();

CREATE FUNCTION app_user_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO user_status_history (history_id, user_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.user_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid, nullif(btrim(current_setting('app.reason', true)), ''));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER app_user_status_history_write AFTER INSERT OR UPDATE ON app_user
  FOR EACH ROW EXECUTE FUNCTION app_user_write_status_history();

-- ── Roles held by users ─────────────────────────────────────────────────────
-- One row per grant, with who granted it and when it ended, so "who could do what
-- on a given date" is always answerable.

CREATE TABLE user_role (
  user_role_id uuid PRIMARY KEY,
  user_id      uuid NOT NULL REFERENCES app_user (user_id),
  role_code    text NOT NULL REFERENCES role (role_code),
  granted_by_user_id uuid,
  granted_at   timestamptz NOT NULL DEFAULT now(),
  revoked_at   timestamptz,
  revoked_by_user_id uuid,
  CHECK (revoked_at IS NULL OR revoked_at >= granted_at)
);
CREATE UNIQUE INDEX user_role_one_active ON user_role (user_id, role_code) WHERE revoked_at IS NULL;
CREATE INDEX user_role_role ON user_role (role_code) WHERE revoked_at IS NULL;

-- A customer user can only hold a customer role, and a staff user a staff role.
-- Checked here (not by copying the type into this table) so the type is stored once.
CREATE FUNCTION user_role_type_matches() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE who text; what text;
BEGIN
  SELECT u.user_type_code INTO who FROM app_user u WHERE u.user_id = NEW.user_id;
  SELECT r.user_type_code INTO what FROM role r WHERE r.role_code = NEW.role_code;
  IF who IS DISTINCT FROM what THEN
    RAISE EXCEPTION 'Role % is for % users, but this user is a % user.', NEW.role_code, what, who USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER user_role_type_matches BEFORE INSERT ON user_role FOR EACH ROW EXECUTE FUNCTION user_role_type_matches();

-- ── Invitations ─────────────────────────────────────────────────────────────

CREATE TABLE user_invitation (
  invitation_id       uuid PRIMARY KEY,
  customer_id         uuid NOT NULL,                                           -- customer database
  email               text NOT NULL CHECK (email = lower(email) AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$'),   -- PII
  role_code           text NOT NULL REFERENCES role (role_code),
  invited_by_user_id  uuid NOT NULL REFERENCES app_user (user_id),
  created_at          timestamptz NOT NULL DEFAULT now(),
  expires_at          timestamptz NOT NULL,
  accepted_at         timestamptz,
  accepted_user_id    uuid REFERENCES app_user (user_id),
  cancelled_at        timestamptz,
  CHECK (expires_at > created_at),
  CHECK ((accepted_at IS NULL) = (accepted_user_id IS NULL)),
  CHECK (accepted_at IS NULL OR cancelled_at IS NULL)
);
-- One open invitation per person per customer. A new invite cancels the old one.
CREATE UNIQUE INDEX user_invitation_one_open ON user_invitation (customer_id, email) WHERE accepted_at IS NULL AND cancelled_at IS NULL;
CREATE INDEX user_invitation_customer ON user_invitation (customer_id, created_at);

CREATE FUNCTION invitation_email_not_registered() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM app_user WHERE email = NEW.email) THEN
    RAISE EXCEPTION 'That email address already has an account.' USING ERRCODE = 'unique_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER invitation_email_not_registered BEFORE INSERT ON user_invitation FOR EACH ROW EXECUTE FUNCTION invitation_email_not_registered();

-- ── One-time codes (OTP) ────────────────────────────────────────────────────

CREATE TABLE otp_challenge (
  challenge_id uuid PRIMARY KEY,
  user_id      uuid NOT NULL REFERENCES app_user (user_id),
  code_hmac    text NOT NULL CHECK (code_hmac ~ '^[0-9a-f]{64}$'),             -- never the code itself
  purpose      text NOT NULL DEFAULT 'login' CHECK (purpose IN ('login')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  attempts     int NOT NULL DEFAULT 0,
  max_attempts int NOT NULL DEFAULT 5 CHECK (max_attempts BETWEEN 1 AND 10),
  closed_at    timestamptz,
  close_reason text CHECK (close_reason IN ('verified', 'superseded', 'expired', 'too_many_attempts')),
  CHECK (expires_at > created_at),
  CHECK (attempts >= 0 AND attempts <= max_attempts),
  CHECK ((closed_at IS NULL) = (close_reason IS NULL))
);
-- At most one live code per user: issuing a new one closes the old one as 'superseded'.
CREATE UNIQUE INDEX otp_challenge_one_open ON otp_challenge (user_id) WHERE closed_at IS NULL;
CREATE INDEX otp_challenge_cleanup ON otp_challenge (created_at);

-- ── Sessions ────────────────────────────────────────────────────────────────

CREATE TABLE session (
  session_id         uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),             -- the user's customer is found through the user, not copied here
  refresh_token_hash text NOT NULL UNIQUE CHECK (refresh_token_hash ~ '^[0-9a-f]{64}$'),
  family_id          uuid NOT NULL,                                           -- every token in one rotation chain shares it
  replaced_by_session_id uuid REFERENCES session (session_id),
  created_at         timestamptz NOT NULL DEFAULT now(),
  expires_at         timestamptz NOT NULL,
  revoked_at         timestamptz,
  revoke_reason      text CHECK (revoke_reason IN ('logout', 'rotated', 'reuse_detected', 'admin', 'user_disabled')),
  CHECK (expires_at > created_at),
  CHECK ((revoked_at IS NULL) = (revoke_reason IS NULL)),
  CHECK (replaced_by_session_id IS NULL OR revoke_reason = 'rotated')
);
CREATE INDEX session_user_live ON session (user_id) WHERE revoked_at IS NULL;
CREATE INDEX session_family     ON session (family_id);

-- ── Sign-in history and product activity (large, append-only, monthly partitions)
-- These are event facts: they record who and where AT THAT TIME, so they keep their
-- own customer_id rather than looking it up. A fact about the past must not change
-- if the present changes.

CREATE TABLE login_event (
  login_event_id    uuid NOT NULL,
  user_id           uuid REFERENCES app_user (user_id),                       -- null when the email matched nobody
  customer_id       uuid,
  outcome_code      text NOT NULL REFERENCES login_outcome (outcome_code),
  reason            text,
  occurred_at       timestamptz NOT NULL,
  ip_hash           text,                                                     -- never the raw address
  user_agent_family text,
  PRIMARY KEY (login_event_id, occurred_at)
) PARTITION BY RANGE (occurred_at);
CREATE TABLE login_event_default PARTITION OF login_event DEFAULT;
CREATE INDEX login_event_customer_time ON login_event (customer_id, occurred_at);
CREATE INDEX login_event_user_time     ON login_event (user_id, occurred_at);
CREATE TRIGGER login_event_append_only BEFORE UPDATE OR DELETE ON login_event FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A successful sign-in keeps the user's first and last login up to date.
CREATE FUNCTION login_event_update_user() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.outcome_code = 'SUCCESS' AND NEW.user_id IS NOT NULL THEN
    UPDATE app_user
       SET first_login_at = COALESCE(first_login_at, NEW.occurred_at),
           last_login_at  = GREATEST(COALESCE(last_login_at, NEW.occurred_at), NEW.occurred_at)
     WHERE user_id = NEW.user_id;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER login_event_update_user AFTER INSERT ON login_event FOR EACH ROW EXECUTE FUNCTION login_event_update_user();

CREATE TABLE activity_event (
  activity_event_id uuid NOT NULL,
  customer_id       uuid NOT NULL,
  user_id           uuid NOT NULL REFERENCES app_user (user_id),
  event_type_code   text NOT NULL REFERENCES activity_event_type (event_type_code),
  feature_code      text,                                                     -- a licence-database feature code; no cross-database FK
  resource_type     text,
  resource_id       text,
  occurred_at       timestamptz NOT NULL,
  metadata          jsonb NOT NULL DEFAULT '{}' CHECK (pg_column_size(metadata) <= 4096),   -- small, and never sensitive
  PRIMARY KEY (activity_event_id, occurred_at)
) PARTITION BY RANGE (occurred_at);
CREATE TABLE activity_event_default PARTITION OF activity_event DEFAULT;
CREATE INDEX activity_event_customer_time ON activity_event (customer_id, occurred_at);
CREATE INDEX activity_event_user_time     ON activity_event (user_id, occurred_at);
CREATE INDEX activity_event_feature_time  ON activity_event (feature_code, occurred_at) WHERE feature_code IS NOT NULL;
CREATE TRIGGER activity_event_append_only BEFORE UPDATE OR DELETE ON activity_event FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ── A reporting-friendly read view ──────────────────────────────────────────
-- One row per live user with labels and their current roles.

CREATE VIEW v_user AS
SELECT
  u.user_id, u.customer_id, t.label AS user_type, u.email, u.display_name,
  s.label AS status, u.status_changed_at, u.first_login_at, u.last_login_at, u.created_at,
  (SELECT string_agg(ur.role_code, ', ' ORDER BY ur.role_code)
     FROM user_role ur WHERE ur.user_id = u.user_id AND ur.revoked_at IS NULL) AS roles
FROM app_user u
JOIN user_type t   ON t.user_type_code = u.user_type_code
JOIN user_status s ON s.status_code = u.status_code
WHERE u.deleted_at IS NULL;

COMMIT;

-- ============================================================================
-- Source: db/identity/002_reference_data.sql
-- ============================================================================

-- Fixed reference data the application relies on. Safe to run more than once.
INSERT INTO user_type (user_type_code, label) VALUES ('customer', 'Customer user'), ('staff', 'Staff user') ON CONFLICT DO NOTHING;

INSERT INTO user_status (status_code, label, sort_order) VALUES
  ('INVITED', 'Invited', 1), ('ACTIVE', 'Active', 2), ('LOCKED', 'Locked', 3), ('DISABLED', 'Disabled', 4)
ON CONFLICT DO NOTHING;

INSERT INTO login_outcome (outcome_code, label) VALUES
  ('OTP_SENT', 'Code sent'), ('SUCCESS', 'Signed in'), ('FAILED', 'Wrong or expired code'), ('LOCKED', 'Blocked: account locked')
ON CONFLICT DO NOTHING;

INSERT INTO activity_event_type (event_type_code, label, description) VALUES
  ('LOGIN', 'Signed in', NULL), ('LOGOUT', 'Signed out', NULL),
  ('FEATURE_USED', 'Used a feature', 'feature_code says which'),
  ('REPORT_VIEWED', 'Viewed a report', NULL), ('REPORT_EXPORTED', 'Exported a report', NULL),
  ('ALERT_VIEWED', 'Viewed an alert', NULL), ('SETTINGS_CHANGED', 'Changed settings', NULL),
  ('USER_INVITED', 'Invited a user', NULL), ('LICENSE_VIEWED', 'Viewed the licence', NULL)
ON CONFLICT DO NOTHING;

INSERT INTO role (role_code, label, user_type_code) VALUES
  ('CUSTOMER_USER',  'Customer user',  'customer'),
  ('CUSTOMER_ADMIN', 'Customer admin', 'customer'),
  ('SUPPORT',        'Support',        'staff'),
  ('PLATFORM_ADMIN', 'Platform admin', 'staff')
ON CONFLICT DO NOTHING;

INSERT INTO permission (permission_code, description) VALUES
  ('CUSTOMER_READ',    'View customer details'),
  ('CUSTOMER_UPDATE',  'Change customer details'),
  ('LICENSE_READ',     'View licences and entitlements'),
  ('LICENSE_UPDATE',   'Change licences and entitlements'),
  ('LICENSE_ACTIVATE', 'Activate or renew a licence'),
  ('LICENSE_SUSPEND',  'Suspend or cancel a licence'),
  ('INVOICE_READ',     'View invoices'),
  ('REPORT_READ',      'View reports'),
  ('USER_READ',        'View users'),
  ('USER_MANAGE',      'Invite, change and disable users'),
  ('AUDIT_READ',       'View the audit log')
ON CONFLICT DO NOTHING;

-- Which role gets which permission is DATA, so it can change without a deploy.
-- Support here cannot suspend a licence or manage users; the owner has not yet
-- decided whether support should have full access (open decision).
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('CUSTOMER_USER',  'LICENSE_READ'), ('CUSTOMER_USER',  'REPORT_READ'),
  ('CUSTOMER_ADMIN', 'LICENSE_READ'), ('CUSTOMER_ADMIN', 'REPORT_READ'), ('CUSTOMER_ADMIN', 'USER_READ'),
  ('CUSTOMER_ADMIN', 'USER_MANAGE'),  ('CUSTOMER_ADMIN', 'INVOICE_READ'),
  ('SUPPORT', 'CUSTOMER_READ'), ('SUPPORT', 'CUSTOMER_UPDATE'), ('SUPPORT', 'LICENSE_READ'), ('SUPPORT', 'LICENSE_UPDATE'),
  ('SUPPORT', 'LICENSE_ACTIVATE'), ('SUPPORT', 'INVOICE_READ'), ('SUPPORT', 'REPORT_READ'), ('SUPPORT', 'USER_READ'), ('SUPPORT', 'AUDIT_READ')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) SELECT 'PLATFORM_ADMIN', permission_code FROM permission
ON CONFLICT DO NOTHING;

-- ============================================================================
-- Source: db/identity/003_admin_audit.up.sql
-- ============================================================================

-- Identity database, migration 003: what staff did through the support API.
--
-- Every change (and every read of a customer's personal data) is written here BEFORE it is made ('started') and again when it ends
-- ('done' or 'failed'), because the change itself lives in another database and cannot share this transaction. A 'started' row with no
-- matching 'done' or 'failed' means the service stopped in the middle: look at it. Append-only. `detail` holds references and codes
-- (a plan, a status, a licence id), never a licence key, a code, a token or free text a customer wrote.

BEGIN;

CREATE TABLE admin_audit (
  audit_id      uuid PRIMARY KEY,
  occurred_at   timestamptz NOT NULL DEFAULT clock_timestamp(),
  actor_user_id uuid NOT NULL REFERENCES app_user (user_id),
  action        text NOT NULL CHECK (action ~ '^[a-z_]+\.[a-z_]+$'),           -- purchase_request.update, licence.create, ...
  subject_ref   text CHECK (subject_ref IS NULL OR char_length(subject_ref) <= 100),
  reason        text CHECK (reason IS NULL OR char_length(reason) BETWEEN 1 AND 500),
  outcome       text NOT NULL CHECK (outcome IN ('started', 'done', 'failed', 'read')),
  started_audit_id uuid REFERENCES admin_audit (audit_id),                     -- on 'done' and 'failed': which 'started' row this ends
  detail        jsonb NOT NULL DEFAULT '{}' CHECK (pg_column_size(detail) <= 4096),
  request_id    text CHECK (request_id IS NULL OR char_length(request_id) <= 64),
  CHECK ((outcome IN ('done', 'failed')) = (started_audit_id IS NOT NULL))
);
CREATE INDEX admin_audit_actor   ON admin_audit (actor_user_id, occurred_at);
CREATE INDEX admin_audit_subject ON admin_audit (subject_ref, occurred_at) WHERE subject_ref IS NOT NULL;
CREATE UNIQUE INDEX admin_audit_one_end ON admin_audit (started_audit_id) WHERE started_audit_id IS NOT NULL;   -- a change ends once
CREATE TRIGGER admin_audit_append_only BEFORE UPDATE OR DELETE ON admin_audit FOR EACH ROW EXECUTE FUNCTION forbid_change();

COMMIT;

-- ============================================================================
-- Source: db/identity/004_domain_attach_permission.up.sql
-- ============================================================================

-- Identity database, migration 004: attaching an email domain to a customer gets its own permission.
--
-- A domain decides who may activate a customer's licence by typing an address there, and support marks it verified on the spot. That is
-- a bigger grant than adding a note, so it is a separate permission and only PLATFORM_ADMIN has it by default. To let support attach
-- domains: INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'DOMAIN_ATTACH');   (who may do what is data)

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('DOMAIN_ATTACH', 'Attach an email domain to a customer (grants its people access to its licences)') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'DOMAIN_ATTACH') ON CONFLICT DO NOTHING;
COMMIT;

-- ============================================================================
-- Source: db/identity/005_block_manage_permission.up.sql
-- ============================================================================

-- Identity database, migration 005: blocking machines gets its own permission.
--
-- A block stops a machine from using OASIS at all (trials, activation, every call), so it is a separate permission, and only PLATFORM_ADMIN
-- has it by default (the plan: support proposes, a platform admin applies). To let support do it:
--   INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'BLOCK_MANAGE');

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('BLOCK_MANAGE', 'Block and unblock machines (stops them using OASIS, trials included)') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'BLOCK_MANAGE') ON CONFLICT DO NOTHING;
COMMIT;

-- ============================================================================
-- Source: db/identity/006_support_message_permissions.up.sql
-- ============================================================================

-- Identity database, migration 006: permissions for the messages people send from the app (feedback and "contact support").
--
-- They hold personal data: an email address, a name and FREE TEXT a person wrote. Reading and answering them are separate permissions, so who may do what stays data.
-- Both staff roles get them by default (this is the support team's daily work). To take one away: DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = '...';

BEGIN;
INSERT INTO permission (permission_code, description) VALUES
  ('SUPPORT_REQUEST_READ',   'Read support requests (name, address and what the person wrote)'),
  ('SUPPORT_REQUEST_UPDATE', 'Answer a support request: assign it, move its status, add notes'),
  ('FEEDBACK_READ',          'Read feedback sent from the app')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('SUPPORT', 'SUPPORT_REQUEST_READ'), ('SUPPORT', 'SUPPORT_REQUEST_UPDATE'), ('SUPPORT', 'FEEDBACK_READ'),
  ('PLATFORM_ADMIN', 'SUPPORT_REQUEST_READ'), ('PLATFORM_ADMIN', 'SUPPORT_REQUEST_UPDATE'), ('PLATFORM_ADMIN', 'FEEDBACK_READ')
ON CONFLICT DO NOTHING;
COMMIT;

-- ============================================================================
-- Source: db/identity/007_portal_roles.up.sql
-- ============================================================================

-- Identity database, migration 007: the portal's two roles, "user" and "admin".
--
-- The portal shows two roles to people: USER (the schema's SUPPORT role) and ADMIN (PLATFORM_ADMIN). The role codes stay as they are; the portal says "user" and "admin".
--
--   user   works the customer requests: reads them, calls the customer, writes notes, moves the status, creates the licence once it is agreed, attaches the customer's
--          email domain (the app cannot activate by email without it), extends or renews, and finds trials.
--   admin  all of that, plus: assign requests, add and manage team members, suspend / cancel / revoke a licence, block machines, and read the audit log.
--
-- Who may do what is data (role_permission), so any of this can be changed without a deploy.

BEGIN;

INSERT INTO permission (permission_code, description) VALUES ('REQUEST_ASSIGN', 'Assign customer requests to a team member') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'REQUEST_ASSIGN') ON CONFLICT DO NOTHING;

-- The customer can only activate by email once their domain is attached, and creating the licence is the user's job, so attaching the domain is too.
-- (Public mail domains are still refused, every attach needs a reason and is audited.)
INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'DOMAIN_ATTACH') ON CONFLICT DO NOTHING;

-- The audit log is for admins. (The identity design gave it to support; the portal does not.)
DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'AUDIT_READ';

COMMIT;

-- ============================================================================
-- Source: db/identity/008_unlimited_licences.up.sql
-- ============================================================================

-- Identity database, migration 008: the biggest licences need an admin.
--
-- A user creates licences once a customer has agreed them (migration 007). Two choices make a licence much larger than the usual: unlimited seats (an enterprise licence) and a very long term. Those need
-- the LICENSE_UNLIMITED permission, which only admins have by default. Everything else a user can do alone is bounded by the plans' own sizes.
--   admin only: kind = enterprise, seats = unlimited, a term over 730 days.
-- To let users do it: INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'LICENSE_UNLIMITED');

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('LICENSE_UNLIMITED', 'Create an enterprise licence, one with unlimited seats, or one longer than 730 days') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'LICENSE_UNLIMITED') ON CONFLICT DO NOTHING;
COMMIT;

-- ============================================================================
-- Source: db/identity/009_report_read_admin_only.up.sql
-- ============================================================================

-- Identity database, migration 009: the Reports screen is for admins.
--
-- REPORT_READ ("View reports") was given to SUPPORT by the identity design. The portal's Reports screen shows totals across all customers and every team member's workload, so it is
-- admin only. Who may read it is data: to let users see it, INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'REPORT_READ');

BEGIN;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'REPORT_READ') ON CONFLICT DO NOTHING;
DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'REPORT_READ';
COMMIT;

-- ============================================================================
-- Source: db/identity/010_staff_passwords.up.sql
-- ============================================================================

-- Identity database, migration 010: staff sign in with an email address and a password.
--
-- Until now staff signed in with an emailed one-time code and had no password. They now have a password, kept ONLY as a salted scrypt hash (see src/password.js); the plain
-- password is never stored or logged. A member without a row here has not set a password yet: they use "Forgot or set your password" on the sign-in page, which emails the same
-- 6-digit code as before and lets them choose one. Wrong passwords are counted per person, and after five the account pauses for 15 minutes (locked_until).

BEGIN;

CREATE TABLE staff_credential (
  user_id             uuid PRIMARY KEY REFERENCES app_user (user_id),
  password_hash       text NOT NULL CHECK (password_hash LIKE 'scrypt$%'),
  password_changed_at timestamptz NOT NULL DEFAULT now(),
  failed_attempts     int NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  locked_until        timestamptz
);

-- A password reset or change ends sessions, and says why.
ALTER TABLE session DROP CONSTRAINT session_revoke_reason_check;
ALTER TABLE session ADD CONSTRAINT session_revoke_reason_check
  CHECK (revoke_reason IN ('logout', 'rotated', 'reuse_detected', 'admin', 'user_disabled', 'password_reset', 'password_changed'));

INSERT INTO login_outcome (outcome_code, label) VALUES ('PASSWORD_SET', 'Password set, reset or changed') ON CONFLICT DO NOTHING;

COMMIT;

-- ============================================================================
-- Source: db/identity/011_staff_links.up.sql
-- ============================================================================

-- Identity database, migration 011: activation and password-reset LINKS for staff.
--
-- A new team member is "Pending activation" (status INVITED) until they open the emailed activation link and choose a password; an admin can also email a password-reset link to
-- anyone active. A link carries a long random secret that is stored here ONLY as a keyed hash, so a copy of the database cannot be used to open one. Each link:
--   * has one purpose ('activate' or 'reset') and works only for that purpose, and only while the account is in the matching state (INVITED / ACTIVE);
--   * works once (used_at), until it expires (expires_at), and is replaced if a newer one is sent (revoked_at): at most one open link per person per purpose.
-- This replaces the emailed 6-digit codes of migration 010 for staff; the otp_challenge table is no longer used by the portal.

BEGIN;

CREATE TABLE staff_link (
  link_id            uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),
  purpose            text NOT NULL CHECK (purpose IN ('activate', 'reset')),
  token_hash         text NOT NULL UNIQUE CHECK (token_hash ~ '^[0-9a-f]{64}$'),
  expires_at         timestamptz NOT NULL,
  used_at            timestamptz,
  revoked_at         timestamptz,
  created_by_user_id uuid,                                  -- the admin who sent it; null when the person asked for it themselves
  created_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX staff_link_one_open ON staff_link (user_id, purpose) WHERE used_at IS NULL AND revoked_at IS NULL;
CREATE INDEX staff_link_recent ON staff_link (user_id, created_at);

INSERT INTO login_outcome (outcome_code, label) VALUES ('LINK_SENT', 'Activation or reset link sent') ON CONFLICT DO NOTHING;

COMMIT;

-- ============================================================================
-- Source: db/identity/012_admin_tools.up.sql
-- ============================================================================

-- Identity database, migration 012: tools for admins and staff.
--
--   * Permissions for the new admin actions (all admin only by default; who may do what is data, so it can be changed without a deploy):
--       LICENSE_MODIFY       change a licence's seats or plan, release one seat
--       CUSTOMER_MANAGE      edit a customer's details
--       CUSTOMER_USER_MANAGE disable, enable, remove or re-invite a customer's own users
--   * staff_notification / staff_notification_state: what the bell in the top bar shows (a request assigned to you; new requests since you last looked).
--   * customer_note: notes the team keeps on a customer. Append-only. Free text: personal data may be in it.
--   * customer_reply: a record of every reply sent to a customer from the portal. Free text: personal data may be in it.
--   * retention_guard: the audit trail, the sign-in history and the reply record stay append-only, EXCEPT that the retention job (src/retention.js) may delete rows past their
--     retention period. It says so by setting app.retention = 'on' inside its own transaction; nothing else in the portal does. Updates are never allowed.
-- The portal owns these tables; nothing here touches the customer, licence or support databases.

BEGIN;

INSERT INTO permission (permission_code, description) VALUES
  ('LICENSE_MODIFY', 'Change a licence''s seats or plan, or release one seat'),
  ('CUSTOMER_MANAGE', 'Edit a customer''s details'),
  ('CUSTOMER_USER_MANAGE', 'Disable, enable, remove or re-invite a customer''s own users')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('PLATFORM_ADMIN', 'LICENSE_MODIFY'), ('PLATFORM_ADMIN', 'CUSTOMER_MANAGE'), ('PLATFORM_ADMIN', 'CUSTOMER_USER_MANAGE')
ON CONFLICT DO NOTHING;

CREATE TABLE staff_notification (
  notification_id uuid PRIMARY KEY,
  user_id         uuid NOT NULL REFERENCES app_user (user_id),
  kind            text NOT NULL CHECK (kind IN ('assigned')),
  subject_kind    text NOT NULL CHECK (subject_kind IN ('licence_request', 'help_request')),
  reference       text NOT NULL CHECK (char_length(reference) BETWEEN 1 AND 100),
  title           text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
  created_at      timestamptz NOT NULL DEFAULT now(),
  read_at         timestamptz
);
CREATE INDEX staff_notification_user ON staff_notification (user_id, created_at DESC);
CREATE INDEX staff_notification_unread ON staff_notification (user_id) WHERE read_at IS NULL;

CREATE TABLE staff_notification_state (
  user_id uuid PRIMARY KEY REFERENCES app_user (user_id),
  seen_at timestamptz NOT NULL DEFAULT now()                    -- requests that arrived after this are "new" to this person
);

CREATE TABLE customer_note (
  note_id            uuid PRIMARY KEY,
  customer_id        uuid NOT NULL,                              -- customer database; no cross-database FK
  body               text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 4000),     -- free text
  created_by_user_id uuid NOT NULL REFERENCES app_user (user_id),
  created_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_note_customer ON customer_note (customer_id, created_at);
CREATE TRIGGER customer_note_append_only BEFORE UPDATE OR DELETE ON customer_note FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE customer_reply (
  reply_id         uuid PRIMARY KEY,
  kind             text NOT NULL CHECK (kind IN ('licence_request', 'help_request')),
  reference        text NOT NULL CHECK (char_length(reference) BETWEEN 1 AND 100),
  sent_by_user_id  uuid NOT NULL REFERENCES app_user (user_id),
  subject          text NOT NULL CHECK (char_length(btrim(subject)) BETWEEN 1 AND 200),
  body             text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 4000),     -- free text
  delivery         text NOT NULL CHECK (delivery IN ('sent', 'failed', 'not_connected')),  -- not_connected: no email provider yet, so it was recorded but not delivered
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_reply_request ON customer_reply (kind, reference, created_at);

CREATE FUNCTION retention_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('app.retention', true) = 'on' THEN RETURN OLD; END IF;
  RAISE EXCEPTION '% rows are append-only: they are only ever deleted by the retention job', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

DROP TRIGGER admin_audit_append_only ON admin_audit;
CREATE TRIGGER admin_audit_append_only BEFORE UPDATE OR DELETE ON admin_audit FOR EACH ROW EXECUTE FUNCTION retention_guard();
DROP TRIGGER login_event_append_only ON login_event;
CREATE TRIGGER login_event_append_only BEFORE UPDATE OR DELETE ON login_event FOR EACH ROW EXECUTE FUNCTION retention_guard();
DROP TRIGGER activity_event_append_only ON activity_event;
CREATE TRIGGER activity_event_append_only BEFORE UPDATE OR DELETE ON activity_event FOR EACH ROW EXECUTE FUNCTION retention_guard();
CREATE TRIGGER customer_reply_append_only BEFORE UPDATE OR DELETE ON customer_reply FOR EACH ROW EXECUTE FUNCTION retention_guard();

COMMIT;

-- ============================================================================
-- Source: db/identity/013_invoice_permissions.up.sql
-- ============================================================================

-- Identity database, migration 013: invoicing permissions.
--
--   INVOICE_READ    (already exists; SUPPORT and PLATFORM_ADMIN hold it) see invoices, the follow-ups queue and the bell's follow-up count
--   INVOICE_WRITE   create and edit drafts, issue, mark sent, share links, record payments, log follow-ups (SUPPORT = "user", PLATFORM_ADMIN = "admin")
--   INVOICE_ADMIN   void an invoice or a payment, raise a credit note, change an invoice's owner, see the Billing reports and export (PLATFORM_ADMIN only)
--
-- A staff member's role in the billing service is "admin" when they hold INVOICE_ADMIN, otherwise "user". Who holds what is data: change role_permission, not code.
-- The billing service enforces the same split itself (its action_role table); the portal's check only decides what is shown and avoids a pointless call.

BEGIN;
INSERT INTO permission (permission_code, description) VALUES
  ('INVOICE_WRITE', 'Create and edit invoices, issue them, share them, record payments and log follow-ups'),
  ('INVOICE_ADMIN', 'Void invoices and payments, raise credit notes, change an invoice''s owner, and see the Billing reports')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('SUPPORT', 'INVOICE_WRITE'), ('PLATFORM_ADMIN', 'INVOICE_WRITE'), ('PLATFORM_ADMIN', 'INVOICE_ADMIN')
ON CONFLICT DO NOTHING;
COMMIT;

-- ============================================================================
-- Migration bookkeeping (same filename and sha256 checksum that src/migrate.js records)
-- ============================================================================

INSERT INTO schema_migration (filename, checksum) VALUES
  ('001_identity_schema.up.sql', '885cd72e68310b2156020c5fecd0938bf0f2206548e7e1ac4fabf531187685c6'),
  ('002_reference_data.sql', '2d61837d7dfb317bddd3158075204f31cdb3bc50ee9b657b7d0e38b8eff1445e'),
  ('003_admin_audit.up.sql', 'd6eccd9fe6ddebf323f5823d777fb63b5f98fdea60eb5f7cd7127fcb342315d9'),
  ('004_domain_attach_permission.up.sql', 'ff48ba44175b07066f98031c75a84695d3fc73e35149e6ada260545dc09fbdd3'),
  ('005_block_manage_permission.up.sql', '8f19e150cbc6c2e16ba6082157353c9908a0a6617159b28009f27d9a94b0e0dd'),
  ('006_support_message_permissions.up.sql', '5577f993128e28336c29908e7125c06db4be2dd1fac7b9a4cd69f860cc4351ae'),
  ('007_portal_roles.up.sql', '38a0d88400a2ee413d16450a926e59951f81ed440a3f2baea7d80d36a9b5561c'),
  ('008_unlimited_licences.up.sql', 'e0668f584567b86a10db9430eaeabe7acab61931301004e4ff26496a87b0d290'),
  ('009_report_read_admin_only.up.sql', 'b73e200a682a68013b6d6aafcddb16d9eadeb9e937791612103d5f799c89911c'),
  ('010_staff_passwords.up.sql', 'b572abcdb59755c1eb5c69d724380dd6d6fa87104acdb1a4fde278849a6ac7c1'),
  ('011_staff_links.up.sql', '672af7c2b024a89d0bdc792e44978be80bd0d9e0e5373395e412b534483681c4'),
  ('012_admin_tools.up.sql', 'b60554d9642cf97fc21846c482a8b0ade2d79cc302d2f35e5fa168d4a292b877'),
  ('013_invoice_permissions.up.sql', '33822e86fdadce2b795b2b95769aca588f3f1dd9115e8df23faff7b73a40b580');
