-- DEV ONLY. SYNTHETIC DATA. Never run this against a shared, staging or production database.
--
-- Run after 01_identity_schema_and_seed.sql, on a local database:
--   psql "postgres://APP_USER:PASSWORD@HOST:5432/identity_db" -v ON_ERROR_STOP=1 -f db/setup/02_optional_demo_data.sql
--
-- Adds one platform admin, "Pending activation" (status INVITED), with NO password and NO row in staff_credential. That is deliberate:
-- there is no usable password hash to leak or guess. The person sets a password through the activation link flow: on the sign-in page
-- choose "Forgot or set your password", enter this address, and the portal issues an activation link (with NOTIFIER=fake and
-- DEV_PRINT_CODES=1 it is printed in the server's terminal). Opening the link and choosing a password makes the account Active.
--
-- The customer_id below is a made-up uuid. Put the same value in PLATFORM_CUSTOMER_ID in .env, and create a matching "platform" row in
-- customer_db (owned by oasis-licence-service) if you want the rest of the portal to work. The address uses example.test (reserved, never
-- delivers), so set STAFF_EMAIL_DOMAINS to blank or to example.test locally.
-- (`npm run demo` is the easier way to see the portal with data: it builds throwaway databases of its own.)

\set ON_ERROR_STOP on

BEGIN;

INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code)
VALUES ('00000000-0000-7000-8000-0000000000a1', '00000000-0000-7000-8000-000000000001', 'staff', 'admin@staff.example.test', 'Example Admin (dev only)', 'INVITED');

INSERT INTO user_role (user_role_id, user_id, role_code)
VALUES ('00000000-0000-7000-8000-0000000000b1', '00000000-0000-7000-8000-0000000000a1', 'PLATFORM_ADMIN');

COMMIT;
