-- Creates the four databases the support portal talks to, and one application login role for it.
--
-- Run as a PostgreSQL superuser (or a role with CREATEDB and CREATEROLE), once per server:
--   psql "postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432/postgres" -v ON_ERROR_STOP=1 -f db/setup/00_create_databases_and_roles.sql
--
-- Psql meta-commands used: \set ON_ERROR_STOP, and \c (connect to another database) to grant access inside each database.
-- This file is therefore for psql, not for a GUI that sends plain SQL.
--
-- WHO OWNS WHAT
--   identity_db  owned by THIS repo. 01_identity_schema_and_seed.sql (or `npm run migrate`) builds it.
--   customer_db  owned by oasis-licence-service, which creates and migrates its tables (see that repo's own setup files).
--   license_db   owned by oasis-licence-service (same).
--   support_db   owned by oasis-support-service, which creates and migrates its tables (see that repo's own setup files).
--   The portal reads and writes customer_db, license_db and support_db directly; it never creates their tables.
--
-- SECRETS: the password below is a PLACEHOLDER. Replace it before running, with a value generated and kept in a secret manager. Never
-- commit the real value, and never put it in a README or a shell history you share.
--
-- NOTE: no PostgreSQL extensions are needed. The identity migrations use only built-in features (gen_random_uuid() is built in from
-- PostgreSQL 13). If a sibling repo's setup files need an extension (for example pgcrypto or btree_gist), they create it themselves.

\set ON_ERROR_STOP on

-- The application role: can log in, nothing else (no superuser, no database or role creation).
CREATE ROLE oasis_portal_app LOGIN PASSWORD 'CHANGE_ME_use_a_secret_manager'
  NOSUPERUSER NOCREATEDB NOCREATEROLE;

-- identity_db is owned by the application role, so `npm run migrate` (which uses IDENTITY_DATABASE_URL) can create its tables. In a
-- stricter setup, own it with a separate migration role and give the application role only the table privileges.
CREATE DATABASE identity_db OWNER oasis_portal_app ENCODING 'UTF8';

-- The sibling services' databases. They stay owned by the administrator here; their repos' setup files create the tables.
CREATE DATABASE customer_db ENCODING 'UTF8';
CREATE DATABASE license_db  ENCODING 'UTF8';
CREATE DATABASE support_db  ENCODING 'UTF8';

-- Nobody but the owner and the application role may connect.
REVOKE CONNECT ON DATABASE identity_db FROM PUBLIC;
REVOKE CONNECT ON DATABASE customer_db FROM PUBLIC;
REVOKE CONNECT ON DATABASE license_db  FROM PUBLIC;
REVOKE CONNECT ON DATABASE support_db  FROM PUBLIC;
GRANT CONNECT ON DATABASE customer_db TO oasis_portal_app;
GRANT CONNECT ON DATABASE license_db  TO oasis_portal_app;
GRANT CONNECT ON DATABASE support_db  TO oasis_portal_app;

-- Let the application role use the public schema of each sibling database.
\c customer_db
GRANT USAGE ON SCHEMA public TO oasis_portal_app;
\c license_db
GRANT USAGE ON SCHEMA public TO oasis_portal_app;
\c support_db
GRANT USAGE ON SCHEMA public TO oasis_portal_app;
\c postgres

-- AFTER the sibling repos have created their tables, grant the portal access to them (run as the role that owns those tables, in each
-- database; tighten to the tables the portal really uses if your policy requires it):
--   GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO oasis_portal_app;
--   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO oasis_portal_app;
-- Their functions and triggers run with the caller's rights; check each repo's README for anything further it needs.
