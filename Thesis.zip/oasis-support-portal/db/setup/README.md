# Database setup

Plain SQL to stand up the databases the support portal uses on a new PostgreSQL 16 server. Nothing here contains a real secret: every
password is a placeholder. Generate real values and keep them in a secret manager.

| File | What it does | Run as |
|---|---|---|
| `00_create_databases_and_roles.sql` | Creates `identity_db`, `customer_db`, `license_db`, `support_db` and the login role `oasis_portal_app` (placeholder password: **edit it first**). Uses psql's `\c`. | a superuser, connected to `postgres` |
| `01_identity_schema_and_seed.sql` | The whole identity schema and its reference data (roles, permissions, lookups): `db/identity/001` to `011` in order, plus `schema_migration` rows. **Generated**: see below. | the application role (or owner), on `identity_db` |
| `02_optional_demo_data.sql` | DEV ONLY: one synthetic admin (`admin@staff.example.test`) with no password. Never on a shared or production database. | same, on a local `identity_db` |

Only `identity_db` belongs to this repo. `customer_db` and `license_db` belong to `oasis-licence-service`, and `support_db` to
`oasis-support-service`: create their tables with the setup files or `npm run migrate` in those repos (the sibling repos sit next to this one,
`../oasis-licence-service` and `../oasis-support-service`). The portal needs all four.

## Run

Replace `ADMIN_USER`, `APP_USER`, `HOST` and the passwords (from your secret manager). Edit the password in file 00 first.

```bash
psql "postgres://ADMIN_USER:ADMIN_PASSWORD@HOST:5432/postgres"  -v ON_ERROR_STOP=1 -f db/setup/00_create_databases_and_roles.sql
psql "postgres://APP_USER:APP_PASSWORD@HOST:5432/identity_db"   -v ON_ERROR_STOP=1 -f db/setup/01_identity_schema_and_seed.sql
psql "postgres://APP_USER:APP_PASSWORD@HOST:5432/identity_db"   -v ON_ERROR_STOP=1 -f db/setup/02_optional_demo_data.sql   # optional, dev only
```

Then set up the three sibling databases with their own repos, and grant `oasis_portal_app` access to their tables (the commented
`GRANT` statements at the end of file 00). Put the four connection URLs in `.env` (see the Configuration table in the main README).

Run file 01 **or** `npm run migrate`, not both on an empty database. File 01 records the same filenames and sha256 checksums that
`src/migrate.js` writes into `schema_migration`, so a later `npm run migrate` reports "up to date". The two routes give the same schema.

## Keep file 01 in step with the migrations

`01_identity_schema_and_seed.sql` is built from `db/identity/*.sql` (down files skipped). After adding or changing a migration:

```bash
npm run db:setup:build                  # rewrites the file
node scripts/build-db-setup.js --check  # exits 1 if it is out of date; npm test checks this too (test/db-setup.test.js)
```

## Verify

```sql
\dt                                                    -- 21 tables (including partitions and schema_migration)
SELECT filename FROM schema_migration ORDER BY filename;   -- 11 rows, 001 to 011
SELECT count(*) FROM permission;                       -- 18
SELECT role_code, count(*) FROM role_permission GROUP BY 1 ORDER BY 1;
SELECT email, status_code FROM app_user;               -- after file 02: one INVITED admin
```

Then `npm run migrate` should print `identity: up to date`.

## Reset (local development only)

Drops everything in the identity database. Never run this on a shared or production server.

```sql
-- connected to the postgres database as an admin
DROP DATABASE identity_db WITH (FORCE);
CREATE DATABASE identity_db OWNER oasis_portal_app ENCODING 'UTF8';
```

Then run file 01 (and 02) again. To remove everything this setup made: drop the four databases, then `DROP ROLE oasis_portal_app;`.
