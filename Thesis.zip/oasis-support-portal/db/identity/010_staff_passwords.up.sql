-- Identity database, migration 010: staff sign in with an email address and a password.
--
-- Until now staff signed in with an emailed one-time code and had no password. They now have a password, kept ONLY as a salted scrypt hash (see src/password.js); the plain
-- password is never stored or logged. A member without a row here has not set a password yet: they use "Forgot or set your password" on the sign-in page, which emails the same
-- 6-digit code as before and lets them choose one. Wrong passwords are counted per person, and after five the account pauses for 15 minutes (locked_until).

BEGIN;

CREATE TABLE staff_credential (
  user_id             uuid PRIMARY KEY REFERENCES app_user (user_id),
  password_hash       text NOT NULL CHECK (password_hash LIKE 'scrypt$%'),
  password_changed_at timestamptz NOT NULL DEFAULT now(),
  failed_attempts     int NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  locked_until        timestamptz
);

-- A password reset or change ends sessions, and says why.
ALTER TABLE session DROP CONSTRAINT session_revoke_reason_check;
ALTER TABLE session ADD CONSTRAINT session_revoke_reason_check
  CHECK (revoke_reason IN ('logout', 'rotated', 'reuse_detected', 'admin', 'user_disabled', 'password_reset', 'password_changed'));

INSERT INTO login_outcome (outcome_code, label) VALUES ('PASSWORD_SET', 'Password set, reset or changed') ON CONFLICT DO NOTHING;

COMMIT;
