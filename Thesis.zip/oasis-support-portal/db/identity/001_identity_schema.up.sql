-- Identity database (PostgreSQL 16).
--
-- Owns people and how they get in: user accounts, roles and permissions, one-time
-- codes (OTP), sessions, invitations, sign-in history, and what users do in the
-- product. Customer details live in the customer database; a user points at their
-- customer by customer_id with NO foreign key across databases.
--
-- Normal forms are explained in README.md. Conventions: uuid keys (UUIDv7, made by
-- the application); times are timestamptz (UTC); columns holding personal data are
-- marked -- PII. The outbox/inbox tables for events come from the shared library's
-- migration, not from this file.

BEGIN;

-- ── Shared helpers ──────────────────────────────────────────────────────────

CREATE FUNCTION touch_row() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  RETURN NEW;
END $$;

CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

-- Creates the partition for one month; safe to call repeatedly. A scheduled job
-- calls it for the next three months so rows never land in the default partition.
CREATE FUNCTION ensure_month_partition(parent regclass, month date) RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  start_d date := date_trunc('month', month)::date;
  end_d   date := (date_trunc('month', month) + interval '1 month')::date;
  part    text := format('%s_%s', parent::text, to_char(start_d, 'YYYY_MM'));
BEGIN
  EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %s FOR VALUES FROM (%L) TO (%L)', part, parent, start_d, end_d);
END $$;

-- ── Reference (lookup) tables ───────────────────────────────────────────────
-- Values that reports group by get a lookup table, so a label is stored once and a
-- typo is rejected. Small closed lists used only inside the service use a CHECK.

CREATE TABLE user_type   (user_type_code text PRIMARY KEY, label text NOT NULL);      -- customer, staff
CREATE TABLE user_status (status_code text PRIMARY KEY, label text NOT NULL, sort_order smallint NOT NULL);
CREATE TABLE login_outcome (outcome_code text PRIMARY KEY, label text NOT NULL);
CREATE TABLE activity_event_type (event_type_code text PRIMARY KEY, label text NOT NULL, description text);

CREATE TABLE role (
  role_code      text PRIMARY KEY,
  label          text NOT NULL,
  user_type_code text NOT NULL REFERENCES user_type (user_type_code)      -- who may hold this role
);

CREATE TABLE permission (
  permission_code text PRIMARY KEY CHECK (permission_code ~ '^[A-Z][A-Z_]+$'),
  description     text NOT NULL
);

CREATE TABLE role_permission (
  role_code       text NOT NULL REFERENCES role (role_code),
  permission_code text NOT NULL REFERENCES permission (permission_code),
  PRIMARY KEY (role_code, permission_code)
);
CREATE INDEX role_permission_permission ON role_permission (permission_code);

-- ── Users ───────────────────────────────────────────────────────────────────

CREATE TABLE app_user (                                                        -- PII
  user_id           uuid PRIMARY KEY,
  customer_id       uuid NOT NULL,                                             -- customer database; staff use the platform's own customer row
  user_type_code    text NOT NULL REFERENCES user_type (user_type_code),
  email             text NOT NULL UNIQUE CHECK (email = lower(email) AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$'),
  display_name      text CHECK (display_name IS NULL OR char_length(btrim(display_name)) BETWEEN 1 AND 150),
  status_code       text NOT NULL DEFAULT 'INVITED' REFERENCES user_status (status_code),
  status_changed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  first_login_at    timestamptz,                                               -- kept after sign-in history is purged; set by trigger
  last_login_at     timestamptz,                                               -- set by trigger
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  row_version       int NOT NULL DEFAULT 1,
  deleted_at        timestamptz,
  CHECK (first_login_at IS NULL OR last_login_at IS NULL OR last_login_at >= first_login_at)
);
CREATE INDEX app_user_customer ON app_user (customer_id, status_code) WHERE deleted_at IS NULL;
CREATE INDEX app_user_status   ON app_user (status_code);

CREATE TABLE user_status_history (
  history_id         uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),
  from_status_code   text REFERENCES user_status (status_code),                -- null for the first status
  to_status_code     text NOT NULL REFERENCES user_status (status_code),
  changed_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  changed_by_user_id uuid,                                                     -- null for the system
  reason             text CHECK (reason IS NULL OR char_length(reason) <= 500)
);
CREATE INDEX user_status_history_user ON user_status_history (user_id, changed_at);
CREATE INDEX user_status_history_to   ON user_status_history (to_status_code, changed_at);
CREATE TRIGGER user_status_history_append_only BEFORE UPDATE OR DELETE ON user_status_history
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- As in the customer database: a status change needs a reason, supplied inside the
-- transaction with set_config('app.reason', '<why>', true) (and 'app.actor_id').
-- A user's customer and type never change; to move someone, create a new account.
CREATE FUNCTION app_user_before_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.user_type_code IS DISTINCT FROM OLD.user_type_code THEN
    RAISE EXCEPTION 'A user''s customer and type cannot change.' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  NEW.row_version := OLD.row_version + 1;
  IF NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    IF coalesce(btrim(current_setting('app.reason', true)), '') = '' THEN
      RAISE EXCEPTION 'A user status change needs a reason: set app.reason first.' USING ERRCODE = 'check_violation';
    END IF;
    NEW.status_changed_at := clock_timestamp();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER app_user_before_update BEFORE UPDATE ON app_user FOR EACH ROW EXECUTE FUNCTION app_user_before_update();

CREATE FUNCTION app_user_write_status_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status_code IS DISTINCT FROM OLD.status_code THEN
    INSERT INTO user_status_history (history_id, user_id, from_status_code, to_status_code, changed_by_user_id, reason)
    VALUES (gen_random_uuid(), NEW.user_id, CASE WHEN TG_OP = 'UPDATE' THEN OLD.status_code END, NEW.status_code,
            nullif(current_setting('app.actor_id', true), '')::uuid, nullif(btrim(current_setting('app.reason', true)), ''));
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER app_user_status_history_write AFTER INSERT OR UPDATE ON app_user
  FOR EACH ROW EXECUTE FUNCTION app_user_write_status_history();

-- ── Roles held by users ─────────────────────────────────────────────────────
-- One row per grant, with who granted it and when it ended, so "who could do what
-- on a given date" is always answerable.

CREATE TABLE user_role (
  user_role_id uuid PRIMARY KEY,
  user_id      uuid NOT NULL REFERENCES app_user (user_id),
  role_code    text NOT NULL REFERENCES role (role_code),
  granted_by_user_id uuid,
  granted_at   timestamptz NOT NULL DEFAULT now(),
  revoked_at   timestamptz,
  revoked_by_user_id uuid,
  CHECK (revoked_at IS NULL OR revoked_at >= granted_at)
);
CREATE UNIQUE INDEX user_role_one_active ON user_role (user_id, role_code) WHERE revoked_at IS NULL;
CREATE INDEX user_role_role ON user_role (role_code) WHERE revoked_at IS NULL;

-- A customer user can only hold a customer role, and a staff user a staff role.
-- Checked here (not by copying the type into this table) so the type is stored once.
CREATE FUNCTION user_role_type_matches() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE who text; what text;
BEGIN
  SELECT u.user_type_code INTO who FROM app_user u WHERE u.user_id = NEW.user_id;
  SELECT r.user_type_code INTO what FROM role r WHERE r.role_code = NEW.role_code;
  IF who IS DISTINCT FROM what THEN
    RAISE EXCEPTION 'Role % is for % users, but this user is a % user.', NEW.role_code, what, who USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER user_role_type_matches BEFORE INSERT ON user_role FOR EACH ROW EXECUTE FUNCTION user_role_type_matches();

-- ── Invitations ─────────────────────────────────────────────────────────────

CREATE TABLE user_invitation (
  invitation_id       uuid PRIMARY KEY,
  customer_id         uuid NOT NULL,                                           -- customer database
  email               text NOT NULL CHECK (email = lower(email) AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$'),   -- PII
  role_code           text NOT NULL REFERENCES role (role_code),
  invited_by_user_id  uuid NOT NULL REFERENCES app_user (user_id),
  created_at          timestamptz NOT NULL DEFAULT now(),
  expires_at          timestamptz NOT NULL,
  accepted_at         timestamptz,
  accepted_user_id    uuid REFERENCES app_user (user_id),
  cancelled_at        timestamptz,
  CHECK (expires_at > created_at),
  CHECK ((accepted_at IS NULL) = (accepted_user_id IS NULL)),
  CHECK (accepted_at IS NULL OR cancelled_at IS NULL)
);
-- One open invitation per person per customer. A new invite cancels the old one.
CREATE UNIQUE INDEX user_invitation_one_open ON user_invitation (customer_id, email) WHERE accepted_at IS NULL AND cancelled_at IS NULL;
CREATE INDEX user_invitation_customer ON user_invitation (customer_id, created_at);

CREATE FUNCTION invitation_email_not_registered() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM app_user WHERE email = NEW.email) THEN
    RAISE EXCEPTION 'That email address already has an account.' USING ERRCODE = 'unique_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER invitation_email_not_registered BEFORE INSERT ON user_invitation FOR EACH ROW EXECUTE FUNCTION invitation_email_not_registered();

-- ── One-time codes (OTP) ────────────────────────────────────────────────────

CREATE TABLE otp_challenge (
  challenge_id uuid PRIMARY KEY,
  user_id      uuid NOT NULL REFERENCES app_user (user_id),
  code_hmac    text NOT NULL CHECK (code_hmac ~ '^[0-9a-f]{64}$'),             -- never the code itself
  purpose      text NOT NULL DEFAULT 'login' CHECK (purpose IN ('login')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  attempts     int NOT NULL DEFAULT 0,
  max_attempts int NOT NULL DEFAULT 5 CHECK (max_attempts BETWEEN 1 AND 10),
  closed_at    timestamptz,
  close_reason text CHECK (close_reason IN ('verified', 'superseded', 'expired', 'too_many_attempts')),
  CHECK (expires_at > created_at),
  CHECK (attempts >= 0 AND attempts <= max_attempts),
  CHECK ((closed_at IS NULL) = (close_reason IS NULL))
);
-- At most one live code per user: issuing a new one closes the old one as 'superseded'.
CREATE UNIQUE INDEX otp_challenge_one_open ON otp_challenge (user_id) WHERE closed_at IS NULL;
CREATE INDEX otp_challenge_cleanup ON otp_challenge (created_at);

-- ── Sessions ────────────────────────────────────────────────────────────────

CREATE TABLE session (
  session_id         uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),             -- the user's customer is found through the user, not copied here
  refresh_token_hash text NOT NULL UNIQUE CHECK (refresh_token_hash ~ '^[0-9a-f]{64}$'),
  family_id          uuid NOT NULL,                                           -- every token in one rotation chain shares it
  replaced_by_session_id uuid REFERENCES session (session_id),
  created_at         timestamptz NOT NULL DEFAULT now(),
  expires_at         timestamptz NOT NULL,
  revoked_at         timestamptz,
  revoke_reason      text CHECK (revoke_reason IN ('logout', 'rotated', 'reuse_detected', 'admin', 'user_disabled')),
  CHECK (expires_at > created_at),
  CHECK ((revoked_at IS NULL) = (revoke_reason IS NULL)),
  CHECK (replaced_by_session_id IS NULL OR revoke_reason = 'rotated')
);
CREATE INDEX session_user_live ON session (user_id) WHERE revoked_at IS NULL;
CREATE INDEX session_family     ON session (family_id);

-- ── Sign-in history and product activity (large, append-only, monthly partitions)
-- These are event facts: they record who and where AT THAT TIME, so they keep their
-- own customer_id rather than looking it up. A fact about the past must not change
-- if the present changes.

CREATE TABLE login_event (
  login_event_id    uuid NOT NULL,
  user_id           uuid REFERENCES app_user (user_id),                       -- null when the email matched nobody
  customer_id       uuid,
  outcome_code      text NOT NULL REFERENCES login_outcome (outcome_code),
  reason            text,
  occurred_at       timestamptz NOT NULL,
  ip_hash           text,                                                     -- never the raw address
  user_agent_family text,
  PRIMARY KEY (login_event_id, occurred_at)
) PARTITION BY RANGE (occurred_at);
CREATE TABLE login_event_default PARTITION OF login_event DEFAULT;
CREATE INDEX login_event_customer_time ON login_event (customer_id, occurred_at);
CREATE INDEX login_event_user_time     ON login_event (user_id, occurred_at);
CREATE TRIGGER login_event_append_only BEFORE UPDATE OR DELETE ON login_event FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- A successful sign-in keeps the user's first and last login up to date.
CREATE FUNCTION login_event_update_user() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.outcome_code = 'SUCCESS' AND NEW.user_id IS NOT NULL THEN
    UPDATE app_user
       SET first_login_at = COALESCE(first_login_at, NEW.occurred_at),
           last_login_at  = GREATEST(COALESCE(last_login_at, NEW.occurred_at), NEW.occurred_at)
     WHERE user_id = NEW.user_id;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER login_event_update_user AFTER INSERT ON login_event FOR EACH ROW EXECUTE FUNCTION login_event_update_user();

CREATE TABLE activity_event (
  activity_event_id uuid NOT NULL,
  customer_id       uuid NOT NULL,
  user_id           uuid NOT NULL REFERENCES app_user (user_id),
  event_type_code   text NOT NULL REFERENCES activity_event_type (event_type_code),
  feature_code      text,                                                     -- a licence-database feature code; no cross-database FK
  resource_type     text,
  resource_id       text,
  occurred_at       timestamptz NOT NULL,
  metadata          jsonb NOT NULL DEFAULT '{}' CHECK (pg_column_size(metadata) <= 4096),   -- small, and never sensitive
  PRIMARY KEY (activity_event_id, occurred_at)
) PARTITION BY RANGE (occurred_at);
CREATE TABLE activity_event_default PARTITION OF activity_event DEFAULT;
CREATE INDEX activity_event_customer_time ON activity_event (customer_id, occurred_at);
CREATE INDEX activity_event_user_time     ON activity_event (user_id, occurred_at);
CREATE INDEX activity_event_feature_time  ON activity_event (feature_code, occurred_at) WHERE feature_code IS NOT NULL;
CREATE TRIGGER activity_event_append_only BEFORE UPDATE OR DELETE ON activity_event FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ── A reporting-friendly read view ──────────────────────────────────────────
-- One row per live user with labels and their current roles.

CREATE VIEW v_user AS
SELECT
  u.user_id, u.customer_id, t.label AS user_type, u.email, u.display_name,
  s.label AS status, u.status_changed_at, u.first_login_at, u.last_login_at, u.created_at,
  (SELECT string_agg(ur.role_code, ', ' ORDER BY ur.role_code)
     FROM user_role ur WHERE ur.user_id = u.user_id AND ur.revoked_at IS NULL) AS roles
FROM app_user u
JOIN user_type t   ON t.user_type_code = u.user_type_code
JOIN user_status s ON s.status_code = u.status_code
WHERE u.deleted_at IS NULL;

COMMIT;
