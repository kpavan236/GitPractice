-- Fixed reference data the application relies on. Safe to run more than once.
INSERT INTO user_type (user_type_code, label) VALUES ('customer', 'Customer user'), ('staff', 'Staff user') ON CONFLICT DO NOTHING;

INSERT INTO user_status (status_code, label, sort_order) VALUES
  ('INVITED', 'Invited', 1), ('ACTIVE', 'Active', 2), ('LOCKED', 'Locked', 3), ('DISABLED', 'Disabled', 4)
ON CONFLICT DO NOTHING;

INSERT INTO login_outcome (outcome_code, label) VALUES
  ('OTP_SENT', 'Code sent'), ('SUCCESS', 'Signed in'), ('FAILED', 'Wrong or expired code'), ('LOCKED', 'Blocked: account locked')
ON CONFLICT DO NOTHING;

INSERT INTO activity_event_type (event_type_code, label, description) VALUES
  ('LOGIN', 'Signed in', NULL), ('LOGOUT', 'Signed out', NULL),
  ('FEATURE_USED', 'Used a feature', 'feature_code says which'),
  ('REPORT_VIEWED', 'Viewed a report', NULL), ('REPORT_EXPORTED', 'Exported a report', NULL),
  ('ALERT_VIEWED', 'Viewed an alert', NULL), ('SETTINGS_CHANGED', 'Changed settings', NULL),
  ('USER_INVITED', 'Invited a user', NULL), ('LICENSE_VIEWED', 'Viewed the licence', NULL)
ON CONFLICT DO NOTHING;

INSERT INTO role (role_code, label, user_type_code) VALUES
  ('CUSTOMER_USER',  'Customer user',  'customer'),
  ('CUSTOMER_ADMIN', 'Customer admin', 'customer'),
  ('SUPPORT',        'Support',        'staff'),
  ('PLATFORM_ADMIN', 'Platform admin', 'staff')
ON CONFLICT DO NOTHING;

INSERT INTO permission (permission_code, description) VALUES
  ('CUSTOMER_READ',    'View customer details'),
  ('CUSTOMER_UPDATE',  'Change customer details'),
  ('LICENSE_READ',     'View licences and entitlements'),
  ('LICENSE_UPDATE',   'Change licences and entitlements'),
  ('LICENSE_ACTIVATE', 'Activate or renew a licence'),
  ('LICENSE_SUSPEND',  'Suspend or cancel a licence'),
  ('INVOICE_READ',     'View invoices'),
  ('REPORT_READ',      'View reports'),
  ('USER_READ',        'View users'),
  ('USER_MANAGE',      'Invite, change and disable users'),
  ('AUDIT_READ',       'View the audit log')
ON CONFLICT DO NOTHING;

-- Which role gets which permission is DATA, so it can change without a deploy.
-- Support here cannot suspend a licence or manage users; the owner has not yet
-- decided whether support should have full access (open decision).
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('CUSTOMER_USER',  'LICENSE_READ'), ('CUSTOMER_USER',  'REPORT_READ'),
  ('CUSTOMER_ADMIN', 'LICENSE_READ'), ('CUSTOMER_ADMIN', 'REPORT_READ'), ('CUSTOMER_ADMIN', 'USER_READ'),
  ('CUSTOMER_ADMIN', 'USER_MANAGE'),  ('CUSTOMER_ADMIN', 'INVOICE_READ'),
  ('SUPPORT', 'CUSTOMER_READ'), ('SUPPORT', 'CUSTOMER_UPDATE'), ('SUPPORT', 'LICENSE_READ'), ('SUPPORT', 'LICENSE_UPDATE'),
  ('SUPPORT', 'LICENSE_ACTIVATE'), ('SUPPORT', 'INVOICE_READ'), ('SUPPORT', 'REPORT_READ'), ('SUPPORT', 'USER_READ'), ('SUPPORT', 'AUDIT_READ')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) SELECT 'PLATFORM_ADMIN', permission_code FROM permission
ON CONFLICT DO NOTHING;
