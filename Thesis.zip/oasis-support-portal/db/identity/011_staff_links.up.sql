-- Identity database, migration 011: activation and password-reset LINKS for staff.
--
-- A new team member is "Pending activation" (status INVITED) until they open the emailed activation link and choose a password; an admin can also email a password-reset link to
-- anyone active. A link carries a long random secret that is stored here ONLY as a keyed hash, so a copy of the database cannot be used to open one. Each link:
--   * has one purpose ('activate' or 'reset') and works only for that purpose, and only while the account is in the matching state (INVITED / ACTIVE);
--   * works once (used_at), until it expires (expires_at), and is replaced if a newer one is sent (revoked_at): at most one open link per person per purpose.
-- This replaces the emailed 6-digit codes of migration 010 for staff; the otp_challenge table is no longer used by the portal.

BEGIN;

CREATE TABLE staff_link (
  link_id            uuid PRIMARY KEY,
  user_id            uuid NOT NULL REFERENCES app_user (user_id),
  purpose            text NOT NULL CHECK (purpose IN ('activate', 'reset')),
  token_hash         text NOT NULL UNIQUE CHECK (token_hash ~ '^[0-9a-f]{64}$'),
  expires_at         timestamptz NOT NULL,
  used_at            timestamptz,
  revoked_at         timestamptz,
  created_by_user_id uuid,                                  -- the admin who sent it; null when the person asked for it themselves
  created_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX staff_link_one_open ON staff_link (user_id, purpose) WHERE used_at IS NULL AND revoked_at IS NULL;
CREATE INDEX staff_link_recent ON staff_link (user_id, created_at);

INSERT INTO login_outcome (outcome_code, label) VALUES ('LINK_SENT', 'Activation or reset link sent') ON CONFLICT DO NOTHING;

COMMIT;
