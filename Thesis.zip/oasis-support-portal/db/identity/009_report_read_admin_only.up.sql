-- Identity database, migration 009: the Reports screen is for admins.
--
-- REPORT_READ ("View reports") was given to SUPPORT by the identity design. The portal's Reports screen shows totals across all customers and every team member's workload, so it is
-- admin only. Who may read it is data: to let users see it, INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'REPORT_READ');

BEGIN;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'REPORT_READ') ON CONFLICT DO NOTHING;
DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'REPORT_READ';
COMMIT;
