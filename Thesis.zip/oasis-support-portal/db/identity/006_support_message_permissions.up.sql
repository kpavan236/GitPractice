-- Identity database, migration 006: permissions for the messages people send from the app (feedback and "contact support").
--
-- They hold personal data: an email address, a name and FREE TEXT a person wrote. Reading and answering them are separate permissions, so who may do what stays data.
-- Both staff roles get them by default (this is the support team's daily work). To take one away: DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = '...';

BEGIN;
INSERT INTO permission (permission_code, description) VALUES
  ('SUPPORT_REQUEST_READ',   'Read support requests (name, address and what the person wrote)'),
  ('SUPPORT_REQUEST_UPDATE', 'Answer a support request: assign it, move its status, add notes'),
  ('FEEDBACK_READ',          'Read feedback sent from the app')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('SUPPORT', 'SUPPORT_REQUEST_READ'), ('SUPPORT', 'SUPPORT_REQUEST_UPDATE'), ('SUPPORT', 'FEEDBACK_READ'),
  ('PLATFORM_ADMIN', 'SUPPORT_REQUEST_READ'), ('PLATFORM_ADMIN', 'SUPPORT_REQUEST_UPDATE'), ('PLATFORM_ADMIN', 'FEEDBACK_READ')
ON CONFLICT DO NOTHING;
COMMIT;
