-- Identity database, migration 007: the portal's two roles, "user" and "admin".
--
-- The portal shows two roles to people: USER (the schema's SUPPORT role) and ADMIN (PLATFORM_ADMIN). The role codes stay as they are; the portal says "user" and "admin".
--
--   user   works the customer requests: reads them, calls the customer, writes notes, moves the status, creates the licence once it is agreed, attaches the customer's
--          email domain (the app cannot activate by email without it), extends or renews, and finds trials.
--   admin  all of that, plus: assign requests, add and manage team members, suspend / cancel / revoke a licence, block machines, and read the audit log.
--
-- Who may do what is data (role_permission), so any of this can be changed without a deploy.

BEGIN;

INSERT INTO permission (permission_code, description) VALUES ('REQUEST_ASSIGN', 'Assign customer requests to a team member') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'REQUEST_ASSIGN') ON CONFLICT DO NOTHING;

-- The customer can only activate by email once their domain is attached, and creating the licence is the user's job, so attaching the domain is too.
-- (Public mail domains are still refused, every attach needs a reason and is audited.)
INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'DOMAIN_ATTACH') ON CONFLICT DO NOTHING;

-- The audit log is for admins. (The identity design gave it to support; the portal does not.)
DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'AUDIT_READ';

COMMIT;
