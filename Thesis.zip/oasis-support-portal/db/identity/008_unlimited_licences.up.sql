-- Identity database, migration 008: the biggest licences need an admin.
--
-- A user creates licences once a customer has agreed them (migration 007). Two choices make a licence much larger than the usual: unlimited seats (an enterprise licence) and a very long term. Those need
-- the LICENSE_UNLIMITED permission, which only admins have by default. Everything else a user can do alone is bounded by the plans' own sizes.
--   admin only: kind = enterprise, seats = unlimited, a term over 730 days.
-- To let users do it: INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'LICENSE_UNLIMITED');

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('LICENSE_UNLIMITED', 'Create an enterprise licence, one with unlimited seats, or one longer than 730 days') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'LICENSE_UNLIMITED') ON CONFLICT DO NOTHING;
COMMIT;
