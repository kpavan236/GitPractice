-- Identity database, migration 004: attaching an email domain to a customer gets its own permission.
--
-- A domain decides who may activate a customer's licence by typing an address there, and support marks it verified on the spot. That is
-- a bigger grant than adding a note, so it is a separate permission and only PLATFORM_ADMIN has it by default. To let support attach
-- domains: INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'DOMAIN_ATTACH');   (who may do what is data)

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('DOMAIN_ATTACH', 'Attach an email domain to a customer (grants its people access to its licences)') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'DOMAIN_ATTACH') ON CONFLICT DO NOTHING;
COMMIT;
