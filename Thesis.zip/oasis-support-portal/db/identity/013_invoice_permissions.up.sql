-- Identity database, migration 013: invoicing permissions.
--
--   INVOICE_READ    (already exists; SUPPORT and PLATFORM_ADMIN hold it) see invoices, the follow-ups queue and the bell's follow-up count
--   INVOICE_WRITE   create and edit drafts, issue, mark sent, share links, record payments, log follow-ups (SUPPORT = "user", PLATFORM_ADMIN = "admin")
--   INVOICE_ADMIN   void an invoice or a payment, raise a credit note, change an invoice's owner, see the Billing reports and export (PLATFORM_ADMIN only)
--
-- A staff member's role in the billing service is "admin" when they hold INVOICE_ADMIN, otherwise "user". Who holds what is data: change role_permission, not code.
-- The billing service enforces the same split itself (its action_role table); the portal's check only decides what is shown and avoids a pointless call.

BEGIN;
INSERT INTO permission (permission_code, description) VALUES
  ('INVOICE_WRITE', 'Create and edit invoices, issue them, share them, record payments and log follow-ups'),
  ('INVOICE_ADMIN', 'Void invoices and payments, raise credit notes, change an invoice''s owner, and see the Billing reports')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('SUPPORT', 'INVOICE_WRITE'), ('PLATFORM_ADMIN', 'INVOICE_WRITE'), ('PLATFORM_ADMIN', 'INVOICE_ADMIN')
ON CONFLICT DO NOTHING;
COMMIT;
