-- Identity database, migration 012: tools for admins and staff.
--
--   * Permissions for the new admin actions (all admin only by default; who may do what is data, so it can be changed without a deploy):
--       LICENSE_MODIFY       change a licence's seats or plan, release one seat
--       CUSTOMER_MANAGE      edit a customer's details
--       CUSTOMER_USER_MANAGE disable, enable, remove or re-invite a customer's own users
--   * staff_notification / staff_notification_state: what the bell in the top bar shows (a request assigned to you; new requests since you last looked).
--   * customer_note: notes the team keeps on a customer. Append-only. Free text: personal data may be in it.
--   * customer_reply: a record of every reply sent to a customer from the portal. Free text: personal data may be in it.
--   * retention_guard: the audit trail, the sign-in history and the reply record stay append-only, EXCEPT that the retention job (src/retention.js) may delete rows past their
--     retention period. It says so by setting app.retention = 'on' inside its own transaction; nothing else in the portal does. Updates are never allowed.
-- The portal owns these tables; nothing here touches the customer, licence or support databases.

BEGIN;

INSERT INTO permission (permission_code, description) VALUES
  ('LICENSE_MODIFY', 'Change a licence''s seats or plan, or release one seat'),
  ('CUSTOMER_MANAGE', 'Edit a customer''s details'),
  ('CUSTOMER_USER_MANAGE', 'Disable, enable, remove or re-invite a customer''s own users')
ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES
  ('PLATFORM_ADMIN', 'LICENSE_MODIFY'), ('PLATFORM_ADMIN', 'CUSTOMER_MANAGE'), ('PLATFORM_ADMIN', 'CUSTOMER_USER_MANAGE')
ON CONFLICT DO NOTHING;

CREATE TABLE staff_notification (
  notification_id uuid PRIMARY KEY,
  user_id         uuid NOT NULL REFERENCES app_user (user_id),
  kind            text NOT NULL CHECK (kind IN ('assigned')),
  subject_kind    text NOT NULL CHECK (subject_kind IN ('licence_request', 'help_request')),
  reference       text NOT NULL CHECK (char_length(reference) BETWEEN 1 AND 100),
  title           text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
  created_at      timestamptz NOT NULL DEFAULT now(),
  read_at         timestamptz
);
CREATE INDEX staff_notification_user ON staff_notification (user_id, created_at DESC);
CREATE INDEX staff_notification_unread ON staff_notification (user_id) WHERE read_at IS NULL;

CREATE TABLE staff_notification_state (
  user_id uuid PRIMARY KEY REFERENCES app_user (user_id),
  seen_at timestamptz NOT NULL DEFAULT now()                    -- requests that arrived after this are "new" to this person
);

CREATE TABLE customer_note (
  note_id            uuid PRIMARY KEY,
  customer_id        uuid NOT NULL,                              -- customer database; no cross-database FK
  body               text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 4000),     -- free text
  created_by_user_id uuid NOT NULL REFERENCES app_user (user_id),
  created_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_note_customer ON customer_note (customer_id, created_at);
CREATE TRIGGER customer_note_append_only BEFORE UPDATE OR DELETE ON customer_note FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE customer_reply (
  reply_id         uuid PRIMARY KEY,
  kind             text NOT NULL CHECK (kind IN ('licence_request', 'help_request')),
  reference        text NOT NULL CHECK (char_length(reference) BETWEEN 1 AND 100),
  sent_by_user_id  uuid NOT NULL REFERENCES app_user (user_id),
  subject          text NOT NULL CHECK (char_length(btrim(subject)) BETWEEN 1 AND 200),
  body             text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 4000),     -- free text
  delivery         text NOT NULL CHECK (delivery IN ('sent', 'failed', 'not_connected')),  -- not_connected: no email provider yet, so it was recorded but not delivered
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_reply_request ON customer_reply (kind, reference, created_at);

CREATE FUNCTION retention_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('app.retention', true) = 'on' THEN RETURN OLD; END IF;
  RAISE EXCEPTION '% rows are append-only: they are only ever deleted by the retention job', TG_TABLE_NAME USING ERRCODE = 'restrict_violation';
END $$;

DROP TRIGGER admin_audit_append_only ON admin_audit;
CREATE TRIGGER admin_audit_append_only BEFORE UPDATE OR DELETE ON admin_audit FOR EACH ROW EXECUTE FUNCTION retention_guard();
DROP TRIGGER login_event_append_only ON login_event;
CREATE TRIGGER login_event_append_only BEFORE UPDATE OR DELETE ON login_event FOR EACH ROW EXECUTE FUNCTION retention_guard();
DROP TRIGGER activity_event_append_only ON activity_event;
CREATE TRIGGER activity_event_append_only BEFORE UPDATE OR DELETE ON activity_event FOR EACH ROW EXECUTE FUNCTION retention_guard();
CREATE TRIGGER customer_reply_append_only BEFORE UPDATE OR DELETE ON customer_reply FOR EACH ROW EXECUTE FUNCTION retention_guard();

COMMIT;
