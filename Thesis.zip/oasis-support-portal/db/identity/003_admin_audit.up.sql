-- Identity database, migration 003: what staff did through the support API.
--
-- Every change (and every read of a customer's personal data) is written here BEFORE it is made ('started') and again when it ends
-- ('done' or 'failed'), because the change itself lives in another database and cannot share this transaction. A 'started' row with no
-- matching 'done' or 'failed' means the service stopped in the middle: look at it. Append-only. `detail` holds references and codes
-- (a plan, a status, a licence id), never a licence key, a code, a token or free text a customer wrote.

BEGIN;

CREATE TABLE admin_audit (
  audit_id      uuid PRIMARY KEY,
  occurred_at   timestamptz NOT NULL DEFAULT clock_timestamp(),
  actor_user_id uuid NOT NULL REFERENCES app_user (user_id),
  action        text NOT NULL CHECK (action ~ '^[a-z_]+\.[a-z_]+$'),           -- purchase_request.update, licence.create, ...
  subject_ref   text CHECK (subject_ref IS NULL OR char_length(subject_ref) <= 100),
  reason        text CHECK (reason IS NULL OR char_length(reason) BETWEEN 1 AND 500),
  outcome       text NOT NULL CHECK (outcome IN ('started', 'done', 'failed', 'read')),
  started_audit_id uuid REFERENCES admin_audit (audit_id),                     -- on 'done' and 'failed': which 'started' row this ends
  detail        jsonb NOT NULL DEFAULT '{}' CHECK (pg_column_size(detail) <= 4096),
  request_id    text CHECK (request_id IS NULL OR char_length(request_id) <= 64),
  CHECK ((outcome IN ('done', 'failed')) = (started_audit_id IS NOT NULL))
);
CREATE INDEX admin_audit_actor   ON admin_audit (actor_user_id, occurred_at);
CREATE INDEX admin_audit_subject ON admin_audit (subject_ref, occurred_at) WHERE subject_ref IS NOT NULL;
CREATE UNIQUE INDEX admin_audit_one_end ON admin_audit (started_audit_id) WHERE started_audit_id IS NOT NULL;   -- a change ends once
CREATE TRIGGER admin_audit_append_only BEFORE UPDATE OR DELETE ON admin_audit FOR EACH ROW EXECUTE FUNCTION forbid_change();

COMMIT;
