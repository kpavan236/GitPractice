-- Identity database, migration 005: blocking machines gets its own permission.
--
-- A block stops a machine from using OASIS at all (trials, activation, every call), so it is a separate permission, and only PLATFORM_ADMIN
-- has it by default (the plan: support proposes, a platform admin applies). To let support do it:
--   INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'BLOCK_MANAGE');

BEGIN;
INSERT INTO permission (permission_code, description) VALUES ('BLOCK_MANAGE', 'Block and unblock machines (stops them using OASIS, trials included)') ON CONFLICT DO NOTHING;
INSERT INTO role_permission (role_code, permission_code) VALUES ('PLATFORM_ADMIN', 'BLOCK_MANAGE') ON CONFLICT DO NOTHING;
COMMIT;
