# Testing: checking customer details

Manual steps and SQL for looking up a customer in the support portal. Use **synthetic data only** (the demo, or a local test database).
Customer contact names and emails are PII: never paste real ones into tickets, chats or prompts.

## 1. Set up

```bash
docker run -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16   # local Postgres the tests use
npm install
npm run demo        # portal on throwaway databases with synthetic data; Ctrl+C deletes everything
```

Open the address it prints (http://127.0.0.1:4030/). Sign in as:

| Who | Email | Role |
|---|---|---|
| Ada | `ada@staff.example.test` | admin |
| Sam | `sam@staff.example.test` | user |
| Lee | `lee@staff.example.test` | user |

The password is **Demo-password-2026** for all three (demo only; see "Demo accounts" in the README). Activation and reset links are printed in the terminal running the demo.

## 2. Manual steps (browser)

| # | Do this | Expect |
|---|---|---|
| 1 | Sign in as Sam (user) | Dashboard shows; no Team, Audit log or Blocked machines in the menu |
| 2 | Open **Customers** | A list of demo customers |
| 3 | Search by a customer name (part of it) | List narrows to matches |
| 4 | Search by an email domain (for example the domain of a demo customer) | The customer who owns that domain is listed |
| 5 | Search for text that matches nothing | An empty-state message, no error |
| 6 | Open one customer | Domains, licences and linked requests are shown |
| 7 | On the licence row, check the key | Only the **last 4 characters** are shown, never the full key |
| 8 | Open a linked licence request | Organisation, size, contact, email, status, history and notes |
| 9 | Open **Licence requests**; filter by status (New / Contacted) | Open requests first, oldest first |
| 10 | Sign out, sign in as Ada (admin) | Team, Audit log and Blocked machines now appear |
| 11 | Open **Audit log** | Your reads of the customer and request from steps 6 and 8 are listed (`read` outcome) |
| 12 | Keyboard only: Tab through the Customers screen | Every control reachable, focus moves to the new page after opening a customer |
| 13 | Sign out, then open a customer URL directly | Redirected to sign in; no data shown |

Negative checks:

- Sign in with an address that is not a staff member, or with a wrong password: the answer is the same (`bad_credentials`), nothing more is revealed.
- Five wrong passwords in a row for Ada pause her account for 15 minutes; the right password is refused until then (a reset link, from "Forgot or set your password", sets a new one at once).
- As Ada, add a team member: they show as *Pending activation* and a link is printed in the terminal. Open it, enter two different passwords (refused), then the same twice: the account becomes *Active* and they can sign in. The same link a second time is refused.
- Deactivate a member: they cannot sign in and any link sent before stops working. Activate them again: they can sign in (or, if they never chose a password, get a fresh activation link).
- "Change password" in the top bar needs the current password; afterwards other sessions are signed out.
- A user (Sam) calling an admin-only route (for example `GET /v1/admin/audit`) gets a refusal.

## 3. API checks (scripts)

Get a bearer token (no `cookie` flag), then call the routes:

```bash
BASE=http://127.0.0.1:4030/v1/admin
TOKEN=$(curl -s -X POST $BASE/auth/login -H 'content-type: application/json' \
  -d '{"email":"sam@staff.example.test","password":"Demo-password-2026"}' | jq -r .token)

curl -s -H "Authorization: Bearer $TOKEN" "$BASE/customers?q=<name-or-domain>"
curl -s -H "Authorization: Bearer $TOKEN" "$BASE/customers/<customer_id>"
curl -s -H "Authorization: Bearer $TOKEN" "$BASE/licenses?customerId=<customer_id>"
curl -s -H "Authorization: Bearer $TOKEN" "$BASE/purchase-requests/PR-000001"
```

Expect: 200 with JSON; the licence list never contains a key, only `key_hint`; a request with no token gets 401.

## 4. Queries (direct database checks)

Use these to confirm what the portal shows. Run them with `psql` against the **local/demo** databases. Do not run against production without
approval, and never `UPDATE` or `DELETE` here: the portal writes the audit trail that way.

The data is split across databases. Connection strings are in `.env` (`CUSTOMER_DATABASE_URL`, `LICENSE_DATABASE_URL`, `IDENTITY_DATABASE_URL`).
There are no cross-database foreign keys, so join by `customer_id` yourself.

### 4.1 Customer database (`customer_db`)

Find a customer by name (the same lookup as the Customers screen):

```sql
SELECT customer_id, name, status, size_band, country, primary_contact_email, created_at
FROM v_customer
WHERE name ILIKE '%' || :'q' || '%'
ORDER BY name
LIMIT 25;
```

Find a customer by email domain:

```sql
SELECT c.customer_id, c.name, d.domain, d.verified_at
FROM customer_domain d
JOIN customer c ON c.customer_id = d.customer_id
WHERE c.deleted_at IS NULL
  AND d.domain = lower(:'domain');
```

One customer in full: domains and contacts:

```sql
SELECT * FROM v_customer WHERE customer_id = :'customer_id';

SELECT domain, verified_at, created_at
FROM customer_domain WHERE customer_id = :'customer_id' ORDER BY domain;

SELECT ccr.contact_type_code, ct.full_name, ct.email, ct.is_active          -- PII
FROM customer_contact_role ccr
JOIN contact ct ON ct.contact_id = ccr.contact_id
WHERE ccr.customer_id = :'customer_id';
```

Status history of a customer (who moved it and when):

```sql
SELECT from_status_code, to_status_code, changed_at, changed_by_user_id, reason
FROM customer_status_history
WHERE customer_id = :'customer_id'
ORDER BY changed_at DESC;
```

Licence requests linked to a customer, and the open queue:

```sql
SELECT reference, organization_name, employee_count, size_band, contact_name, email,
       status, status_changed_at, assigned_to_user_id, hours_open_or_to_close
FROM v_purchase_request
WHERE customer_id = :'customer_id'
ORDER BY created_at DESC;

SELECT reference, organization_name, status, hours_open_or_to_close, assigned_to_user_id
FROM v_purchase_request
WHERE NOT is_closed
ORDER BY created_at;                                  -- oldest first, as the support list
```

Look up one request by reference, and every status it has been through:

```sql
SELECT * FROM v_purchase_request WHERE reference = :'reference';

SELECT h.* FROM purchase_request_status_history h
JOIN purchase_request p USING (purchase_request_id)
WHERE p.reference = :'reference'
ORDER BY 1;   -- inspect the columns first: \d purchase_request_status_history
```

Sanity checks (each should return **0 rows**):

```sql
-- a request tied to a customer must be AGREED
SELECT reference FROM purchase_request WHERE customer_id IS NOT NULL AND status_code <> 'AGREED';

-- a domain must be lowercase and belong to exactly one customer (UNIQUE enforces it)
SELECT domain FROM customer_domain WHERE domain <> lower(domain);

-- a customer must not be soft-deleted yet still show a live licence (compare with the licence database by id)
SELECT customer_id, name FROM customer WHERE deleted_at IS NOT NULL;
```

### 4.2 Licence database (`license_db`)

Licences for a customer (the key is stored only as a hash; `key_hint` is the last 4 characters):

```sql
SELECT license_id, plan, kind, status, starts_at, expires_at, days_to_expiry,
       seat_limit, seats_in_use, grace_days, key_hint
FROM v_license
WHERE customer_id = :'customer_id'
ORDER BY created_at DESC;
```

What a licence includes right now:

```sql
SELECT * FROM entitlement_current WHERE license_id = :'license_id';
```

Terms (renewals) of a licence:

```sql
SELECT * FROM license_term WHERE license_id = :'license_id' ORDER BY starts_at;
```

Status history of a licence:

```sql
SELECT * FROM license_status_history WHERE license_id = :'license_id' ORDER BY 1;
-- inspect the columns first: \d license_status_history
```

Trials for a customer:

```sql
SELECT trial_id, status, started_at, effective_expiry, has_ended, source,
       platform, app_version, open_review_flags, converted_license_id
FROM v_trial
WHERE customer_id = :'customer_id'
ORDER BY started_at DESC;
```

Licences about to lapse (30 days), as on the dashboard:

```sql
SELECT license_id, customer_id, plan, status, expires_at, days_to_expiry
FROM v_license
WHERE status = 'Active' AND days_to_expiry BETWEEN 0 AND 30
ORDER BY expires_at;
```

Sanity checks (each should return **0 rows**):

```sql
-- a licence with no term has no dates
SELECT license_id FROM v_license WHERE starts_at IS NULL OR expires_at IS NULL;

-- seats in use above the limit
SELECT license_id, seat_limit, seats_in_use FROM v_license WHERE seat_limit IS NOT NULL AND seats_in_use > seat_limit;
```

### 4.3 Identity database (`identity_db`): who looked at what

Every read of a customer's personal data, and every change, is audited. After the manual steps above:

```sql
SELECT a.occurred_at, u.email AS staff_email, a.action, a.subject_ref, a.outcome, a.reason
FROM admin_audit a
JOIN app_user u ON u.user_id = a.actor_user_id
ORDER BY a.occurred_at DESC
LIMIT 50;
```

A change that started but never finished (the service stopped midway; **should return 0 rows** after a clean run):

```sql
SELECT s.audit_id, s.occurred_at, s.action, s.subject_ref
FROM admin_audit s
WHERE s.outcome = 'started'
  AND NOT EXISTS (SELECT 1 FROM admin_audit e WHERE e.started_audit_id = s.audit_id);
```

What a role may do (data, not code):

```sql
SELECT role_code, permission_code
FROM role_permission
WHERE permission_code LIKE 'CUSTOMER_%'
ORDER BY 1, 2;
```

## 5. Automated tests

```bash
npm test                                   # all suites (needs the local Postgres above)
node --test test/purchase-requests.test.js # licence requests
node --test test/overview.test.js          # dashboard, customers
node --test test/licences.test.js          # licences
node --test test/static.test.js            # UI safety: no innerHTML, eval or browser storage
```

## 6. Clean up

Ctrl+C stops the demo and deletes its throwaway databases. Nothing to remove by hand.
