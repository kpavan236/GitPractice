'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { unique } = require('./fixtures');

/**
 * Ready-made situations for the licence tests: a licence made through the real create route, a machine that has activated it on the real
 * licence service, and the admin call helper. `boss` is a signed-in PLATFORM_ADMIN.
 */
function scenarios(svc, ls, boss) {
  const REASON = 'Agreed with the customer';
  const act = (path, body, who = boss) => svc.post(`/v1/admin/${path}`, { reason: REASON, ...body }, who.as);
  const machineId = () => crypto.randomBytes(16).toString('hex');

  /** A customer with a new licence (via POST /licenses). Returns { licenseId, customerId, licenceKey, name }. */
  async function licence({ plan = 'team', seats = 5, days = 365, name = `Life ${unique()} Ltd` } = {}) {
    const r = await act('licenses', { customer: { name }, plan, seats, termDays: days });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    return { ...r.body, name };
  }

  /** Another machine takes a seat on a licence, on the real licence service. Returns { machine, token }. */
  async function seat(l) {
    const machine = machineId();
    const a = await ls.post('/v1/activate', { machineId: machine, licenseKey: l.licenceKey, appVersion: '2.0.1' });
    assert.equal(a.status, 200, JSON.stringify(a.body));
    return { machine, token: a.body.token };
  }

  /** A licence with one machine already seated on it. */
  async function activeLicence(opts) {
    const l = await licence(opts);
    return { ...l, ...await seat(l) };
  }

  return { REASON, act, machineId, licence, seat, activeLicence, hintOf: l => l.licenceKey.slice(-4) };
}

module.exports = { scenarios };
