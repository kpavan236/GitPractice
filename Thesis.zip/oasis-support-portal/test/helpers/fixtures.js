'use strict';
const crypto = require('node:crypto');
const { uuidv7 } = require('../../src/uuid');
const { createHasher } = require('../../src/secrets');
const { hashPassword } = require('../../src/password');

const TEST_PASSWORD = 'synthetic test password 2026';

let n = 0;
const unique = () => `${Date.now().toString(36)}${(++n).toString(36)}`;
const PLATFORM_CUSTOMER = uuidv7();

/** A staff member (synthetic: example.test), straight into the identity database. Returns { userId, email }. */
async function createStaff(svc, { role = 'SUPPORT', name = 'Sam Support', status = 'ACTIVE' } = {}) {
  const userId = uuidv7(), email = `staff-${unique()}@staff.example.test`;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code) VALUES ($1, $2, 'staff', $3, $4, $5)`, [userId, PLATFORM_CUSTOMER, email, name, status]);
  if (role) await svc.identityDb.query('INSERT INTO user_role (user_role_id, user_id, role_code) VALUES ($1, $2, $3)', [uuidv7(), userId, role]);
  return { userId, email };
}

/** Gives a staff member a password straight in the database (as if they had already set one), unless they have one. Cheap hashing: this is a test. */
async function givePassword(svc, userId, password = TEST_PASSWORD) {
  const passwordHash = await hashPassword(createHasher(svc.hashPepper), password, svc.passwordCost);
  await svc.identityDb.query(`INSERT INTO staff_credential (user_id, password_hash) VALUES ($1, $2) ON CONFLICT (user_id) DO NOTHING`, [userId, passwordHash]);
}

/** The whole sign-in as a person would do it: email address and password. Returns the bearer token. */
async function signIn(svc, email, password = TEST_PASSWORD) {
  const { rows: [u] } = await svc.identityDb.query('SELECT user_id FROM app_user WHERE email = $1', [email]);
  if (u) await givePassword(svc, u.user_id, password);
  const v = await svc.post('/v1/admin/auth/login', { email, password });
  if (v.status !== 200) throw new Error(`sign-in failed: ${v.status} ${JSON.stringify(v.body)}`);
  return v.body.token;
}

/** The secret in the last link emailed to an address, and which kind it was ('activation' or 'password_reset'). */
const lastLink = (svc, email, kind) => {
  const m = svc.notifier.sent.findLast(x => x.to === email && (!kind || x.kind === kind));
  return m ? { token: m.link.split('/').pop(), link: m.link, kind: m.kind, expiresInHours: m.expiresInHours } : null;
};

/** Opens the emailed activation link for an address and chooses a password, as the person would. */
async function activateByLink(svc, email, password = TEST_PASSWORD) {
  const l = lastLink(svc, email, 'activation');
  if (!l) throw new Error(`no activation link was sent to ${email}`);
  const r = await svc.post('/v1/admin/auth/link/complete', { token: l.token, newPassword: password, confirmPassword: password });
  if (r.status !== 200) throw new Error(`activation failed: ${r.status} ${JSON.stringify(r.body)}`);
}

/** A staff member who is already signed in: { userId, email, token, as } where `as` gives the Authorization header. */
async function staffSignedIn(svc, opts) {
  const s = await createStaff(svc, opts);
  const token = await signIn(svc, s.email);
  return { ...s, token, as: { Authorization: `Bearer ${token}` } };
}

/** A purchase request as the app would have made it (straight into the customer database). Returns its reference. */
async function createRequest(svc, { organization = 'Acme Example Ltd', employees = 120, email = `pat-${unique()}@acme.example.test`, status = 'NEW' } = {}) {
  const { rows: [r] } = await svc.customerDb.query(
    `INSERT INTO purchase_request (purchase_request_id, organization_name, employee_count, contact_name, email) VALUES ($1, $2, $3, 'Pat Example', $4) RETURNING reference`,
    [uuidv7(), organization, employees, email]);
  const path = { NEW: [], CONTACTED: ['CONTACTED'], AGREED: ['CONTACTED', 'AGREED'], DECLINED: ['DECLINED'], DUPLICATE: ['DUPLICATE'] }[status];
  for (const to of path) {
    await svc.customerDb.query(`WITH r AS (SELECT set_config('app.reason', 'test setup', true)) UPDATE purchase_request SET status_code = $2 FROM r WHERE reference = $1`, [r.reference, to]);
  }
  return r.reference;
}

const rows = (db, sql, params) => db.query(sql, params).then(r => r.rows);

module.exports = { PLATFORM_CUSTOMER, TEST_PASSWORD, unique, createStaff, givePassword, lastLink, activateByLink, signIn, staffSignedIn, createRequest, rows, crypto };
