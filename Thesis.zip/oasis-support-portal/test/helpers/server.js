'use strict';
const crypto = require('node:crypto');
const { createApp } = require('../../src/app');
const { createTestDatabases } = require('./db');
const { createFakeNotifier } = require('../../src/notifier');
const { rateLimit } = require('../../src/rate-limit');
const { PLATFORM_CUSTOMER } = require('./fixtures');

const PEPPER = 'test-pepper-test-pepper-test-pepper-0123';
const LICENCE_PEPPER = 'licence-pepper-licence-pepper-licence-9';

/** A running admin API on a free port, on throwaway databases. `logs` collects every log line so tests can check what was (not) logged. */
async function startService(options = {}) {
  const dbs = options.dbs || await createTestDatabases();
  const logs = [];
  const notifier = createFakeNotifier();
  const app = createApp({
    identityDb: options.identityDb || dbs.identityDb, customerDb: options.customerDb || dbs.customerDb, licenseDb: options.licenseDb || dbs.licenseDb, supportDb: options.supportDb || dbs.supportDb,
    hashPepper: PEPPER, licenceHashPepper: LICENCE_PEPPER, platformCustomerId: PLATFORM_CUSTOMER, staffEmailDomains: options.staffEmailDomains || [], secureCookies: false, notifier, billing: options.billing ?? null, sessionHours: options.sessionHours || 8, passwordCost: { N: 2 ** 10 }, portalBaseUrl: 'http://portal.example.test',
    limiter: rateLimit({ max: 10_000 }), authLimiter: options.authLimiter || rateLimit({ max: 10_000 }), log: line => logs.push(line),
  });
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, route, body, headers = {}) => {
    const res = await fetch(`${base}${route}`, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    const text = await res.text();
    return { status: res.status, headers: res.headers, text, body: (() => { try { return JSON.parse(text); } catch (_) { return {}; } })() };
  };
  return {
    ...dbs, app, base, logs, billing: options.billing ?? null, notifier, hashPepper: PEPPER, licenceHashPepper: LICENCE_PEPPER, passwordCost: { N: 2 ** 10 }, call,
    post: (route, body, headers) => call('POST', route, body, headers),
    get: (route, headers) => call('GET', route, undefined, headers),
    patch: (route, body, headers) => call('PATCH', route, body, headers),
    async close() { await new Promise(r => server.close(r)); if (!options.dbs) await dbs.drop(); },
  };
}

module.exports = { startService, crypto };
