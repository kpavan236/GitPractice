'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { LICENCE_SERVICE_DIR } = require('./db');

const licenceService = name => require(path.join(LICENCE_SERVICE_DIR, 'src', name));

/**
 * The licence service itself (its own code, from its repository) running on the same databases as the admin service under test, as the
 * OASIS app would reach it. Anything support does here must change what the app is told THERE: this is how the tests prove it.
 */
async function startLicenceService(svc) {
  const { createApp } = licenceService('app');
  const { prepareSigner } = licenceService('signing-key');
  const { rateLimit } = licenceService('rate-limit');
  const { createFakeNotifier } = licenceService('notifier');
  const pem = crypto.generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' });
  const signer = await prepareSigner(svc.licenseDb, { signingKeyPem: pem, signingKid: `admin-test-${crypto.randomBytes(3).toString('hex')}` });
  const notifier = createFakeNotifier();
  const app = createApp({ customerDb: svc.customerDb, licenseDb: svc.licenseDb, signer, hashPepper: svc.licenceHashPepper, notifier, limiter: rateLimit({ max: 10_000 }), log: () => {} });
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = async (route, body) => { const r = await fetch(`${base}${route}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, body: await r.json() }; };
  const claims = token => JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString());
  return { post, notifier, claims, close: () => new Promise(r => server.close(r)) };
}

module.exports = { startLicenceService };
