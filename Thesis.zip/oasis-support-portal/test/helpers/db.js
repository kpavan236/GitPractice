'use strict';
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { Pool } = require('pg');
const { migrate } = require('../../src/migrate');

// Tests run against REAL PostgreSQL. Each call makes three throwaway databases on the server named by TEST_PG_ADMIN_URL (default: the local
// development container, docker run -p 5433:5432 postgres:16) and drops them afterwards.
//
// The support schema (feedback and support requests) is the support service's, read from ITS repository the same way (SUPPORT_SERVICE_DIR, default ../oasis-support-service).
// The identity schema is this repo's. The CUSTOMER and LICENCE schemas belong to the licence service: they are read straight from its
// repository (LICENCE_SERVICE_DIR, default ../oasis-licence-service) so there is one copy of them and they cannot drift.
const ADMIN_URL = process.env.TEST_PG_ADMIN_URL || 'postgres://postgres:local-dev-only@localhost:5433/postgres';
const LICENCE_SERVICE_DIR = process.env.LICENCE_SERVICE_DIR || path.join(__dirname, '..', '..', '..', 'oasis-licence-service');
const SUPPORT_SERVICE_DIR = process.env.SUPPORT_SERVICE_DIR || path.join(__dirname, '..', '..', '..', 'oasis-support-service');

const urlFor = name => { const u = new URL(ADMIN_URL); u.pathname = `/${name}`; return u.toString(); };

async function createTestDatabases() {
  for (const d of ['customer', 'license']) {
    if (!fs.existsSync(path.join(LICENCE_SERVICE_DIR, 'db', d))) throw new Error(`The tests need the licence service's schemas at ${LICENCE_SERVICE_DIR}/db/${d}. Set LICENCE_SERVICE_DIR.`);
  }
  if (!fs.existsSync(path.join(SUPPORT_SERVICE_DIR, 'db', 'support'))) throw new Error(`The tests need the support service's schema at ${SUPPORT_SERVICE_DIR}/db/support. Set SUPPORT_SERVICE_DIR.`);
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try { await admin.query('SELECT 1'); }
  catch (err) { await admin.end().catch(() => {}); throw new Error(`Cannot reach PostgreSQL for the tests (${err.message}). Start one, or set TEST_PG_ADMIN_URL.`); }
  const id = crypto.randomBytes(4).toString('hex');
  const names = { identity: `t_${id}_identity`, customer: `t_${id}_customer`, license: `t_${id}_license`, support: `t_${id}_support` };
  for (const n of Object.values(names)) await admin.query(`CREATE DATABASE ${n}`);
  await migrate(urlFor(names.identity), path.join(__dirname, '..', '..', 'db', 'identity'));
  await migrate(urlFor(names.customer), path.join(LICENCE_SERVICE_DIR, 'db', 'customer'));
  await migrate(urlFor(names.license), path.join(LICENCE_SERVICE_DIR, 'db', 'license'));
  await migrate(urlFor(names.support), path.join(SUPPORT_SERVICE_DIR, 'db', 'support'));
  const pool = name => { const p = new Pool({ connectionString: urlFor(name), max: 10 }); p.on('error', () => {}); return p; };
  const dbs = { identityDb: pool(names.identity), customerDb: pool(names.customer), licenseDb: pool(names.license), supportDb: pool(names.support) };
  return {
    ...dbs, identityUrl: urlFor(names.identity),
    async drop() {
      await Promise.all(Object.values(dbs).map(p => p.end()));
      for (const n of Object.values(names)) await admin.query(`DROP DATABASE IF EXISTS ${n} WITH (FORCE)`);
      await admin.end();
    },
  };
}

module.exports = { createTestDatabases, LICENCE_SERVICE_DIR, SUPPORT_SERVICE_DIR };
