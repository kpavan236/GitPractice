'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { SUPPORT_SERVICE_DIR } = require('./db');

const supportService = name => require(path.join(SUPPORT_SERVICE_DIR, 'src', name));

/**
 * The support service itself (its own code, from its repository) running on the same support database as the admin service under test. Messages are made
 * the way the OASIS app makes them, through its public routes, so what staff read here is exactly what the real service stores.
 */
async function startSupportService(svc) {
  const { createApp } = supportService('app');
  const { rateLimit } = supportService('rate-limit');
  const app = createApp({ db: svc.supportDb, hashPepper: 'support-pepper-support-pepper-support-1', supportMailbox: null, limiter: rateLimit({ max: 100_000 }), log: () => {} });
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = async (route, body) => {
    const r = await fetch(`${base}${route}`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': `k-${crypto.randomUUID()}` }, body: JSON.stringify(body) });
    return { status: r.status, body: await r.json() };
  };
  let n = 0;
  const unique = () => `p${Date.now().toString(36)}${++n}@acme.example.test`;
  /** A "contact support" message as a person would send it. Returns its reference. */
  const request = async (over = {}) => {
    const r = await post('/v1/support-request', { subject: 'Cannot connect to Jenkins', message: 'The Setup tab says the token is rejected.', contactName: 'Pat Example', email: unique(), appVersion: '2.0.1', ...over });
    if (r.status !== 200) throw new Error(`support-request failed: ${r.status} ${JSON.stringify(r.body)}`);
    return r.body.reference;
  };
  /** Feedback as a person would send it. Returns its reference. */
  const feedback = async (over = {}) => {
    const r = await post('/v1/feedback', { category: 'idea', message: 'Group the graph by team.', ...over });
    if (r.status !== 200) throw new Error(`feedback failed: ${r.status} ${JSON.stringify(r.body)}`);
    return r.body.reference;
  };
  return { request, feedback, unique, close: () => new Promise(r => server.close(r)) };
}

module.exports = { startSupportService };
