'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const { Pool } = require('pg');

// The billing service's own code, from its own repository (BILLING_SERVICE_DIR, default ../oasis-billing-service), on a throwaway database: there is one copy of its schema and
// it cannot drift. Same pattern as the licence service helper.
const BILLING_SERVICE_DIR = process.env.BILLING_SERVICE_DIR || path.join(__dirname, '..', '..', '..', 'oasis-billing-service');
const ADMIN_URL = process.env.TEST_PG_ADMIN_URL || 'postgres://postgres:local-dev-only@localhost:5433/postgres';
const urlFor = name => { const u = new URL(ADMIN_URL); u.pathname = `/${name}`; return u.toString(); };
const billing = name => require(path.join(BILLING_SERVICE_DIR, 'src', name));

const KEY = 'portal-test-key-portal-test-key-0123456789';
const PEPPER = 'portal-test-pepper-portal-test-pepper-01';

async function startBillingService({ currency = 'INR' } = {}) {
  const admin = new Pool({ connectionString: ADMIN_URL, max: 1 });
  try { await admin.query('SELECT 1'); }
  catch (err) { await admin.end().catch(() => {}); throw new Error(`Cannot reach PostgreSQL for the tests (${err.message}). Start one, or set TEST_PG_ADMIN_URL.`); }
  const name = `t_${crypto.randomBytes(4).toString('hex')}_billing`;
  await admin.query(`CREATE DATABASE ${name}`);
  await billing('migrate').migrate(urlFor(name), path.join(BILLING_SERVICE_DIR, 'db', 'billing'));
  const db = new Pool({ connectionString: urlFor(name), max: 10 });
  db.on('error', () => {});
  const logs = [];
  // The share-link URLs the service hands out must be fetchable in tests, so the app is built once the port is known.
  let handler = (_req, res) => res.status(503).end();
  const server = await new Promise(r => { const s = require('node:http').createServer((req, res) => handler(req, res)); s.listen(0, '127.0.0.1', () => r(s)); });
  const url = `http://127.0.0.1:${server.address().port}`;
  handler = billing('app').createApp({ db, serviceKey: KEY, hashPepper: PEPPER, currency, shareLinkDefaultDays: 14, publicBaseUrl: url,
    limiter: billing('rate-limit').rateLimit({ max: 100_000 }), publicLimiter: billing('rate-limit').rateLimit({ max: 100_000 }), log: l => logs.push(l) });
  return {
    db, logs, key: KEY, url,
    async close() { await new Promise(r => { server.closeAllConnections(); server.close(r); }); await db.end(); await admin.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`); await admin.end(); },
  };
}

module.exports = { startBillingService, BILLING_SERVICE_DIR, KEY };
