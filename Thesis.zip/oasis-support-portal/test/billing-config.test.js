'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');

const base = { IDENTITY_DATABASE_URL: 'a', CUSTOMER_DATABASE_URL: 'b', LICENSE_DATABASE_URL: 'c', SUPPORT_DATABASE_URL: 'd', HASH_PEPPER: 'p'.repeat(32), LICENCE_HASH_PEPPER: 'q'.repeat(32), PLATFORM_CUSTOMER_ID: '0190aaaa-0000-7000-8000-000000000001' };

test('billing is optional: with no settings the portal starts and billing is off', () => {
  const c = loadConfig(base);
  assert.deepEqual([c.billingServiceUrl, c.billingServiceKey, c.billingCaFile], ['', '', '']);
});

test('the billing address and key are set together; the key is at least 32 characters', () => {
  assert.throws(() => loadConfig({ ...base, BILLING_SERVICE_URL: 'http://127.0.0.1:4060' }), /BILLING_SERVICE_URL and BILLING_SERVICE_KEY must be set together/);
  assert.throws(() => loadConfig({ ...base, BILLING_SERVICE_KEY: 'k'.repeat(40) }), /set together/);
  assert.throws(() => loadConfig({ ...base, BILLING_SERVICE_URL: 'http://127.0.0.1:4060', BILLING_SERVICE_KEY: 'short' }), /BILLING_SERVICE_KEY must be at least 32/);
  const c = loadConfig({ ...base, BILLING_SERVICE_URL: 'http://127.0.0.1:4060/', BILLING_SERVICE_KEY: 'k'.repeat(40) });
  assert.equal(c.billingServiceUrl, 'http://127.0.0.1:4060');
});

test('the billing address is a plain web address; production needs https', () => {
  const ok = { BILLING_SERVICE_KEY: 'k'.repeat(40) };
  assert.throws(() => loadConfig({ ...base, ...ok, BILLING_SERVICE_URL: 'ftp://x.test' }), /BILLING_SERVICE_URL/);
  assert.throws(() => loadConfig({ ...base, ...ok, BILLING_SERVICE_URL: 'http://x.test/path?a=1' }), /BILLING_SERVICE_URL/);
  assert.throws(() => loadConfig({ ...base, ...ok, BILLING_SERVICE_URL: 'http://user:pw@x.test' }), /BILLING_SERVICE_URL/);
  assert.throws(() => loadConfig({ ...base, ...ok, NODE_ENV: 'production', TRUST_PROXY: '0', ALLOW_PLAIN_HTTP: '1', PORTAL_BASE_URL: 'https://p.example.test', STAFF_EMAIL_DOMAINS: 'example.test', BILLING_SERVICE_URL: 'http://x.test' }), /BILLING_SERVICE_URL must be https in production/);
});
