'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { startLicenceService } = require('./helpers/licence-service');
const { scenarios } = require('./helpers/scenarios');
const { staffSignedIn, createRequest, unique, rows } = require('./helpers/fixtures');

const DAY = 864e5;
let svc, sam, boss, ls, act, licence, activeLicence;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  ls = await startLicenceService(svc);
  ({ act, licence, activeLicence } = scenarios(svc, ls, boss));
});
test.after(async () => { await ls.close(); await svc.close(); });

const q = (sql, params) => rows(svc.licenseDb, sql, params);

/** Makes a licence's current term already over (terms are append-only, so this steps outside the rules, as a time machine would). */
async function ageTerm(licenseId, daysAgo) {
  await svc.licenseDb.query('ALTER TABLE license_term DISABLE TRIGGER license_term_append_only');
  await svc.licenseDb.query(`UPDATE license_term SET starts_at = now() - make_interval(days => $2 + 30), ends_at = now() - make_interval(days => $2) WHERE license_id = $1`, [licenseId, daysAgo]);
  await svc.licenseDb.query('ALTER TABLE license_term ENABLE TRIGGER license_term_append_only');
}
const terms = id => q('SELECT term_no, starts_at, ends_at, source_code, reference FROM license_term WHERE license_id = $1 ORDER BY term_no', [id]);

// ── Listing ─────────────────────────────────────────────────────────────────

test('the licence list shows customer, plan, status, dates and seats in use, with filters and limits; bad filters are refused', async () => {
  const a = await activeLicence({ name: 'Listed Ltd', seats: 3 });
  const b = await licence({ name: 'Pending Ltd' });
  const all = await svc.get('/v1/admin/licenses?limit=200', sam.as);
  assert.equal(all.status, 200);
  const row = all.body.licences.find(l => l.license_id === a.licenseId);
  assert.equal(row.customer_name, 'Listed Ltd');
  assert.deepEqual([row.plan_code, row.status_code, row.seat_limit, row.seats_in_use, row.key_hint], ['team', 'ACTIVE', 3, 1, a.licenceKey.slice(-4)]);
  assert.ok(row.expires_at > new Date(Date.now() + 360 * DAY).toISOString());
  assert.ok(!JSON.stringify(all.body).includes(a.licenceKey), 'never the key');
  assert.ok(!JSON.stringify(all.body).includes(a.machine), 'never a machine id');

  const byCustomer = await svc.get(`/v1/admin/licenses?customerId=${b.customerId}`, sam.as);
  assert.deepEqual(byCustomer.body.licences.map(l => l.license_id), [b.licenseId]);
  const pending = await svc.get('/v1/admin/licenses?status=pending_activation,suspended&limit=200', sam.as);
  assert.ok(pending.body.licences.some(l => l.license_id === b.licenseId) && pending.body.licences.every(l => ['PENDING_ACTIVATION', 'SUSPENDED'].includes(l.status_code)));
  assert.equal((await svc.get('/v1/admin/licenses?limit=1', sam.as)).body.licences.length, 1);
  for (const bad of ['?status=NOPE', '?status=', '?customerId=x', '?limit=0', '?limit=201', '?offset=-1', '?customerId[]=a', '?status=A&status=B']) {
    const r = await svc.get(`/v1/admin/licenses${bad}`, sam.as);
    assert.equal(r.status, 400, bad); assert.equal(r.body.reason, 'bad_filter');
  }
});

// ── Suspend and reinstate ───────────────────────────────────────────────────

test('suspending stops the app at once: the licence service refuses it, with a reason on record; reinstating restores it', async () => {
  const l = await activeLicence();
  const other = crypto.randomBytes(16).toString('hex');
  const s = await act(`licenses/${l.licenseId}/suspend`, { reason: 'Invoice 4411 unpaid' });
  assert.equal(s.status, 200, JSON.stringify(s.body));
  assert.equal(s.body.status, 'SUSPENDED');
  const [h] = await q('SELECT reason, changed_by_user_id, from_status_code, to_status_code FROM license_status_history WHERE license_id = $1 ORDER BY changed_at DESC LIMIT 1', [l.licenseId]);
  assert.deepEqual([h.reason, h.changed_by_user_id, h.from_status_code, h.to_status_code], ['Invoice 4411 unpaid', boss.userId, 'ACTIVE', 'SUSPENDED']);

  const reval = await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token });
  assert.equal(reval.status, 403); assert.equal(reval.body.reason, 'suspended');
  const act2 = await ls.post('/v1/activate', { machineId: other, licenseKey: l.licenceKey });
  assert.equal(act2.status, 403); assert.equal(act2.body.reason, 'suspended');

  assert.equal((await act(`licenses/${l.licenseId}/suspend`, {})).status, 200, 'suspending twice is harmless');
  assert.equal((await q('SELECT count(*)::int AS n FROM license_status_history WHERE license_id = $1 AND to_status_code = $2', [l.licenseId, 'SUSPENDED']))[0].n, 1, 'and does not write a second history row');

  const back = await act(`licenses/${l.licenseId}/reinstate`, { reason: 'Paid on 12 Oct' });
  assert.equal(back.body.status, 'ACTIVE');
  assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).status, 200, 'the same machine carries on, its seat was kept');
  assert.equal((await act(`licenses/${l.licenseId}/reinstate`, {})).status, 200, 'reinstating an active licence is harmless');
});

test('only a licence that is ACTIVE can be suspended, only a SUSPENDED one reinstated; support lacks the permission by default', async () => {
  const pending = await licence();
  const r = await act(`licenses/${pending.licenseId}/suspend`, {});
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'invalid_transition');
  assert.match(r.body.message, /PENDING_ACTIVATION/);

  const a = await activeLicence();
  const denied = await act(`licenses/${a.licenseId}/suspend`, {}, sam);
  assert.equal(denied.status, 403); assert.equal(denied.body.reason, 'forbidden');
  assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [a.licenseId]))[0].status_code, 'ACTIVE');
  assert.equal((await act(`licenses/${a.licenseId}/reinstate`, {}, sam)).status, 403);

  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = 'CANCELLED' FROM r WHERE license_id = $1`, [a.licenseId]);
  assert.equal((await act(`licenses/${a.licenseId}/reinstate`, {})).status, 409, 'a cancelled licence is final');
});

test('a reason is required for every change, and every id must be an id', async () => {
  const a = await activeLicence();
  const routes = [`licenses/${a.licenseId}/suspend`, `licenses/${a.licenseId}/reinstate`, `licenses/${a.licenseId}/renew`, `licenses/${a.licenseId}/extend`, `licenses/${a.licenseId}/cancel`, `licenses/${a.licenseId}/revoke`, 'trials/0190aaaa-0000-7000-8000-000000000000/extend'];
  for (const route of routes) {
    for (const reason of [undefined, '', '   ', 7, 'x'.repeat(501)]) {
      const r = await svc.post(`/v1/admin/${route}`, { reason, days: 5 }, boss.as);
      assert.equal(r.status, 400, `${route} ${JSON.stringify(reason)}`);
      assert.ok(['reason_required', 'reason_too_long'].includes(r.body.reason));
    }
  }
  for (const id of ['x', '..', '0190AAAA', "'; DROP TABLE license; --", '0190aaaa-0000-7000-8000-000000000000']) {
    for (const route of ['suspend', 'reinstate', 'cancel', 'revoke', 'renew', 'extend']) {
      assert.equal((await act(`licenses/${encodeURIComponent(id)}/${route}`, { days: 5 })).status, 404, `${route} ${id}`);
    }
    assert.equal((await act(`trials/${encodeURIComponent(id)}/extend`, { days: 5 })).status, 404, `trial ${id}`);
  }
});

// ── Renew ───────────────────────────────────────────────────────────────────

test('renewing adds a term that starts where the last one ends; the app sees the new expiry at its next check', async () => {
  const l = await activeLicence({ days: 30 });
  const before = ls.claims(l.token).exp;
  const r = await act(`licenses/${l.licenseId}/renew`, { termDays: 365, reference: 'PO #4411/2026' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.term.termNo, r.body.term.days, r.body.term.source], [2, 365, 'renewal']);
  const t = await terms(l.licenseId);
  assert.equal(t.length, 2);
  assert.equal(t[1].starts_at.getTime(), t[0].ends_at.getTime(), 'contiguous: no gap and no overlap');
  assert.equal(t[1].ends_at.getTime() - t[1].starts_at.getTime(), 365 * DAY);
  assert.deepEqual([t[1].source_code, t[1].reference], ['renewal', 'PO #4411/2026']);
  const re = await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token });
  assert.equal(re.status, 200);
  assert.equal(ls.claims(re.body.token).exp - before, 365 * DAY);
});

test('renewing a licence that has already ended starts the new term now, and the app can use it again', async () => {
  const l = await activeLicence({ days: 30 });
  await ageTerm(l.licenseId, 20);
  assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).body.reason, 'expired');
  const r = await act(`licenses/${l.licenseId}/renew`, { termDays: 100 });
  assert.equal(r.status, 200);
  const t = await terms(l.licenseId);
  assert.ok(Math.abs(t[1].starts_at.getTime() - Date.now()) < 5000, 'starts now, not at the old end');
  assert.ok(t[1].starts_at > t[0].ends_at, 'the time in between was not covered');
  assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).status, 200);
});

test('a licence the system marked EXPIRED becomes ACTIVE again when it is renewed, with a reason on record', async () => {
  const l = await activeLicence({ days: 30 });
  await ageTerm(l.licenseId, 5);
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'term ended', true)) UPDATE license SET status_code = 'EXPIRED' FROM r WHERE license_id = $1`, [l.licenseId]);
  const r = await act(`licenses/${l.licenseId}/renew`, { termDays: 365, reason: 'Renewed for 2027' });
  assert.equal(r.body.status, 'ACTIVE'); assert.equal(r.body.statusMoved, true);
  const [h] = await q(`SELECT reason, changed_by_user_id FROM license_status_history WHERE license_id = $1 AND to_status_code = 'ACTIVE' ORDER BY changed_at DESC LIMIT 1`, [l.licenseId]);
  assert.deepEqual([h.reason, h.changed_by_user_id], ['Renewed for 2027', boss.userId]);
});

test('renewal defaults to the plan\'s term; a cancelled licence cannot be renewed; a suspended one stays suspended', async () => {
  const l = await licence({ plan: 'individual', seats: 1 });
  assert.equal((await act(`licenses/${l.licenseId}/renew`, {})).body.term.days, 365);
  const a = await activeLicence();
  await act(`licenses/${a.licenseId}/suspend`, {});
  const r = await act(`licenses/${a.licenseId}/renew`, { termDays: 30 });
  assert.equal(r.status, 200); assert.equal(r.body.status, 'SUSPENDED');
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE license SET status_code = 'CANCELLED' FROM r WHERE license_id = $1`, [a.licenseId]);
  const c = await act(`licenses/${a.licenseId}/renew`, { termDays: 30 });
  assert.equal(c.status, 409); assert.equal(c.body.reason, 'licence_cancelled');
  assert.equal((await terms(a.licenseId)).length, 2, 'nothing was added');
});

test('renew and extend refuse bad sizes and references, and add nothing', async () => {
  const l = await licence();
  const before = (await terms(l.licenseId)).length;
  for (const body of [{ termDays: 0 }, { termDays: 3651 }, { termDays: 1.5 }, { termDays: '30' }, { termDays: null }, { termDays: [30] }, { reference: 5 }, { reference: 'x'.repeat(101) }, { reference: '<script>' }, { reference: '' }]) {
    const r = await act(`licenses/${l.licenseId}/renew`, body);
    assert.equal(r.status, 400, JSON.stringify(body)); assert.ok(['bad_term', 'bad_reference'].includes(r.body.reason));
  }
  for (const body of [{}, { days: 0 }, { days: 91 }, { days: 2.5 }, { days: '7' }, { days: null }, { termDays: 7 }]) {
    const r = await act(`licenses/${l.licenseId}/extend`, body);
    assert.equal(r.status, 400, JSON.stringify(body)); assert.equal(r.body.reason, 'bad_term');
  }
  assert.equal((await terms(l.licenseId)).length, before);
});

test('three renewals at once: all succeed, one after another, with no overlap and no duplicate term number', async () => {
  const l = await activeLicence({ days: 30 });
  const results = await Promise.all([1, 2, 3].map(() => act(`licenses/${l.licenseId}/renew`, { termDays: 10 })));
  assert.deepEqual(results.map(r => r.status), [200, 200, 200], JSON.stringify(results.map(r => r.body)));
  const t = await terms(l.licenseId);
  assert.deepEqual(t.map(x => x.term_no), [1, 2, 3, 4]);
  for (let i = 1; i < t.length; i++) assert.equal(t[i].starts_at.getTime(), t[i - 1].ends_at.getTime());
});

// ── Extend a licence ────────────────────────────────────────────────────────

test('extending adds a goodwill term "entered by hand": up to 90 days, from the current end', async () => {
  const l = await activeLicence({ days: 30 });
  const r = await act(`licenses/${l.licenseId}/extend`, { days: 14, reason: 'Renewal PO delayed, goodwill' });
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.term.termNo, r.body.term.days, r.body.term.source], [2, 14, 'manual']);
  const t = await terms(l.licenseId);
  assert.equal(t[1].ends_at.getTime() - t[0].ends_at.getTime(), 14 * DAY);
  assert.equal(t[1].reference, null);
  assert.equal(ls.claims((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).body.token).exp, t[1].ends_at.getTime());
  assert.equal((await act(`licenses/${l.licenseId}/extend`, { days: 90 })).status, 200);
  assert.equal((await act(`licenses/${l.licenseId}/extend`, { days: 91 })).status, 400);
});

test('renew needs LICENSE_ACTIVATE and extend needs LICENSE_UPDATE: both are granted to support, and both can be taken away', async () => {
  const l = await activeLicence();
  assert.equal((await act(`licenses/${l.licenseId}/renew`, { termDays: 10 }, sam)).status, 200);
  assert.equal((await act(`licenses/${l.licenseId}/extend`, { days: 10 }, sam)).status, 200);
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code IN ('LICENSE_ACTIVATE', 'LICENSE_UPDATE')`);
  const n = (await terms(l.licenseId)).length;
  assert.equal((await act(`licenses/${l.licenseId}/renew`, { termDays: 10 }, sam)).status, 403);
  assert.equal((await act(`licenses/${l.licenseId}/extend`, { days: 10 }, sam)).status, 403);
  assert.equal((await act(`trials/${crypto.randomUUID()}/extend`, { days: 5 }, sam)).status, 403);
  assert.equal((await terms(l.licenseId)).length, n);
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'LICENSE_ACTIVATE'), ('SUPPORT', 'LICENSE_UPDATE')`);
});

// ── Trials ──────────────────────────────────────────────────────────────────

/** A trial row straight into the licence database. `endsInDays` negative means already over. Returns { trialId, machine }. */
async function trial({ endsInDays = 3, status = 'ACTIVE', org = null, flag = null } = {}) {
  const machine = crypto.randomBytes(16).toString('hex'), instId = crypto.randomUUID(), trialId = crypto.randomUUID();
  await svc.licenseDb.query(`INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code, platform, arch, app_version) VALUES ($1, $2, 'darwin', 'darwin', 'arm64', '2.0.1')`, [instId, machine]);
  await svc.licenseDb.query(`INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '10 days' + make_interval(days => $3), now() + make_interval(days => $3))`, [trialId, instId, endsInDays]);
  if (org) await svc.licenseDb.query(`INSERT INTO trial_integration (trial_id, github_org, github_url, jenkins_url) VALUES ($1, $2, 'https://github.example.test', 'https://ci.example.test')`, [trialId, org]);
  if (flag) await svc.licenseDb.query(`INSERT INTO trial_review_flag (trial_id, flag_code) VALUES ($1, $2)`, [trialId, flag]);
  if (status !== 'ACTIVE') await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'setup', true)) UPDATE trial SET status_code = $2 FROM r WHERE trial_id = $1`, [trialId, status]);
  return { trialId, machine };
}

test('the trial list shows what identifies a trial, never the machine id, with filters; reading it is recorded', async () => {
  const a = await trial({ org: 'listed-org', flag: 'weak_fingerprint' });
  const b = await trial({ endsInDays: -2, status: 'EXPIRED' });
  const all = await svc.get('/v1/admin/trials?limit=200', sam.as);
  assert.equal(all.status, 200);
  const row = all.body.trials.find(t => t.trial_id === a.trialId);
  assert.deepEqual([row.status_code, row.github_org, row.platform, row.has_ended, row.open_flags], ['ACTIVE', 'listed-org', 'darwin', false, ['weak_fingerprint']]);
  assert.ok(!/github_url|jenkins_url|https:\/\/(github|ci)\.example\.test/.test(JSON.stringify(all.body)), 'only what the screen needs: the organisation, not the addresses');
  assert.ok(!JSON.stringify(all.body).includes(a.machine) && !JSON.stringify(all.body).includes(b.machine), 'a machine id is never shown to staff');
  assert.ok(all.body.trials.find(t => t.trial_id === b.trialId).has_ended);

  assert.ok((await svc.get('/v1/admin/trials?status=expired&limit=200', sam.as)).body.trials.every(t => t.status_code === 'EXPIRED'));
  assert.ok((await svc.get('/v1/admin/trials?flagged=true&limit=200', sam.as)).body.trials.every(t => t.open_flags.length > 0));
  assert.ok((await svc.get('/v1/admin/trials?flagged=false&limit=200', sam.as)).body.trials.every(t => t.open_flags.length === 0));
  for (const bad of ['?status=NOPE', '?flagged=maybe', '?limit=0', '?status[]=x']) assert.equal((await svc.get(`/v1/admin/trials${bad}`, sam.as)).status, 400, bad);
  const [audit] = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE action = 'trial.list' ORDER BY occurred_at DESC LIMIT 1`);
  assert.equal(audit.outcome, 'read'); assert.ok(Number.isInteger(audit.detail.returned));
});

test('extending a running trial adds days to its current end; the app\'s next token carries it', async () => {
  const t = await trial({ endsInDays: 2 });
  const r = await act(`trials/${t.trialId}/extend`, { days: 5, reason: 'Evaluation slipped' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.status, 'ACTIVE');
  const [row] = await q('SELECT expires_at, extended_until, extended_by_user_id FROM trial WHERE trial_id = $1', [t.trialId]);
  assert.equal(row.extended_until.getTime() - row.expires_at.getTime(), 5 * DAY, 'the original expiry is kept, the extension is separate');
  assert.equal(row.extended_by_user_id, boss.userId);
  const token = (await ls.post('/v1/trial', { machineId: t.machine })).body.token;
  assert.ok(Math.abs(ls.claims(token).exp - row.extended_until.getTime()) < 1000);
  const again = await act(`trials/${t.trialId}/extend`, { days: 3 }, sam);
  assert.equal(again.status, 200);
  assert.equal((await q('SELECT extended_until FROM trial WHERE trial_id = $1', [t.trialId]))[0].extended_until.getTime() - row.extended_until.getTime(), 3 * DAY, 'extensions add up');
});

test('extending a trial that has already ended brings it back for a real window from now, with a reason on record', async () => {
  const t = await trial({ endsInDays: -20, status: 'EXPIRED' });
  assert.equal((await ls.post('/v1/trial', { machineId: t.machine })).body.reason, 'trial_ended');
  const r = await act(`trials/${t.trialId}/extend`, { days: 7, reason: 'Customer was on leave' });
  assert.equal(r.status, 200);
  assert.equal(r.body.status, 'ACTIVE');
  const [row] = await q('SELECT extended_until FROM trial WHERE trial_id = $1', [t.trialId]);
  assert.ok(Math.abs(row.extended_until.getTime() - (Date.now() + 7 * DAY)) < 5000, 'seven days from now, not from last month');
  const [h] = await q(`SELECT reason, from_status_code, to_status_code, changed_by_user_id FROM trial_status_history WHERE trial_id = $1 ORDER BY changed_at DESC LIMIT 1`, [t.trialId]);
  assert.deepEqual([h.reason, h.from_status_code, h.to_status_code, h.changed_by_user_id], ['Customer was on leave', 'EXPIRED', 'ACTIVE', boss.userId]);
  const issued = await ls.post('/v1/trial', { machineId: t.machine });
  assert.equal(issued.status, 200, 'the app can start again');
  assert.equal((await ls.post('/v1/revalidate', { machineId: t.machine, token: issued.body.token })).status, 200);
});

test('a trial that became a licence cannot be extended; unknown trials, bad sizes and a missing size are refused', async () => {
  const converted = await trial({ endsInDays: 2 });
  const lic = await licence();
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'activated', true)) UPDATE trial SET status_code = 'CONVERTED', converted_license_id = $2, converted_at = now() FROM r WHERE trial_id = $1`, [converted.trialId, lic.licenseId]);
  const r = await act(`trials/${converted.trialId}/extend`, { days: 5 });
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'trial_converted');
  assert.equal((await act(`trials/${crypto.randomUUID()}/extend`, { days: 5 })).status, 404);
  const t = await trial();
  for (const body of [{}, { days: 0 }, { days: 31 }, { days: 1.5 }, { days: '5' }, { days: null }, { days: [5] }]) {
    const x = await act(`trials/${t.trialId}/extend`, body);
    assert.equal(x.status, 400, JSON.stringify(body)); assert.equal(x.body.reason, 'bad_term');
  }
  assert.equal((await q('SELECT extended_until FROM trial WHERE trial_id = $1', [t.trialId]))[0].extended_until, null);
});

// ── Audit ───────────────────────────────────────────────────────────────────

test('every one of these changes is audited before it is made, with a validated detail and the reason', async () => {
  const l = await activeLicence({ days: 30 });
  await act(`licenses/${l.licenseId}/suspend`, { reason: 'audit 1' });
  await act(`licenses/${l.licenseId}/reinstate`, { reason: 'audit 2' });
  await act(`licenses/${l.licenseId}/renew`, { termDays: 20, reason: 'audit 3', reference: 'PO-77' });
  await act(`licenses/${l.licenseId}/extend`, { days: 4, reason: 'audit 4' });
  const trail = await rows(svc.identityDb, `SELECT action, outcome, reason, detail, actor_user_id FROM admin_audit WHERE subject_ref = $1 AND action <> 'licence.create' ORDER BY occurred_at`, [l.licenseId]);
  assert.deepEqual(trail.map(t => `${t.action}:${t.outcome}`), ['licence.suspend:started', 'licence.suspend:done', 'licence.reinstate:started', 'licence.reinstate:done', 'licence.renew:started', 'licence.renew:done', 'licence.extend:started', 'licence.extend:done']);
  assert.ok(trail.every(t => t.actor_user_id === boss.userId));
  assert.deepEqual(trail[1].detail, { from: 'ACTIVE', to: 'SUSPENDED' });
  assert.deepEqual(trail[5].detail.days, 20);
  assert.deepEqual([trail[5].detail.from, trail[5].detail.to, trail[5].detail.termNo], ['ACTIVE', 'ACTIVE', 2]);
  assert.ok(!JSON.stringify(trail).includes('PO-77'), 'free text a person typed is not copied into the trail');
  assert.equal(trail[6].reason, 'audit 4');
});

test('a refused change is audited as failed with its code, and changes nothing', async () => {
  const pending = await licence();
  await act(`licenses/${pending.licenseId}/suspend`, { reason: 'too early' });
  const trail = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE subject_ref = $1 AND action <> 'licence.create' ORDER BY occurred_at`, [pending.licenseId]);
  assert.deepEqual(trail.map(t => t.outcome), ['started', 'failed']);
  assert.equal(trail[1].detail.error, 'invalid_transition');
  assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [pending.licenseId]))[0].status_code, 'PENDING_ACTIVATION');
});

test('if the audit cannot be written, the suspension is not made', async () => {
  const l = await activeLicence();
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    const r = await broken.post(`/v1/admin/licenses/${l.licenseId}/suspend`, { reason: 'should not happen' }, boss.as);
    assert.equal(r.status, 500);
    assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [l.licenseId]))[0].status_code, 'ACTIVE');
    assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).status, 200);
  } finally { await broken.close(); }
});

test('every route needs a signed-in session', async () => {
  const l = await licence();
  const calls = [['get', '/v1/admin/licenses'], ['get', '/v1/admin/trials'], ...['suspend', 'reinstate', 'cancel', 'revoke', 'renew', 'extend'].map(a => ['post', `/v1/admin/licenses/${l.licenseId}/${a}`]), ['post', `/v1/admin/trials/${crypto.randomUUID()}/extend`]];
  for (const [method, path] of calls) {
    for (const headers of [{}, { Authorization: 'Bearer nope' }]) {
      const r = await svc[method](path, method === 'get' ? undefined : { reason: 'x', days: 1 }, headers);
      assert.equal(r.status, 401, `${method} ${path}`);
    }
  }
});

// ── Cancel and revoke ───────────────────────────────────────────────────────

const hintOf = l => l.licenceKey.slice(-4);

test('cancelling ends the licence for good: the app is told "revoked", nothing can renew or reinstate it, and the history says who and why', async () => {
  const l = await activeLicence();
  const r = await act(`licenses/${l.licenseId}/cancel`, { confirm: hintOf(l), reason: 'Customer left; refund agreed' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.status, 'CANCELLED');
  assert.equal(r.body.seatsReleased, undefined, 'a cancellation leaves the seat record as it was');
  const [h] = await q('SELECT reason, changed_by_user_id, from_status_code, to_status_code FROM license_status_history WHERE license_id = $1 ORDER BY changed_at DESC LIMIT 1', [l.licenseId]);
  assert.deepEqual([h.reason, h.changed_by_user_id, h.from_status_code, h.to_status_code], ['Customer left; refund agreed', boss.userId, 'ACTIVE', 'CANCELLED']);

  const reval = await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token });
  assert.equal(reval.status, 403); assert.equal(reval.body.reason, 'revoked');
  const fresh = await ls.post('/v1/activate', { machineId: crypto.randomBytes(16).toString('hex'), licenseKey: l.licenceKey });
  assert.equal(fresh.status, 403); assert.equal(fresh.body.reason, 'revoked');

  assert.equal((await act(`licenses/${l.licenseId}/reinstate`, {})).status, 409);
  assert.equal((await act(`licenses/${l.licenseId}/suspend`, {})).status, 409);
  assert.equal((await act(`licenses/${l.licenseId}/renew`, { termDays: 30 })).body.reason, 'licence_cancelled');
  assert.equal((await act(`licenses/${l.licenseId}/extend`, { days: 5 })).body.reason, 'licence_cancelled');
  assert.equal((await q(`SELECT count(*)::int AS n FROM license_status_history WHERE license_id = $1 AND to_status_code = 'CANCELLED'`, [l.licenseId]))[0].n, 1);
});

test('revoking also frees every seat at once, with the reason "revoked"; cancelling an already cancelled licence changes nothing', async () => {
  const l = await activeLicence({ seats: 5 });
  for (let i = 0; i < 2; i++) assert.equal((await ls.post('/v1/activate', { machineId: crypto.randomBytes(16).toString('hex'), licenseKey: l.licenceKey })).status, 200);
  assert.equal((await q('SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [l.licenseId]))[0].n, 3);
  const r = await act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l).toLowerCase(), reason: 'Key posted publicly' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.status, r.body.seatsReleased], ['CANCELLED', 3]);
  const seats = await q('SELECT release_reason_code, released_at, activated_at FROM activation WHERE license_id = $1', [l.licenseId]);
  assert.ok(seats.every(s => s.release_reason_code === 'revoked' && s.released_at >= s.activated_at));
  assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).body.reason, 'revoked');

  assert.equal((await act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l) })).body.seatsReleased, 0, 'repeating frees nothing more');
  assert.equal((await act(`licenses/${l.licenseId}/cancel`, { confirm: hintOf(l) })).status, 200);
  assert.equal((await q(`SELECT count(*)::int AS n FROM license_status_history WHERE license_id = $1 AND to_status_code = 'CANCELLED'`, [l.licenseId]))[0].n, 1, 'one cancellation on record, however many times it was asked for');
});

test('revoking a licence that was only cancelled frees the seats that cancelling left', async () => {
  const l = await activeLicence();
  await act(`licenses/${l.licenseId}/cancel`, { confirm: hintOf(l) });
  assert.equal((await q('SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [l.licenseId]))[0].n, 1);
  const r = await act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l), reason: 'Found to be shared' });
  assert.equal(r.body.seatsReleased, 1);
});

test('a pending, suspended or active licence can be ended; an EXPIRED one cannot (it is already over)', async () => {
  const pending = await licence();
  assert.equal((await act(`licenses/${pending.licenseId}/cancel`, { confirm: hintOf(pending) })).status, 200);
  const suspended = await activeLicence();
  await act(`licenses/${suspended.licenseId}/suspend`, {});
  assert.equal((await act(`licenses/${suspended.licenseId}/revoke`, { confirm: hintOf(suspended) })).status, 200);
  const expired = await activeLicence();
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'term ended', true)) UPDATE license SET status_code = 'EXPIRED' FROM r WHERE license_id = $1`, [expired.licenseId]);
  const r = await act(`licenses/${expired.licenseId}/cancel`, { confirm: hintOf(expired) });
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'invalid_transition');
  assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [expired.licenseId]))[0].status_code, 'EXPIRED');
});

test('it cannot be done by accident: confirmation is required and must match the licence, and nothing changes without it', async () => {
  const l = await activeLicence();
  const other = await licence();
  for (const route of ['cancel', 'revoke']) {
    const missing = await act(`licenses/${l.licenseId}/${route}`, {});
    assert.equal(missing.status, 400); assert.equal(missing.body.reason, 'confirmation_required');
    for (const confirm of ['', '    ', 'ZZZZ', hintOf(other) === hintOf(l) ? 'QQQQ' : hintOf(other), 5, null, [hintOf(l)], { a: 1 }, true, `${hintOf(l)}X`]) {
      const r = await act(`licenses/${l.licenseId}/${route}`, { confirm });
      assert.equal(r.status, 400, `${route} ${JSON.stringify(confirm)}`); assert.equal(r.body.reason, 'confirmation_mismatch');
    }
    assert.equal((await act(`licenses/${l.licenseId}/${route}`, { confirm: hintOf(l), reason: '' })).body.reason, 'reason_required');
  }
  assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [l.licenseId]))[0].status_code, 'ACTIVE');
  assert.equal((await q('SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [l.licenseId]))[0].n, 1);
  assert.equal((await ls.post('/v1/revalidate', { machineId: l.machine, token: l.token })).status, 200);
});

test('cancel and revoke need LICENSE_SUSPEND, which support does not have by default; unknown ids are 404', async () => {
  const l = await activeLicence();
  for (const route of ['cancel', 'revoke']) {
    const r = await act(`licenses/${l.licenseId}/${route}`, { confirm: hintOf(l) }, sam);
    assert.equal(r.status, 403); assert.equal(r.body.reason, 'forbidden');
    assert.equal((await act(`licenses/${crypto.randomUUID()}/${route}`, { confirm: 'ABCD' })).status, 404);
    assert.equal((await act(`licenses/not-an-id/${route}`, { confirm: 'ABCD' })).status, 404);
  }
  assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [l.licenseId]))[0].status_code, 'ACTIVE');
  assert.equal((await svc.post(`/v1/admin/licenses/${l.licenseId}/cancel`, { confirm: hintOf(l), reason: 'x' }, {})).status, 401);
});

test('cancel and revoke are told apart in the audit trail, and the confirmation text is not copied into it', async () => {
  const l = await activeLicence();
  await act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l), reason: 'Leaked key' });
  const l2 = await activeLicence();
  await act(`licenses/${l2.licenseId}/cancel`, { confirm: hintOf(l2), reason: 'Left us' });
  const t1 = await rows(svc.identityDb, `SELECT action, outcome, detail, reason FROM admin_audit WHERE subject_ref = $1 AND action <> 'licence.create' ORDER BY occurred_at`, [l.licenseId]);
  assert.deepEqual(t1.map(t => `${t.action}:${t.outcome}`), ['licence.revoke:started', 'licence.revoke:done']);
  assert.deepEqual(t1[1].detail, { from: 'ACTIVE', to: 'CANCELLED', seatsReleased: 1 });
  const t2 = await rows(svc.identityDb, `SELECT action, detail FROM admin_audit WHERE subject_ref = $1 AND outcome = 'done' AND action <> 'licence.create'`, [l2.licenseId]);
  assert.deepEqual([t2[0].action, t2[0].detail], ['licence.cancel', { from: 'ACTIVE', to: 'CANCELLED' }]);
  assert.ok(!JSON.stringify(t1).includes('confirm'), 'the confirmation is not copied into the trail');
  const refused = await activeLicence();
  await act(`licenses/${refused.licenseId}/cancel`, { confirm: 'WRNG', reason: 'wrong' });
  const failed = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE subject_ref = $1 AND action = 'licence.cancel' ORDER BY occurred_at`, [refused.licenseId]);
  assert.deepEqual(failed.map(t => t.outcome), ['started', 'failed']);
  assert.equal(failed[1].detail.error, 'confirmation_mismatch');
});

test('if the audit cannot be written, the licence is not revoked', async () => {
  const l = await activeLicence();
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    assert.equal((await broken.post(`/v1/admin/licenses/${l.licenseId}/revoke`, { confirm: hintOf(l), reason: 'nope' }, boss.as)).status, 500);
    assert.equal((await q('SELECT status_code FROM license WHERE license_id = $1', [l.licenseId]))[0].status_code, 'ACTIVE');
  } finally { await broken.close(); }
});
