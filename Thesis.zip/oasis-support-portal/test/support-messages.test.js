'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { startSupportService } = require('./helpers/support-service');
const { staffSignedIn, rows } = require('./helpers/fixtures');

let svc, sup, sam, lee, boss;
test.before(async () => {
  svc = await startService();
  sup = await startSupportService(svc);
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  lee = await staffSignedIn(svc, { name: 'Lee Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
});
test.after(async () => { await sup.close(); await svc.close(); });

const list = (query = '', who = sam) => svc.get(`/v1/admin/support-requests${query}`, who.as);
const view = (ref, who = sam) => svc.get(`/v1/admin/support-requests/${ref}`, who.as);
const patch = (ref, body, who = sam) => svc.patch(`/v1/admin/support-requests/${ref}`, body, who.as);
const note = (ref, body, who = sam) => svc.post(`/v1/admin/support-requests/${ref}/notes`, body, who.as);
const feedbackList = (query = '', who = sam) => svc.get(`/v1/admin/feedback${query}`, who.as);
const sdb = (sql, params) => rows(svc.supportDb, sql, params);
const trail = (ref, action) => rows(svc.identityDb, `SELECT outcome, reason, detail, actor_user_id FROM admin_audit WHERE subject_ref = $1 AND action = $2 ORDER BY occurred_at`, [ref, action]);

// ── Support requests: the list ───────────────────────────────────────────────

test('the list shows who and about what, open ones first and oldest first, and never the message or anything that identifies a machine', async () => {
  const closed = await sup.request({ subject: 'Old and closed' });
  await patch(closed, { status: 'CLOSED', reason: 'Not needed' });
  const a = await sup.request({ subject: 'First open', email: 'first@first.example.test', message: 'SECRET words the person wrote' });
  const b = await sup.request({ subject: 'Second open', machineId: crypto.randomBytes(16).toString('hex') });
  const r = await list('?limit=200');
  assert.equal(r.status, 200);
  const refs = r.body.supportRequests.map(x => x.reference);
  assert.ok(refs.indexOf(a) < refs.indexOf(b) && refs.indexOf(b) < refs.indexOf(closed), 'open first, oldest first, closed last');
  const row = r.body.supportRequests.find(x => x.reference === a);
  assert.deepEqual(Object.keys(row).sort(), ['app_version', 'assigned_to_name', 'assigned_to_user_id', 'contact_name', 'created_at', 'customer_ref', 'email', 'email_domain', 'hours_open_or_to_close', 'is_closed', 'notes', 'reference', 'status', 'status_changed_at', 'status_code', 'subject']);
  assert.deepEqual([row.email, row.email_domain, row.status_code, row.notes], ['first@first.example.test', 'first.example.test', 'NEW', 0]);
  assert.ok(!JSON.stringify(r.body).includes('SECRET words'), 'the message is read one request at a time, and that read is audited');
  assert.ok(!/installation|request_hash|idempotency/.test(JSON.stringify(r.body)));
});

test('filters: status (one or several), assignee (me, none, an id), limit and offset; bad filters are refused', async () => {
  const x = await sup.request();
  await patch(x, { assignedTo: sam.userId, reason: 'Mine' }, boss);
  await patch(x, { status: 'IN_PROGRESS', reason: 'Working it' });
  assert.ok((await list('?status=in_progress')).body.supportRequests.every(r => r.status_code === 'IN_PROGRESS'));
  assert.ok((await list('?status=NEW,IN_PROGRESS&limit=200')).body.supportRequests.some(r => r.reference === x));
  const mine = (await list('?assignedTo=me&limit=200')).body.supportRequests;
  assert.ok(mine.some(r => r.reference === x) && mine.every(r => r.assigned_to_user_id === sam.userId));
  assert.equal(mine.find(r => r.reference === x).assigned_to_name, 'Sam Support');
  assert.ok(!(await list('?assignedTo=me&limit=200', lee)).body.supportRequests.some(r => r.reference === x));
  assert.ok((await list('?assignedTo=none&limit=200')).body.supportRequests.every(r => r.assigned_to_user_id === null));
  assert.ok((await list(`?assignedTo=${sam.userId}&limit=200`)).body.supportRequests.some(r => r.reference === x));
  assert.equal((await list('?limit=1')).body.supportRequests.length, 1);
  for (const bad of ['?status=BOGUS', '?status=', '?assignedTo=someone', '?limit=0', '?limit=201', '?offset=-1', '?status[]=NEW', '?status=NEW&status=NEW']) {
    const r = await list(bad);
    assert.equal(r.status, 400, bad); assert.equal(r.body.reason, 'bad_filter');
  }
});

test('reading the list is recorded with the filter and how many rows, but no addresses or words', async () => {
  await sup.request({ email: 'audited@audit.example.test', message: 'audit-me-please' });
  await list('?status=NEW');
  const [a] = await rows(svc.identityDb, `SELECT * FROM admin_audit WHERE actor_user_id = $1 AND action = 'support_request.list' ORDER BY occurred_at DESC LIMIT 1`, [sam.userId]);
  assert.equal(a.outcome, 'read'); assert.equal(a.detail.status, 'NEW'); assert.ok(a.detail.returned >= 1);
  assert.ok(!JSON.stringify(a).includes('audit.example.test') && !JSON.stringify(a).includes('audit-me-please'));
});

// ── One request in full ──────────────────────────────────────────────────────

test('one request in full: the message, the notes and every status it has had, with names; the read is audited with the reference', async () => {
  const ref = await sup.request({ subject: 'Full view', message: 'Line one\n\nLine two with <b>markup</b>', contactName: 'Vera Viewer' });
  await patch(ref, { assignedTo: lee.userId, reason: 'Lee takes it' }, boss);
  await patch(ref, { status: 'IN_PROGRESS', reason: 'Lee started' }, lee);
  await note(ref, { body: 'Called, no answer' }, lee);
  const r = await view(ref);
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.subject, r.body.message, r.body.contact_name, r.body.status_code, r.body.assigned_to_name], ['Full view', 'Line one\n\nLine two with <b>markup</b>', 'Vera Viewer', 'IN_PROGRESS', 'Lee Support']);
  assert.deepEqual(r.body.notes.map(n => [n.body, n.author_name]), [['Called, no answer', 'Lee Support']]);
  assert.deepEqual(r.body.history.map(h => [h.from_status_code, h.to_status_code, h.reason, h.changed_by_name]), [[null, 'NEW', 'Submitted', null], ['NEW', 'IN_PROGRESS', 'Lee started', 'Lee Support']]);
  assert.ok(!/support_request_id|installation_ref|request_hash|idempotency/.test(JSON.stringify(r.body)), 'no internal keys');
  const t = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE subject_ref = $1 AND action = 'support_request.view'`, [ref]);
  assert.deepEqual(t, [{ outcome: 'read', detail: { notes: 1 } }]);
});

test('an unknown or malformed reference is 404, and nothing is read', async () => {
  for (const ref of ['SR-999999', 'SR-1', 'sr-000001', "SR-000001'--", '..', 'FB-000001']) {
    assert.equal((await view(encodeURIComponent(ref))).status, 404, ref);
    assert.equal((await patch(encodeURIComponent(ref), { status: 'CLOSED', reason: 'x' })).status, 404, ref);
    assert.equal((await note(encodeURIComponent(ref), { body: 'x' })).status, 404, ref);
  }
});

// ── Answering ────────────────────────────────────────────────────────────────

test('a status move needs a reason, follows the allowed moves, and is recorded with who and why; closed is final', async () => {
  const ref = await sup.request();
  const noReason = await patch(ref, { status: 'IN_PROGRESS' });
  assert.equal(noReason.status, 400); assert.equal(noReason.body.reason, 'reason_required');
  for (const reason of ['', '   ', 5, 'x'.repeat(501)]) assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason })).status, 400);
  assert.equal((await patch(ref, { status: 'in_progress', reason: 'Picked up' })).status, 200);
  const back = await patch(ref, { status: 'NEW', reason: 'back again' });
  assert.equal(back.status, 409); assert.equal(back.body.reason, 'invalid_transition');
  assert.equal((await patch(ref, { status: 'WIBBLE', reason: 'nonsense' })).body.reason, 'bad_status');
  assert.equal((await patch(ref, { status: 'RESOLVED', reason: 'Answered by email' })).status, 200);
  assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason: 'The person wrote back' })).status, 200);
  assert.equal((await patch(ref, { status: 'CLOSED', reason: 'Sorted' })).status, 200);
  assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason: 'reopen' })).status, 409, 'a closed request stays closed');
  const h = await sdb(`SELECT h.to_status_code, h.reason, h.changed_by_user_id FROM support_request_status_history h JOIN support_request r USING (support_request_id) WHERE r.reference = $1 ORDER BY h.changed_at`, [ref]);
  assert.deepEqual(h.map(x => x.to_status_code), ['NEW', 'IN_PROGRESS', 'RESOLVED', 'IN_PROGRESS', 'CLOSED']);
  assert.deepEqual([h[1].reason, h[1].changed_by_user_id], ['Picked up', sam.userId]);
});

test('assigning: to an active staff member or to nobody; a stranger, a customer user, a disabled or role-less member, and the wrong type are refused', async () => {
  const ref = await sup.request();
  assert.equal((await patch(ref, { assignedTo: lee.userId, reason: 'Lee has the account' }, boss)).status, 200);
  assert.equal((await sdb('SELECT assigned_to_user_id FROM support_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, lee.userId);
  assert.equal((await patch(ref, { assignedTo: null, reason: 'unassign' }, boss)).status, 200);
  assert.equal((await sdb('SELECT assigned_to_user_id FROM support_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, null);

  const gone = await staffSignedIn(svc), roleless = await staffSignedIn(svc);
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'left', true)) UPDATE app_user SET status_code = 'DISABLED' FROM r WHERE user_id = $1`, [gone.userId]);
  await svc.identityDb.query('UPDATE user_role SET revoked_at = now() WHERE user_id = $1', [roleless.userId]);
  const customer = (await rows(svc.identityDb, 'SELECT gen_random_uuid() AS id'))[0].id;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, status_code) VALUES ($1, gen_random_uuid(), 'customer', 'c1@example.test', 'ACTIVE')`, [customer]);
  for (const who of [gone.userId, roleless.userId, customer, '0190aaaa-0000-7000-8000-000000000000', 'me', 42, {}]) {
    const r = await patch(ref, { assignedTo: who, reason: 'try' }, boss);
    assert.equal(r.status, 400, JSON.stringify(who)); assert.equal(r.body.reason, 'unknown_assignee');
  }
});

test('a request can be linked to a customer that exists, and unlinked; an unknown or malformed customer is refused', async () => {
  const ref = await sup.request();
  const customerId = (await svc.post('/v1/admin/licenses', { reason: 'setup', customer: { name: 'Linked Example Ltd' }, plan: 'team' }, (await staffSignedIn(svc, { role: 'PLATFORM_ADMIN' })).as)).body.customerId;
  assert.equal((await patch(ref, { customerRef: customerId, reason: 'This is Linked Example' })).status, 200);
  assert.equal((await view(ref)).body.customer_ref, customerId);
  assert.equal((await patch(ref, { customerRef: null, reason: 'Wrong customer' })).status, 200);
  assert.equal((await view(ref)).body.customer_ref, null);
  assert.equal((await patch(ref, { customerRef: '0190aaaa-0000-7000-8000-000000000000', reason: 'x' })).status, 404);
  for (const bad of ['x', 5, {}, ['a']]) assert.equal((await patch(ref, { customerRef: bad, reason: 'x' })).body.reason, 'unknown_customer', JSON.stringify(bad));
});

test('what the person submitted cannot be changed through this route, and an empty change is refused', async () => {
  const ref = await sup.request({ subject: 'Original subject', email: 'orig@orig.example.test' });
  const r = await patch(ref, { subject: 'Changed', message: 'Changed', contact_name: 'Changed', email: 'evil@example.test', reference: 'SR-000001', created_at: '2001-01-01', reason: 'sneaky' });
  assert.equal(r.status, 400); assert.equal(r.body.reason, 'nothing_to_change');
  const [row] = await sdb('SELECT subject, email FROM support_request WHERE reference = $1', [ref]);
  assert.deepEqual([row.subject, row.email], ['Original subject', 'orig@orig.example.test']);
  for (const body of [{}, { reason: 'only a reason' }, [], 'text', null]) assert.equal((await patch(ref, body)).status, 400);
});

test('two staff changing one request at once: the history ends where the request is, and nobody gets a 500', async () => {
  const ref = await sup.request();
  const results = await Promise.all([patch(ref, { status: 'IN_PROGRESS', reason: 'A' }, sam), patch(ref, { status: 'IN_PROGRESS', reason: 'B' }, lee), patch(ref, { status: 'CLOSED', reason: 'C' }, sam)]);
  assert.ok(results.every(r => [200, 409].includes(r.status)), results.map(r => r.status).join());
  assert.ok(results.some(r => r.status === 200));
  const h = await sdb(`SELECT h.to_status_code FROM support_request_status_history h JOIN support_request r USING (support_request_id) WHERE r.reference = $1 ORDER BY h.changed_at`, [ref]);
  assert.equal(h[h.length - 1].to_status_code, (await sdb('SELECT status_code FROM support_request WHERE reference = $1', [ref]))[0].status_code);
});

// ── Notes ────────────────────────────────────────────────────────────────────

test('notes are added, never replaced: each carries its author and time; line breaks are kept and control characters removed', async () => {
  const ref = await sup.request();
  const a = await note(ref, { body: 'Left a message\n\n\n\nwill try again\u0000‮' });
  assert.equal(a.status, 201); assert.ok(a.body.noteId && a.body.createdAt);
  await note(ref, { body: 'Pat called back' }, lee);
  const v = (await view(ref)).body;
  assert.deepEqual(v.notes.map(n => [n.body, n.author_name]), [['Left a message\n\nwill try again', 'Sam Support'], ['Pat called back', 'Lee Support']]);
  for (const body of [{}, { body: '' }, { body: '   ' }, { body: 5 }, { body: ['a'] }, { body: 'x'.repeat(4001) }, { text: 'wrong field' }]) {
    const r = await note(ref, body);
    assert.equal(r.status, 400, JSON.stringify(body).slice(0, 30)); assert.equal(r.body.reason, 'bad_note');
  }
  assert.equal((await note(ref, { body: 'x'.repeat(4000) })).status, 201);
  assert.equal((await svc.patch(`/v1/admin/support-requests/${ref}/notes/${a.body.noteId}`, { body: 'edit' }, sam.as)).status, 404, 'there is no route to edit a note');
  assert.equal((await svc.call('DELETE', `/v1/admin/support-requests/${ref}/notes/${a.body.noteId}`, undefined, sam.as)).status, 404, 'or to delete one');
  await assert.rejects(svc.supportDb.query(`UPDATE support_note SET body = 'edited'`), /append-only/);
});

test('a note is audited as a note with its length, and the note text is never copied into the trail', async () => {
  const ref = await sup.request();
  await note(ref, { body: 'A confidential remark about the customer' });
  const t = await trail(ref, 'support_request.note');
  assert.deepEqual(t.map(x => x.outcome), ['started', 'done']);
  assert.deepEqual(t[1].detail, { length: 'A confidential remark about the customer'.length });
  assert.ok(!JSON.stringify(t).includes('confidential remark'));
});

// ── Audit and permissions ────────────────────────────────────────────────────

test('every change leaves a trail (started, then done or failed) with the reason and the actor', async () => {
  const ref = await sup.request();
  await patch(ref, { status: 'IN_PROGRESS', reason: 'Audit me' });
  await patch(ref, { status: 'NEW', reason: 'not allowed' });
  const t = await trail(ref, 'support_request.update');
  assert.deepEqual(t.map(x => x.outcome), ['started', 'done', 'started', 'failed']);
  assert.ok(t.every(x => x.actor_user_id === sam.userId));
  assert.deepEqual(t[1].detail, { from: 'NEW', to: 'IN_PROGRESS' });
  assert.equal(t[3].detail.error, 'invalid_transition');
});

test('if the audit cannot be written, the change is not made, and a read is refused too', async () => {
  const ref = await sup.request();
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    const h = { Authorization: `Bearer ${(await staffSignedIn(svc)).token}` };
    assert.equal((await broken.patch(`/v1/admin/support-requests/${ref}`, { status: 'IN_PROGRESS', reason: 'nope' }, h)).status, 500);
    assert.equal((await broken.post(`/v1/admin/support-requests/${ref}/notes`, { body: 'nope' }, h)).status, 500);
    assert.equal((await sdb('SELECT status_code FROM support_request WHERE reference = $1', [ref]))[0].status_code, 'NEW');
    assert.equal((await sdb(`SELECT count(*)::int AS n FROM support_note n JOIN support_request r USING (support_request_id) WHERE r.reference = $1`, [ref]))[0].n, 0);
    assert.equal((await broken.get(`/v1/admin/support-requests/${ref}`, h)).status, 500, 'a read that cannot be recorded is refused');
    assert.equal((await broken.get('/v1/admin/feedback', h)).status, 500);
  } finally { await broken.close(); }
});

test('reading needs the read permission, answering needs the update permission, feedback needs its own; everything needs a session', async () => {
  const ref = await sup.request();
  const s = await staffSignedIn(svc);
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'SUPPORT_REQUEST_UPDATE'`);
  assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason: 'x' }, s)).status, 403);
  assert.equal((await note(ref, { body: 'x' }, s)).status, 403);
  assert.equal((await view(ref, s)).status, 200, 'it can still read');
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code IN ('SUPPORT_REQUEST_READ', 'FEEDBACK_READ')`);
  assert.equal((await list('', s)).status, 403); assert.equal((await view(ref, s)).status, 403); assert.equal((await feedbackList('', s)).status, 403);
  assert.equal((await sdb('SELECT status_code FROM support_request WHERE reference = $1', [ref]))[0].status_code, 'NEW');
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'SUPPORT_REQUEST_UPDATE'), ('SUPPORT', 'SUPPORT_REQUEST_READ'), ('SUPPORT', 'FEEDBACK_READ')`);
  assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason: 'back' }, s)).status, 200);
  for (const [method, path] of [['get', '/v1/admin/support-requests'], ['get', `/v1/admin/support-requests/${ref}`], ['patch', `/v1/admin/support-requests/${ref}`], ['post', `/v1/admin/support-requests/${ref}/notes`], ['get', '/v1/admin/feedback']]) {
    for (const headers of [{}, { Authorization: 'Bearer nope' }]) assert.equal((await svc[method](path, method === 'get' ? undefined : { reason: 'x', body: 'x' }, headers)).status, 401, `${method} ${path}`);
  }
});

// ── Feedback ─────────────────────────────────────────────────────────────────

test('feedback: newest first with what was said, the category, the rating and the tab; filters by category, rating and whether an address was given', async () => {
  const bug = await sup.feedback({ category: 'bug', message: 'Graph crashes on big repos', rating: 2, screen: 'repos', email: 'fb@fb.example.test' });
  const praise = await sup.feedback({ category: 'praise', message: 'Love the security tab', rating: 5 });
  const r = await feedbackList('?limit=200');
  assert.equal(r.status, 200);
  const refs = r.body.feedback.map(f => f.reference);
  assert.ok(refs.indexOf(praise) < refs.indexOf(bug), 'newest first');
  const row = r.body.feedback.find(f => f.reference === bug);
  assert.deepEqual([row.category_code, row.category, row.rating, row.message, row.screen, row.email], ['bug', 'Something is wrong', 2, 'Graph crashes on big repos', 'repos', 'fb@fb.example.test']);
  assert.ok(!/installation|request_hash|idempotency|feedback_id/.test(JSON.stringify(r.body)));
  assert.ok((await feedbackList('?category=bug&limit=200')).body.feedback.every(f => f.category_code === 'bug'));
  assert.ok((await feedbackList('?category=BUG,praise&limit=200')).body.feedback.some(f => f.reference === praise));
  assert.deepEqual((await feedbackList('?rating=5&limit=200')).body.feedback.every(f => f.rating === 5), true);
  assert.ok((await feedbackList('?withEmail=true&limit=200')).body.feedback.every(f => f.email !== null));
  assert.ok((await feedbackList('?withEmail=false&limit=200')).body.feedback.every(f => f.email === null));
  assert.equal((await feedbackList('?limit=1')).body.feedback.length, 1);
  for (const bad of ['?category=nope', '?category=', '?rating=0', '?rating=6', '?rating=x', '?withEmail=maybe', '?limit=0', '?offset=-1', '?category[]=bug']) {
    const x = await feedbackList(bad);
    assert.equal(x.status, 400, bad); assert.equal(x.body.reason, 'bad_filter');
  }
  const [a] = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE action = 'feedback.list' ORDER BY occurred_at DESC LIMIT 1`);
  assert.equal(a.outcome, 'read'); assert.ok(Number.isInteger(a.detail.returned));
  assert.ok(!JSON.stringify(a).includes('fb.example.test'));
});

test('a database fault is a 5xx and nothing from it is logged', async () => {
  const broken = await startService({ dbs: { identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: { query: async () => { throw Object.assign(new Error('connection refused 10.0.0.9 for secret@acme.example.test'), { code: 'ECONNREFUSED' }); } } } });
  try {
    const h = { Authorization: `Bearer ${(await staffSignedIn(svc)).token}` };
    const r = await broken.get('/v1/admin/support-requests', h);
    assert.equal(r.status, 500); assert.equal(r.body.error, 'internal');
    assert.ok(!JSON.stringify(broken.logs).includes('10.0.0.9') && !JSON.stringify(broken.logs).includes('secret@'));
  } finally { await broken.close(); }
});

test('what people wrote, their names and addresses never appear in a log line', async () => {
  await sup.request({ message: 'A very private sentence about our build server', contactName: 'Zelda Distinct', email: 'logcheck3@acme.example.test' });
  const ref = (await sdb(`SELECT reference FROM support_request WHERE email = 'logcheck3@acme.example.test'`))[0].reference;
  await view(ref); await list(); await feedbackList();
  const text = JSON.stringify(svc.logs);
  assert.ok(svc.logs.length > 10);
  for (const secret of ['private sentence', 'Zelda', 'logcheck3@']) assert.ok(!text.includes(secret), secret);
});

test('only an admin can assign a support request; a user is refused and can still work it', async () => {
  const ref = await sup.request();
  const denied = await patch(ref, { assignedTo: sam.userId, reason: 'taking it' });
  assert.equal(denied.status, 403); assert.equal(denied.body.reason, 'forbidden');
  assert.equal((await sdb('SELECT assigned_to_user_id FROM support_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, null);
  assert.equal((await patch(ref, { status: 'IN_PROGRESS', reason: 'Looking' })).status, 200);
});
