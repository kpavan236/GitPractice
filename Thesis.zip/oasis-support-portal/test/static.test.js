'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { startService } = require('./helpers/server');

const PUBLIC = path.join(__dirname, '..', 'public');
const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));
const modules = walk(path.join(PUBLIC, 'js')).filter(f => f.endsWith('.js'));

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const fetchRaw = (route, init) => fetch(`${svc.base}${route}`, init);

test('the portal page is served at /, with a strict content policy and the other protective headers', async () => {
  const r = await fetchRaw('/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type'), /text\/html/);
  const csp = r.headers.get('content-security-policy');
  for (const directive of ["default-src 'none'", "script-src 'self'", "style-src 'self'", "connect-src 'self'", "frame-ancestors 'none'", "base-uri 'none'", "form-action 'self'"]) assert.ok(csp.includes(directive), directive);
  assert.ok(!/unsafe-inline|unsafe-eval|\*|https?:|data:/.test(csp), 'nothing loosened and nothing allowed from elsewhere');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal(r.headers.get('referrer-policy'), 'no-referrer');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('cross-origin-opener-policy'), 'same-origin');
  assert.match(r.headers.get('permissions-policy'), /camera=\(\)/);
  assert.ok(!r.headers.get('strict-transport-security'), 'HSTS only where the cookie is Secure (https)');
  assert.ok(!r.headers.get('x-powered-by'));
  assert.equal(r.headers.get('cache-control'), 'no-cache');
  const html = await r.text();
  assert.match(html, /<div id="app">/);
});

test('the same headers cover the API, which is never cached', async () => {
  const r = await fetchRaw('/v1/admin/auth/me');
  assert.equal(r.status, 401);
  assert.equal(r.headers.get('cache-control'), 'no-store');
  assert.ok(r.headers.get('content-security-policy').includes("default-src 'none'"));
});

test('when TLS is on the browser is told to use https only', async () => {
  const { createApp } = require('../src/app');
  const app = createApp({ identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb, hashPepper: svc.hashPepper, licenceHashPepper: svc.licenceHashPepper, log: () => {}, tls: true });
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try { const r = await fetch(`http://127.0.0.1:${server.address().port}/`); assert.match(r.headers.get('strict-transport-security'), /max-age=31536000/); }
  finally { await new Promise(r => server.close(r)); }
});

test('the page has no inline script or style, so the content policy never has to be loosened', () => {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script\b[^>]*>/gi)].map(m => m[0]);
  assert.ok(scripts.length >= 1 && scripts.every(s => /\bsrc="/.test(s)), 'every script has a src');
  assert.ok(!/<script\b[^>]*>[^<]+<\/script>/i.test(html), 'no script body');
  assert.ok(!/\bstyle="/i.test(html) && !/<style\b/i.test(html), 'no inline style');
  assert.ok(!/\son[a-z]+="/i.test(html), 'no inline event handler');
  assert.ok(!/https?:\/\//.test(html), 'nothing loaded from another site');
  const css = fs.readFileSync(path.join(PUBLIC, 'css', 'portal.css'), 'utf8');
  assert.ok(!/@import|url\(\s*['"]?https?:/i.test(css), 'the stylesheet loads nothing from elsewhere');
});

test('nothing in the portal\'s JavaScript can turn text into markup or code: no innerHTML, eval, document.write or the like', () => {
  const banned = [/\binnerHTML\b/, /\bouterHTML\b/, /\binsertAdjacentHTML\b/, /\bdocument\.write\b/, /\beval\s*\(/, /\bnew Function\b/, /\bsetTimeout\s*\(\s*['"`]/, /\bsetInterval\s*\(\s*['"`]/, /\bsrcdoc\b/, /javascript:/i, /\bimportScripts\b/, /\.createContextualFragment\b/];
  assert.ok(modules.length >= 15, `found ${modules.length} modules`);
  for (const file of modules) {
    const src = fs.readFileSync(file, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').replace(/\s\/\/ .*$/gm, '');      // what the code does, not what its comments say
    for (const re of banned) assert.ok(!re.test(src), `${path.relative(PUBLIC, file)} uses ${re}`);
    assert.ok(!/localStorage|sessionStorage|document\.cookie/.test(src), `${path.relative(PUBLIC, file)} must not store or read the session (it lives in an HttpOnly cookie)`);
    assert.ok(!/https?:\/\//.test(src), `${path.relative(PUBLIC, file)} calls another site`);
  }
});

test('every browser module is valid JavaScript', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-modules-'));
  try {
    for (const file of modules) {
      const copy = path.join(tmp, `${path.basename(file)}.mjs`);
      fs.copyFileSync(file, copy);
      const r = spawnSync(process.execPath, ['--check', copy], { encoding: 'utf8' });
      assert.equal(r.status, 0, `${path.relative(PUBLIC, file)}: ${r.stderr.split('\n').slice(0, 4).join(' ')}`);
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('every module the page imports exists, and every import resolves to a file that exports that name', () => {
  const exportsOf = file => { const s = fs.readFileSync(file, 'utf8'); return new Set([...s.matchAll(/export\s+(?:async\s+)?(?:function|const|class|let)\s+([A-Za-z0-9_$]+)/g)].map(m => m[1])); };
  for (const file of modules) {
    const src = fs.readFileSync(file, 'utf8');
    for (const m of src.matchAll(/import\s*\{([^}]*)\}\s*from\s*'([^']+)'/g)) {
      const target = path.resolve(path.dirname(file), m[2]);
      assert.ok(fs.existsSync(target), `${path.relative(PUBLIC, file)} imports ${m[2]}, which does not exist`);
      const have = exportsOf(target);
      for (const name of m[1].split(',').map(s => s.trim().split(/\s+as\s+/)[0]).filter(Boolean)) assert.ok(have.has(name), `${path.relative(PUBLIC, file)} imports ${name} from ${m[2]}, which does not export it`);
    }
  }
});

test('the files are served, but nothing outside public/ and no hidden file can be reached', async () => {
  for (const f of ['/js/main.js', '/js/dom.js', '/js/views/team.js', '/css/portal.css', '/favicon.svg']) assert.equal((await fetchRaw(f)).status, 200, f);
  assert.match((await fetchRaw('/js/main.js')).headers.get('content-type'), /javascript/);
  for (const bad of ['/../package.json', '/%2e%2e/package.json', '/..%2fsrc%2fapp.js', '/.env', '/js/../../src/config.js', '/%00', '/js/%2e%2e/%2e%2e/.env']) {
    const r = await fetchRaw(bad);
    assert.ok([400, 404].includes(r.status), `${bad} -> ${r.status}`);
    assert.ok(!(await r.text()).includes('HASH_PEPPER'), bad);
  }
  assert.equal((await fetchRaw('/package.json')).status, 404);
  assert.equal((await fetchRaw('/src/app.js')).status, 404);
});

test('an unknown page or API route answers 404 in the standard shape, never an HTML error page with a stack', async () => {
  const r = await fetchRaw('/v1/nope');
  assert.equal(r.status, 404);
  assert.equal((await r.json()).error, 'not_found');
  assert.equal((await fetchRaw('/nope')).status, 404);
});

test('a mailto: link built from a customer\'s address cannot add a hidden recipient or header', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-dom-'));
  try {
    const copy = path.join(tmp, 'dom.mjs');
    fs.copyFileSync(path.join(PUBLIC, 'js', 'dom.js'), copy);
    const { mailtoHref } = await import(copy);
    assert.equal(mailtoHref('pat@acme.example.test'), 'mailto:pat@acme.example.test');
    assert.equal(mailtoHref('pat@acme.example.test', 'Re: Help [SR-000001]'), 'mailto:pat@acme.example.test?subject=Re%3A%20Help%20%5BSR-000001%5D');
    for (const hostile of ['a?bcc=x@evil.example.test', 'a&bcc=x@evil.example.test', 'a%0d%0abcc=x@evil.example.test', 'a?subject=hi&body=pwned@evil.example.test', 'a#frag@evil.example.test', 'a"@evil.example.test']) {
      const href = mailtoHref(hostile, 'Subject');
      const [beforeQuery, query] = href.split('?');
      assert.equal(query, 'subject=Subject', `${hostile} -> ${href}: the only header is the one we add`);
      assert.ok(!/[?&=#%"\s]/.test(beforeQuery.slice('mailto:'.length).replace(/%[0-9A-F]{2}/g, '')), `${hostile} -> ${beforeQuery}`);
      assert.equal((beforeQuery.match(/@/g) || []).length, 1, 'one recipient');
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('every mailto: link in the portal is built with mailtoHref, never by pasting an address into a string', () => {
  for (const file of modules) {
    const src = fs.readFileSync(file, 'utf8');
    if (file.endsWith('dom.js')) continue;
    assert.ok(!/['"`]mailto:/.test(src), `${path.relative(PUBLIC, file)} builds a mailto: link by hand`);
  }
});

test('path traversal, sent as raw request lines (a client library would tidy these before sending), reaches nothing outside public/', async () => {
  const net = require('node:net');
  const port = new URL(svc.base).port;
  const raw = target => new Promise((resolve, reject) => {
    const sock = net.connect(Number(port), '127.0.0.1', () => sock.write(`GET ${target} HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nConnection: close\r\n\r\n`));
    let data = ''; sock.on('data', d => { data += d; }); sock.on('end', () => resolve(data)); sock.on('error', reject);
  });
  for (const target of ['/../package.json', '/../../etc/passwd', '/js/../../src/config.js', '/%2e%2e/package.json', '/%2e%2e%2fsrc%2fapp.js', '/js/..%2f..%2fsrc%2fconfig.js', '/..%5csrc%5capp.js', '/%252e%252e/package.json', '/js/../../.env', '/....//package.json']) {
    const reply = await raw(target);
    const status = Number(reply.split(' ')[1]);
    assert.ok([301, 400, 403, 404].includes(status), `${target} -> ${status}`);
    assert.ok(!reply.includes('HASH_PEPPER') && !reply.includes('"name": "oasis-support-portal"') && !reply.includes('root:'), target);
  }
});
