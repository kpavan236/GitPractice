'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { staffSignedIn, rows } = require('./helpers/fixtures');
const { toCsv, cell } = require('../src/csv');

let svc, sam, boss;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
});
test.after(async () => { await svc.close(); });

const raw = async (path, who) => { const r = await fetch(`${svc.base}/v1/admin/${path}`, { headers: who ? who.as : {} }); const buf = Buffer.from(await r.arrayBuffer()); return { status: r.status, headers: r.headers, text: buf.toString('utf8'), bom: buf.subarray(0, 3).toString('hex') }; };

test('CSV cells: quoting, and no cell can run as a spreadsheet formula', () => {
  assert.equal(cell('plain'), 'plain');
  assert.equal(cell('a,b'), '"a,b"');
  assert.equal(cell('say "hi"'), '"say ""hi"""');
  assert.equal(cell('two\nlines'), '"two\nlines"');
  for (const bad of ['=HYPERLINK("http://evil.example.test")', '+1+1', '-2+3', '@SUM(A1)', '\tcmd', '\rcmd']) assert.ok(cell(bad).replace(/^"/, '').startsWith("'"), JSON.stringify(bad));
  assert.equal(cell(-5), '-5', 'a real negative number is left alone');
  assert.equal(cell(null), '');
  assert.equal(cell(new Date('2026-10-12T10:00:00Z')), '2026-10-12T10:00:00.000Z');
  assert.equal(toCsv([['a', 'b'], [1, 'x']]), '﻿a,b\r\n1,x\r\n');
});

test('the reports, customer users and audit log download as CSV for admins only; every download is on the record', async () => {
  for (const path of ['reports.csv', 'customer-users.csv', 'audit.csv']) {
    assert.equal((await raw(path)).status, 401, `${path} needs a session`);
    assert.equal((await raw(path, sam)).status, 403, `${path} is for admins`);
    const r = await raw(path, boss);
    assert.equal(r.status, 200, path);
    assert.match(r.headers.get('content-type'), /^text\/csv/);
    assert.match(r.headers.get('content-disposition'), /^attachment; filename="oasis-[a-z-]+-\d{4}-\d{2}-\d{2}\.csv"$/);
    assert.equal(r.headers.get('cache-control'), 'no-store');
    assert.ok(r.text.startsWith('﻿') && r.text.includes('\r\n'));
  }
  const rep = (await raw('reports.csv?weeks=4', boss)).text.split('\r\n');
  assert.equal(rep[0].replace('﻿', ''), 'section,item,value');
  assert.equal(rep.filter(l => l.startsWith('weekly_licence_requests,')).length, 4, 'one row per week');
  assert.equal((await raw('reports.csv?weeks=1', boss)).status, 400);
  assert.equal((await raw('audit.csv?outcome=bogus', boss)).status, 400);
  const logged = await rows(svc.identityDb, `SELECT action FROM admin_audit WHERE outcome = 'read' AND action IN ('report.export', 'customer_users.export', 'audit.export')`);
  assert.deepEqual([...new Set(logged.map(l => l.action))].sort(), ['audit.export', 'customer_users.export', 'report.export']);
});

test('the audit export carries who did what and the reason, honours the filters, and neutralises hostile text', async () => {
  await svc.identityDb.query(`INSERT INTO admin_audit (audit_id, actor_user_id, action, subject_ref, reason, outcome, detail) VALUES (gen_random_uuid(), $1, 'licence.create', 'X1', $2, 'read', '{}')`, [boss.userId, '=cmd|"/c calc"!A1']);
  const all = (await raw('audit.csv', boss)).text;
  assert.ok(all.includes("'=cmd"), 'a reason that starts with = is not a formula');
  assert.ok(all.includes('Bo Admin'));
  const filtered = (await raw('audit.csv?action=licence.create', boss)).text.trim().split('\r\n');
  assert.ok(filtered.length >= 2 && filtered.slice(1).every(l => l.includes('licence.create')));
  assert.equal(filtered[0].replace('﻿', ''), 'when,who,action,subject,outcome,reason,detail,request_id');
});
