'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const PUBLIC = path.join(__dirname, '..', 'public');

/** The browser module, loaded as the browser would (it is plain ES-module JavaScript with no DOM in it). */
async function loadMoney() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-money-'));
  try { const copy = path.join(tmp, 'money.mjs'); fs.copyFileSync(path.join(PUBLIC, 'js', 'money.js'), copy); return await import(copy); }
  finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

test('toMinor reads money exactly: commas and spaces are ignored, two decimals at most, no floating point', async () => {
  const { toMinor } = await loadMoney();
  for (const [text, minor] of [['1234.5', 123450], ['1,234.50', 123450], [' 7 ', 700], ['0.1', 10], ['0.07', 7], ['100000000.00', 10_000_000_000], ['0', 0], ['19.99', 1999], ['1.1', 110]]) assert.equal(toMinor(text), minor, text);
  for (const bad of ['', 'abc', '12.345', '1e3', '-5', '+5', '1.', '.5', '1,2,3.4.5', '100000000.01', '1234567890123', '٣', null, undefined, 5]) assert.equal(toMinor(bad), null, String(bad));
  assert.equal(toMinor('-5.25', { allowNegative: true }), -525);
  assert.equal(toMinor('-100000000.01', { allowNegative: true }), null);
});

test('toInput and fmtMoney show money back; an unknown currency still shows something sensible', async () => {
  const { toInput, fmtMoney } = await loadMoney();
  assert.equal(toInput(123450), '1234.50'); assert.equal(toInput(7), '0.07'); assert.equal(toInput(-525), '-5.25'); assert.equal(toInput(0), '0.00');
  assert.equal(fmtMoney(123450, 'INR'), '₹1,234.50'); assert.equal(fmtMoney(950000, 'INR'), '₹9,500.00'); assert.equal(fmtMoney(-50000, 'INR'), '-₹500.00');
  assert.match(fmtMoney(100, 'USD'), /\$1\.00/);
  assert.equal(fmtMoney(100, '??'), '1.00 ??');
});

test('toQuantity accepts up to three decimals, above zero, up to 10000', async () => {
  const { toQuantity } = await loadMoney();
  for (const [text, q] of [['25', '25'], ['1.5', '1.5'], [' 0.001 ', '0.001'], ['10000', '10000']]) assert.equal(toQuantity(text), q, text);
  for (const bad of ['', '0', '0.0004', '10001', '-1', '1e2', 'x', '1,5']) assert.equal(toQuantity(bad), null, bad);
});

test('lineAmount rounds a half away from zero exactly as the database does, so the preview matches the invoice', async () => {
  const { lineAmount } = await loadMoney();
  assert.equal(lineAmount('1.5', 333), 500); assert.equal(lineAmount('3', 3333), 9999); assert.equal(lineAmount('1.5', -333), -500);
  assert.equal(lineAmount('0.001', 499), 0); assert.equal(lineAmount('0.001', 500), 1); assert.equal(lineAmount('25', 40000), 1_000_000);
  assert.equal(lineAmount('10000', 10_000_000_000), 100_000_000_000_000);
  assert.equal(lineAmount('x', 1), null);
});

test('the new modules are registered: three screens with the right permissions, the nav icons, and no markup is built from text', () => {
  const shell = fs.readFileSync(path.join(PUBLIC, 'js', 'shell.js'), 'utf8');
  assert.match(shell, /path: 'invoices', title: 'Invoices', needs: 'INVOICE_READ'/);
  assert.match(shell, /path: 'follow-ups', title: 'Follow-ups', needs: 'INVOICE_READ'/);
  assert.match(shell, /path: 'billing', title: 'Billing', needs: 'INVOICE_ADMIN'/);
  const icons = fs.readFileSync(path.join(PUBLIC, 'js', 'icons.js'), 'utf8');
  for (const name of ['invoices', "'follow-ups'", 'billing']) assert.ok(icons.includes(name), name);
});

test('the bell asks billing for the follow-ups due, and a billing failure is swallowed so the bell keeps working', () => {
  const shell = fs.readFileSync(path.join(PUBLIC, 'js', 'shell.js'), 'utf8');
  assert.match(shell, /invoice-follow-ups\/summary\?mine=1/);
  assert.match(shell, /followUps/);
  const refresh = shell.slice(shell.indexOf('const refreshBell'), shell.indexOf('function drawPanel'));
  assert.match(refresh, /\.catch\(\(\) => null\)|\.catch\(\(\) => \{\}\)/, 'a failing summary is ignored');
  assert.match(shell, /#\/follow-ups/);
});

test('the follow-ups screen groups by owner and links each invoice', () => {
  const src = fs.readFileSync(path.join(PUBLIC, 'js', 'views', 'follow-ups.js'), 'utf8');
  assert.match(src, /invoice-follow-ups\/queue/);
  assert.match(src, /nameOf\(/);
  assert.match(src, /#\/invoices\//);
  assert.ok(!/Coming in the next task/.test(src), 'the stub is replaced');
});

test('the billing screen links every figure to the matching list and is not a stub', () => {
  const src = fs.readFileSync(path.join(PUBLIC, 'js', 'views', 'billing.js'), 'utf8');
  assert.ok(!/Coming in the next task/.test(src));
  assert.match(src, /billing\/dashboard/);
  for (const key of ['status:', 'bucket:', 'health:', 'ownerId:', 'customerId:', 'closed:', 'overdue:', 'open:']) assert.ok(src.includes(key), `a link filters by ${key}`);
  assert.match(src, /nameOf\(/);
  assert.match(src, /export\.csv/);
});

test('fmtDate shows a plain calendar date as that day in any time zone, and timestamps as before', () => {
  const { spawnSync } = require('node:child_process');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-dom-'));
  try {
    const copy = path.join(tmp, 'dom.mjs'); fs.copyFileSync(path.join(PUBLIC, 'js', 'dom.js'), copy);
    const script = `import(${JSON.stringify(require('node:url').pathToFileURL(copy).href)}).then(m => { const t = new Date(2026, 9, 14, 15, 30); console.log(JSON.stringify([m.fmtDate('2026-10-14'), m.fmtDate('2026-01-01'), m.fmtDate(t), m.fmtDate(t.toISOString()), m.fmtDateTime(t), m.fmtDate(''), m.fmtDate('nope')])); });`;
    for (const tz of ['America/Los_Angeles', 'Pacific/Auckland', 'UTC']) {
      const r = spawnSync(process.execPath, ['-e', script], { env: { ...process.env, TZ: tz }, encoding: 'utf8' });
      assert.equal(r.status, 0, r.stderr);
      assert.deepEqual(JSON.parse(r.stdout), ['14 Oct 2026', '1 Jan 2026', '14 Oct 2026', '14 Oct 2026', '14 Oct 2026, 15:30', '—', '—'], tz);
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});
