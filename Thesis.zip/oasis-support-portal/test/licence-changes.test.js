'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { startLicenceService } = require('./helpers/licence-service');
const { scenarios } = require('./helpers/scenarios');
const { staffSignedIn, rows } = require('./helpers/fixtures');

let svc, ls, sam, boss, act, licence, seat, activeLicence;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  ls = await startLicenceService(svc);
  ({ act, licence, seat, activeLicence } = scenarios(svc, ls, boss));
});
test.after(async () => { await ls.close(); await svc.close(); });

const q = (sql, params) => rows(svc.licenseDb, sql, params);
const change = (l, body, who = boss) => act(`licenses/${l.licenseId}/change`, body, who);
const detail = l => svc.get(`/v1/admin/licenses/${l.licenseId}`, boss.as);
const trail = (action, id) => rows(svc.identityDb, `SELECT outcome, detail, reason FROM admin_audit WHERE action = $1 AND subject_ref = $2 ORDER BY occurred_at`, [action, id]);

test('an admin changes the seats up and down; never below the seats in use; users cannot; it is audited with from and to', async () => {
  const l = await activeLicence({ plan: 'team', seats: 5 });
  assert.equal((await change(l, { seats: 10 }, sam)).status, 403, 'a user may not');
  const up = await change(l, { seats: 10 });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  assert.deepEqual([up.body.before.seats, up.body.after.seats], [5, 10]);
  assert.equal((await detail(l)).body.seat_limit, 10);
  await seat(l); await seat(l);
  const tooLow = await change(l, { seats: 2 });
  assert.equal(tooLow.status, 409);
  assert.equal(tooLow.body.reason, 'seats_in_use');
  assert.match(tooLow.body.message, /3 seats are in use/);
  assert.equal((await change(l, { seats: 3 })).status, 200, 'exactly the seats in use is fine');
  const t = await trail('licence.change', l.licenseId);
  assert.deepEqual(t.map(x => x.outcome), ['started', 'done', 'started', 'failed', 'started', 'done']);
  assert.deepEqual([t[1].detail.fromSeats, t[1].detail.toSeats], [5, 10]);
});

test('seats are validated: whole numbers only; unlimited only for an enterprise licence; nothing to change is refused; unknown licences are 404', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  for (const [body, reason] of [[{}, 'nothing_to_change'], [{ seats: 5 }, 'nothing_to_change'], [{ seats: 0 }, 'bad_seats'], [{ seats: 1.5 }, 'bad_seats'], [{ seats: '7' }, 'bad_seats'], [{ seats: 100001 }, 'bad_seats'], [{ seats: null }, 'bad_seats'], [{ plan: 'no-such-plan' }, 'bad_plan'], [{ plan: 'trial' }, 'bad_plan'], [{ plan: 5 }, 'bad_plan']]) {
    const r = await change(l, body);
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.body.reason, reason, JSON.stringify(body));
  }
  assert.equal((await act('licenses/00000000-0000-0000-0000-000000000000/change', { seats: 9 })).status, 404);
  assert.equal((await svc.post(`/v1/admin/licenses/${l.licenseId}/change`, { seats: 9 }, boss.as)).status, 400, 'and a reason is needed');
});

test('changing the plan swaps the features the old plan included, keeps a feature set by hand, and leaves the key and customer alone', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  const before = (await q(`SELECT feature_code FROM entitlement WHERE license_id = $1 AND effective_until IS NULL ORDER BY 1`, [l.licenseId])).map(r => r.feature_code);
  assert.ok(before.length > 0);
  const plans = (await q(`SELECT plan_code FROM plan WHERE is_active AND plan_code NOT IN ('trial', 'team') ORDER BY default_seat_limit NULLS LAST`)).map(r => r.plan_code);
  assert.ok(plans.length > 0);
  const target = plans[0];
  const keyBefore = (await q('SELECT license_key_hash, customer_id FROM license WHERE license_id = $1', [l.licenseId]))[0];
  const r = await change(l, { plan: target });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.after.plan, target);
  const [lic] = await q('SELECT plan_code, license_key_hash, customer_id FROM license WHERE license_id = $1', [l.licenseId]);
  assert.deepEqual([lic.plan_code, lic.license_key_hash, lic.customer_id], [target, keyBefore.license_key_hash, keyBefore.customer_id]);
  const wanted = (await q(`SELECT feature_code FROM plan_feature_default WHERE plan_code = $1 AND enabled ORDER BY 1`, [target])).map(x => x.feature_code);
  const now = (await q(`SELECT feature_code FROM entitlement WHERE license_id = $1 AND effective_until IS NULL AND enabled ORDER BY 1`, [l.licenseId])).map(x => x.feature_code);
  assert.deepEqual(now, wanted, 'the open features are the new plan\'s');
  const closed = await q(`SELECT count(*)::int AS n FROM entitlement WHERE license_id = $1 AND effective_until IS NOT NULL`, [l.licenseId]);
  assert.ok(closed[0].n > 0, 'the old plan\'s features were closed, not deleted (the history stays)');

  const feature = wanted[0];
  await svc.licenseDb.query(`UPDATE entitlement SET effective_until = now() WHERE license_id = $1 AND feature_code = $2 AND effective_until IS NULL`, [l.licenseId, feature]);
  await svc.licenseDb.query(`INSERT INTO entitlement (entitlement_id, license_id, feature_code, enabled, limit_value, reason, effective_from) SELECT gen_random_uuid(), $1, feature_code, enabled, limit_value, 'Granted by hand for a pilot', now() FROM plan_feature_default WHERE plan_code = $2 AND feature_code = $3`, [l.licenseId, target, feature]);
  const back = await change(l, { plan: 'team' });
  assert.equal(back.status, 200, JSON.stringify(back.body));
  const kept = await q(`SELECT reason FROM entitlement WHERE license_id = $1 AND feature_code = $2 AND effective_until IS NULL`, [l.licenseId, feature]);
  assert.ok(kept.length <= 1, 'one open version at a time');
  if (kept.length) assert.equal(kept[0].reason, 'Granted by hand for a pilot', 'a feature set by hand is left as it was');
});

test('a cancelled licence cannot be changed', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  const hint = l.licenceKey.slice(-4);
  assert.equal((await act(`licenses/${l.licenseId}/cancel`, { confirm: hint, reason: 'Customer left' })).status, 200);
  const r = await change(l, { seats: 8 });
  assert.equal(r.status, 409);
  assert.equal(r.body.reason, 'invalid_transition');
});

test('releasing one seat frees it for another machine; the seat list never shows a machine id; users cannot; unknown and already-released seats are 404', async () => {
  const l = await activeLicence({ plan: 'team', seats: 2 });
  await seat(l);
  const d = (await detail(l)).body;
  assert.equal(d.seats.length, 2);
  assert.deepEqual(Object.keys(d.seats[0]).sort(), ['activated_at', 'activation_id', 'app_version', 'last_seen_at', 'platform']);
  assert.ok(!/machine|fingerprint/i.test(JSON.stringify(d.seats)), 'no machine id');
  const full = await ls.post('/v1/activate', { machineId: 'f'.repeat(32), licenseKey: l.licenceKey, appVersion: '2.0.1' });
  assert.equal(full.status === 200, false, 'the licence is full');

  const release = (id, who = boss) => act(`licenses/${l.licenseId}/seats/${id}/release`, { reason: 'Laptop lost' }, who);
  assert.equal((await release(d.seats[0].activation_id, sam)).status, 403);
  const r = await release(d.seats[0].activation_id);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.seatsInUse, 1);
  assert.equal((await release(d.seats[0].activation_id)).status, 404, 'a seat is released once');
  assert.equal((await release('00000000-0000-0000-0000-000000000000')).status, 404);
  assert.equal((await release('not-an-id')).status, 404);
  const [a] = await q('SELECT release_reason_code FROM activation WHERE activation_id = $1', [d.seats[0].activation_id]);
  assert.equal(a.release_reason_code, 'support');
  const again = await ls.post('/v1/activate', { machineId: 'e'.repeat(32), licenseKey: l.licenceKey, appVersion: '2.0.1' });
  assert.equal(again.status, 200, 'room for another machine now');
  const t = await trail('licence.release_seat', l.licenseId);
  assert.ok(t.some(x => x.outcome === 'done' && x.detail.seatsInUse === 1));
});
