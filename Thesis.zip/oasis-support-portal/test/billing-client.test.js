'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createBillingClient } = require('../src/billing-client');
const { startBillingService } = require('./helpers/billing-service');
const { uuidv7 } = require('../src/uuid');

const ACTOR = { userId: uuidv7(), role: 'user' };
const ADMIN = { ...ACTOR, role: 'admin' };

/** A stand-in billing server that answers whatever the test says, and remembers what it was asked. */
async function fake(handler) {
  const seen = [];
  const server = http.createServer((req, res) => {
    let body = ''; req.on('data', c => { body += c; });
    req.on('end', () => { seen.push({ method: req.method, url: req.url, headers: req.headers, body }); handler(req, res, body); });
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  return { seen, url: `http://127.0.0.1:${server.address().port}`, close: () => new Promise(r => { server.closeAllConnections(); server.close(r); }) };
}
const json = (res, status, body, headers = {}) => { res.writeHead(status, { 'content-type': 'application/json', ...headers }); res.end(JSON.stringify(body)); };
const KEY = 'k'.repeat(40);

test('every call carries the key, the acting person and role, and the idempotency key; the path is the staff API', async () => {
  const f = await fake((_req, res) => json(res, 201, { invoice: { invoiceId: 'x' } }));
  try {
    const c = createBillingClient({ baseUrl: f.url, serviceKey: KEY });
    const r = await c.createInvoice(ADMIN, { customerId: 'c' }, 'create-key-0001');
    assert.equal(r.status, 201);
    const s = f.seen[0];
    assert.equal(s.method, 'POST'); assert.equal(s.url, '/v1/staff/invoices');
    assert.equal(s.headers['x-service-key'], KEY); assert.equal(s.headers['x-acting-user'], ADMIN.userId); assert.equal(s.headers['x-acting-role'], 'admin');
    assert.equal(s.headers['idempotency-key'], 'create-key-0001');
    assert.deepEqual(JSON.parse(s.body), { customerId: 'c' });
    await c.listInvoices(ACTOR, { status: 'SENT', ownerId: undefined, bucket: '61+' });
    assert.equal(f.seen[1].url, '/v1/staff/invoices?status=SENT&bucket=61%2B');                // empty values are left out; "+" is encoded
    assert.equal(f.seen[1].headers['idempotency-key'], undefined);
  } finally { await f.close(); }
});

test('a replayed answer is flagged; ids in paths are encoded', async () => {
  const f = await fake((_req, res) => json(res, 201, {}, { 'idempotent-replayed': 'true' }));
  try {
    const c = createBillingClient({ baseUrl: f.url, serviceKey: KEY });
    assert.equal((await c.recordPayment(ACTOR, 'a/b', {}, 'pay-key-0001')).replayed, true);
    assert.equal(f.seen[0].url, '/v1/staff/invoices/a%2Fb/payments');
  } finally { await f.close(); }
});

test('billing 4xx refusals come through as they are, with their reason and extra fields', async () => {
  const f = await fake((_req, res) => json(res, 409, { error: 'rejected', message: 'That is more than the amount still owed.', reason: 'payment_exceeds_balance', balanceMinor: 4000, requestId: 'r1' }));
  try {
    const c = createBillingClient({ baseUrl: f.url, serviceKey: KEY });
    await assert.rejects(c.recordPayment(ACTOR, 'i', {}), e => e.status === 409 && e.reason === 'payment_exceeds_balance' && e.extra.balanceMinor === 4000 && e.message === 'That is more than the amount still owed.');
  } finally { await f.close(); }
});

test('billing 401 or bad_actor is OUR misconfiguration: a 502, never a 401 (which would sign the person out)', async () => {
  for (const [status, reason] of [[401, 'service_key_required'], [400, 'bad_actor']]) {
    const f = await fake((_req, res) => json(res, status, { error: 'rejected', message: 'x', reason }));
    try {
      await assert.rejects(createBillingClient({ baseUrl: f.url, serviceKey: KEY }).whoami(ACTOR), e => e.status === 502 && e.reason === 'billing_misconfigured');
    } finally { await f.close(); }
  }
});

test('a 500, an HTML error page, a dropped connection and a timeout are all 502 billing_unavailable, without the cause', async () => {
  const logs = [];
  const f500 = await fake((_req, res) => json(res, 500, { error: 'internal', message: 'secret internals' }));
  const fHtml = await fake((_req, res) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end('<html>oops</html>'); });
  const fDrop = await fake((req) => req.socket.destroy());
  const fSlow = await fake(() => {});
  try {
    for (const [f, ms] of [[f500, 2000], [fHtml, 2000], [fDrop, 2000], [fSlow, 300]]) {
      const c = createBillingClient({ baseUrl: f.url, serviceKey: KEY, timeoutMs: ms, log: l => logs.push(l) });
      const started = Date.now();
      await assert.rejects(c.getInvoice(ACTOR, 'i'), e => e.status === 502 && e.reason === 'billing_unavailable' && !/secret|oops/.test(e.message));
      assert.ok(Date.now() - started < 3000, 'fails fast');
    }
    assert.ok(!JSON.stringify(logs).includes(KEY));
  } finally { await Promise.all([f500, fHtml, fDrop, fSlow].map(f => f.close())); }
});

test('billing that is not running at all is 502 billing_unavailable', async () => {
  const f = await fake(() => {}); const url = f.url; await f.close();
  await assert.rejects(createBillingClient({ baseUrl: url, serviceKey: KEY }).whoami(ACTOR), e => e.status === 502 && e.reason === 'billing_unavailable');
});

test('against the real billing service: whoami, settings, a refusal and a wrong key', async () => {
  const b = await startBillingService();
  try {
    const c = createBillingClient({ baseUrl: b.url, serviceKey: b.key });
    assert.deepEqual((await c.whoami(ADMIN)).body, { userId: ADMIN.userId, role: 'admin' });
    assert.deepEqual((await c.settings(ACTOR)).body, { currency: 'INR', shareLinkDefaultDays: 14 });
    await assert.rejects(c.getInvoice(ACTOR, '00000000-0000-7000-8000-00000000dead'), e => e.status === 404 && e.reason === 'not_found');
    await assert.rejects(c.dashboard(ACTOR), e => e.status === 403 && e.reason === 'forbidden');
    await assert.rejects(createBillingClient({ baseUrl: b.url, serviceKey: 'x'.repeat(40) }).whoami(ACTOR), e => e.status === 502 && e.reason === 'billing_misconfigured');
  } finally { await b.close(); }
});

test('the client is a fixed list of methods: there is no generic call that forwards an arbitrary path', () => {
  const c = createBillingClient({ baseUrl: 'http://127.0.0.1:1', serviceKey: KEY });
  assert.deepEqual(Object.keys(c).sort(), ['cancelDraft', 'changeOwner', 'createInvoice', 'createLink', 'creditNote', 'dashboard', 'exportRows', 'followUpQueue', 'followUpSummary', 'getInvoice', 'issue',
    'listInvoices', 'logFollowUp', 'markSent', 'recordPayment', 'revokeLink', 'settings', 'updateDraft', 'voidInvoice', 'voidPayment', 'whoami']);
});
