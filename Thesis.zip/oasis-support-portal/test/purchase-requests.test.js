'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { staffSignedIn, createRequest, rows } = require('./helpers/fixtures');

let svc, sam, lee, boss;
test.before(async () => { svc = await startService(); sam = await staffSignedIn(svc, { name: 'Sam Support' }); lee = await staffSignedIn(svc, { name: 'Lee Support' }); boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' }); });
test.after(async () => { await svc.close(); });

const list = (query = '', who = sam) => svc.get(`/v1/admin/purchase-requests${query}`, who.as);
const patch = (ref, body, who = sam) => svc.patch(`/v1/admin/purchase-requests/${ref}`, body, who.as);

test('the list shows requests, open ones first and oldest first, with the fields support needs and nothing secret', async () => {
  const closed = await createRequest(svc, { status: 'DECLINED' });
  const a = await createRequest(svc, { organization: 'First Example Ltd', email: 'first@first.example.test' });
  const b = await createRequest(svc, { organization: 'Second Example Ltd' });
  const r = await list();
  assert.equal(r.status, 200);
  const refs = r.body.purchaseRequests.map(p => p.reference);
  assert.ok(refs.indexOf(a) < refs.indexOf(b), 'oldest open first');
  assert.ok(refs.indexOf(b) < refs.indexOf(closed), 'closed ones after');
  const row = r.body.purchaseRequests.find(p => p.reference === a);
  assert.deepEqual(Object.keys(row).sort(), ['app_version', 'assigned_to_name', 'assigned_to_user_id', 'contact_name', 'created_at', 'customer_id', 'email', 'email_domain', 'employee_count', 'hours_open_or_to_close', 'is_closed', 'organization_name', 'reference', 'size_band', 'source_code', 'status', 'status_changed_at', 'status_code']);
  assert.equal(row.email, 'first@first.example.test');
  assert.equal(row.email_domain, 'first.example.test');
  assert.equal(row.size_band, '51 to 200 people');
  assert.equal(r.body.limit, 50);
});

test('filters: by status (one or several), by assignee (me, none, an id), with limit and offset; bad filters are refused', async () => {
  const x = await createRequest(svc, { status: 'CONTACTED' });
  await patch(x, { assignedTo: sam.userId, reason: 'mine' }, boss);
  const contacted = (await list('?status=contacted')).body.purchaseRequests;
  assert.ok(contacted.length >= 1 && contacted.every(p => p.status === 'Support has been in touch'));
  assert.ok((await list('?status=NEW,CONTACTED')).body.purchaseRequests.length >= contacted.length);
  assert.ok((await list('?assignedTo=me')).body.purchaseRequests.some(p => p.reference === x));
  assert.ok(!(await list('?assignedTo=me', lee)).body.purchaseRequests.some(p => p.reference === x));
  assert.ok((await list('?assignedTo=none')).body.purchaseRequests.every(p => p.assigned_to_user_id === null));
  assert.ok((await list(`?assignedTo=${sam.userId}`)).body.purchaseRequests.some(p => p.reference === x));
  assert.equal((await list('?limit=1')).body.purchaseRequests.length, 1);
  assert.notEqual((await list('?limit=1&offset=1')).body.purchaseRequests[0].reference, (await list('?limit=1')).body.purchaseRequests[0].reference);
  for (const q of ['?status=BOGUS', '?status=', '?assignedTo=someone', '?limit=0', '?limit=201', '?limit=abc', '?offset=-1', '?status=NEW&status=NEW', '?assignedTo[]=x']) {
    const r = await list(q);
    assert.equal(r.status, 400, q);
    assert.equal(r.body.reason, 'bad_filter');
  }
});

test('reading the list is itself recorded (it is personal data), with the filter and how many rows, but no addresses', async () => {
  await list('?status=NEW');
  const [a] = await rows(svc.identityDb, `SELECT * FROM admin_audit WHERE actor_user_id = $1 AND action = 'purchase_request.list' ORDER BY occurred_at DESC LIMIT 1`, [sam.userId]);
  assert.equal(a.outcome, 'read');
  assert.equal(a.detail.status, 'NEW');
  assert.ok(Number.isInteger(a.detail.returned));
  assert.ok(!JSON.stringify(a).includes('example.test'));
});

test('a status move needs a reason, follows the allowed moves, and is recorded with who and why', async () => {
  const ref = await createRequest(svc);
  const noReason = await patch(ref, { status: 'CONTACTED' });
  assert.equal(noReason.status, 400); assert.equal(noReason.body.reason, 'reason_required');
  for (const reason of ['', '   ', 5, 'x'.repeat(501)]) assert.equal((await patch(ref, { status: 'CONTACTED', reason })).status, 400);

  const r = await patch(ref, { status: 'contacted', reason: 'Emailed Pat on 9 Oct' });
  assert.equal(r.status, 200);
  assert.equal(r.body.reference, ref);
  const [row] = await rows(svc.customerDb, `SELECT status_code FROM purchase_request WHERE reference = $1`, [ref]);
  assert.equal(row.status_code, 'CONTACTED');
  const history = await rows(svc.customerDb, `SELECT h.to_status_code, h.reason, h.changed_by_user_id FROM purchase_request_status_history h JOIN purchase_request p USING (purchase_request_id) WHERE p.reference = $1 ORDER BY h.changed_at`, [ref]);
  assert.deepEqual(history.map(h => [h.to_status_code, h.reason]), [['NEW', 'Submitted'], ['CONTACTED', 'Emailed Pat on 9 Oct']]);
  assert.equal(history[1].changed_by_user_id, sam.userId);

  const bad = await patch(ref, { status: 'NEW', reason: 'back again' });
  assert.equal(bad.status, 409); assert.equal(bad.body.reason, 'invalid_transition');
  assert.equal((await patch(ref, { status: 'WIBBLE', reason: 'nonsense' })).status, 400);
  assert.equal((await patch(ref, { status: 'AGREED', reason: 'Pat confirmed 120 seats' })).status, 200);
  assert.equal((await patch(ref, { status: 'DECLINED', reason: 'closed already' })).status, 409, 'an agreed request is final');
});

test('notes are added, never replaced, and carry who wrote them and when', async () => {
  const ref = await createRequest(svc);
  assert.equal((await patch(ref, { note: 'Left a message', reason: 'First attempt' })).status, 200);
  assert.equal((await patch(ref, { note: 'Pat called back', reason: 'Second attempt' }, lee)).status, 200);
  const [row] = await rows(svc.customerDb, 'SELECT support_notes FROM purchase_request WHERE reference = $1', [ref]);
  const lines = row.support_notes.split('\n');
  assert.equal(lines.length, 2);
  assert.match(lines[0], /^\d{4}-\d{2}-\d{2} Sam Support: Left a message$/);
  assert.match(lines[1], /^\d{4}-\d{2}-\d{2} Lee Support: Pat called back$/);
  for (const note of ['', '   ', 5, 'x'.repeat(1001)]) assert.equal((await patch(ref, { note, reason: 'bad note' })).status, 400, JSON.stringify(note).slice(0, 20));
  const many = await createRequest(svc);
  let last;
  for (let i = 0; i < 6; i++) last = await patch(many, { note: 'n'.repeat(900), reason: 'fill it' });
  assert.equal(last.body.reason, 'notes_full', 'notes stop at the 4,000 the schema allows, with a clear message');
});

test('a note with line breaks or control characters cannot forge a second note', async () => {
  const ref = await createRequest(svc);
  await patch(ref, { note: 'ok\n2026-01-01 Lee Support: approved the discount\u0000', reason: 'forgery try' });
  const [row] = await rows(svc.customerDb, 'SELECT support_notes FROM purchase_request WHERE reference = $1', [ref]);
  assert.equal(row.support_notes.split('\n').length, 1);
  assert.ok(!row.support_notes.includes('\u0000'));
});

test('assigning: to an active staff member or to nobody; a stranger, a customer user and a disabled member are refused', async () => {
  const ref = await createRequest(svc);
  assert.equal((await patch(ref, { assignedTo: lee.userId, reason: 'Lee has the account' }, boss)).status, 200);
  assert.equal((await rows(svc.customerDb, 'SELECT assigned_to_user_id FROM purchase_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, lee.userId);
  assert.equal((await patch(ref, { assignedTo: null, reason: 'unassign' }, boss)).status, 200);
  assert.equal((await rows(svc.customerDb, 'SELECT assigned_to_user_id FROM purchase_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, null);

  const gone = await staffSignedIn(svc);
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'left', true)) UPDATE app_user SET status_code = 'DISABLED' FROM r WHERE user_id = $1`, [gone.userId]);
  const customerUser = (await rows(svc.identityDb, `SELECT gen_random_uuid() AS id`))[0].id;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, status_code) VALUES ($1, gen_random_uuid(), 'customer', 'c@example.test', 'ACTIVE')`, [customerUser]);
  const roleless = await staffSignedIn(svc);
  await svc.identityDb.query('UPDATE user_role SET revoked_at = now() WHERE user_id = $1', [roleless.userId]);
  for (const who of [gone.userId, roleless.userId, customerUser, '0190aaaa-0000-7000-8000-000000000000', 'me', 42, {}]) {
    const r = await patch(ref, { assignedTo: who, reason: 'try' }, boss);
    assert.equal(r.status, 400, JSON.stringify(who));
    assert.equal(r.body.reason, 'unknown_assignee');
  }
});

test('the details the customer submitted cannot be edited through this route, and unknown fields are ignored', async () => {
  const ref = await createRequest(svc, { organization: 'Original Ltd' });
  const r = await patch(ref, { organization_name: 'Changed Ltd', organization: 'Changed Ltd', email: 'evil@example.test', employee_count: 1, customer_id: '0190aaaa-0000-7000-8000-000000000000', status_code: 'AGREED', reason: 'sneaky' });
  assert.equal(r.status, 400); assert.equal(r.body.reason, 'nothing_to_change');
  const [row] = await rows(svc.customerDb, 'SELECT organization_name, status_code, customer_id FROM purchase_request WHERE reference = $1', [ref]);
  assert.deepEqual([row.organization_name, row.status_code, row.customer_id], ['Original Ltd', 'NEW', null]);
});

test('unknown or malformed references are 404, and an empty body is refused', async () => {
  for (const ref of ['PR-999999', 'PR-1', 'pr-000001', "PR-000001'--", '..%2f..']) assert.equal((await svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'x' }, sam.as)).status, 404, ref);
  const ref = await createRequest(svc);
  for (const body of [{}, { reason: 'only a reason' }, [], 'text', null]) assert.ok([400].includes((await patch(ref, body)).status));
});

test('two staff changing one request at once: one move wins, the other gets a clear 409, never a 500', async () => {
  const ref = await createRequest(svc);
  const results = await Promise.all([patch(ref, { status: 'CONTACTED', reason: 'A' }, sam), patch(ref, { status: 'CONTACTED', reason: 'B' }, lee), patch(ref, { status: 'DECLINED', reason: 'C' }, sam)]);
  assert.ok(results.every(r => [200, 409].includes(r.status)), results.map(r => r.status).join());
  assert.ok(results.some(r => r.status === 200));
  const hist = await rows(svc.customerDb, `SELECT h.to_status_code FROM purchase_request_status_history h JOIN purchase_request p USING (purchase_request_id) WHERE p.reference = $1 ORDER BY h.changed_at`, [ref]);
  const [now] = await rows(svc.customerDb, 'SELECT status_code FROM purchase_request WHERE reference = $1', [ref]);
  assert.equal(hist[hist.length - 1].to_status_code, now.status_code, 'the history ends where the request is');
  assert.ok(['CONTACTED', 'DECLINED'].includes(now.status_code));
  for (let i = 1; i < hist.length; i++) assert.ok(!(hist[i - 1].to_status_code === 'DECLINED'), 'nothing moved after DECLINED');
});

test('each change leaves an audit trail: started then done, with the reason, the actor and the request id', async () => {
  const ref = await createRequest(svc);
  const r = await patch(ref, { status: 'CONTACTED', reason: 'Audit me' });
  const trail = await rows(svc.identityDb, `SELECT * FROM admin_audit WHERE subject_ref = $1 ORDER BY occurred_at`, [ref]);
  assert.deepEqual(trail.map(t => t.outcome), ['started', 'done']);
  assert.ok(trail.every(t => t.actor_user_id === sam.userId && t.reason === 'Audit me' && t.action === 'purchase_request.update'));
  assert.equal(trail[1].started_audit_id, trail[0].audit_id);
  assert.equal(trail[1].request_id, r.headers.get('x-request-id'));
  assert.deepEqual(trail[1].detail, { from: 'NEW', to: 'CONTACTED' });
  await assert.rejects(svc.identityDb.query('DELETE FROM admin_audit'), /append-only/);
  await assert.rejects(svc.identityDb.query(`UPDATE admin_audit SET reason = 'edited'`), /append-only/);

  const refused = await createRequest(svc);
  await patch(refused, { status: 'AGREED', reason: 'skipping a step' });
  const t2 = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE subject_ref = $1 ORDER BY occurred_at`, [refused]);
  assert.deepEqual(t2.map(t => t.outcome), ['started', 'failed']);
  assert.equal(t2[1].detail.error, 'invalid_transition');
});

test('the request id in the audit trail is ours: a caller cannot choose it', async () => {
  const ref = await createRequest(svc);
  const r = await patch(ref, { status: 'CONTACTED', reason: 'id test' }, { ...sam, as: { ...sam.as, 'X-Request-Id': 'chosen-by-the-caller-1234' } });
  const [t] = await rows(svc.identityDb, `SELECT request_id FROM admin_audit WHERE subject_ref = $1 AND outcome = 'done'`, [ref]);
  assert.notEqual(t.request_id, 'chosen-by-the-caller-1234');
  assert.equal(t.request_id, r.headers.get('x-request-id'));
});

test('if only the closing audit row fails, the change stands, the caller gets its answer, and the fault is logged', async () => {
  const ref = await createRequest(svc);
  const flaky = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) && params[5] === 'done' ? Promise.reject(Object.assign(new Error('boom'), { code: '57P01' })) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    const r = await flaky.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'closing row will fail' }, sam.as);
    assert.equal(r.status, 200);
    assert.equal((await rows(svc.customerDb, 'SELECT status_code FROM purchase_request WHERE reference = $1', [ref]))[0].status_code, 'CONTACTED');
    assert.deepEqual((await rows(svc.identityDb, `SELECT outcome FROM admin_audit WHERE subject_ref = $1`, [ref])).map(t => t.outcome), ['started'], 'a started row with no end: exactly the sign to look at');
    assert.ok(flaky.logs.some(l => l.msg === 'audit end row not written' && l.error === '57P01'));
  } finally { await flaky.close(); }
});

test('if the audit cannot be written, the change is not made (it fails closed)', async () => {
  const ref = await createRequest(svc);
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    const token = (await staffSignedIn(svc)).token;
    const r = await broken.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'should not happen' }, { Authorization: `Bearer ${token}` });
    assert.equal(r.status, 500);
    assert.equal((await rows(svc.customerDb, 'SELECT status_code FROM purchase_request WHERE reference = $1', [ref]))[0].status_code, 'NEW');
    assert.equal((await broken.get('/v1/admin/purchase-requests', { Authorization: `Bearer ${token}` })).status, 500, 'and a read that cannot be recorded is refused too');
  } finally { await broken.close(); }
});

test('a role without the permission is refused with 403: permissions are data, not code', async () => {
  const reader = await staffSignedIn(svc, { role: 'SUPPORT' });
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'CUSTOMER_UPDATE'`);
  const ref = await createRequest(svc);
  const r = await svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'x' }, reader.as);
  assert.equal(r.status, 403); assert.equal(r.body.reason, 'forbidden');
  assert.equal((await svc.get('/v1/admin/purchase-requests', reader.as)).status, 200, 'it can still read');
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'CUSTOMER_UPDATE')`);
  assert.equal((await svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'x' }, reader.as)).status, 200);
});

test('only an admin can assign a request: a user who tries is refused (403) and nothing changes; a user can still work it', async () => {
  const ref = await createRequest(svc);
  const denied = await patch(ref, { assignedTo: sam.userId, reason: 'taking it' });
  assert.equal(denied.status, 403); assert.equal(denied.body.reason, 'forbidden');
  assert.equal((await rows(svc.customerDb, 'SELECT assigned_to_user_id FROM purchase_request WHERE reference = $1', [ref]))[0].assigned_to_user_id, null);
  assert.equal((await patch(ref, { status: 'CONTACTED', note: 'Called Pat', reason: 'Spoke to Pat' })).status, 200, 'a user can work any request: notes and status');
  assert.equal((await patch(ref, { assignedTo: lee.userId, reason: 'Lee has it' }, boss)).status, 200);
  assert.equal((await patch(ref, { status: 'AGREED', reason: 'Agreed on the call' }, sam)).status, 200, 'and still works a request that is assigned to someone else');
  assert.equal((await list('?assignedTo=none')).body.purchaseRequests.some(p => p.reference === ref), false);
  assert.equal((await list(`?assignedTo=${lee.userId}`)).body.purchaseRequests.find(p => p.reference === ref).assigned_to_name, 'Lee Support');
});

test('one request in full: what was asked, who has it, every status it has had with names and reasons, the customer it became and its licences; the read is audited', async () => {
  const ref = await createRequest(svc, { organization: 'Detail Example Ltd', employees: 80, email: 'detail@detail.example.test', status: 'CONTACTED' });
  await patch(ref, { assignedTo: lee.userId, reason: 'Lee has it' }, boss);
  await patch(ref, { status: 'AGREED', note: 'Agreed 25 seats', reason: 'Pat agreed on the call' }, lee);
  const created = await svc.post('/v1/admin/licenses', { reason: 'Agreed', purchaseRequest: ref, plan: 'team', seats: 25 }, sam.as);
  assert.equal(created.status, 201, JSON.stringify(created.body));
  const r = await svc.get(`/v1/admin/purchase-requests/${ref}`, sam.as);
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.organization_name, r.body.employee_count, r.body.email, r.body.status_code, r.body.assigned_to_name, r.body.size_band], ['Detail Example Ltd', 80, 'detail@detail.example.test', 'AGREED', 'Lee Support', '51 to 200 people']);
  assert.match(r.body.support_notes, /Lee Support: Agreed 25 seats/);
  assert.deepEqual(r.body.customer, { id: created.body.customerId, name: 'Detail Example Ltd' });
  assert.deepEqual(r.body.licences.map(l => [l.license_id, l.plan_code, l.seat_limit]), [[created.body.licenseId, 'team', 25]]);
  assert.deepEqual(r.body.history.map(h => [h.from_status_code, h.to_status_code, h.reason, h.changed_by_name]), [[null, 'NEW', 'Submitted', null], ['NEW', 'CONTACTED', 'test setup', null], ['CONTACTED', 'AGREED', 'Pat agreed on the call', 'Lee Support']]);
  assert.ok(!/purchase_request_id|idempotency/.test(JSON.stringify(r.body)));
  const t = await rows(svc.identityDb, `SELECT outcome FROM admin_audit WHERE subject_ref = $1 AND action = 'purchase_request.view'`, [ref]);
  assert.deepEqual(t, [{ outcome: 'read' }]);
  for (const bad of ['PR-999999', 'PR-1', 'pr-000001', 'x']) assert.equal((await svc.get(`/v1/admin/purchase-requests/${bad}`, sam.as)).status, 404, bad);
  assert.equal((await svc.get(`/v1/admin/purchase-requests/${ref}`, {})).status, 401);
});
