'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { createStaff, signIn, staffSignedIn, givePassword, lastLink, unique, rows, TEST_PASSWORD } = require('./helpers/fixtures');
const { createHasher } = require('../src/secrets');
const { rateLimit } = require('../src/rate-limit');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const NEW_PASSWORD = 'a brand new synthetic passphrase';
const forgot = (email, s = svc) => s.post('/v1/admin/auth/password/forgot', { email });
const check = token => svc.post('/v1/admin/auth/link/check', { token });
const complete = (token, newPassword = NEW_PASSWORD, confirmPassword = newPassword) => svc.post('/v1/admin/auth/link/complete', { token, newPassword, confirmPassword });
const login = (email, password, extra = {}, s = svc) => s.post('/v1/admin/auth/login', { email, password, ...extra });
/** A staff member who is Pending activation, with a link emailed to them the way "forgot" does it. */
const pending = async () => { const s = await createStaff(svc, { status: 'INVITED' }); await forgot(s.email); return { ...s, link: lastLink(svc, s.email, 'activation') }; };
/** An Active member who asked for a reset link. */
const resetting = async () => { const s = await createStaff(svc); await givePassword(svc, s.userId); await forgot(s.email); return { ...s, link: lastLink(svc, s.email, 'password_reset') }; };
const hashOf = token => createHasher(svc.hashPepper)('staff-link', token);
const BAD = /bad_link/;

test('a Pending member asks for a link, opens it, chooses a password twice, and is then Active and can sign in', async () => {
  const s = await createStaff(svc, { status: 'INVITED', name: 'Sam Support' });
  assert.equal((await login(s.email, NEW_PASSWORD)).body.reason, 'bad_credentials', 'Pending: cannot sign in');
  const ask = await forgot(s.email.toUpperCase());
  assert.equal(ask.status, 200);
  assert.deepEqual(Object.keys(ask.body).sort(), ['message', 'ok']);
  const l = lastLink(svc, s.email);
  assert.deepEqual([l.kind, l.expiresInHours], ['activation', 72], 'a pending member who forgot simply gets a fresh activation link');
  assert.match(l.link, /^http:\/\/portal\.example\.test\/#\/activate\/[A-Za-z0-9_-]{43}$/);
  assert.ok(!JSON.stringify(ask.body).includes(l.token));
  assert.deepEqual((await check(l.token)).body, { purpose: 'activate', email: s.email, displayName: 'Sam Support' });

  const done = await complete(l.token);
  assert.deepEqual(done.body, { ok: true, purpose: 'activate' }, 'choosing a password does not sign anyone in');
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE user_id = $1', [s.userId]))[0].status_code, 'ACTIVE');
  const v = await login(s.email.toUpperCase(), NEW_PASSWORD);
  assert.equal(v.status, 200);
  assert.deepEqual(v.body.user, { email: s.email, displayName: 'Sam Support', roles: ['SUPPORT'] });
  assert.ok(new Date(v.body.expiresAt) > new Date(Date.now() + 7 * 3600_000));
  const me = await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${v.body.token}` });
  assert.ok(me.body.permissions.includes('CUSTOMER_UPDATE') && me.body.permissions.includes('LICENSE_ACTIVATE'));
  assert.ok(!me.body.permissions.includes('LICENSE_SUSPEND'), 'support cannot suspend: that is a platform admin\'s');
});

test('asking for a link looks the same for a stranger, a customer user and a deactivated member: nobody learns who is staff', async () => {
  const disabled = await createStaff(svc, { status: 'DISABLED' });
  const noRole = await createStaff(svc, { role: null });
  const before = svc.notifier.sent.length;
  const answers = [];
  for (const email of [`nobody-${unique()}@example.test`, disabled.email, noRole.email]) {
    const r = await forgot(email);
    answers.push(JSON.stringify([r.status, r.body]));
  }
  assert.equal(new Set(answers).size, 1);
  assert.equal(svc.notifier.sent.length, before, 'and no email was sent');
  assert.equal((await forgot('not-an-email')).body.reason, 'bad_email');
});

test('a stranger, a member with no password and a member with the wrong password are indistinguishable at sign-in', async () => {
  const noPassword = await createStaff(svc), withPassword = await createStaff(svc);
  await givePassword(svc, withPassword.userId);
  const answers = [];
  for (const email of [`stranger-${unique()}@example.test`, noPassword.email, withPassword.email]) {
    const r = await login(email, 'definitely not the password');
    answers.push(JSON.stringify([r.status, r.body.error, r.body.reason, r.body.message]));
  }
  assert.equal(new Set(answers).size, 1, answers.join('\n'));
  assert.match(answers[0], /bad_credentials/);
  assert.ok(!/tries left|locked|no password/i.test(answers[0].replace('sign-in pauses for 15 minutes', '')), 'nothing about the account, the tries left or whether a password exists');
});

test('an unknown link, a malformed one and a real one in the wrong hands all look the same, and are never errors', async () => {
  const p = await pending();
  const answers = [];
  for (const token of [crypto.randomBytes(32).toString('base64url'), p.link.token.slice(0, -1), p.link.token + 'x', undefined, null, 12345, '', { $ne: 1 }, [p.link.token], '../../etc/passwd', ' ' + p.link.token, 'é'.repeat(43), 'a'.repeat(5000)]) {
    const c = await check(token), d = await complete(token);
    assert.equal(c.status, 400, JSON.stringify(token)); assert.equal(d.status, 400, JSON.stringify(token));
    answers.push(JSON.stringify([c.body.error, c.body.reason, c.body.message]), JSON.stringify([d.body.error, d.body.reason, d.body.message]));
  }
  assert.equal(new Set(answers.map(a => a.replace(/"message":.*$/, ''))).size <= 1, true);
  assert.equal(new Set(answers).size, 1, 'one answer for every bad link, whatever was wrong with it');
  assert.match(answers[0], BAD);
  assert.equal((await check(p.link.token)).status, 200, 'and the real link was not harmed by the attempts');
});

test('a failure to send the email looks the same as success (it must not reveal who is staff)', async () => {
  const s = await createStaff(svc);
  const original = svc.notifier.send;
  svc.notifier.send = async () => { throw new Error('provider down'); };
  try {
    const real = await forgot(s.email);
    const stranger = await forgot(`x-${unique()}@example.test`);
    assert.deepEqual([real.status, real.body], [stranger.status, stranger.body]);
    await new Promise(r => setTimeout(r, 50));
    assert.ok(svc.logs.some(l => l.msg === 'link email not sent'), 'the fault is logged for us');
    assert.ok(!JSON.stringify(svc.logs).includes('#/'), 'and never the link');
  } finally { svc.notifier.send = original; }
});

test('the link secret, the password and the session token are stored only as hashes', async () => {
  const p = await pending();
  await complete(p.link.token);
  const v = await login(p.email, NEW_PASSWORD);
  const [cred] = await rows(svc.identityDb, 'SELECT password_hash FROM staff_credential WHERE user_id = $1', [p.userId]);
  assert.match(cred.password_hash, /^scrypt\$\d+\$8\$1\$[\w-]+\$[\w-]+$/, 'salted scrypt, with its cost recorded');
  const [link] = await rows(svc.identityDb, 'SELECT * FROM staff_link WHERE user_id = $1', [p.userId]);
  assert.equal(link.token_hash, hashOf(p.link.token), 'a keyed hash of the secret');
  const dump = JSON.stringify([link, cred, ...await rows(svc.identityDb, 'SELECT * FROM session WHERE user_id = $1', [p.userId]), ...await rows(svc.identityDb, 'SELECT * FROM login_event WHERE user_id = $1', [p.userId])]);
  assert.ok(!dump.includes(p.link.token) && !dump.includes(v.body.token) && !dump.includes(NEW_PASSWORD));
  assert.ok(!dump.includes(p.email));
  const two = await pending();
  await complete(two.link.token);
  const [other] = await rows(svc.identityDb, 'SELECT password_hash FROM staff_credential WHERE user_id = $1', [two.userId]);
  assert.notEqual(other.password_hash, cred.password_hash, 'the same password gives different hashes: each has its own salt');
});

test('a link works once, and is used up even by the right person a second time', async () => {
  const p = await pending();
  assert.equal((await complete(p.link.token)).status, 200);
  assert.equal((await complete(p.link.token, 'another good passphrase here')).body.reason, 'bad_link');
  assert.equal((await check(p.link.token)).body.reason, 'bad_link');
  const [l] = await rows(svc.identityDb, 'SELECT used_at FROM staff_link WHERE user_id = $1', [p.userId]);
  assert.ok(l.used_at);
  assert.equal((await login(p.email, NEW_PASSWORD)).status, 200, 'and the first password stands');
});

test('two people opening the same link at the same moment: one wins, the other is refused (never two passwords)', async () => {
  const p = await pending();
  const [a, b] = await Promise.all([complete(p.link.token, 'first passphrase wins maybe'), complete(p.link.token, 'second passphrase wins maybe')]);
  assert.deepEqual([a.status, b.status].sort(), [200, 400]);
  const winner = a.status === 200 ? 'first passphrase wins maybe' : 'second passphrase wins maybe';
  assert.equal((await login(p.email, winner)).status, 200);
});

test('an expired link is refused, and so is one that was replaced by a newer link', async () => {
  const p = await pending();
  await svc.identityDb.query(`UPDATE staff_link SET expires_at = now() + interval '1 second', created_at = now() - interval '1 hour' WHERE user_id = $1`, [p.userId]);
  await new Promise(r => setTimeout(r, 1200));
  assert.equal((await check(p.link.token)).body.reason, 'bad_link');
  assert.equal((await complete(p.link.token)).body.reason, 'bad_link');
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE user_id = $1', [p.userId]))[0].status_code, 'INVITED', 'still Pending');

  const q = await pending();
  await forgot(q.email);
  const newer = lastLink(svc, q.email);
  assert.notEqual(newer.token, q.link.token);
  assert.equal((await check(q.link.token)).body.reason, 'bad_link', 'the older link no longer works');
  assert.equal((await complete(newer.token)).status, 200);
});

test('links last 72 hours to activate and one hour to reset, and are only ever 256 bits of randomness', async () => {
  const p = await pending(), r = await resetting();
  const [pl] = await rows(svc.identityDb, `SELECT round(extract(epoch FROM (expires_at - created_at)) / 3600)::int AS h FROM staff_link WHERE user_id = $1`, [p.userId]);
  const [rl] = await rows(svc.identityDb, `SELECT round(extract(epoch FROM (expires_at - created_at)) / 3600)::int AS h FROM staff_link WHERE user_id = $1`, [r.userId]);
  assert.deepEqual([pl.h, rl.h], [72, 1]);
  assert.equal(Buffer.from(p.link.token, 'base64url').length, 32);
  assert.notEqual(p.link.token, (await pending()).link.token);
});

test('three links per fifteen minutes; asking again replaces the earlier link', async () => {
  const s = await createStaff(svc, { status: 'INVITED' });
  const sent = [];
  for (let i = 0; i < 4; i++) { await forgot(s.email); sent.push(svc.notifier.sent.filter(m => m.to === s.email).length); }
  assert.equal(sent[3], 3, 'the fourth request sends nothing, and looks the same');
  const [first, , third] = svc.notifier.sent.filter(m => m.to === s.email).map(m => m.link.split('/').pop());
  assert.notEqual(first, third);
  assert.equal((await complete(first)).status, 400, 'an older link no longer works');
  assert.equal((await complete(third)).status, 200);
});

test('a link is for its own purpose only: an activation link cannot reset an Active account, and a reset link cannot activate a Pending one', async () => {
  const p = await pending(), a = await createStaff(svc);
  await givePassword(svc, a.userId);
  const insert = (userId, purpose) => {
    const token = crypto.randomBytes(32).toString('base64url');
    return svc.identityDb.query(`INSERT INTO staff_link (link_id, user_id, purpose, token_hash, expires_at) VALUES (gen_random_uuid(), $1, $2, $3, now() + interval '1 hour')`, [userId, purpose, hashOf(token)]).then(() => token);
  };
  const activateOnActive = await insert(a.userId, 'activate'), resetOnPending = await insert(p.userId, 'reset');
  assert.equal((await check(activateOnActive)).body.reason, 'bad_link');
  assert.equal((await complete(activateOnActive)).body.reason, 'bad_link');
  assert.equal((await check(resetOnPending)).body.reason, 'bad_link');
  assert.equal((await complete(resetOnPending)).body.reason, 'bad_link');
  assert.equal((await login(a.email, TEST_PASSWORD)).status, 200, 'the Active account\'s password is unchanged');
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE user_id = $1', [p.userId]))[0].status_code, 'INVITED', 'and the Pending account is still Pending');
});

test('a deactivated member\'s link is dead, whichever kind it was, and so is a customer user\'s', async () => {
  const p = await pending(), r = await resetting();
  for (const [s, kind] of [[p, 'activation'], [r, 'password_reset']]) {
    await svc.identityDb.query(`WITH x AS (SELECT set_config('app.reason', 'left', true)) UPDATE app_user SET status_code = 'DISABLED' FROM x WHERE user_id = $1`, [s.userId]);
    const l = lastLink(svc, s.email, kind);
    assert.equal((await check(l.token)).body.reason, 'bad_link', kind);
    assert.equal((await complete(l.token)).body.reason, 'bad_link', kind);
  }
  const id = (await rows(svc.identityDb, 'SELECT gen_random_uuid() AS id'))[0].id;
  const email = `cust-${unique()}@example.test`;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, status_code) VALUES ($1, gen_random_uuid(), 'customer', $2, 'ACTIVE')`, [id, email]);
  await svc.identityDb.query(`INSERT INTO user_role (user_role_id, user_id, role_code) VALUES (gen_random_uuid(), $1, 'CUSTOMER_ADMIN')`, [id]);
  const before = svc.notifier.sent.length;
  await forgot(email);
  assert.equal(svc.notifier.sent.length, before);
  assert.equal((await login(email, NEW_PASSWORD)).status, 400);
  for (const t of ['session', 'staff_link', 'staff_credential']) assert.equal((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM ${t} WHERE user_id = $1`, [id]))[0].n, 0, t);
});

test('a weak password, or two that do not match, is refused with the reason, and the link is not used up', async () => {
  const p = await pending();
  const local = p.email.split('@')[0];
  for (const weak of ['short1', 'password12345', 'aaaaaaaaaaaaaaaa', `${local}-and-more`, 'x'.repeat(129), null, 12345678901234, ['a long enough passphrase']]) {
    const r = await complete(p.link.token, weak, weak);
    assert.equal(r.status, 400, String(weak).slice(0, 20));
    assert.equal(r.body.reason, 'weak_password');
  }
  for (const confirm of ['a different passphrase altogether', '', null]) assert.equal((await complete(p.link.token, NEW_PASSWORD, confirm)).body.reason, 'password_mismatch');
  assert.equal((await complete(p.link.token, NEW_PASSWORD)).status, 200, 'the same link still works for a good, matching password');
});

test('resetting a password signs out every session, clears a pause, withdraws other links, and the old password stops working', async () => {
  const s = await staffSignedIn(svc);
  const other = (await login(s.email, TEST_PASSWORD)).body.token;
  await svc.identityDb.query(`UPDATE staff_credential SET locked_until = now() + interval '10 minutes', failed_attempts = 3 WHERE user_id = $1`, [s.userId]);
  await forgot(s.email);
  const l = lastLink(svc, s.email, 'password_reset');
  assert.deepEqual((await check(l.token)).body.purpose, 'reset');
  assert.deepEqual((await complete(l.token)).body, { ok: true, purpose: 'reset' });
  assert.equal((await svc.get('/v1/admin/auth/me', s.as)).status, 401, 'the session they had is gone');
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${other}` })).status, 401, 'and so is every other');
  assert.equal((await login(s.email, TEST_PASSWORD)).body.reason, 'bad_credentials', 'the old password is no good');
  assert.equal((await login(s.email, NEW_PASSWORD)).status, 200, 'the new one works at once, even though the account had been paused');
  const reasons = (await rows(svc.identityDb, 'SELECT DISTINCT revoke_reason FROM session WHERE user_id = $1 AND revoke_reason IS NOT NULL', [s.userId])).map(r => r.revoke_reason);
  assert.deepEqual(reasons, ['password_reset']);
  assert.equal((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM staff_link WHERE user_id = $1 AND used_at IS NULL AND revoked_at IS NULL`, [s.userId]))[0].n, 0, 'no link is left open');
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE user_id = $1', [s.userId]))[0].status_code, 'ACTIVE');
});

test('sign-in attempts and link use are recorded without the address, and a success updates the last login', async () => {
  const p = await pending();
  await complete(p.link.token);
  await login(p.email, 'wrong password here'); await login(p.email, NEW_PASSWORD);
  const events = await rows(svc.identityDb, 'SELECT outcome_code, reason, ip_hash FROM login_event WHERE user_id = $1 ORDER BY occurred_at', [p.userId]);
  assert.deepEqual(events.map(e => e.outcome_code), ['LINK_SENT', 'PASSWORD_SET', 'FAILED', 'SUCCESS']);
  assert.deepEqual([events[0].reason, events[1].reason], ['activate', 'activated']);
  assert.ok(events.every(e => /^[0-9a-f]{64}$/.test(e.ip_hash)), 'a hash of the network address, never the address');
  assert.ok((await rows(svc.identityDb, 'SELECT last_login_at FROM app_user WHERE user_id = $1', [p.userId]))[0].last_login_at);
});

test('five wrong passwords pause the account for fifteen minutes; the right password is then refused too, until the pause ends', async () => {
  const s = await createStaff(svc);
  await givePassword(svc, s.userId);
  for (let i = 0; i < 5; i++) assert.equal((await login(s.email, `wrong password number ${i}`)).body.reason, 'bad_credentials');
  const paused = await login(s.email, TEST_PASSWORD);
  assert.equal(paused.status, 400);
  assert.equal(paused.body.reason, 'bad_credentials', 'the same answer as a wrong password: it does not say the account is paused');
  const [c] = await rows(svc.identityDb, `SELECT failed_attempts, (locked_until > now() + interval '14 minutes') AS paused FROM staff_credential WHERE user_id = $1`, [s.userId]);
  assert.equal(c.paused, true);
  const events = (await rows(svc.identityDb, 'SELECT outcome_code, reason FROM login_event WHERE user_id = $1 ORDER BY occurred_at', [s.userId])).map(e => e.reason || e.outcome_code);
  assert.ok(events.includes('too_many_passwords') && events.includes('paused'));

  await svc.identityDb.query(`UPDATE staff_credential SET locked_until = now() - interval '1 second' WHERE user_id = $1`, [s.userId]);
  assert.equal((await login(s.email, TEST_PASSWORD)).status, 200, 'after the pause the right password works');
  const [after] = await rows(svc.identityDb, 'SELECT failed_attempts, locked_until FROM staff_credential WHERE user_id = $1', [s.userId]);
  assert.deepEqual([after.failed_attempts, after.locked_until], [0, null]);

  await login(s.email, 'wrong again'); await login(s.email, TEST_PASSWORD);
  assert.equal((await rows(svc.identityDb, 'SELECT failed_attempts FROM staff_credential WHERE user_id = $1', [s.userId]))[0].failed_attempts, 0, 'a right password resets the count');
});

test('five wrong passwords sent at the same moment still pause the account (no race around the count)', async () => {
  const s = await createStaff(svc);
  await givePassword(svc, s.userId);
  await Promise.all(Array.from({ length: 12 }, (_, i) => login(s.email, `wrong ${i}`)));
  const [c] = await rows(svc.identityDb, `SELECT (locked_until > now()) AS paused FROM staff_credential WHERE user_id = $1`, [s.userId]);
  assert.equal(c.paused, true);
  assert.equal((await login(s.email, TEST_PASSWORD)).status, 400);
});

test('a disabled member, or one whose role was taken away, cannot sign in even with the right password', async () => {
  const a = await createStaff(svc), b = await createStaff(svc);
  await givePassword(svc, a.userId); await givePassword(svc, b.userId);
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'left', true)) UPDATE app_user SET status_code = 'DISABLED' FROM r WHERE user_id = $1`, [a.userId]);
  await svc.identityDb.query('UPDATE user_role SET revoked_at = now() WHERE user_id = $1', [b.userId]);
  assert.equal((await login(a.email, TEST_PASSWORD)).body.reason, 'bad_credentials');
  assert.equal((await login(b.email, TEST_PASSWORD)).body.reason, 'bad_credentials');
});

test('a signed-in member changes their password: they must know the current one, other sessions end, this one stays', async () => {
  const s = await staffSignedIn(svc);
  const other = (await login(s.email, TEST_PASSWORD)).body.token;
  const change = (body, headers = s.as) => svc.post('/v1/admin/auth/password/change', body, headers);
  assert.equal((await change({ currentPassword: TEST_PASSWORD, newPassword: NEW_PASSWORD }, {})).status, 401, 'needs a session');
  assert.equal((await change({ currentPassword: 'not it', newPassword: NEW_PASSWORD })).body.reason, 'bad_current_password');
  assert.equal((await change({ newPassword: NEW_PASSWORD })).body.reason, 'bad_current_password');
  assert.equal((await change({ currentPassword: TEST_PASSWORD, newPassword: 'short' })).body.reason, 'weak_password');
  assert.equal((await change({ currentPassword: TEST_PASSWORD, newPassword: NEW_PASSWORD })).status, 200);
  assert.equal((await svc.get('/v1/admin/auth/me', s.as)).status, 200, 'this session stays');
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${other}` })).status, 401, 'the other one ends');
  assert.equal((await login(s.email, TEST_PASSWORD)).status, 400);
  assert.equal((await login(s.email, NEW_PASSWORD)).status, 200);
});

test('every protected route refuses a missing, malformed, unknown or expired session with 401', async () => {
  const s = await staffSignedIn(svc);
  const routes = [['get', '/v1/admin/auth/me'], ['post', '/v1/admin/auth/logout'], ['get', '/v1/admin/purchase-requests'], ['patch', '/v1/admin/purchase-requests/PR-000001'], ['post', '/v1/admin/licenses'], ['post', '/v1/admin/domains']];
  const bad = [undefined, '', 'Bearer', 'Bearer ', 'Bearer x', `Bearer ${'a'.repeat(5000)}`, `Basic ${s.token}`, `bearer ${s.token}`, `Bearer ${s.token.slice(0, -2)}xx`, `Bearer ${s.token} extra`];
  for (const [method, path] of routes) {
    for (const header of bad) {
      const r = await svc[method](path, method === 'get' ? undefined : {}, header === undefined ? {} : { Authorization: header });
      assert.equal(r.status, 401, `${method} ${path} with ${String(header).slice(0, 20)}`);
      assert.equal(r.body.reason, 'sign_in_required');
    }
  }
  await svc.identityDb.query(`UPDATE session SET expires_at = now() + interval '1 second', created_at = now() - interval '1 hour' WHERE user_id = $1`, [s.userId]);
  await new Promise(r => setTimeout(r, 1200));
  assert.equal((await svc.get('/v1/admin/auth/me', s.as)).status, 401, 'an expired session');
});

test('signing out ends the session at once', async () => {
  const s = await staffSignedIn(svc);
  assert.equal((await svc.post('/v1/admin/auth/logout', {}, s.as)).status, 200);
  assert.equal((await svc.get('/v1/admin/auth/me', s.as)).status, 401);
  const [row] = await rows(svc.identityDb, 'SELECT revoke_reason FROM session WHERE user_id = $1', [s.userId]);
  assert.equal(row.revoke_reason, 'logout');
});

test('disabling a staff member, or taking their role away, stops their session at the next request', async () => {
  const a = await staffSignedIn(svc), b = await staffSignedIn(svc);
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'left the team', true)) UPDATE app_user SET status_code = 'DISABLED' FROM r WHERE user_id = $1`, [a.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', a.as)).status, 401);
  await svc.identityDb.query(`UPDATE user_role SET revoked_at = now() WHERE user_id = $1`, [b.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', b.as)).status, 401);
});

test('re-enabling a staff member, or re-granting a role, does not bring an old session back to life', async () => {
  const a = await staffSignedIn(svc), b = await staffSignedIn(svc);
  const disable = id => svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'test', true)) UPDATE app_user SET status_code = $2 FROM r WHERE user_id = $1`, [id, 'DISABLED']);
  await disable(a.userId);
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'back', true)) UPDATE app_user SET status_code = 'ACTIVE' FROM r WHERE user_id = $1`, [a.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', a.as)).status, 401, 'the old session stays dead');
  assert.ok(await signIn(svc, a.email), 'a fresh sign-in works');

  await svc.identityDb.query(`UPDATE user_role SET revoked_at = now() WHERE user_id = $1`, [b.userId]);
  await svc.identityDb.query(`INSERT INTO user_role (user_role_id, user_id, role_code) VALUES (gen_random_uuid(), $1, 'SUPPORT')`, [b.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', b.as)).status, 401);
});

test('loading the portal (/auth/me, /auth/config) is never counted against the sign-in limit, which covers only signing in and the password and link routes', async () => {
  const limited = await startService({ dbs: { identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb }, authLimiter: rateLimit({ max: 2 }) });
  try {
    for (let i = 0; i < 12; i++) {
      assert.equal((await limited.get('/v1/admin/auth/config')).status, 200);
      assert.equal((await limited.get('/v1/admin/auth/me')).status, 401, 'refused for want of a session, not for want of patience');
    }
    assert.equal((await forgot('a@staff.example.test', limited)).status, 200);
    assert.equal((await login('a@staff.example.test', 'x', {}, limited)).status, 400);
    assert.equal((await forgot('a@staff.example.test', limited)).status, 429, 'but a third request is limited');
  } finally { await limited.close(); }
});

test('the password hash: salted, checks only the right password, and ignores a hash it does not understand', async () => {
  const { hashPassword, verifyPassword, passwordProblem } = require('../src/password');
  const hash = require('../src/secrets').createHasher(svc.hashPepper);
  const a = await hashPassword(hash, 'correct horse battery', { N: 2 ** 10 }), b = await hashPassword(hash, 'correct horse battery', { N: 2 ** 10 });
  assert.notEqual(a, b);
  assert.equal(await verifyPassword(hash, 'correct horse battery', a), true);
  assert.equal(await verifyPassword(hash, 'correct horse batterY', a), false);
  assert.equal(await verifyPassword(require('../src/secrets').createHasher('another-secret-another-secret-another-1'), 'correct horse battery', a), false, 'a copy of the database without the server secret is not enough');
  for (const junk of ['', 'plain', 'bcrypt$x$y', 'scrypt$1$2$3$4']) assert.equal(await verifyPassword(hash, 'x', junk), false);
  assert.equal(passwordProblem('a perfectly fine passphrase', 'a@b.test'), null);
});

test('the sign-in routes are limited per caller network address (the fourth call in a window is refused with 429)', async () => {
  const limited = await startService({ dbs: { identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb }, authLimiter: rateLimit({ max: 3 }) });
  try {
    const statuses = [];
    for (let i = 0; i < 5; i++) statuses.push((await forgot(`x-${unique()}@example.test`, limited)).status);
    assert.deepEqual(statuses, [200, 200, 200, 429, 429]);
    for (const route of ['login', 'link/check', 'link/complete', 'password/change']) assert.equal((await limited.post(`/v1/admin/auth/${route}`, { email: 'a@staff.example.test', token: 'x' })).status, 429, route);
  } finally { await limited.close(); }
});

test('no password, link, address, token or network address appears in any log line', async () => {
  const text = JSON.stringify(svc.logs);
  assert.ok(svc.logs.length > 30);
  assert.ok(svc.notifier.sent.length > 5);
  for (const m of svc.notifier.sent) { assert.ok(!text.includes(m.to), 'an address'); assert.ok(!text.includes(m.link.split('/').pop()), 'a link secret'); }
  assert.ok(!text.includes(TEST_PASSWORD) && !text.includes(NEW_PASSWORD) && !text.includes('wrong password'), 'a password');
  assert.ok(!/[A-Za-z0-9_-]{43}/.test(text), 'a session token');
  assert.ok(!/127\.0\.0\.1|::1|::ffff/.test(text), 'a network address');
});

test('how long asking for a link takes does not depend on the email: a sender that never finishes does not hold the answer back', async () => {
  const s = await createStaff(svc);
  const original = svc.notifier.send;
  svc.notifier.send = () => new Promise(() => {});          // never resolves
  try {
    const started = Date.now();
    const real = await forgot(s.email);
    const stranger = await forgot(`nobody-${unique()}@example.test`);
    assert.deepEqual([real.status, real.body], [stranger.status, stranger.body]);
    assert.ok(Date.now() - started < 2000);
  } finally { svc.notifier.send = original; }
});

test('a cheaper password hash is possible only when passed in (the demo and tests), and never in production', async () => {
  const { createApp } = require('../src/app');
  const make = () => createApp({ identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb, hashPepper: svc.hashPepper, licenceHashPepper: svc.licenceHashPepper,
    notifier: svc.notifier, passwordCost: { N: 2 ** 10 }, limiter: (_q, _s, n) => n(), authLimiter: (_q, _s, n) => n(), log: () => {}, secureCookies: false });
  make();
  const was = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try { assert.throws(make, /not allowed in production/); } finally { if (was === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = was; }
  const real = require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'src', 'server.js'), 'utf8');
  assert.ok(!/passwordCost/.test(real), 'the real server never passes a cheaper hash');
});

test('the password hash: salted, checks only the right password, and ignores a hash it does not understand', async () => {
  const { hashPassword, verifyPassword, passwordProblem } = require('../src/password');
  const hash = require('../src/secrets').createHasher(svc.hashPepper);
  const a = await hashPassword(hash, 'correct horse battery', { N: 2 ** 10 }), b = await hashPassword(hash, 'correct horse battery', { N: 2 ** 10 });
  assert.notEqual(a, b);
  assert.equal(await verifyPassword(hash, 'correct horse battery', a), true);
  assert.equal(await verifyPassword(hash, 'correct horse batterY', a), false);
  assert.equal(await verifyPassword(require('../src/secrets').createHasher('another-secret-another-secret-another-1'), 'correct horse battery', a), false, 'a copy of the database without the server secret is not enough');
  for (const junk of ['', 'plain', 'bcrypt$x$y', 'scrypt$1$2$3$4']) assert.equal(await verifyPassword(hash, 'x', junk), false);
  assert.equal(passwordProblem('a perfectly fine passphrase', 'a@b.test'), null);
});
