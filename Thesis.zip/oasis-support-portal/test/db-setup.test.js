'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const { build, OUTPUT } = require('../scripts/build-db-setup');

test('db/setup/01_identity_schema_and_seed.sql matches db/identity (run npm run db:setup:build if this fails)', () => {
  assert.strictEqual(fs.readFileSync(OUTPUT, 'utf8'), build());
});
