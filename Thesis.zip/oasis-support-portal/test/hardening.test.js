'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { loadConfig } = require('../src/config');
const { createShutdown } = require('../src/shutdown');
const { startService } = require('./helpers/server');

const base = { IDENTITY_DATABASE_URL: 'a', CUSTOMER_DATABASE_URL: 'b', LICENSE_DATABASE_URL: 'c', SUPPORT_DATABASE_URL: 'd', HASH_PEPPER: 'p'.repeat(32), LICENCE_HASH_PEPPER: 'q'.repeat(32), PLATFORM_CUSTOMER_ID: '0190aaaa-0000-7000-8000-000000000001' };

test('TLS settings: both files or neither; production needs TLS or an explicit plain-http allowance', () => {
  assert.equal(loadConfig(base).tls, false);
  const both = loadConfig({ ...base, TLS_CERT_FILE: '/x/cert.pem', TLS_KEY_FILE: '/x/key.pem' });
  assert.deepEqual([both.tls, both.tlsCertFile, both.tlsKeyFile, both.secureCookies], [true, '/x/cert.pem', '/x/key.pem', true]);
  assert.throws(() => loadConfig({ ...base, TLS_CERT_FILE: '/x/cert.pem' }), /TLS_CERT_FILE and TLS_KEY_FILE/);
  assert.throws(() => loadConfig({ ...base, TLS_KEY_FILE: '/x/key.pem' }), /TLS_CERT_FILE and TLS_KEY_FILE/);
  assert.throws(() => loadConfig({ ...base, ALLOW_PLAIN_HTTP: 'yes' }), /ALLOW_PLAIN_HTTP/);
  // Production gets past the TLS check with files or the allowance (and then stops at the later, unrelated email-sender check).
  const prod = { ...base, NODE_ENV: 'production', TRUST_PROXY: '0' };
  assert.throws(() => loadConfig(prod), /TLS_CERT_FILE and TLS_KEY_FILE, or ALLOW_PLAIN_HTTP/);
});

test('shutdown timeout setting: default 10 seconds, range checked', () => {
  assert.equal(loadConfig(base).shutdownTimeoutMs, 10000);
  assert.equal(loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: '2500' }).shutdownTimeoutMs, 2500);
  assert.throws(() => loadConfig({ ...base, SHUTDOWN_TIMEOUT_MS: 'x' }), /SHUTDOWN_TIMEOUT_MS/);
});

test('HSTS follows TLS, not the cookie setting', async () => {
  const svc = await startService();          // secureCookies false, tls off
  try { assert.equal((await svc.get('/healthz')).headers.get('strict-transport-security'), null); } finally { await svc.close(); }
  const { createApp } = require('../src/app');
  const dbs = {};
  const app = createApp({ identityDb: dbs, customerDb: dbs, licenseDb: dbs, supportDb: dbs, hashPepper: 'p'.repeat(32), licenceHashPepper: 'q'.repeat(32), platformCustomerId: base.PLATFORM_CUSTOMER_ID, secureCookies: true, tls: true, log: () => {} });
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/healthz`);
    assert.match(res.headers.get('strict-transport-security'), /max-age=31536000/);
  } finally { await new Promise(r => server.close(r)); }
  const app2 = createApp({ identityDb: dbs, customerDb: dbs, licenseDb: dbs, supportDb: dbs, hashPepper: 'p'.repeat(32), licenceHashPepper: 'q'.repeat(32), platformCustomerId: base.PLATFORM_CUSTOMER_ID, secureCookies: true, tls: false, log: () => {} });
  const s2 = await new Promise(r => { const s = app2.listen(0, '127.0.0.1', () => r(s)); });
  try { assert.equal((await fetch(`http://127.0.0.1:${s2.address().port}/healthz`)).headers.get('strict-transport-security'), null); } finally { await new Promise(r => s2.close(r)); }
});

test('shutdown: stops listening, ends every pool, exits 0; a second signal does nothing', async () => {
  const server = http.createServer((_q, s) => s.end('ok'));
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const ended = [], exits = [];
  const shutdown = createShutdown({ server, pools: [{ end: async () => ended.push(1) }, { end: async () => ended.push(2) }], timeoutMs: 5000, exit: c => exits.push(c), log: () => {} });
  await Promise.all([shutdown('SIGTERM'), shutdown('SIGINT')]);
  assert.deepEqual([ended, exits, server.listening], [[1, 2], [0], false]);
});

test('shutdown: an idle keep-alive connection does not hold it open; a stuck request is cut off at the timeout with exit 1', async () => {
  const server = http.createServer(() => { /* never answers */ });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const exits = [];
  const done = new Promise(r => { exits.push = c => { Array.prototype.push.call(exits, c); r(); return exits.length; }; });
  const req = http.get({ port, host: '127.0.0.1' }); req.on('error', () => {});
  await new Promise(r => setTimeout(r, 50));
  const shutdown = createShutdown({ server, pools: [{ end: async () => {} }], timeoutMs: 100, exit: c => exits.push(c), log: () => {} });
  shutdown('SIGTERM');
  await done;
  assert.deepEqual([...exits], [1]);
  await new Promise(r => setTimeout(r, 20));
});
