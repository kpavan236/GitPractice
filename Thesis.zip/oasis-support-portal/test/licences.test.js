'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService, crypto } = require('./helpers/server');
const { staffSignedIn, createRequest, unique, rows } = require('./helpers/fixtures');

const { startLicenceService: startLicenceServiceFor } = require('./helpers/licence-service');

let svc, sam, boss;
test.before(async () => { svc = await startService(); sam = await staffSignedIn(svc, { name: 'Sam Support' }); boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' }); });
test.after(async () => { await svc.close(); });

const createLicence = (body, who = sam) => svc.post('/v1/admin/licenses', { reason: 'Agreed with the customer', ...body }, who.as);
const attach = (body, who = boss) => svc.post('/v1/admin/domains', { reason: 'Checked ownership with Pat', ...body }, who.as);

const startLicenceService = () => startLicenceServiceFor(svc);

test('an agreed request becomes a customer and a licence: the key is shown once, the request is linked, and the licence service accepts the key', async () => {
  const ref = await createRequest(svc, { organization: 'Brand New Example Ltd', employees: 40, status: 'AGREED' });
  const r = await createLicence({ purchaseRequest: ref, plan: 'team', seats: 25, termDays: 365 });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.match(r.body.licenceKey, /^OASIS-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  assert.equal(r.body.customerName, 'Brand New Example Ltd');
  assert.equal(r.body.customerCreated, true);
  assert.equal(r.headers.get('cache-control'), 'no-store');

  const [pr] = await rows(svc.customerDb, 'SELECT customer_id, status_code FROM purchase_request WHERE reference = $1', [ref]);
  assert.equal(pr.customer_id, r.body.customerId);
  const [lic] = await rows(svc.licenseDb, `SELECT l.*, (SELECT count(*)::int FROM entitlement e WHERE e.license_id = l.license_id) AS features FROM license l WHERE license_id = $1`, [r.body.licenseId]);
  assert.equal(lic.status_code, 'PENDING_ACTIVATION');
  assert.equal(lic.seat_limit, 25);
  assert.equal(lic.plan_code, 'team');
  assert.equal(lic.created_by_user_id, sam.userId);
  assert.equal(lic.features, 1, 'the plan\'s features were copied');
  const dump = JSON.stringify(lic);
  assert.ok(!dump.includes(r.body.licenceKey), 'only the hash is stored');
  const [history] = await rows(svc.licenseDb, 'SELECT reason, changed_by_user_id FROM license_status_history WHERE license_id = $1 ORDER BY changed_at DESC LIMIT 1', [r.body.licenseId]);
  assert.equal(history.reason, 'Agreed with the customer');
  assert.equal(history.changed_by_user_id, sam.userId);

  const ls = await startLicenceService();
  try {
    const m = crypto.randomBytes(16).toString('hex');
    const a = await ls.post('/v1/activate', { machineId: m, licenseKey: r.body.licenceKey.toLowerCase(), appVersion: '2.0.1' });
    assert.equal(a.status, 200, JSON.stringify(a.body));
    const payload = JSON.parse(Buffer.from(a.body.token.split('.')[1], 'base64url').toString());
    assert.equal(payload.licenseId, r.body.licenseId);
    assert.equal(payload.customer, 'Brand New Example Ltd');
    assert.equal(payload.seats, 25);
    assert.deepEqual(payload.features, ['version-watch']);
  } finally { await ls.close(); }
});

test('then a domain is attached and "Activate licence" by email works end to end against the licence service', async () => {
  const ref = await createRequest(svc, { status: 'AGREED' });
  const lic = (await createLicence({ purchaseRequest: ref, plan: 'viewer-security', seats: 3 })).body;
  const domain = `ex-${unique()}.example.test`;
  const d = await attach({ customerId: lic.customerId, domain: domain.toUpperCase() });
  assert.equal(d.status, 201, JSON.stringify(d.body));
  assert.deepEqual(d.body, { customerId: lic.customerId, domain, verified: true, reason: 'Checked ownership with Pat' });

  const ls = await startLicenceService();
  try {
    const m = crypto.randomBytes(16).toString('hex'), email = `pat@${domain}`;
    assert.equal((await ls.post('/v1/domain/otp', { machineId: m, email })).status, 200);
    const code = ls.notifier.last().code;
    const a = await ls.post('/v1/domain/activate', { machineId: m, email, code });
    assert.equal(a.status, 200, JSON.stringify(a.body));
    assert.equal(JSON.parse(Buffer.from(a.body.token.split('.')[1], 'base64url').toString()).licenseId, lic.licenseId);
  } finally { await ls.close(); }
});

test('an existing customer can get a second licence; a customer can also be created by name alone', async () => {
  const first = (await createLicence({ customer: { name: 'Named Only Ltd' }, plan: 'individual', seats: 1 })).body;
  assert.equal(first.customerCreated, true);
  const [c] = await rows(svc.customerDb, 'SELECT name, status_code, slug FROM customer WHERE customer_id = $1', [first.customerId]);
  assert.deepEqual([c.name, c.status_code], ['Named Only Ltd', 'ACTIVE']);
  assert.match(c.slug, /^named-only-ltd-[0-9a-f]{6}$/);
  const second = await createLicence({ customerId: first.customerId, plan: 'team', seats: 5 });
  assert.equal(second.status, 201);
  assert.equal(second.body.customerCreated, false);
  assert.notEqual(second.body.licenseId, first.licenseId);
});

test('an enterprise licence may be uncounted; nothing else may', async () => {
  const c = (await createLicence({ customer: { name: 'Big Example plc' }, plan: 'enterprise', kind: 'enterprise', seats: null }, boss)).body;
  const [l] = await rows(svc.licenseDb, 'SELECT seat_limit, offline_allowed, kind_code FROM license WHERE license_id = $1', [c.licenseId]);
  assert.deepEqual([l.seat_limit, l.offline_allowed, l.kind_code], [null, true, 'enterprise']);
  const r = await createLicence({ customerId: c.customerId, plan: 'team', seats: null }, boss);
  assert.equal(r.status, 400); assert.equal(r.body.reason, 'bad_seats');
});

test('the request must be AGREED first, and one request makes one licence', async () => {
  const open = await createRequest(svc, { status: 'CONTACTED' });
  const r = await createLicence({ purchaseRequest: open, plan: 'team' });
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'request_not_agreed');
  assert.equal((await rows(svc.customerDb, 'SELECT customer_id FROM purchase_request WHERE reference = $1', [open]))[0].customer_id, null);

  const agreed = await createRequest(svc, { status: 'AGREED' });
  const first = (await createLicence({ purchaseRequest: agreed, plan: 'team' })).body;
  const again = await createLicence({ purchaseRequest: agreed, plan: 'team' });
  assert.equal(again.status, 409); assert.equal(again.body.reason, 'request_linked');
  assert.equal(again.body.customerId, first.customerId, 'and the answer says which customer, so the next step is clear');
  const more = await createLicence({ customerId: first.customerId, plan: 'individual', seats: 1 });
  assert.equal(more.status, 201, 'a further licence for that customer goes by customerId');
  assert.equal((await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license WHERE customer_id = $1', [first.customerId]))[0].n, 2);
  assert.equal((await createLicence({ purchaseRequest: 'PR-999999', plan: 'team' })).status, 404);
});

test('a double click: two identical requests at once make exactly one licence', async () => {
  const ref = await createRequest(svc, { status: 'AGREED' });
  const results = await Promise.all([1, 2, 3, 4].map(() => createLicence({ purchaseRequest: ref, plan: 'team' })));
  assert.equal(results.filter(r => r.status === 201).length, 1);
  assert.ok(results.filter(r => r.status !== 201).every(r => r.status === 409 && r.body.reason === 'request_linked'));
  const [pr] = await rows(svc.customerDb, 'SELECT customer_id FROM purchase_request WHERE reference = $1', [ref]);
  assert.equal((await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license WHERE customer_id = $1', [pr.customer_id]))[0].n, 1);
});

test('if the licence step fails after the customer was created, the answer and the audit trail both name the customer, and the retry works', async () => {
  const ref = await createRequest(svc, { status: 'AGREED' });
  const failing = await startService({ dbs: { identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: {
    query: (sql, params) => svc.licenseDb.query(sql, params),
    connect: async () => { const c = await svc.licenseDb.connect(); const original = c.query; const release = c.release.bind(c);
      c.query = function (sql, ...rest) { return /INSERT INTO license_term/.test(sql) ? Promise.reject(new Error('disk full')) : original.call(this, sql, ...rest); };
      c.release = (...a) => { c.query = original; return release(...a); };     // a pooled connection must not stay broken for the next caller
      return c; } } } });
  try {
    const r = await failing.post('/v1/admin/licenses', { reason: 'Agreed', purchaseRequest: ref, plan: 'team' }, sam.as);
    assert.equal(r.status, 500);
    assert.equal(r.body.error, 'internal');
    assert.equal(r.body.reason, 'licence_failed');
    assert.match(r.body.customerId, /^[0-9a-f-]{36}$/);
    assert.ok(!JSON.stringify(r.body).includes('disk full'));
    const [last] = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE action = 'licence.create' AND subject_ref = $1 ORDER BY occurred_at DESC LIMIT 1`, [ref]);
    assert.equal(last.outcome, 'failed');
    assert.equal(last.detail.customerId, r.body.customerId);
    assert.equal((await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license WHERE customer_id = $1', [r.body.customerId]))[0].n, 0, 'no half-made licence');

    const retry = await createLicence({ customerId: r.body.customerId, plan: 'team' });
    assert.equal(retry.status, 201);
    assert.equal(retry.body.customerId, r.body.customerId, 'no second customer');
  } finally { await failing.close(); }
});

test('bad input is refused with a reason, and nothing is created', async () => {
  const customersBefore = (await rows(svc.customerDb, 'SELECT count(*)::int AS n FROM customer'))[0].n;
  const licencesBefore = (await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license'))[0].n;
  const named = { customer: { name: 'Never Created Ltd' } };
  const cases = [
    [{ ...named, plan: 'trial' }, 'bad_plan'], [{ ...named, plan: 'platinum' }, 'bad_plan'], [{ ...named, plan: 5 }, 'bad_plan'], [{ ...named }, 'bad_plan'],
    [{ ...named, plan: 'team', kind: 'free' }, 'bad_kind'],
    [{ ...named, plan: 'team', seats: 0 }, 'bad_seats'], [{ ...named, plan: 'team', seats: 1.5 }, 'bad_seats'], [{ ...named, plan: 'team', seats: '10' }, 'bad_seats'], [{ ...named, plan: 'team', seats: 2_000_000 }, 'bad_seats'],
    [{ ...named, plan: 'team', termDays: 0 }, 'bad_term'], [{ ...named, plan: 'team', termDays: 4000 }, 'bad_term'], [{ ...named, plan: 'team', startsAt: 'tomorrow-ish' }, 'bad_term'], [{ ...named, plan: 'team', startsAt: 5 }, 'bad_term'], [{ ...named, plan: 'team', startsAt: '1' }, 'bad_term'], [{ ...named, plan: 'team', startsAt: '1999-01-01' }, 'bad_term'],
    [{ plan: 'team' }, 'customer_required'], [{ plan: 'team', customerId: 'x', customer: { name: 'A' } }, 'customer_required'], [{ plan: 'team', customer: { name: '' } }, 'customer_required'], [{ plan: 'team', customer: { name: 'x'.repeat(201) } }, 'customer_required'],
    [{ plan: 'team', customerId: 'not-a-uuid' }, 'unknown_customer'], [{ plan: 'team', purchaseRequest: 'nope' }, 'bad_reference'],
  ];
  for (const [body, reason] of cases) {
    const r = await createLicence(body);
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.body.reason, reason, JSON.stringify(body));
  }
  assert.equal((await createLicence({ plan: 'team', customerId: '0190aaaa-0000-7000-8000-000000000000' })).status, 404);
  assert.equal((await svc.post('/v1/admin/licenses', { plan: 'team', customer: { name: 'No Reason Ltd' } }, sam.as)).body.reason, 'reason_required');
  assert.equal((await rows(svc.customerDb, 'SELECT count(*)::int AS n FROM customer'))[0].n, customersBefore);
  assert.equal((await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license'))[0].n, licencesBefore);
});

test('a licence can be given a start date in the future', async () => {
  const future = (await createLicence({ customer: { name: 'Future Ltd' }, plan: 'team', startsAt: new Date(Date.now() + 30 * 864e5).toISOString(), termDays: 30 })).body;
  const [t] = await rows(svc.licenseDb, 'SELECT starts_at FROM license_term WHERE license_id = $1', [future.licenseId]);
  assert.ok(t.starts_at > new Date(Date.now() + 29 * 864e5));
});

test('the licence key is never in the audit trail, the logs or a second response', async () => {
  const r = (await createLicence({ customer: { name: 'Secret Key Ltd' }, plan: 'team' })).body;
  const trail = JSON.stringify(await rows(svc.identityDb, `SELECT * FROM admin_audit WHERE subject_ref = $1 OR detail->>'licenseId' = $1`, [r.licenseId]));
  assert.ok(trail.includes(r.licenseId) && !trail.includes(r.licenceKey));
  assert.ok(!JSON.stringify(svc.logs).includes(r.licenceKey));
  const entries = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE subject_ref = $1 ORDER BY occurred_at`, [r.licenseId]);
  assert.deepEqual(entries.map(e => e.outcome), ['done']);
  assert.deepEqual(entries[0].detail, { licenseId: r.licenseId, customerId: r.customerId, customerCreated: true, plan: 'team', kind: 'paid', seats: 10, termDays: 365 });
});

test('a failed licence creation is audited as failed', async () => {
  await createLicence({ plan: 'platinum', customer: { name: 'X' } });
  const [last] = await rows(svc.identityDb, `SELECT outcome, detail FROM admin_audit WHERE action = 'licence.create' ORDER BY occurred_at DESC LIMIT 1`);
  assert.equal(last.outcome, 'failed');
  assert.equal(last.detail.error, 'bad_plan');
});

// ── Domains ─────────────────────────────────────────────────────────────────

test('a domain is attached once, to one customer, and is lower-cased', async () => {
  const c = (await createLicence({ customer: { name: 'Domain Owner Ltd' }, plan: 'team' })).body;
  const other = (await createLicence({ customer: { name: 'Other Owner Ltd' }, plan: 'team' })).body;
  const domain = `owner-${unique()}.example.test`;
  assert.equal((await attach({ customerId: c.customerId, domain })).status, 201);
  const again = await attach({ customerId: c.customerId, domain });
  assert.equal(again.status, 409); assert.match(again.body.message, /already attached to this customer/);
  const taken = await attach({ customerId: other.customerId, domain: ` ${domain.toUpperCase()} ` });
  assert.equal(taken.status, 409); assert.equal(taken.body.reason, 'domain_taken'); assert.match(taken.body.message, /another customer/);
  const [row] = await rows(svc.customerDb, 'SELECT verified_at, verification_token_hash FROM customer_domain WHERE domain = $1', [domain]);
  assert.ok(row.verified_at);
  assert.match(row.verification_token_hash, /^[0-9a-f]{64}$/);
});

test('common public mailbox domains, regional variants, internet providers and public suffixes are refused', async () => {
  const c = (await createLicence({ customer: { name: 'Careless Ltd' }, plan: 'team' })).body;
  const refused = ['gmail.com', 'GMAIL.COM', 'outlook.com', 'yahoo.com', 'icloud.com', 'proton.me', 'hotmail.com', 'outlook.co.uk', 'hotmail.co.uk', 'yahoo.co.uk', 'yahoo.ca', 'comcast.net', 'att.net', 'sbcglobal.net', 'verizon.net', 'cox.net', 'bellsouth.net', 'mac.com', 'hey.com', 'fastmail.com', 'pm.me', 'protonmail.ch', 'gmx.de', 'mail.ru', '126.com'];
  for (const domain of refused) {
    const r = await attach({ customerId: c.customerId, domain });
    assert.equal(r.status, 400, domain); assert.equal(r.body.reason, 'public_mail_domain', domain);
  }
  for (const domain of ['co.uk', 'com.au', 'k12.us']) assert.equal((await attach({ customerId: c.customerId, domain })).body.reason, 'bad_domain', domain);
  assert.equal((await rows(svc.customerDb, `SELECT count(*)::int AS n FROM customer_domain WHERE domain = ANY($1)`, [refused.map(d => d.toLowerCase())]))[0].n, 0);
  assert.equal((await attach({ customerId: c.customerId, domain: `school-${unique()}.k12.example.test` })).status, 201, 'an organisation\'s own domain is fine');
});

test('awkward domains and customers are refused: not a domain, an address, a URL, a path, too long, unknown customer', async () => {
  const c = (await createLicence({ customer: { name: 'Awkward Ltd' }, plan: 'team' })).body;
  for (const domain of ['', 'nodot', 'a@b.com', 'https://acme.com', 'acme.com/path', '-bad.com', 'a.-b.com', 'a..b.com', 'acme..com', 'acme-.com', '.com', 'a.b', 'ac me.com', `${'a'.repeat(250)}.com`, "x.com'; DROP TABLE customer; --", 5, null, ['a.com']]) {
    const r = await attach({ customerId: c.customerId, domain });
    assert.equal(r.status, 400, JSON.stringify(domain).slice(0, 30)); assert.equal(r.body.reason, 'bad_domain');
  }
  assert.equal((await attach({ customerId: 'x', domain: 'ok.example.test' })).body.reason, 'unknown_customer');
  assert.equal((await attach({ customerId: '0190aaaa-0000-7000-8000-000000000000', domain: 'ok.example.test' })).status, 404);
  assert.equal((await svc.post('/v1/admin/domains', { customerId: c.customerId, domain: 'fine.example.test' }, boss.as)).body.reason, 'reason_required');
});

test('creating a licence needs LICENSE_ACTIVATE; attaching a domain needs DOMAIN_ATTACH: both are the "user" role\'s by default (migration 007), and either can be taken away', async () => {
  const c = (await createLicence({ customer: { name: 'Permission Test Ltd' }, plan: 'team' })).body;
  assert.equal((await attach({ customerId: c.customerId, domain: `by-user-${unique()}.example.test` }, sam)).status, 201, 'a user can attach the domain: the app cannot activate by email without it');
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'DOMAIN_ATTACH'`);
  const denied = await attach({ customerId: c.customerId, domain: `nope-${unique()}.example.test` }, sam);
  assert.equal(denied.status, 403); assert.equal(denied.body.reason, 'forbidden');
  assert.equal((await rows(svc.customerDb, 'SELECT count(*)::int AS n FROM customer_domain WHERE customer_id = $1', [c.customerId]))[0].n, 1);
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'DOMAIN_ATTACH')`);

  const s = await staffSignedIn(svc);
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'LICENSE_ACTIVATE'`);
  const r = await createLicence({ customer: { name: 'No Permission Ltd' }, plan: 'team' }, s);
  assert.equal(r.status, 403);
  assert.equal((await rows(svc.customerDb, `SELECT count(*)::int AS n FROM customer WHERE name = 'No Permission Ltd'`))[0].n, 0);
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'LICENSE_ACTIVATE')`);
});

test('what goes into the audit trail is validated: raw caller text never lands in it', async () => {
  await createLicence({ plan: { evil: 'x'.repeat(5000) }, customer: { name: 'X' } });
  await createLicence({ plan: 'a b <script>', purchaseRequest: 'PR-1; DROP', customer: { name: 'X' } });
  await attach({ customerId: { a: 1 }, domain: { b: 2 } });
  await attach({ customerId: 'x'.repeat(500), domain: 'y'.repeat(500) });
  const trail = await rows(svc.identityDb, `SELECT subject_ref, detail FROM admin_audit WHERE action IN ('licence.create', 'domain.attach') ORDER BY occurred_at DESC LIMIT 8`);
  const dump = JSON.stringify(trail);
  assert.ok(!dump.includes('xxxxx') && !dump.includes('script') && !dump.includes('DROP') && !dump.includes('yyyyy'));
});

test('the largest licences need an admin: a user cannot create an enterprise or unlimited licence or one over 730 days, but can create ordinary ones', async () => {
  const before = (await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license'))[0].n;
  for (const body of [{ plan: 'enterprise', kind: 'enterprise', seats: null }, { plan: 'enterprise', kind: 'enterprise', seats: 50 }, { plan: 'team', termDays: 731 }, { plan: 'team', termDays: 3650 }]) {
    const r = await createLicence({ customer: { name: 'Too Big Ltd' }, ...body }, sam);
    assert.equal(r.status, 403, JSON.stringify(body)); assert.equal(r.body.reason, 'needs_admin');
  }
  assert.equal((await rows(svc.licenseDb, 'SELECT count(*)::int AS n FROM license'))[0].n, before, 'nothing was created');
  assert.equal((await rows(svc.customerDb, `SELECT count(*)::int AS n FROM customer WHERE name = 'Too Big Ltd'`))[0].n, 0, 'nor a customer');
  assert.equal((await createLicence({ customer: { name: 'Ordinary Ltd' }, plan: 'team', termDays: 730 }, sam)).status, 201, 'two years is the ceiling for a user');
  assert.equal((await createLicence({ customer: { name: 'Big Ltd' }, plan: 'team', termDays: 3650 }, boss)).status, 201, 'an admin may');
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'LICENSE_UNLIMITED')`);
  assert.equal((await createLicence({ customer: { name: 'Granted Ltd' }, plan: 'team', termDays: 800 }, sam)).status, 201, 'granting the permission is one row of data');
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'LICENSE_UNLIMITED'`);
});

test('a public suffix is refused whatever its shape (co.kr, ac.jp, edu.in, k12.ca.us, ca.us), but an organisation under one is fine', async () => {
  const c = (await createLicence({ customer: { name: 'Suffix Test Ltd' }, plan: 'team' })).body;
  for (const domain of ['co.kr', 'ac.jp', 'edu.in', 'k12.ca.us', 'ca.us', 'com.au', 'org.uk', 'k12.in', 'gov.uk']) {
    const r = await attach({ customerId: c.customerId, domain });
    assert.equal(r.status, 400, domain); assert.equal(r.body.reason, 'bad_domain', domain);
  }
  for (const domain of ['bcps.k12.md.us', 'school.example.co.uk', 'univ.ac.jp']) assert.equal((await attach({ customerId: c.customerId, domain })).status, 201, domain);
});
