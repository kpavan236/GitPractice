'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { startLicenceService } = require('./helpers/licence-service');
const { startSupportService } = require('./helpers/support-service');
const { scenarios } = require('./helpers/scenarios');
const { staffSignedIn, createRequest, unique, rows } = require('./helpers/fixtures');

let svc, ls, sup, sam, boss, act, licence, seat, activeLicence, hintOf;
test.before(async () => {
  svc = await startService();
  ls = await startLicenceService(svc);
  sup = await startSupportService(svc);
  sam = await staffSignedIn(svc, { name: 'Sam User' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  ({ act, licence, seat, activeLicence, hintOf } = scenarios(svc, ls, boss));
});
test.after(async () => { await sup.close(); await ls.close(); await svc.close(); });

const get = (path, who = sam) => svc.get(`/v1/admin/${path}`, who.as);
const q = (db, sql, params) => rows(db, sql, params);

// ── Dashboard ────────────────────────────────────────────────────────────────

test('the dashboard counts what is waiting, what is mine, what is unassigned, and what is about to lapse, as the data changes', async () => {
  const before = (await get('dashboard')).body;
  assert.deepEqual(Object.keys(before).sort(), ['feedback', 'licences', 'purchaseRequests', 'supportRequests', 'trials']);

  const a = await createRequest(svc), b = await createRequest(svc, { status: 'CONTACTED' }), c = await createRequest(svc, { status: 'AGREED' });
  await svc.patch(`/v1/admin/purchase-requests/${b}`, { assignedTo: sam.userId, reason: 'Mine' }, boss.as);
  await sup.request(); await sup.request();
  const sr = await sup.request();
  await svc.patch(`/v1/admin/support-requests/${sr}`, { assignedTo: sam.userId, reason: 'Mine' }, boss.as);
  await sup.feedback({ category: 'bug' }); await sup.feedback({ category: 'idea' });
  const soon = await activeLicence({ days: 20 });
  await activeLicence({ days: 400 });
  const pending = await licence();
  await act(`licenses/${(await activeLicence()).licenseId}/suspend`, {});

  const after = (await get('dashboard')).body;
  const d = (section, key) => after[section][key] - before[section][key];
  assert.deepEqual([d('purchaseRequests', 'new'), d('purchaseRequests', 'contacted'), d('purchaseRequests', 'agreedWithoutLicence'), d('purchaseRequests', 'unassigned'), d('purchaseRequests', 'mine')], [1, 1, 1, 1, 1], 'purchase requests');
  assert.deepEqual([d('supportRequests', 'new'), d('supportRequests', 'unassigned'), d('supportRequests', 'mine')], [3, 2, 1], 'support requests');
  assert.deepEqual([d('feedback', 'last7Days'), d('feedback', 'bugsLast7Days')], [2, 1]);
  assert.deepEqual([d('licences', 'expiringIn30Days'), d('licences', 'suspended'), d('licences', 'waitingForFirstActivation'), d('licences', 'live')], [1, 1, 1, 3], 'licences');
  assert.ok(after.purchaseRequests.oldestOpenHours >= 0 && typeof after.supportRequests.oldestOpenHours === 'number');
  assert.ok(a && c && soon && pending);
  const mine = (await get('dashboard', boss)).body;
  assert.equal(mine.purchaseRequests.mine, 0, '"mine" is the signed-in person\'s own');
});

test('the dashboard counts trials: running, ending soon, ended lately, flagged for review', async () => {
  const before = (await get('dashboard')).body.trials;
  const trial = async (endsInDays, flag) => {
    const m = crypto.randomBytes(16).toString('hex'), inst = crypto.randomUUID(), t = crypto.randomUUID();
    await svc.licenseDb.query(`INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code) VALUES ($1, $2, 'darwin')`, [inst, m]);
    await svc.licenseDb.query(`INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '10 days' + make_interval(days => $3), now() + make_interval(days => $3))`, [t, inst, endsInDays]);
    if (flag) await svc.licenseDb.query(`INSERT INTO trial_review_flag (trial_id, flag_code) VALUES ($1, 'weak_fingerprint')`, [t]);
    return t;
  };
  await trial(5); await trial(2, true);
  const ended = await trial(-2);
  await svc.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', 'ended', true)) UPDATE trial SET status_code = 'EXPIRED' FROM r WHERE trial_id = $1`, [ended]);
  const after = (await get('dashboard')).body.trials;
  assert.deepEqual([after.running - before.running, after.endingIn3Days - before.endingIn3Days, after.endedLast7Days - before.endedLast7Days, after.flaggedForReview - before.flaggedForReview], [2, 1, 1, 1]);
});

test('the dashboard needs a session and CUSTOMER_READ', async () => {
  assert.equal((await svc.get('/v1/admin/dashboard', {})).status, 401);
  const s = await staffSignedIn(svc);
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'CUSTOMER_READ'`);
  assert.equal((await get('dashboard', s)).status, 403);
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'CUSTOMER_READ')`);
});

// ── Customers ────────────────────────────────────────────────────────────────

test('customers can be found by name or by email domain, with their domain and licence counts', async () => {
  const l = await licence({ name: 'Findable Example Ltd' });
  await licence({ name: 'Other Findable Co', seats: 3 });
  await svc.post('/v1/admin/domains', { reason: 'Checked', customerId: l.customerId, domain: 'findable.example.test' }, boss.as);
  const byName = (await get('customers?q=findable')).body.customers;
  assert.deepEqual(byName.map(c => c.name).sort(), ['Findable Example Ltd', 'Other Findable Co']);
  const row = byName.find(c => c.name === 'Findable Example Ltd');
  assert.deepEqual([row.domains, row.licences, row.live_licences, row.status_code], [1, 1, 1, 'ACTIVE']);
  assert.deepEqual((await get('customers?q=findable.example.test')).body.customers.map(c => c.name), ['Findable Example Ltd']);
  assert.deepEqual((await get('customers?q=%25%25')).body.customers, [], 'a wildcard is searched for literally, not as a wildcard');
  assert.deepEqual((await get('customers?q=NoSuchCustomerAnywhere')).body.customers, []);
  assert.ok((await get('customers')).body.customers.length >= 2);
  for (const bad of ['?q=a', `?q=${'x'.repeat(101)}`, '?q[]=ab', '?limit=0', '?limit=201', '?offset=-1']) assert.equal((await get(`customers${bad}`)).status, 400, bad);
  assert.equal((await get('customers?limit=1')).body.customers.length, 1);
});

test('one customer: domains, licences and the requests that led to it; the read is audited', async () => {
  const ref = await createRequest(svc, { organization: 'Whole Picture Ltd', status: 'AGREED' });
  const made = (await svc.post('/v1/admin/licenses', { reason: 'Agreed', purchaseRequest: ref, plan: 'team', seats: 10 }, sam.as)).body;
  await svc.post('/v1/admin/domains', { reason: 'Checked', customerId: made.customerId, domain: 'whole.example.test' }, sam.as);
  const sr = await sup.request();
  await svc.patch(`/v1/admin/support-requests/${sr}`, { customerRef: made.customerId, reason: 'This is Whole Picture' }, sam.as);
  const r = await get(`customers/${made.customerId}`);
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.name, r.body.domains.map(d => d.domain), r.body.purchaseRequests.map(p => p.reference), r.body.supportRequests.map(s => s.reference), r.body.licences.map(l => l.license_id)], ['Whole Picture Ltd', ['whole.example.test'], [ref], [sr], [made.licenseId]]);
  assert.ok(r.body.domains[0].verified_at);
  assert.ok(!JSON.stringify(r.body).includes('@'), 'no email addresses in a customer view');
  const t = await q(svc.identityDb, `SELECT outcome FROM admin_audit WHERE subject_ref = $1 AND action = 'customer.view'`, [made.customerId]);
  assert.deepEqual(t, [{ outcome: 'read' }]);
  for (const id of [crypto.randomUUID(), 'x', '..']) assert.equal((await get(`customers/${id}`)).status, 404, id);
});

// ── One licence in full ──────────────────────────────────────────────────────

test('one licence in full: customer, plan, status, terms, features, seats, blocks and the history with who and why; never the key or a machine id', async () => {
  const l = await activeLicence({ plan: 'viewer-security', seats: 5, days: 30, name: 'Full Licence Ltd' });
  await seat(l);
  await act(`licenses/${l.licenseId}/renew`, { termDays: 100, reference: 'PO-9', reason: 'Renewed' });
  await act(`licenses/${l.licenseId}/suspend`, { reason: 'Invoice unpaid' });
  const r = await get(`licenses/${l.licenseId}`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.customer.name, r.body.plan_code, r.body.plan_label, r.body.status_code, r.body.seat_limit, r.body.seats_in_use, r.body.key_hint, r.body.created_by_name], ['Full Licence Ltd', 'viewer-security', 'Version Viewer + Security', 'SUSPENDED', 5, 2, l.licenceKey.slice(-4), 'Bo Admin']);
  assert.deepEqual(r.body.terms.map(t => [t.term_no, t.source_code, t.reference]), [[1, 'purchase', null], [2, 'renewal', 'PO-9']]);
  assert.deepEqual(r.body.features.map(f => f.feature_code).sort(), ['security', 'version-watch']);
  assert.ok(new Date(r.body.expires_at) > new Date(Date.now() + 120 * 864e5) && r.body.starts_at);
  assert.deepEqual(r.body.history.map(h => [h.from_status_code, h.to_status_code, h.reason, h.changed_by_name]).slice(-2), [['PENDING_ACTIVATION', 'ACTIVE', 'First activation', null], ['ACTIVE', 'SUSPENDED', 'Invoice unpaid', 'Bo Admin']]);
  const dump = JSON.stringify(r.body);
  assert.ok(!dump.includes(l.licenceKey) && !dump.includes(l.machine) && !/license_key_hash|fingerprint/.test(dump));
  for (const id of [crypto.randomUUID(), 'x']) assert.equal((await get(`licenses/${id}`)).status, 404);
  await act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l), reason: 'Leaked' });
  await act(`licenses/${l.licenseId}/block-machines`, { confirm: hintOf(l), reason: 'Leaked' });
  assert.equal((await get(`licenses/${l.licenseId}`)).body.machines_blocked, 2);
});

// ── Audit log ────────────────────────────────────────────────────────────────

test('the audit log is for admins: who did what, when and why, newest first, with names; filters; reading it is recorded', async () => {
  const ref = await createRequest(svc);
  await svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'Audit target' }, sam.as);
  const r = await get('audit?limit=200', boss);
  assert.equal(r.status, 200);
  const done = r.body.entries.find(e => e.subject_ref === ref && e.outcome === 'done');
  assert.deepEqual([done.action, done.reason, done.actor_name, done.actor_user_id], ['purchase_request.update', 'Audit target', 'Sam User', sam.userId]);
  assert.deepEqual(Object.keys(done).sort(), ['action', 'actor_name', 'actor_user_id', 'audit_id', 'detail', 'occurred_at', 'outcome', 'reason', 'request_id', 'subject_ref']);
  assert.ok(r.body.entries.every((e, i, all) => i === 0 || all[i - 1].occurred_at >= e.occurred_at), 'newest first');
  assert.deepEqual((await get(`audit?subject=${ref}`, boss)).body.entries.map(e => e.outcome).sort(), ['done', 'started']);
  assert.ok((await get(`audit?actor=${sam.userId}&limit=200`, boss)).body.entries.every(e => e.actor_user_id === sam.userId));
  assert.ok((await get('audit?action=purchase_request.update&outcome=done&limit=200', boss)).body.entries.every(e => e.action === 'purchase_request.update' && e.outcome === 'done'));
  assert.ok((await get('audit?since=2999-01-01', boss)).body.entries.length === 0);
  assert.equal((await get('audit?limit=1', boss)).body.entries.length, 1);
  for (const bad of ['?actor=x', '?action=A B', '?subject=a b', '?outcome=maybe', '?since=yesterday', '?since=2026-13-45', '?limit=0', '?action[]=x']) assert.equal((await get(`audit${bad}`, boss)).status, 400, bad);
  const own = await q(svc.identityDb, `SELECT outcome FROM admin_audit WHERE action = 'audit.list' AND actor_user_id = $1 LIMIT 1`, [boss.userId]);
  assert.deepEqual(own, [{ outcome: 'read' }], 'looking at the trail is itself in the trail');
});

test('a user cannot read the audit log, and nobody signed in can', async () => {
  assert.equal((await get('audit', sam)).status, 403);
  assert.equal((await svc.get('/v1/admin/audit', {})).status, 401);
  assert.equal((await get('audit', boss)).status, 200);
});

test('the read routes need a session', async () => {
  const l = await licence();
  for (const path of ['customers', `customers/${l.customerId}`, `licenses/${l.licenseId}`, 'dashboard']) assert.equal((await svc.get(`/v1/admin/${path}`, {})).status, 401, path);
});

// ── Reports ──────────────────────────────────────────────────────────────────

test('reports are for admins only, are counts with no personal data, and viewing them is on record', async () => {
  assert.equal((await get('reports', sam)).status, 403);
  const r = await get('reports?weeks=6', boss);
  assert.equal(r.status, 200);
  assert.equal(r.body.weeks, 6);
  for (const k of ['licenceRequests', 'helpRequests', 'feedback', 'trials']) assert.equal(r.body.weekly[k].length, 6, `${k} has one point per week`);
  assert.deepEqual(Object.keys(r.body).sort(), ['feedback', 'helpRequests', 'licenceRequests', 'licences', 'trials', 'weekly', 'weeks', 'workload']);
  assert.ok(!/@|contact_name|organization/i.test(JSON.stringify(r.body)), 'no address or customer name in a report');
  assert.equal((await get('reports?weeks=1', boss)).status, 400);
  const logged = await q(svc.identityDb, `SELECT 1 FROM admin_audit WHERE action = 'report.view' AND outcome = 'read'`);
  assert.ok(logged.length >= 1);
});

// ── Customer users ───────────────────────────────────────────────────────────

test('customer users: admins see each customer\'s people and seats; the overview has counts only, the list is personal data and every read is on record', async () => {
  const lic = await activeLicence({ plan: 'team' }).catch(() => null);
  const customerId = lic && (lic.customerId || (lic.licence && lic.licence.customer_id));
  assert.ok(customerId, 'the scenario gives a customer with a live licence');
  const mk = (email, name, status, last) => svc.identityDb.query(
    `INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code, first_login_at, last_login_at) VALUES (gen_random_uuid(), $1, 'customer', $2, $3, $4, $5, $5)`, [customerId, email, name, status, last]);
  await mk('one@people.example.test', 'One Person', 'ACTIVE', new Date().toISOString());
  await mk('two@people.example.test', 'Two Person', 'INVITED', null);

  assert.equal((await get('customer-users', sam)).status, 403);
  assert.equal((await get(`customer-users/${customerId}`, sam)).status, 403);

  const o = (await get('customer-users?weeks=4', boss)).body;
  const row = o.customers.find(c => c.customerId === customerId);
  assert.ok(row, 'the customer is listed');
  assert.equal(row.users.total, 2); assert.equal(row.users.active, 1); assert.equal(row.users.invited, 1); assert.equal(row.users.neverSignedIn, 1); assert.equal(row.users.active30d, 1);
  assert.equal(o.signups.length, 4);
  assert.ok(!/people\.example\.test|One Person/.test(JSON.stringify(o)), 'no name or address in the overview');

  const d = (await get(`customer-users/${customerId}`, boss)).body;
  assert.deepEqual(d.users.map(u => u.email).sort(), ['one@people.example.test', 'two@people.example.test']);
  assert.equal((await get('customer-users/not-an-id', boss)).status, 404);

  const logged = await q(svc.identityDb, `SELECT detail, subject_ref FROM admin_audit WHERE action = 'customer_users.view' AND outcome = 'read'`);
  assert.ok(logged.length >= 1 && !/people\.example\.test/.test(JSON.stringify(logged)), 'the read is recorded without what was read');
});
