'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { createStaff, rows } = require('./helpers/fixtures');
const { runRetention, policyFrom, DEFAULTS } = require('../src/retention');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

const count = async (table) => (await rows(svc.identityDb, `SELECT count(*)::int AS n FROM ${table}`))[0].n;
const DAY = 86_400_000;

test('the periods come from settings, are checked, and "never" keeps a kind for ever', () => {
  assert.deepEqual(policyFrom({}), DEFAULTS);
  assert.deepEqual(policyFrom({ RETENTION_AUDIT_DAYS: '3650', RETENTION_SESSIONS_DAYS: 'never', RETENTION_REPLIES_DAYS: '0' }), { ...DEFAULTS, audit: 3650, sessions: null, replies: null });
  for (const [name, value] of [['RETENTION_AUDIT_DAYS', '30'], ['RETENTION_AUDIT_DAYS', '-1'], ['RETENTION_AUDIT_DAYS', 'abc'], ['RETENTION_AUDIT_DAYS', '1.5'], ['RETENTION_LOGIN_EVENTS_DAYS', '10'], ['RETENTION_SESSIONS_DAYS', '1'], ['RETENTION_SESSIONS_DAYS', '99999']]) {
    assert.throws(() => policyFrom({ [name]: value }), new RegExp(name), `${name}=${value}`);
  }
});

test('a dry run changes nothing; applying deletes only what is past its period, and keeps everything that is recent or still open', async () => {
  const s = await createStaff(svc);
  const q = (sql, params) => svc.identityDb.query(sql, params);
  const old = new Date(Date.now() - 800 * DAY).toISOString(), recent = new Date(Date.now() - 2 * DAY).toISOString();

  // sessions: an old ended one, an old expired one, a recent revoked one, a live one
  const session = (hash, createdAt, expires, revoked) => q(`INSERT INTO session (session_id, user_id, refresh_token_hash, family_id, created_at, expires_at, revoked_at, revoke_reason) VALUES (gen_random_uuid(), $1, $2, gen_random_uuid(), $3, $4, $5, $6)`,
    [s.userId, hash.repeat(64).slice(0, 64), createdAt, expires, revoked, revoked ? 'logout' : null]);
  await session('a', new Date(Date.now() - 100 * DAY).toISOString(), new Date(Date.now() - 99 * DAY).toISOString(), new Date(Date.now() - 99 * DAY).toISOString());
  await session('b', new Date(Date.now() - 100 * DAY).toISOString(), new Date(Date.now() - 90 * DAY).toISOString(), null);
  await session('c', recent, new Date(Date.now() + DAY).toISOString(), new Date(Date.now() - DAY).toISOString());
  await session('d', recent, new Date(Date.now() + DAY).toISOString(), null);
  // links: an old used one, an old open one that has expired, a recent used one, an open live one
  const link = (hash, created, expires, used) => q(`INSERT INTO staff_link (link_id, user_id, purpose, token_hash, created_at, expires_at, used_at) VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6)`, [s.userId, hash === 'live' ? 'reset' : 'activate', hash === 'live' ? 'e'.repeat(64) : hash.repeat(64).slice(0, 64), created, expires, used]);
  await link('1', new Date(Date.now() - 100 * DAY).toISOString(), new Date(Date.now() - 97 * DAY).toISOString(), new Date(Date.now() - 99 * DAY).toISOString());
  await link('2', new Date(Date.now() - 60 * DAY).toISOString(), new Date(Date.now() - 57 * DAY).toISOString(), null);
  await link('3', recent, new Date(Date.now() + DAY).toISOString(), recent);
  await link('live', recent, new Date(Date.now() + DAY).toISOString(), null);
  // login events, notifications, replies
  const ev = at => q(`INSERT INTO login_event (login_event_id, user_id, outcome_code, occurred_at) VALUES (gen_random_uuid(), $1, 'FAILED', $2)`, [s.userId, at]);
  await ev(old); await ev(old); await ev(recent);
  const note = at => q(`INSERT INTO staff_notification (notification_id, user_id, kind, subject_kind, reference, title, created_at) VALUES (gen_random_uuid(), $1, 'assigned', 'licence_request', 'PR-000001', 'x', $2)`, [s.userId, at]);
  await note(new Date(Date.now() - 200 * DAY).toISOString()); await note(recent);
  const reply = at => q(`INSERT INTO customer_reply (reply_id, kind, reference, sent_by_user_id, subject, body, delivery, created_at) VALUES (gen_random_uuid(), 'help_request', 'SR-000001', $1, 's', 'b', 'sent', $2)`, [s.userId, at]);
  await reply(old); await reply(recent);
  // audit: an old opening + its old ending, an old opening whose ending is recent (kept), an old read, a recent change
  const start = (at, outcome = 'started') => q(`INSERT INTO admin_audit (audit_id, occurred_at, actor_user_id, action, outcome, detail) VALUES (gen_random_uuid(), $1, $2, 'licence.create', $3, '{}') RETURNING audit_id`, [at, s.userId, outcome]).then(r => r.rows[0].audit_id);
  const end = (at, startedId) => q(`INSERT INTO admin_audit (audit_id, occurred_at, actor_user_id, action, outcome, started_audit_id, detail) VALUES (gen_random_uuid(), $1, $2, 'licence.create', 'done', $3, '{}')`, [at, s.userId, startedId]);
  const oldAudit = new Date(Date.now() - 3000 * DAY).toISOString(), edgeStart = new Date(Date.now() - 2600 * DAY).toISOString();
  const a1 = await start(oldAudit); await end(new Date(Date.now() - 2999 * DAY).toISOString(), a1);
  const a2 = await start(edgeStart); await end(new Date(Date.now() - 100 * DAY).toISOString(), a2);        // the ending is recent: the pair is kept together
  await start(oldAudit, 'read');
  const a4 = await start(recent); await end(recent, a4);

  const before = { session: await count('session'), staff_link: await count('staff_link'), login_event: await count('login_event'), staff_notification: await count('staff_notification'), customer_reply: await count('customer_reply'), admin_audit: await count('admin_audit') };
  const policy = policyFrom({});

  const dry = await runRetention(svc.identityDb, policy);
  assert.equal(dry.session.wouldDelete, 2);
  assert.equal(dry.staff_link.wouldDelete, 2);
  assert.equal(dry.login_event.wouldDelete, 2);
  assert.equal(dry.staff_notification.wouldDelete, 1);
  assert.equal(dry.customer_reply.wouldDelete, 1);
  assert.equal(dry.admin_audit.wouldDelete, 3, 'the old opening and its ending, and the old read; not the pair whose ending is recent');
  for (const [t, n] of Object.entries(before)) assert.equal(await count(t), n, `${t}: a dry run deletes nothing`);

  const done = await runRetention(svc.identityDb, policy, { apply: true });
  assert.deepEqual([done.session.deleted, done.staff_link.deleted, done.login_event.deleted, done.staff_notification.deleted, done.customer_reply.deleted, done.admin_audit.deleted], [2, 2, 2, 1, 1, 3]);
  assert.equal(await count('session') , before.session - 2);
  assert.equal((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM staff_link WHERE user_id = $1 AND revoked_at IS NULL AND used_at IS NULL AND expires_at > now()`, [s.userId]))[0].n, 1, 'the open link survives');
  assert.equal((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM session WHERE user_id = $1 AND revoked_at IS NULL`, [s.userId]))[0].n, 1, 'the live session survives');
  assert.equal(await count('admin_audit'), before.admin_audit - 3);
  const again = await runRetention(svc.identityDb, policy, { apply: true });
  assert.ok(Object.values(again).every(r => (r.deleted || 0) === 0), 'a second run finds nothing');
});

test('outside the retention job the audit trail, the sign-in history and the reply record stay append-only; "never" keeps a kind untouched', async () => {
  const s = await createStaff(svc);
  await svc.identityDb.query(`INSERT INTO admin_audit (audit_id, occurred_at, actor_user_id, action, outcome, detail) VALUES (gen_random_uuid(), now() - interval '4000 days', $1, 'licence.create', 'read', '{}')`, [s.userId]);
  for (const sql of [`DELETE FROM admin_audit`, `UPDATE admin_audit SET reason = 'edited'`, `DELETE FROM login_event`, `UPDATE login_event SET reason = 'edited'`, `DELETE FROM customer_reply`, `UPDATE customer_reply SET body = 'edited'`]) {
    await assert.rejects(svc.identityDb.query(sql), /append-only|retention job/i, sql);
  }
  const keep = await runRetention(svc.identityDb, { ...DEFAULTS, audit: null, loginEvents: null }, { apply: true });
  assert.deepEqual([keep.admin_audit.kept, keep.login_event.kept], ['for ever', 'for ever']);
  assert.ok((await count('admin_audit')) > 0);
  // the setting is local to the job's own transaction: nothing stays switched on afterwards
  await assert.rejects(svc.identityDb.query(`DELETE FROM admin_audit`), /retention job/i);
});

test('the command needs a database address and refuses unknown arguments', () => {
  const { spawnSync } = require('node:child_process');
  const env = { ...process.env }; delete env.IDENTITY_DATABASE_URL;
  const run = args => spawnSync(process.execPath, ['src/retention.js', ...args], { cwd: require('node:path').join(__dirname, '..'), env, encoding: 'utf8' });
  const none = run([]);
  assert.notEqual(none.status, 0);
  assert.match(none.stderr, /IDENTITY_DATABASE_URL is required/);
  assert.ok(require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'src', 'retention.js'), 'utf8').includes('Unknown argument'));
});

test('activity events past their period are deleted too (their guard allows only the retention job)', async () => {
  const s = await createStaff(svc);
  await svc.identityDb.query(`INSERT INTO activity_event (activity_event_id, customer_id, user_id, event_type_code, occurred_at) VALUES (gen_random_uuid(), gen_random_uuid(), $1, 'LOGIN', now() - interval '900 days')`, [s.userId]);
  await assert.rejects(svc.identityDb.query('DELETE FROM activity_event'), /retention job/i);
  const r = await runRetention(svc.identityDb, policyFrom({}), { apply: true });
  assert.ok(r.activity_event.deleted >= 1);
});
