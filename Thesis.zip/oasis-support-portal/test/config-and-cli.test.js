'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { loadConfig } = require('../src/config');
const { startService } = require('./helpers/server');
const { signIn, rows } = require('./helpers/fixtures');

const run = promisify(execFile);

test('configuration: required settings, peppers, ranges, and what production refuses', () => {
  const base = { IDENTITY_DATABASE_URL: 'a', CUSTOMER_DATABASE_URL: 'b', LICENSE_DATABASE_URL: 'c', SUPPORT_DATABASE_URL: 'd', HASH_PEPPER: 'p'.repeat(32), LICENCE_HASH_PEPPER: 'q'.repeat(32), PLATFORM_CUSTOMER_ID: '0190aaaa-0000-7000-8000-000000000001' };
  const c = loadConfig(base);
  assert.deepEqual([c.port, c.sessionHours, c.printCodes], [4030, 8, false]);
  for (const name of Object.keys(base)) assert.throws(() => loadConfig({ ...base, [name]: '' }), new RegExp(name));
  assert.throws(() => loadConfig({ ...base, HASH_PEPPER: 'short' }), /HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, LICENCE_HASH_PEPPER: 'short' }), /LICENCE_HASH_PEPPER/);
  assert.throws(() => loadConfig({ ...base, SESSION_HOURS: '0' }), /SESSION_HOURS/);
  assert.throws(() => loadConfig({ ...base, SESSION_HOURS: '25' }), /SESSION_HOURS/);
  assert.throws(() => loadConfig({ ...base, PORT: 'x' }), /PORT/);
  assert.throws(() => loadConfig({ ...base, NOTIFIER: 'smtp' }), /NOTIFIER/);
  assert.equal(loadConfig({ ...base, DEV_PRINT_CODES: '1' }).printCodes, true);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production' }), /TRUST_PROXY/);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', TRUST_PROXY: '1', ALLOW_PLAIN_HTTP: '1' }), /approved email sender/);
});

test('the staff command creates a staff member who can then sign in, and refuses a bad role, a bad address and a repeat', async () => {
  const svc = await startService();
  try {
    const env = { ...process.env, IDENTITY_DATABASE_URL: svc.identityUrl };
    const cli = (...args) => run('node', [path.join(__dirname, '..', 'src', 'staff-cli.js'), ...args], { env });
    const email = 'new.person@staff.example.test';

    const ok = await cli('--email', email.toUpperCase(), '--name', 'New Person', '--role', 'SUPPORT', '--customer', '0190aaaa-0000-7000-8000-000000000001');
    assert.match(ok.stdout, /created with role SUPPORT/);
    const [u] = await rows(svc.identityDb, `SELECT u.user_type_code, u.status_code, u.display_name, r.role_code FROM app_user u JOIN user_role r USING (user_id) WHERE u.email = $1`, [email]);
    assert.deepEqual(u, { user_type_code: 'staff', status_code: 'ACTIVE', display_name: 'New Person', role_code: 'SUPPORT' });
    assert.ok(await signIn(svc, email), 'and they can sign in');

    await assert.rejects(cli('--email', email, '--role', 'SUPPORT', '--customer', '0190aaaa-0000-7000-8000-000000000001'), /already|unique|duplicate/i);
    await assert.rejects(cli('--email', 'x@staff.example.test', '--role', 'CUSTOMER_ADMIN', '--customer', '0190aaaa-0000-7000-8000-000000000001'), /--role must be one of/);
    await assert.rejects(cli('--email', 'not-an-email', '--role', 'SUPPORT', '--customer', '0190aaaa-0000-7000-8000-000000000001'), /Usage/);
    await assert.rejects(cli('--email', 'y@staff.example.test', '--role', 'SUPPORT'), /Usage/);
  } finally { await svc.close(); }
});
