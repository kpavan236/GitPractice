'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { startLicenceService } = require('./helpers/licence-service');
const { scenarios } = require('./helpers/scenarios');
const { LICENCE_SERVICE_DIR } = require('./helpers/db');
const { staffSignedIn, rows } = require('./helpers/fixtures');

let svc, sam, boss, ls, act, licence, seat, activeLicence, hintOf;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  ls = await startLicenceService(svc);
  ({ act, licence, seat, activeLicence, hintOf } = scenarios(svc, ls, boss));
});
test.after(async () => { await ls.close(); await svc.close(); });

const q = (sql, params) => rows(svc.licenseDb, sql, params);
const block = (l, body = {}, who = boss) => act(`licenses/${l.licenseId}/block-machines`, { confirm: hintOf(l), ...body }, who);
const revoke = (l, who = boss) => act(`licenses/${l.licenseId}/revoke`, { confirm: hintOf(l), reason: 'Key leaked' }, who);
const blocksOf = l => svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}&state=all`, sam.as);

/** A licence with `n` machines seated, then revoked. Returns the licence and its machines [{ machine, token }]. */
async function revokedWith(n) {
  const l = await licence({ seats: 10 });
  const machines = [];
  for (let i = 0; i < n; i++) machines.push(await seat(l));
  assert.equal((await revoke(l)).status, 200);
  return { l, machines };
}

test('blocking the machines of a revoked licence: every one is refused everywhere in the licence service, including a new trial; others are not', async () => {
  const { l, machines } = await revokedWith(3);
  const innocent = crypto.randomBytes(16).toString('hex');
  const r = await block(l, { reason: 'Key was posted publicly' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.machines, r.body.newlyBlocked, r.body.alreadyBlocked], [3, 3, 0]);

  for (const m of machines) {
    const trial = await ls.post('/v1/trial', { machineId: m.machine });
    assert.equal(trial.status, 403, 'a revoked machine cannot start a trial either');
    assert.equal(trial.body.reason, 'blocked');
    const reval = await ls.post('/v1/revalidate', { machineId: m.machine, token: m.token });
    assert.equal(reval.status, 403); assert.equal(reval.body.reason, 'blocked');
    assert.equal(reval.body.message, 'This machine cannot use the licence. Contact support.', 'one fixed message; the internal note is never shown');
  }
  assert.equal((await ls.post('/v1/trial', { machineId: innocent })).status, 200, 'an unrelated machine is unaffected');
});

test('staff never see a machine id: not in the answer, the list, the stored blocks or the audit trail', async () => {
  const { l, machines } = await revokedWith(2);
  const r = await block(l, { reason: 'Leaked' });
  const list = await blocksOf(l);
  const trail = await rows(svc.identityDb, `SELECT * FROM admin_audit WHERE subject_ref = $1`, [l.licenseId]);
  const stored = await q('SELECT * FROM access_block WHERE license_id = $1', [l.licenseId]);
  for (const m of machines) {
    for (const where of [r.body, list.body, trail, stored]) assert.ok(!JSON.stringify(where).includes(m.machine));
  }
  assert.equal(stored.length, 2);
  assert.ok(stored.every(b => /^[0-9a-f]{64}$/.test(b.subject_hash) && b.subject_type === 'machine' && b.reason_code === 'licence_revoked' && b.blocked_by_user_id === boss.userId));
  const shown = list.body.blocks[0];
  assert.deepEqual(Object.keys(shown).sort(), ['block_id', 'blocked_at', 'blocked_by_user_id', 'expires_at', 'license_id', 'lifted_at', 'lifted_by_user_id', 'note', 'reason_code', 'subject_type']);
  assert.match(shown.note, new RegExp(`Licence ${l.licenseId} ended: Leaked`));
});

test('the hash is the one the licence service looks up: blocking here is what makes it refuse there', async () => {
  const { l, machines } = await revokedWith(1);
  assert.equal((await ls.post('/v1/revalidate', { machineId: machines[0].machine, token: machines[0].token })).body.reason, 'revoked', 'before: told it was revoked');
  await block(l, {});
  assert.equal((await ls.post('/v1/revalidate', { machineId: machines[0].machine, token: machines[0].token })).body.reason, 'blocked', 'after: not even that');
});

test('the licence must already be cancelled or revoked, and the caller must confirm it', async () => {
  const live = await activeLicence();
  const r = await block(live, {});
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'licence_not_ended');
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1', [live.licenseId]))[0].n, 0);

  const { l } = await revokedWith(2);
  const missing = await act(`licenses/${l.licenseId}/block-machines`, {});
  assert.equal(missing.status, 400); assert.equal(missing.body.reason, 'confirmation_required');
  for (const confirm of ['', 'ZZZZ', 5, null, [hintOf(l)], `${hintOf(l)}X`]) {
    const x = await act(`licenses/${l.licenseId}/block-machines`, { confirm });
    assert.equal(x.status, 400, JSON.stringify(confirm)); assert.equal(x.body.reason, 'confirmation_mismatch');
  }
  assert.equal((await act(`licenses/${l.licenseId}/block-machines`, { confirm: hintOf(l), reason: '' })).body.reason, 'reason_required');
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1', [l.licenseId]))[0].n, 0, 'nothing was blocked by any of those');
});

test('a cancelled licence works too: its machines still hold seats, and they are the ones blocked; machines that left earlier are not', async () => {
  const l = await licence({ seats: 10 });
  const stays = await seat(l), alsoStays = await seat(l), left = await seat(l);
  await ls.post('/v1/deactivate', { machineId: left.machine, token: left.token });
  assert.equal((await act(`licenses/${l.licenseId}/cancel`, { confirm: hintOf(l), reason: 'Left us' })).status, 200);
  const r = await block(l, {});
  assert.equal(r.body.machines, 2);
  assert.equal((await ls.post('/v1/trial', { machineId: stays.machine })).body.reason, 'blocked');
  assert.equal((await ls.post('/v1/trial', { machineId: alsoStays.machine })).body.reason, 'blocked');
  assert.equal((await ls.post('/v1/trial', { machineId: left.machine })).status, 200, 'it deactivated before the end, so it is not one of the licence\'s machines');
});

test('repeating changes nothing; a machine already blocked for another reason keeps that block and is counted as already blocked', async () => {
  const { l, machines } = await revokedWith(3);
  const { createAccess } = require(require('node:path').join(LICENCE_SERVICE_DIR, 'src', 'access'));
  const { createHasher } = require('../src/secrets');
  const access = createAccess({ licenseDb: svc.licenseDb, hash: createHasher(svc.licenceHashPepper) });
  await access.block({ type: 'machine', value: machines[0].machine, reason: 'abuse', note: 'earlier' });
  const first = await block(l, {});
  assert.deepEqual([first.body.machines, first.body.newlyBlocked, first.body.alreadyBlocked], [3, 2, 1]);
  const again = await block(l, {});
  assert.deepEqual([again.body.newlyBlocked, again.body.alreadyBlocked], [0, 3]);
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE lifted_at IS NULL AND license_id = $1', [l.licenseId]))[0].n, 2);
  assert.equal(await access.check({ machineId: machines[0].machine }), 'abuse', 'its own block is untouched');
});

test('a machine that is also on another licence is refused there too: a block is on the machine, and the answer says how many were blocked so it is not a surprise', async () => {
  const a = await licence({ seats: 5 }), b = await licence({ seats: 5 });
  const shared = await seat(a);
  const onB = await ls.post('/v1/activate', { machineId: shared.machine, licenseKey: b.licenceKey });
  assert.equal(onB.status, 200);
  await revoke(a);
  await block(a, {});
  const reval = await ls.post('/v1/revalidate', { machineId: shared.machine, token: onB.body.token });
  assert.equal(reval.body.reason, 'blocked', 'the other, good licence is refused on that machine too');
  const lifted = await act(`licenses/${a.licenseId}/unblock-machines`, {});
  assert.equal(lifted.body.lifted, 1);
  assert.equal((await ls.post('/v1/revalidate', { machineId: shared.machine, token: onB.body.token })).status, 200, 'and lifting restores it');
});

test('unblocking a licence\'s machines lifts them all at once; the app is then told "revoked" again, and a trial can start; repeating lifts nothing', async () => {
  const { l, machines } = await revokedWith(3);
  await block(l, {});
  const r = await act(`licenses/${l.licenseId}/unblock-machines`, { reason: 'Revoked by mistake, customer has settled' });
  assert.equal(r.status, 200);
  assert.equal(r.body.lifted, 3);
  assert.equal((await ls.post('/v1/revalidate', { machineId: machines[0].machine, token: machines[0].token })).body.reason, 'revoked');
  assert.equal((await ls.post('/v1/trial', { machineId: machines[1].machine })).status, 200);
  assert.equal((await act(`licenses/${l.licenseId}/unblock-machines`, {})).body.lifted, 0);
  const rows3 = await q('SELECT lifted_at, lifted_by_user_id FROM access_block WHERE license_id = $1', [l.licenseId]);
  assert.ok(rows3.every(b => b.lifted_at && b.lifted_by_user_id === boss.userId));
  const again = await block(l, {});
  assert.equal(again.body.newlyBlocked, 3, 'after lifting, blocking again makes new blocks (the old ones stay as history)');
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1', [l.licenseId]))[0].n, 6);
});

test('lifting one block frees only that machine', async () => {
  const { l, machines } = await revokedWith(2);
  await block(l, {});
  const list = (await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}`, sam.as)).body.blocks;
  assert.equal(list.length, 2);
  const r = await act(`blocks/${list[0].block_id}/lift`, { reason: 'This one was a test machine' });
  assert.equal(r.status, 200); assert.equal(r.body.lifted, 1);
  const states = await Promise.all(machines.map(m => ls.post('/v1/revalidate', { machineId: m.machine, token: m.token }).then(x => x.body.reason)));
  assert.deepEqual([...states].sort(), ['blocked', 'revoked']);
  assert.equal((await act(`blocks/${list[0].block_id}/lift`, {})).body.lifted, 0, 'lifting twice changes nothing');
  assert.equal((await act(`blocks/${crypto.randomUUID()}/lift`, {})).status, 404);
  assert.equal((await act('blocks/not-an-id/lift', {})).status, 404);
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}`, sam.as)).body.blocks.length, 1, 'the active list now shows one');
  const trail = await rows(svc.identityDb, `SELECT outcome, detail, reason, subject_ref FROM admin_audit WHERE action = 'block.lift' AND subject_ref = $1 ORDER BY occurred_at`, [list[0].block_id]);
  assert.deepEqual(trail.map(t => t.outcome), ['started', 'done', 'started', 'done']);
  assert.deepEqual([trail[1].detail, trail[1].reason], [{ lifted: 1 }, 'This one was a test machine']);
  assert.deepEqual(trail[3].detail, { lifted: 0 });
});

test('the block list: active by default, filters by state, reason and licence, limits; bad filters are refused', async () => {
  const { l } = await revokedWith(3);
  await block(l, {});
  const id = (await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}`, sam.as)).body.blocks[0].block_id;
  await act(`blocks/${id}/lift`, {});
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}`, sam.as)).body.blocks.length, 2);
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}&state=lifted`, sam.as)).body.blocks.length, 1);
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}&state=all`, sam.as)).body.blocks.length, 3);
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}&state=all&reason=licence_revoked&limit=1`, sam.as)).body.blocks.length, 1);
  assert.equal((await svc.get(`/v1/admin/blocks?licenseId=${l.licenseId}&state=all&reason=abuse`, sam.as)).body.blocks.length, 0);
  for (const bad of ['?state=maybe', '?reason=because', '?licenseId=x', '?limit=0', '?limit=201', '?offset=-1', '?state[]=all', '?reason[]=abuse']) {
    const r = await svc.get(`/v1/admin/blocks${bad}`, sam.as);
    assert.equal(r.status, 400, bad); assert.equal(r.body.reason, 'bad_filter');
  }
});

test('only BLOCK_MANAGE may block or lift (platform admin by default); reading the list needs only LICENSE_READ; everything needs a session', async () => {
  const { l } = await revokedWith(1);
  for (const [path, body] of [[`licenses/${l.licenseId}/block-machines`, { confirm: hintOf(l) }], [`licenses/${l.licenseId}/unblock-machines`, {}], [`blocks/${crypto.randomUUID()}/lift`, {}]]) {
    const r = await act(path, body, sam);
    assert.equal(r.status, 403, path); assert.equal(r.body.reason, 'forbidden');
    assert.equal((await svc.post(`/v1/admin/${path}`, { reason: 'x', ...body }, {})).status, 401);
  }
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1', [l.licenseId]))[0].n, 0);
  assert.equal((await svc.get('/v1/admin/blocks', sam.as)).status, 200);
  assert.equal((await svc.get('/v1/admin/blocks', {})).status, 401);
  await svc.identityDb.query(`INSERT INTO role_permission (role_code, permission_code) VALUES ('SUPPORT', 'BLOCK_MANAGE')`);
  assert.equal((await block(l, {}, sam)).status, 200, 'granting it is one row of data');
  await svc.identityDb.query(`DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'BLOCK_MANAGE'`);
});

test('unknown or malformed licence ids are 404, and a reason is always required', async () => {
  for (const id of [crypto.randomUUID(), 'x', '..', "'; DROP TABLE access_block; --"]) {
    for (const route of ['block-machines', 'unblock-machines']) assert.equal((await act(`licenses/${encodeURIComponent(id)}/${route}`, { confirm: 'ABCD' })).status, 404, `${route} ${id}`);
  }
  const { l } = await revokedWith(1);
  assert.equal((await act(`licenses/${l.licenseId}/unblock-machines`, { reason: '' })).body.reason, 'reason_required');
});

test('every block change is audited with counts only, and a refusal is audited as failed', async () => {
  const { l } = await revokedWith(2);
  await block(l, { reason: 'audit me' });
  await act(`licenses/${l.licenseId}/unblock-machines`, { reason: 'and lift' });
  await act(`licenses/${l.licenseId}/block-machines`, { confirm: 'WRNG' });
  const t = await rows(svc.identityDb, `SELECT action, outcome, detail, reason FROM admin_audit WHERE subject_ref = $1 AND action LIKE 'licence.%block%' ORDER BY occurred_at`, [l.licenseId]);
  assert.deepEqual(t.map(x => `${x.action}:${x.outcome}`), [
    'licence.block_machines:started', 'licence.block_machines:done', 'licence.unblock_machines:started', 'licence.unblock_machines:done', 'licence.block_machines:started', 'licence.block_machines:failed']);
  assert.deepEqual(t[1].detail, { machines: 2, newlyBlocked: 2, alreadyBlocked: 0 });
  assert.deepEqual(t[3].detail, { lifted: 2 });
  assert.equal(t[5].detail.error, 'confirmation_mismatch');
  assert.equal(t[0].reason, 'audit me');
});

test('if the audit cannot be written, nothing is blocked', async () => {
  const { l } = await revokedWith(2);
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    assert.equal((await broken.post(`/v1/admin/licenses/${l.licenseId}/block-machines`, { confirm: hintOf(l), reason: 'nope' }, boss.as)).status, 500);
    assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1', [l.licenseId]))[0].n, 0);
  } finally { await broken.close(); }
});

test('two people blocking the same licence at once: each machine is blocked once', async () => {
  const { l } = await revokedWith(4);
  const results = await Promise.all([1, 2, 3].map(() => block(l, {})));
  assert.ok(results.every(r => r.status === 200), JSON.stringify(results.map(r => r.body)));
  assert.equal(results.reduce((n, r) => n + r.body.newlyBlocked, 0), 4);
  assert.equal((await q('SELECT count(*)::int AS n FROM access_block WHERE license_id = $1 AND lifted_at IS NULL', [l.licenseId]))[0].n, 4);
});
