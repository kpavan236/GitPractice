'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { rows } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });
const held = async role => new Set((await rows(svc.identityDb, `SELECT permission_code FROM role_permission WHERE role_code = $1 AND permission_code LIKE 'INVOICE_%'`, [role])).map(r => r.permission_code));

test('a user can read and work invoices; only an admin has the administrative actions; customers have neither', async () => {
  assert.deepEqual([...await held('SUPPORT')].sort(), ['INVOICE_READ', 'INVOICE_WRITE']);
  assert.deepEqual([...await held('PLATFORM_ADMIN')].sort(), ['INVOICE_ADMIN', 'INVOICE_READ', 'INVOICE_WRITE']);
  for (const role of ['CUSTOMER_USER', 'CUSTOMER_ADMIN']) { const p = await held(role); assert.ok(!p.has('INVOICE_WRITE') && !p.has('INVOICE_ADMIN'), role); }
});
