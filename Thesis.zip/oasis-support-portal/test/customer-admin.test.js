'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { startLicenceService } = require('./helpers/licence-service');
const { scenarios } = require('./helpers/scenarios');
const { staffSignedIn, rows, unique } = require('./helpers/fixtures');

let svc, ls, sam, boss, licence;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  ls = await startLicenceService(svc);
  ({ licence } = scenarios(svc, ls, boss));
});
test.after(async () => { await ls.close(); await svc.close(); });

const patch = (id, body, who = boss) => svc.patch(`/v1/admin/customers/${id}`, { reason: 'Corrected after a call', ...body }, who.as);
const customerOf = l => l.customerId || l.customer_id;
const trail = (action, subject) => rows(svc.identityDb, `SELECT outcome, detail, reason FROM admin_audit WHERE action = $1 AND subject_ref = $2 ORDER BY occurred_at`, [action, subject]);

test('an admin corrects a customer\'s details; the offered values come from the lists; invalid ones are refused; users cannot; the trail names the fields, not the values', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  const id = customerOf(l);
  const opts = (await svc.get('/v1/admin/customer-options', sam.as)).body;
  assert.ok(opts.industries.length && opts.sizeBands.length && opts.countries.length);
  const industry = opts.industries[0].code, sizeBand = opts.sizeBands[0].code, country = opts.countries[0].code;

  assert.equal((await patch(id, { name: 'Nope' }, sam)).status, 403, 'a user may not');
  const r = await patch(id, { name: '  Renamed   Distinctive Ltd ', legalName: 'Renamed Distinctive Limited', website: 'https://renamed.example.test', industry, sizeBand, country: country.toLowerCase(), timezone: 'Europe/London' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.name, r.body.legal_name, r.body.website, r.body.industry_code, r.body.size_band_code, r.body.country_code, r.body.timezone],
    ['Renamed Distinctive Ltd', 'Renamed Distinctive Limited', 'https://renamed.example.test', industry, sizeBand, country, 'Europe/London']);
  const d = (await svc.get(`/v1/admin/customers/${id}`, sam.as)).body;
  assert.deepEqual([d.name, d.country_code, d.timezone], ['Renamed Distinctive Ltd', country, 'Europe/London']);

  for (const [body, reason] of [[{}, 'nothing_to_change'], [{ name: '' }, 'bad_name'], [{ name: 5 }, 'bad_name'], [{ name: 'x'.repeat(201) }, 'bad_name'], [{ legalName: 5 }, 'bad_legal_name'],
    [{ website: 'javascript:alert(1)' }, 'bad_website'], [{ website: 'ftp://x.example.test' }, 'bad_website'], [{ website: 'https://user:pw@x.example.test' }, 'bad_website'], [{ website: 'not a url' }, 'bad_website'],
    [{ industry: 'made-up' }, 'bad_industry'], [{ sizeBand: 'huge' }, 'bad_sizeBand'], [{ country: 'ZZ' }, 'bad_country'], [{ country: 5 }, 'bad_country'], [{ timezone: 'Mars/Base' }, 'bad_timezone'], [{ timezone: '../etc' }, 'bad_timezone']]) {
    const x = await patch(id, body);
    assert.equal(x.status, 400, JSON.stringify(body));
    assert.equal(x.body.reason, reason, JSON.stringify(body));
  }
  assert.equal((await patch(id, { website: null, legalName: null })).status, 200, 'optional details can be cleared');
  assert.equal((await patch('00000000-0000-0000-0000-000000000000', { name: 'X' })).status, 404);
  assert.equal((await svc.patch(`/v1/admin/customers/${id}`, { name: 'No reason' }, boss.as)).status, 400);
  const t = await trail('customer.update', id);
  assert.ok(t.some(x => x.outcome === 'done' && x.detail.changed.includes('name')));
  assert.ok(!JSON.stringify(t).includes('Distinctive'), 'the new name is not copied into the trail');
  assert.equal((await rows(svc.customerDb, 'SELECT status_code FROM customer WHERE customer_id = $1', [id]))[0].status_code !== undefined, true);
});

test('any staff member can add a note to a customer; notes are append-only, shown with who wrote them, and cleaned of control characters', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  const id = customerOf(l);
  const add = (body, who = sam) => svc.post(`/v1/admin/customers/${id}/notes`, { body }, who.as);
  assert.equal((await add('First call: they want 3 more seats in March.\n\nSecond paragraph.')).status, 201);
  assert.equal((await add('Asked for an invoice‮ reversed\u0000')).status, 201);
  for (const bad of ['', '   ', 5, null, 'x'.repeat(4001)]) assert.equal((await add(bad)).body.reason, 'bad_note');
  assert.equal((await svc.post('/v1/admin/customers/00000000-0000-0000-0000-000000000000/notes', { body: 'x' }, sam.as)).status, 404);
  const d = (await svc.get(`/v1/admin/customers/${id}`, boss.as)).body;
  assert.equal(d.notes.length, 2);
  assert.equal(d.notes[0].by, 'Sam Support');
  assert.match(d.notes[0].body, /three more seats|3 more seats/);
  assert.ok(d.notes[0].body.includes('\n\n'), 'line breaks are kept');
  assert.ok(!/[‮\u0000]/.test(d.notes[1].body), 'control and bidi characters are removed');
  await assert.rejects(svc.identityDb.query(`UPDATE customer_note SET body = 'changed'`), /append-only|never/i);
  await assert.rejects(svc.identityDb.query('DELETE FROM customer_note'), /append-only|never/i);
  const t = await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = 'customer.note' AND subject_ref = $1 AND outcome = 'done'`, [id]);
  assert.ok(t.length === 2 && !JSON.stringify(t).includes('seats'), 'the trail records that a note was added, never what it said');
});

async function customerUser(customerId, { status = 'ACTIVE', signedIn = true } = {}) {
  const id = (await rows(svc.identityDb, 'SELECT gen_random_uuid() AS id'))[0].id;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code, first_login_at, last_login_at) VALUES ($1, $2, 'customer', $3, 'Pat Person', $4, $5, $5)`,
    [id, customerId, `pat-${unique()}@people.example.test`, status, signedIn ? new Date().toISOString() : null]);
  return id;
}
const manage = (customerId, userId, action, who = boss) => svc.post(`/v1/admin/customer-users/${customerId}/users/${userId}/${action}`, { reason: 'Asked by their IT team' }, who.as);
const statusOf = id => rows(svc.identityDb, 'SELECT status_code, deleted_at FROM app_user WHERE user_id = $1', [id]).then(r => r[0]);

test('an admin disables, enables, re-invites and removes a customer\'s user; their sessions end; each is on the record; users cannot; the wrong customer is 404', async () => {
  const l = await licence({ plan: 'team', seats: 5 });
  const cid = customerOf(l), other = customerOf(await licence({ plan: 'team', seats: 5 }));
  const u = await customerUser(cid);
  await svc.identityDb.query(`INSERT INTO session (session_id, user_id, refresh_token_hash, family_id, expires_at) VALUES (gen_random_uuid(), $1, $2, gen_random_uuid(), now() + interval '1 day')`, [u, 'a'.repeat(64)]);

  assert.equal((await manage(cid, u, 'disable', sam)).status, 403);
  assert.equal((await manage(other, u, 'disable')).status, 404, 'a user of another customer');
  assert.equal((await manage(cid, u, 'explode')).status, 404);
  assert.equal((await manage(cid, u, 'enable')).body.reason, 'wrong_state', 'cannot enable someone active');

  const dis = await manage(cid, u, 'disable');
  assert.deepEqual([dis.status, dis.body.from, dis.body.to], [200, 'ACTIVE', 'DISABLED']);
  assert.equal((await rows(svc.identityDb, 'SELECT count(*)::int AS n FROM session WHERE user_id = $1 AND revoked_at IS NULL', [u]))[0].n, 0, 'their sessions ended');
  assert.equal((await manage(cid, u, 'disable')).body.reason, 'wrong_state');
  assert.equal((await manage(cid, u, 'enable')).body.to, 'ACTIVE', 'they had signed in before: Active again');
  await manage(cid, u, 'disable');
  const re = await manage(cid, u, 'reinvite');
  assert.deepEqual([re.body.from, re.body.to], ['DISABLED', 'INVITED']);
  assert.equal((await manage(cid, u, 'reinvite')).status, 200, 'repeating is harmless');
  const rem = await manage(cid, u, 'remove');
  assert.deepEqual([rem.status, rem.body.removed], [200, true]);
  assert.ok((await statusOf(u)).deleted_at);
  assert.equal((await manage(cid, u, 'enable')).status, 404, 'a removed person is gone from the list');
  const list = (await svc.get(`/v1/admin/customer-users/${cid}`, boss.as)).body;
  assert.ok(!list.users.some(x => x.user_id === u), 'and from the customer\'s list');

  const never = await customerUser(cid, { status: 'DISABLED', signedIn: false });
  assert.equal((await manage(cid, never, 'enable')).body.to, 'INVITED', 'never signed in: still waiting to activate');
  const active = await customerUser(cid);
  assert.equal((await manage(cid, active, 'reinvite')).body.reason, 'wrong_state', 'an active person is not re-invited');

  const t = await trail('customer_user.disable', u);
  assert.ok(t.some(x => x.outcome === 'done' && x.detail.customerId === cid && x.detail.to === 'DISABLED'));
  assert.ok(!JSON.stringify(t).includes('people.example.test'), 'no address in the trail');
  const h = await rows(svc.identityDb, 'SELECT to_status_code, reason FROM user_status_history WHERE user_id = $1 ORDER BY changed_at', [u]);
  assert.ok(h.every(x => x.reason === 'Asked by their IT team' || x.reason === null || x.reason), 'the status history carries the reason');
  assert.equal((await svc.post(`/v1/admin/customer-users/${cid}/users/${u}/disable`, {}, boss.as)).status, 400, 'a reason is needed');
});
