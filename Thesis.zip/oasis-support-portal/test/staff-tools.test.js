'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { staffSignedIn, createRequest, createStaff, rows, unique } = require('./helpers/fixtures');

let svc, sam, lee, boss;
test.before(async () => {
  svc = await startService();
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  lee = await staffSignedIn(svc, { name: 'Lee Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
});
test.after(async () => { await svc.close(); });

const helpRequest = async (email = `help-${unique()}@people.example.test`, subject = 'Cannot connect') => (await rows(svc.supportDb,
  `INSERT INTO support_request (support_request_id, subject, message, contact_name, email) VALUES (gen_random_uuid(), $1, 'It fails with a token error', 'Hana Help', $2) RETURNING reference`, [subject, email]))[0].reference;
const bell = who => svc.get('/v1/admin/notifications', who.as);
const assign = (ref, who, by = boss, kind = 'purchase-requests') => svc.patch(`/v1/admin/${kind}/${ref}`, { reason: 'Handing it over', assignedTo: who.userId }, by.as);

test('the bell: being assigned a request notifies that person (not the admin, not twice), new requests are counted since they last looked, and "mark read" clears it', async () => {
  const first = await bell(lee);
  assert.deepEqual([first.status, first.body.unread, first.body.count], [200, 0, 0], 'the first look starts the clock: nothing is "new"');
  const pr = await createRequest(svc), sr = await helpRequest();
  const arrived = (await bell(lee)).body;
  assert.deepEqual(arrived.newRequests, { licenceRequests: 1, helpRequests: 1 });
  assert.equal(arrived.count, 2);

  const a = await assign(pr, lee);
  assert.equal(a.status, 200, JSON.stringify(a.body));
  assert.equal((await assign(pr, lee)).status, 200);
  assert.equal((await assign(sr, lee, boss, 'support-requests')).status, 200);
  const b = (await bell(lee)).body;
  assert.equal(b.unread, 2, 'one for each request; the repeat did not add another');
  assert.deepEqual(b.items.map(i => i.title).sort(), [`Help request ${sr} was assigned to you`, `Licence request ${pr} was assigned to you`]);
  assert.ok(b.items.every(i => i.read === false));
  assert.equal(b.count, 4);
  assert.equal((await bell(boss)).body.unread, 0, 'the admin who assigned it is not notified');
  assert.equal((await bell(sam)).body.unread, 0, 'and nobody else is');

  const own = await svc.patch(`/v1/admin/purchase-requests/${pr}`, { reason: 'Taking it myself', assignedTo: boss.userId }, boss.as);
  assert.equal(own.status, 200);
  assert.equal((await bell(boss)).body.unread, 0, 'assigning to yourself is not news');

  const read = await svc.post('/v1/admin/notifications/read', {}, lee.as);
  assert.deepEqual([read.status, read.body.marked], [200, 2]);
  const after = (await bell(lee)).body;
  assert.deepEqual([after.unread, after.count, after.newRequests], [0, 0, { licenceRequests: 0, helpRequests: 0 }]);
  assert.equal(after.items.length, 2);
  assert.ok(after.items.every(i => i.read));
  assert.equal((await svc.get('/v1/admin/notifications', {})).status, 401);
  assert.equal((await svc.post('/v1/admin/notifications/read', {}, {})).status, 401);
});

test('a failing notification never fails the assignment', async () => {
  const pr = await createRequest(svc);
  await svc.identityDb.query(`ALTER TABLE staff_notification RENAME TO staff_notification_x`);
  try { assert.equal((await assign(pr, sam)).status, 200); }
  finally { await svc.identityDb.query(`ALTER TABLE staff_notification_x RENAME TO staff_notification`); }
  assert.equal((await svc.get(`/v1/admin/purchase-requests/${pr}`, sam.as)).body.assigned_to_user_id, sam.userId);
});

test('replying: the message goes to the address on the request (never one the caller names), is recorded with the request, and says plainly when nothing could be delivered', async () => {
  const email = `pat-${unique()}@acme.example.test`;
  const pr = await createRequest(svc, { email });
  const before = svc.notifier.sent.length;
  const r = await svc.post(`/v1/admin/purchase-requests/${pr}/reply`, { body: 'Thanks for asking.\n\nCould you call us on Tuesday?', to: 'evil@attacker.example.test', subject: 'About your request\r\nBcc: x@y.test' }, sam.as);
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.equal(r.body.delivery, 'not_connected', 'no email provider yet: recorded, not delivered');
  const sent = svc.notifier.sent[svc.notifier.sent.length - 1];
  assert.equal(svc.notifier.sent.length, before + 1);
  assert.deepEqual([sent.kind, sent.to, sent.fromName, sent.reference], ['customer_reply', email, 'Sam Support', pr]);
  assert.ok(!/[\r\n]/.test(sent.subject), 'a line break in the subject cannot add a header');
  assert.equal(sent.body, 'Thanks for asking.\n\nCould you call us on Tuesday?');

  const d = (await svc.get(`/v1/admin/purchase-requests/${pr}`, sam.as)).body;
  assert.equal(d.replies.length, 1);
  assert.deepEqual([d.replies[0].by, d.replies[0].delivery], ['Sam Support', 'not_connected']);
  const dflt = await svc.post(`/v1/admin/purchase-requests/${pr}/reply`, { body: 'Second note' }, sam.as);
  assert.equal(dflt.status, 201);
  assert.equal(svc.notifier.sent[svc.notifier.sent.length - 1].subject, `Your OASIS licence request ${pr}`, 'a sensible default subject');

  for (const [body, reason] of [[{}, 'bad_reply'], [{ body: '   ' }, 'bad_reply'], [{ body: 5 }, 'bad_reply'], [{ body: 'x'.repeat(4001) }, 'bad_reply'], [{ body: 'ok', subject: 'x'.repeat(201) }, 'bad_subject'], [{ body: 'ok', subject: 5 }, 'bad_subject']]) {
    const x = await svc.post(`/v1/admin/purchase-requests/${pr}/reply`, body, sam.as);
    assert.equal(x.status, 400, JSON.stringify(body).slice(0, 40));
    assert.equal(x.body.reason, reason);
  }
  assert.equal((await svc.post('/v1/admin/purchase-requests/PR-999999/reply', { body: 'hi' }, sam.as)).status, 404);
  assert.equal((await svc.post('/v1/admin/purchase-requests/..%2Fx/reply', { body: 'hi' }, sam.as)).status, 404);
  assert.equal((await svc.post(`/v1/admin/purchase-requests/${pr}/reply`, { body: 'hi' }, {})).status, 401);
  const t = await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = 'purchase_request.reply' AND subject_ref = $1 AND outcome = 'done'`, [pr]);
  assert.equal(t.length, 2);
  assert.ok(!JSON.stringify(t).includes('Tuesday') && !JSON.stringify(t).includes('acme.example.test'), 'the trail holds the length and the outcome, never the words or the address');
});

test('a reply to a help request works the same way; a send that fails is recorded as failed; and a real provider\'s success is recorded as sent', async () => {
  const email = `hana-${unique()}@people.example.test`;
  const sr = await helpRequest(email, 'Token rejected');
  const r = await svc.post(`/v1/admin/support-requests/${sr}/reply`, { body: 'Try rotating the token.' }, sam.as);
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.equal(svc.notifier.sent[svc.notifier.sent.length - 1].subject, 'Re: Token rejected');
  assert.equal((await svc.get(`/v1/admin/support-requests/${sr}`, sam.as)).body.replies[0].body, 'Try rotating the token.');

  const original = svc.notifier.send;
  svc.notifier.send = async () => { throw new Error('provider down'); };
  try { assert.equal((await svc.post(`/v1/admin/support-requests/${sr}/reply`, { body: 'Another try' }, sam.as)).body.delivery, 'failed'); } finally { svc.notifier.send = original; }
  const kind = svc.notifier.kind;
  svc.notifier.kind = 'live';
  try { assert.equal((await svc.post(`/v1/admin/support-requests/${sr}/reply`, { body: 'Third' }, sam.as)).body.delivery, 'sent'); } finally { svc.notifier.kind = kind; }
  assert.deepEqual((await svc.get(`/v1/admin/support-requests/${sr}`, sam.as)).body.replies.map(x => x.delivery), ['not_connected', 'failed', 'sent']);
  await assert.rejects(svc.identityDb.query(`UPDATE customer_reply SET body = 'edited'`), /append-only|retention/i);
});

test('the workload page: one row per active team member with what they hold, the oldest wait and what they closed this week; one person\'s open list has references only', async () => {
  const a = await createStaff(svc, { name: 'Wendy Workload' });
  const { signIn } = require('./helpers/fixtures');
  const w = { userId: a.userId, email: a.email, as: { Authorization: `Bearer ${await signIn(svc, a.email)}` } };
  const p1 = await createRequest(svc), p2 = await createRequest(svc, { status: 'CONTACTED' }), p3 = await createRequest(svc, { status: 'AGREED' }), sr = await helpRequest();
  for (const ref of [p1, p2, p3]) await assign(ref, w);
  await assign(sr, w, boss, 'support-requests');

  const page = (await svc.get('/v1/admin/workload', sam.as)).body;
  const me = page.people.find(x => x.name === 'Wendy Workload');
  assert.deepEqual([me.licenceRequests, me.helpRequests, me.open, me.closedLast7Days], [2, 1, 3, 1]);
  assert.ok(me.oldestOpenHours >= 0 && me.oldestOpenHours < 1, 'just created: well under an hour');
  assert.equal(page.people[page.people.length - 1].name, 'Not assigned', 'unassigned work is last');
  assert.ok(page.people.every(x => !('email' in x)), 'no address on the page');
  const idx = page.people.map(x => x.open);
  assert.deepEqual(idx.slice(0, -1), [...idx.slice(0, -1)].sort((x, y) => y - x), 'busiest first');

  const mine = (await svc.get(`/v1/admin/workload/${w.userId}`, sam.as)).body;
  assert.deepEqual([mine.name, mine.licenceRequests.map(r => r.reference).sort(), mine.helpRequests.map(r => r.reference)], ['Wendy Workload', [p1, p2].sort(), [sr]]);
  assert.ok(!/@|contact_name|organization|"message"/i.test(JSON.stringify(mine)), 'references, statuses and times only');
  const none = (await svc.get('/v1/admin/workload/none', sam.as)).body;
  assert.equal(none.name, 'Not assigned');
  assert.equal((await svc.get('/v1/admin/workload/00000000-0000-0000-0000-000000000000', sam.as)).status, 404);
  assert.equal((await svc.get('/v1/admin/workload/not-an-id', sam.as)).status, 404);
  assert.equal((await svc.get('/v1/admin/workload', {})).status, 401);
});
