'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { createStaff, givePassword, TEST_PASSWORD } = require('./helpers/fixtures');

let svc;
test.before(async () => { svc = await startService(); });
test.after(async () => { await svc.close(); });

/** The browser's way in: email address and password with { cookie: true }. Returns the cookie header to send back, and the CSRF token. */
async function browserSignIn(opts = {}) {
  const s = await createStaff(svc, opts);
  await givePassword(svc, s.userId);
  const v = await svc.post('/v1/admin/auth/login', { email: s.email, password: TEST_PASSWORD, cookie: true });
  const setCookie = v.headers.get('set-cookie');
  return { ...s, v, setCookie, cookie: setCookie.split(';')[0], csrf: v.body.csrfToken };
}

test('a browser sign-in puts the session in an HttpOnly, SameSite=Strict cookie that the page cannot read; the answer carries no token', async () => {
  const b = await browserSignIn();
  assert.equal(b.v.status, 200);
  assert.equal(b.v.body.token, undefined, 'no bearer token for JavaScript to hold');
  assert.ok(b.v.body.csrfToken && b.v.body.user.email === b.email);
  for (const attr of ['HttpOnly', 'SameSite=Strict', 'Path=/v1', /Max-Age=28800/]) assert.match(b.setCookie, attr instanceof RegExp ? attr : new RegExp(attr));
  assert.ok(!/Secure/.test(b.setCookie), 'the test service runs on plain http, so the Secure flag is off here');
  assert.ok(!b.setCookie.includes(b.csrf), 'the CSRF token is not the cookie');
});

test('in production the cookie is Secure (https only)', async () => {
  const { createApp } = require('../src/app');
  const app = createApp({ identityDb: svc.identityDb, customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb, hashPepper: svc.hashPepper, licenceHashPepper: svc.licenceHashPepper,
    notifier: svc.notifier, limiter: (_q, _s, n) => n(), authLimiter: (_q, _s, n) => n(), log: () => {}, tls: true });          // secureCookies defaults to true; HSTS follows tls
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  try {
    const s = await createStaff(svc);
    const base = `http://127.0.0.1:${server.address().port}`;
    const post = (route, body) => fetch(`${base}${route}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    await givePassword(svc, s.userId);
    const r = await post('/v1/admin/auth/login', { email: s.email, password: TEST_PASSWORD, cookie: true });
    assert.match(r.headers.get('set-cookie'), /; Secure/);
  } finally { await new Promise(r => server.close(r)); }
});

test('the cookie signs the person in for reads; /auth/me hands back the CSRF token again after a page reload', async () => {
  const b = await browserSignIn();
  const me = await svc.get('/v1/admin/auth/me', { Cookie: b.cookie });
  assert.equal(me.status, 200);
  assert.equal(me.body.csrfToken, b.csrf, 'the same token, derived from the session, so a reload can recover it');
  assert.equal((await svc.get('/v1/admin/purchase-requests', { Cookie: b.cookie })).status, 200);
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: 'oasis_portal=nonsense' })).status, 401);
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: `other=${b.cookie.split('=')[1]}` })).status, 401, 'only the right cookie name counts');
});

test('a change made with the cookie alone is refused: it needs the CSRF token the portal page was given, and a matching origin', async () => {
  const b = await browserSignIn();
  const ref = (await svc.customerDb.query(`INSERT INTO purchase_request (purchase_request_id, organization_name, employee_count, contact_name, email) VALUES (gen_random_uuid(), 'Csrf Ltd', 5, 'Pat', 'csrf@example.test') RETURNING reference`)).rows[0].reference;
  const body = { status: 'CONTACTED', reason: 'Called' };
  const patch = headers => svc.patch(`/v1/admin/purchase-requests/${ref}`, body, headers);
  const noToken = await patch({ Cookie: b.cookie });
  assert.equal(noToken.status, 403); assert.equal(noToken.body.reason, 'bad_csrf');
  for (const bad of ['', 'x', b.csrf.slice(0, -1), `${b.csrf}x`, 'A'.repeat(64)]) assert.equal((await patch({ Cookie: b.cookie, 'X-CSRF-Token': bad })).body.reason, 'bad_csrf', bad);
  const other = await browserSignIn();
  assert.equal((await patch({ Cookie: b.cookie, 'X-CSRF-Token': other.csrf })).body.reason, 'bad_csrf', 'another session\'s token does not work');
  assert.equal((await svc.customerDb.query('SELECT status_code FROM purchase_request WHERE reference = $1', [ref])).rows[0].status_code, 'NEW');

  const foreign = await patch({ Cookie: b.cookie, 'X-CSRF-Token': b.csrf, Origin: 'https://evil.example.test' });
  assert.equal(foreign.status, 403); assert.equal(foreign.body.reason, 'bad_origin');
  const bogus = await patch({ Cookie: b.cookie, 'X-CSRF-Token': b.csrf, Origin: 'not a url' });
  assert.equal(bogus.body.reason, 'bad_origin');
  assert.equal((await svc.customerDb.query('SELECT status_code FROM purchase_request WHERE reference = $1', [ref])).rows[0].status_code, 'NEW');

  const ok = await patch({ Cookie: b.cookie, 'X-CSRF-Token': b.csrf, Origin: svc.base });
  assert.equal(ok.status, 200, JSON.stringify(ok.body));
  assert.equal((await svc.customerDb.query('SELECT status_code FROM purchase_request WHERE reference = $1', [ref])).rows[0].status_code, 'CONTACTED');
});

test('reads with a foreign origin are refused too, and a bearer token (an API client, not a browser) needs no CSRF token', async () => {
  const b = await browserSignIn();
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: b.cookie, Origin: 'https://evil.example.test' })).body.reason, 'bad_origin');
  const s = await createStaff(svc);
  await givePassword(svc, s.userId);
  const api = await svc.post('/v1/admin/auth/login', { email: s.email, password: TEST_PASSWORD });
  assert.ok(api.body.token && !api.headers.get('set-cookie'), 'without cookie: true the answer carries the token and sets no cookie');
  const ref = (await svc.customerDb.query(`INSERT INTO purchase_request (purchase_request_id, organization_name, employee_count, contact_name, email) VALUES (gen_random_uuid(), 'Api Ltd', 5, 'Pat', 'api@example.test') RETURNING reference`)).rows[0].reference;
  assert.equal((await svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'x' }, { Authorization: `Bearer ${api.body.token}` })).status, 200);
});

test('signing out ends the session on the server and clears the cookie', async () => {
  const b = await browserSignIn();
  const out = await svc.post('/v1/admin/auth/logout', {}, { Cookie: b.cookie, 'X-CSRF-Token': b.csrf });
  assert.equal(out.status, 200);
  assert.match(out.headers.get('set-cookie'), /oasis_portal=; .*Max-Age=0/);
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: b.cookie })).status, 401, 'the old cookie no longer works even if someone kept it');
  assert.equal((await svc.post('/v1/admin/auth/logout', {}, { Cookie: b.cookie, 'X-CSRF-Token': b.csrf })).status, 401);
});

test('a role change or a disable ends a browser session as it does a token session', async () => {
  const b = await browserSignIn();
  await svc.identityDb.query(`WITH r AS (SELECT set_config('app.reason', 'left', true)) UPDATE app_user SET status_code = 'DISABLED' FROM r WHERE user_id = $1`, [b.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: b.cookie })).status, 401);
});

test('CSRF edge cases: a token of the right length but non-ASCII is a refusal (not a crash), an absent Origin is judged by the token alone, and "Origin: null" is refused', async () => {
  const b = await browserSignIn();
  const ref = (await svc.customerDb.query(`INSERT INTO purchase_request (purchase_request_id, organization_name, employee_count, contact_name, email) VALUES (gen_random_uuid(), 'Edge Ltd', 5, 'Pat', 'edge@example.test') RETURNING reference`)).rows[0].reference;
  const patch = headers => svc.patch(`/v1/admin/purchase-requests/${ref}`, { status: 'CONTACTED', reason: 'x' }, headers);
  const nonAscii = await patch({ Cookie: b.cookie, 'X-CSRF-Token': '\u00e9'.repeat(b.csrf.length) });
  assert.equal(nonAscii.status, 403); assert.equal(nonAscii.body.reason, 'bad_csrf');
  assert.equal((await patch({ Cookie: b.cookie, Origin: 'null', 'X-CSRF-Token': b.csrf })).body.reason, 'bad_origin');
  assert.equal((await patch({ Cookie: b.cookie, 'X-CSRF-Token': b.csrf })).status, 200, 'no Origin header: the token alone decides');
});

test('a bearer token and a cookie are never mixed: an invalid bearer is refused even when a valid cookie is sent, and a valid bearer needs no CSRF token', async () => {
  const b = await browserSignIn();
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: 'Bearer not-a-real-token-at-all-0123456789', Cookie: b.cookie })).status, 401);
  const s = await createStaff(svc);
  await givePassword(svc, s.userId);
  const api = await svc.post('/v1/admin/auth/login', { email: s.email, password: TEST_PASSWORD });
  const mixed = await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${api.body.token}`, Cookie: b.cookie });
  assert.equal(mixed.body.email, s.email, 'the bearer decides, the cookie is ignored');
  assert.equal(mixed.body.csrfToken, undefined);
});

test('changing a role ends a browser session too', async () => {
  const b = await browserSignIn();
  await svc.identityDb.query('UPDATE user_role SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [b.userId]);
  await svc.identityDb.query(`INSERT INTO user_role (user_role_id, user_id, role_code) VALUES (gen_random_uuid(), $1, 'PLATFORM_ADMIN')`, [b.userId]);
  assert.equal((await svc.get('/v1/admin/auth/me', { Cookie: b.cookie })).status, 401, 'a session from before a new grant does not carry it');
});
