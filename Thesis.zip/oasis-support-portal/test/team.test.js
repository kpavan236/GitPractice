'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { startService } = require('./helpers/server');
const { staffSignedIn, signIn, unique, rows, lastLink, activateByLink, TEST_PASSWORD } = require('./helpers/fixtures');

let svc, boss, sam;
test.before(async () => {
  svc = await startService({ staffEmailDomains: ['staff.example.test'] });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  sam = await staffSignedIn(svc, { name: 'Sam User' });
});
test.after(async () => { await svc.close(); });

const addRaw = (body, who = boss) => svc.post('/v1/admin/users', { reason: 'Joined the support team', displayName: 'New Person', role: 'user', ...body }, who.as);
/** Adds a member and has them open the emailed link to activate (as most tests need someone who can sign in). */
const add = async (body, who = boss) => { const r = await addRaw(body, who); if (r.status === 201) await activateByLink(svc, r.body.email); return r; };
const patch = (id, body, who = boss) => svc.patch(`/v1/admin/users/${id}`, { reason: 'Team change', ...body }, who.as);
const fresh = () => `new-${unique()}@staff.example.test`;
const trail = (id, action) => rows(svc.identityDb, `SELECT outcome, detail, reason FROM admin_audit WHERE action = $1 AND subject_ref = $2 ORDER BY occurred_at`, [action, id]);

test('an admin adds a team member: they are Pending activation, an activation link is emailed, and they activate by choosing a password twice; the admin never sees the link or a password', async () => {
  const email = fresh();
  const r = await addRaw({ email: email.toUpperCase(), displayName: 'Nia  New', role: 'user' });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.deepEqual([r.body.email, r.body.displayName, r.body.role, r.body.status, r.body.lastLoginAt, r.body.emailed], [email, 'Nia New', 'user', 'INVITED', null, true]);
  assert.ok(!/password|token|link|http/i.test(JSON.stringify(r.body).replace('"emailed"', '')), 'nothing to read or copy in what the admin is shown');
  const mail = svc.notifier.sent.findLast(m => m.to === email);
  assert.deepEqual([mail.kind, mail.expiresInHours, mail.displayName], ['activation', 72, 'Nia New']);
  assert.match(mail.link, /^http:\/\/portal\.example\.test\/#\/activate\/[A-Za-z0-9_-]{43}$/, 'the secret is in the fragment, so it never reaches a server log or a Referer');

  assert.equal((await svc.post('/v1/admin/auth/login', { email, password: 'whatever password they guess' })).body.reason, 'bad_credentials', 'Pending: cannot sign in');
  const { token } = lastLink(svc, email);
  assert.deepEqual((await svc.post('/v1/admin/auth/link/check', { token })).body, { purpose: 'activate', email, displayName: 'Nia New' });
  const chosen = 'the password nia chose herself';
  assert.equal((await svc.post('/v1/admin/auth/link/complete', { token, newPassword: chosen, confirmPassword: 'a different one entirely' })).body.reason, 'password_mismatch', 'both fields must match');
  assert.equal((await svc.post('/v1/admin/auth/link/complete', { token, newPassword: 'short', confirmPassword: 'short' })).body.reason, 'weak_password');
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE email = $1', [email]))[0].status_code, 'INVITED', 'still Pending after those refusals');
  const done = await svc.post('/v1/admin/auth/link/complete', { token, newPassword: chosen, confirmPassword: chosen });
  assert.deepEqual(done.body, { ok: true, purpose: 'activate' });
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE email = $1', [email]))[0].status_code, 'ACTIVE');
  assert.equal((await svc.post('/v1/admin/auth/link/complete', { token, newPassword: chosen, confirmPassword: chosen })).body.reason, 'bad_link', 'the link works once');

  const login = await svc.post('/v1/admin/auth/login', { email, password: chosen });
  assert.equal(login.status, 200, 'and then they can sign in');
  const me = await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${login.body.token}` });
  assert.deepEqual(me.body.roles, ['SUPPORT']);
  assert.ok(me.body.permissions.includes('CUSTOMER_UPDATE') && !me.body.permissions.includes('USER_MANAGE') && !me.body.permissions.includes('REQUEST_ASSIGN'));
  const h = await rows(svc.identityDb, 'SELECT to_status_code, reason FROM user_status_history WHERE user_id = $1 ORDER BY changed_at', [r.body.id]);
  assert.deepEqual(h.map(x => x.to_status_code), ['INVITED', 'ACTIVE'], 'the status history records the activation');
  const [u] = await rows(svc.identityDb, 'SELECT user_type_code, status_code, customer_id FROM app_user WHERE email = $1', [email]);
  assert.equal(u.user_type_code, 'staff');
  const adm = await add({ email: fresh(), role: 'admin' });
  assert.equal(adm.body.role, 'admin');
  const admMe = await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${await signIn(svc, adm.body.email)}` });
  assert.ok(admMe.body.permissions.includes('USER_MANAGE') && admMe.body.permissions.includes('REQUEST_ASSIGN') && admMe.body.permissions.includes('AUDIT_READ'));
});

test('the team list shows name, role, status and last sign-in; active members first', async () => {
  const gone = await add({ email: fresh(), displayName: 'Zed Gone' });
  await patch(gone.body.id, { status: 'DISABLED', reason: 'Left' });
  const r = await svc.get('/v1/admin/users', boss.as);
  assert.equal(r.status, 200);
  const list = r.body.users;
  assert.deepEqual(Object.keys(list[0]).sort(), ['createdAt', 'displayName', 'email', 'id', 'lastLoginAt', 'role', 'status']);
  const bo = list.find(u => u.id === boss.userId);
  assert.deepEqual([bo.role, bo.status, !!bo.lastLoginAt], ['admin', 'ACTIVE', true]);
  assert.ok(list.findIndex(u => u.id === gone.body.id) > list.findIndex(u => u.id === boss.userId), 'disabled members after active ones');
  assert.ok(!list.some(u => u.role === null), 'only staff, and only those with a staff role, are listed');
});

test('only admins reach the team: a user is refused (403), nobody signed in is 401', async () => {
  const call = (method, path, body, headers) => (method === 'get' ? svc.get(path, headers) : svc[method](path, body, headers));
  for (const [method, path, body] of [['get', '/v1/admin/users'], ['post', '/v1/admin/users', { reason: 'x', email: fresh(), displayName: 'X', role: 'user' }], ['patch', `/v1/admin/users/${boss.userId}`, { reason: 'x', role: 'user' }]]) {
    const r = await call(method, path, body, sam.as);
    assert.equal(r.status, 403, `${method} ${path}`); assert.equal(r.body.reason, 'forbidden');
    assert.equal((await call(method, path, body, {})).status, 401);
  }
  assert.equal((await rows(svc.identityDb, 'SELECT role_code FROM user_role WHERE user_id = $1 AND revoked_at IS NULL', [boss.userId]))[0].role_code, 'PLATFORM_ADMIN');
});

test('adding someone: a reason, a work address on the allowed domain, a name and a real role are all required; duplicates are refused', async () => {
  const email = fresh();
  assert.equal((await add({ email })).status, 201);
  const dup = await add({ email: email.toUpperCase() });
  assert.equal(dup.status, 409); assert.equal(dup.body.reason, 'user_exists');
  const cases = [
    [{ email: 'not-an-email' }, 'bad_email'], [{ email: 'a\u0000b@staff.example.test' }, 'bad_email'], [{ email: 5 }, 'bad_email'], [{ email: 'someone@gmail.com' }, 'bad_email_domain'], [{ email: 'x@staff.example.test.evil.test' }, 'bad_email_domain'],
    [{ email: fresh(), displayName: '' }, 'bad_name'], [{ email: fresh(), displayName: 'x'.repeat(151) }, 'bad_name'], [{ email: fresh(), displayName: 5 }, 'bad_name'],
    [{ email: fresh(), role: 'owner' }, 'bad_role'], [{ email: fresh(), role: 'PLATFORM_ADMIN' }, 'bad_role'], [{ email: fresh(), role: 5 }, 'bad_role'], [{ email: fresh(), role: undefined }, 'bad_role'],
    [{ email: fresh(), reason: '' }, 'reason_required'], [{ email: fresh(), reason: 'x'.repeat(501) }, 'reason_too_long'],
  ];
  for (const [body, reason] of cases) {
    const r = await add(body);
    assert.equal(r.status, 400, JSON.stringify(body).slice(0, 50)); assert.equal(r.body.reason, reason, JSON.stringify(body).slice(0, 50));
  }
  const before = (await rows(svc.identityDb, `SELECT count(*)::int AS n FROM app_user`))[0].n;
  await add({ email: 'x@nowhere.test' });
  assert.equal((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM app_user`))[0].n, before, 'a refused add creates nothing');
});

test('changing a role: the person\'s old sessions end and the new permissions apply at their next sign-in; the change is on record with who and why', async () => {
  const m = await add({ email: fresh(), displayName: 'Rae Role', role: 'user' });
  const token = await signIn(svc, m.body.email);
  const r = await patch(m.body.id, { role: 'admin', reason: 'Promoted to team lead' });
  assert.equal(r.status, 200); assert.equal(r.body.role, 'admin');
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${token}` })).status, 401, 'the old session ended');
  const again = await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${await signIn(svc, m.body.email)}` });
  assert.ok(again.body.permissions.includes('USER_MANAGE'));
  const grants = await rows(svc.identityDb, 'SELECT role_code, granted_by_user_id, revoked_at, revoked_by_user_id FROM user_role WHERE user_id = $1 ORDER BY granted_at', [m.body.id]);
  assert.deepEqual(grants.map(g => g.role_code), ['SUPPORT', 'PLATFORM_ADMIN']);
  assert.ok(grants[0].revoked_at && grants[0].revoked_by_user_id === boss.userId && grants[1].granted_by_user_id === boss.userId && grants[1].revoked_at === null);
  const t = await trail(m.body.id, 'user.update');
  assert.deepEqual(t.map(x => x.outcome), ['started', 'done']);
  assert.deepEqual([t[1].detail.fromRole, t[1].detail.toRole], ['user', 'admin']);
  assert.equal(t[1].reason, 'Promoted to team lead');
});

test('disabling stops a team member at once and ends their sessions; enabling lets them sign in again; the status history says who and why', async () => {
  const m = await add({ email: fresh(), role: 'user' });
  const token = await signIn(svc, m.body.email);
  assert.equal((await patch(m.body.id, { status: 'disabled', reason: 'Left the team' })).body.status, 'DISABLED');
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${token}` })).status, 401);
  const before = svc.notifier.sent.length;
  await svc.post('/v1/admin/auth/password/forgot', { email: m.body.email });
  assert.equal(svc.notifier.sent.length, before, 'a deactivated member gets no link');
  assert.equal((await rows(svc.identityDb, `SELECT revoke_reason FROM session WHERE user_id = $1`, [m.body.id]))[0].revoke_reason, 'user_disabled');
  assert.equal((await patch(m.body.id, { status: 'ACTIVE', reason: 'Back from leave' })).body.status, 'ACTIVE');
  assert.ok(await signIn(svc, m.body.email));
  const h = await rows(svc.identityDb, 'SELECT to_status_code, reason, changed_by_user_id FROM user_status_history WHERE user_id = $1 ORDER BY changed_at', [m.body.id]);
  assert.deepEqual(h.map(x => [x.to_status_code, x.reason]), [['INVITED', 'Joined the support team'], ['ACTIVE', 'Activated their account from the emailed link'], ['DISABLED', 'Left the team'], ['ACTIVE', 'Back from leave']]);
  assert.equal(h[2].changed_by_user_id, boss.userId);
});

test('a name can be corrected; an empty change, a bad status and an unknown or customer user are refused', async () => {
  const m = await add({ email: fresh(), displayName: 'Typo Nme' });
  assert.equal((await patch(m.body.id, { displayName: 'Typo Name' })).body.displayName, 'Typo Name');
  for (const [body, reason] of [[{}, 'nothing_to_change'], [{ reason: 'only a reason' }, 'nothing_to_change'], [{ status: 'DELETED' }, 'bad_status'], [{ status: 5 }, 'bad_status'], [{ role: 'root' }, 'bad_role'], [{ displayName: '' }, 'bad_name']]) {
    const r = await patch(m.body.id, body);
    assert.equal(r.status, 400, JSON.stringify(body)); assert.equal(r.body.reason, reason);
  }
  const customer = (await rows(svc.identityDb, 'SELECT gen_random_uuid() AS id'))[0].id;
  await svc.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, status_code) VALUES ($1, gen_random_uuid(), 'customer', 'cust@example.test', 'ACTIVE')`, [customer]);
  for (const id of [crypto.randomUUID(), customer, 'x', '..']) assert.equal((await patch(id, { displayName: 'X' })).status, 404, id);
});

test('nobody can change their own role or status, and the last active admin can never be demoted or disabled', async () => {
  const self = await patch(boss.userId, { role: 'user' });
  assert.equal(self.status, 409); assert.equal(self.body.reason, 'cannot_change_self');
  assert.equal((await patch(boss.userId, { status: 'DISABLED' })).body.reason, 'cannot_change_self');
  assert.equal((await patch(boss.userId, { displayName: 'Bo The Admin' })).status, 200, 'renaming yourself is fine');
  assert.equal((await patch(boss.userId, { role: 'admin' })).status, 200, 'and "changing" to what you already are is a no-op');

  // Only two admins now: each tries to remove the other at the same time. Exactly one may succeed; one admin must remain.
  const other = await add({ email: fresh(), role: 'admin' });
  const otherSession = { as: { Authorization: `Bearer ${await signIn(svc, other.body.email)}` } };
  for (const u of (await svc.get('/v1/admin/users', boss.as)).body.users.filter(x => x.role === 'admin' && x.status === 'ACTIVE' && ![boss.userId, other.body.id].includes(x.id))) await patch(u.id, { status: 'DISABLED' });
  const results = await Promise.all([patch(other.body.id, { status: 'DISABLED', reason: 'A removes B' }, boss), patch(boss.userId, { role: 'user', reason: 'B removes A' }, otherSession)]);
  // If A wins first, B is disabled and B's request is refused at the door (401), or reaches the lock and is refused as the last admin (409): either way exactly one succeeds.
  assert.equal(results.filter(r => r.status === 200).length, 1, JSON.stringify(results.map(r => [r.status, r.body.reason])));
  assert.ok(results.filter(r => r.status !== 200).every(r => [401, 409].includes(r.status)));
  const admins = await rows(svc.identityDb, `SELECT count(*)::int AS n FROM app_user u WHERE u.status_code = 'ACTIVE' AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = 'PLATFORM_ADMIN')`);
  assert.equal(admins[0].n, 1, 'one admin remains');
});

test('every team change is audited before it is made, with ids and roles but not the address or the name; a refusal is audited as failed', async () => {
  const admin2 = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Audit Admin' });
  const email = fresh();
  const m = await add({ email, displayName: 'Distinctive Name' }, admin2);
  await patch(m.body.id, { role: 'admin' }, admin2);
  await patch(admin2.userId, { role: 'user' }, admin2);
  const t = await rows(svc.identityDb, `SELECT action, outcome, detail FROM admin_audit WHERE actor_user_id = $1 AND action LIKE 'user.%' ORDER BY occurred_at`, [admin2.userId]);
  assert.deepEqual(t.map(x => `${x.action}:${x.outcome}`), ['user.create:started', 'user.create:done', 'user.update:started', 'user.update:done', 'user.update:started', 'user.update:failed']);
  assert.deepEqual(t[1].detail, { userId: m.body.id, role: 'user' });
  assert.equal(t[5].detail.error, 'cannot_change_self');
  assert.ok(!JSON.stringify(t).includes(email) && !JSON.stringify(t).includes('Distinctive'));
});

test('if the audit cannot be written, nobody is added', async () => {
  const broken = await startService({ dbs: { customerDb: svc.customerDb, licenseDb: svc.licenseDb, supportDb: svc.supportDb, identityDb: {
    query: (sql, params) => (/INSERT INTO admin_audit/.test(sql) ? Promise.reject(new Error('audit store down')) : svc.identityDb.query(sql, params)),
    connect: () => svc.identityDb.connect() } } });
  try {
    const email = fresh();
    const r = await broken.post('/v1/admin/users', { reason: 'x', email, displayName: 'Ghost', role: 'user' }, boss.as);
    assert.equal(r.status, 500);
    assert.equal((await rows(svc.identityDb, 'SELECT count(*)::int AS n FROM app_user WHERE email = $1', [email]))[0].n, 0);
  } finally { await broken.close(); }
});

test('two people adding the same address at once: one is added, the other is told it exists (never a 500)', async () => {
  const email = fresh();
  const results = await Promise.all([add({ email }), add({ email }), add({ email })]);
  assert.deepEqual(results.map(r => r.status).sort(), [201, 409, 409]);
  assert.ok(results.filter(r => r.status === 409).every(r => r.body.reason === 'user_exists'));
});

test('the last-admin lock, deterministically: two requests that would each remove one of the only two admins, made at the same moment by someone who is not one of them', async () => {
  const { createUsers } = require('../src/users');
  const users = createUsers({ identityDb: svc.identityDb, platformCustomerId: require('./helpers/fixtures').PLATFORM_CUSTOMER });
  // Leave exactly two active admins, X and Y.
  for (const u of (await svc.get('/v1/admin/users', boss.as)).body.users.filter(x => x.role === 'admin' && x.status === 'ACTIVE' && x.id !== boss.userId)) await patch(u.id, { status: 'DISABLED', reason: 'tidy' });
  const x = (await add({ email: fresh(), role: 'admin' })).body, y = (await add({ email: fresh(), role: 'admin' })).body;
  await patch(boss.userId, { role: 'admin' });                       // no-op, boss stays an admin
  await svc.identityDb.query(`UPDATE user_role SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [boss.userId]);      // boss is no longer an admin, so X and Y are the only two
  const outsider = { userId: boss.userId };
  const results = await Promise.allSettled(Array.from({ length: 6 }, (_, i) => users.update(i % 2 ? x.id : y.id, { status: 'DISABLED' }, 'removing', outsider)));
  const ok = results.filter(r => r.status === 'fulfilled'), refused = results.filter(r => r.status === 'rejected');
  assert.ok(refused.every(r => r.reason.reason === 'last_admin' || r.reason.reason === undefined), JSON.stringify(refused.map(r => r.reason.message)));
  const stillAdmins = await rows(svc.identityDb, `SELECT count(*)::int AS n FROM app_user u WHERE u.status_code = 'ACTIVE' AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = 'PLATFORM_ADMIN')`);
  assert.equal(stillAdmins[0].n, 1, 'exactly one admin is left');
  assert.ok(ok.length >= 1);
  await svc.identityDb.query(`INSERT INTO user_role (user_role_id, user_id, role_code) VALUES (gen_random_uuid(), $1, 'PLATFORM_ADMIN')`, [boss.userId]);   // put boss back for any later test
});

test('an admin can send an activation link to someone still Pending, and a reset link to someone Active; a newer link replaces the older; never to a deactivated member', async () => {
  const boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Fresh Admin' });
  const email = fresh();
  const m = await addRaw({ email }, boss);
  const first = lastLink(svc, email).token;
  const send = (id, who = boss) => svc.post(`/v1/admin/users/${id}/send-link`, { reason: 'They did not get the first email' }, who.as);

  const again = await send(m.body.id);
  assert.deepEqual([again.status, again.body.purpose, again.body.emailed], [200, 'activate', true]);
  assert.equal((await svc.post('/v1/admin/auth/link/check', { token: first })).body.reason, 'bad_link', 'the first link no longer works');
  assert.equal((await svc.post('/v1/admin/auth/link/check', { token: lastLink(svc, email).token })).status, 200);
  assert.ok(!JSON.stringify(again.body).includes(lastLink(svc, email).token), 'the admin is told it was sent, never given the link');
  await activateByLink(svc, email);

  const reset = await send(m.body.id);
  assert.deepEqual([reset.status, reset.body.purpose], [200, 'reset']);
  const mail = svc.notifier.sent.findLast(x => x.to === email);
  assert.deepEqual([mail.kind, mail.expiresInHours], ['password_reset', 1]);
  assert.match(mail.link, /#\/reset\//);

  await svc.patch(`/v1/admin/users/${m.body.id}`, { status: 'DISABLED', reason: 'Left' }, boss.as);
  assert.equal((await send(m.body.id)).body.reason, 'wrong_state', 'a deactivated member needs activating first');
  assert.equal((await svc.post('/v1/admin/auth/link/check', { token: lastLink(svc, email).token })).body.reason, 'bad_link', 'a link sent before deactivation is dead');

  assert.equal((await send('00000000-0000-0000-0000-000000000000')).status, 404);
  assert.equal((await send(m.body.id, sam)).status, 403, 'only admins');
  assert.equal((await svc.post(`/v1/admin/users/${m.body.id}/send-link`, {}, boss.as)).status, 400, 'and with a reason');
  const t = await trail(m.body.id, 'user.send_link');
  assert.deepEqual(t.map(x => x.outcome), ['started', 'done', 'started', 'done', 'started', 'failed']);
  assert.ok(!/http|portal\.example|token/i.test(JSON.stringify(t)), 'the trail never holds a link');
});

test('deactivating blocks sign-in at once; activating someone who never chose a password sends them back to Pending with a fresh link', async () => {
  const boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Fresh Admin' });
  const patch = (id, body) => svc.patch(`/v1/admin/users/${id}`, { reason: 'Team change', ...body }, boss.as);
  const email = fresh();
  const m = await addRaw({ email }, boss);
  const old = lastLink(svc, email).token;
  assert.equal((await patch(m.body.id, { status: 'DISABLED', reason: 'Offer withdrawn' })).body.status, 'DISABLED');
  assert.equal((await svc.post('/v1/admin/auth/link/complete', { token: old, newPassword: TEST_PASSWORD, confirmPassword: TEST_PASSWORD })).body.reason, 'bad_link', 'the activation link of a deactivated account is dead');

  const before = svc.notifier.sent.length;
  const back = await patch(m.body.id, { status: 'ACTIVE', reason: 'Offer back on' });
  assert.equal(back.body.status, 'INVITED', 'never chose a password: Pending activation, not Active');
  assert.equal(back.body.emailed, true);
  assert.equal(svc.notifier.sent.length, before + 1);
  assert.notEqual(lastLink(svc, email).token, old);
  await activateByLink(svc, email);
  assert.equal((await rows(svc.identityDb, 'SELECT status_code FROM app_user WHERE email = $1', [email]))[0].status_code, 'ACTIVE');

  assert.equal((await patch(m.body.id, { status: 'DISABLED', reason: 'Left' })).body.status, 'DISABLED');
  assert.equal((await svc.post('/v1/admin/auth/login', { email, password: TEST_PASSWORD })).body.reason, 'bad_credentials', 'Deactivated: cannot sign in');
  assert.equal((await patch(m.body.id, { status: 'ACTIVE', reason: 'Back' })).body.status, 'ACTIVE', 'someone who has a password goes straight back to Active');
  assert.equal((await svc.post('/v1/admin/auth/login', { email, password: TEST_PASSWORD })).status, 200);
});

test('an admin can correct a member\'s name and email address: sessions end, a pending member gets a fresh link at the new address, the old address is released; never your own; same rules as adding', async () => {
  const boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Edit Admin' });
  const patch = (id, body) => svc.patch(`/v1/admin/users/${id}`, { reason: 'Corrected a typo', ...body }, boss.as);
  const oldEmail = fresh(), newEmail = fresh();
  const m = await add({ email: oldEmail, displayName: 'Typo Persn' }, boss);
  const token = await signIn(svc, oldEmail);
  const r = await patch(m.body.id, { displayName: 'Correct Person', email: newEmail.toUpperCase() });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.email, r.body.displayName, r.body.status], [newEmail, 'Correct Person', 'ACTIVE']);
  assert.equal((await svc.get('/v1/admin/auth/me', { Authorization: `Bearer ${token}` })).status, 401, 'signed in as the old address: signed out');
  assert.equal((await svc.post('/v1/admin/auth/login', { email: oldEmail, password: TEST_PASSWORD })).status, 400, 'the old address no longer signs in');
  assert.equal((await svc.post('/v1/admin/auth/login', { email: newEmail, password: TEST_PASSWORD })).status, 200, 'the password stays; the new address signs in');
  assert.equal((await addRaw({ email: oldEmail }, boss)).status, 201, 'the old address is free to be used again');

  const pendingEmail = fresh(), fixed = fresh();
  const p = await addRaw({ email: pendingEmail }, boss);
  const oldLink = lastLink(svc, pendingEmail).token;
  assert.equal((await patch(p.body.id, { email: fixed })).status, 200);
  assert.equal((await svc.post('/v1/admin/auth/link/check', { token: oldLink })).body.reason, 'bad_link', 'the link sent to the old address is withdrawn');
  const fresh_ = lastLink(svc, fixed, 'activation');
  assert.ok(fresh_, 'and a new activation link went to the corrected address');
  assert.equal((await svc.post('/v1/admin/auth/link/check', { token: fresh_.token })).body.email, fixed);

  for (const [body, reason] of [[{ email: 'not-an-email' }, 'bad_email'], [{ email: 'x@nowhere.test' }, 'bad_email_domain'], [{ email: 5 }, 'bad_email'], [{ email: fresh() + ',other@staff.example.test' }, 'bad_email']]) {
    assert.equal((await patch(m.body.id, body)).body.reason, reason, JSON.stringify(body));
  }
  assert.equal((await patch(m.body.id, { email: fixed })).body.reason, 'user_exists', 'an address that belongs to someone else');
  const self = await svc.patch(`/v1/admin/users/${boss.userId}`, { reason: 'x', email: fresh() }, boss.as);
  assert.equal(self.body.reason, 'cannot_change_self');
  assert.equal((await patch(m.body.id, { displayName: 'Same Again', email: newEmail })).status, 200, 'the same address is not a change');
  const t = await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = 'user.update' AND subject_ref = $1 AND outcome = 'done' ORDER BY occurred_at`, [m.body.id]);
  assert.equal(t[0].detail.emailChanged, true);
  assert.ok(!JSON.stringify(t).includes('@'), 'the trail records that the address changed, never the address');
});
