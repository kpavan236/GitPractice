'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { startBillingService } = require('./helpers/billing-service');
const { createBillingClient } = require('../src/billing-client');
const { staffSignedIn, rows } = require('./helpers/fixtures');
const { uuidv7 } = require('../src/uuid');

let svc, bs, sam, boss;
const invoiceBody = (o = {}) => ({
  customerId: uuidv7(),
  billTo: { name: 'Example Public School', line1: '1 Example Road', city: 'Pune', countryCode: 'IN' },
  lines: [{ description: 'Licence, 25 seats', quantity: 25, unitPriceMinor: 40000 }],
  dueOn: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10), ...o,
});

test.before(async () => {
  bs = await startBillingService();
  svc = await startService({ billing: createBillingClient({ baseUrl: bs.url, serviceKey: bs.key }) });
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
});
test.after(async () => { await svc.close(); await bs.close(); });

const create = (o, who = sam, headers = {}) => svc.post('/v1/admin/invoices', invoiceBody(o), { ...who.as, ...headers });
const issued = async who => { const id = (await create({}, who)).body.invoice.invoiceId; await svc.post(`/v1/admin/invoices/${id}/issue`, {}, who.as); return id; };
const trail = (action, subject) => rows(svc.identityDb, `SELECT outcome, reason, detail FROM admin_audit WHERE action = $1 AND subject_ref = $2 ORDER BY occurred_at`, [action, subject]);

test('billing status says it is on, and every route needs a signed-in staff member', async () => {
  assert.deepEqual((await svc.get('/v1/admin/billing/status', sam.as)).body, { enabled: true, currency: 'INR', shareLinkDefaultDays: 14 });
  assert.equal((await svc.get('/v1/admin/billing/status')).status, 401);
  assert.equal((await svc.get('/v1/admin/invoices')).status, 401);
  assert.equal((await svc.post('/v1/admin/invoices', invoiceBody())).status, 401);
});

test('a user creates a draft; they own it; names are resolved; the trail has the id and no money or names', async () => {
  const r = await create();
  assert.equal(r.status, 201);
  const inv = r.body.invoice;
  assert.equal(inv.status, 'DRAFT'); assert.equal(inv.ownerUserId, sam.userId); assert.equal(r.body.names[sam.userId], 'Sam Support');
  const t = await trail('invoice.create', inv.invoiceId);
  assert.deepEqual(t.map(x => x.outcome), ['done']);                     // the "started" row is written before the invoice has an id, so it has no subject
  assert.ok((await rows(svc.identityDb, `SELECT count(*)::int AS n FROM admin_audit WHERE action = 'invoice.create' AND outcome = 'started'`))[0].n >= 1);
  const all = JSON.stringify(t);
  for (const secret of ['Example Public School', 'Licence, 25 seats', '40000', '1000000']) assert.ok(!all.includes(secret), secret);
});

test('the detail page carries names for everyone in it, and a person who has left is just absent from names', async () => {
  const id = await issued(sam);
  await svc.post(`/v1/admin/invoices/${id}/owner`, { toUserId: boss.userId, reason: 'Handover' }, boss.as);
  const d = (await svc.get(`/v1/admin/invoices/${id}`, boss.as)).body;
  assert.equal(d.names[sam.userId], 'Sam Support');
  assert.ok(d.names[sam.userId] && d.names[boss.userId]);
  const gone = uuidv7();
  await bs.db.query('UPDATE invoice SET owner_user_id = $2 WHERE invoice_id = $1', [id, gone]);
  const d2 = (await svc.get(`/v1/admin/invoices/${id}`, boss.as)).body;
  assert.equal(d2.invoice.ownerUserId, gone); assert.equal(d2.names[gone], undefined);
  assert.equal((await trail('invoice.view', id)).length, 2);                // every look at personal data is recorded
});

test('permissions: a user cannot void, credit or void a payment (403 from the portal); an admin can; a reason is required', async () => {
  const id = await issued(sam);
  assert.equal((await svc.post(`/v1/admin/invoices/${id}/void`, { reason: 'x' }, sam.as)).status, 403);
  assert.equal((await svc.post(`/v1/admin/invoices/${id}/credit-notes`, { amountMinor: 100, reason: 'x' }, sam.as)).status, 403);
  assert.equal((await svc.post(`/v1/admin/invoices/${id}/void`, {}, boss.as)).body.reason, 'reason_required');
  const v = await svc.post(`/v1/admin/invoices/${id}/void`, { reason: 'Raised to the wrong district' }, boss.as);
  assert.equal(v.status, 200); assert.equal(v.body.invoice.status, 'VOID');
  assert.equal((await trail('invoice.void', id)).at(-1).reason, 'Raised to the wrong district');
});

test('issue, mark sent, pay: partial then full; the receipt comes back; a double submit with one key pays once', async () => {
  const id = await issued(sam);
  assert.equal((await svc.post(`/v1/admin/invoices/${id}/mark-sent`, { channel: 'email', note: 'Sent to the finance office' }, sam.as)).body.invoice.status, 'SENT');
  const h = { 'Idempotency-Key': 'portal-pay-key-1' };
  const a = await svc.post(`/v1/admin/invoices/${id}/payments`, { amountMinor: 400000, method: 'bank_transfer', reference: 'SYNTH-REF' }, { ...sam.as, ...h });
  const b = await svc.post(`/v1/admin/invoices/${id}/payments`, { amountMinor: 400000, method: 'bank_transfer', reference: 'SYNTH-REF' }, { ...sam.as, ...h });
  assert.equal(a.status, 201); assert.match(a.body.payment.receiptNumber, /^RCT-/); assert.equal(b.body.payment.paymentId, a.body.payment.paymentId);
  assert.equal((await svc.get(`/v1/admin/invoices/${id}`, sam.as)).body.payments.length, 1);
  const over = await svc.post(`/v1/admin/invoices/${id}/payments`, { amountMinor: 700000, method: 'po' }, sam.as);
  assert.equal(over.status, 409); assert.equal(over.body.reason, 'payment_exceeds_balance'); assert.equal(over.body.balanceMinor, 600000);
  const done = await svc.post(`/v1/admin/invoices/${id}/payments`, { amountMinor: 600000, method: 'po' }, sam.as);
  assert.equal(done.body.invoice.status, 'PAID');
  const pt = JSON.stringify(await trail('payment.record', id));
  for (const secret of ['SYNTH-REF', '400000', '600000']) assert.ok(!pt.includes(secret), secret);
});

test('a share link: the URL comes back once, and it is nowhere in the audit trail or the detail page', async () => {
  const id = await issued(sam);
  const r = await svc.post(`/v1/admin/invoices/${id}/links`, { days: 7 }, sam.as);
  assert.equal(r.status, 201);
  const token = r.body.link.url.split('/i/')[1];
  assert.match(token, /^[A-Za-z0-9_-]{43}$/);
  assert.ok(!JSON.stringify(await trail('link.create', id)).includes(token));
  assert.ok(!(await svc.get(`/v1/admin/invoices/${id}`, sam.as)).text.includes(token));
  const page = await fetch(r.body.link.url);
  assert.equal(page.status, 200);
  assert.equal((await svc.post(`/v1/admin/invoices/${id}/links/${r.body.link.linkId}/revoke`, {}, sam.as)).status, 200);
  assert.equal((await fetch(r.body.link.url)).status, 404);
});

test('only the filters the portal knows are forwarded to billing', async () => {
  const seen = [];
  const spy = new Proxy(createBillingClient({ baseUrl: bs.url, serviceKey: bs.key }), { get: (t, k) => (k === 'listInvoices' ? (actor, query) => { seen.push({ actor, query }); return t.listInvoices(actor, query); } : t[k]) });
  const s2 = await startService({ billing: spy, dbs: svc });
  try {
    const who = { Authorization: `Bearer ${sam.token}` };
    await s2.get(`/v1/admin/invoices?status=SENT&ownerId=${sam.userId}&bucket=61%2B&evil=1&__proto__=x&limit=5`, who);
    assert.deepEqual(Object.keys(seen[0].query).sort(), ['bucket', 'limit', 'ownerId', 'status']);
    assert.deepEqual(seen[0].actor, { userId: sam.userId, role: 'user' });
    await s2.get('/v1/admin/invoices', { Authorization: `Bearer ${boss.token}` });
    assert.equal(seen[1].actor.role, 'admin');
  } finally { await s2.close(); }
});

test('ids that are not ids are a 404 before billing is asked; unknown ids are 404 from billing', async () => {
  assert.equal((await svc.get('/v1/admin/invoices/not-an-id', sam.as)).status, 404);
  assert.equal((await svc.post('/v1/admin/invoices/not-an-id/issue', {}, sam.as)).status, 404);
  assert.equal((await svc.get(`/v1/admin/invoices/${uuidv7()}`, sam.as)).status, 404);
});

test('billing switched off: 503 billing_not_configured, status says so', async () => {
  const off = await startService({ dbs: svc });
  try {
    assert.deepEqual((await off.get('/v1/admin/billing/status', sam.as)).body, { enabled: false });
    const r = await off.get('/v1/admin/invoices', sam.as);
    assert.equal(r.status, 503); assert.equal(r.body.reason, 'billing_not_configured');
  } finally { await off.close(); }
});

test('billing down or refusing the portal: 502, never a 401 (which would sign the person out) and never a 500', async () => {
  const wrongKey = await startService({ billing: createBillingClient({ baseUrl: bs.url, serviceKey: 'w'.repeat(40) }), dbs: svc });
  const down = await startService({ billing: createBillingClient({ baseUrl: 'http://127.0.0.1:1', serviceKey: bs.key, timeoutMs: 500 }), dbs: svc });
  try {
    const a = await wrongKey.get('/v1/admin/invoices', sam.as);
    assert.equal(a.status, 502); assert.equal(a.body.reason, 'billing_misconfigured');
    const b = await down.get('/v1/admin/invoices', sam.as);
    assert.equal(b.status, 502); assert.equal(b.body.reason, 'billing_unavailable');
    assert.equal((await wrongKey.get('/v1/admin/auth/me', sam.as)).status, 200, 'still signed in');
  } finally { await wrongKey.close(); await down.close(); }
});

test('a failed change is recorded as failed in the trail, with the reason code only', async () => {
  const id = await issued(sam);
  await svc.post(`/v1/admin/invoices/${id}/payments`, { amountMinor: 99_999_999, method: 'po' }, sam.as);
  assert.deepEqual((await trail('payment.record', id)).map(x => x.outcome), ['started', 'failed']);
  assert.equal((await trail('payment.record', id))[1].detail.error, 'payment_exceeds_balance');
});

test('the portal\'s logs hold no invoice content', async () => {
  svc.logs.length = 0;
  await create({ billTo: { name: 'Zebra Secret Academy', line1: '9 Hidden Lane', city: 'Pune', countryCode: 'IN' }, notes: 'INTERNAL-NOTE' });
  const all = JSON.stringify(svc.logs);
  for (const secret of ['Zebra', 'Hidden Lane', 'INTERNAL-NOTE', 'Licence, 25 seats', bs.key]) assert.ok(!all.includes(secret), secret);
});
