'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startService } = require('./helpers/server');
const { startBillingService } = require('./helpers/billing-service');
const { startLicenceService } = require('./helpers/licence-service');
const { scenarios } = require('./helpers/scenarios');
const { createBillingClient } = require('../src/billing-client');
const { staffSignedIn, createRequest, createStaff, rows } = require('./helpers/fixtures');
const { uuidv7 } = require('../src/uuid');

let svc, bs, ls, sam, boss, tess;
const invoiceBody = (o = {}) => ({ customerId: uuidv7(), billTo: { name: 'Example Public School', line1: '1 Example Road', city: 'Pune', countryCode: 'IN' },
  lines: [{ description: 'Licence', quantity: 1, unitPriceMinor: 100000 }], dueOn: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10), ...o });

test.before(async () => {
  bs = await startBillingService();
  svc = await startService({ billing: createBillingClient({ baseUrl: bs.url, serviceKey: bs.key }) });
  sam = await staffSignedIn(svc, { name: 'Sam Support' });
  boss = await staffSignedIn(svc, { role: 'PLATFORM_ADMIN', name: 'Bo Admin' });
  tess = await staffSignedIn(svc, { name: 'Tess Tester' });
  ls = await startLicenceService(svc);
});
test.after(async () => { await ls.close(); await svc.close(); await bs.close(); });
const mk = async (who = sam, o) => (await svc.post('/v1/admin/invoices', invoiceBody(o), who.as)).body.invoice.invoiceId;
const issued = async who => { const id = await mk(who); await svc.post(`/v1/admin/invoices/${id}/issue`, {}, who.as); return id; };

test('a request with no customer yet cannot be invoiced; one with a customer and licence pre-fills customer, plan and seats, with the price left for staff', async () => {
  const bare = await createRequest(svc, { organization: 'Bare Example School' });
  const r = await svc.get(`/v1/admin/purchase-requests/${bare}/invoice-draft`, sam.as);
  assert.equal(r.status, 409); assert.equal(r.body.reason, 'request_has_no_customer');

  const ref = await createRequest(svc, { organization: 'Agreed Example Academy', employees: 80, status: 'AGREED' });
  const made = await svc.post('/v1/admin/licenses', { reason: 'Agreed', purchaseRequest: ref, plan: 'team', seats: 25, termDays: 365 }, boss.as);
  assert.equal(made.status, 201, JSON.stringify(made.body));
  const d = (await svc.get(`/v1/admin/purchase-requests/${ref}/invoice-draft`, sam.as)).body;
  assert.equal(d.customerId, made.body.customerId); assert.match(d.sourcePurchaseRequestId, /^[0-9a-f-]{36}$/);
  assert.equal(d.billTo.name, 'Agreed Example Academy');
  assert.equal(d.lines.length, 1); assert.equal(d.lines[0].quantity, '25'); assert.match(d.lines[0].description, /25 seats/); assert.equal(d.lines[0].unitPriceMinor, null);
  assert.equal((await svc.get('/v1/admin/purchase-requests/nonsense/invoice-draft', sam.as)).status, 404);
  assert.equal((await svc.get('/v1/admin/purchase-requests/PR-999999/invoice-draft', sam.as)).status, 404);
  // the pre-filled draft becomes an invoice linked to the request
  const inv = await svc.post('/v1/admin/invoices', { ...d, lines: [{ description: d.lines[0].description, quantity: 25, unitPriceMinor: 40000 }], billTo: { ...d.billTo, line1: '1 Example Road', city: 'Pune', countryCode: 'IN' } }, sam.as);
  assert.equal(inv.status, 201); assert.equal(inv.body.invoice.sourcePurchaseRequestId, d.sourcePurchaseRequestId);
  const linked = await svc.get(`/v1/admin/invoices?sourcePurchaseRequestId=${d.sourcePurchaseRequestId}`, sam.as);
  assert.equal(linked.body.invoices.length, 1);
});

test('the owners list is active staff only', async () => {
  const gone = await createStaff(svc, { name: 'Gone Person', status: 'DISABLED' });
  const body = (await svc.get('/v1/admin/invoice-owners', sam.as)).body;
  const r = body.owners;
  assert.equal(body.meId, sam.userId);
  assert.ok(r.some(o => o.id === sam.userId && o.name === 'Sam Support'));
  assert.ok(!r.some(o => o.id === gone.userId));
});

test('changing the owner: admin only, to an active staff member, with a reason; the new owner and the history show names', async () => {
  const id = await issued(sam);
  const u = `/v1/admin/invoices/${id}/owner`;
  assert.equal((await svc.post(u, { toUserId: tess.userId, reason: 'Handover' }, sam.as)).status, 403);
  assert.equal((await svc.post(u, { toUserId: tess.userId }, boss.as)).body.reason, 'reason_required');
  assert.equal((await svc.post(u, { toUserId: uuidv7(), reason: 'Handover' }, boss.as)).body.reason, 'unknown_owner');
  const gone = await createStaff(svc, { name: 'Gone Person', status: 'DISABLED' });
  assert.equal((await svc.post(u, { toUserId: gone.userId, reason: 'Handover' }, boss.as)).body.reason, 'unknown_owner');
  const r = await svc.post(u, { toUserId: tess.userId, reason: 'South region handover' }, boss.as);
  assert.equal(r.status, 200); assert.equal(r.body.invoice.ownerUserId, tess.userId); assert.equal(r.body.names[tess.userId], 'Tess Tester');
  const d = (await svc.get(`/v1/admin/invoices/${id}`, boss.as)).body;
  assert.equal(d.ownerHistory.length, 1); assert.equal(d.names[d.ownerHistory[0].changedByUserId], 'Bo Admin');
  const t = await rows(svc.identityDb, `SELECT reason, detail FROM admin_audit WHERE action = 'owner.change' AND subject_ref = $1 AND outcome = 'done'`, [id]);
  assert.equal(t[0].reason, 'South region handover'); assert.deepEqual(t[0].detail, { to: tess.userId });
});

test('follow-ups: any staff member logs one on any open invoice; the queue and the summary (mine and everyone)', async () => {
  const id = await issued(sam);
  const next = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const r = await svc.post(`/v1/admin/invoices/${id}/follow-ups`, { channel: 'call', outcome: 'Asked for a PO number', note: 'Call back Thursday', nextFollowUpOn: next }, tess.as);
  assert.equal(r.status, 201); assert.equal(r.body.invoice.followUpCount, 1);
  const t = JSON.stringify(await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = 'followup.log' AND subject_ref = $1`, [id]));
  assert.ok(!t.includes('PO number') && !t.includes('Thursday'), 'what the customer said stays out of the trail'); assert.ok(t.includes('call'));
  const mine = (await svc.get('/v1/admin/invoice-follow-ups/summary?mine=1', sam.as)).body;
  assert.ok(Number.isInteger(mine.overdue) && Number.isInteger(mine.followUpsDue));
  const q = (await svc.get('/v1/admin/invoice-follow-ups/queue', sam.as)).body;
  assert.ok(Array.isArray(q.groups) && q.groups.every(g => g.invoices.every(i => i.reason)));
  assert.ok(q.names);
  assert.equal((await svc.get('/v1/admin/invoice-follow-ups/queue?mine=1', sam.as)).status, 200);
});

test('the dashboard and the export are for admins; the export is a safe CSV with owner names and the filtered rows', async () => {
  await issued(sam);
  assert.equal((await svc.get('/v1/admin/billing/dashboard', sam.as)).status, 403);
  assert.equal((await svc.get('/v1/admin/billing/export.csv', sam.as)).status, 403);
  const d = (await svc.get('/v1/admin/billing/dashboard', boss.as)).body;
  assert.ok(d.tiles && d.money && d.aging && d.followUpHealth && d.names);
  assert.ok(d.byOwner.every(o => typeof o.ownerUserId === 'string'));
  const id2 = await mk(sam, { billTo: { name: '=HYPERLINK("http://evil.example.test")', line1: '1 Road', city: 'Pune', countryCode: 'IN' } });
  await svc.post(`/v1/admin/invoices/${id2}/issue`, {}, sam.as);
  const csv = await svc.get('/v1/admin/billing/export.csv?status=ISSUED', boss.as);
  assert.equal(csv.status, 200); assert.match(csv.headers.get('content-type'), /text\/csv/); assert.match(csv.headers.get('content-disposition'), /invoices-\d{4}-\d{2}-\d{2}\.csv/);
  const lines = csv.text.replace(/^﻿/, '').trim().split('\r\n');
  assert.equal(lines[0], 'Invoice number,Status,Customer,Currency,Total,Paid,Balance,Issued on,Due on,Owner,Last follow-up');
  assert.ok(lines.length >= 3);
  assert.ok(lines.some(l => l.includes("'=HYPERLINK")), 'a typed name can never become a formula');
  assert.ok(lines.slice(1).every(l => /,(Sam Support|Tess Tester|Bo Admin|Former team member),/.test(l)), 'every row names its owner');
  assert.ok(lines.some(l => /,1000\.00,0\.00,1000\.00,/.test(l)), 'money is written as decimals');
  assert.equal((await rows(svc.identityDb, `SELECT 1 FROM admin_audit WHERE action = 'invoice.export' AND outcome = 'read'`)).length, 1);
});

test('the draft pre-fill and the follow-up queue each write a read row to the audit trail, with no customer name in it', async () => {
  const ref = await createRequest(svc, { organization: 'Audited Example Academy', employees: 40, status: 'AGREED' });
  assert.equal((await svc.post('/v1/admin/licenses', { reason: 'Agreed', purchaseRequest: ref, plan: 'team', seats: 5, termDays: 365 }, boss.as)).status, 201);
  assert.equal((await svc.get(`/v1/admin/purchase-requests/${ref}/invoice-draft`, sam.as)).status, 200);
  assert.equal((await svc.get('/v1/admin/invoice-follow-ups/queue', sam.as)).status, 200);
  for (const action of ['invoice.draft_prefill', 'followup.queue']) {
    const r = await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = $1 AND outcome = 'read'`, [action]);
    assert.ok(r.length >= 1, `${action} is audited`);
    assert.ok(!JSON.stringify(r).includes('Audited Example'), `${action} holds no customer name`);
  }
  const q = await rows(svc.identityDb, `SELECT detail FROM admin_audit WHERE action = 'followup.queue' AND outcome = 'read' ORDER BY 1 LIMIT 1`);
  assert.ok(Number.isInteger(q[0].detail.returned));
});
