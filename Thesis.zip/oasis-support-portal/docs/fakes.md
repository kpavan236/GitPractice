# Faked integrations (waiting on the IT Helpdesk)

Anything that needs a new external service is **faked** until IT approves it (cainc.service-now.com, IT Helpdesk first). A fake does the
whole job in memory, so every flow works and is tested; going live means writing the real implementation behind the same interface.

| Integration | Interface (the swap point) | What the fake does | What the real one must do |
|---|---|---|---|
| **Email sender** (activation and password-reset links) | `src/notifier.js`: `send({ kind, to, displayName, link, expiresInHours })`, `kind` is `activation` or `password_reset` (and `customer_reply`: `{ kind, to, subject, body, fromName, reference }`, a staff member's reply to a customer, in plain text) | Keeps each message in memory (last 1,000). `DEV_PRINT_CODES=1` prints the link to the terminal. | Deliver the email. Throwing is fine: `src/auth.js` swallows and logs a send failure so a failure cannot reveal who is staff. Use CA-reviewed wording. |

- `src/config.js` refuses to start in production with the fake sender or `DEV_PRINT_CODES=1`.
- The real sender must not log the message body: it holds a link that sets someone's password.
- This copy of `notifier.js` mirrors `oasis-licence-service/src/notifier.js` (which also has `notifySupport`). When there is a real sender, put it in the shared package
  (see README, "Decisions", item 7) rather than writing it twice.
