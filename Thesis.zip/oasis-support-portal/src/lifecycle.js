'use strict';
const { ApiError, refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { stripControl } = require('./forms');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const REFERENCE = /^[A-Za-z0-9 ._/#-]{1,100}$/;
const LICENCE_STATUSES = ['DRAFT', 'PENDING_ACTIVATION', 'ACTIVE', 'SUSPENDED', 'EXPIRED', 'CANCELLED'];
const TRIAL_STATUSES = ['ACTIVE', 'EXPIRED', 'CONVERTED'];

const conflict = (message, reason) => new ApiError(409, message, reason);
const notFound = (message, reason) => new ApiError(404, message, reason);
const idOr404 = (id, what) => { if (typeof id !== 'string' || !UUID.test(id)) throw notFound(`No such ${what}.`, 'not_found'); return id; };
const whole = (value, { min, max, fallback, name, reason }) => {
  if (value === undefined) return fallback;
  if (!Number.isInteger(value) || value < min || value > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, reason);
  return value;
};

/**
 * What support does to a licence or a trial after it exists: suspend and reinstate a licence, renew it (a new paid term), extend it (a
 * few more days, a goodwill term), and extend a trial. All in the licence database; the status history there records who and why.
 *
 * A licence's dates live only in its terms, and terms are never edited, so renewing and extending both ADD a term that starts where the
 * last one ended (or now, if it has already ended: the gap in between was a time the licence did not cover). They differ in size and in what
 * the record says: a renewal is a purchase, an extension is "entered by hand".
 */
function createLifecycle({ licenseDb, customerDb, licenceHash }) {
  const withReason = async (db, reason, actorId) => {
    await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await db.query(`SELECT set_config('app.actor_id', $1, true)`, [actorId]);
  };

  async function lockLicense(db, licenseId) {
    const { rows: [lic] } = await db.query('SELECT license_id, customer_id, status_code, plan_code FROM license WHERE license_id = $1 FOR UPDATE', [licenseId]);
    if (!lic) throw notFound('No such licence.', 'not_found');
    return lic;
  }

  const summary = async (db, licenseId) => (await db.query(
    `SELECT license_id AS "licenseId", status_code AS "status", seat_limit AS "seats",
            (SELECT min(starts_at) FROM license_term t WHERE t.license_id = l.license_id) AS "startsAt",
            (SELECT max(ends_at) FROM license_term t WHERE t.license_id = l.license_id) AS "expiresAt"
       FROM license l WHERE license_id = $1`, [licenseId])).rows[0];

  // ── Reading ─────────────────────────────────────────────────────────────────

  async function listLicences({ customerId, status, limit, offset }) {
    const where = [], params = [];
    if (customerId !== undefined) {
      if (!UUID.test(customerId)) throw refuse('customerId must be a customer id.', 'bad_filter');
      params.push(customerId); where.push(`l.customer_id = $${params.length}`);
    }
    if (status !== undefined) {
      const wanted = String(status).split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      if (!wanted.length || wanted.some(s => !LICENCE_STATUSES.includes(s))) throw refuse(`status must be one or more of ${LICENCE_STATUSES.join(', ')}.`, 'bad_filter');
      params.push(wanted); where.push(`l.status_code = ANY($${params.length})`);
    }
    params.push(limit, offset);
    const { rows } = await licenseDb.query(
      `SELECT l.license_id, l.customer_id, l.plan_code, l.kind_code, l.status_code, l.seat_limit, l.key_hint, l.grace_days, l.created_at,
              t.starts_at, t.expires_at, (SELECT count(*)::int FROM activation a WHERE a.license_id = l.license_id AND a.released_at IS NULL) AS seats_in_use
         FROM license l LEFT JOIN LATERAL (SELECT min(starts_at) AS starts_at, max(ends_at) AS expires_at FROM license_term WHERE license_id = l.license_id) t ON true
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY l.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    const names = rows.length ? (await customerDb.query('SELECT customer_id, name FROM customer WHERE customer_id = ANY($1)', [[...new Set(rows.map(r => r.customer_id))]])).rows : [];
    const nameOf = new Map(names.map(n => [n.customer_id, n.name]));
    return rows.map(r => ({ ...r, customer_name: nameOf.get(r.customer_id) || null }));
  }

  /** Trials for support to find one to extend. A machine id is NEVER shown to staff; the customer's own addresses are, because they say whose trial it is. */
  async function listTrials({ status, flagged, limit, offset }) {
    const where = [], params = [];
    if (status !== undefined) {
      const wanted = String(status).split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      if (!wanted.length || wanted.some(s => !TRIAL_STATUSES.includes(s))) throw refuse(`status must be one or more of ${TRIAL_STATUSES.join(', ')}.`, 'bad_filter');
      params.push(wanted); where.push(`t.status_code = ANY($${params.length})`);
    }
    if (flagged !== undefined) {
      if (flagged !== 'true' && flagged !== 'false') throw refuse('flagged must be true or false.', 'bad_filter');
      where.push(`${flagged === 'true' ? '' : 'NOT '}EXISTS (SELECT 1 FROM trial_review_flag f WHERE f.trial_id = t.trial_id AND f.reviewed_at IS NULL)`);
    }
    params.push(limit, offset);
    const { rows } = await licenseDb.query(
      `SELECT t.trial_id, t.status_code, t.started_at, t.expires_at, t.extended_until, coalesce(t.extended_until, t.expires_at) AS effective_expiry,
              (coalesce(t.extended_until, t.expires_at) <= now()) AS has_ended, i.platform, i.arch, i.app_version, ti.github_org,
              (SELECT coalesce(array_agg(f.flag_code ORDER BY f.flag_code), '{}') FROM trial_review_flag f WHERE f.trial_id = t.trial_id AND f.reviewed_at IS NULL) AS open_flags
         FROM trial t JOIN installation i USING (installation_id) LEFT JOIN trial_integration ti USING (trial_id)
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY t.started_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    return rows;
  }

  // ── Licence status ──────────────────────────────────────────────────────────

  async function move(licenseId, { from, to, reason, staff }) {
    idOr404(licenseId, 'licence');
    return tx(licenseDb, async db => {
      const lic = await lockLicense(db, licenseId);
      if (lic.status_code !== from) {
        if (lic.status_code === to) return { before: lic.status_code, after: await summary(db, licenseId) };        // already there: repeating is harmless
        throw conflict(`A licence that is ${lic.status_code} cannot be ${to === 'SUSPENDED' ? 'suspended' : 'reinstated'}. It must be ${from}.`, 'invalid_transition');
      }
      await withReason(db, reason, staff.userId);
      await db.query('UPDATE license SET status_code = $2 WHERE license_id = $1', [licenseId, to]);
      return { before: from, after: await summary(db, licenseId) };
    });
  }

  const suspend = (licenseId, reason, staff) => move(licenseId, { from: 'ACTIVE', to: 'SUSPENDED', reason, staff });
  const reinstate = (licenseId, reason, staff) => move(licenseId, { from: 'SUSPENDED', to: 'ACTIVE', reason, staff });

  // ── Changing what was sold, and releasing a seat ────────────────────────────

  /**
   * Changes a licence's seats, its plan, or both. Seats can go up or down but never below the seats in use (release some first); "unlimited" (seats: null) is only for an
   * enterprise licence. A new plan replaces the features the old plan included; any feature a person set by hand is left as it is. The terms as sold (grace days, offline) are
   * not touched. A cancelled or ended licence cannot be changed: renew it, or make a new one.
   */
  async function changeTerms(licenseId, body, reason, staff) {
    idOr404(licenseId, 'licence');
    const hasSeats = Object.prototype.hasOwnProperty.call(body, 'seats'), hasPlan = body.plan !== undefined;
    if (!hasSeats && !hasPlan) throw refuse('Give seats, a plan, or both to change.', 'nothing_to_change');
    if (hasSeats && body.seats !== null && (!Number.isInteger(body.seats) || body.seats < 1 || body.seats > 100000)) throw refuse('seats must be a whole number from 1 to 100000, or null for unlimited.', 'bad_seats');
    if (hasPlan && (typeof body.plan !== 'string' || !/^[a-z0-9-]{1,60}$/.test(body.plan))) throw refuse('plan must be a plan code.', 'bad_plan');
    return tx(licenseDb, async db => {
      const { rows: [lic] } = await db.query('SELECT license_id, status_code, plan_code, kind_code, seat_limit FROM license WHERE license_id = $1 FOR UPDATE', [licenseId]);
      if (!lic) throw notFound('No such licence.', 'not_found');
      if (['CANCELLED', 'EXPIRED'].includes(lic.status_code)) throw conflict(`A licence that is ${lic.status_code === 'CANCELLED' ? 'cancelled' : 'ended'} cannot be changed. Renew it, or create a new licence.`, 'invalid_transition');
      const newPlan = hasPlan ? body.plan : lic.plan_code;
      if (hasPlan && newPlan !== lic.plan_code) {
        const { rows } = await db.query(`SELECT plan_code FROM plan WHERE plan_code = $1 AND is_active AND plan_code <> 'trial'`, [newPlan]);
        if (!rows.length) throw refuse('That plan is not on sale.', 'bad_plan');
      }
      const newSeats = hasSeats ? body.seats : lic.seat_limit;
      if (newSeats === null && lic.kind_code !== 'enterprise') throw refuse('Unlimited seats are only for an enterprise licence.', 'bad_seats');
      const { rows: [inUse] } = await db.query('SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [licenseId]);
      if (newSeats !== null && newSeats < inUse.n) throw conflict(`${inUse.n} seats are in use. Release some seats first, or choose ${inUse.n} or more.`, 'seats_in_use');
      if (newPlan === lic.plan_code && newSeats === lic.seat_limit) throw refuse('Nothing would change.', 'nothing_to_change');
      await withReason(db, reason, staff.userId);
      await db.query('UPDATE license SET plan_code = $2, seat_limit = $3 WHERE license_id = $1', [licenseId, newPlan, newSeats]);
      if (newPlan !== lic.plan_code) {
        await db.query(`UPDATE entitlement SET effective_until = now() WHERE license_id = $1 AND effective_until IS NULL AND reason = 'Included in the plan'`, [licenseId]);
        await db.query(
          `INSERT INTO entitlement (entitlement_id, license_id, feature_code, enabled, limit_value, reason, created_by_user_id, effective_from)
           SELECT gen_random_uuid(), $1, d.feature_code, d.enabled, d.limit_value, 'Included in the plan', $3, now() FROM plan_feature_default d
            WHERE d.plan_code = $2 AND NOT EXISTS (SELECT 1 FROM entitlement e WHERE e.license_id = $1 AND e.feature_code = d.feature_code AND e.effective_until IS NULL)`,
          [licenseId, newPlan, staff.userId]);
      }
      return { before: { plan: lic.plan_code, seats: lic.seat_limit }, after: { ...(await summary(db, licenseId)), plan: newPlan } };
    });
  }

  /** Frees one seat (a lost laptop, a person who left). The machine can take a seat again if there is room. Never shows a machine id. */
  async function releaseSeat(licenseId, activationId, reason, staff) {
    idOr404(licenseId, 'licence'); idOr404(activationId, 'seat');
    return tx(licenseDb, async db => {
      await lockLicense(db, licenseId);
      await withReason(db, reason, staff.userId);
      const { rowCount } = await db.query(`UPDATE activation SET released_at = now(), release_reason_code = 'support' WHERE activation_id = $1 AND license_id = $2 AND released_at IS NULL`, [activationId, licenseId]);
      if (!rowCount) throw notFound('No such seat in use on this licence.', 'not_found');
      const { rows: [n] } = await db.query('SELECT count(*)::int AS n FROM activation WHERE license_id = $1 AND released_at IS NULL', [licenseId]);
      return { seatsInUse: n.n };
    });
  }

  // ── Ending a licence for good ───────────────────────────────────────────────

  /**
   * Cancel (an agreed end: the customer left, a refund, no renewal) or revoke (for cause: abuse, a leaked key). Both end the licence as
   * CANCELLED, which is final and which the licence service tells the app as "revoked" at its next check. A revocation also frees every
   * seat at once, so a machine cannot be counted on a licence that is gone. Because neither can be undone, the caller must confirm by
   * sending the last four characters of the licence key, which stops a wrong id from ending the wrong customer.
   * Repeating is harmless: cancelling a cancelled licence changes nothing, and revoking one frees any seats still held.
   */
  async function end(licenseId, { mode, confirm, reason, staff }) {
    idOr404(licenseId, 'licence');
    return tx(licenseDb, async db => {
      const lic = await lockLicense(db, licenseId);                 // an unknown licence is a 404 before anything is said about confirming
      if (confirm === undefined) throw refuse('Confirm by sending confirm: the last four characters of the licence key (shown in the licence list).', 'confirmation_required');
      const { rows: [k] } = await db.query('SELECT key_hint FROM license WHERE license_id = $1', [licenseId]);
      if (typeof confirm !== 'string' || confirm.trim().toUpperCase() !== k.key_hint.toUpperCase()) throw refuse('That does not match the last four characters of this licence\'s key.', 'confirmation_mismatch');
      if (lic.status_code === 'EXPIRED') throw conflict('This licence has already ended (EXPIRED); there is nothing to cancel.', 'invalid_transition');
      await withReason(db, reason, staff.userId);
      if (lic.status_code !== 'CANCELLED') await db.query(`UPDATE license SET status_code = 'CANCELLED' WHERE license_id = $1`, [licenseId]);
      let seatsReleased;
      if (mode === 'revoke') {
        ({ rowCount: seatsReleased } = await db.query(
          `UPDATE activation SET released_at = clock_timestamp(), release_reason_code = 'revoked' WHERE license_id = $1 AND released_at IS NULL`, [licenseId]));
      }
      return { before: lic.status_code, after: await summary(db, licenseId), seatsReleased };
    });
  }

  const cancel = (licenseId, body, reason, staff) => end(licenseId, { mode: 'cancel', confirm: body.confirm, reason, staff });
  const revoke = (licenseId, body, reason, staff) => end(licenseId, { mode: 'revoke', confirm: body.confirm, reason, staff });

  // ── Blocking the machines of an ended licence ───────────────────────────────

  const BLOCK_STATES = ['active', 'lifted', 'all'];

  /**
   * Blocks every machine that held a seat on this licence when it ended (an open seat, or one freed by the revocation). Staff never see a
   * machine id: the ids are read here, hashed with the licence service's secret, and stored only as hashes, which is how the licence service
   * looks them up. A blocked machine is refused on EVERY route there, including starting a trial, until the block is lifted.
   * A machine blocked for another reason stays blocked for that one. The licence must already be cancelled or revoked.
   */
  async function blockMachines(licenseId, { confirm, reason, staff }) {
    idOr404(licenseId, 'licence');
    return tx(licenseDb, async db => {
      const lic = await lockLicense(db, licenseId);
      if (lic.status_code !== 'CANCELLED') throw conflict('Cancel or revoke the licence before blocking its machines.', 'licence_not_ended');
      if (confirm === undefined) throw refuse('Confirm by sending confirm: the last four characters of the licence key (shown in the licence list).', 'confirmation_required');
      const { rows: [k] } = await db.query('SELECT key_hint FROM license WHERE license_id = $1', [licenseId]);
      if (typeof confirm !== 'string' || confirm.trim().toUpperCase() !== k.key_hint.toUpperCase()) throw refuse('That does not match the last four characters of this licence\'s key.', 'confirmation_mismatch');
      const { rows: machines } = await db.query(
        `SELECT DISTINCT i.fingerprint FROM activation a JOIN installation i USING (installation_id)
          WHERE a.license_id = $1 AND (a.released_at IS NULL OR a.release_reason_code = 'revoked')`, [licenseId]);
      const hashes = [...new Set(machines.map(m => licenceHash('machine', m.fingerprint)))];
      let newly = 0;
      if (hashes.length) {
        ({ rowCount: newly } = await db.query(
          `INSERT INTO access_block (block_id, subject_type, subject_hash, reason_code, note, blocked_by_user_id, license_id)
           SELECT gen_random_uuid(), 'machine', h, 'licence_revoked', $2, $3, $1 FROM unnest($4::text[]) AS h
           ON CONFLICT DO NOTHING`, [licenseId, `Licence ${licenseId} ended: ${reason}`.slice(0, 500), staff.userId, hashes]));
      }
      return { licenseId, machines: hashes.length, newlyBlocked: newly, alreadyBlocked: hashes.length - newly };
    });
  }

  /** Lifts every block made for this licence (the revocation was a mistake, or the customer has settled). Lifting twice changes nothing. */
  async function unblockMachines(licenseId, { staff }) {
    idOr404(licenseId, 'licence');
    return tx(licenseDb, async db => {
      await lockLicense(db, licenseId);
      const { rowCount } = await db.query(
        `UPDATE access_block SET lifted_at = now(), lifted_by_user_id = $2 WHERE license_id = $1 AND lifted_at IS NULL`, [licenseId, staff.userId]);
      return { licenseId, lifted: rowCount };
    });
  }

  /** Lifts one block by its id. */
  async function liftBlock(blockId, { staff }) {
    idOr404(blockId, 'block');
    return tx(licenseDb, async db => {
      const { rows: [b] } = await db.query('SELECT block_id, lifted_at FROM access_block WHERE block_id = $1 FOR UPDATE', [blockId]);
      if (!b) throw notFound('No such block.', 'not_found');
      if (b.lifted_at) return { blockId, lifted: 0 };
      await db.query('UPDATE access_block SET lifted_at = now(), lifted_by_user_id = $2 WHERE block_id = $1', [blockId, staff.userId]);
      return { blockId, lifted: 1 };
    });
  }

  /** The block list. It never shows what was blocked (only hashes are kept): it shows why, when, by whom, and for which licence. */
  async function listBlocks({ licenseId, reason, state, limit, offset }) {
    const where = [], params = [];
    if (licenseId !== undefined) {
      if (!UUID.test(licenseId)) throw refuse('licenseId must be a licence id.', 'bad_filter');
      params.push(licenseId); where.push(`b.license_id = $${params.length}`);
    }
    if (reason !== undefined) {
      const { rows } = await licenseDb.query('SELECT reason_code FROM block_reason');
      if (!rows.some(r => r.reason_code === reason)) throw refuse(`reason must be one of ${rows.map(r => r.reason_code).join(', ')}.`, 'bad_filter');
      params.push(reason); where.push(`b.reason_code = $${params.length}`);
    }
    const wanted = state === undefined ? 'active' : state;
    if (!BLOCK_STATES.includes(wanted)) throw refuse(`state must be one of ${BLOCK_STATES.join(', ')}.`, 'bad_filter');
    if (wanted === 'active') where.push('b.lifted_at IS NULL AND (b.expires_at IS NULL OR b.expires_at > now())');
    if (wanted === 'lifted') where.push('b.lifted_at IS NOT NULL');
    params.push(limit, offset);
    const { rows } = await licenseDb.query(
      `SELECT b.block_id, b.subject_type, b.reason_code, b.note, b.blocked_at, b.blocked_by_user_id, b.expires_at, b.lifted_at, b.lifted_by_user_id, b.license_id
         FROM access_block b ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY b.blocked_at DESC, b.block_id LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    return rows;
  }

  // ── Terms: renew and extend ─────────────────────────────────────────────────

  async function addTerm(licenseId, { kind, body, reason, staff }) {
    idOr404(licenseId, 'licence');
    const isRenewal = kind === 'renew';
    let days = body.termDays;
    let reference = null;
    if (isRenewal && body.reference !== undefined) {
      if (typeof body.reference !== 'string' || !REFERENCE.test(stripControl(body.reference))) throw refuse('reference (a PO or invoice number) may use letters, digits, spaces and . _ / # - only, up to 100 characters.', 'bad_reference');
      reference = stripControl(body.reference);
    }
    if (!isRenewal) days = body.days;
    const limits = isRenewal ? { min: 1, max: 3650, name: 'termDays' } : { min: 1, max: 90, name: 'days' };
    return tx(licenseDb, async db => {
      const lic = await lockLicense(db, licenseId);
      if (lic.status_code === 'CANCELLED') throw conflict('This licence has been cancelled; it cannot be renewed or extended. Issue a new one.', 'licence_cancelled');
      if (lic.status_code === 'DRAFT') throw conflict('This licence has not been issued yet.', 'invalid_transition');
      if (isRenewal && days === undefined) days = (await db.query('SELECT default_term_days FROM plan WHERE plan_code = $1', [lic.plan_code])).rows[0].default_term_days;
      days = whole(days, { ...limits, reason: 'bad_term' });
      if (days === undefined) throw refuse(`${limits.name} is required.`, 'bad_term');

      await withReason(db, reason, staff.userId);
      const { rows: [t] } = await db.query(
        `WITH last AS (SELECT coalesce(max(term_no), 0) AS n, max(ends_at) AS ends FROM license_term WHERE license_id = $1),
              began AS (SELECT greatest(coalesce(last.ends, now()), now()) AS at, last.n FROM last)
         INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code, reference)
         SELECT $2, $1, began.n + 1, began.at, began.at + make_interval(days => $3), $4, $5 FROM began
         RETURNING term_no, starts_at, ends_at`,
        [licenseId, uuidv7(), days, isRenewal ? 'renewal' : 'manual', reference]);
      // A licence the system had marked EXPIRED is live again as soon as a term covers now.
      let statusMoved = false;
      if (lic.status_code === 'EXPIRED' && t.starts_at <= new Date()) {
        await db.query(`UPDATE license SET status_code = 'ACTIVE' WHERE license_id = $1`, [licenseId]);
        statusMoved = true;
      }
      const after = await summary(db, licenseId);
      return { before: lic.status_code, after, term: { termNo: t.term_no, startsAt: t.starts_at, endsAt: t.ends_at, days, source: isRenewal ? 'renewal' : 'manual' }, statusMoved };
    });
  }

  const renew = (licenseId, body, reason, staff) => addTerm(licenseId, { kind: 'renew', body, reason, staff });
  const extend = (licenseId, body, reason, staff) => addTerm(licenseId, { kind: 'extend', body, reason, staff });

  // ── Trials ──────────────────────────────────────────────────────────────────

  /** More days for a trial: from the later of its current end and now, so extending one that ended last month still gives a real window. */
  async function extendTrial(trialId, body, reason, staff) {
    idOr404(trialId, 'trial');
    const days = whole(body.days, { min: 1, max: 30, name: 'days', reason: 'bad_term' });
    if (days === undefined) throw refuse('days is required.', 'bad_term');
    return tx(licenseDb, async db => {
      const { rows: [t] } = await db.query(
        `SELECT trial_id, status_code, coalesce(extended_until, expires_at) AS ends FROM trial WHERE trial_id = $1 FOR UPDATE`, [trialId]);
      if (!t) throw notFound('No such trial.', 'not_found');
      if (t.status_code === 'CONVERTED') throw conflict('This trial became a licence; there is nothing to extend.', 'trial_converted');
      await withReason(db, reason, staff.userId);
      const { rows: [u] } = await db.query(
        `UPDATE trial SET extended_until = greatest(coalesce(extended_until, expires_at), now()) + make_interval(days => $2), extended_by_user_id = $3,
                          status_code = 'ACTIVE'
          WHERE trial_id = $1 RETURNING trial_id, status_code, expires_at, extended_until`, [trialId, days, staff.userId]);
      return { before: t.status_code, after: { trialId: u.trial_id, status: u.status_code, originalExpiry: u.expires_at, extendedUntil: u.extended_until }, days };
    });
  }

  return { listLicences, listTrials, suspend, reinstate, cancel, revoke, blockMachines, unblockMachines, liftBlock, listBlocks, renew, extend, extendTrial, changeTerms, releaseSeat };
}

module.exports = { createLifecycle };
