'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);
const COST = { N: 2 ** 15, r: 8, p: 1 };         // about 80 ms on a laptop; the cost is stored with each hash, so it can be raised later without locking anyone out
const KEY_BYTES = 32;
const MIN_LENGTH = 12;
const MAX_LENGTH = 128;       // the ceiling is a guard against someone sending a megabyte to be hashed, not a rule about strength
const COMMON = new Set(['password1234', 'password12345', '123456789012', 'qwertyuiopas', 'iloveyou1234', 'welcome12345', 'administrator', 'letmein123456', 'changeme1234', 'passw0rd1234', 'oasis-support', 'oasissupport']);

const maxmem = N => 256 * N * COST.r + 1024 * 1024;

/**
 * A password as the portal stores it: scrypt over the password after it has been run through the server's secret (the same keyed hash the portal uses for codes), with a random
 * salt per person. So a copy of the database alone cannot be used to guess passwords: it also needs the secret. Returns "scrypt$N$r$p$salt$key".
 */
async function hashPassword(hash, password, cost = {}) {
  const { N, r, p } = { ...COST, ...cost };
  const salt = crypto.randomBytes(16);
  const key = await scrypt(hash('password', password), salt, KEY_BYTES, { N, r, p, maxmem: maxmem(N) });
  return ['scrypt', N, r, p, salt.toString('base64url'), key.toString('base64url')].join('$');
}

/** True when the password matches what was stored. Takes the same time for a right and a wrong password. */
async function verifyPassword(hash, password, stored) {
  const [scheme, N, r, p, salt, key] = String(stored).split('$');
  if (scheme !== 'scrypt' || !key) return false;
  const want = Buffer.from(key, 'base64url');
  const got = await scrypt(hash('password', password), Buffer.from(salt, 'base64url'), want.length, { N: Number(N), r: Number(r), p: Number(p), maxmem: maxmem(Number(N)) });
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}

/** Why a new password is not allowed, in words for the person, or null when it is fine. Length matters more than mixing characters. */
function passwordProblem(password, email) {
  if (typeof password !== 'string') return 'Enter a password.';
  if ([...password].length < MIN_LENGTH) return `Use at least ${MIN_LENGTH} characters. A few ordinary words together make a strong one.`;
  if (password.length > MAX_LENGTH) return `Use at most ${MAX_LENGTH} characters.`;
  const lower = password.toLowerCase();
  const local = String(email || '').split('@')[0].toLowerCase();
  if (COMMON.has(lower) || /^(.)\1+$/.test(password)) return 'That password is too easy to guess. Choose something less common.';
  if (local.length >= 4 && lower.includes(local)) return 'The password must not contain your email address.';
  return null;
}

module.exports = { hashPassword, verifyPassword, passwordProblem, MIN_LENGTH, MAX_LENGTH };
