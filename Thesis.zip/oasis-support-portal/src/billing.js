'use strict';
const { refuse } = require('./errors');

const REFERENCE = /^PR-\d{6,}$/;

/** Portal-side helpers for the billing section: who is acting (and as what), and names for the people in a response. */
function createBilling({ client, namesOf, identityDb, customerDb, licenseDb }) {
  /** The billing role is data: whoever holds INVOICE_ADMIN acts as "admin", everyone else as "user". */
  const actorOf = staff => ({ userId: staff.userId, role: staff.permissions.has('INVOICE_ADMIN') ? 'admin' : 'user' });

  const idsIn = value => {
    const ids = new Set();
    const walk = v => {
      if (Array.isArray(v)) return v.forEach(walk);
      if (v && typeof v === 'object') {
        for (const [k, x] of Object.entries(v)) {
          if (/UserId$/.test(k) && typeof x === 'string') ids.add(x);          // ownerUserId, createdByUserId, byUserId, changedByUserId, actorUserId, recordedByUserId, fromUserId, toUserId
          else walk(x);
        }
      }
    };
    walk(value);
    return [...ids];
  };

  /** Adds `names` ({ userId: displayName }) for every staff id found anywhere in the body. Someone who has left is absent: the screens say so. */
  async function withNames(body) {
    const map = await namesOf(idsIn(body));
    return { ...body, names: Object.fromEntries(map) };
  }

  /** Active staff only (who may own a deal): the same test the portal uses when a request is assigned. */
  async function activeStaff() {
    const { rows } = await identityDb.query(
      `SELECT u.user_id, coalesce(u.display_name, u.email) AS name FROM app_user u
        WHERE u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code IN ('SUPPORT', 'PLATFORM_ADMIN'))
        ORDER BY name`);
    return rows.map(r => ({ id: r.user_id, name: r.name }));
  }
  async function requireActiveStaff(userId) {
    if (typeof userId !== 'string' || !(await activeStaff()).some(o => o.id === userId)) throw refuse('Choose an active member of the team.', 'unknown_owner');
  }

  /** What to pre-fill on "Create invoice" from a Buy-licence request: the customer, the plan and the seats. The price is left for staff: nothing here knows it. */
  async function draftFromRequest(reference) {
    const notFound = () => refuse('No such purchase request.', 'not_found', {}, 404);
    if (typeof reference !== 'string' || !REFERENCE.test(reference)) throw notFound();
    const { rows: [r] } = await customerDb.query('SELECT purchase_request_id, customer_id, organization_name, employee_count FROM purchase_request WHERE reference = $1', [reference]);
    if (!r) throw notFound();
    if (!r.customer_id) throw refuse('Create the customer and licence for this request first: an invoice is raised for a customer.', 'request_has_no_customer', {}, 409);
    const [{ rows: [c] }, { rows: [l] }] = await Promise.all([
      customerDb.query('SELECT name FROM customer WHERE customer_id = $1', [r.customer_id]),
      licenseDb.query(`SELECT p.label, l.seat_limit FROM license l JOIN plan p USING (plan_code) WHERE l.customer_id = $1 AND l.status_code <> 'CANCELLED' ORDER BY l.created_at DESC LIMIT 1`, [r.customer_id]),
    ]);
    const seats = l && l.seat_limit ? l.seat_limit : r.employee_count;
    return {
      sourcePurchaseRequestId: r.purchase_request_id, customerId: r.customer_id, billTo: { name: (c && c.name) || r.organization_name },
      lines: [{ description: l ? `Licence: ${l.label}, ${seats} seats` : `Licence, ${seats} seats`, quantity: String(seats), unitPriceMinor: null }],
      notes: `Raised from request ${reference}`,
    };
  }

  return { client, actorOf, withNames, activeStaff, requireActiveStaff, draftFromRequest };
}

module.exports = { createBilling };
