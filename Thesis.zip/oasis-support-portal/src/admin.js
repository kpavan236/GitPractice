'use strict';
const crypto = require('node:crypto');
const { ApiError, refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { stripControl } = require('./forms');
const { issueLicence } = require('./issue-licence');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const REFERENCE = /^PR-\d{6,}$/;

// A domain here decides who may activate a licence by typing an address, so a public mailbox domain must never be attached to a
// customer: anyone with a free account there would get in. Not exhaustive (support is trusted, and every attach is audited): it stops
// the obvious mistake.
const PUBLIC_MAIL_DOMAINS = new Set([
  // global webmail
  'gmail.com', 'googlemail.com', 'outlook.com', 'hotmail.com', 'live.com', 'msn.com', 'yahoo.com', 'ymail.com', 'rocketmail.com', 'icloud.com', 'me.com', 'mac.com',
  'aol.com', 'proton.me', 'pm.me', 'protonmail.com', 'protonmail.ch', 'gmx.com', 'gmx.net', 'gmx.de', 'mail.com', 'zoho.com', 'yandex.com', 'yandex.ru', 'mail.ru',
  'hey.com', 'fastmail.com', 'fastmail.fm', 'tutanota.com', 'tuta.io', 'qq.com', '163.com', '126.com', 'naver.com', 'daum.net', 'web.de',
  // regional variants
  'outlook.co.uk', 'hotmail.co.uk', 'live.co.uk', 'yahoo.co.uk', 'yahoo.ca', 'yahoo.com.au', 'hotmail.ca', 'outlook.com.au', 'hotmail.fr', 'yahoo.fr', 'yahoo.de', 'yahoo.in',
  // US internet providers (common for teachers' and parents' personal mail)
  'comcast.net', 'att.net', 'sbcglobal.net', 'verizon.net', 'cox.net', 'bellsouth.net', 'charter.net', 'earthlink.net', 'optonline.net', 'centurylink.net', 'frontier.com', 'windstream.net',
]);

// A "domain" that is really a public suffix (co.uk, com.au) would cover every organisation under it.
const PUBLIC_SUFFIXES = new Set(['co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'me.uk', 'com.au', 'net.au', 'org.au', 'edu.au', 'co.nz', 'co.za', 'co.in', 'co.jp', 'com.br', 'com.mx', 'com.cn', 'com.sg', 'k12.us']);
// A public suffix is shared by thousands of organisations (a country's "co.uk", a state's "k12.ca.us"): attaching one would let anyone under it activate. The list above names the common
// ones; these patterns catch the general shapes (a second-level label like co/com/ac/edu/gov under a country code, and US state school suffixes) without needing a full public-suffix list.
const SUFFIX_SHAPES = [/^(?:ac|co|com|edu|gov|mil|net|org|or|ne|go|gob|sch|school|nom)\.[a-z]{2}$/, /^(?:k12|cc|tec|lib|state|dst|pvt)\.[a-z]{2}\.us$/, /^[a-z]{2}\.us$/, /^(?:k12|edu)\.[a-z]{2,}$/];
const LABEL = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/;
const validDomain = d => d.length <= 253 && d.split('.').length >= 2 && d.split('.').every(l => l.length >= 1 && l.length <= 63 && LABEL.test(l)) && /^[a-z]{2,}$/.test(d.split('.').pop());

const conflict = (message, reason, extra) => new ApiError(409, message, reason, extra);
const notFound = (message, reason) => new ApiError(404, message, reason);

function reasonOf(body) {
  const reason = typeof body.reason === 'string' ? stripControl(body.reason) : '';
  if (!reason) throw refuse('Say why you are making this change.', 'reason_required');
  if (reason.length > 500) throw refuse('Keep the reason under 500 characters.', 'reason_too_long');
  return reason;
}

/** The staff operations behind the /admin routes. Each returns plain data; the routes decide who may call and what to audit. */
function createAdmin({ identityDb, customerDb, licenseDb, licenceHash }) {

  // ── Purchase requests ───────────────────────────────────────────────────────

  /** Names for staff ids (assignee, who moved a status), so the lists read as people. A user that is gone shows as null. */
  async function namesOf(ids) {
    const wanted = [...new Set(ids.filter(Boolean))];
    if (!wanted.length) return new Map();
    const { rows } = await identityDb.query('SELECT user_id, display_name, email FROM app_user WHERE user_id = ANY($1)', [wanted]);
    return new Map(rows.map(r => [r.user_id, r.display_name || r.email]));
  }

  async function listPurchaseRequests({ status, assignedTo, limit, offset }, staff) {
    const where = [], params = [];
    if (status !== undefined) {
      const { rows } = await customerDb.query('SELECT status_code FROM purchase_request_status');
      const known = rows.map(r => r.status_code);
      const wanted = String(status).split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      if (!wanted.length || wanted.some(s => !known.includes(s))) throw refuse(`status must be one or more of ${known.join(', ')}.`, 'bad_filter');
      params.push(wanted); where.push(`p.status_code = ANY($${params.length})`);
    }
    if (assignedTo !== undefined) {
      if (assignedTo === 'none') where.push('p.assigned_to_user_id IS NULL');
      else {
        const id = assignedTo === 'me' ? staff.userId : assignedTo;
        if (!UUID.test(id)) throw refuse('assignedTo must be "me", "none" or a staff user id.', 'bad_filter');
        params.push(id); where.push(`p.assigned_to_user_id = $${params.length}`);
      }
    }
    params.push(limit, offset);
    const { rows } = await customerDb.query(
      `SELECT v.reference, v.organization_name, v.employee_count, v.size_band, v.contact_name, v.email, v.email_domain, p.status_code, v.status, v.is_closed,
              v.status_changed_at, v.assigned_to_user_id, v.customer_id, v.source_code, v.app_version, v.created_at, v.hours_open_or_to_close
         FROM v_purchase_request v JOIN purchase_request p USING (purchase_request_id)
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY (NOT v.is_closed) DESC, v.created_at ASC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    const names = await namesOf(rows.map(r => r.assigned_to_user_id));
    return rows.map(r => ({ ...r, assigned_to_name: r.assigned_to_user_id ? names.get(r.assigned_to_user_id) || null : null }));
  }

  /** One Buy-form request in full: what the person asked for, who has it, every status it has had, the customer it became, and that customer's licences. */
  async function getPurchaseRequest(reference) {
    if (!REFERENCE.test(reference)) throw notFound('No such purchase request.', 'not_found');
    const { rows: [r] } = await customerDb.query(
      `SELECT p.purchase_request_id, v.reference, v.organization_name, v.employee_count, v.size_band, v.contact_name, v.email, v.email_domain, p.status_code, v.status, v.is_closed,
              v.status_changed_at, v.assigned_to_user_id, v.customer_id, v.source_code, v.app_version, v.created_at, v.hours_open_or_to_close, p.support_notes
         FROM v_purchase_request v JOIN purchase_request p USING (purchase_request_id) WHERE v.reference = $1`, [reference]);
    if (!r) throw notFound('No such purchase request.', 'not_found');
    const [{ rows: history }, customer, licences] = await Promise.all([
      customerDb.query(`SELECT h.from_status_code, h.to_status_code, h.changed_at, h.changed_by_user_id, h.reason FROM purchase_request_status_history h WHERE h.purchase_request_id = $1 ORDER BY h.changed_at, h.history_id`, [r.purchase_request_id]),
      r.customer_id ? customerDb.query('SELECT customer_id, name FROM customer WHERE customer_id = $1', [r.customer_id]) : { rows: [] },
      r.customer_id ? licenseDb.query(
        `SELECT l.license_id, l.plan_code, l.status_code, l.seat_limit, (SELECT max(ends_at) FROM license_term t WHERE t.license_id = l.license_id) AS expires_at
           FROM license l WHERE l.customer_id = $1 ORDER BY l.created_at DESC`, [r.customer_id]) : { rows: [] },
    ]);
    const names = await namesOf([r.assigned_to_user_id, ...history.map(h => h.changed_by_user_id)]);
    const who = id => (id ? names.get(id) || null : null);
    const { purchase_request_id: _id, ...shown } = r;
    return {
      ...shown, assigned_to_name: who(r.assigned_to_user_id),
      customer: customer.rows[0] ? { id: customer.rows[0].customer_id, name: customer.rows[0].name } : null,
      licences: licences.rows,
      history: history.map(h => ({ ...h, changed_by_name: who(h.changed_by_user_id) })),
    };
  }

  async function requireStaffUser(userId) {
    const { rows } = await identityDb.query(
      `SELECT 1 FROM app_user u WHERE u.user_id = $1 AND u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code IN ('SUPPORT', 'PLATFORM_ADMIN'))`, [userId]);
    if (!rows.length) throw refuse('assignedTo is not an active staff member.', 'unknown_assignee');
  }

  /** Adds a note, assigns, or moves the status, with a reason. The DB enforces the allowed moves and that details are never edited. */
  async function updatePurchaseRequest(reference, body, staff) {
    if (!REFERENCE.test(reference)) throw notFound('No such purchase request.', 'not_found');
    const reason = reasonOf(body);
    const status = body.status === undefined ? undefined : String(body.status).toUpperCase();
    if (status !== undefined && !(await customerDb.query('SELECT 1 FROM purchase_request_status WHERE status_code = $1', [status])).rowCount) throw refuse('That is not a status a request can have.', 'bad_status');
    const hasAssign = Object.prototype.hasOwnProperty.call(body, 'assignedTo');
    const note = body.note === undefined ? undefined : (typeof body.note === 'string' ? stripControl(body.note) : null);
    if (note === null || note === '') throw refuse('note must be some text.', 'bad_note');
    if (note !== undefined && note.length > 1000) throw refuse('Keep a note under 1,000 characters.', 'bad_note');
    if (status === undefined && !hasAssign && note === undefined) throw refuse('Give a status, an assignedTo, or a note to add.', 'nothing_to_change');
    if (hasAssign && body.assignedTo !== null) {
      if (typeof body.assignedTo !== 'string' || !UUID.test(body.assignedTo)) throw refuse('assignedTo must be a staff user id, or null.', 'unknown_assignee');
      await requireStaffUser(body.assignedTo);
    }

    return tx(customerDb, async db => {
      const { rows: [cur] } = await db.query('SELECT purchase_request_id, status_code, support_notes FROM purchase_request WHERE reference = $1 FOR UPDATE', [reference]);
      if (!cur) throw notFound('No such purchase request.', 'not_found');
      await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
      await db.query(`SELECT set_config('app.actor_id', $1, true)`, [staff.userId]);
      const sets = [], params = [cur.purchase_request_id];
      if (status !== undefined && status !== cur.status_code) { params.push(status); sets.push(`status_code = $${params.length}`); }
      if (hasAssign) { params.push(body.assignedTo); sets.push(`assigned_to_user_id = $${params.length}`); }
      if (note !== undefined) {
        const stamped = `${new Date().toISOString().slice(0, 10)} ${staff.displayName || staff.email}: ${note}`;
        const joined = cur.support_notes ? `${cur.support_notes}\n${stamped}` : stamped;
        if (joined.length > 4000) throw refuse('This request\'s notes are full. Summarise the older ones first.', 'notes_full');
        params.push(joined); sets.push(`support_notes = $${params.length}`);
      }
      if (sets.length) {
        try { await db.query(`UPDATE purchase_request SET ${sets.join(', ')} WHERE purchase_request_id = $1`, params); }
        catch (err) {
          if (err.code === '23514' && /cannot go from/.test(err.message)) throw conflict(`A request cannot move from ${cur.status_code} to ${status}.`, 'invalid_transition');
          throw err;
        }
      }
      const { rows: [row] } = await db.query(
        `SELECT p.reference, p.status_code, v.status, p.assigned_to_user_id, p.customer_id, p.status_changed_at
           FROM purchase_request p JOIN v_purchase_request v USING (purchase_request_id) WHERE p.purchase_request_id = $1`, [cur.purchase_request_id]);
      return { before: cur.status_code, after: row };
    });
  }

  // ── Licences ────────────────────────────────────────────────────────────────

  /**
   * Creates the customer if needed, links the purchase request, and issues the licence. The two databases cannot share a transaction,
   * so everything that can be checked is checked first, then the customer step, then the licence. If the licence step fails the customer
   * exists and the request is linked: repeat the call with that customerId. Nothing is half-visible to the app: a customer without a
   * licence grants nothing.
   */
  async function createLicence(body, staff) {
    const reason = reasonOf(body);
    const planCode = typeof body.plan === 'string' ? body.plan : '';
    const kind = body.kind === undefined ? 'paid' : body.kind;
    if (!['paid', 'enterprise', 'pilot'].includes(kind)) throw refuse('kind must be paid, enterprise or pilot.', 'bad_kind');
    const { rows: [plan] } = await licenseDb.query('SELECT plan_code, default_seat_limit, default_term_days, default_grace_days, offline_allowed FROM plan WHERE plan_code = $1 AND is_active', [planCode]);
    if (!plan || plan.plan_code === 'trial') throw refuse('plan must be one of the plans on sale.', 'bad_plan');
    let seats = body.seats === undefined ? plan.default_seat_limit : body.seats;
    if (seats !== null && !(Number.isInteger(seats) && seats >= 1 && seats <= 1_000_000)) throw refuse('seats must be a whole number from 1 to 1,000,000, or null for an enterprise licence.', 'bad_seats');
    if (seats === null && kind !== 'enterprise') throw refuse('Only an enterprise licence may have unlimited seats.', 'bad_seats');
    const termDays = body.termDays === undefined ? plan.default_term_days : body.termDays;
    if (!Number.isInteger(termDays) || termDays < 1 || termDays > 3650) throw refuse('termDays must be a whole number from 1 to 3650.', 'bad_term');
    // The largest licences need an admin: an enterprise licence, unlimited seats, or a term over two years.
    if ((kind === 'enterprise' || seats === null || termDays > 730) && !staff.permissions.has('LICENSE_UNLIMITED')) {
      throw new ApiError(403, 'An enterprise licence, unlimited seats, or a term over 730 days needs an admin.', 'needs_admin');
    }
    let startsAt = null;
    if (body.startsAt !== undefined) {
      startsAt = new Date(body.startsAt);
      if (typeof body.startsAt !== 'string' || !/^\d{4}-\d{2}-\d{2}/.test(body.startsAt) || Number.isNaN(startsAt.getTime()) || startsAt.getFullYear() < 2020 || startsAt.getFullYear() > 2100) throw refuse('startsAt must be a date such as 2026-11-01 (between 2020 and 2100).', 'bad_term');
    }
    const hasCustomerId = body.customerId !== undefined, hasNewCustomer = body.customer !== undefined;
    if (hasCustomerId === hasNewCustomer && !body.purchaseRequest) throw refuse('Give customerId (an existing customer) or customer.name (a new one), or a purchaseRequest to take it from.', 'customer_required');
    if (hasCustomerId && hasNewCustomer) throw refuse('Give customerId or customer, not both.', 'customer_required');
    if (hasCustomerId && (typeof body.customerId !== 'string' || !UUID.test(body.customerId))) throw refuse('customerId must be a customer id.', 'unknown_customer');
    if (body.purchaseRequest !== undefined && (typeof body.purchaseRequest !== 'string' || !REFERENCE.test(body.purchaseRequest))) throw refuse('purchaseRequest must look like PR-000123.', 'bad_reference');

    // Step 1 (customer database): find or create the customer, and link the request.
    const customer = await tx(customerDb, async db => {
      let request = null;
      if (body.purchaseRequest) {
        ({ rows: [request] } = await db.query('SELECT purchase_request_id, status_code, customer_id, organization_name FROM purchase_request WHERE reference = $1 FOR UPDATE', [body.purchaseRequest]));
        if (!request) throw notFound('No such purchase request.', 'not_found');
        if (request.status_code !== 'AGREED') throw conflict('Move the request to AGREED (with a reason) before creating its licence.', 'request_not_agreed');
        // One request, one licence: a repeat (a double click, a retry) must not make a second live licence whose key nobody was shown.
        // For a further licence for the same customer, or to retry after a failure, call again with customerId and no purchaseRequest.
        if (request.customer_id) throw conflict(`This request is already linked to a customer (${request.customer_id}). For another licence for that customer, or to retry one that failed, give customerId and no purchaseRequest.`, 'request_linked', { customerId: request.customer_id });
      }
      let customerId = hasCustomerId ? body.customerId : (request && request.customer_id) || null;
      let created = false, name;
      if (customerId) {
        const { rows } = await db.query('SELECT customer_id, name FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [customerId]);
        if (!rows.length) throw notFound('No such customer.', 'unknown_customer');
        name = rows[0].name;
      } else {
        const given = hasNewCustomer && body.customer && typeof body.customer.name === 'string' ? stripControl(body.customer.name) : (request ? request.organization_name : '');
        if (!given || given.length > 200) throw refuse('customer.name is required (1 to 200 characters).', 'customer_required');
        customerId = uuidv7(); name = given; created = true;
        const slug = `${given.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50) || 'customer'}-${crypto.randomBytes(3).toString('hex')}`;
        await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
        await db.query(`SELECT set_config('app.actor_id', $1, true)`, [staff.userId]);
        await db.query(`INSERT INTO customer (customer_id, name, slug, status_code, source_code) VALUES ($1, $2, $3, 'ACTIVE', 'sales')`, [customerId, given, slug]);
      }
      if (request) {
        await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
        await db.query(`SELECT set_config('app.actor_id', $1, true)`, [staff.userId]);
        await db.query('UPDATE purchase_request SET customer_id = $2 WHERE purchase_request_id = $1', [request.purchase_request_id, customerId]);
      }
      return { customerId, name, created };
    });

    // Step 2 (licence database): the licence, its term and its features.
    let issued;
    try {
      issued = await tx(licenseDb, db => issueLicence(db, licenceHash, { customerId: customer.customerId, plan, kind, seats, startsAt, termDays, reason, actorUserId: staff.userId }));
    } catch (err) {
      // The customer now exists. Say so, and in the audit trail too, so the retry uses it instead of making a second customer.
      throw new ApiError(500, `The customer was created but the licence was not. Try again with customerId ${customer.customerId}.`, 'licence_failed', { customerId: customer.customerId });
    }
    return { ...issued, customerId: customer.customerId, customerName: customer.name, customerCreated: customer.created, plan: plan.plan_code, kind, seats, termDays };
  }

  // ── Domains ─────────────────────────────────────────────────────────────────

  async function attachDomain(body) {
    const reason = reasonOf(body);
    if (typeof body.customerId !== 'string' || !UUID.test(body.customerId)) throw refuse('customerId must be a customer id.', 'unknown_customer');
    const domain = typeof body.domain === 'string' ? body.domain.trim().toLowerCase() : '';
    if (!domain || !validDomain(domain)) throw refuse('domain must be a domain such as acme.com.', 'bad_domain');
    if (PUBLIC_SUFFIXES.has(domain) || SUFFIX_SHAPES.some(re => re.test(domain))) throw refuse(`${domain} is a public suffix shared by many organisations, not one organisation's domain.`, 'bad_domain');
    if (PUBLIC_MAIL_DOMAINS.has(domain)) throw refuse(`${domain} is a public mailbox domain: anyone with a free account there could activate this customer's licence.`, 'public_mail_domain');
    return tx(customerDb, async db => {
      const { rows } = await db.query('SELECT 1 FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [body.customerId]);
      if (!rows.length) throw notFound('No such customer.', 'unknown_customer');
      const { rows: [taken] } = await db.query('SELECT customer_id FROM customer_domain WHERE domain = $1', [domain]);
      if (taken) throw conflict(taken.customer_id === body.customerId ? 'That domain is already attached to this customer.' : 'That domain already belongs to another customer.', 'domain_taken');
      // Support attaches it after checking ownership with the customer, so it is recorded as verified now; the audit trail holds who and why.
      try {
        await db.query(
          `INSERT INTO customer_domain (domain_id, customer_id, domain, verification_token_hash, verified_at) VALUES ($1, $2, $3, $4, now())`,
          [uuidv7(), body.customerId, domain, crypto.randomBytes(32).toString('hex')]);
      } catch (err) {
        if (err.code === '23505') throw conflict('That domain already belongs to another customer.', 'domain_taken');    // someone attached it a moment ago
        throw err;
      }
      return { customerId: body.customerId, domain, verified: true, reason };
    });
  }

  return { listPurchaseRequests, getPurchaseRequest, updatePurchaseRequest, namesOf, createLicence, attachDomain, reasonOf };
}

module.exports = { createAdmin, PUBLIC_MAIL_DOMAINS };
