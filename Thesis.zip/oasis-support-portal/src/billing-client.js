'use strict';
const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const { ApiError } = require('./errors');

const MAX_BODY = 20 * 1024 * 1024;       // an export of 10,000 invoices is a few MB

const unavailable = () => new ApiError(502, 'Billing is not available right now. Please try again in a moment.', 'billing_unavailable');
const misconfigured = () => new ApiError(502, 'Billing is not set up correctly. Tell the person who runs the portal.', 'billing_misconfigured');

/**
 * The portal's one way to talk to the billing service. A FIXED list of methods, one per endpoint: there is no call that forwards a path or a body it was handed
 * (that would be a proxy). Every call says who is acting and in which role; the service key never leaves this file and never reaches a log.
 * Errors: a refusal from billing (4xx) is passed on as it is. A 401 or a bad_actor answer means THIS portal is misconfigured: a 401 to the browser would sign the person
 * out for no reason, so it becomes a 502. Everything else (5xx, no answer, a timeout, something that is not JSON) is 502 billing_unavailable and says nothing about why.
 */
function createBillingClient({ baseUrl, serviceKey, caFile = '', timeoutMs = 10_000, log = () => {} }) {
  const base = new URL(baseUrl);
  const secure = base.protocol === 'https:';
  const transport = secure ? https : http;
  const agent = new transport.Agent({ keepAlive: true, ...(secure && caFile ? { ca: fs.readFileSync(caFile) } : {}) });

  function call(method, path, { actor, body, query, idempotencyKey } = {}) {
    return new Promise((resolve, reject) => {
      const qs = query ? new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => [k, String(v)])).toString() : '';
      const payload = body === undefined ? null : JSON.stringify(body);
      const headers = { Accept: 'application/json', 'X-Service-Key': serviceKey, 'X-Acting-User': actor.userId, 'X-Acting-Role': actor.role };
      if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
      if (payload !== null) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(payload); }
      let settled = false;
      const done = (fn, value) => { if (!settled) { settled = true; fn(value); } };
      const req = transport.request({ agent, hostname: base.hostname, port: base.port || (secure ? 443 : 80), method, path: `/v1/staff${path}${qs ? `?${qs}` : ''}`, headers, timeout: timeoutMs }, res => {
        const chunks = []; let size = 0;
        res.on('data', c => { size += c.length; if (size > MAX_BODY) { req.destroy(Object.assign(new Error('too large'), { code: 'EBODY' })); return; } chunks.push(c); });
        res.on('error', err => { log({ level: 'error', msg: 'billing answer failed', code: err.code }); done(reject, unavailable()); });
        res.on('end', () => {
          let parsed = null;
          try { parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { /* not JSON */ }
          const status = res.statusCode;
          if (status >= 200 && status < 300 && parsed !== null) return done(resolve, { status, body: parsed, replayed: res.headers['idempotent-replayed'] === 'true' });
          if (status === 401 || (parsed && parsed.reason === 'bad_actor')) { log({ level: 'error', msg: 'billing refused the portal', status }); return done(reject, misconfigured()); }
          if (status >= 400 && status < 500 && parsed && typeof parsed.message === 'string') {
            const { error: _e, message, reason, requestId: _r, ...extra } = parsed;
            return done(reject, new ApiError(status, message, reason, extra));
          }
          log({ level: 'error', msg: 'billing failed', status });
          done(reject, unavailable());
        });
      });
      req.on('timeout', () => req.destroy(Object.assign(new Error('timeout'), { code: 'ETIMEDOUT' })));
      req.on('error', err => { log({ level: 'error', msg: 'billing unreachable', code: err.code }); done(reject, unavailable()); });
      if (payload !== null) req.write(payload);
      req.end();
    });
  }

  const id = v => encodeURIComponent(v);
  return {
    settings: actor => call('GET', '/settings', { actor }),
    whoami: actor => call('GET', '/whoami', { actor }),
    createInvoice: (actor, body, idempotencyKey) => call('POST', '/invoices', { actor, body, idempotencyKey }),
    listInvoices: (actor, query) => call('GET', '/invoices', { actor, query }),
    getInvoice: (actor, invoiceId) => call('GET', `/invoices/${id(invoiceId)}`, { actor }),
    updateDraft: (actor, invoiceId, body) => call('PATCH', `/invoices/${id(invoiceId)}`, { actor, body }),
    cancelDraft: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/cancel`, { actor, body }),
    issue: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/issue`, { actor, body }),
    markSent: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/mark-sent`, { actor, body }),
    voidInvoice: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/void`, { actor, body }),
    recordPayment: (actor, invoiceId, body, idempotencyKey) => call('POST', `/invoices/${id(invoiceId)}/payments`, { actor, body, idempotencyKey }),
    voidPayment: (actor, invoiceId, paymentId, body) => call('POST', `/invoices/${id(invoiceId)}/payments/${id(paymentId)}/void`, { actor, body }),
    creditNote: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/credit-notes`, { actor, body }),
    changeOwner: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/owner`, { actor, body }),
    logFollowUp: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/follow-ups`, { actor, body }),
    followUpQueue: (actor, query) => call('GET', '/follow-ups/queue', { actor, query }),
    followUpSummary: (actor, query) => call('GET', '/follow-ups/summary', { actor, query }),
    createLink: (actor, invoiceId, body) => call('POST', `/invoices/${id(invoiceId)}/links`, { actor, body }),
    revokeLink: (actor, invoiceId, linkId) => call('POST', `/invoices/${id(invoiceId)}/links/${id(linkId)}/revoke`, { actor, body: {} }),
    dashboard: actor => call('GET', '/reports/dashboard', { actor }),
    exportRows: (actor, query) => call('GET', '/reports/export', { actor, query }),
  };
}

module.exports = { createBillingClient };
