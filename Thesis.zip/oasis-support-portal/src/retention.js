'use strict';
// Deletes records that are older than their retention period, so the identity database does not keep personal and security data for longer than it needs to.
//
//   node src/retention.js            shows what WOULD be deleted (a dry run: nothing changes)
//   node src/retention.js --apply    deletes it
//
// Run it on a schedule (for example once a day) with IDENTITY_DATABASE_URL set. The periods are settings, in days; "never" keeps that kind of record for ever.
// What is covered, and the default period:
//   sessions         ended sessions                                   30 days after they ended or expired   RETENTION_SESSIONS_DAYS
//   links            used, withdrawn or expired activation/reset links, and old sign-in codes   30 days     RETENTION_LINKS_DAYS
//   login events     the sign-in history                              400 days                              RETENTION_LOGIN_EVENTS_DAYS
//   notifications    the bell's notifications                         90 days                               RETENTION_NOTIFICATIONS_DAYS
//   replies          the record of replies sent to customers          730 days (it holds what staff wrote)  RETENTION_REPLIES_DAYS
//   audit            the audit trail of what staff did                2555 days (7 years)                   RETENTION_AUDIT_DAYS
// NOT covered, on purpose: customer notes, the status histories (team members, customers' users) and request notes. They are business records, not logs.
// The periods are a starting point: the company's records policy decides them. Audit rows are append-only: only this job may delete them, and it says so to the database
// (app.retention = 'on') inside its own transaction.
const { createPool, tx } = require('./db');

const DEFAULTS = { sessions: 30, links: 30, loginEvents: 400, notifications: 90, replies: 730, audit: 2555 };
const ENV = { sessions: 'RETENTION_SESSIONS_DAYS', links: 'RETENTION_LINKS_DAYS', loginEvents: 'RETENTION_LOGIN_EVENTS_DAYS', notifications: 'RETENTION_NOTIFICATIONS_DAYS', replies: 'RETENTION_REPLIES_DAYS', audit: 'RETENTION_AUDIT_DAYS' };
const MINIMUM = { sessions: 7, links: 7, loginEvents: 90, notifications: 7, replies: 30, audit: 365 };      // a typo must not wipe the trail

/** The periods, from the environment, checked. A value of "never" (or "0") keeps that kind for ever: it becomes null. */
function policyFrom(env = process.env) {
  const policy = {};
  for (const [key, name] of Object.entries(ENV)) {
    const raw = env[name];
    if (raw === undefined || raw === '') { policy[key] = DEFAULTS[key]; continue; }
    if (raw === 'never' || raw === '0') { policy[key] = null; continue; }
    const n = Number(raw);
    if (!/^\d+$/.test(raw) || n < MINIMUM[key] || n > 36500) throw new Error(`${name} must be "never" or a whole number of days from ${MINIMUM[key]} to 36500.`);
    policy[key] = n;
  }
  return policy;
}

/** What to delete for each kind. `where` is the condition on a row older than the cutoff; the same condition counts (dry run) and deletes. */
const KINDS = [
  { key: 'sessions', table: 'session', where: `least(coalesce(revoked_at, expires_at), expires_at) < $1 AND NOT EXISTS (SELECT 1 FROM session s2 WHERE s2.replaced_by_session_id = session.session_id)` },
  { key: 'links', table: 'staff_link', where: `created_at < $1 AND (used_at IS NOT NULL OR revoked_at IS NOT NULL OR expires_at < now())` },
  { key: 'links', table: 'otp_challenge', where: `created_at < $1 AND (closed_at IS NOT NULL OR expires_at < now())` },
  { key: 'loginEvents', table: 'login_event', where: `occurred_at < $1` },
  { key: 'loginEvents', table: 'activity_event', where: `occurred_at < $1` },
  { key: 'notifications', table: 'staff_notification', where: `created_at < $1` },
  { key: 'replies', table: 'customer_reply', where: `created_at < $1` },
];

/**
 * Counts (and, with `apply`, deletes) the records past their period. Returns { table: count }. Everything happens in one transaction, so a failure leaves nothing half done.
 * `now` is injectable so a test can say what "now" is.
 */
async function runRetention(identityDb, policy, { apply = false, now = new Date() } = {}) {
  const cutoff = days => new Date(now.getTime() - days * 86_400_000);
  const report = {};
  await tx(identityDb, async db => {
    if (apply) await db.query(`SELECT set_config('app.retention', 'on', true)`);
    for (const kind of KINDS) {
      if (policy[kind.key] === null || policy[kind.key] === undefined) { report[kind.table] = { kept: 'for ever' }; continue; }
      const c = cutoff(policy[kind.key]);
      const sql = apply ? `DELETE FROM ${kind.table} WHERE ${kind.where}` : `SELECT 1 FROM ${kind.table} WHERE ${kind.where}`;
      const r = await db.query(sql, [c]);
      report[kind.table] = { days: policy[kind.key], [apply ? 'deleted' : 'wouldDelete']: r.rowCount };
    }
    // The audit trail points at itself (a closing row names its opening row): close the ends first, then the openings and reads that nothing points at any more.
    if (policy.audit === null || policy.audit === undefined) report.admin_audit = { kept: 'for ever' };
    else {
      const c = cutoff(policy.audit);
      const ends = await db.query(apply ? `DELETE FROM admin_audit WHERE occurred_at < $1 AND outcome IN ('done', 'failed')` : `SELECT 1 FROM admin_audit WHERE occurred_at < $1 AND outcome IN ('done', 'failed')`, [c]);
      const rest = await db.query(apply
        ? `DELETE FROM admin_audit a WHERE a.occurred_at < $1 AND NOT EXISTS (SELECT 1 FROM admin_audit e WHERE e.started_audit_id = a.audit_id)`
        : `SELECT 1 FROM admin_audit a WHERE a.occurred_at < $1 AND a.outcome IN ('started', 'read') AND NOT EXISTS (SELECT 1 FROM admin_audit e WHERE e.started_audit_id = a.audit_id AND e.occurred_at >= $1)`, [c]);
      report.admin_audit = { days: policy.audit, [apply ? 'deleted' : 'wouldDelete']: ends.rowCount + rest.rowCount };
    }
  });
  return report;
}

module.exports = { runRetention, policyFrom, DEFAULTS };

if (require.main === module) {
  (async () => {
    if (!process.env.IDENTITY_DATABASE_URL) throw new Error('IDENTITY_DATABASE_URL is required.');
    const apply = process.argv.includes('--apply');
    const unknown = process.argv.slice(2).filter(a => a !== '--apply');
    if (unknown.length) throw new Error(`Unknown argument "${unknown[0]}". Use --apply to delete; without it nothing is deleted.`);
    const policy = policyFrom();
    const db = createPool(process.env.IDENTITY_DATABASE_URL);
    try {
      const report = await runRetention(db, policy, { apply });
      console.log(JSON.stringify({ level: 'info', msg: apply ? 'retention applied' : 'retention dry run (nothing deleted; add --apply to delete)', report }));
    } finally { await db.end(); }
  })().catch(err => { console.error(err.message); process.exit(1); });
}
