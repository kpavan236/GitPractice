'use strict';
const { ApiError, refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { stripControl } = require('./forms');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const notFound = what => new ApiError(404, `No such ${what}.`, 'not_found');
const conflict = (message, reason) => new ApiError(409, message, reason);
const ACTIONS = ['disable', 'enable', 'reinvite', 'remove'];

/** A note keeps its line breaks; every other control character (and bidirectional tricks) is removed. Built from character codes so no invisible character sits in this file. */
const chr = n => String.fromCharCode(n);
const LINE_BREAKS = new RegExp(`\\r\\n?|${chr(0x85)}|${chr(0x2028)}|${chr(0x2029)}`, 'g');
const BAD_CHARS = new RegExp(`[${[[0, 9], [11, 31], [127, 127], [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064], [0x2066, 0x2069], [0xfeff, 0xfeff]].map(([x, y]) => `${chr(x)}-${chr(y)}`).join('')}]`, 'g');
const cleanNote = t => String(t).replace(LINE_BREAKS, '\n').replace(BAD_CHARS, '').split('\n').map(l => l.trimEnd()).join('\n').replace(/\n{3,}/g, '\n\n').trim();

function validZone(zone) { try { new Intl.DateTimeFormat('en', { timeZone: zone }); return /^[A-Za-z_]+(\/[A-Za-z0-9_+-]+){0,2}$|^UTC$/.test(zone); } catch { return false; } }

/**
 * What admins do with customers that is not about a licence: correct the details we hold, keep notes, and look after the customer's own users (disable, enable, re-invite,
 * remove). The customer record and its lookup lists live in the customer database; the notes and the users live in the identity database. A customer's status (prospect, trial,
 * active, churned) is not changed here. Every change needs a reason and is audited by the route.
 */
function createCustomerAdmin({ identityDb, customerDb, namesOf }) {
  const withReason = async (db, reason, actorId) => {
    await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await db.query(`SELECT set_config('app.actor_id', $1, true)`, [actorId]);
  };

  /** The lists the edit form offers. */
  async function options() {
    const [industries, sizes, countries] = await Promise.all([
      customerDb.query('SELECT industry_code AS code, label FROM industry ORDER BY label'),
      customerDb.query('SELECT size_band_code AS code, label FROM company_size_band ORDER BY sort_order'),
      customerDb.query('SELECT country_code AS code, name AS label FROM country ORDER BY name'),
    ]);
    return { industries: industries.rows, sizeBands: sizes.rows, countries: countries.rows };
  }

  async function update(customerId, body, reason, staff) {
    if (typeof customerId !== 'string' || !UUID.test(customerId)) throw notFound('customer');
    const set = [], params = [customerId], note = {};
    const add = (column, value, key) => { params.push(value); set.push(`${column} = $${params.length}`); note[key] = true; };
    if (body.name !== undefined) {
      const name = typeof body.name === 'string' ? stripControl(body.name) : '';
      if (!name || name.length > 200) throw refuse('name is required (1 to 200 characters).', 'bad_name');
      add('name', name, 'name');
    }
    if (body.legalName !== undefined) {
      const v = body.legalName === null ? null : (typeof body.legalName === 'string' ? stripControl(body.legalName) : undefined);
      if (v === undefined || (v !== null && (v.length > 200))) throw refuse('legalName must be text up to 200 characters, or null.', 'bad_legal_name');
      add('legal_name', v || null, 'legalName');
    }
    if (body.website !== undefined) {
      let v = body.website;
      if (v !== null) {
        v = typeof v === 'string' ? v.trim() : '';
        let u; try { u = new URL(v); } catch { u = null; }
        if (!u || !['http:', 'https:'].includes(u.protocol) || v.length > 300 || /\s/.test(v) || u.username || u.password) throw refuse('website must be a web address starting with http:// or https://, or null.', 'bad_website');
      }
      add('website', v || null, 'website');
    }
    for (const [key, column, table, codeColumn] of [['industry', 'industry_code', 'industry', 'industry_code'], ['sizeBand', 'size_band_code', 'company_size_band', 'size_band_code']]) {
      if (body[key] === undefined) continue;
      if (body[key] !== null) {
        if (typeof body[key] !== 'string' || !(await customerDb.query(`SELECT 1 FROM ${table} WHERE ${codeColumn} = $1`, [body[key]])).rowCount) throw refuse(`${key} is not one of the offered values.`, `bad_${key}`);
      }
      add(column, body[key], key);
    }
    if (body.country !== undefined) {
      if (body.country !== null) {
        if (typeof body.country !== 'string' || !(await customerDb.query('SELECT 1 FROM country WHERE country_code = $1', [body.country.toUpperCase()])).rowCount) throw refuse('country is not one of the offered values.', 'bad_country');
      }
      add('country_code', body.country === null ? null : body.country.toUpperCase(), 'country');
    }
    if (body.timezone !== undefined) {
      if (typeof body.timezone !== 'string' || !validZone(body.timezone)) throw refuse('timezone must be a time zone such as Europe/London or UTC.', 'bad_timezone');
      add('timezone', body.timezone, 'timezone');
    }
    if (!set.length) throw refuse('Give a detail to change: name, legalName, website, industry, sizeBand, country or timezone.', 'nothing_to_change');
    return tx(customerDb, async db => {
      const { rows: [before] } = await db.query('SELECT customer_id FROM customer WHERE customer_id = $1 AND deleted_at IS NULL FOR UPDATE', [customerId]);
      if (!before) throw notFound('customer');
      await withReason(db, reason, staff.userId);
      await db.query(`UPDATE customer SET ${set.join(', ')} WHERE customer_id = $1`, params);
      const { rows: [after] } = await db.query('SELECT customer_id, name, legal_name, website, industry_code, size_band_code, country_code, timezone FROM customer WHERE customer_id = $1', [customerId]);
      return { changed: Object.keys(note), after };
    });
  }

  // ── Notes ───────────────────────────────────────────────────────────────────

  async function listNotes(customerId) {
    const { rows } = await identityDb.query('SELECT note_id, body, created_by_user_id, created_at FROM customer_note WHERE customer_id = $1 ORDER BY created_at, note_id', [customerId]);
    const names = await namesOf(rows.map(r => r.created_by_user_id));
    return rows.map(r => ({ id: r.note_id, body: r.body, createdAt: r.created_at, by: names.get(r.created_by_user_id) || null }));
  }

  async function addNote(customerId, body, staff) {
    if (typeof customerId !== 'string' || !UUID.test(customerId)) throw notFound('customer');
    const text = typeof body === 'string' ? cleanNote(body) : '';
    if (!text || text.length > 4000) throw refuse('A note is 1 to 4000 characters.', 'bad_note');
    if (!(await customerDb.query('SELECT 1 FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [customerId])).rowCount) throw notFound('customer');
    const id = uuidv7();
    await identityDb.query('INSERT INTO customer_note (note_id, customer_id, body, created_by_user_id) VALUES ($1, $2, $3, $4)', [id, customerId, text, staff.userId]);
    return { id, length: text.length };
  }

  // ── A customer's own users ──────────────────────────────────────────────────

  /**
   * disable: they cannot sign in to the app, and their sessions end. enable: they can again (Active if they had signed in before, otherwise still waiting to activate).
   * reinvite: back to "invited", so they can activate again from the app with their work address (we send nothing: there is no email sender yet, and the app does the activation).
   * remove: their account is closed and hidden; the address stays reserved, so the same person cannot be added twice by accident. Nothing here deletes history.
   */
  async function manageUser(customerId, userId, action, reason, staff) {
    if (typeof customerId !== 'string' || !UUID.test(customerId) || typeof userId !== 'string' || !UUID.test(userId)) throw notFound('user');
    if (!ACTIONS.includes(action)) throw notFound('action');
    return tx(identityDb, async db => {
      const { rows: [u] } = await db.query(
        `SELECT user_id, status_code, first_login_at FROM app_user WHERE user_id = $1 AND customer_id = $2 AND user_type_code = 'customer' AND deleted_at IS NULL FOR UPDATE`, [userId, customerId]);
      if (!u) throw notFound('user');
      const from = u.status_code;
      let to = from, remove = false;
      if (action === 'disable') { if (from === 'DISABLED') throw conflict('That person is already disabled.', 'wrong_state'); to = 'DISABLED'; }
      if (action === 'enable') { if (!['DISABLED', 'LOCKED'].includes(from)) throw conflict('Only a disabled or locked person can be enabled.', 'wrong_state'); to = u.first_login_at ? 'ACTIVE' : 'INVITED'; }
      if (action === 'reinvite') { if (!['DISABLED', 'LOCKED', 'INVITED'].includes(from)) throw conflict('That person is already active. Disable them first if they must start again.', 'wrong_state'); to = 'INVITED'; }
      if (action === 'remove') { to = 'DISABLED'; remove = true; }
      await withReason(db, reason, staff.userId);
      if (to !== from) await db.query('UPDATE app_user SET status_code = $2 WHERE user_id = $1', [userId, to]);
      if (remove) await db.query('UPDATE app_user SET deleted_at = now() WHERE user_id = $1', [userId]);
      if (to !== 'ACTIVE') await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'admin' WHERE user_id = $1 AND revoked_at IS NULL`, [userId]);
      return { from, to, removed: remove };
    });
  }

  return { options, update, listNotes, addNote, manageUser, ACTIONS };
}

module.exports = { createCustomerAdmin };
