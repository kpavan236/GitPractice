'use strict';
const crypto = require('node:crypto');
const path = require('node:path');
const express = require('express');
const { errorHandler, refuse, wrap } = require('./errors');
const { rateLimit } = require('./rate-limit');
const { createHasher } = require('./secrets');
const { createAuth } = require('./auth');
const { createAudit } = require('./audit');
const { createAdmin } = require('./admin');
const { createLifecycle } = require('./lifecycle');
const { createSupportMessages } = require('./support-messages');
const { createUsers } = require('./users');
const { createCustomerAdmin } = require('./customer-admin');
const { customerAdminRoutes } = require('./routes/customer-admin');
const { exportRoutes } = require('./routes/export');
const { createStaffTools } = require('./staff-tools');
const { staffToolsRoutes } = require('./routes/staff-tools');
const { createBilling } = require('./billing');
const { billingRoutes } = require('./routes/billing');
const { createOverview } = require('./overview');
const { createFakeNotifier } = require('./notifier');
const SESSION_COOKIE = 'oasis_portal';
const readCookie = (header, name) => { for (const part of String(header || '').split(';')) { const i = part.indexOf('='); if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim(); } return null; };
const { authRoutes } = require('./routes/auth');
const { adminRoutes } = require('./routes/admin');
const { lifecycleRoutes } = require('./routes/lifecycle');
const { supportMessageRoutes } = require('./routes/support-messages');
const { teamRoutes } = require('./routes/team');
const { overviewRoutes } = require('./routes/overview');

/**
 * Builds the HTTP app. Everything it needs is passed in, so tests hand it throwaway databases.
 * Logging: one line per request (method, path, status, time, request id). Never a body, an address, a code or a token.
 */
function createApp({ identityDb, customerDb, licenseDb, supportDb, hashPepper, licenceHashPepper, platformCustomerId, staffEmailDomains = [], secureCookies = true, tls = false, passwordCost, portalBaseUrl = 'http://127.0.0.1:4030', notifier = createFakeNotifier(), billing = null, sessionHours = 8, trustProxy = 0,
  limiter = rateLimit({ max: 600 }), authLimiter = rateLimit({ max: 20 }), log = line => console.log(JSON.stringify(line)) }) {
  // `passwordCost` makes password hashing cheap so tests and the demo run fast. The real server never passes it, and a cheap hash is refused in production.
  if (passwordCost && process.env.NODE_ENV === 'production') throw new Error('A reduced password-hashing cost is for tests only; it is not allowed in production.');
  const hash = createHasher(hashPepper);
  const auth = createAuth({ identityDb, hash, notifier, log, sessionHours, portalBaseUrl, ...(passwordCost ? { passwordCost } : {}) });
  const audit = createAudit({ identityDb, log });
  const users = createUsers({ identityDb, platformCustomerId, staffEmailDomains, auth });
  const messages = createSupportMessages({ supportDb, customerDb, identityDb });
  const lifecycle = createLifecycle({ licenseDb, customerDb, licenceHash: createHasher(licenceHashPepper) });
  const admin = createAdmin({ identityDb, customerDb, licenseDb, licenceHash: createHasher(licenceHashPepper) });

  const billingHelper = createBilling({ client: billing, namesOf: ids => admin.namesOf(ids), identityDb, customerDb, licenseDb });

  const tools = createStaffTools({ identityDb, customerDb, supportDb, notifier, namesOf: ids => admin.namesOf(ids), identityDb, customerDb, licenseDb });
  const customerAdmin = createCustomerAdmin({ identityDb, customerDb, namesOf: ids => admin.namesOf(ids), identityDb, customerDb, licenseDb });
  const overview = createOverview({ identityDb, customerDb, licenseDb, supportDb, lifecycle, namesOf: ids => admin.namesOf(ids), customerAdmin });

  /**
   * Route guard: a signed-in staff member (401 otherwise) who holds the permission (403 otherwise).
   *
   * Two ways in. A bearer token (API clients, scripts, tests) needs nothing else. The browser portal uses an HttpOnly cookie, which the browser attaches to ANY request
   * to this site, including one a malicious page makes it send; so a cookie session must also prove the request came from the portal: an X-CSRF-Token that only the portal's
   * own page was given, and (when the browser says where the request came from) a matching Origin. SameSite=Strict on the cookie is the first line; these are the second.
   */
  const requireStaff = permission => wrap(async (req, _res, next) => {
    const header = req.get('Authorization') || '';
    let staff = null, viaCookie = false;
    if (header.startsWith('Bearer ')) staff = await auth.authenticate(header.slice(7).trim());
    else {
      const token = readCookie(req.get('Cookie'), SESSION_COOKIE);
      if (token) { staff = await auth.authenticate(token); viaCookie = !!staff; if (staff) req.sessionToken = token; }
    }
    if (!staff) throw refuse('Sign in to continue.', 'sign_in_required', {}, 401);
    if (viaCookie) {
      const origin = req.get('Origin');
      if (origin && (() => { try { return new URL(origin).host !== req.get('Host'); } catch (_) { return true; } })()) throw refuse('That request did not come from the portal.', 'bad_origin', {}, 403);
      if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
        const sent = Buffer.from(req.get('X-CSRF-Token') || '', 'utf8'), want = Buffer.from(csrfOf(req.sessionToken), 'utf8');     // compared as bytes: a non-ASCII token of the same length must be a refusal, not an error
        if (sent.length !== want.length || !crypto.timingSafeEqual(sent, want)) throw refuse('That request did not come from the portal.', 'bad_csrf', {}, 403);
      }
    }
    if (permission && !staff.permissions.has(permission)) throw refuse('You do not have permission to do that.', 'forbidden', {}, 403);
    req.staff = staff; req.viaCookie = viaCookie;
    next();
  });
  const csrfOf = sessionToken => hash('csrf', sessionToken);

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);
  app.use((req, res, next) => {
    req.id = crypto.randomUUID();       // always ours: it goes into the audit trail, so a caller must not be able to choose it
    res.set('X-Request-Id', req.id);
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Cache-Control', 'no-store');
    const started = Date.now();
    res.on('finish', () => log({ level: 'info', requestId: req.id, method: req.method, path: req.path, status: res.statusCode, ms: Date.now() - started }));
    next();
  });

  // The portal's own pages. A strict content policy: only this site's own scripts and styles run, nothing is loaded from elsewhere, nothing can frame the portal, and the
  // page can talk only to this site. The pages are written without inline scripts or styles so none of that has to be loosened.
  app.use((req, res, next) => {
    res.set('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    res.set('X-Frame-Options', 'DENY');
    res.set('Referrer-Policy', 'no-referrer');
    res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    res.set('Cross-Origin-Opener-Policy', 'same-origin');
    res.set('Cross-Origin-Resource-Policy', 'same-origin');
    if (tls) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });
  app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', dotfiles: 'ignore', etag: true, setHeaders: res => res.set('Cache-Control', 'no-cache') }));

  app.get('/healthz', (_req, res) => res.json({ ok: true }));
  app.get('/readyz', async (_req, res) => {
    try { await Promise.all([identityDb, customerDb, licenseDb, supportDb].map(db => db.query('SELECT 1'))); res.json({ ok: true }); }
    catch (_) { res.status(503).json({ ok: false }); }
  });

  const v1 = express.Router();
  v1.use(limiter);        // generous: a signed-in team (possibly behind one office address) makes many calls; asking for a code has its own strict limit below
  v1.use(express.json({ limit: '16kb' }));
  // Only signing in, asking for a link and using one are limited hard. /auth/me and /auth/config run on every page load, and a whole team may share one office address.
  v1.use('/admin/auth/login', authLimiter);
  v1.use('/admin/auth/password/forgot', authLimiter);
  v1.use('/admin/auth/link/check', authLimiter);
  v1.use('/admin/auth/link/complete', authLimiter);
  v1.use('/admin/auth/password/change', authLimiter);
  v1.use('/admin', authRoutes({ auth, hash, requireStaff, csrfOf, cookie: { name: SESSION_COOKIE, secure: secureCookies, maxAgeSeconds: sessionHours * 3600 }, emailDelivery: notifier.kind || 'fake' }));
  v1.use('/admin', overviewRoutes({ overview, audit, requireStaff }));
  v1.use('/admin', exportRoutes({ overview, audit, requireStaff }));
  v1.use('/admin', customerAdminRoutes({ customerAdmin, admin, audit, requireStaff }));
  v1.use('/admin', teamRoutes({ users, admin, audit, requireStaff }));
  v1.use('/admin', staffToolsRoutes({ tools, audit, requireStaff }));
  v1.use('/admin', adminRoutes({ admin, audit, requireStaff, tools }));
  v1.use('/admin', supportMessageRoutes({ messages, admin, audit, requireStaff, tools }));
  v1.use('/admin', lifecycleRoutes({ lifecycle, admin, audit, requireStaff }));
  v1.use('/admin', billingRoutes({ billing: billingHelper, audit, admin, requireStaff }));
  app.use('/v1', v1);

  app.use((req, res) => res.status(404).json({ error: 'not_found', message: 'No such route.', requestId: req.id }));
  app.use(errorHandler(log));
  return app;
}

module.exports = { createApp };
