'use strict';
const { ApiError, refuse } = require('./errors');
const { uuidv7 } = require('./uuid');
const { stripControl } = require('./forms');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const REFERENCE = /^[A-Za-z0-9-]{1,40}$/;
const KINDS = { licence_request: { label: 'Licence request' }, help_request: { label: 'Help request' } };
const chr = n => String.fromCharCode(n);
const LINE_BREAKS = new RegExp(`\\r\\n?|${chr(0x85)}|${chr(0x2028)}|${chr(0x2029)}`, 'g');
const BAD_CHARS = new RegExp(`[${[[0, 9], [11, 31], [127, 127], [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064], [0x2066, 0x2069], [0xfeff, 0xfeff]].map(([x, y]) => `${chr(x)}-${chr(y)}`).join('')}]`, 'g');
const cleanBody = t => String(t).replace(LINE_BREAKS, '\n').replace(BAD_CHARS, '').split('\n').map(l => l.trimEnd()).join('\n').replace(/\n{3,}/g, '\n\n').trim();

/**
 * What staff use day to day beyond the lists: the bell (notifications), replying to a customer, and the workload page. Notifications, replies and notes live in the identity
 * database, which this portal owns; the requests themselves are read from the customer and support databases.
 */
function createStaffTools({ identityDb, customerDb, supportDb, notifier, namesOf }) {

  // ── Notifications ───────────────────────────────────────────────────────────

  /** Tells a person a request was assigned to them. Never the person who did the assigning, and never about themselves. */
  async function notifyAssigned({ userId, byUserId, kind, reference }) {
    if (!userId || userId === byUserId || !KINDS[kind]) return;
    await identityDb.query(
      `INSERT INTO staff_notification (notification_id, user_id, kind, subject_kind, reference, title)
       SELECT $1, $2, 'assigned', $3, $4, $5 WHERE NOT EXISTS (SELECT 1 FROM staff_notification WHERE user_id = $2 AND subject_kind = $3 AND reference = $4 AND read_at IS NULL)`,      // assigned again while the first is still unread: one bell, not two
      [uuidv7(), userId, kind, reference, `${KINDS[kind].label} ${reference} was assigned to you`]);
  }

  /** What the bell shows: unread notifications, and how many requests arrived since the person last looked. Looking for the first time starts the clock: no flood of "new". */
  async function notifications(staff) {
    const { rows: [state] } = await identityDb.query(
      `INSERT INTO staff_notification_state (user_id) VALUES ($1) ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id RETURNING seen_at`, [staff.userId]);
    const [items, unread, licence, help] = await Promise.all([
      identityDb.query(`SELECT notification_id, subject_kind, reference, title, created_at, read_at FROM staff_notification WHERE user_id = $1 ORDER BY created_at DESC LIMIT 20`, [staff.userId]),
      identityDb.query(`SELECT count(*)::int AS n FROM staff_notification WHERE user_id = $1 AND read_at IS NULL`, [staff.userId]),
      customerDb.query(`SELECT count(*)::int AS n FROM purchase_request WHERE created_at > $1`, [state.seen_at]),
      supportDb.query(`SELECT count(*)::int AS n FROM support_request WHERE created_at > $1`, [state.seen_at]),
    ]);
    const newRequests = { licenceRequests: licence.rows[0].n, helpRequests: help.rows[0].n };
    return {
      unread: unread.rows[0].n, newRequests, count: unread.rows[0].n + newRequests.licenceRequests + newRequests.helpRequests, seenAt: state.seen_at,
      items: items.rows.map(r => ({ id: r.notification_id, kind: r.subject_kind, reference: r.reference, title: r.title, createdAt: r.created_at, read: !!r.read_at })),
    };
  }

  /** "I have seen it all": the new-request clock restarts and every notification is marked read. */
  async function markSeen(staff) {
    await identityDb.query(`INSERT INTO staff_notification_state (user_id, seen_at) VALUES ($1, now()) ON CONFLICT (user_id) DO UPDATE SET seen_at = now()`, [staff.userId]);
    const r = await identityDb.query('UPDATE staff_notification SET read_at = now() WHERE user_id = $1 AND read_at IS NULL', [staff.userId]);
    return { marked: r.rowCount };
  }

  // ── Replying to a customer ──────────────────────────────────────────────────

  async function recipientOf(kind, reference) {
    if (!KINDS[kind] || typeof reference !== 'string' || !REFERENCE.test(reference)) throw new ApiError(404, 'No such request.', 'not_found');
    const sql = kind === 'licence_request'
      ? ['SELECT email, contact_name FROM purchase_request WHERE reference = $1', customerDb, 'Your OASIS licence request']
      : ['SELECT email, subject FROM support_request WHERE reference = $1', supportDb, null];
    const { rows: [r] } = await sql[1].query(sql[0], [reference]);
    if (!r) throw new ApiError(404, 'No such request.', 'not_found');
    return { email: r.email, defaultSubject: kind === 'licence_request' ? `Your OASIS licence request ${reference}` : `Re: ${r.subject}` };
  }

  /**
   * Sends a reply to the person who made a request and keeps a record of it with the request. With no email provider connected yet nothing leaves the building: the reply is
   * recorded as "not connected" and the screen says so, so nobody thinks the customer was written to. The address comes from the request, never from the caller.
   */
  async function reply({ kind, reference, subject, body }, staff) {
    const to = await recipientOf(kind, reference);
    const text = typeof body === 'string' ? cleanBody(body) : '';
    if (!text || text.length > 4000) throw refuse('A reply is 1 to 4000 characters.', 'bad_reply');
    let line = to.defaultSubject;
    if (subject !== undefined && subject !== null && subject !== '') {
      line = typeof subject === 'string' ? stripControl(subject) : '';
      if (!line || line.length > 200) throw refuse('The subject is 1 to 200 characters.', 'bad_subject');
    }
    let delivery;
    try { await notifier.send({ kind: 'customer_reply', to: to.email, subject: line, body: text, fromName: staff.displayName || null, reference }); delivery = notifier.kind === 'fake' ? 'not_connected' : 'sent'; }
    catch { delivery = 'failed'; }
    const id = uuidv7();
    await identityDb.query(`INSERT INTO customer_reply (reply_id, kind, reference, sent_by_user_id, subject, body, delivery) VALUES ($1, $2, $3, $4, $5, $6, $7)`, [id, kind, reference, staff.userId, line, text, delivery]);
    return { id, delivery, length: text.length };
  }

  async function replies(kind, reference) {
    const { rows } = await identityDb.query('SELECT reply_id, subject, body, delivery, sent_by_user_id, created_at FROM customer_reply WHERE kind = $1 AND reference = $2 ORDER BY created_at, reply_id', [kind, reference]);
    const names = await namesOf(rows.map(r => r.sent_by_user_id));
    return rows.map(r => ({ id: r.reply_id, subject: r.subject, body: r.body, delivery: r.delivery, createdAt: r.created_at, by: names.get(r.sent_by_user_id) || null }));
  }

  // ── Workload ────────────────────────────────────────────────────────────────

  /** One row per active team member (and "Not assigned"): what each holds now, how long the oldest has waited, and what they closed in the last 7 days. Counts only. */
  async function workload() {
    const [people, pr, sr] = await Promise.all([
      identityDb.query(`SELECT u.user_id, u.display_name, u.email FROM app_user u WHERE u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL
                         AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code IN ('SUPPORT', 'PLATFORM_ADMIN')) ORDER BY lower(coalesce(u.display_name, u.email))`),
      customerDb.query(`SELECT assigned_to_user_id AS who, count(*) FILTER (WHERE status_code IN ('NEW', 'CONTACTED'))::int AS open,
                               count(*) FILTER (WHERE status_code NOT IN ('NEW', 'CONTACTED') AND status_changed_at > now() - interval '7 days')::int AS closed7,
                               round(extract(epoch FROM (now() - min(created_at) FILTER (WHERE status_code IN ('NEW', 'CONTACTED')))) / 3600.0, 1) AS oldest_hours
                          FROM purchase_request GROUP BY 1`),
      supportDb.query(`SELECT assigned_to_user_id AS who, count(*) FILTER (WHERE status_code IN ('NEW', 'IN_PROGRESS'))::int AS open,
                              count(*) FILTER (WHERE status_code NOT IN ('NEW', 'IN_PROGRESS') AND status_changed_at > now() - interval '7 days')::int AS closed7,
                              round(extract(epoch FROM (now() - min(created_at) FILTER (WHERE status_code IN ('NEW', 'IN_PROGRESS')))) / 3600.0, 1) AS oldest_hours
                         FROM support_request GROUP BY 1`),
    ]);
    const p = new Map(pr.rows.map(r => [r.who, r])), s = new Map(sr.rows.map(r => [r.who, r]));
    const row = (id, name) => {
      const a = p.get(id) || {}, b = s.get(id) || {};
      const oldest = [a.oldest_hours, b.oldest_hours].filter(x => x !== null && x !== undefined).map(Number);
      return { id, name, licenceRequests: a.open || 0, helpRequests: b.open || 0, open: (a.open || 0) + (b.open || 0), closedLast7Days: (a.closed7 || 0) + (b.closed7 || 0), oldestOpenHours: oldest.length ? Math.max(...oldest) : null };
    };
    const rows = people.rows.map(u => row(u.user_id, u.display_name || u.email));
    rows.push(row(null, 'Not assigned'));
    return { people: rows.sort((x, y) => (x.id === null) - (y.id === null) || y.open - x.open || x.name.localeCompare(y.name)) };
  }

  /** One person's open requests (references, statuses and ages: nothing a customer wrote). `who` is a staff id or "none". */
  async function workloadOf(who) {
    if (who !== 'none' && !UUID.test(who)) throw new ApiError(404, 'No such team member.', 'not_found');
    const unassigned = who === 'none';
    const cond = col => (unassigned ? `${col} IS NULL` : `${col} = $1`);
    const params = unassigned ? [] : [who];
    const [pr, sr, name] = await Promise.all([
      customerDb.query(`SELECT reference, status_code, created_at, status_changed_at FROM purchase_request WHERE status_code IN ('NEW', 'CONTACTED') AND ${cond('assigned_to_user_id')} ORDER BY created_at LIMIT 100`, params),
      supportDb.query(`SELECT reference, status_code, created_at, status_changed_at FROM support_request WHERE status_code IN ('NEW', 'IN_PROGRESS') AND ${cond('assigned_to_user_id')} ORDER BY created_at LIMIT 100`, params),
      unassigned ? null : namesOf([who]),
    ]);
    if (!unassigned && !name.get(who)) throw new ApiError(404, 'No such team member.', 'not_found');
    return { id: unassigned ? null : who, name: unassigned ? 'Not assigned' : name.get(who), licenceRequests: pr.rows, helpRequests: sr.rows };
  }

  return { notifyAssigned, notifications, markSeen, reply, replies, workload, workloadOf };
}

module.exports = { createStaffTools };
