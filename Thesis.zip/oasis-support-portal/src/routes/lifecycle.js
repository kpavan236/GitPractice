'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const idOf = v => (typeof v === 'string' && UUID.test(v) ? v : null);       // for the audit trail: an id or nothing, never raw caller text
const whole = (value, { min, max, fallback, name }) => {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!/^\d+$/.test(String(value)) || n < min || n > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, 'bad_filter');
  return n;
};
const text = (req, name) => {
  const v = req.query[name];
  if (v !== undefined && typeof v !== 'string') throw refuse(`${name} must be text.`, 'bad_filter');
  return v;
};

/**
 * Suspend, reinstate, cancel, revoke, renew, extend and change (seats, plan) a licence, release one seat, extend a trial, and the two lists support needs to find them. Permissions are data
 * (the identity database's role_permission): suspend, reinstate, cancel and revoke need LICENSE_SUSPEND (platform admin only by default), renew needs
 * LICENSE_ACTIVATE, extending a licence or a trial needs LICENSE_UPDATE. Every change needs a reason and is audited first.
 */
function lifecycleRoutes({ lifecycle, admin, audit, requireStaff }) {
  const router = express.Router();

  router.get('/licenses', requireStaff('LICENSE_READ'), wrap(async (req, res) => {
    const limit = whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' });
    const offset = whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' });
    const licences = await lifecycle.listLicences({ customerId: text(req, 'customerId'), status: text(req, 'status'), limit, offset });
    res.json({ licences, limit, offset });
  }));

  router.get('/trials', requireStaff('LICENSE_READ'), wrap(async (req, res) => {
    const limit = whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' });
    const offset = whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' });
    const status = text(req, 'status'), flagged = text(req, 'flagged');
    const trials = await lifecycle.listTrials({ status, flagged, limit, offset });
    await audit.read(req, { action: 'trial.list', detail: { returned: trials.length } });     // it shows a customer's own Jenkins and GitHub addresses
    res.json({ trials, limit, offset });
  }));

  router.get('/blocks', requireStaff('LICENSE_READ'), wrap(async (req, res) => {
    const limit = whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' });
    const offset = whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' });
    const blocks = await lifecycle.listBlocks({ licenseId: text(req, 'licenseId'), reason: text(req, 'reason'), state: text(req, 'state'), limit, offset });
    res.json({ blocks, limit, offset });
  }));

  /** One audited change on a licence (or trial): `run` does it, `shape` says what goes in the trail. */
  const change = (path, permission, action, subjectKey, run, shape) => router.post(path, requireStaff(permission), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const subject = idOf(req.params[subjectKey]);
    const out = await audit.change(req, { action, subject, reason, detail: {} }, async () => {
      const r = await run(req.params[subjectKey], body, reason, req.staff);
      if (r.after === undefined) return { result: r, detail: shape(r) };       // blocks: the answer is the count, there is no before and after
      return { result: { ...r.after, ...(r.term ? { term: r.term, statusMoved: r.statusMoved } : {}), ...(r.seatsReleased !== undefined ? { seatsReleased: r.seatsReleased } : {}) }, detail: shape(r) };
    });
    res.json(out);
  }));

  change('/licenses/:id/suspend', 'LICENSE_SUSPEND', 'licence.suspend', 'id', (id, _b, reason, staff) => lifecycle.suspend(id, reason, staff), r => ({ from: r.before, to: r.after.status }));
  change('/licenses/:id/reinstate', 'LICENSE_SUSPEND', 'licence.reinstate', 'id', (id, _b, reason, staff) => lifecycle.reinstate(id, reason, staff), r => ({ from: r.before, to: r.after.status }));
  change('/licenses/:id/cancel', 'LICENSE_SUSPEND', 'licence.cancel', 'id', (id, body, reason, staff) => lifecycle.cancel(id, body, reason, staff), r => ({ from: r.before, to: r.after.status }));
  change('/licenses/:id/revoke', 'LICENSE_SUSPEND', 'licence.revoke', 'id', (id, body, reason, staff) => lifecycle.revoke(id, body, reason, staff), r => ({ from: r.before, to: r.after.status, seatsReleased: r.seatsReleased }));
  change('/licenses/:id/block-machines', 'BLOCK_MANAGE', 'licence.block_machines', 'id', (id, body, reason, staff) => lifecycle.blockMachines(id, { confirm: body.confirm, reason, staff }),
    r => ({ machines: r.machines, newlyBlocked: r.newlyBlocked, alreadyBlocked: r.alreadyBlocked }));
  change('/licenses/:id/unblock-machines', 'BLOCK_MANAGE', 'licence.unblock_machines', 'id', (id, _b, _reason, staff) => lifecycle.unblockMachines(id, { staff }), r => ({ lifted: r.lifted }));
  change('/blocks/:id/lift', 'BLOCK_MANAGE', 'block.lift', 'id', (id, _b, _reason, staff) => lifecycle.liftBlock(id, { staff }), r => ({ lifted: r.lifted }));
  change('/licenses/:id/renew', 'LICENSE_ACTIVATE', 'licence.renew', 'id', (id, body, reason, staff) => lifecycle.renew(id, body, reason, staff),
    r => ({ from: r.before, to: r.after.status, termNo: r.term.termNo, days: r.term.days, endsAt: r.term.endsAt }));
  change('/licenses/:id/extend', 'LICENSE_UPDATE', 'licence.extend', 'id', (id, body, reason, staff) => lifecycle.extend(id, body, reason, staff),
    r => ({ from: r.before, to: r.after.status, termNo: r.term.termNo, days: r.term.days, endsAt: r.term.endsAt }));
  change('/trials/:id/extend', 'LICENSE_UPDATE', 'trial.extend', 'id', (id, body, reason, staff) => lifecycle.extendTrial(id, body, reason, staff),
    r => ({ from: r.before, to: r.after.status, days: r.days, until: r.after.extendedUntil }));

  // Changing what was sold, and freeing one seat: admin only by default (LICENSE_MODIFY). Both need a reason and are audited first.
  router.post('/licenses/:id/change', requireStaff('LICENSE_MODIFY'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'licence.change', subject: idOf(req.params.id), reason, detail: {} }, async () => {
      const r = await lifecycle.changeTerms(req.params.id, body, reason, req.staff);
      return { result: r, detail: { fromPlan: r.before.plan, toPlan: r.after.plan, fromSeats: r.before.seats, toSeats: r.after.seats } };
    });
    res.json(out);
  }));

  router.post('/licenses/:id/seats/:seatId/release', requireStaff('LICENSE_MODIFY'), wrap(async (req, res) => {
    const reason = admin.reasonOf(bodyOf(req));
    const out = await audit.change(req, { action: 'licence.release_seat', subject: idOf(req.params.id), reason, detail: {} }, async () => {
      const r = await lifecycle.releaseSeat(req.params.id, req.params.seatId, reason, req.staff);
      return { result: r, detail: { seatsInUse: r.seatsInUse } };
    });
    res.json(out);
  }));

  return router;
}

module.exports = { lifecycleRoutes };
