'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');
const { normaliseEmail } = require('../forms');

const bodyOf = req => (req.body && typeof req.body === 'object' ? req.body : {});

/** Staff sign-in with an email address and a password. Asking for a link answers the same whether or not the address is a staff member's. */
function authRoutes({ auth, hash, requireStaff, csrfOf, cookie, emailDelivery = 'fake' }) {
  const router = express.Router();
  const ipHash = req => hash('network', req.ip || 'unknown');

  /** Whether sign-in emails really go out. The sign-in page says so when they do not, so nobody waits for a code that will never arrive. */
  router.get('/auth/config', (_req, res) => res.json({ emailDelivery }));

  const emailOf = body => { const email = normaliseEmail(body.email); if (!email) throw refuse('Enter a valid email address.', 'bad_email'); return email; };
  const text = v => (typeof v === 'string' ? v : '');

  /** "Forgot or set your password": emails a link to a team member (a reset link, or a fresh activation link if they never activated). The answer is the same for anyone. */
  router.post('/auth/password/forgot', wrap(async (req, res) => {
    await auth.requestLink({ email: emailOf(bodyOf(req)), ipHash: ipHash(req) });
    res.json({ ok: true, message: 'If that address belongs to a support team member, we have emailed a link.' });
  }));

  /** What a link is for, so its page can say "Activate your account" or "Reset your password" and whose it is. The secret travels in the body, never in the address. */
  router.post('/auth/link/check', wrap(async (req, res) => { res.json(await auth.inspectLink(text(bodyOf(req).token))); }));

  /** The link's secret and a new password typed twice. Activates a pending account, or resets the password; ends the person's sessions. They then sign in. */
  router.post('/auth/link/complete', wrap(async (req, res) => {
    const body = bodyOf(req);
    const done = await auth.completeLink({ token: text(body.token), newPassword: text(body.newPassword), confirmPassword: text(body.confirmPassword), ipHash: ipHash(req) });
    res.json({ ok: true, purpose: done.purpose });
  }));

  const setCookie = (res, value, maxAge) => res.append('Set-Cookie', `${cookie.name}=${value}; Path=/v1; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${cookie.secure ? '; Secure' : ''}`);

  /**
   * Email address and password, then a session. With `{ "cookie": true }` (the browser portal) the session token goes into an HttpOnly cookie the page's JavaScript cannot read,
   * and the answer carries a CSRF token instead; without it (an API client) the answer carries the bearer token.
   */
  router.post('/auth/login', wrap(async (req, res) => {
    const body = bodyOf(req);
    const session = await auth.login({ email: emailOf(body), password: body.password, ipHash: ipHash(req) });
    const staff = await auth.authenticate(session.token);
    if (!staff) throw refuse('That email address or password is not right. After several wrong tries, sign-in pauses for 15 minutes.', 'bad_credentials');     // the role was withdrawn this instant
    const user = { email: staff.email, displayName: staff.displayName, roles: staff.roles };
    if (body.cookie === true) {
      setCookie(res, session.token, cookie.maxAgeSeconds);
      return res.json({ expiresAt: session.expiresAt, user, csrfToken: csrfOf(session.token) });
    }
    res.json({ token: session.token, expiresAt: session.expiresAt, user });
  }));

  router.post('/auth/password/change', requireStaff(), wrap(async (req, res) => {
    const body = bodyOf(req);
    await auth.changePassword({ userId: req.staff.userId, sessionId: req.staff.sessionId, email: req.staff.email, currentPassword: body.currentPassword, newPassword: text(body.newPassword), ipHash: ipHash(req) });
    res.json({ ok: true });
  }));

  router.get('/auth/me', requireStaff(), wrap(async (req, res) => {
    const { email, displayName, roles } = req.staff;
    res.json({ email, displayName, roles, permissions: [...req.staff.permissions].sort(), ...(req.viaCookie ? { csrfToken: csrfOf(req.sessionToken) } : {}) });
  }));

  router.post('/auth/logout', requireStaff(), wrap(async (req, res) => {
    await auth.signOut(req.staff.sessionId);
    if (req.viaCookie) setCookie(res, '', 0);
    res.json({ ok: true });
  }));

  return router;
}

module.exports = { authRoutes };
