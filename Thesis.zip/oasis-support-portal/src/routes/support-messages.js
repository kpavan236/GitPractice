'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');

const REFERENCE = /^[A-Za-z0-9-]{1,40}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const code = v => (typeof v === 'string' && /^[A-Za-z0-9._,-]{1,60}$/.test(v) ? v : null);     // for the audit trail: a short plain code or nothing, never raw caller text
const whole = (value, { min, max, fallback, name }) => {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!/^\d+$/.test(String(value)) || n < min || n > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, 'bad_filter');
  return n;
};
const text = (req, name) => {
  const v = req.query[name];
  if (v !== undefined && typeof v !== 'string') throw refuse(`${name} must be text.`, 'bad_filter');
  return v;
};

/**
 * The staff routes for what people send from the app. Reading any of it is audited (it holds a name, an address and free text), and so is every change.
 * Permissions are data: SUPPORT_REQUEST_READ, SUPPORT_REQUEST_UPDATE and FEEDBACK_READ (migration 006), granted to both staff roles by default.
 */
function supportMessageRoutes({ messages, admin, audit, requireStaff, tools }) {
  const router = express.Router();
  const page = req => ({
    limit: whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' }),
    offset: whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' }),
  });

  router.get('/support-requests', requireStaff('SUPPORT_REQUEST_READ'), wrap(async (req, res) => {
    const { limit, offset } = page(req);
    const status = text(req, 'status'), assignedTo = text(req, 'assignedTo');
    const rows = await messages.listRequests({ status, assignedTo, limit, offset }, req.staff);
    await audit.read(req, { action: 'support_request.list', detail: { status: code(status), assignedTo: code(assignedTo), returned: rows.length } });
    res.json({ supportRequests: rows, limit, offset });
  }));

  router.get('/support-requests/:reference', requireStaff('SUPPORT_REQUEST_READ'), wrap(async (req, res) => {
    const request = await messages.getRequest(req.params.reference);
    await audit.read(req, { action: 'support_request.view', subject: request.reference, detail: { notes: request.notes.length } });     // the message is read here, so who read it is recorded
    res.json({ ...request, replies: await tools.replies('help_request', request.reference) });
  }));

  router.patch('/support-requests/:reference', requireStaff('SUPPORT_REQUEST_UPDATE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    if (Object.prototype.hasOwnProperty.call(body, 'assignedTo') && !req.staff.permissions.has('REQUEST_ASSIGN')) throw refuse('Only an admin can assign a request.', 'forbidden', {}, 403);
    const reason = admin.reasonOf(body);
    const subject = REFERENCE.test(req.params.reference) ? req.params.reference : null;
    const out = await audit.change(req, { action: 'support_request.update', subject, reason,
      detail: { status: code(body.status), assigned: Object.prototype.hasOwnProperty.call(body, 'assignedTo'), customerLinked: Object.prototype.hasOwnProperty.call(body, 'customerRef') } }, async () => {
      const r = await messages.updateRequest(req.params.reference, body, reason, req.staff);
      return { result: r.after, detail: { from: r.before, to: r.after.status_code } };
    });
    const who = typeof body.assignedTo === 'string' && out && out.assigned_to_user_id === body.assignedTo ? body.assignedTo : null;
    await tools.notifyAssigned({ userId: who, byUserId: req.staff.userId, kind: 'help_request', reference: out.reference || req.params.reference }).catch(() => {});
    res.json(out);
  }));

  router.post('/support-requests/:reference/notes', requireStaff('SUPPORT_REQUEST_UPDATE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const subject = REFERENCE.test(req.params.reference) ? req.params.reference : null;
    const out = await audit.change(req, { action: 'support_request.note', subject, reason: 'Added a note', detail: {} }, async () => {
      const r = await messages.addNote(req.params.reference, body, req.staff);
      return { result: { noteId: r.noteId, createdAt: r.createdAt }, detail: { length: r.length } };       // the note itself is not copied into the trail
    });
    res.status(201).json(out);
  }));

  router.get('/feedback', requireStaff('FEEDBACK_READ'), wrap(async (req, res) => {
    const { limit, offset } = page(req);
    const category = text(req, 'category'), rating = text(req, 'rating'), withEmail = text(req, 'withEmail');
    const rows = await messages.listFeedback({ category, rating, withEmail, limit, offset });
    await audit.read(req, { action: 'feedback.list', detail: { category: code(category), returned: rows.length } });
    res.json({ feedback: rows, limit, offset });
  }));

  return router;
}

module.exports = { supportMessageRoutes };
