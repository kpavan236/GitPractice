'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
/** For the audit trail: a short plain code or reference, or null. Never raw caller text, which could be anything. */
const code = v => (typeof v === 'string' && /^[A-Za-z0-9._-]{1,60}$/.test(v) ? v : null);
const idOf = v => (typeof v === 'string' && UUID.test(v) ? v : null);
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const whole = (value, { min, max, fallback, name }) => {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!/^\d+$/.test(String(value)) || n < min || n > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, 'bad_filter');
  return n;
};

/** Who a request was just assigned to, when this change assigned it: the id the caller sent, if the answer agrees. */
const assignedTo = (body, out) => (typeof body.assignedTo === 'string' && out && out.assigned_to_user_id === body.assignedTo ? body.assignedTo : null);

/**
 * The four support routes in the contract. Each needs a signed-in staff member with the right permission (permissions come from the
 * identity database's role_permission table, so who may do what is data). Every change needs a reason and is audited before it is made.
 */
function adminRoutes({ admin, audit, requireStaff, tools }) {
  const router = express.Router();

  router.get('/purchase-requests', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => {
    const { status, assignedTo } = req.query;
    for (const [k, v] of Object.entries({ status, assignedTo })) if (v !== undefined && typeof v !== 'string') throw refuse(`${k} must be text.`, 'bad_filter');
    const limit = whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' });
    const offset = whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' });
    const rows = await admin.listPurchaseRequests({ status, assignedTo, limit, offset }, req.staff);
    await audit.read(req, { action: 'purchase_request.list', detail: { status: status || null, assignedTo: assignedTo || null, returned: rows.length } });     // personal data: who looked is recorded
    res.json({ purchaseRequests: rows, limit, offset });
  }));

  router.get('/purchase-requests/:reference', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => {
    const request = await admin.getPurchaseRequest(req.params.reference);
    await audit.read(req, { action: 'purchase_request.view', subject: request.reference, detail: {} });       // it shows a name and an address: who looked is recorded
    res.json({ ...request, replies: await tools.replies('licence_request', request.reference) });
  }));

  router.patch('/purchase-requests/:reference', requireStaff('CUSTOMER_UPDATE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    if (Object.prototype.hasOwnProperty.call(body, 'assignedTo') && !req.staff.permissions.has('REQUEST_ASSIGN')) throw refuse('Only an admin can assign a request.', 'forbidden', {}, 403);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'purchase_request.update', subject: code(req.params.reference), reason, detail: { status: code(body.status), assigned: Object.prototype.hasOwnProperty.call(body, 'assignedTo'), note: body.note !== undefined } }, async () => {
      const r = await admin.updatePurchaseRequest(req.params.reference, body, req.staff);
      return { result: r.after, detail: { from: r.before, to: r.after.status_code || null } };
    });
    await tools.notifyAssigned({ userId: assignedTo(body, out), byUserId: req.staff.userId, kind: 'licence_request', reference: out.reference || req.params.reference }).catch(() => {});       // a bell that fails must never fail the change
    res.json(out);
  }));

  router.post('/licenses', requireStaff('LICENSE_ACTIVATE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'licence.create', subject: code(body.purchaseRequest), reason, detail: { plan: code(body.plan) } }, async () => {
      const r = await admin.createLicence(body, req.staff);
      return { result: r, subject: r.licenseId, detail: { licenseId: r.licenseId, customerId: r.customerId, customerCreated: r.customerCreated, plan: r.plan, kind: r.kind, seats: r.seats, termDays: r.termDays } };
    });
    res.status(201).json(out);       // the licence key is in this answer, once: Cache-Control: no-store is set for every response
  }));

  router.post('/domains', requireStaff('DOMAIN_ATTACH'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'domain.attach', subject: typeof body.domain === 'string' && /^[A-Za-z0-9.-]{1,100}$/.test(body.domain) ? body.domain.toLowerCase() : null, reason, detail: { customerId: idOf(body.customerId) } }, async () => ({ result: await admin.attachDomain(body) }));
    res.status(201).json(out);
  }));

  return router;
}

module.exports = { adminRoutes };
