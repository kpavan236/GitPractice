'use strict';
const express = require('express');
const { wrap } = require('../errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const idOf = v => (typeof v === 'string' && UUID.test(v) ? v : null);
const code = v => (typeof v === 'string' && /^[A-Za-z0-9._-]{1,40}$/.test(v) ? v : null);

/** The team (admins only): who may sign in, as what. Nothing here shows a password or a link: an admin only causes a link to be emailed, and never sees it. */
function teamRoutes({ users, admin, audit, requireStaff }) {
  const router = express.Router();

  router.get('/users', requireStaff('USER_MANAGE'), wrap(async (_req, res) => {
    res.json({ users: await users.list() });
  }));

  router.post('/users', requireStaff('USER_MANAGE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'user.create', subject: null, reason, detail: { role: code(body.role) } }, async () => {
      const user = await users.create(body, reason, req.staff);
      return { result: user, subject: user.id, detail: { userId: user.id, role: user.role } };       // the address and name are not copied into the trail
    });
    res.status(201).json(out);
  }));

  /** Emails an activation link (to someone Pending) or a password-reset link (to someone Active). The admin is told it was sent, never given the link. */
  router.post('/users/:id/send-link', requireStaff('USER_MANAGE'), wrap(async (req, res) => {
    const reason = admin.reasonOf(bodyOf(req));
    const out = await audit.change(req, { action: 'user.send_link', subject: idOf(req.params.id), reason, detail: {} }, async () => {
      const r = await users.sendLink(req.params.id, reason, req.staff);
      return { result: { id: r.user.id, purpose: r.purpose, emailed: r.emailed }, detail: { purpose: r.purpose, emailed: r.emailed } };
    });
    res.json(out);
  }));

  router.patch('/users/:id', requireStaff('USER_MANAGE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'user.update', subject: idOf(req.params.id), reason,
      detail: { role: code(body.role), status: code(body.status), renamed: body.displayName !== undefined, emailChanged: body.email !== undefined } }, async () => {
      const r = await users.update(req.params.id, body, reason, req.staff);
      return { result: { ...r.after, ...(r.emailed !== undefined ? { emailed: r.emailed } : {}) }, detail: { fromRole: r.before.role, toRole: r.after.role, fromStatus: r.before.status, toStatus: r.after.status, emailChanged: r.emailChanged } };
    });
    res.json(out);
  }));

  return router;
}

module.exports = { teamRoutes };
