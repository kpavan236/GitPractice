'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');

const whole = (value, { min, max, fallback, name }) => {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!/^\d+$/.test(String(value)) || n < min || n > max) throw refuse(`${name} must be a whole number from ${min} to ${max}.`, 'bad_filter');
  return n;
};
const text = (req, name) => {
  const v = req.query[name];
  if (v !== undefined && typeof v !== 'string') throw refuse(`${name} must be text.`, 'bad_filter');
  return v;
};
const code = v => (typeof v === 'string' && /^[A-Za-z0-9._-]{1,60}$/.test(v) ? v : null);

/** The dashboard, customers, one licence in full, and the audit log (admins). Read only. */
function overviewRoutes({ overview, audit, requireStaff }) {
  const router = express.Router();
  const page = req => ({ limit: whole(req.query.limit, { min: 1, max: 200, fallback: 50, name: 'limit' }), offset: whole(req.query.offset, { min: 0, max: 1_000_000, fallback: 0, name: 'offset' }) });

  router.get('/dashboard', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => { res.json(await overview.dashboard(req.staff)); }));

  router.get('/reports', requireStaff('REPORT_READ'), wrap(async (req, res) => {
    const weeks = whole(req.query.weeks, { min: 4, max: 52, fallback: 12, name: 'weeks' });
    await audit.read(req, { action: 'report.view', detail: { weeks } });       // totals only, but who looked at the numbers is on record
    res.json(await overview.reports(weeks));
  }));

  router.get('/customer-users', requireStaff('REPORT_READ'), wrap(async (req, res) => {
    const weeks = whole(req.query.weeks, { min: 4, max: 52, fallback: 12, name: 'weeks' });
    await audit.read(req, { action: 'customer_users.overview', detail: { weeks } });       // counts only, but who looked is on record
    res.json(await overview.customerUsersOverview(weeks));
  }));

  router.get('/customer-users/:id', requireStaff('REPORT_READ'), wrap(async (req, res) => {
    const result = await overview.customerUsers(req.params.id);
    await audit.read(req, { action: 'customer_users.view', subject: result.customer.id, detail: { returned: result.users.length } });       // names and addresses: every read is recorded, never what was read
    res.json(result);
  }));

  router.get('/plans', requireStaff('LICENSE_READ'), wrap(async (_req, res) => { res.json({ plans: await overview.listPlans() }); }));

  router.get('/customers', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => {
    const { limit, offset } = page(req);
    res.json({ customers: await overview.listCustomers({ q: text(req, 'q'), limit, offset }), limit, offset });
  }));

  router.get('/customers/:id', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => {
    const customer = await overview.getCustomer(req.params.id);
    await audit.read(req, { action: 'customer.view', subject: customer.customer_id, detail: {} });
    res.json(customer);
  }));

  router.get('/licenses/:id', requireStaff('LICENSE_READ'), wrap(async (req, res) => { res.json(await overview.getLicence(req.params.id)); }));

  router.get('/audit', requireStaff('AUDIT_READ'), wrap(async (req, res) => {
    const { limit, offset } = page(req);
    const filters = { actor: text(req, 'actor'), action: text(req, 'action'), subject: text(req, 'subject'), outcome: text(req, 'outcome'), since: text(req, 'since') };
    const entries = await overview.listAudit({ ...filters, limit, offset });
    await audit.read(req, { action: 'audit.list', detail: { action: code(filters.action), outcome: code(filters.outcome), returned: entries.length } });     // reading the trail is itself recorded
    res.json({ entries, limit, offset });
  }));

  return router;
}

module.exports = { overviewRoutes };
