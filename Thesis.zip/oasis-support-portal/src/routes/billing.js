'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');
const { toCsv } = require('../csv');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const idOf = v => (typeof v === 'string' && UUID.test(v) ? v : null);
const notFound = () => refuse('No such invoice.', 'not_found', {}, 404);
const LIST_FILTERS = ['status', 'customerId', 'ownerId', 'overdue', 'dueFrom', 'dueTo', 'open', 'closed', 'bucket', 'health', 'sourcePurchaseRequestId', 'limit', 'offset'];

/** Only what this portal knows how to ask for is forwarded: a query parameter nobody listed here never reaches the billing service. */
const pick = (query, allowed) => Object.fromEntries(allowed.filter(k => typeof query[k] === 'string' && query[k] !== '').map(k => [k, query[k]]));

/**
 * The Invoices API: explicit handlers, one per billing action. Permissions are the portal's (INVOICE_READ / INVOICE_WRITE / INVOICE_ADMIN, which are data); the billing service
 * checks the same split again itself. Every change is audited BEFORE it is made, with the invoice id and the reason, and never an amount, a name, a note or a link.
 */
function billingRoutes({ billing, audit, admin, requireStaff }) {
  const router = express.Router();
  const { client } = billing;
  const off = () => { if (!client) throw refuse('Billing is not set up on this portal.', 'billing_not_configured', {}, 503); return client; };

  router.get('/billing/status', requireStaff(), wrap(async (req, res) => {
    if (!client) return res.json({ enabled: false });
    const s = (await client.settings(billing.actorOf(req.staff))).body;
    res.json({ enabled: true, currency: s.currency, shareLinkDefaultDays: s.shareLinkDefaultDays });
  }));

  router.get('/invoices', requireStaff('INVOICE_READ'), wrap(async (req, res) => {
    const out = (await off().listInvoices(billing.actorOf(req.staff), pick(req.query, LIST_FILTERS))).body;
    await audit.read(req, { action: 'invoice.list', detail: { returned: out.invoices.length } });          // names of customers: every look is recorded, never what was seen
    res.json(await billing.withNames(out));
  }));

  router.get('/invoices/:id', requireStaff('INVOICE_READ'), wrap(async (req, res) => {
    const id = idOf(req.params.id); if (!id) throw notFound();
    const out = (await off().getInvoice(billing.actorOf(req.staff), id)).body;
    await audit.read(req, { action: 'invoice.view', subject: id });
    res.json(await billing.withNames(out));
  }));

  /** One audited change. `run(actor, id)` calls billing and returns its { status, body, replayed }; `detail` is what goes in the trail (ids and enumerations only). */
  const change = (method, path, permission, action, { reason, detail = () => ({}), status } = {}) => router[method](path, requireStaff(permission), wrap(async (req, res) => {
    const c = off();
    const id = idOf(req.params.id); if (!id) throw notFound();
    const body = bodyOf(req);
    const why = typeof reason === 'function' ? reason(body) : reason;
    const actor = billing.actorOf(req.staff);
    const run = changes[action];
    const out = await audit.change(req, { action, subject: id, reason: why, detail: {} }, async () => {
      const r = await run(c, actor, id, body, req);
      return { result: r, detail: detail(r.body, body, req) };
    });
    if (out.replayed) res.set('Idempotent-Replayed', 'true');
    res.status(status || out.status).json(await billing.withNames(out.body));
  }));

  const fixed = text => () => text;
  const typed = body => admin.reasonOf(body);
  const changes = {
    'invoice.edit': (c, a, id, body) => c.updateDraft(a, id, body),
    'invoice.cancel_draft': (c, a, id, body) => c.cancelDraft(a, id, body),
    'invoice.issue': (c, a, id, body) => c.issue(a, id, body),
    'invoice.mark_sent': (c, a, id, body) => c.markSent(a, id, body),
    'invoice.void': (c, a, id, body) => c.voidInvoice(a, id, body),
    'payment.record': (c, a, id, body, req) => c.recordPayment(a, id, body, req.get('Idempotency-Key')),
    'credit_note.create': (c, a, id, body) => c.creditNote(a, id, body),
    'link.create': (c, a, id, body) => c.createLink(a, id, body),
  };

  // Creating has no invoice id yet, so it is written out rather than routed through `change`.
  router.post('/invoices', requireStaff('INVOICE_WRITE'), wrap(async (req, res) => {
    const c = off();
    const actor = billing.actorOf(req.staff);
    const out = await audit.change(req, { action: 'invoice.create', subject: null, reason: 'Created an invoice', detail: {} }, async () => {
      const r = await c.createInvoice(actor, bodyOf(req), req.get('Idempotency-Key'));
      return { result: r, subject: idOf(r.body.invoice && r.body.invoice.invoiceId), detail: { invoiceId: idOf(r.body.invoice && r.body.invoice.invoiceId) } };
    });
    if (out.replayed) res.set('Idempotent-Replayed', 'true');
    res.status(out.status).json(await billing.withNames(out.body));
  }));

  change('patch', '/invoices/:id', 'INVOICE_WRITE', 'invoice.edit', { reason: fixed('Edited a draft invoice'), detail: (_r, b) => ({ fields: ['lines', 'billTo', 'dueOn', 'notes'].filter(k => Object.prototype.hasOwnProperty.call(b, k)) }) });
  change('post', '/invoices/:id/cancel', 'INVOICE_WRITE', 'invoice.cancel_draft', { reason: typed });
  change('post', '/invoices/:id/issue', 'INVOICE_WRITE', 'invoice.issue', { reason: fixed('Issued the invoice') });
  change('post', '/invoices/:id/mark-sent', 'INVOICE_WRITE', 'invoice.mark_sent', { reason: fixed('Marked the invoice as sent'), detail: (_r, b) => ({ channel: typeof b.channel === 'string' ? b.channel.slice(0, 20) : null }) });
  change('post', '/invoices/:id/void', 'INVOICE_ADMIN', 'invoice.void', { reason: typed });
  change('post', '/invoices/:id/payments', 'INVOICE_WRITE', 'payment.record', { reason: fixed('Recorded a payment'), detail: r => ({ receiptNumber: r.payment && r.payment.receiptNumber }) });
  change('post', '/invoices/:id/credit-notes', 'INVOICE_ADMIN', 'credit_note.create', { reason: typed, detail: r => ({ creditNoteNumber: r.creditNote && r.creditNote.creditNoteNumber }) });
  change('post', '/invoices/:id/links', 'INVOICE_WRITE', 'link.create', { reason: fixed('Created a secure link'), detail: r => ({ linkId: r.link && r.link.linkId }) });

  router.post('/invoices/:id/payments/:paymentId/void', requireStaff('INVOICE_ADMIN'), wrap(async (req, res) => {
    const c = off();
    const id = idOf(req.params.id), paymentId = idOf(req.params.paymentId);
    if (!id || !paymentId) throw notFound();
    const reason = admin.reasonOf(bodyOf(req));
    const out = await audit.change(req, { action: 'payment.void', subject: id, reason, detail: {} }, async () => {
      const r = await c.voidPayment(billing.actorOf(req.staff), id, paymentId, bodyOf(req));
      return { result: r, detail: { paymentId } };
    });
    res.status(out.status).json(await billing.withNames(out.body));
  }));

  router.post('/invoices/:id/links/:linkId/revoke', requireStaff('INVOICE_WRITE'), wrap(async (req, res) => {
    const c = off();
    const id = idOf(req.params.id), linkId = idOf(req.params.linkId);
    if (!id || !linkId) throw notFound();
    const out = await audit.change(req, { action: 'link.revoke', subject: id, reason: 'Revoked a secure link', detail: {} }, async () => {
      const r = await c.revokeLink(billing.actorOf(req.staff), id, linkId);
      return { result: r, detail: { linkId } };
    });
    res.status(out.status).json(await billing.withNames(out.body));
  }));

  router.get('/purchase-requests/:reference/invoice-draft', requireStaff('INVOICE_WRITE'), wrap(async (req, res) => {
    const out = await billing.draftFromRequest(req.params.reference);
    await audit.read(req, { action: 'invoice.draft_prefill', detail: {} });
    res.json(out);
  }));
  router.get('/invoice-owners', requireStaff('INVOICE_READ'), wrap(async (req, res) => { res.json({ owners: await billing.activeStaff(), meId: req.staff.userId }); }));

  router.post('/invoices/:id/owner', requireStaff('INVOICE_ADMIN'), wrap(async (req, res) => {
    const c = off();
    const id = idOf(req.params.id); if (!id) throw notFound();
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    await billing.requireActiveStaff(body.toUserId);
    const out = await audit.change(req, { action: 'owner.change', subject: id, reason, detail: {} }, async () => {
      const r = await c.changeOwner(billing.actorOf(req.staff), id, body);
      return { result: r, detail: { to: idOf(body.toUserId) } };
    });
    res.status(out.status).json(await billing.withNames(out.body));
  }));

  router.post('/invoices/:id/follow-ups', requireStaff('INVOICE_WRITE'), wrap(async (req, res) => {
    const c = off();
    const id = idOf(req.params.id); if (!id) throw notFound();
    const body = bodyOf(req);
    const out = await audit.change(req, { action: 'followup.log', subject: id, reason: 'Logged a follow-up', detail: {} }, async () => {
      const r = await c.logFollowUp(billing.actorOf(req.staff), id, body);
      return { result: r, detail: { channel: typeof body.channel === 'string' ? body.channel.slice(0, 20) : null } };       // what the customer said stays in the follow-up, not in the trail
    });
    res.status(out.status).json(await billing.withNames(out.body));
  }));

  const mineOf = req => (req.query.mine === '1' ? { ownerId: req.staff.userId } : {});
  router.get('/invoice-follow-ups/queue', requireStaff('INVOICE_READ'), wrap(async (req, res) => {
    const out = (await off().followUpQueue(billing.actorOf(req.staff), mineOf(req))).body;
    await audit.read(req, { action: 'followup.queue', detail: { returned: (out.groups || []).reduce((n, g) => n + (g.invoices || []).length, 0) } });
    res.json(await billing.withNames(out));
  }));
  router.get('/invoice-follow-ups/summary', requireStaff('INVOICE_READ'), wrap(async (req, res) => { res.json((await off().followUpSummary(billing.actorOf(req.staff), mineOf(req))).body); }));

  router.get('/billing/dashboard', requireStaff('INVOICE_ADMIN'), wrap(async (req, res) => {
    const d = (await off().dashboard(billing.actorOf(req.staff))).body;
    await audit.read(req, { action: 'billing.dashboard' });
    res.json(await billing.withNames(d));
  }));

  const money = minor => (Number(minor) / 100).toFixed(2);
  router.get('/billing/export.csv', requireStaff('INVOICE_ADMIN'), wrap(async (req, res) => {
    const out = (await off().exportRows(billing.actorOf(req.staff), pick(req.query, LIST_FILTERS.filter(k => k !== 'limit' && k !== 'offset')))).body;
    const names = (await billing.withNames({ rows: out.rows })).names;
    await audit.read(req, { action: 'invoice.export', detail: { returned: out.rows.length, truncated: out.truncated } });
    const rows = [['Invoice number', 'Status', 'Customer', 'Currency', 'Total', 'Paid', 'Balance', 'Issued on', 'Due on', 'Owner', 'Last follow-up']];
    for (const i of out.rows) rows.push([i.invoiceNumber, i.effectiveStatus, i.billToName, i.currency, money(i.totalMinor), money(i.paidMinor), money(i.balanceMinor), i.issuedOn, i.dueOn, names[i.ownerUserId] || 'Former team member', i.lastFollowUpAt]);
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="invoices-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' });
    res.send(toCsv(rows));
  }));

  return router;
}

module.exports = { billingRoutes };
