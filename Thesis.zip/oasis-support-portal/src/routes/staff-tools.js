'use strict';
const express = require('express');
const { wrap } = require('../errors');

const REFERENCE = /^[A-Za-z0-9-]{1,40}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});

/** The bell, replying to a customer, and the workload page. Replies are written to a customer, so each one is audited (its length and how it went, never what it said). */
function staffToolsRoutes({ tools, audit, requireStaff }) {
  const router = express.Router();

  router.get('/notifications', requireStaff(), wrap(async (req, res) => { res.json(await tools.notifications(req.staff)); }));
  router.post('/notifications/read', requireStaff(), wrap(async (req, res) => { res.json(await tools.markSeen(req.staff)); }));

  router.get('/workload', requireStaff('CUSTOMER_READ'), wrap(async (_req, res) => { res.json(await tools.workload()); }));
  router.get('/workload/:who', requireStaff('CUSTOMER_READ'), wrap(async (req, res) => { res.json(await tools.workloadOf(req.params.who)); }));

  const reply = (path, permission, kind, action) => router.post(path, requireStaff(permission), wrap(async (req, res) => {
    const body = bodyOf(req);
    const subject = REFERENCE.test(req.params.reference) ? req.params.reference : null;
    const out = await audit.change(req, { action, subject, reason: 'Replied to the customer', detail: {} }, async () => {
      const r = await tools.reply({ kind, reference: req.params.reference, subject: body.subject, body: body.body }, req.staff);
      return { result: { id: r.id, delivery: r.delivery }, detail: { length: r.length, delivery: r.delivery } };
    });
    res.status(201).json(out);
  }));
  reply('/purchase-requests/:reference/reply', 'CUSTOMER_UPDATE', 'licence_request', 'purchase_request.reply');
  reply('/support-requests/:reference/reply', 'SUPPORT_REQUEST_UPDATE', 'help_request', 'support_request.reply');

  return router;
}

module.exports = { staffToolsRoutes };
