'use strict';
const express = require('express');
const { refuse, wrap } = require('../errors');
const { toCsv } = require('../csv');

const MAX_ROWS = 50_000;
const stamp = () => new Date().toISOString().slice(0, 10);
const text = (req, name) => {
  const v = req.query[name];
  if (v !== undefined && typeof v !== 'string') throw refuse(`${name} must be text.`, 'bad_filter');
  return v;
};
const code = v => (typeof v === 'string' && /^[A-Za-z0-9._-]{1,60}$/.test(v) ? v : null);

/** Downloads (CSV) of the Reports screen, the Customer users overview and the audit log. Admins only; each download is itself recorded. Totals only, except the audit log. */
function exportRoutes({ overview, audit, requireStaff }) {
  const router = express.Router();
  const send = (res, name, rows) => {
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}-${stamp()}.csv"`, 'Cache-Control': 'no-store' });
    res.send(toCsv(rows));
  };
  const weeksOf = req => {
    const v = req.query.weeks;
    if (v === undefined) return 12;
    const n = Number(v);
    if (!/^\d+$/.test(String(v)) || n < 4 || n > 52) throw refuse('weeks must be a whole number from 4 to 52.', 'bad_filter');
    return n;
  };

  router.get('/reports.csv', requireStaff('REPORT_READ'), wrap(async (req, res) => {
    const weeks = weeksOf(req);
    await audit.read(req, { action: 'report.export', detail: { weeks } });
    const r = await overview.reports(weeks);
    const rows = [['section', 'item', 'value']];
    for (const [name, points] of Object.entries(r.weekly)) for (const p of points) rows.push([`weekly_${name.replace(/[A-Z]/g, c => `_${c.toLowerCase()}`)}`, p.week, p.n]);
    for (const [k, v] of Object.entries(r.licenceRequests.byStatus)) rows.push(['licence_requests_by_status', k, v]);
    for (const s of r.licenceRequests.bySource) rows.push(['licence_requests_by_source', s.code, s.n]);
    rows.push(['licence_requests', 'agreed_rate_percent', r.licenceRequests.agreeRate], ['licence_requests', 'total', r.licenceRequests.total]);
    for (const [k, v] of Object.entries(r.helpRequests.byStatus)) rows.push(['help_requests_by_status', k, v]);
    for (const [k, v] of Object.entries(r.licences.byStatus)) rows.push(['licences_by_status', k, v]);
    for (const p of r.licences.byPlan) rows.push(['licences_in_use_by_plan', p.label, p.n]);
    for (const [k, v] of Object.entries(r.licences.expiring)) rows.push(['licences_ending', k, v]);
    for (const [k, v] of Object.entries(r.trials.byStatus)) rows.push(['trials_by_status', k, v]);
    rows.push(['trials', 'conversion_rate_percent', r.trials.conversionRate]);
    for (const c of r.feedback.byCategory) rows.push(['feedback_by_kind', c.label, c.n]);
    for (const c of r.feedback.byRating) rows.push(['feedback_by_rating', c.rating, c.n]);
    rows.push(['feedback', 'average_rating', r.feedback.averageRating]);
    for (const w of r.workload) rows.push(['workload_licence_requests', w.name, w.licenceRequests], ['workload_help_requests', w.name, w.helpRequests]);
    send(res, 'oasis-report', rows);
  }));

  router.get('/customer-users.csv', requireStaff('REPORT_READ'), wrap(async (req, res) => {
    const weeks = weeksOf(req);
    await audit.read(req, { action: 'customer_users.export', detail: { weeks } });
    const r = await overview.customerUsersOverview(weeks);
    const rows = [['customer', 'status', 'users', 'active', 'invited', 'locked_or_disabled', 'signed_in_last_30_days', 'never_signed_in', 'seats_in_use', 'seat_limit', 'last_sign_in', 'needs_attention']];
    for (const c of r.customers) rows.push([c.name, c.status, c.users.total, c.users.active, c.users.invited, c.users.blocked, c.users.active30d, c.users.neverSignedIn, c.seatsInUse, c.seatLimit === null ? 'unlimited' : c.seatLimit, c.lastSignIn, c.flags.join(' ')]);
    send(res, 'oasis-customer-users', rows);
  }));

  router.get('/audit.csv', requireStaff('AUDIT_READ'), wrap(async (req, res) => {
    const filters = { actor: text(req, 'actor'), action: text(req, 'action'), subject: text(req, 'subject'), outcome: text(req, 'outcome'), since: text(req, 'since') };
    const entries = [];
    for (let offset = 0; entries.length < MAX_ROWS; offset += 200) {
      const chunk = await overview.listAudit({ ...filters, limit: 200, offset });
      entries.push(...chunk);
      if (chunk.length < 200) break;
    }
    await audit.read(req, { action: 'audit.export', detail: { action: code(filters.action), outcome: code(filters.outcome), returned: entries.length } });
    const rows = [['when', 'who', 'action', 'subject', 'outcome', 'reason', 'detail', 'request_id']];
    for (const e of entries.slice(0, MAX_ROWS)) rows.push([e.occurred_at, e.actor_name, e.action, e.subject_ref, e.outcome, e.reason, e.detail, e.request_id]);
    send(res, 'oasis-audit-log', rows);
  }));

  return router;
}

module.exports = { exportRoutes };
