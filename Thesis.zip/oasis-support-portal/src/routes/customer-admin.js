'use strict';
const express = require('express');
const { wrap } = require('../errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const bodyOf = req => (req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {});
const idOf = v => (typeof v === 'string' && UUID.test(v) ? v : null);

/**
 * Customers: edit their details (admins), keep notes on them (any staff who can update customers), and look after their own users (admins). Notes and users are
 * personal data, so what is written goes in the trail as ids and lengths, never the text.
 */
function customerAdminRoutes({ customerAdmin, admin, audit, requireStaff }) {
  const router = express.Router();

  router.get('/customer-options', requireStaff('CUSTOMER_READ'), wrap(async (_req, res) => { res.json(await customerAdmin.options()); }));

  router.patch('/customers/:id', requireStaff('CUSTOMER_MANAGE'), wrap(async (req, res) => {
    const body = bodyOf(req);
    const reason = admin.reasonOf(body);
    const out = await audit.change(req, { action: 'customer.update', subject: idOf(req.params.id), reason, detail: {} }, async () => {
      const r = await customerAdmin.update(req.params.id, body, reason, req.staff);
      return { result: r.after, detail: { changed: r.changed } };           // which fields, never the new values (a name can be personal)
    });
    res.json(out);
  }));

  router.post('/customers/:id/notes', requireStaff('CUSTOMER_UPDATE'), wrap(async (req, res) => {
    const out = await audit.change(req, { action: 'customer.note', subject: idOf(req.params.id), reason: 'Added a note', detail: {} }, async () => {
      const r = await customerAdmin.addNote(req.params.id, bodyOf(req).body, req.staff);
      return { result: { id: r.id }, detail: { length: r.length } };
    });
    res.status(201).json(out);
  }));

  router.post('/customer-users/:customerId/users/:userId/:action', requireStaff('CUSTOMER_USER_MANAGE'), wrap(async (req, res) => {
    const reason = admin.reasonOf(bodyOf(req));
    const out = await audit.change(req, { action: `customer_user.${customerAdmin.ACTIONS.includes(req.params.action) ? req.params.action : 'unknown'}`, subject: idOf(req.params.userId), reason, detail: { customerId: idOf(req.params.customerId) } }, async () => {
      const r = await customerAdmin.manageUser(req.params.customerId, req.params.userId, req.params.action, reason, req.staff);
      return { result: r, detail: { customerId: idOf(req.params.customerId), from: r.from, to: r.to, removed: r.removed } };
    });
    res.json(out);
  }));

  return router;
}

module.exports = { customerAdminRoutes };
