'use strict';
const crypto = require('node:crypto');
const { refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { hashPassword, verifyPassword, passwordProblem } = require('./password');

const WINDOW_MINUTES = 15;
const MAX_LINKS = 3;                    // links per person per window: asking again and again cannot be used to flood someone's mailbox
const LINK_HOURS = { activate: 72, reset: 1 };
const BAD_LINK = 'This link is not valid. It may have expired or already been used. Ask for a new one.';
const MAX_PASSWORD_TRIES = 5;
const LOCK_MINUTES = 15;
const STAFF_ROLES = ['SUPPORT', 'PLATFORM_ADMIN'];

/**
 * Staff sign-in: an email address and a password, then a session. A password is chosen, or replaced, through an emailed link (activation for a new member, reset for the rest). Nothing here tells a caller whether an address
 * belongs to a staff member: a wrong address and a wrong password fail the same way and take the same time, and asking for a link always answers the same. Passwords
 * are kept only as salted scrypt hashes (src/password.js); codes and session tokens only as keyed hashes. After five wrong passwords the account pauses for 15 minutes.
 */
function createAuth({ identityDb, hash, notifier, log = () => {}, sessionHours = 8, passwordCost, portalBaseUrl }) {
  const linkHash = token => hash('staff-link', token);
  const tokenHash = token => hash('session', token);
  const BAD_LOGIN = () => refuse('That email address or password is not right. After several wrong tries, sign-in pauses for 15 minutes.', 'bad_credentials');
  let dummy;       // a real hash to compare against when the address is unknown, so a stranger and a staff member take the same time
  const dummyHash = () => (dummy ||= hashPassword(hash, 'not-a-real-password-for-timing', passwordCost));

  async function findStaff(db, email) {
    const { rows } = await db.query(
      `SELECT u.user_id FROM app_user u
        WHERE u.email = $1 AND u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = ANY($2))`, [email, STAFF_ROLES]);
    return rows.length ? rows[0].user_id : null;
  }

  const loginEvent = (db, { userId, outcome, reason, ipHash }) => db.query(
    `INSERT INTO login_event (login_event_id, user_id, outcome_code, reason, occurred_at, ip_hash) VALUES ($1, $2, $3, $4, now(), $5)`,
    [uuidv7(), userId, outcome, reason, ipHash]);

  /** A new session for a person who has just proved who they are. */
  async function startSession(db, userId) {
    const token = crypto.randomBytes(32).toString('base64url');
    const { rows: [s] } = await db.query(
      `INSERT INTO session (session_id, user_id, refresh_token_hash, family_id, expires_at) VALUES ($1, $2, $3, $4, now() + make_interval(hours => $5)) RETURNING expires_at`,
      [uuidv7(), userId, tokenHash(token), uuidv7(), sessionHours]);
    return { token, expiresAt: s.expires_at };
  }

  /** Email address and password. A wrong password is counted; the fifth in a row pauses the account. Every failure gives the same answer. */
  async function login({ email, password, ipHash }) {
    const given = typeof password === 'string' && password.length <= 200 ? password : '';
    const outcome = await tx(identityDb, async db => {
      const userId = await findStaff(db, email);
      const { rows } = userId ? await db.query('SELECT password_hash, failed_attempts, (locked_until > now()) AS locked FROM staff_credential WHERE user_id = $1 FOR UPDATE', [userId]) : { rows: [] };
      const cred = rows[0];
      if (!cred) {
        await verifyPassword(hash, given, await dummyHash());
        await loginEvent(db, { userId: userId || null, outcome: 'FAILED', reason: userId ? 'no_password' : 'unknown_email', ipHash });
        return { failed: true };
      }
      if (cred.locked) { await loginEvent(db, { userId, outcome: 'LOCKED', reason: 'paused', ipHash }); return { failed: true }; }
      if (!(await verifyPassword(hash, given, cred.password_hash))) {
        const tries = cred.failed_attempts + 1;
        if (tries >= MAX_PASSWORD_TRIES) {
          await db.query(`UPDATE staff_credential SET failed_attempts = 0, locked_until = now() + make_interval(mins => $2) WHERE user_id = $1`, [userId, LOCK_MINUTES]);
          await loginEvent(db, { userId, outcome: 'LOCKED', reason: 'too_many_passwords', ipHash });
        } else {
          await db.query('UPDATE staff_credential SET failed_attempts = $2 WHERE user_id = $1', [userId, tries]);
          await loginEvent(db, { userId, outcome: 'FAILED', reason: 'wrong_password', ipHash });
        }
        return { failed: true };
      }
      await db.query('UPDATE staff_credential SET failed_attempts = 0, locked_until = NULL WHERE user_id = $1', [userId]);
      const session = await startSession(db, userId);
      await loginEvent(db, { userId, outcome: 'SUCCESS', reason: null, ipHash });
      return session;
    });
    if (outcome.token) return outcome;
    throw BAD_LOGIN();
  }

  const savePassword = (db, userId, passwordHash) => db.query(
    `INSERT INTO staff_credential (user_id, password_hash) VALUES ($1, $2)
     ON CONFLICT (user_id) DO UPDATE SET password_hash = EXCLUDED.password_hash, password_changed_at = now(), failed_attempts = 0, locked_until = NULL`, [userId, passwordHash]);

  // ── Activation and reset links ──────────────────────────────────────────────

  const linkFor = (purpose, token) => `${portalBaseUrl.replace(/\/$/, '')}/#/${purpose === 'activate' ? 'activate' : 'reset'}/${token}`;      // in the fragment, so the secret never reaches a server log or a Referer header

  /** Makes a new link for a person, replacing any open one for the same purpose. Returns the secret, which exists nowhere else: it goes in the email and is never stored. */
  async function issueLink(db, { userId, purpose, createdBy = null }) {
    await db.query('SELECT pg_advisory_xact_lock(hashtext($1))', [userId]);
    await db.query(`UPDATE staff_link SET revoked_at = now() WHERE user_id = $1 AND purpose = $2 AND used_at IS NULL AND revoked_at IS NULL`, [userId, purpose]);
    const token = crypto.randomBytes(32).toString('base64url');
    const { rows: [l] } = await db.query(
      `INSERT INTO staff_link (link_id, user_id, purpose, token_hash, expires_at, created_by_user_id) VALUES ($1, $2, $3, $4, now() + make_interval(hours => $5), $6) RETURNING expires_at`,
      [uuidv7(), userId, purpose, linkHash(token), LINK_HOURS[purpose], createdBy]);
    return { token, purpose, expiresAt: l.expires_at, expiresInHours: LINK_HOURS[purpose] };
  }

  /** Emails a link. Returns whether the sender took it; a failure is logged (never the link) and is not thrown. */
  async function deliverLink({ to, displayName, link }) {
    try { await notifier.send({ kind: link.purpose === 'activate' ? 'activation' : 'password_reset', to, displayName: displayName || null, link: linkFor(link.purpose, link.token), expiresInHours: link.expiresInHours }); return true; }
    catch (err) { log({ level: 'error', msg: 'link email not sent', error: err && err.name }); return false; }
  }

  /** A person asks for a link themselves ("Forgot or set your password"). Always looks the same: an address that is not staff gets nothing and the caller learns nothing. */
  async function requestLink({ email, ipHash }) {
    let send = null;
    await tx(identityDb, async db => {
      const { rows } = await db.query(
        `SELECT u.user_id, u.display_name, u.status_code FROM app_user u
          WHERE u.email = $1 AND u.user_type_code = 'staff' AND u.status_code IN ('ACTIVE', 'INVITED') AND u.deleted_at IS NULL
            AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = ANY($2))`, [email, STAFF_ROLES]);
      if (!rows.length) return loginEvent(db, { userId: null, outcome: 'FAILED', reason: 'unknown_email', ipHash });
      const u = rows[0];
      await db.query('SELECT pg_advisory_xact_lock(hashtext($1))', [u.user_id]);
      const { rows: [recent] } = await db.query(`SELECT count(*)::int AS n FROM staff_link WHERE user_id = $1 AND created_at > now() - make_interval(mins => $2)`, [u.user_id, WINDOW_MINUTES]);
      if (recent.n >= MAX_LINKS) return loginEvent(db, { userId: u.user_id, outcome: 'FAILED', reason: 'too_many_links', ipHash });
      const link = await issueLink(db, { userId: u.user_id, purpose: u.status_code === 'INVITED' ? 'activate' : 'reset' });      // a pending member who "forgot" simply gets a fresh activation link
      await loginEvent(db, { userId: u.user_id, outcome: 'LINK_SENT', reason: link.purpose, ipHash });
      send = { to: email, displayName: u.display_name, link };
    });
    // Sent WITHOUT making the caller wait, and a failure is only logged: the time taken must not show that an address is a staff member's.
    if (send) Promise.resolve().then(() => deliverLink(send)).catch(() => {});
  }

  /** The open link for a secret, with the account it is for, or null. The state must still match its purpose (a deactivated person's link is dead). */
  async function openLink(db, token, { lock = false } = {}) {
    if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
    const { rows } = await db.query(
      `SELECT l.link_id, l.purpose, u.user_id, u.email, u.display_name, u.status_code FROM staff_link l JOIN app_user u ON u.user_id = l.user_id
        WHERE l.token_hash = $1 AND l.used_at IS NULL AND l.revoked_at IS NULL AND l.expires_at > now() AND u.user_type_code = 'staff' AND u.deleted_at IS NULL
          AND ((l.purpose = 'activate' AND u.status_code = 'INVITED') OR (l.purpose = 'reset' AND u.status_code = 'ACTIVE'))
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = ANY($2))${lock ? ' FOR UPDATE OF l, u' : ''}`, [linkHash(token), STAFF_ROLES]);
    return rows[0] || null;
  }

  /** What the page behind a link needs to say: which kind, and whose account. Nothing else is revealed. */
  async function inspectLink(token) {
    const l = await openLink(identityDb, token);
    if (!l) throw refuse(BAD_LINK, 'bad_link');
    return { purpose: l.purpose, email: l.email, displayName: l.display_name };
  }

  /**
   * Uses a link: the person chooses a password (typed twice), and an activation link also makes the account Active. The link is used up in the same step, every other open
   * link for the person is withdrawn, and every session they had ends. Nobody is signed in by this: they sign in with the new password. A password that is too weak, or typed
   * differently the second time, is refused BEFORE the link is used, so they can try again with the same link.
   */
  async function completeLink({ token, newPassword, confirmPassword, ipHash }) {
    const given = typeof newPassword === 'string' ? newPassword : '';
    const peek = await openLink(identityDb, token);
    if (!peek) throw refuse(BAD_LINK, 'bad_link');
    const problem = passwordProblem(given, peek.email);
    if (problem) throw refuse(problem, 'weak_password');
    if (given !== confirmPassword) throw refuse('The two passwords are not the same.', 'password_mismatch');
    const passwordHash = await hashPassword(hash, given, passwordCost);
    const done = await tx(identityDb, async db => {
      const l = await openLink(db, token, { lock: true });
      if (!l) return false;
      await db.query('UPDATE staff_link SET used_at = now() WHERE link_id = $1', [l.link_id]);
      await db.query(`UPDATE staff_link SET revoked_at = now() WHERE user_id = $1 AND used_at IS NULL AND revoked_at IS NULL`, [l.user_id]);
      if (l.purpose === 'activate') {
        await db.query(`SELECT set_config('app.reason', 'Activated their account from the emailed link', true)`);
        await db.query(`SELECT set_config('app.actor_id', $1, true)`, [l.user_id]);
        await db.query(`UPDATE app_user SET status_code = 'ACTIVE' WHERE user_id = $1`, [l.user_id]);
      }
      await savePassword(db, l.user_id, passwordHash);
      await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'password_reset' WHERE user_id = $1 AND revoked_at IS NULL`, [l.user_id]);
      await loginEvent(db, { userId: l.user_id, outcome: 'PASSWORD_SET', reason: l.purpose === 'activate' ? 'activated' : 'reset', ipHash });
      return l.purpose;
    });
    if (!done) throw refuse(BAD_LINK, 'bad_link');
    return { purpose: done };
  }

  /** A signed-in member chooses a new password, proving they know the current one. Their other sessions end; this one stays. */
  async function changePassword({ userId, sessionId, email, currentPassword, newPassword, ipHash }) {
    const problem = passwordProblem(newPassword, email);
    if (problem) throw refuse(problem, 'weak_password');
    const passwordHash = await hashPassword(hash, newPassword, passwordCost);
    const ok = await tx(identityDb, async db => {
      const { rows } = await db.query('SELECT password_hash, (locked_until > now()) AS locked FROM staff_credential WHERE user_id = $1 FOR UPDATE', [userId]);
      const good = rows.length && !rows[0].locked && typeof currentPassword === 'string' && currentPassword.length <= 200 && await verifyPassword(hash, currentPassword, rows[0].password_hash);
      if (!good) { await loginEvent(db, { userId, outcome: 'FAILED', reason: 'wrong_current_password', ipHash }); return false; }
      await savePassword(db, userId, passwordHash);
      await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'password_changed' WHERE user_id = $1 AND session_id <> $2 AND revoked_at IS NULL`, [userId, sessionId]);
      await loginEvent(db, { userId, outcome: 'PASSWORD_SET', reason: 'changed', ipHash });
      return true;
    });
    if (!ok) throw refuse('Your current password is not right.', 'bad_current_password');
  }

  /** The signed-in staff member for a bearer token, or null. A disabled or role-less user's sessions stop working at once. */
  async function authenticate(token) {
    if (typeof token !== 'string' || token.length < 20 || token.length > 100) return null;
    const { rows } = await identityDb.query(
      `SELECT s.session_id, u.user_id, u.email, u.display_name,
              coalesce(array_agg(DISTINCT r.role_code) FILTER (WHERE r.role_code IS NOT NULL), '{}') AS roles,
              coalesce(array_agg(DISTINCT rp.permission_code) FILTER (WHERE rp.permission_code IS NOT NULL), '{}') AS permissions
         FROM session s
         JOIN app_user u ON u.user_id = s.user_id AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL AND u.user_type_code = 'staff'
                          AND s.created_at >= u.status_changed_at          -- disabling and re-enabling someone does not bring an old session back
         LEFT JOIN user_role r ON r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = ANY($2)
                              AND r.granted_at <= s.created_at              -- nor does revoking and re-granting a role
         LEFT JOIN role_permission rp ON rp.role_code = r.role_code
        WHERE s.refresh_token_hash = $1 AND s.revoked_at IS NULL AND s.expires_at > now()
        GROUP BY s.session_id, u.user_id`, [tokenHash(token), STAFF_ROLES]);
    if (!rows.length || !rows[0].roles.length) return null;
    const r = rows[0];
    return { sessionId: r.session_id, userId: r.user_id, email: r.email, displayName: r.display_name, roles: r.roles, permissions: new Set(r.permissions) };
  }

  async function signOut(sessionId) {
    await identityDb.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'logout' WHERE session_id = $1 AND revoked_at IS NULL`, [sessionId]);
  }

  return { login, changePassword, requestLink, inspectLink, completeLink, issueLink, deliverLink, authenticate, signOut };
}

module.exports = { createAuth, STAFF_ROLES };
