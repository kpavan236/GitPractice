'use strict';
const { ApiError, refuse } = require('./errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const notFound = what => new ApiError(404, `No such ${what}.`, 'not_found');
const escapeLike = s => s.replace(/[\\%_]/g, m => `\\${m}`);

/**
 * The read side the screens need that is not tied to one kind of request: the dashboard counts, customers, one licence in full, and the audit log. Nothing here
 * changes anything. What it returns is shaped for people: names instead of ids where a person is meant, labels beside codes, and never a licence key, a machine id,
 * a code or a hash.
 */
function createOverview({ identityDb, customerDb, licenseDb, supportDb, lifecycle, namesOf, customerAdmin }) {

  // ── Dashboard ───────────────────────────────────────────────────────────────

  /** What the team needs to see first: what is waiting, what is theirs, what is going stale, what is about to lapse. */
  async function dashboard(staff) {
    const mine = staff.userId;
    const [purchase, support, feedback, licences, trials] = await Promise.all([
      customerDb.query(
        `SELECT count(*) FILTER (WHERE status_code = 'NEW')::int AS new_count,
                count(*) FILTER (WHERE status_code = 'CONTACTED')::int AS contacted,
                count(*) FILTER (WHERE status_code = 'AGREED' AND customer_id IS NULL)::int AS agreed_without_licence,
                count(*) FILTER (WHERE status_code IN ('NEW', 'CONTACTED') AND assigned_to_user_id IS NULL)::int AS unassigned,
                count(*) FILTER (WHERE status_code IN ('NEW', 'CONTACTED') AND assigned_to_user_id = $1)::int AS mine,
                coalesce(round(extract(epoch FROM (now() - min(created_at) FILTER (WHERE status_code IN ('NEW', 'CONTACTED')))) / 3600.0, 1), 0) AS oldest_open_hours
           FROM purchase_request`, [mine]),
      supportDb.query(
        `SELECT count(*) FILTER (WHERE status_code = 'NEW')::int AS new_count,
                count(*) FILTER (WHERE status_code = 'IN_PROGRESS')::int AS in_progress,
                count(*) FILTER (WHERE status_code = 'RESOLVED')::int AS resolved,
                count(*) FILTER (WHERE status_code IN ('NEW', 'IN_PROGRESS') AND assigned_to_user_id IS NULL)::int AS unassigned,
                count(*) FILTER (WHERE status_code IN ('NEW', 'IN_PROGRESS') AND assigned_to_user_id = $1)::int AS mine,
                coalesce(round(extract(epoch FROM (now() - min(created_at) FILTER (WHERE status_code IN ('NEW', 'IN_PROGRESS')))) / 3600.0, 1), 0) AS oldest_open_hours
           FROM support_request`, [mine]),
      supportDb.query(
        `SELECT count(*)::int AS last_7_days, count(*) FILTER (WHERE category_code = 'bug')::int AS bugs_last_7_days FROM feedback WHERE created_at > now() - interval '7 days'`),
      licenseDb.query(
        `SELECT count(*) FILTER (WHERE status_code = 'ACTIVE' AND expires_at > now() AND expires_at <= now() + interval '30 days')::int AS expiring_in_30_days,
                count(*) FILTER (WHERE status_code = 'ACTIVE' AND expires_at <= now())::int AS ended_still_active,
                count(*) FILTER (WHERE status_code = 'SUSPENDED')::int AS suspended,
                count(*) FILTER (WHERE status_code = 'PENDING_ACTIVATION')::int AS waiting_for_first_activation,
                count(*) FILTER (WHERE status_code IN ('ACTIVE', 'PENDING_ACTIVATION'))::int AS live
           FROM (SELECT l.status_code, (SELECT max(ends_at) FROM license_term t WHERE t.license_id = l.license_id) AS expires_at FROM license l) x`),
      licenseDb.query(
        `SELECT count(*) FILTER (WHERE status_code = 'ACTIVE' AND coalesce(extended_until, expires_at) > now())::int AS running,
                count(*) FILTER (WHERE status_code = 'ACTIVE' AND coalesce(extended_until, expires_at) > now() AND coalesce(extended_until, expires_at) <= now() + interval '3 days')::int AS ending_in_3_days,
                count(*) FILTER (WHERE status_code = 'EXPIRED' AND coalesce(extended_until, expires_at) > now() - interval '7 days')::int AS ended_last_7_days,
                (SELECT count(DISTINCT trial_id)::int FROM trial_review_flag WHERE reviewed_at IS NULL) AS flagged_for_review
           FROM trial`),
    ]);
    const p = purchase.rows[0], s = support.rows[0];
    return {
      purchaseRequests: { new: p.new_count, contacted: p.contacted, agreedWithoutLicence: p.agreed_without_licence, unassigned: p.unassigned, mine: p.mine, oldestOpenHours: Number(p.oldest_open_hours) },
      supportRequests: { new: s.new_count, inProgress: s.in_progress, resolved: s.resolved, unassigned: s.unassigned, mine: s.mine, oldestOpenHours: Number(s.oldest_open_hours) },
      feedback: { last7Days: feedback.rows[0].last_7_days, bugsLast7Days: feedback.rows[0].bugs_last_7_days },
      licences: {
        live: licences.rows[0].live, expiringIn30Days: licences.rows[0].expiring_in_30_days, endedStillActive: licences.rows[0].ended_still_active,
        suspended: licences.rows[0].suspended, waitingForFirstActivation: licences.rows[0].waiting_for_first_activation,
      },
      trials: { running: trials.rows[0].running, endingIn3Days: trials.rows[0].ending_in_3_days, endedLast7Days: trials.rows[0].ended_last_7_days, flaggedForReview: trials.rows[0].flagged_for_review },
    };
  }

  // ── Reports (admins) ────────────────────────────────────────────────────────

  /**
   * Totals for the admin Reports screen: how much is coming in each week, where requests stand, what is being sold, how trials turn out, how feedback feels and who holds the
   * open work. Counts only: no customer name, address or message is ever in here. `weeks` is how far back the weekly series go.
   */
  async function reports(weeks) {
    const weekly = table => `SELECT to_char(w, 'YYYY-MM-DD') AS week, coalesce(n, 0)::int AS n
      FROM generate_series(date_trunc('week', now()) - ($1::int - 1) * interval '1 week', date_trunc('week', now()), interval '1 week') w
      LEFT JOIN (SELECT date_trunc('week', ${table.at}) AS wk, count(*) AS n FROM ${table.name} WHERE ${table.at} >= date_trunc('week', now()) - ($1::int - 1) * interval '1 week'${table.where ? ` AND ${table.where}` : ''} GROUP BY 1) c ON c.wk = w
      ORDER BY w`;
    const series = (db, table) => db.query(weekly(table), [weeks]).then(r => r.rows);
    const [purchaseWeekly, supportWeekly, feedbackWeekly, trialWeekly, purchaseStatus, supportStatus, source, licenceStatus, licencePlan, expiring, trialStatus, feedbackCategory, feedbackRating, openPurchase, openSupport, licenceTotals] = await Promise.all([
      series(customerDb, { name: 'purchase_request', at: 'created_at' }),
      series(supportDb, { name: 'support_request', at: 'created_at' }),
      series(supportDb, { name: 'feedback', at: 'created_at' }),
      series(licenseDb, { name: 'trial', at: 'started_at' }),
      customerDb.query(`SELECT status_code AS code, count(*)::int AS n FROM purchase_request GROUP BY 1`),
      supportDb.query(`SELECT status_code AS code, count(*)::int AS n FROM support_request GROUP BY 1`),
      customerDb.query(`SELECT source_code AS code, count(*)::int AS n FROM purchase_request GROUP BY 1 ORDER BY 2 DESC`),
      licenseDb.query(`SELECT status_code AS code, count(*)::int AS n FROM license GROUP BY 1`),
      licenseDb.query(`SELECT p.label, count(*)::int AS n FROM license l JOIN plan p USING (plan_code) WHERE l.status_code IN ('ACTIVE', 'PENDING_ACTIVATION') GROUP BY p.label ORDER BY 2 DESC`),
      licenseDb.query(
        `SELECT count(*) FILTER (WHERE e <= now() + interval '30 days')::int AS d30,
                count(*) FILTER (WHERE e > now() + interval '30 days' AND e <= now() + interval '60 days')::int AS d60,
                count(*) FILTER (WHERE e > now() + interval '60 days' AND e <= now() + interval '90 days')::int AS d90
           FROM (SELECT (SELECT max(ends_at) FROM license_term t WHERE t.license_id = l.license_id) AS e FROM license l WHERE l.status_code = 'ACTIVE') x WHERE e > now()`),
      licenseDb.query(`SELECT status_code AS code, count(*)::int AS n FROM trial GROUP BY 1`),
      supportDb.query(`SELECT c.label, count(*)::int AS n FROM feedback f JOIN feedback_category c USING (category_code) GROUP BY c.label ORDER BY 2 DESC`),
      supportDb.query(`SELECT rating, count(*)::int AS n FROM feedback WHERE rating IS NOT NULL GROUP BY 1 ORDER BY 1`),
      customerDb.query(`SELECT assigned_to_user_id AS who, count(*)::int AS n FROM purchase_request WHERE status_code IN ('NEW', 'CONTACTED') GROUP BY 1`),
      supportDb.query(`SELECT assigned_to_user_id AS who, count(*)::int AS n FROM support_request WHERE status_code IN ('NEW', 'IN_PROGRESS') GROUP BY 1`),
      licenseDb.query(`SELECT count(*)::int AS n FROM license`),
    ]);
    const counts = rows => Object.fromEntries(rows.map(r => [r.code, r.n]));
    const ps = counts(purchaseStatus.rows), ts = counts(trialStatus.rows);
    const sum = o => Object.values(o).reduce((a, b) => a + b, 0);
    const decided = (ps.AGREED || 0) + (ps.DECLINED || 0);
    const ratings = feedbackRating.rows;
    const rated = ratings.reduce((a, r) => a + r.n, 0);
    const names = await namesOf([...openPurchase.rows, ...openSupport.rows].map(r => r.who));
    const load = new Map();
    for (const [rowsOf, key] of [[openPurchase.rows, 'licenceRequests'], [openSupport.rows, 'helpRequests']]) {
      for (const r of rowsOf) {
        const name = r.who ? (names.get(r.who) || 'Former team member') : 'Not assigned';
        const entry = load.get(name) || { name, licenceRequests: 0, helpRequests: 0 };
        entry[key] += r.n; load.set(name, entry);
      }
    }
    return {
      weeks,
      weekly: { licenceRequests: purchaseWeekly, helpRequests: supportWeekly, feedback: feedbackWeekly, trials: trialWeekly },
      licenceRequests: { byStatus: ps, bySource: source.rows, total: sum(ps), agreeRate: decided ? Math.round((100 * (ps.AGREED || 0)) / decided) : null },
      helpRequests: { byStatus: counts(supportStatus.rows), total: sum(counts(supportStatus.rows)) },
      licences: { byStatus: counts(licenceStatus.rows), byPlan: licencePlan.rows, total: licenceTotals.rows[0].n, expiring: { within30: expiring.rows[0].d30, within60: expiring.rows[0].d60, within90: expiring.rows[0].d90 } },
      trials: { byStatus: ts, total: sum(ts), conversionRate: sum(ts) ? Math.round((100 * (ts.CONVERTED || 0)) / sum(ts)) : null },
      feedback: { byCategory: feedbackCategory.rows, byRating: ratings, averageRating: rated ? Math.round((10 * ratings.reduce((a, r) => a + r.rating * r.n, 0)) / rated) / 10 : null },
      workload: [...load.values()].sort((a, b) => (b.licenceRequests + b.helpRequests) - (a.licenceRequests + a.helpRequests)),
    };
  }

  // ── Customer users (admins) ─────────────────────────────────────────────────

  /**
   * One row per customer: how many of their people have an account, how many signed in lately, how many seats they use of what they bought, and when anyone last signed in.
   * Counts only: no name or address (those are in customerUsers, which is audited). `weeks` sets how far back the sign-up series goes.
   */
  async function customerUsersOverview(weeks) {
    const [users, signups, customers, seats, seatUse] = await Promise.all([
      identityDb.query(
        `SELECT customer_id, count(*)::int AS total,
                count(*) FILTER (WHERE status_code = 'ACTIVE')::int AS active, count(*) FILTER (WHERE status_code = 'INVITED')::int AS invited,
                count(*) FILTER (WHERE status_code IN ('LOCKED', 'DISABLED'))::int AS blocked,
                count(*) FILTER (WHERE last_login_at > now() - interval '30 days')::int AS active_30d,
                count(*) FILTER (WHERE first_login_at IS NULL)::int AS never_signed_in, max(last_login_at) AS last_login_at
           FROM app_user WHERE user_type_code = 'customer' AND deleted_at IS NULL GROUP BY customer_id`),
      identityDb.query(
        `SELECT to_char(w, 'YYYY-MM-DD') AS week, coalesce(n, 0)::int AS n
           FROM generate_series(date_trunc('week', now()) - ($1::int - 1) * interval '1 week', date_trunc('week', now()), interval '1 week') w
           LEFT JOIN (SELECT date_trunc('week', created_at) AS wk, count(*) AS n FROM app_user WHERE user_type_code = 'customer' AND deleted_at IS NULL
                       AND created_at >= date_trunc('week', now()) - ($1::int - 1) * interval '1 week' GROUP BY 1) c ON c.wk = w ORDER BY w`, [weeks]),
      customerDb.query(`SELECT c.customer_id, c.name, c.status_code, (SELECT count(*) FROM customer_domain d WHERE d.customer_id = c.customer_id)::int AS domains FROM customer c WHERE c.deleted_at IS NULL`),
      licenseDb.query(
        `SELECT customer_id, count(*)::int AS live_licences, sum(seat_limit)::int AS seat_limit, bool_or(seat_limit IS NULL) AS unlimited
           FROM license WHERE status_code IN ('ACTIVE', 'PENDING_ACTIVATION') GROUP BY customer_id`),
      licenseDb.query(`SELECT l.customer_id, count(*)::int AS seats_in_use FROM activation a JOIN license l USING (license_id) WHERE a.released_at IS NULL GROUP BY l.customer_id`),
    ]);
    const u = new Map(users.rows.map(r => [r.customer_id, r])), sl = new Map(seats.rows.map(r => [r.customer_id, r])), su = new Map(seatUse.rows.map(r => [r.customer_id, r.seats_in_use]));
    const now = Date.now(), DAY = 86_400_000;
    const rows = customers.rows.map(c => {
      const a = u.get(c.customer_id) || { total: 0, active: 0, invited: 0, blocked: 0, active_30d: 0, never_signed_in: 0, last_login_at: null };
      const l = sl.get(c.customer_id) || { live_licences: 0, seat_limit: 0, unlimited: false };
      const seatsInUse = su.get(c.customer_id) || 0;
      const last = a.last_login_at ? new Date(a.last_login_at).getTime() : null;
      const flags = [];
      if (l.live_licences && !a.total) flags.push('no_users');
      if (a.total && (last === null || now - last > 60 * DAY)) flags.push('dormant');
      if (!l.unlimited && l.seat_limit && seatsInUse / l.seat_limit >= 0.9) flags.push('near_seat_limit');
      return {
        customerId: c.customer_id, name: c.name, status: c.status_code, domains: c.domains,
        users: { total: a.total, active: a.active, invited: a.invited, blocked: a.blocked, active30d: a.active_30d, neverSignedIn: a.never_signed_in },
        lastSignIn: a.last_login_at, liveLicences: l.live_licences, seatsInUse, seatLimit: l.unlimited ? null : l.seat_limit, flags,
      };
    }).filter(r => r.users.total || r.liveLicences).sort((a, b) => b.users.total - a.users.total || a.name.localeCompare(b.name));
    const sum = f => rows.reduce((t, r) => t + f(r), 0);
    return {
      weeks, signups: signups.rows,
      totals: {
        customers: rows.length, users: sum(r => r.users.total), active: sum(r => r.users.active), invited: sum(r => r.users.invited), blocked: sum(r => r.users.blocked),
        active30d: sum(r => r.users.active30d), neverSignedIn: sum(r => r.users.neverSignedIn), seatsInUse: sum(r => r.seatsInUse),
        needAttention: rows.filter(r => r.flags.length).length, averagePerCustomer: rows.length ? Math.round((10 * sum(r => r.users.total)) / rows.length) / 10 : 0,
      },
      customers: rows,
    };
  }

  /** One customer's people: name, address, status and when they last signed in. Personal data, so the route records every read. */
  async function customerUsers(customerId) {
    if (typeof customerId !== 'string' || !UUID.test(customerId)) throw notFound('customer');
    const { rows: [c] } = await customerDb.query('SELECT customer_id, name, status_code FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [customerId]);
    if (!c) throw notFound('customer');
    const [people, domains, licences] = await Promise.all([
      identityDb.query(
        `SELECT user_id, display_name, email, status_code, first_login_at, last_login_at, created_at FROM app_user
          WHERE customer_id = $1 AND user_type_code = 'customer' AND deleted_at IS NULL ORDER BY last_login_at DESC NULLS LAST, created_at LIMIT 500`, [customerId]),
      customerDb.query('SELECT domain, verified_at FROM customer_domain WHERE customer_id = $1 ORDER BY domain', [customerId]),
      lifecycle.listLicences({ customerId, limit: 50, offset: 0 }),
    ]);
    return { customer: { id: c.customer_id, name: c.name, status: c.status_code }, users: people.rows, domains: domains.rows, licences };
  }

  // ── Plans (for the "create licence" form) ───────────────────────────────────

  /** The plans on sale, with their defaults and what they include, so the form can offer them and pre-fill seats and term. */
  async function listPlans() {
    const { rows } = await licenseDb.query(
      `SELECT p.plan_code, p.label, p.default_seat_limit, p.default_term_days, p.default_grace_days, p.offline_allowed,
              (SELECT coalesce(array_agg(f.name ORDER BY f.name), '{}') FROM plan_feature_default d JOIN feature f USING (feature_code) WHERE d.plan_code = p.plan_code AND d.enabled) AS features
         FROM plan p WHERE p.is_active AND p.plan_code <> 'trial' ORDER BY p.default_seat_limit NULLS LAST, p.label`);
    return rows;
  }

  // ── Customers ───────────────────────────────────────────────────────────────

  async function listCustomers({ q, limit, offset }) {
    const params = [], where = ['c.deleted_at IS NULL'];
    if (q !== undefined) {
      const term = q.trim();
      if (term.length < 2 || term.length > 100) throw refuse('q must be 2 to 100 characters.', 'bad_filter');
      params.push(`%${escapeLike(term)}%`);
      where.push(`(c.name ILIKE $1 ESCAPE '\\' OR EXISTS (SELECT 1 FROM customer_domain d WHERE d.customer_id = c.customer_id AND d.domain ILIKE $1 ESCAPE '\\'))`);
    }
    params.push(limit, offset);
    const { rows } = await customerDb.query(
      `SELECT c.customer_id, c.name, c.status_code, c.created_at, (SELECT count(*) FROM customer_domain d WHERE d.customer_id = c.customer_id)::int AS domains
         FROM customer c WHERE ${where.join(' AND ')} ORDER BY lower(c.name) LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    if (!rows.length) return [];
    const { rows: counts } = await licenseDb.query(
      `SELECT customer_id, count(*)::int AS licences, count(*) FILTER (WHERE status_code IN ('ACTIVE', 'PENDING_ACTIVATION'))::int AS live FROM license WHERE customer_id = ANY($1) GROUP BY customer_id`, [rows.map(r => r.customer_id)]);
    const by = new Map(counts.map(c => [c.customer_id, c]));
    return rows.map(r => ({ ...r, licences: (by.get(r.customer_id) || {}).licences || 0, live_licences: (by.get(r.customer_id) || {}).live || 0 }));
  }

  /** One customer: its domains, its licences, and the requests that led to it. */
  async function getCustomer(id) {
    if (typeof id !== 'string' || !UUID.test(id)) throw notFound('customer');
    const { rows: [c] } = await customerDb.query('SELECT customer_id, name, legal_name, website, industry_code, size_band_code, country_code, timezone, status_code, created_at FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [id]);
    if (!c) throw notFound('customer');
    const [domains, purchase, support, licences] = await Promise.all([
      customerDb.query('SELECT domain, verified_at, created_at FROM customer_domain WHERE customer_id = $1 ORDER BY domain', [id]),
      customerDb.query(`SELECT reference, organization_name, status_code, created_at FROM purchase_request WHERE customer_id = $1 ORDER BY created_at`, [id]),
      supportDb.query(`SELECT reference, subject, status_code, created_at FROM support_request WHERE customer_ref = $1 ORDER BY created_at`, [id]),
      lifecycle.listLicences({ customerId: id, limit: 200, offset: 0 }),
    ]);
    return { ...c, domains: domains.rows, purchaseRequests: purchase.rows, supportRequests: support.rows, licences, notes: await customerAdmin.listNotes(id) };
  }

  // ── One licence in full ─────────────────────────────────────────────────────

  /** Terms, features, seats, blocks and every status the licence has had, with who and why. Never the key (only its last four characters) and never a machine id. */
  async function getLicence(id) {
    if (typeof id !== 'string' || !UUID.test(id)) throw notFound('licence');
    const { rows: [l] } = await licenseDb.query(
      `SELECT l.license_id, l.customer_id, l.plan_code, p.label AS plan_label, l.kind_code, l.status_code, l.seat_limit, l.grace_days, l.offline_allowed, l.key_hint, l.created_at, l.created_by_user_id,
              (SELECT count(*)::int FROM activation a WHERE a.license_id = l.license_id AND a.released_at IS NULL) AS seats_in_use,
              (SELECT count(*)::int FROM access_block b WHERE b.license_id = l.license_id AND b.lifted_at IS NULL) AS machines_blocked
         FROM license l JOIN plan p USING (plan_code) WHERE l.license_id = $1`, [id]);
    if (!l) throw notFound('licence');
    const [terms, features, history, customer, seats] = await Promise.all([
      licenseDb.query('SELECT term_no, starts_at, ends_at, source_code, reference FROM license_term WHERE license_id = $1 ORDER BY term_no', [id]),
      licenseDb.query(`SELECT f.feature_code, f.name, e.limit_value FROM entitlement_current e JOIN feature f USING (feature_code) WHERE e.license_id = $1 AND e.enabled ORDER BY f.name`, [id]),
      licenseDb.query('SELECT from_status_code, to_status_code, changed_at, changed_by_user_id, reason FROM license_status_history WHERE license_id = $1 ORDER BY changed_at, history_id', [id]),
      customerDb.query('SELECT customer_id, name FROM customer WHERE customer_id = $1', [l.customer_id]),
      licenseDb.query(`SELECT a.activation_id, i.platform, i.app_version, a.activated_at, a.last_seen_at FROM activation a JOIN installation i USING (installation_id)
                        WHERE a.license_id = $1 AND a.released_at IS NULL ORDER BY a.activated_at LIMIT 500`, [id]),
    ]);
    const names = await namesOf([l.created_by_user_id, ...history.rows.map(h => h.changed_by_user_id)]);
    const who = uid => (uid ? names.get(uid) || null : null);
    const { created_by_user_id: createdBy, customer_id: _c, ...shown } = l;
    const ends = terms.rows.length ? terms.rows[terms.rows.length - 1].ends_at : null;
    return {
      ...shown, created_by_name: who(createdBy), customer: customer.rows[0] ? { id: customer.rows[0].customer_id, name: customer.rows[0].name } : null,
      starts_at: terms.rows.length ? terms.rows[0].starts_at : null, expires_at: ends,
      terms: terms.rows, features: features.rows, seats: seats.rows,
      history: history.rows.map(h => ({ ...h, changed_by_name: who(h.changed_by_user_id) })),
    };
  }

  // ── Audit log (admins) ──────────────────────────────────────────────────────

  async function listAudit({ actor, action, subject, outcome, since, limit, offset }) {
    const where = [], params = [];
    if (actor !== undefined) { if (!UUID.test(actor)) throw refuse('actor must be a team member id.', 'bad_filter'); params.push(actor); where.push(`a.actor_user_id = $${params.length}`); }
    if (action !== undefined) { if (!/^[a-z_.]{3,60}$/.test(action)) throw refuse('action must look like licence.create.', 'bad_filter'); params.push(action); where.push(`a.action = $${params.length}`); }
    if (subject !== undefined) { if (!/^[A-Za-z0-9._-]{1,100}$/.test(subject)) throw refuse('subject must be a reference or id.', 'bad_filter'); params.push(subject); where.push(`a.subject_ref = $${params.length}`); }
    if (outcome !== undefined) { if (!['started', 'done', 'failed', 'read'].includes(outcome)) throw refuse('outcome must be started, done, failed or read.', 'bad_filter'); params.push(outcome); where.push(`a.outcome = $${params.length}`); }
    if (since !== undefined) {
      const d = new Date(since);
      if (typeof since !== 'string' || !/^\d{4}-\d{2}-\d{2}/.test(since) || Number.isNaN(d.getTime())) throw refuse('since must be a date such as 2026-10-01.', 'bad_filter');
      params.push(d); where.push(`a.occurred_at >= $${params.length}`);
    }
    params.push(limit, offset);
    const { rows } = await identityDb.query(
      `SELECT a.audit_id, a.occurred_at, a.actor_user_id, a.action, a.subject_ref, a.reason, a.outcome, a.detail, a.request_id
         FROM admin_audit a ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY a.occurred_at DESC, a.audit_id DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    const names = await namesOf(rows.map(r => r.actor_user_id));
    return rows.map(r => ({ ...r, actor_name: names.get(r.actor_user_id) || null }));
  }

  return { dashboard, reports, customerUsersOverview, customerUsers, listPlans, listCustomers, getCustomer, getLicence, listAudit };
}

module.exports = { createOverview };
