'use strict';
const { ApiError, refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { stripControl } = require('./forms');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const REFERENCE = /^SR-\d{6,}$/;
const CATEGORIES = ['bug', 'idea', 'praise', 'other'];

const conflict = (message, reason) => new ApiError(409, message, reason);
const notFound = () => new ApiError(404, 'No such support request.', 'not_found');

/**
 * What staff do with the messages people send from the app (the support service's database): read the lists, read one request in full, assign it, move
 * its status, link it to a customer, add notes; and read feedback. The text a person wrote is personal data and may hold anything, so reading it is audited
 * by the routes, and what they submitted is never editable (the database refuses, and nothing here tries).
 */
function createSupportMessages({ supportDb, customerDb, identityDb }) {

  /** Names for staff ids (assignee, note authors, who moved a status), so the lists read as people. A user that is gone shows as null. */
  async function namesOf(ids) {
    const wanted = [...new Set(ids.filter(Boolean))];
    if (!wanted.length) return new Map();
    const { rows } = await identityDb.query('SELECT user_id, display_name, email FROM app_user WHERE user_id = ANY($1)', [wanted]);
    return new Map(rows.map(r => [r.user_id, r.display_name || r.email]));
  }

  async function requireStaffUser(userId) {
    const { rows } = await identityDb.query(
      `SELECT 1 FROM app_user u WHERE u.user_id = $1 AND u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code IN ('SUPPORT', 'PLATFORM_ADMIN'))`, [userId]);
    if (!rows.length) throw refuse('assignedTo is not an active staff member.', 'unknown_assignee');
  }

  async function statusCodes() {
    return (await supportDb.query('SELECT status_code FROM request_status ORDER BY sort_order')).rows.map(r => r.status_code);
  }

  // ── Support requests ────────────────────────────────────────────────────────

  async function listRequests({ status, assignedTo, limit, offset }, staff) {
    const where = [], params = [];
    if (status !== undefined) {
      const known = await statusCodes();
      const wanted = String(status).split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      if (!wanted.length || wanted.some(s => !known.includes(s))) throw refuse(`status must be one or more of ${known.join(', ')}.`, 'bad_filter');
      params.push(wanted); where.push(`r.status_code = ANY($${params.length})`);
    }
    if (assignedTo !== undefined) {
      if (assignedTo === 'none') where.push('r.assigned_to_user_id IS NULL');
      else {
        const id = assignedTo === 'me' ? staff.userId : assignedTo;
        if (!UUID.test(id)) throw refuse('assignedTo must be "me", "none" or a staff user id.', 'bad_filter');
        params.push(id); where.push(`r.assigned_to_user_id = $${params.length}`);
      }
    }
    params.push(limit, offset);
    // The list never carries the message: it is the longest and most sensitive field, and reading one request is its own audited call.
    const { rows } = await supportDb.query(
      `SELECT v.reference, v.subject, v.contact_name, v.email, v.email_domain, r.status_code, v.status, v.is_closed, v.status_changed_at, v.assigned_to_user_id,
              v.customer_ref, v.app_version, v.created_at, v.hours_open_or_to_close, v.notes
         FROM v_support_request v JOIN support_request r USING (support_request_id)
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY (NOT v.is_closed) DESC, v.created_at ASC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    const names = await namesOf(rows.map(r => r.assigned_to_user_id));
    return rows.map(r => ({ ...r, assigned_to_name: r.assigned_to_user_id ? names.get(r.assigned_to_user_id) || null : null }));
  }

  /** One request in full: what the person wrote, its notes, and every status it has had. */
  async function getRequest(reference) {
    if (!REFERENCE.test(reference)) throw notFound();
    const { rows: [r] } = await supportDb.query(
      `SELECT r.support_request_id, r.reference, r.subject, r.message, r.contact_name, r.email, r.status_code, s.label AS status, s.is_closed, r.status_changed_at,
              r.assigned_to_user_id, r.customer_ref, r.app_version, r.created_at
         FROM support_request r JOIN request_status s USING (status_code) WHERE r.reference = $1`, [reference]);
    if (!r) throw notFound();
    const [{ rows: notes }, { rows: history }] = await Promise.all([
      supportDb.query('SELECT note_id, author_user_id, body, created_at FROM support_note WHERE support_request_id = $1 ORDER BY created_at, note_id', [r.support_request_id]),
      supportDb.query('SELECT from_status_code, to_status_code, changed_at, changed_by_user_id, reason FROM support_request_status_history WHERE support_request_id = $1 ORDER BY changed_at, history_id', [r.support_request_id]),
    ]);
    const names = await namesOf([r.assigned_to_user_id, ...notes.map(n => n.author_user_id), ...history.map(h => h.changed_by_user_id)]);
    const who = id => (id ? names.get(id) || null : null);
    const { support_request_id: _id, ...shown } = r;
    return {
      ...shown, assigned_to_name: who(r.assigned_to_user_id),
      notes: notes.map(n => ({ ...n, author_name: who(n.author_user_id) })),
      history: history.map(h => ({ ...h, changed_by_name: who(h.changed_by_user_id) })),
    };
  }

  /**
   * Assign, move the status, or link a customer, with a reason. The database enforces the allowed moves (and that every move has a reason) and that what the
   * person submitted is never edited; `app.reason` and `app.actor_id` are set with `set_config(..., true)` so they live only inside this transaction.
   */
  async function updateRequest(reference, body, reason, staff) {
    if (!REFERENCE.test(reference)) throw notFound();
    const status = body.status === undefined ? undefined : String(body.status).toUpperCase();
    const hasAssign = Object.prototype.hasOwnProperty.call(body, 'assignedTo');
    const hasCustomer = Object.prototype.hasOwnProperty.call(body, 'customerRef');
    if (status === undefined && !hasAssign && !hasCustomer) throw refuse('Give a status, an assignedTo, or a customerRef to change.', 'nothing_to_change');
    if (status !== undefined && !(await statusCodes()).includes(status)) throw refuse('That is not a status a support request can have.', 'bad_status');
    if (hasAssign && body.assignedTo !== null) {
      if (typeof body.assignedTo !== 'string' || !UUID.test(body.assignedTo)) throw refuse('assignedTo must be a staff user id, or null.', 'unknown_assignee');
      await requireStaffUser(body.assignedTo);
    }
    if (hasCustomer && body.customerRef !== null) {
      if (typeof body.customerRef !== 'string' || !UUID.test(body.customerRef)) throw refuse('customerRef must be a customer id, or null.', 'unknown_customer');
      if (!(await customerDb.query('SELECT 1 FROM customer WHERE customer_id = $1 AND deleted_at IS NULL', [body.customerRef])).rowCount) throw new ApiError(404, 'No such customer.', 'unknown_customer');
    }

    return tx(supportDb, async db => {
      const { rows: [cur] } = await db.query('SELECT support_request_id, status_code FROM support_request WHERE reference = $1 FOR UPDATE', [reference]);
      if (!cur) throw notFound();
      await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
      await db.query(`SELECT set_config('app.actor_id', $1, true)`, [staff.userId]);
      const sets = [], params = [cur.support_request_id];
      if (status !== undefined && status !== cur.status_code) { params.push(status); sets.push(`status_code = $${params.length}`); }
      if (hasAssign) { params.push(body.assignedTo); sets.push(`assigned_to_user_id = $${params.length}`); }
      if (hasCustomer) { params.push(body.customerRef); sets.push(`customer_ref = $${params.length}`); }
      if (sets.length) {
        try { await db.query(`UPDATE support_request SET ${sets.join(', ')} WHERE support_request_id = $1`, params); }
        catch (err) {
          if (err.code === '23514' && /cannot go from/.test(err.message)) throw conflict(`A request cannot move from ${cur.status_code} to ${status}.`, 'invalid_transition');
          throw err;
        }
      }
      const { rows: [after] } = await db.query(
        `SELECT reference, status_code, assigned_to_user_id, customer_ref, status_changed_at FROM support_request WHERE support_request_id = $1`, [cur.support_request_id]);
      return { before: cur.status_code, after };
    });
  }

  /** Adds a note. Notes are append-only: nobody can edit or remove one, so what support recorded is what stays recorded. */
  async function addNote(reference, body, staff) {
    if (!REFERENCE.test(reference)) throw notFound();
    const text = typeof body.body === 'string' ? stripNote(body.body) : '';
    if (!text) throw refuse('body must be the text of the note.', 'bad_note');
    if (text.length > 4000) throw refuse('Keep a note under 4,000 characters.', 'bad_note');
    return tx(supportDb, async db => {
      const { rows: [r] } = await db.query('SELECT support_request_id FROM support_request WHERE reference = $1 FOR SHARE', [reference]);
      if (!r) throw notFound();
      const noteId = uuidv7();
      const { rows: [n] } = await db.query(
        'INSERT INTO support_note (note_id, support_request_id, author_user_id, body) VALUES ($1, $2, $3, $4) RETURNING note_id, created_at', [noteId, r.support_request_id, staff.userId, text]);
      return { noteId: n.note_id, createdAt: n.created_at, length: text.length };
    });
  }
  const stripNote = t => String(t).replace(/\r\n?|\u0085|\u2028|\u2029/g, '\n').replace(/[\u0000-\u0009\u000b-\u001f\u007f​-‏‪-‮⁠-⁤⁦-⁩﻿]/g, '').split('\n').map(l => l.trimEnd()).join('\n').replace(/\n{3,}/g, '\n\n').trim();

  // ── Feedback ────────────────────────────────────────────────────────────────

  async function listFeedback({ category, rating, withEmail, limit, offset }) {
    const where = [], params = [];
    if (category !== undefined) {
      const wanted = String(category).split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
      if (!wanted.length || wanted.some(c => !CATEGORIES.includes(c))) throw refuse(`category must be one or more of ${CATEGORIES.join(', ')}.`, 'bad_filter');
      params.push(wanted); where.push(`f.category_code = ANY($${params.length})`);
    }
    if (rating !== undefined) {
      if (!/^[1-5]$/.test(rating)) throw refuse('rating must be a whole number from 1 to 5.', 'bad_filter');
      params.push(Number(rating)); where.push(`f.rating = $${params.length}`);
    }
    if (withEmail !== undefined) {
      if (withEmail !== 'true' && withEmail !== 'false') throw refuse('withEmail must be true or false.', 'bad_filter');
      where.push(withEmail === 'true' ? 'f.email IS NOT NULL' : 'f.email IS NULL');
    }
    params.push(limit, offset);
    const { rows } = await supportDb.query(
      `SELECT v.reference, f.category_code, v.category, v.rating, v.message, v.email, v.app_version, v.screen, v.created_at
         FROM v_feedback v JOIN feedback f USING (feedback_id) ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY v.created_at DESC, v.reference DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    return rows;
  }

  return { listRequests, getRequest, updateRequest, addNote, listFeedback };
}

module.exports = { createSupportMessages };
