'use strict';

function whole(env, name, { min, max, fallback }) {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return n;
}

/** Reads and checks the settings once, at start-up. A missing or malformed setting stops the service with a clear message. */
function loadConfig(env = process.env) {
  const need = name => { if (!env[name]) throw new Error(`${name} is required.`); return env[name]; };
  const pepper = name => { const v = need(name); if (v.length < 32) throw new Error(`${name} must be at least 32 characters.`); return v; };
  const production = env.NODE_ENV === 'production';

  if (production && (env.TRUST_PROXY === undefined || env.TRUST_PROXY === '')) {
    throw new Error('TRUST_PROXY must be set in production (the number of proxies in front of the service; 0 if none).');
  }

  // TLS is done by this service when both files are named. Only one is a mistake. In production, neither is allowed only when the hosting platform ends TLS
  // before the traffic reaches the service, and the operator says so with ALLOW_PLAIN_HTTP=1.
  const tlsCertFile = env.TLS_CERT_FILE || '', tlsKeyFile = env.TLS_KEY_FILE || '';
  if (Boolean(tlsCertFile) !== Boolean(tlsKeyFile)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together.');
  const tls = Boolean(tlsCertFile);
  if (env.ALLOW_PLAIN_HTTP !== undefined && !['', '0', '1'].includes(env.ALLOW_PLAIN_HTTP)) throw new Error('ALLOW_PLAIN_HTTP must be 1 or 0.');
  if (production && !tls && env.ALLOW_PLAIN_HTTP !== '1') throw new Error('Production needs TLS_CERT_FILE and TLS_KEY_FILE, or ALLOW_PLAIN_HTTP=1 when the hosting platform ends TLS.');
  // The billing service (invoices). Optional: with neither setting the portal runs without an Invoices section. The key is shared with that service and never leaves the server.
  const billingServiceUrl = (env.BILLING_SERVICE_URL || '').replace(/\/$/, '');
  const billingServiceKey = env.BILLING_SERVICE_KEY || '';
  if (Boolean(billingServiceUrl) !== Boolean(billingServiceKey)) throw new Error('BILLING_SERVICE_URL and BILLING_SERVICE_KEY must be set together.');
  if (billingServiceKey) {
    if (billingServiceKey.length < 32) throw new Error('BILLING_SERVICE_KEY must be at least 32 characters.');
    let b;
    try { b = new URL(billingServiceUrl); } catch { throw new Error('BILLING_SERVICE_URL must be a web address such as https://billing.example.test.'); }
    if (!['https:', 'http:'].includes(b.protocol) || b.search || b.hash || b.username || (b.pathname !== '/' && b.pathname !== '')) throw new Error('BILLING_SERVICE_URL must be a plain web address: no path, query, fragment or login.');
    if (production && b.protocol !== 'https:') throw new Error('BILLING_SERVICE_URL must be https in production.');
  }
  const notifier = env.NOTIFIER || 'fake';
  if (notifier !== 'fake') throw new Error('NOTIFIER must be "fake": no email provider has been approved yet (IT Helpdesk, cainc.service-now.com).');
  if (production) throw new Error('Production needs an approved email sender; the fake one would never deliver a staff sign-in code.');
  const printCodes = env.DEV_PRINT_CODES === '1';

  const platformCustomerId = need('PLATFORM_CUSTOMER_ID');
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(platformCustomerId)) throw new Error('PLATFORM_CUSTOMER_ID must be a customer id (uuid).');
  // Staff must sign in with a company address. Empty means any address (development only); production should name the domain(s).
  const staffEmailDomains = (env.STAFF_EMAIL_DOMAINS || '').split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
  if (staffEmailDomains.some(d => !/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/.test(d))) throw new Error('STAFF_EMAIL_DOMAINS must be a comma-separated list of domains such as cainc.com.');
  if (production && !staffEmailDomains.length) throw new Error('STAFF_EMAIL_DOMAINS is required in production: the domain(s) staff addresses must be on.');
  // The browser session cookie is Secure (https only) in production, and by default everywhere; COOKIE_SECURE=false is for http://localhost development only.
  if (env.COOKIE_SECURE !== undefined && !['true', 'false'].includes(env.COOKIE_SECURE)) throw new Error('COOKIE_SECURE must be true or false.');
  if (production && env.COOKIE_SECURE === 'false') throw new Error('COOKIE_SECURE=false is not allowed in production.');
  // Where the links in activation and reset emails point. It must be the address people open the portal at.
  const port = whole(env, 'PORT', { min: 1, max: 65535, fallback: 4030 });
  const portalBaseUrl = env.PORTAL_BASE_URL || (production ? '' : `http://127.0.0.1:${port}`);
  if (!portalBaseUrl) throw new Error('PORTAL_BASE_URL is required in production: the address staff open the portal at, used in activation and reset emails.');
  let parsed;
  try { parsed = new URL(portalBaseUrl); } catch { throw new Error('PORTAL_BASE_URL must be a web address such as https://support.example.com.'); }
  if (!['https:', 'http:'].includes(parsed.protocol) || parsed.search || parsed.hash || parsed.username) throw new Error('PORTAL_BASE_URL must be a plain web address: no query, fragment or login.');
  if (production && parsed.protocol !== 'https:') throw new Error('PORTAL_BASE_URL must be https in production.');
  return {
    tls, tlsCertFile, tlsKeyFile, shutdownTimeoutMs: whole(env, 'SHUTDOWN_TIMEOUT_MS', { min: 100, max: 300000, fallback: 10000 }),
    portalBaseUrl: portalBaseUrl.replace(/\/$/, ''), platformCustomerId, staffEmailDomains, secureCookies: env.COOKIE_SECURE !== 'false',
    printCodes, notifier,
    billingServiceUrl, billingServiceKey, billingCaFile: env.BILLING_CA_FILE || '',
    port: whole(env, 'PORT', { min: 1, max: 65535, fallback: 4030 }),
    identityDatabaseUrl: need('IDENTITY_DATABASE_URL'),
    customerDatabaseUrl: need('CUSTOMER_DATABASE_URL'),
    licenseDatabaseUrl: need('LICENSE_DATABASE_URL'),
    supportDatabaseUrl: need('SUPPORT_DATABASE_URL'),
    hashPepper: pepper('HASH_PEPPER'),                  // staff codes, session tokens, network addresses
    licenceHashPepper: pepper('LICENCE_HASH_PEPPER'),   // MUST equal the licence service's HASH_PEPPER: it is how licence keys are matched
    sessionHours: whole(env, 'SESSION_HOURS', { min: 1, max: 24, fallback: 8 }),
    trustProxy: whole(env, 'TRUST_PROXY', { min: 0, max: 10, fallback: 0 }),
  };
}

module.exports = { loadConfig };
