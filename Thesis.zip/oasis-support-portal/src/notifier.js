'use strict';

/**
 * The email sender, behind one method: send({ kind, to, ... }) where kind is 'activation' or 'password_reset' (with displayName, link, expiresInHours) or 'customer_reply' (with subject, body, fromName, reference). No real provider is approved yet (new email
 * services go through the IT Helpdesk, cainc.service-now.com first, and the wording needs CA employee review), so the only
 * implementation is a fake that keeps what it was asked to send, in memory, for tests.
 *
 * `print` is for a developer without a mailbox: it writes the link to the terminal. It is never turned on by default and
 * config.js refuses it in production, because a link that sets someone's password must not reach a log.
 */
function createFakeNotifier({ print = false, out = line => console.log(line) } = {}) {
  const sent = [];
  return {
    kind: 'fake',
    sent,
    async send(message) {
      sent.push({ ...message, at: Date.now() });
      if (sent.length > 1000) sent.shift();      // a fake that runs for weeks must not grow without limit
      if (print) out(message.kind === 'customer_reply' ? `(development only) reply to ${message.to}: ${message.subject}` : `(development only) ${message.kind} link for ${message.to}: ${message.link}`);
    },
    last: () => sent[sent.length - 1] || null,
  };
}

module.exports = { createFakeNotifier };
