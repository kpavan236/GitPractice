'use strict';
// Creates a staff member who can sign in to the support API, and grants a role.
//   node src/staff-cli.js --email pat@cainc.com --name "Pat Example" --role SUPPORT --customer <platform customer uuid>
// Needs IDENTITY_DATABASE_URL. --customer is the customer-database row that stands for the platform itself (staff belong to it).
// There is no public sign-up: this is the only way staff are added, and it is run by someone with database access.
const { createPool, tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { normaliseEmail, stripControl } = require('./forms');
const { STAFF_ROLES } = require('./auth');

function args(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    if (!argv[i].startsWith('--') || argv[i + 1] === undefined) throw new Error(`Unexpected argument "${argv[i]}".`);
    out[argv[i].slice(2)] = argv[i + 1];
  }
  return out;
}

(async () => {
  const a = args(process.argv.slice(2));
  const email = normaliseEmail(a.email);
  if (!email || !a.role || !a.customer) throw new Error('Usage: node src/staff-cli.js --email <address> --name <name> --role SUPPORT|PLATFORM_ADMIN --customer <uuid>');
  if (!STAFF_ROLES.includes(a.role)) throw new Error(`--role must be one of ${STAFF_ROLES.join(', ')}.`);
  if (!process.env.IDENTITY_DATABASE_URL) throw new Error('IDENTITY_DATABASE_URL is required.');
  const identityDb = createPool(process.env.IDENTITY_DATABASE_URL);
  try {
    const userId = uuidv7();
    await tx(identityDb, async db => {
      await db.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code) VALUES ($1, $2, 'staff', $3, $4, 'ACTIVE')`,
        [userId, a.customer, email, a.name ? stripControl(a.name).slice(0, 150) : null]);
      await db.query('INSERT INTO user_role (user_role_id, user_id, role_code) VALUES ($1, $2, $3)', [uuidv7(), userId, a.role]);
    });
    console.log(`Staff member ${email} created with role ${a.role} (${userId}). They choose a password on the sign-in page with "Forgot or set your password" (an emailed link).`);
  } finally { await identityDb.end(); }
})().catch(err => { console.error(err.message); process.exit(1); });
