'use strict';
const crypto = require('node:crypto');
const { uuidv7 } = require('./uuid');
const { normaliseKey } = require('./secrets');

// No 0, O, 1, I or L: a key read over the phone or typed from a PDF is not misread.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/** A new licence key such as OASIS-7K3M-2QX9-HDV4. Shown once, at issue; only its hash is kept. */
function newLicenceKey() {
  const group = () => Array.from(crypto.randomBytes(4), b => ALPHABET[b % ALPHABET.length]).join('');
  return `OASIS-${group()}-${group()}-${group()}`;
}

/**
 * Creates a licence in the licence database and returns its key. The licence starts "pending activation" and becomes active when the
 * first machine activates. Its features are copied from the plan. The key is matched by the licence service with
 * hash('licence-key', normalised key), so `hash` MUST be made with the licence service's pepper: test/conformance.test.js proves it.
 * (This mirrors oasis-licence-service/src/issue-licence.js. Two copies are a known cost of two repositories; keep them in step.)
 */
async function issueLicence(db, hash, { customerId, plan, kind, seats, startsAt, termDays, reason, actorUserId }) {
  const key = newLicenceKey();
  const licenseId = uuidv7();
  await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
  await db.query(`SELECT set_config('app.actor_id', $1, true)`, [actorUserId]);
  await db.query(
    `INSERT INTO license (license_id, customer_id, plan_code, license_key_hash, key_hint, kind_code, seat_limit, grace_days, offline_allowed, created_by_user_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [licenseId, customerId, plan.plan_code, hash('licence-key', normaliseKey(key)), key.slice(-4), kind, seats, plan.default_grace_days, plan.offline_allowed && kind === 'enterprise', actorUserId]);
  await db.query(
    `INSERT INTO license_term (term_id, license_id, term_no, starts_at, ends_at, source_code)
     VALUES ($1, $2, 1, coalesce($3::timestamptz, now()), coalesce($3::timestamptz, now()) + make_interval(days => $4), 'purchase')`,
    [uuidv7(), licenseId, startsAt, termDays]);
  await db.query(
    `INSERT INTO entitlement (entitlement_id, license_id, feature_code, enabled, limit_value, reason, created_by_user_id)
     SELECT gen_random_uuid(), $1, feature_code, enabled, limit_value, 'Included in the plan', $3 FROM plan_feature_default WHERE plan_code = $2`,
    [licenseId, plan.plan_code, actorUserId]);
  await db.query(`UPDATE license SET status_code = 'PENDING_ACTIVATION' WHERE license_id = $1`, [licenseId]);
  return { licenseId, licenceKey: key };
}

module.exports = { issueLicence, newLicenceKey };
