'use strict';

/**
 * Builds the function that stops the service cleanly: stop accepting connections, close idle ones, let requests in flight finish, end the database pools, exit.
 * If that takes longer than timeoutMs, it exits anyway (code 1). Calling it again while it runs does nothing.
 */
function createShutdown({ server, pools, timeoutMs = 10000, exit = process.exit, log = line => console.log(JSON.stringify(line)), setTimer = setTimeout }) {
  let started = false;
  return async function shutdown(signal = 'shutdown') {
    if (started) return;
    started = true;
    log({ level: 'info', msg: 'shutting down', signal });
    const timer = setTimer(() => { log({ level: 'error', msg: 'shutdown timed out; forcing exit' }); server.closeAllConnections?.(); exit(1); }, timeoutMs);
    timer.unref?.();
    try {
      const closed = new Promise(resolve => server.close(() => resolve()));
      server.closeIdleConnections?.();
      await closed;
      await Promise.all(pools.map(p => p.end())).catch(() => {});
      clearTimeout(timer);
      exit(0);
    } catch (_) {
      clearTimeout(timer);
      exit(1);
    }
  };
}

module.exports = { createShutdown };
