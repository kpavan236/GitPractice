'use strict';
const { ApiError, refuse } = require('./errors');
const { tx } = require('./db');
const { uuidv7 } = require('./uuid');
const { normaliseEmail, stripControl } = require('./forms');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
/** The portal says "user" and "admin"; the identity database keeps its own role codes. */
const ROLE_CODES = { user: 'SUPPORT', admin: 'PLATFORM_ADMIN' };
const STAFF_ROLE_CODES = Object.values(ROLE_CODES);
const roleLabel = code => Object.keys(ROLE_CODES).find(k => ROLE_CODES[k] === code) || null;

const conflict = (message, reason) => new ApiError(409, message, reason);
const notFound = () => new ApiError(404, 'No such team member.', 'not_found');

/**
 * The team: who may sign in to the portal, and as what. Only admins reach this (USER_MANAGE). There is no sign-up: an admin adds a person by work email address, the account is
 * Pending activation, and the person gets an emailed link to activate it by choosing a password (the admin never sees or sets one). A person is Pending activation (INVITED),
 * Active, or Deactivated (DISABLED); a deactivated person cannot sign in until an admin activates them again. Two protections keep the team from locking itself out or being quietly changed: nobody can change their own
 * role or status, and the last active admin can never be demoted or disabled. Every change needs a reason and is audited by the route.
 */
function createUsers({ identityDb, platformCustomerId, staffEmailDomains = [], auth }) {
  const withReason = async (db, reason, actorId) => {
    await db.query(`SELECT set_config('app.reason', $1, true)`, [reason]);
    await db.query(`SELECT set_config('app.actor_id', $1, true)`, [actorId]);
  };

  const rowOf = r => ({
    id: r.user_id, email: r.email, displayName: r.display_name, role: roleLabel(r.role_code), status: r.status_code,
    lastLoginAt: r.last_login_at, createdAt: r.created_at,
  });
  const SELECT_USER = `SELECT u.user_id, u.email, u.display_name, u.status_code, u.last_login_at, u.created_at,
        (SELECT r.role_code FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = ANY($1) ORDER BY r.granted_at DESC LIMIT 1) AS role_code
      FROM app_user u WHERE u.user_type_code = 'staff' AND u.deleted_at IS NULL`;

  async function list() {
    const { rows } = await identityDb.query(`${SELECT_USER} ORDER BY (u.status_code = 'ACTIVE') DESC, lower(coalesce(u.display_name, u.email))`, [STAFF_ROLE_CODES]);
    return rows.map(rowOf);
  }

  async function get(db, id) {
    const { rows } = await db.query(`${SELECT_USER} AND u.user_id = $2`, [STAFF_ROLE_CODES, id]);
    return rows.length ? rowOf(rows[0]) : null;
  }

  function checkName(value) {
    if (typeof value !== 'string') throw refuse('displayName is required (1 to 150 characters).', 'bad_name');
    const name = stripControl(value);
    if (!name || name.length > 150) throw refuse('displayName is required (1 to 150 characters).', 'bad_name');
    return name;
  }

  function checkEmail(value) {
    const address = normaliseEmail(value);
    if (!address) throw refuse('Enter a valid email address.', 'bad_email');
    if (staffEmailDomains.length && !staffEmailDomains.includes(address.split('@')[1])) {
      throw refuse(`Team members must use a work address on: ${staffEmailDomains.join(', ')}.`, 'bad_email_domain');
    }
    return address;
  }

  async function create({ email, displayName, role }, reason, actor) {
    const address = checkEmail(email);
    const name = checkName(displayName);
    if (typeof role !== 'string' || !ROLE_CODES[role]) throw refuse('role must be "user" or "admin".', 'bad_role');

    const made = await tx(identityDb, async db => {
      if ((await db.query('SELECT 1 FROM app_user WHERE email = $1', [address])).rowCount) throw conflict('That address already has an account.', 'user_exists');
      await withReason(db, reason, actor.userId);
      const id = uuidv7();
      try { await db.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code) VALUES ($1, $2, 'staff', $3, $4, 'INVITED')`, [id, platformCustomerId, address, name]); }
      catch (err) { if (err.code === '23505') throw conflict('That address already has an account.', 'user_exists'); throw err; }      // added a moment ago by someone else
      await db.query('INSERT INTO user_role (user_role_id, user_id, role_code, granted_by_user_id) VALUES ($1, $2, $3, $4)', [uuidv7(), id, ROLE_CODES[role], actor.userId]);
      const link = await auth.issueLink(db, { userId: id, purpose: 'activate', createdBy: actor.userId });
      return { user: await get(db, id), link };
    });
    const emailed = await auth.deliverLink({ to: made.user.email, displayName: made.user.displayName, link: made.link });
    return { ...made.user, emailed };
  }

  /** An admin emails a link to a team member: an activation link to someone still Pending, a password-reset link to someone Active. Replaces any link sent before. */
  async function sendLink(id, reason, actor) {
    if (typeof id !== 'string' || !UUID.test(id)) throw notFound();
    const made = await tx(identityDb, async db => {
      const { rows: [locked] } = await db.query(`SELECT user_id FROM app_user WHERE user_id = $1 AND user_type_code = 'staff' AND deleted_at IS NULL FOR UPDATE`, [id]);
      if (!locked) throw notFound();
      const user = await get(db, id);
      if (user.status === 'DISABLED') throw conflict('That person is deactivated. Activate them first.', 'wrong_state');
      if (!user.role) throw conflict('That person has no role.', 'wrong_state');
      const link = await auth.issueLink(db, { userId: id, purpose: user.status === 'INVITED' ? 'activate' : 'reset', createdBy: actor.userId });
      return { user, link };
    });
    const emailed = await auth.deliverLink({ to: made.user.email, displayName: made.user.displayName, link: made.link });
    return { user: made.user, purpose: made.link.purpose, emailed };
  }

  /** Counts the active admins other than `exceptId`, under a lock so two admins cannot each remove "the other one" at once. */
  async function otherActiveAdmins(db, exceptId) {
    await db.query(`SELECT pg_advisory_xact_lock(hashtext('portal-admins'))`);
    const { rows } = await db.query(
      `SELECT count(*)::int AS n FROM app_user u WHERE u.user_type_code = 'staff' AND u.status_code = 'ACTIVE' AND u.deleted_at IS NULL AND u.user_id <> $1
          AND EXISTS (SELECT 1 FROM user_role r WHERE r.user_id = u.user_id AND r.revoked_at IS NULL AND r.role_code = 'PLATFORM_ADMIN')`, [exceptId]);
    return rows[0].n;
  }

  async function update(id, body, reason, actor) {
    if (typeof id !== 'string' || !UUID.test(id)) throw notFound();
    const hasRole = body.role !== undefined, hasStatus = body.status !== undefined, hasName = body.displayName !== undefined, hasEmail = body.email !== undefined;
    if (!hasRole && !hasStatus && !hasName && !hasEmail) throw refuse('Give a role, a status, a displayName or an email to change.', 'nothing_to_change');
    if (hasRole && (typeof body.role !== 'string' || !ROLE_CODES[body.role])) throw refuse('role must be "user" or "admin".', 'bad_role');
    const status = hasStatus ? String(body.status).toUpperCase() : undefined;
    if (hasStatus && !['ACTIVE', 'DISABLED'].includes(status)) throw refuse('status must be ACTIVE or DISABLED.', 'bad_status');
    const name = hasName ? checkName(body.displayName) : undefined;
    const address = hasEmail ? checkEmail(body.email) : undefined;

    return tx(identityDb, async db => {
      const { rows: [locked] } = await db.query(`SELECT user_id FROM app_user WHERE user_id = $1 AND user_type_code = 'staff' AND deleted_at IS NULL FOR UPDATE`, [id]);
      if (!locked) throw notFound();
      const before = await get(db, id);
      const isSelf = id === actor.userId;
      if (isSelf && ((hasRole && body.role !== before.role) || (hasStatus && status !== before.status) || (hasEmail && address !== before.email))) {
        throw conflict('You cannot change your own role, status or email address. Ask another admin.', 'cannot_change_self');
      }
      const demoting = hasRole && before.role === 'admin' && body.role !== 'admin';
      const disabling = hasStatus && status === 'DISABLED' && before.status === 'ACTIVE' && before.role === 'admin';
      if ((demoting || disabling) && before.status === 'ACTIVE' && (await otherActiveAdmins(db, id)) === 0) {
        throw conflict('That would leave the portal with no active admin.', 'last_admin');
      }
      await withReason(db, reason, actor.userId);
      if (hasName) await db.query('UPDATE app_user SET display_name = $2 WHERE user_id = $1', [id, name]);
      let emailLink = null;
      if (hasEmail && address !== before.email) {
        if ((await db.query('SELECT 1 FROM app_user WHERE email = $1 AND user_id <> $2', [address, id])).rowCount) throw conflict('That address already has an account.', 'user_exists');
        try { await db.query('UPDATE app_user SET email = $2 WHERE user_id = $1', [id, address]); }
        catch (err) { if (err.code === '23505') throw conflict('That address already has an account.', 'user_exists'); throw err; }
        // They signed in as the old address: every session ends, and a link sent to the old address is withdrawn. A person still waiting to activate gets a fresh link at the new one.
        await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'admin' WHERE user_id = $1 AND revoked_at IS NULL`, [id]);
        await db.query(`UPDATE staff_link SET revoked_at = now() WHERE user_id = $1 AND used_at IS NULL AND revoked_at IS NULL`, [id]);
        if (before.status === 'INVITED') emailLink = await auth.issueLink(db, { userId: id, purpose: 'activate', createdBy: actor.userId });
      }
      let activationLink = null;
      if (hasStatus && status !== before.status) {
        // Activating someone who never chose a password puts them back to Pending activation with a fresh link: Active means "can sign in", and they cannot yet.
        const hasPassword = (await db.query('SELECT 1 FROM staff_credential WHERE user_id = $1', [id])).rowCount > 0;
        const target = status === 'ACTIVE' && !hasPassword ? 'INVITED' : status;
        if (target !== before.status) await db.query('UPDATE app_user SET status_code = $2 WHERE user_id = $1', [id, target]);
        if (status === 'DISABLED') {
          await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'user_disabled' WHERE user_id = $1 AND revoked_at IS NULL`, [id]);
          await db.query(`UPDATE staff_link SET revoked_at = now() WHERE user_id = $1 AND used_at IS NULL AND revoked_at IS NULL`, [id]);       // a link sent before cannot be used after
        } else if (target === 'INVITED') activationLink = await auth.issueLink(db, { userId: id, purpose: 'activate', createdBy: actor.userId });
      }
      if (hasRole && body.role !== before.role) {
        await db.query('UPDATE user_role SET revoked_at = now(), revoked_by_user_id = $2 WHERE user_id = $1 AND revoked_at IS NULL AND role_code = ANY($3)', [id, actor.userId, STAFF_ROLE_CODES]);
        await db.query('INSERT INTO user_role (user_role_id, user_id, role_code, granted_by_user_id) VALUES ($1, $2, $3, $4)', [uuidv7(), id, ROLE_CODES[body.role], actor.userId]);
        // A new role is a new grant: sessions from before it stop working (auth.js only trusts a role granted before the session began), so the person signs in again.
        await db.query(`UPDATE session SET revoked_at = now(), revoke_reason = 'admin' WHERE user_id = $1 AND revoked_at IS NULL`, [id]);
      }
      return { before, after: await get(db, id), activationLink: activationLink || emailLink, emailChanged: hasEmail && address !== before.email };
    }).then(async r => {
      if (r.activationLink) r.emailed = await auth.deliverLink({ to: r.after.email, displayName: r.after.displayName, link: r.activationLink });
      delete r.activationLink;
      return r;
    });
  }

  return { list, create, update, sendLink, roleLabel, ROLE_CODES };
}

module.exports = { createUsers, roleLabel, ROLE_CODES };
