'use strict';

/**
 * A CSV file (RFC 4180) that opens safely in a spreadsheet. A cell that starts with = + - @ or a tab or carriage return would be run as a formula by Excel or Sheets, so such text
 * gets a leading apostrophe: what a customer typed can never become a formula. Numbers and dates are written plainly. A byte-order mark is added so Excel reads it as UTF-8.
 */
const FORMULA = /^[=+\-@\t\r]/;

function cell(value) {
  if (value === null || value === undefined) return '';
  if (value instanceof Date) return value.toISOString();
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  let s = typeof value === 'object' ? JSON.stringify(value) : String(value);
  if (FORMULA.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** rows: arrays of values; the first array is the header. */
function toCsv(rows) {
  return `﻿${rows.map(r => r.map(cell).join(',')).join('\r\n')}\r\n`;
}

module.exports = { toCsv, cell };
