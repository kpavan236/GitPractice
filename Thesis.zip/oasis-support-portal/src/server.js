'use strict';
const { loadConfig } = require('./config');
const { createPool } = require('./db');
const { createApp } = require('./app');
const { createFakeNotifier } = require('./notifier');
const { createBillingClient } = require('./billing-client');
const { createShutdown } = require('./shutdown');
const fs = require('node:fs');
const https = require('node:https');

async function main() {
  const config = loadConfig();
  const identityDb = createPool(config.identityDatabaseUrl);
  const customerDb = createPool(config.customerDatabaseUrl);
  const licenseDb = createPool(config.licenseDatabaseUrl);
  const supportDb = createPool(config.supportDatabaseUrl);
  const billing = config.billingServiceUrl ? createBillingClient({ baseUrl: config.billingServiceUrl, serviceKey: config.billingServiceKey, caFile: config.billingCaFile, log: line => console.log(JSON.stringify(line)) }) : null;
  const app = createApp({
    billing, identityDb, customerDb, licenseDb, supportDb, hashPepper: config.hashPepper, licenceHashPepper: config.licenceHashPepper,
    notifier: createFakeNotifier({ print: config.printCodes }), sessionHours: config.sessionHours, portalBaseUrl: config.portalBaseUrl, platformCustomerId: config.platformCustomerId, staffEmailDomains: config.staffEmailDomains, secureCookies: config.secureCookies, tls: config.tls, trustProxy: config.trustProxy,
  });
  const server = config.tls ? https.createServer({ cert: fs.readFileSync(config.tlsCertFile), key: fs.readFileSync(config.tlsKeyFile) }, app) : require('node:http').createServer(app);
  server.listen(config.port, () => console.log(JSON.stringify({ level: 'info', msg: 'listening', port: config.port, tls: config.tls })));
  const stop = createShutdown({ server, pools: [identityDb, customerDb, licenseDb, supportDb], timeoutMs: config.shutdownTimeoutMs });
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch(err => { console.error(JSON.stringify({ level: 'fatal', error: err.message })); process.exit(1); });
