'use strict';
const { uuidv7 } = require('./uuid');

/**
 * The audit trail of what staff did (see db/identity/003_admin_audit.up.sql). A change is recorded BEFORE it is made, so if the audit
 * cannot be written the change does not happen; and again when it ends. If the second write fails, the change has already been made and
 * cannot be taken back, so the failure is logged (without any request content) and the caller still gets its answer.
 */
function createAudit({ identityDb, log }) {
  const write = (row) => identityDb.query(
    `INSERT INTO admin_audit (audit_id, actor_user_id, action, subject_ref, reason, outcome, started_audit_id, detail, request_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
    [row.id, row.actor, row.action, row.subject, row.reason, row.outcome, row.startedId || null, JSON.stringify(row.detail || {}), row.requestId]);

  /** Records a read of personal data. Fails closed: if it cannot be recorded, the read is refused. */
  async function read(req, { action, subject = null, detail = {} }) {
    await write({ id: uuidv7(), actor: req.staff.userId, action, subject, reason: null, outcome: 'read', detail, requestId: req.id });
  }

  /**
   * Runs `work` as an audited change. `work` returns { result, subject?, detail? }: `result` goes back to the caller, the rest goes
   * in the trail. A thrown error is recorded as failed (its code only) and rethrown.
   */
  async function change(req, { action, subject = null, reason, detail = {} }, work) {
    const startedId = uuidv7();
    await write({ id: startedId, actor: req.staff.userId, action, subject, reason, outcome: 'started', detail, requestId: req.id });
    const end = (outcome, extra) => write({ id: uuidv7(), actor: req.staff.userId, action, subject: extra.subject || subject, reason, outcome, startedId, detail: extra.detail || {}, requestId: req.id })
      .catch(err => log({ level: 'error', requestId: req.id, msg: 'audit end row not written', action, error: err.code }));
    let out;
    try { out = await work(); }
    catch (err) { await end('failed', { detail: { error: err.reason || err.code || 'internal', ...(err.extra && err.extra.customerId ? { customerId: err.extra.customerId } : {}) } }); throw err; }
    await end('done', out);
    return out.result;
  }

  return { read, change };
}

module.exports = { createAudit };
