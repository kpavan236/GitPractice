'use strict';

// Input rules for what staff type: an email address and free text. Control characters are removed.

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/;
const MAX_EMAIL = 254;

// Removes control characters; a line break or tab becomes a space.
function stripControl(text) {
  // eslint-disable-next-line no-control-regex
  return String(text).replace(/[\r\n\t\u0085\u2028\u2029]+/g, ' ').replace(/[\u0000-\u001f\u007f]/g, '').replace(/[ ]{2,}/g, ' ').trim();
}

/** The address, trimmed and lower-cased, or null when it is not exactly one email address. */
function normaliseEmail(value) {
  if (typeof value !== 'string') return null;
  const s = value.trim().toLowerCase();
  if (!s || s.length > MAX_EMAIL || /[\s,;<>\u0000-\u001f\u007f\u0085\u2028\u2029\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/.test(s)) return null;
  if ((s.match(/@/g) || []).length !== 1 || !EMAIL.test(s)) return null;
  return s;
}

/** The part after the @, or null. */
function domainOf(value) {
  const email = normaliseEmail(value);
  return email ? email.split('@')[1] : null;
}

module.exports = { normaliseEmail, domainOf, stripControl };
