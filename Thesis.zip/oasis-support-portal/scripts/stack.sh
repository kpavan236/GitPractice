#!/usr/bin/env bash
# Starts the four services the support portal works with, on this machine, for LOCAL DEVELOPMENT:
#   oasis-licence-service  (customer + licence databases)   default port 4020
#   oasis-support-service  (help requests and feedback)     default port 4040
#   oasis-billing-service  (invoices; billing database)         default port 4060
#   oasis-support-portal   (this repo: the staff portal)    default port 4030
#
#   scripts/stack.sh init     one time: create missing databases, write a .env for each service (never overwrites one), make a signing key, run migrations, add a first admin
#   scripts/stack.sh up       start all four in the background and wait until they answer
#   scripts/stack.sh status   what is running
#   scripts/stack.sh logs [portal|licence|support|billing]   follow a log
#   scripts/stack.sh link     show the latest activation / reset link the portal printed (there is no email provider yet)
#   scripts/stack.sh down     stop them
#
# Needs: node >= 22, openssl, uuidgen, and a PostgreSQL 16: either a Docker container (default name oasis-pg, port 5433) or psql on this machine.
#   docker run -d --name oasis-pg -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16
# The databases and passwords this creates are LOCAL ONLY (a throwaway postgres password and random secrets that live in ~/.oasis-local-stack and in each repo's git-ignored .env).
# Never point it at a shared or real database, and never reuse these values anywhere else. It does not drop or change a database that already exists.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="${OASIS_REPOS_DIR:-$(cd "$HERE/.." && pwd)}"
PORTAL_DIR="$HERE"
LICENCE_DIR="${LICENCE_SERVICE_DIR:-$ROOT/oasis-licence-service}"
SUPPORT_DIR="${SUPPORT_SERVICE_DIR:-$ROOT/oasis-support-service}"
BILLING_DIR="${BILLING_SERVICE_DIR:-$ROOT/oasis-billing-service}"
STATE="${STACK_HOME:-$HOME/.oasis-local-stack}"
ENV_FILE="${STACK_ENV_FILE:-.env}"
PG_CONTAINER="${PG_CONTAINER:-oasis-pg}"; PG_USER="${PG_USER:-postgres}"; PG_PASSWORD="${PG_PASSWORD:-local-dev-only}"; PG_HOST="${PG_HOST:-127.0.0.1}"; PG_PORT="${PG_PORT:-5433}"
DB_PREFIX="${STACK_DB_PREFIX:-}"
LICENCE_PORT="${LICENCE_PORT:-4020}"; SUPPORT_PORT="${SUPPORT_PORT:-4040}"; PORTAL_PORT="${PORTAL_PORT:-4030}"; BILLING_PORT="${BILLING_PORT:-4060}"
ADMIN_EMAIL="${STACK_ADMIN_EMAIL:-admin@staff.example.test}"
DBS=("${DB_PREFIX}identity_db" "${DB_PREFIX}customer_db" "${DB_PREFIX}license_db" "${DB_PREFIX}support_db" "${DB_PREFIX}billing_db")

say() { printf '%s\n' "$*"; }
die() { printf 'Error: %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "$1 is required but was not found."; }
url() { printf 'postgres://%s:%s@%s:%s/%s' "$PG_USER" "$PG_PASSWORD" "$PG_HOST" "$PG_PORT" "$1"; }

psql_admin() {   # runs SQL against the maintenance database; prints bare values
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$PG_CONTAINER"; then docker exec -i "$PG_CONTAINER" psql -U "$PG_USER" -d postgres -tA -v ON_ERROR_STOP=1 -c "$1"
  elif command -v psql >/dev/null 2>&1; then PGPASSWORD="$PG_PASSWORD" psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d postgres -tA -v ON_ERROR_STOP=1 -c "$1"
  else die "No PostgreSQL found: start the container ('docker run -d --name $PG_CONTAINER -p $PG_PORT:5432 -e POSTGRES_PASSWORD=$PG_PASSWORD postgres:16') or install psql."; fi
}

port_in_use() { lsof -nP -iTCP:"$1" -sTCP:LISTEN >/dev/null 2>&1; }
pid_file() { printf '%s/%s.pid' "$STATE" "$1"; }
running() { local f; f="$(pid_file "$1")"; [[ -f "$f" ]] && kill -0 "$(cat "$f")" 2>/dev/null; }
env_value() { { grep -E "^$2=" "$1/$ENV_FILE" 2>/dev/null || true; } | head -1 | cut -d= -f2-; }

write_env() {   # write_env <dir> <content>: never overwrites
  if [[ -f "$1/$ENV_FILE" ]]; then say "  keeping the existing $1/$ENV_FILE"; else umask 077; printf '%s\n' "$2" > "$1/$ENV_FILE"; say "  wrote $1/$ENV_FILE"; fi
}

ensure_env() {   # ensure_env <dir> <NAME> <value>: appends NAME=value only if the file has no NAME line; never changes an existing value
  [[ -f "$1/$ENV_FILE" ]] || return 0
  grep -qE "^$2=" "$1/$ENV_FILE" || { printf '%s=%s\n' "$2" "$3" >> "$1/$ENV_FILE"; say "  added $2 to $1/$ENV_FILE"; }
}

cmd_init() {
  need node; need openssl; need uuidgen
  [[ -d "$LICENCE_DIR" && -d "$SUPPORT_DIR" && -d "$BILLING_DIR" ]] || die "Expected the sibling repos at $LICENCE_DIR, $SUPPORT_DIR and $BILLING_DIR (set OASIS_REPOS_DIR, LICENCE_SERVICE_DIR, SUPPORT_SERVICE_DIR or BILLING_SERVICE_DIR)."
  mkdir -p "$STATE/logs"; chmod 700 "$STATE"
  say "Databases (created only if missing; none is dropped or changed):"
  for d in "${DBS[@]}"; do
    if [[ -n "$(psql_admin "SELECT 1 FROM pg_database WHERE datname = '$d'")" ]]; then say "  $d exists"; else psql_admin "CREATE DATABASE \"$d\"" >/dev/null; say "  $d created"; fi
  done
  local pepper_l pepper_s pepper_p customer
  pepper_l="$(env_value "$LICENCE_DIR" HASH_PEPPER)"; pepper_l="${pepper_l:-$(openssl rand -hex 32)}"
  pepper_s="$(env_value "$SUPPORT_DIR" HASH_PEPPER)"; pepper_s="${pepper_s:-$(openssl rand -hex 32)}"
  pepper_p="$(env_value "$PORTAL_DIR" HASH_PEPPER)"; pepper_p="${pepper_p:-$(openssl rand -hex 32)}"
  local pepper_b key_b
  pepper_b="$(env_value "$BILLING_DIR" BILLING_HASH_PEPPER)"; pepper_b="${pepper_b:-$(openssl rand -hex 32)}"
  key_b="$(env_value "$BILLING_DIR" BILLING_SERVICE_KEY)"; key_b="${key_b:-$(openssl rand -hex 32)}"
  customer="$(env_value "$PORTAL_DIR" PLATFORM_CUSTOMER_ID)"; customer="${customer:-$(uuidgen | tr 'A-Z' 'a-z')}"
  [[ -f "$STATE/licence-signing.pem" ]] || { openssl genpkey -algorithm ed25519 -out "$STATE/licence-signing.pem" 2>/dev/null; chmod 600 "$STATE/licence-signing.pem"; say "  made a local signing key in $STATE"; }
  say "Settings (git-ignored $ENV_FILE files):"
  write_env "$LICENCE_DIR" "PORT=$LICENCE_PORT
CUSTOMER_DATABASE_URL=$(url "${DB_PREFIX}customer_db")
LICENSE_DATABASE_URL=$(url "${DB_PREFIX}license_db")
LICENCE_SIGNING_KEY_FILE=$STATE/licence-signing.pem
LICENCE_SIGNING_KID=local
HASH_PEPPER=$pepper_l
TRUST_PROXY=0
NOTIFIER=fake
DEV_PRINT_CODES=1"
  write_env "$SUPPORT_DIR" "PORT=$SUPPORT_PORT
SUPPORT_DATABASE_URL=$(url "${DB_PREFIX}support_db")
HASH_PEPPER=$pepper_s
TRUST_PROXY=0
NOTIFIER=fake
DEV_PRINT_NOTICES=1"
  write_env "$BILLING_DIR" "PORT=$BILLING_PORT
BILLING_DATABASE_URL=$(url "${DB_PREFIX}billing_db")
BILLING_SERVICE_KEY=$key_b
BILLING_HASH_PEPPER=$pepper_b
BILLING_CURRENCY=INR
SHARE_LINK_DEFAULT_DAYS=14
PUBLIC_BASE_URL=http://127.0.0.1:$BILLING_PORT
NOTIFIER=fake"
  write_env "$PORTAL_DIR" "PORT=$PORTAL_PORT
IDENTITY_DATABASE_URL=$(url "${DB_PREFIX}identity_db")
CUSTOMER_DATABASE_URL=$(url "${DB_PREFIX}customer_db")
LICENSE_DATABASE_URL=$(url "${DB_PREFIX}license_db")
SUPPORT_DATABASE_URL=$(url "${DB_PREFIX}support_db")
HASH_PEPPER=$pepper_p
LICENCE_HASH_PEPPER=$(env_value "$LICENCE_DIR" HASH_PEPPER)
PLATFORM_CUSTOMER_ID=$customer
PORTAL_BASE_URL=http://127.0.0.1:$PORTAL_PORT
COOKIE_SECURE=false
TRUST_PROXY=0
NOTIFIER=fake
DEV_PRINT_CODES=1"
  ensure_env "$PORTAL_DIR" BILLING_SERVICE_URL "http://127.0.0.1:$BILLING_PORT"
  ensure_env "$PORTAL_DIR" BILLING_SERVICE_KEY "$(env_value "$BILLING_DIR" BILLING_SERVICE_KEY)"
  say "Migrations (each applies only what is new):"
  (cd "$LICENCE_DIR" && node --env-file="$ENV_FILE" src/migrate.js)
  (cd "$SUPPORT_DIR" && node --env-file="$ENV_FILE" src/migrate.js)
  (cd "$BILLING_DIR" && node --env-file="$ENV_FILE" src/migrate.js)
  (cd "$PORTAL_DIR" && node --env-file="$ENV_FILE" src/migrate.js)
  say "First admin:"
  if (cd "$PORTAL_DIR" && node --env-file="$ENV_FILE" src/staff-cli.js --email "$ADMIN_EMAIL" --name "Local Admin" --role PLATFORM_ADMIN --customer "$(env_value "$PORTAL_DIR" PLATFORM_CUSTOMER_ID)" 2>&1 | sed 's/^/  /'); then :; fi
  say ""
  say "Done. Next: scripts/stack.sh up   then open http://127.0.0.1:$PORTAL_PORT/ and choose 'Forgot or set your password' for $ADMIN_EMAIL;"
  say "the activation link is printed in the portal log: scripts/stack.sh link"
}

start_one() {   # start_one <name> <dir> <port>
  local name="$1" dir="$2" port="$3"
  if running "$name"; then say "  $name is already running (pid $(cat "$(pid_file "$name")"))"; return; fi
  [[ -f "$dir/$ENV_FILE" ]] || die "$dir/$ENV_FILE is missing. Run: scripts/stack.sh init"
  port_in_use "$port" && die "Port $port is already in use (is the demo or another copy running?). Stop it or set ${name^^}_PORT."
  mkdir -p "$STATE/logs"
  # exec makes the background process node itself (so $! is node's pid), and its output and input are detached from this terminal or pipe
  (cd "$dir" && exec nohup node --env-file="$ENV_FILE" src/server.js) >> "$STATE/logs/$name.log" 2>&1 < /dev/null &
  echo $! > "$(pid_file "$name")"
  say "  starting $name on port $port (pid $(cat "$(pid_file "$name")"))"
}

wait_for() {   # wait_for <name> <port>
  for _ in $(seq 1 40); do
    curl -fs "http://127.0.0.1:$2/healthz" >/dev/null 2>&1 && { say "  $1 is up: http://127.0.0.1:$2/"; return 0; }
    running "$1" || { say "  $1 stopped. Last lines of its log:"; tail -n 8 "$STATE/logs/$1.log" | sed 's/^/    /'; return 1; }
    sleep 0.5
  done
  say "  $1 did not answer in 20 seconds; see $STATE/logs/$1.log"; return 1
}

cmd_up() {
  need node; need curl
  mkdir -p "$STATE"
  start_one licence "$LICENCE_DIR" "$LICENCE_PORT"; start_one support "$SUPPORT_DIR" "$SUPPORT_PORT"; start_one billing "$BILLING_DIR" "$BILLING_PORT"; start_one portal "$PORTAL_DIR" "$PORTAL_PORT"
  local bad=0
  wait_for licence "$LICENCE_PORT" || bad=1; wait_for support "$SUPPORT_PORT" || bad=1; wait_for billing "$BILLING_PORT" || bad=1; wait_for portal "$PORTAL_PORT" || bad=1
  [[ $bad -eq 0 ]] || { say "Something did not start. Stop the rest with: scripts/stack.sh down"; exit 1; }
  say ""
  say "Portal:  http://127.0.0.1:$PORTAL_PORT/   (sign in as $ADMIN_EMAIL; set the password with 'Forgot or set your password', then: scripts/stack.sh link)"
  say "Logs:    $STATE/logs   Stop: scripts/stack.sh down"
}

cmd_down() {
  for n in portal billing support licence; do
    if running "$n"; then kill "$(cat "$(pid_file "$n")")" 2>/dev/null || true; say "  stopped $n"; else say "  $n was not running"; fi
    rm -f "$(pid_file "$n")"
  done
}

cmd_status() {
  for pair in "licence:$LICENCE_PORT" "support:$SUPPORT_PORT" "billing:$BILLING_PORT" "portal:$PORTAL_PORT"; do
    n="${pair%%:*}"; p="${pair##*:}"
    if running "$n"; then if curl -fs "http://127.0.0.1:$p/healthz" >/dev/null 2>&1; then say "  $n: running, answering on http://127.0.0.1:$p/ (pid $(cat "$(pid_file "$n")"))"; else say "  $n: running but not answering yet"; fi
    else say "  $n: not running"; fi
  done
}

cmd_logs() { local n="${1:-portal}"; [[ "$n" =~ ^(portal|licence|support|billing)$ ]] || die "Use: logs portal|licence|support|billing"; tail -n 40 -f "$STATE/logs/$n.log"; }

cmd_link() {
  local f="$STATE/logs/portal.log"; [[ -f "$f" ]] || die "No portal log yet. Run: scripts/stack.sh up"
  local l; l="$(grep -E 'link for ' "$f" | tail -n 1 || true)"
  [[ -n "$l" ]] && say "$l" || say "No link has been printed yet. On the sign-in page choose 'Forgot or set your password' for $ADMIN_EMAIL, then run this again."
}

case "${1:-}" in
  init) cmd_init ;; up|start) cmd_up ;; down|stop) cmd_down ;; status) cmd_status ;; logs) shift; cmd_logs "${1:-portal}" ;; link) cmd_link ;;
  *) sed -n '2,16p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
