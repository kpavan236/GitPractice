'use strict';
// Starts the portal on THROWAWAY databases filled with SYNTHETIC data, so the team can click through it without touching anything real.
//
//   node scripts/demo.js            (needs the local PostgreSQL from test/helpers/db.js, and the sibling repos' schemas)
//
// Sign in as ada@staff.example.test (admin) or sam@staff.example.test (user). Every demo account has the password Demo-password-2026. Activation and reset links are printed in this terminal (there is no email provider yet). Everything is deleted when you press Ctrl+C. Nothing here is real: every name and address is invented (example.test).
const path = require('node:path');
const crypto = require('node:crypto');
const { createTestDatabases, LICENCE_SERVICE_DIR, SUPPORT_SERVICE_DIR } = require('../test/helpers/db');
const { createApp } = require('../src/app');
const { createFakeNotifier } = require('../src/notifier');
const { uuidv7 } = require('../src/uuid');
const { createHasher } = require('../src/secrets');
const { issueLicence } = require('../src/issue-licence');
const { hashPassword } = require('../src/password');
const { createBillingClient } = require('../src/billing-client');
const { startBillingService } = require('../test/helpers/billing-service');

const PORT = Number(process.env.DEMO_PORT || 4030);
const PEPPER = 'demo-pepper-demo-pepper-demo-pepper-0123';
const LICENCE_PEPPER = 'demo-licence-pepper-demo-licence-pepper-1';
const PLATFORM = uuidv7();
const DEMO_PASSWORD = 'Demo-password-2026';   // DEMO ONLY: every demo account has it. The real server never has a known password.

let dbs;
(async () => {
  dbs = await createTestDatabases();
  // Invoices: the REAL billing service (from its own repository) on a throwaway database, if that repository is next to this one. Without it the demo simply has no Invoices section.
  let billingService = null, billing = null;
  try { billingService = await startBillingService(); billing = createBillingClient({ baseUrl: billingService.url, serviceKey: billingService.key }); }
  catch (err) { console.log(`  (no billing demo: ${err.message.split('\n')[0]})`); }
  const notifier = createFakeNotifier({ print: true, out: line => console.log(`  ${line}`) });
  const app = createApp({ ...dbs, hashPepper: PEPPER, licenceHashPepper: LICENCE_PEPPER, platformCustomerId: PLATFORM, billing, secureCookies: false, portalBaseUrl: `http://127.0.0.1:${PORT}`, notifier, log: () => {} });

  // Staff
  const staff = {};
  for (const [key, email, name, role] of [['ada', 'ada@staff.example.test', 'Ada Admin', 'PLATFORM_ADMIN'], ['sam', 'sam@staff.example.test', 'Sam User', 'SUPPORT'], ['lee', 'lee@staff.example.test', 'Lee User', 'SUPPORT']]) {
    const id = uuidv7(); staff[key] = id;
    await dbs.identityDb.query(`INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code) VALUES ($1, $2, 'staff', $3, $4, 'ACTIVE')`, [id, PLATFORM, email, name]);
    await dbs.identityDb.query('INSERT INTO user_role (user_role_id, user_id, role_code) VALUES ($1, $2, $3)', [uuidv7(), id, role]);
    await dbs.identityDb.query('INSERT INTO staff_credential (user_id, password_hash) VALUES ($1, $2)', [id, await hashPassword(createHasher(PEPPER), DEMO_PASSWORD)]);
  }

  // Licence requests from the Buy form, in different states
  const request = async (organization, employees, contact, email, status, assignedTo, note) => {
    const { rows: [r] } = await dbs.customerDb.query(
      `INSERT INTO purchase_request (purchase_request_id, organization_name, employee_count, contact_name, email, created_at) VALUES ($1, $2, $3, $4, $5, now() - interval '1 hour' * $6) RETURNING reference, purchase_request_id`,
      [uuidv7(), organization, employees, contact, email, Math.floor(Math.random() * 120) + 2]);
    for (const to of { NEW: [], CONTACTED: ['CONTACTED'], AGREED: ['CONTACTED', 'AGREED'], DECLINED: ['DECLINED'] }[status]) {
      await dbs.customerDb.query(`WITH r AS (SELECT set_config('app.reason', $2, true)) UPDATE purchase_request SET status_code = $3 FROM r WHERE reference = $1`, [r.reference, to === 'CONTACTED' ? 'Called the contact' : to === 'AGREED' ? 'Agreed 25 seats' : 'Not going ahead', to]);
    }
    if (assignedTo || note) await dbs.customerDb.query('UPDATE purchase_request SET assigned_to_user_id = $2, support_notes = $3 WHERE reference = $1', [r.reference, assignedTo || null, note || null]);
    return r.reference;
  };
  await request('Maple Grove Academy', 120, 'Priya Raman', 'priya@maplegrove.example.test', 'NEW');
  await request('Riverside Learning Trust', 540, 'Tom Becker', 'tom@riverside.example.test', 'NEW');
  await request('Oak Hill Schools', 60, 'Dana Ortiz', 'dana@oakhill.example.test', 'CONTACTED', staff.sam, '2026-10-08 Sam User: Left a voicemail, will try again tomorrow');
  await request('Brightwater Partnership', 900, 'Marcus Lee', 'marcus@brightwater.example.test', 'AGREED', staff.lee, '2026-10-09 Lee User: Agreed 40 seats for a year');
  await request('Cedar Park District', 15, 'Hana Kim', 'hana@cedarpark.example.test', 'DECLINED');

  // A customer with a live licence, a suspended one, and one about to end
  const hash = createHasher(LICENCE_PEPPER);
  const customer = async (name, domain) => {
    const id = uuidv7();
    await dbs.customerDb.query(`INSERT INTO customer (customer_id, name, slug, status_code) VALUES ($1, $2, $3, 'ACTIVE')`, [id, name, `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${crypto.randomBytes(2).toString('hex')}`]);
    if (domain) await dbs.customerDb.query(`INSERT INTO customer_domain (domain_id, customer_id, domain, verification_token_hash, verified_at) VALUES ($1, $2, $3, $4, now())`, [uuidv7(), id, domain, crypto.randomBytes(32).toString('hex')]);
    return id;
  };
  const licence = async (customerId, plan, seats, days) => {
    const plans = (await dbs.licenseDb.query('SELECT plan_code, default_grace_days, offline_allowed FROM plan WHERE plan_code = $1', [plan])).rows[0];
    const c = await dbs.licenseDb.connect();
    try { await c.query('BEGIN'); const out = await issueLicence(c, hash, { customerId, plan: plans, kind: plan === 'enterprise' ? 'enterprise' : 'paid', seats, termDays: days, reason: 'Demo data', actorUserId: staff.ada }); await c.query('COMMIT'); return out; }
    catch (e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
  };
  const harbour = await customer('Harbour View School District', 'harbourview.example.test');
  const l1 = await licence(harbour, 'team', 25, 365);
  const pine = await customer('Pine Ridge Academy', 'pineridge.example.test');
  const l2 = await licence(pine, 'viewer-security', 10, 25);
  const lake = await customer('Lakeside Charter Network', 'lakeside.example.test');
  const l3 = await licence(lake, 'enterprise', null, 365);
  const move = (id, to, reason) => dbs.licenseDb.query(`WITH r AS (SELECT set_config('app.reason', $3, true)) UPDATE license SET status_code = $2 FROM r WHERE license_id = $1`, [id, to, reason]);
  await move(l1.licenseId, 'ACTIVE', 'First activation'); await move(l2.licenseId, 'ACTIVE', 'First activation'); await move(l2.licenseId, 'SUSPENDED', 'Invoice 4411 unpaid');

  if (billing) {
    const as = (userId, role) => ({ userId, role });
    const ada = as(staff.ada, 'admin'), sam = as(staff.sam, 'user'), lee = as(staff.lee, 'user');
    const day = n => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
    const bill = (name, city) => ({ name, line1: '1 Example Road', city, countryCode: 'IN' });
    const make = async (actor, customerId, name, lines, dueOn) => (await billing.createInvoice(actor, { customerId, billTo: bill(name, 'Pune'), lines, dueOn })).body.invoice.invoiceId;
    const seat = (n, unit) => [{ description: `Licence, ${n} seats, 12 months`, quantity: n, unitPriceMinor: unit }];
    const issue = async (actor, id, dueOn) => { await billing.issue(actor, id, { dueOn }); return id; };
    const back = async (id, issuedAgo, dueAgo) => { const c = await billingService.db.connect(); try { await c.query('SET session_replication_role = replica'); await c.query('UPDATE invoice SET issued_on = CURRENT_DATE - $2::int, due_on = CURRENT_DATE - $3::int WHERE invoice_id = $1', [id, issuedAgo, dueAgo]); } finally { await c.query('SET session_replication_role = DEFAULT'); c.release(); } };

    const paid = await issue(sam, await make(sam, harbour, 'Harbour View School District', seat(25, 36000), day(20)), day(20));
    await back(paid, 20, -10); await billing.recordPayment(sam, paid, { amountMinor: 900000, method: 'bank_transfer', reference: 'DEMO-0001' });
    const sent = await issue(sam, await make(sam, harbour, 'Harbour View School District', [...seat(10, 36000), { description: 'Early-payment discount', quantity: 1, unitPriceMinor: -20000 }], day(10)), day(10));
    await billing.markSent(sam, sent, { channel: 'email', note: 'Sent to the finance office' });
    const part = await issue(lee, await make(lee, pine, 'Pine Ridge Academy', seat(10, 30000), day(30)), day(30));
    await back(part, 40, 12); await billing.recordPayment(lee, part, { amountMinor: 100000, method: 'cheque', reference: 'DEMO-0002' });
    const never = await issue(lee, await make(lee, pine, 'Pine Ridge Academy', seat(4, 30000), day(30)), day(30)); await back(never, 60, 50);
    const lapsed = await issue(sam, await make(sam, lake, 'Lakeside Charter Network', seat(60, 28000), day(30)), day(30)); await back(lapsed, 90, 75);
    await billingService.db.query(`INSERT INTO follow_up (follow_up_id, invoice_id, by_user_id, channel, outcome, next_follow_up_on) VALUES (gen_random_uuid(), $1, $2, 'call', 'Promised to pay by the end of the month', CURRENT_DATE - 4)`, [lapsed, staff.sam]);     // a follow-up whose planned date has passed
    await make(ada, lake, 'Lakeside Charter Network', seat(20, 28000), day(30));                       // a draft
    await issue(lee, await make(lee, harbour, 'Harbour View School District', seat(5, 36000), day(25)), day(25));
    const voided = await issue(sam, await make(sam, pine, 'Pine Ridge Academy', seat(2, 30000), day(20)), day(20)); await billing.voidInvoice(ada, voided, { reason: 'Raised to the wrong district' });
    const reopened = await issue(lee, await make(lee, lake, 'Lakeside Charter Network', seat(8, 28000), day(15)), day(15));
    const pay = (await billing.recordPayment(lee, reopened, { amountMinor: 224000, method: 'po', reference: 'DEMO-0003' })).body.payment;
    await billing.voidPayment(ada, reopened, pay.paymentId, { reason: 'The purchase order was withdrawn' });
  }
  // The customers' own people (invented names, example.test addresses): some active, some invited and never signed in, one customer silent for months
  const person = (customerId, domain, name, status, daysAgoFirst, daysAgoLast, createdDaysAgo) => dbs.identityDb.query(
    `INSERT INTO app_user (user_id, customer_id, user_type_code, email, display_name, status_code, first_login_at, last_login_at, created_at)
     VALUES ($1, $2, 'customer', $3, $4, $5, now() - make_interval(days => $6), now() - make_interval(days => $7), now() - make_interval(days => $8))`,
    [uuidv7(), customerId, `${name.split(' ')[0].toLowerCase()}.${name.split(' ')[1].toLowerCase()}@${domain}`, name, status, daysAgoFirst, daysAgoLast, createdDaysAgo]);
  const people = [
    [harbour, 'harbourview.example.test', [['Nia Patel', 'ACTIVE', 40, 1, 50], ['Marcus Lee', 'ACTIVE', 30, 0, 42], ['Priya Shah', 'ACTIVE', 20, 3, 35], ['Tom Becker', 'ACTIVE', 12, 6, 20], ['Ana Souza', 'ACTIVE', 5, 2, 14], ['Dev Rao', 'ACTIVE', 3, 1, 9], ['Lena Fischer', 'INVITED', null, null, 6], ['Sam Ortiz', 'INVITED', null, null, 2], ['Ivy Chen', 'ACTIVE', 1, 0, 4]]],
    [pine, 'pineridge.example.test', [['Omar Haddad', 'ACTIVE', 25, 2, 30], ['Kim Novak', 'ACTIVE', 18, 9, 25], ['Raj Mehta', 'DISABLED', 40, 15, 45]]],
    [lake, 'lakeside.example.test', [['Elena Rossi', 'ACTIVE', 200, 95, 210], ['Hugo Martin', 'ACTIVE', 190, 80, 205], ['Zoe Adams', 'INVITED', null, null, 120]]],
  ];
  for (const [cid, domain, list] of people) for (const [name, status, first, last, created] of list) await person(cid, domain, name, status, first ?? 0, last ?? 0, created).then(() => (first === null ? dbs.identityDb.query(`UPDATE app_user SET first_login_at = NULL, last_login_at = NULL WHERE email = $1`, [`${name.split(' ')[0].toLowerCase()}.${name.split(' ')[1].toLowerCase()}@${domain}`]) : null));

  // Help requests and feedback, made the way the app makes them: through the support service itself
  const supportApp = require(path.join(SUPPORT_SERVICE_DIR, 'src', 'app')).createApp({ db: dbs.supportDb, hashPepper: 'demo-support-pepper-demo-support-pepper-1', supportMailbox: null, limiter: (_q, _s, n) => n(), log: () => {} });
  const supportServer = await new Promise(r => { const s = supportApp.listen(0, '127.0.0.1', () => r(s)); });
  const post = (route, body) => fetch(`http://127.0.0.1:${supportServer.address().port}${route}`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': crypto.randomUUID() }, body: JSON.stringify(body) });
  await post('/v1/support-request', { subject: 'Cannot connect to Jenkins', message: 'The Setup tab says the token is rejected, but it worked yesterday.\n\nWe rotated our Jenkins tokens last week.', contactName: 'Nia Patel', email: 'nia@harbourview.example.test', appVersion: '2.0.1' });
  await post('/v1/support-request', { subject: 'How do we add more seats?', message: 'We have hired three more people.', contactName: 'Omar Haddad', email: 'omar@pineridge.example.test', appVersion: '2.0.1' });
  await post('/v1/feedback', { category: 'idea', message: 'Group the dependency graph by team.', rating: 4, screen: 'repos', appVersion: '2.0.1' });
  await post('/v1/feedback', { category: 'bug', message: 'The security tab freezes on repos with more than 500 dependencies.', rating: 2, screen: 'security', email: 'dev@harbourview.example.test', appVersion: '2.0.1' });
  await post('/v1/feedback', { category: 'praise', message: 'Version Watch saved us a day of work.', rating: 5, screen: 'version-watch' });
  supportServer.close();

  // Two trials, one flagged
  for (const [days, flag] of [[2, true], [5, false]]) {
    const inst = uuidv7(), t = uuidv7();
    await dbs.licenseDb.query(`INSERT INTO installation (installation_id, fingerprint, fingerprint_source_code, platform, arch, app_version) VALUES ($1, $2, 'darwin', 'darwin', 'arm64', '2.0.1')`, [inst, crypto.randomBytes(16).toString('hex')]);
    await dbs.licenseDb.query(`INSERT INTO trial (trial_id, installation_id, started_at, expires_at) VALUES ($1, $2, now() - interval '5 days', now() + make_interval(days => $3))`, [t, inst, days]);
    await dbs.licenseDb.query(`INSERT INTO trial_integration (trial_id, github_org, github_url) VALUES ($1, $2, 'https://github.example.test')`, [t, flag ? 'sunrise-schools' : 'meadow-district']);
    if (flag) await dbs.licenseDb.query(`INSERT INTO trial_review_flag (trial_id, flag_code) VALUES ($1, 'weak_fingerprint')`, [t]);
  }

  const server = app.listen(PORT, '127.0.0.1', () => {
    console.log(`\nOASIS Support Portal (demo, synthetic data) at http://127.0.0.1:${PORT}/`);
    console.log('  Admin: ada@staff.example.test   User: sam@staff.example.test   User: lee@staff.example.test');
    console.log(`  Password for all three: ${DEMO_PASSWORD}`);
    console.log('  Activation and password-reset links are printed here (there is no email provider yet): add a team member, or use "Forgot or set your password", then open the link shown. Ctrl+C to stop and delete everything.\n');
  });
  const stop = async () => { server.close(); if (billingService) await billingService.close().catch(() => {}); await dbs.drop().catch(() => {}); process.exit(0); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
})().catch(async err => { console.error(err); if (dbs) await dbs.drop().catch(() => {}); process.exit(1); });
