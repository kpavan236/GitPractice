'use strict';
// Regenerates db/setup/01_identity_schema_and_seed.sql from db/identity/*.sql so the one-file setup cannot drift from the migrations.
//
//   node scripts/build-db-setup.js           writes the file
//   node scripts/build-db-setup.js --check   exits 1 if the file on disk differs from what would be generated
//
// The migrations are concatenated verbatim, in file-name order (*.down.sql skipped), each under a comment naming its source file. The
// generated file ends by recording every migration in schema_migration with the same sha256 checksum src/migrate.js computes, so
// `npm run migrate` afterwards sees them as applied and does nothing.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.join(__dirname, '..');
const SOURCE_DIR = path.join(ROOT, 'db', 'identity');
const OUTPUT = path.join(ROOT, 'db', 'setup', '01_identity_schema_and_seed.sql');

function build(sourceDir = SOURCE_DIR) {
  const files = fs.readdirSync(sourceDir).filter(f => /^\d+_.*\.sql$/.test(f) && !f.endsWith('.down.sql')).sort();   // same filter and order as src/migrate.js
  const parts = [`-- GENERATED FILE: do not edit. Rebuild with \`npm run db:setup:build\` (scripts/build-db-setup.js) from db/identity/*.sql.
--
-- Complete setup of the IDENTITY database (identity_db), the one database this repo owns: every table, index, trigger and function,
-- plus the reference data (roles, permissions and the like). Run it ONCE, on an EMPTY database, after 00_create_databases_and_roles.sql:
--
--   psql "postgres://APP_USER:PASSWORD@HOST:5432/identity_db" -v ON_ERROR_STOP=1 -f db/setup/01_identity_schema_and_seed.sql
--
-- Contains: ${files.join(', ')}.
-- The last statement records each file in schema_migration with its sha256 checksum, exactly as src/migrate.js does, so a later
-- \`npm run migrate\` treats them as already applied. If you edit a migration after running this file, migrate stops with an error
-- (an applied file must not change); add a new migration instead and rebuild this file.
-- Psql meta-command used: \\set ON_ERROR_STOP (stop at the first error).

\\set ON_ERROR_STOP on

CREATE TABLE IF NOT EXISTS schema_migration (filename text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now());
`];
  const rows = [];
  for (const file of files) {
    const sql = fs.readFileSync(path.join(sourceDir, file), 'utf8');
    rows.push(`  ('${file}', '${crypto.createHash('sha256').update(sql).digest('hex')}')`);
    parts.push(`\n-- ============================================================================\n-- Source: db/identity/${file}\n-- ============================================================================\n\n${sql.replace(/\s+$/, '')}\n`);
  }
  parts.push(`\n-- ============================================================================
-- Migration bookkeeping (same filename and sha256 checksum that src/migrate.js records)
-- ============================================================================

INSERT INTO schema_migration (filename, checksum) VALUES
${rows.join(',\n')};
`);
  return parts.join('');
}

module.exports = { build, OUTPUT };

if (require.main === module) {
  const sql = build();
  if (process.argv.includes('--check')) {
    const current = fs.existsSync(OUTPUT) ? fs.readFileSync(OUTPUT, 'utf8') : null;
    if (current !== sql) { console.error('db/setup/01_identity_schema_and_seed.sql is out of date. Run: npm run db:setup:build'); process.exit(1); }
    console.log('db/setup/01_identity_schema_and_seed.sql is up to date.');
  } else {
    fs.mkdirSync(path.dirname(OUTPUT), { recursive: true });
    fs.writeFileSync(OUTPUT, sql);
    console.log(`Wrote ${path.relative(ROOT, OUTPUT)}`);
  }
}
