# oasis-support-portal

## Overview

The support portal for the i-Ready OASIS app: the web screens and the API behind them that the support team uses to work customer requests
and licences. Staff only; the OASIS app never calls it. The rest of this file describes how the team works with it, then how the code is built.

## Tech stack

Node.js (CommonJS, no build step), Express 4, `pg` (node-postgres) and PostgreSQL 16. The screens are plain HTML, CSS and JavaScript modules in
`public/`. Tests use the built-in `node:test` runner against real PostgreSQL. Runtime dependencies are only `express` and `pg`.

## Prerequisites

- Node.js 22 or later (`engines` in `package.json`).
- PostgreSQL 16 (the tests and demo use `docker run -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16`).
- The sibling repositories checked out next to this one: `../oasis-licence-service` (owns the customer and licence databases, `db/customer` and `db/license`) and
  `../oasis-support-service` (owns the support database, `db/support`) and `../oasis-billing-service` (owns the billing database, port 4060). The tests and the demo read their schemas from there; override with
  `LICENCE_SERVICE_DIR`, `SUPPORT_SERVICE_DIR` and `BILLING_SERVICE_DIR`.

## Quick start

Demo (throwaway databases, synthetic data, nothing real):

```bash
npm install
npm run demo        # open http://127.0.0.1:4030/ ; Ctrl+C deletes everything
```

Real setup:

```bash
npm install
# 1. Create the databases and the identity schema: see db/setup/README.md (or run `npm run migrate` against an existing, empty identity_db).
# 2. Set up the customer, licence and support databases with their own repos.
cp .env.example .env                       # fill it in; never commit .env
npm run create-staff -- --email you@your-company-domain --name "Your Name" --role PLATFORM_ADMIN --customer <PLATFORM_CUSTOMER_ID>
npm run start:local                        # reads .env; `npm start` expects the variables already in the environment
```

The new person sets a password with "Forgot or set your password" on the sign-in page. Until an email provider is approved the link is not delivered:
with `DEV_PRINT_CODES=1` (development only) it is printed in the server's terminal.

### Run the whole stack locally

The portal needs four services (licence, support, billing and itself) and five databases. `scripts/stack.sh` (also `npm run stack -- <command>`) sets that up for **local development** with a PostgreSQL 16 (a Docker container, default name `oasis-pg` on port 5433, or `psql` on your machine) and the three sibling repos `oasis-licence-service`, `oasis-support-service` and `oasis-billing-service` next to this one:

```bash
docker run -d --name oasis-pg -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16     # once, if you have no local PostgreSQL
npm run stack -- init     # once: create the databases if missing, write a git-ignored .env for each service, make a local signing key, run migrations, add a first admin
npm run stack -- up       # start all four in the background and wait until each answers (licence 4020, support 4040, portal 4030, billing 4060)
npm run stack -- link     # show the activation/reset link the portal printed (no email provider yet)
npm run stack -- status   # what is running;   logs [portal|licence|support|billing] follows a log;   down stops everything
```

After `up`, open http://127.0.0.1:4030/, choose **Forgot or set your password** for `admin@staff.example.test`, then run `npm run stack -- link` and open the link to choose a password.

What it will and will not do: it never overwrites an existing `.env`, never drops or changes a database that already exists, and keeps its logs, process ids and the signing key in `~/.oasis-local-stack` (not in any repo). Everything it creates is local only: a throwaway database password and random secrets. **Do not point it at a shared or real database or reuse its values anywhere else.** It refuses to start if a port is taken (for example while `npm run demo` is running on 4030). Settings you can change with environment variables: `PG_CONTAINER`, `PG_HOST`, `PG_PORT`, `PG_USER`, `PG_PASSWORD`, `STACK_DB_PREFIX`, `LICENCE_PORT`, `SUPPORT_PORT`, `PORTAL_PORT`, `STACK_ADMIN_EMAIL`, `STACK_HOME`, `OASIS_REPOS_DIR`. Each service can also be started on its own with `npm run start:local` after you have a `.env` for it.

## Configuration

Set in `.env` (see `.env.example`; every value there is a placeholder) or the environment. `src/config.js` checks them at start-up and stops with a clear message.

| Variable | Required | Default | Meaning |
|---|---|---|---|
| `PORT` | no | `4030` | Port to listen on (1 to 65535). |
| `IDENTITY_DATABASE_URL` | yes | | Identity database (owned by this repo). Also used by `npm run migrate` and `npm run create-staff`. |
| `CUSTOMER_DATABASE_URL` | yes | | Customer database (owned by oasis-licence-service). |
| `LICENSE_DATABASE_URL` | yes | | Licence database (owned by oasis-licence-service). |
| `SUPPORT_DATABASE_URL` | yes | | Support database: feedback and support requests (owned by oasis-support-service). |
| `HASH_PEPPER` | yes | | At least 32 random characters. Keyed hashing of passwords, session tokens, links and network addresses. Keep it in a secret store. |
| `LICENCE_HASH_PEPPER` | yes | | At least 32 characters; must equal the licence service's `HASH_PEPPER` or issued keys are not recognised there. |
| `PORTAL_BASE_URL` | production | `http://127.0.0.1:<PORT>` | Address staff open the portal at (https in production); used in activation and reset links. No query, fragment or login. |
| `SESSION_HOURS` | no | `8` | Session length in hours (1 to 24). |
| `TRUST_PROXY` | production | `0` | Number of proxies in front of the service (0 to 10). |
| `NOTIFIER` | no | `fake` | Only `fake` is accepted until an email provider is approved (IT Helpdesk, cainc.service-now.com). Production refuses it. |
| `DEV_PRINT_CODES` | no | `0` | `1` prints each activation/reset link to the terminal. Development only. |
| `PLATFORM_CUSTOMER_ID` | yes | | uuid of the customer-database row that stands for the platform itself; every staff user belongs to it. |
| `STAFF_EMAIL_DOMAINS` | production | empty (any) | Comma-separated domains staff addresses must be on, for example `cainc.com`. |
| `RETENTION_SESSIONS_DAYS` | no | `30` | `npm run retention`: how long ended sessions are kept. `never` or `0` keeps them for ever; otherwise at least 7. |
| `RETENTION_LINKS_DAYS` | no | `30` | The same for used, withdrawn or expired activation/reset links (at least 7). |
| `RETENTION_LOGIN_EVENTS_DAYS` | no | `400` | The same for the sign-in history (at least 90). |
| `RETENTION_NOTIFICATIONS_DAYS` | no | `90` | The same for the bell's notifications (at least 7). |
| `RETENTION_REPLIES_DAYS` | no | `730` | The same for the record of replies sent to customers (at least 30). It holds what staff wrote. |
| `RETENTION_AUDIT_DAYS` | no | `2555` (7 years) | The same for the audit trail (at least 365). The company's records policy decides this number. |
| `TLS_CERT_FILE` | production* | | Path to the certificate file (PEM). Set together with `TLS_KEY_FILE`: the service then serves https itself. Only one of the two stops start-up. |
| `TLS_KEY_FILE` | production* | | Path to the private key file (PEM). See `TLS_CERT_FILE`. |
| `ALLOW_PLAIN_HTTP` | no | | `1` lets production start without TLS files, for a hosting platform that ends TLS itself before traffic reaches the service. Without it, production with no TLS files stops at start-up. |
| `SHUTDOWN_TIMEOUT_MS` | no | `10000` | How long SIGTERM/SIGINT waits for requests in flight (100 to 300000) before the service exits anyway. |
| `COOKIE_SECURE` | no | `true` | `false` only for local development on http://localhost; refused in production. |

\* Production needs the two TLS files, or `ALLOW_PLAIN_HTTP=1`. The Strict-Transport-Security header is sent whenever TLS is on; the session cookie is Secure unless `COOKIE_SECURE=false` (never allowed in production).

On SIGTERM or SIGINT the service stops accepting connections, closes idle ones, lets requests in flight finish (up to `SHUTDOWN_TIMEOUT_MS`), ends the database pools and exits; after the timeout it exits with code 1.

`NODE_ENV=production` turns on the production checks. The test and demo settings (`TEST_PG_ADMIN_URL`, `LICENCE_SERVICE_DIR`, `SUPPORT_SERVICE_DIR`, `BILLING_SERVICE_DIR`, `DEMO_PORT`) are described under Test.

## Project structure

```
src/        server code: server.js (start), app.js (Express app), config.js, auth.js, users.js, admin.js, lifecycle.js,
            overview.js, support-messages.js, audit.js, password.js, secrets.js, rate-limit.js, notifier.js (fake email sender),
            issue-licence.js, migrate.js, staff-cli.js, db.js, routes/
public/     the browser screens: index.html, css/, js/ (no framework, no build step)
db/identity the identity database migrations (001 to 011)
db/setup    one-file SQL setup for a new server (see db/setup/README.md)
scripts/    demo.js (throwaway demo), build-db-setup.js (regenerates db/setup/01_...sql)
test/       node:test suites; test/helpers has the database, server and sibling-service helpers
docs/       fakes.md: integrations faked until IT approves them
```

## Scripts

| Command | Does |
|---|---|
| `npm run stack -- <init\|up\|down\|status\|logs\|link>` | One command for the whole local stack (licence service, support service and this portal). See "Run the whole stack locally" below. |
| `npm start` | `node src/server.js` (settings from the environment). |
| `npm run start:local` | The same, loading `.env` with `node --env-file=.env`. |
| `npm run migrate` | Applies `db/identity/*.sql` once each to `IDENTITY_DATABASE_URL`, recording a checksum; stops if an applied file changed. |
| `npm run create-staff -- --email <address> --name <name> --role SUPPORT\|PLATFORM_ADMIN --customer <uuid>` | Adds an Active staff member (needs `IDENTITY_DATABASE_URL`). They set a password through the sign-in page. |
| `npm test` | Runs `test/**/*.test.js` with `node --test`. |
| `npm run demo` | Starts the portal on throwaway databases with synthetic data. |
| `npm run retention` | Dry run: shows how many records are past their retention period. `npm run retention -- --apply` deletes them. Run it on a schedule. See "Retention" below. |
| `npm run db:setup:build` | Regenerates `db/setup/01_identity_schema_and_seed.sql` from `db/identity`. |

## Database setup

`db/setup/` holds SQL to create the four databases and a login role (`00`), the whole identity schema and reference data in one file (`01`, generated), and optional
synthetic development data (`02`). How to run, verify and reset: `db/setup/README.md`. This repo owns only the identity database.

## Troubleshooting

- **"X is required" / "must be at least 32 characters" at start-up**: a setting in `.env` is missing or too short; see Configuration. `npm start` does not read `.env`; use `npm run start:local`.
- **Tests or the demo say they cannot reach PostgreSQL**: start the container above, or set `TEST_PG_ADMIN_URL`.
- **"The tests need the licence service's schemas at ..."** (or the support or billing service's): check out the sibling repo next to this one, or set `LICENCE_SERVICE_DIR` / `SUPPORT_SERVICE_DIR` / `BILLING_SERVICE_DIR`.
- **`migrate` says a file "was applied and has since changed"**: never edit an applied migration; add a new one.
- **Every change from the browser is refused**: a proxy is rewriting the `Host` header (see Known limits), or `COOKIE_SECURE=true` is used over plain http locally.
- **Production refuses to start**: it needs `STAFF_EMAIL_DOMAINS`, `TRUST_PROXY`, `PORTAL_BASE_URL` (https) and an approved email sender; the fake sender is not allowed (see `docs/fakes.md`).
- **Cannot sign in as a new member**: they must use the emailed link; with the fake sender, run with `DEV_PRINT_CODES=1` and read the link in the terminal.

---

## What it is for

Where the OASIS support team works. A customer asks to buy OASIS (the Buy form in the app) or asks for help; the team sees it here, calls the customer, agrees the details, and creates
the licence; the customer can then use the app. It is a web portal (screens for the team) with the API behind it.

The OASIS app never calls this service. The app talks to `oasis-licence-service` and `oasis-support-service`; this one is for staff.

## The work, start to finish

1. **A customer asks.** In the app they use *Buy a licence* (a **licence request**) or *Contact support* (a **help request**), or send *Feedback*.
2. **The team sees it.** The dashboard shows what is new, what is unassigned, what is yours and how long the oldest has waited. An admin can assign each request to a person and track who has what.
3. **Call the customer.** Open the request: organisation, size, contact and email. The Buy form collects an email address, not a phone number, so ask for one when you write. Write what was said as a **note**, and
   mark the request *Contacted*, then *Agreed* (or *Declined* / *Duplicate*). Every change asks for a reason and is on the record with your name.
4. **Create the licence.** On an agreed request, *Create licence*: choose the plan, seats and length. The licence key is shown **once**. Then attach the customer's email domain.
5. **The customer uses the app.** They choose *Activate licence*, enter their work email address, and enter the 6-digit code we email them.
   (Until an email provider is approved the codes are not delivered: see "Faked until IT approves it".)
6. **After that.** Renew, give extra days, suspend, cancel or revoke a licence, extend a trial, block the machines of a revoked licence, all from the portal.

## Sign in and roles

A team member signs in with their work email address and a password they chose themselves. An admin adds them and they get an **activation link** by email (valid 3 days): they open it, choose a password and type it again to confirm, and the account becomes active. A forgotten password is replaced the same way, with a **reset link** (valid 1 hour) that the person asks for on the sign-in page ("Forgot or set your password") or an admin sends from the Team screen. Two roles:

| | **User** | **Admin** |
|---|---|---|
| See licence requests, help requests, feedback, customers, licences, trials | yes | yes |
| Call the customer, add notes, mark status, create licences, attach domains, renew, give extra days, extend trials | yes (**any** request) | yes |
| Create the biggest licences: **enterprise**, **unlimited seats**, or a term **over 730 days** | no | yes |
| **Assign** requests to people and see each person's work | no | yes |
| Add, disable or re-role team members | no | yes |
| Suspend, reinstate, cancel or revoke a licence; block or unblock machines | no | yes |
| **Change a licence's seats or plan**, or **release one seat** (`LICENSE_MODIFY`) | no | yes |
| **Edit a customer's details** (`CUSTOMER_MANAGE`); add a note on a customer (any staff who can update customers) | notes only | yes |
| **Disable, enable, re-invite or remove a customer's own user** (`CUSTOMER_USER_MANAGE`) | no | yes |
| **Edit a team member's name or email address** (with the rest of team management) | no | yes |
| **Download CSV** of the reports, customer users and audit log | no | yes |
| **Reply to a customer** from a request; see the **bell** and the **Workload** page | yes | yes |
| Read the audit log | no | yes |
| **Reports** (totals across all customers and each person's workload) and **Customer users** (each customer's accounts, sign-ins and seats) | no | yes |

The portal calls them user and admin; the identity database keeps the codes `SUPPORT` and `PLATFORM_ADMIN`. What each role may do is **data** (`role_permission`, migrations 006 and 007), so it can change without a deploy.
An admin adds people on the **Team** screen: work email address, name, role. Each person is **Pending activation** (added, not yet activated), **Active**, or **Deactivated**. A pending person cannot sign in until they open their link; a deactivated person cannot sign in until an admin activates them again (activating someone who never chose a password puts them back to Pending with a fresh link). An admin can resend an activation link, send a reset link, and activate or deactivate at any time, each with a reason on the record. Nobody, admins included, ever sees a link or a password. Two safeguards keep the team from locking itself out: **nobody can change their own role or status**,
and **the last active admin can never be demoted or disabled** (even if two admins try to remove each other at the same moment). Changing a role or disabling someone ends their sessions at once.

## The screens

Dashboard, Licence requests, Help requests, Feedback, **Workload**, Licences, Customers, Trials, and (admins) Reports, Customer users, Blocked machines, Team, Audit log. They are plain HTML, CSS and JavaScript modules in `public/`: **no framework, no build step,
no third-party code** and nothing loaded from another site. It works with the keyboard and a screen reader (landmarks, labelled fields, a focus move on each page, native dialogs), in light and dark, and on a phone.

## Invoices (billing)

The Invoices section is the portal's side of `oasis-billing-service` (sibling repo; port 4060). The portal never touches the billing database: it calls the service with a service key and says who is acting and as what. It is optional: with `BILLING_SERVICE_URL` and `BILLING_SERVICE_KEY` unset the screens show "Billing is not set up" and every invoice route answers `503 billing_not_configured`.

| Setting | Meaning |
|---|---|
| `BILLING_SERVICE_URL` | Where the billing service is (https in production, no path) |
| `BILLING_SERVICE_KEY` | Must equal the billing service's key (32+ characters, from a secret store, never committed) |
| `BILLING_CA_FILE` | Optional: the certificate authority for a private certificate |

Screens: **Invoices** (list, create from a licence request or by hand, edit a draft, the invoice page with issue, mark sent, secure link, record payment, follow-up, void, credit note, change owner), **Follow-ups** (overdue and due, grouped by owner; the bell counts your own due follow-ups) and, for admins, **Billing** (status tiles, outstanding, overdue, collected, aging, by owner, by customer, follow-up health, CSV). Every figure opens the invoices behind it.

Permissions are data in the identity database: `INVOICE_READ`, `INVOICE_WRITE` (users and admins) and `INVOICE_ADMIN` (admins: void, credit notes, owner change, the Billing screen). The billing service enforces the same split itself.

What is audited: every change (the invoice id, the reason, ids and enumerations) and every look at invoice data. Never an amount, a customer name, a note, a follow-up's text or a secure-link address. A secure link is shown once when it is made and cannot be shown again.

Operator notes:

- An invoice from a licence request needs the customer to exist (create the licence from the request first).
- The customer's secure-link page is served by the billing service itself, so its `PUBLIC_BASE_URL` must be an address customers can reach (https in production).
- Business dates (due, overdue) use the billing database's time zone. Set it to the business's zone, for example `ALTER DATABASE billing_db SET timezone TO 'Asia/Kolkata'`, or "overdue" can flip at the wrong hour.
- `npm run stack -- up` also starts the billing service on 4060.
- Voiding a payment is admin-only and cancelling a draft is open to any user; both are rows in the billing service's `action_role`. Voiding a payment adds a reversing row and the original shows as voided.
- Customer-facing wording needs CA employee review before real customers see it. The billing service cannot start in production yet (only the fake notifier exists).
- No retention period is set for invoice data and nothing is scheduled.
- This code was written with AI assistance and goes through the standard review, CI/CD and SAST/DAST gates before release.

Run `npm run demo` to click through synthetic invoices (needs the billing repo next to this one).

## How the browser is kept safe

- **The session is an HttpOnly, SameSite=Strict, Secure cookie.** The page's JavaScript cannot read it, and nothing is kept in browser storage.
- **Every change must prove it came from the portal page:** an `X-CSRF-Token` (derived from the session, given to the page at sign-in) and, when the browser says where a request came from, a matching `Origin`.
  A bearer token (for scripts and tests) needs neither.
- **A strict content policy:** only the portal's own scripts and styles run; nothing is loaded from elsewhere; the page cannot be framed; it can only talk to itself. There is **no inline script or style**, so it is never loosened.
- **What a customer wrote is only ever text.** The code never builds markup from data (no `innerHTML`): a test fails the build if any module uses it, or `eval`, or browser storage.
- Sign-in is limited hard (asking for and checking a code); loading the portal is not, so a team behind one office address is not locked out.

## Run it and try it

(Setup steps are summarised in Quick start above.)

```bash
npm install
npm run demo       # starts the portal on throwaway databases with SYNTHETIC data; Ctrl+C deletes it all
```

Open the address it prints (http://127.0.0.1:4030/). Sign in as `ada@staff.example.test` (admin) or `sam@staff.example.test` (user), with the password **Demo-password-2026** (the demo's accounts all use it). Activation and reset links are **printed in the terminal** where the demo runs, because no email
provider is connected: add a team member (or use "Forgot or set your password") and open the link it prints. (The demo password exists only in the demo and tests: the real server never has one, and the app refuses to start with a cheaper password hash in production.) It needs the local PostgreSQL the tests use (`docker run -p 5433:5432 -e POSTGRES_PASSWORD=local-dev-only postgres:16`) and the sibling repos' schemas.

### Demo accounts (for testing only)

`npm run demo` creates these three accounts on throwaway databases. The addresses use the reserved `example.test` domain, nothing is emailed to them, and everything is deleted when you press Ctrl+C. The password is shared and public **on purpose**: it exists only in the demo and in tests. **Never reuse it, and never create an account with it anywhere real.**

| Who | Email | Password | Role | What to try |
|---|---|---|---|---|
| Ada Admin | `ada@staff.example.test` | `Demo-password-2026` | Admin | Everything: Team, Reports, Customer users, Audit log, change seats or plan, edit customers, CSV downloads |
| Sam User | `sam@staff.example.test` | `Demo-password-2026` | User | Work requests, create licences, add notes, reply, Workload; no admin screens |
| Lee User | `lee@staff.example.test` | `Demo-password-2026` | User | A second user: use it to check that assigned requests appear in the bell |

More ways to test:
- **A new team member:** sign in as Ada, add someone on the Team screen (any address on `example.test`), then open the **activation link printed in the terminal** that runs the demo. Choose a password and type it again to confirm.
- **Forgot password:** on the sign-in page choose *Forgot or set your password*, enter one of the addresses above, and open the **reset link printed in the terminal**.
- **Customers in the demo:** Harbour View School District, Pine Ridge Academy and Lakeside Charter Network, with invented people on `harbourview.example.test`, `pineridge.example.test` and `lakeside.example.test`.
- **Wrong password:** five wrong passwords in a row pause that account for 15 minutes. Restart the demo to clear it.
- **Automated tests** create their own accounts (`staff-<id>@staff.example.test`) with their own throwaway password, so you do not need any of the above to run `npm test`.

For real (production-shaped) use: `cp .env.example .env`, fill it in, `npm run migrate`, `npm run create-staff -- ...` for the first admin, `npm start` (or `npm run start:local`, which reads `.env` for you). Settings: see `.env.example`.
In production the service refuses to start without `STAFF_EMAIL_DOMAINS`, `TRUST_PROXY` and an approved email sender, and the session cookie is always Secure (https only).

## Admin and staff tools

- **Licence seats and plan** (admin). On a licence: *Change seats or plan* and a *Seats in use* list with *Release*. Seats cannot go below the seats in use (release some first); unlimited is only for an enterprise licence. A new plan closes the features the old plan included and adds the new plan's; a feature someone set by hand is left alone. A cancelled or ended licence cannot be changed. A released seat has the reason `support` (migration 006 in oasis-licence-service); the list shows platform and app version, never a machine id. Each change is audited with the old and new values.
- **Customers** (admin edits, any staff add notes). *Edit details* changes name, legal name, website, industry, size, country and time zone (the lists come from the customer database); the customer's *status* is not changed here. **Notes** are append-only and kept in the identity database (`customer_note`). The audit trail says which fields changed or that a note was added, never the text.
- **Customer users** (admin). On a customer's page: *Disable* (they cannot sign in to the app, sessions end), *Enable*, *Re-invite* (back to "waiting to activate" so they can activate again from the app; the portal sends no email) and *Remove* (account closed and hidden; the address stays reserved; history is kept).
- **Team** (admin). *Edit* a member's name and email address. A changed address signs them out, withdraws links sent to the old address, and sends a pending member a fresh activation link at the new one. Nobody can change their own address.
- **CSV** (admin). *Download CSV* on Reports, Customer users and the Audit log (the audit export honours the filters, up to 50,000 rows). Text that starts with `=`, `+`, `-` or `@` is neutralised so it cannot run as a spreadsheet formula. Every download is itself on the audit record.
- **The bell** (everyone). A badge in the top bar counts requests **assigned to you** (an admin assigning a request to you adds one notification; assigning to yourself adds none) plus licence and help requests that **arrived since you last looked**. *Mark all as read* restarts that count. It checks every minute.
- **Replying to a customer** (everyone who can update requests). *Reply from the portal* on a licence request or a help request. The message goes to the address **on the request** (a caller cannot name another), the subject is cleaned of line breaks, and a copy is kept with the request (`customer_reply`) showing who wrote it and what happened: *Sent*, *Not sent* (the email failed), or *Recorded, not delivered* (**no email provider is connected yet**, which is the case until IT approves one). The screen says which, so nobody believes a customer was written to when they were not.
- **Workload** (everyone). One row per active team member plus "Not assigned": open licence and help requests, the oldest wait, and what they finished in the last 7 days. A row opens that person's open requests (references, status and age only).

### Retention

`npm run retention` deletes records past their period (dry run by default; `--apply` deletes). Defaults: ended sessions 30 days, used/expired links 30 days, sign-in history 400 days, notifications 90 days, replies 730 days, audit trail 2555 days (7 years); each is a setting (`RETENTION_*`, see Configuration) and `never` keeps a kind for ever. A typo cannot wipe the trail: each setting has a minimum. Not covered, on purpose: customer notes, status histories and request notes (they are business records). The audit trail, sign-in history, activity events and reply record are append-only **except** for this job: it tells the database so (`app.retention = 'on'`) inside its own transaction, and nothing else in the portal does (migration 012). **The periods are a starting point; the company's records policy must decide them, and the job must be scheduled (for example once a day) with `IDENTITY_DATABASE_URL` set.**

**Scheduling it (operator notes; the periods are pending the records policy).** No schedule is installed and no period has been chosen: until the company's records policy decides, keep the defaults or `never`, and look at the dry run first (`npm run retention`, which deletes nothing). When the policy is set, an operator runs `npm run retention -- --apply` once a day with `IDENTITY_DATABASE_URL` set, for example with cron (`17 3 * * * cd /srv/oasis-support-portal && npm run retention -- --apply`) or a systemd timer (`OnCalendar=daily`) that starts a oneshot service running the same command with an `EnvironmentFile=` holding the settings.

## The API (all under `/v1/admin`)

| Route | Needs | Does |
|---|---|---|
| `POST /auth/login` `{email, password, cookie?}` | none | Email address and password. With `cookie: true` (the browser) the session goes in an HttpOnly cookie and the answer carries a CSRF token; without it (scripts) the answer carries the bearer token. 8 hours. Every failure (unknown address, no password yet, wrong password, deactivated, paused) is the same `bad_credentials` answer. |
| `GET /auth/me`, `POST /auth/logout` | a session | Who am I and what may I do; end the session. |
| `GET /dashboard` | `CUSTOMER_READ` | Counts: what is new, unassigned, mine, waiting, about to lapse. |
| `GET /plans` | `LICENSE_READ` | Plans on sale with their defaults and what they include (for the create-licence form). |
| `GET /customers?q=`, `GET /customers/{id}` | `CUSTOMER_READ` | Find a customer by name or email domain; one customer with its domains, licences and linked requests. |
| `GET /licenses/{id}` | `LICENSE_READ` | One licence in full: terms, features, seats, blocks and history. Never the key (only its last four characters). |
| `GET /purchase-requests/{reference}` | `CUSTOMER_READ` | One licence request in full with its history, notes and licences. Audited. |
| `GET /users`, `POST /users`, `PATCH /users/{id}` | `USER_MANAGE` (admin) | The team: list, add (`email`, `displayName`, `role` = `user` or `admin`), change role, disable or enable. |
| `GET /reports?weeks=` | `REPORT_READ` (admin) | Totals for the Reports screen: weekly series, status counts, plans, trial outcomes, feedback and each person's open work. Counts only. Audited (`report.view`). |
| `GET /customer-users?weeks=` | `REPORT_READ` (admin) | One row per customer: users by status, signed in in 30 days, never signed in, seats used and bought, last sign-in, and flags (no users, dormant, seats almost full). Counts only. Audited. |
| `GET /customer-users/{customerId}` | `REPORT_READ` (admin) | One customer's people (name, work address, status, sign-ins), licences with seats and domains. **Personal data:** every read is audited. |
| `POST /auth/login`, `POST /auth/password/forgot`, `POST /auth/link/check`, `POST /auth/link/complete`, `POST /auth/password/change` | none (change: a session) | Sign in with email and password; ask for an activation or reset link; look up what a link is for; use a link to set a password (typed twice: `newPassword`, `confirmPassword`); change your own password. Every failure looks the same for any address. |
| `POST /users/{id}/send-link` `{reason}` | `USER_MANAGE` (admin) | Emails an activation link (to a Pending member) or a reset link (to an Active one). Never returns the link. Audited. |
| `POST /licenses/{id}/change` `{reason, seats?, plan?}` | `LICENSE_MODIFY` (admin) | Changes seats (`null` = unlimited, enterprise only) and/or plan. Refused below the seats in use. |
| `POST /licenses/{id}/seats/{seatId}/release` `{reason}` | `LICENSE_MODIFY` (admin) | Frees one seat (reason `support`). |
| `GET /customer-options` | `CUSTOMER_READ` | The industry, size and country lists for the edit form. |
| `PATCH /customers/{id}` `{reason, name?, legalName?, website?, industry?, sizeBand?, country?, timezone?}` | `CUSTOMER_MANAGE` (admin) | Corrects a customer's details. Never the status. |
| `POST /customers/{id}/notes` `{body}` | `CUSTOMER_UPDATE` | Adds an append-only note (up to 4000 characters). |
| `POST /customer-users/{customerId}/users/{userId}/{disable\|enable\|reinvite\|remove}` `{reason}` | `CUSTOMER_USER_MANAGE` (admin) | Manages a customer's own user. Audited with ids, never an address. |
| `PATCH /users/{id}` `{reason, displayName?, email?, role?, status?}` | `USER_MANAGE` (admin) | Also changes a team member's email address (not your own). |
| `GET /reports.csv`, `GET /customer-users.csv` (`?weeks=`), `GET /audit.csv` (same filters as `/audit`) | `REPORT_READ` / `AUDIT_READ` (admin) | CSV downloads. Audited. |
| `POST /purchase-requests/{reference}/reply`, `POST /support-requests/{reference}/reply` `{subject?, body}` | `CUSTOMER_UPDATE` / `SUPPORT_REQUEST_UPDATE` | Replies to the address on the request; recorded. The request detail now carries `replies`. |
| `GET /notifications`, `POST /notifications/read` | a session | The bell: unread notifications and new-request counts; mark all read. |
| `GET /workload`, `GET /workload/{userId\|none}` | `CUSTOMER_READ` | Per-person counts; one person's open requests. |
| `GET /audit?actor=&action=&subject=&outcome=&since=` | `AUDIT_READ` (admin) | The audit log. Reading it is itself recorded. |
| `GET /auth/config` | none | Whether sign-in emails really go out (the sign-in page says so when they do not). |
| `GET /purchase-requests?status=&assignedTo=&limit=&offset=` | `CUSTOMER_READ` | The support list. Open requests first, oldest first. `status` is one or more codes (`NEW,CONTACTED`); `assignedTo` is `me`, `none` or a user id. |
| `PATCH /purchase-requests/{reference}` `{reason, status?, assignedTo?, note?}` | `CUSTOMER_UPDATE` | Move the status (`CONTACTED`, `AGREED`, `DECLINED`, `DUPLICATE`), assign, or add a note. **A reason is always required.** |
| `POST /licenses` `{reason, purchaseRequest? \| customerId? \| customer:{name}, plan, kind?, seats?, termDays?, startsAt?}` | `LICENSE_ACTIVATE` | After agreement: creates the customer (if new), links the request, issues the licence with its term and features. Returns the licence key **once**. |
| `POST /domains` `{reason, customerId, domain}` | `DOMAIN_ATTACH` (PLATFORM_ADMIN only by default) | Attaches a verified email domain to a customer. Refuses public mailbox domains, internet providers and public suffixes. |
| `GET /licenses?customerId=&status=&limit=&offset=` | `LICENSE_READ` | Find a licence: customer, plan, status, dates, seats in use, last 4 characters of the key. Never the key. |
| `POST /licenses/{id}/suspend`, `/reinstate` `{reason}` | `LICENSE_SUSPEND` (PLATFORM_ADMIN only by default) | ACTIVE to SUSPENDED and back. The licence service refuses a suspended licence at the app's next check; seats are kept. Repeating is harmless. |
| `POST /licenses/{id}/cancel` `{reason, confirm}` | `LICENSE_SUSPEND` | Ends the licence for good (an agreed end: the customer left, a refund, no renewal). The app is told "revoked" at its next check. |
| `POST /licenses/{id}/revoke` `{reason, confirm}` | `LICENSE_SUSPEND` | The same, for cause (abuse, a leaked key), and **frees every seat at once** (reason `revoked`). |
| `POST /licenses/{id}/block-machines` `{reason, confirm}` | `BLOCK_MANAGE` (PLATFORM_ADMIN only by default) | After a cancel or revoke: blocks every machine that held a seat on the licence. They are refused on **every** call in the licence service, a new trial included. Staff never see a machine id. |
| `POST /licenses/{id}/unblock-machines` `{reason}` | `BLOCK_MANAGE` | Lifts every block made for that licence. |
| `POST /blocks/{id}/lift` `{reason}` | `BLOCK_MANAGE` | Lifts one block. |
| `GET /blocks?licenseId=&reason=&state=&limit=&offset=` | `LICENSE_READ` | The block list (`state` is `active` by default, `lifted` or `all`). Shows why, when, by whom and for which licence; never what was blocked. |
| `GET /support-requests?status=&assignedTo=&limit=&offset=` | `SUPPORT_REQUEST_READ` | The list of "contact support" messages: who, about what, status, owner, linked customer. **Never the message.** Open first, oldest first. Audited. |
| `GET /support-requests/{reference}` | `SUPPORT_REQUEST_READ` | One request in full: what the person wrote, its notes and every status it has had, with names. Audited with the reference (it is where the free text is read). |
| `PATCH /support-requests/{reference}` `{reason, status?, assignedTo?, customerRef?}` | `SUPPORT_REQUEST_UPDATE` | Assign, move the status (`NEW`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`), or link a customer. A reason is always required. What the person submitted can never be edited. |
| `POST /support-requests/{reference}/notes` `{body}` | `SUPPORT_REQUEST_UPDATE` | Add a note (append-only; there is no edit or delete). |
| `GET /feedback?category=&rating=&withEmail=&limit=&offset=` | `FEEDBACK_READ` | Feedback sent from the app, newest first, with what was said. Audited. |
| `POST /licenses/{id}/renew` `{reason, termDays?, reference?}` | `LICENSE_ACTIVATE` | Adds a paid term (1 to 3650 days, default the plan's) starting where the last one ends, or now if it has ended. `reference` is a PO or invoice number. |
| `POST /licenses/{id}/extend` `{reason, days}` | `LICENSE_UPDATE` | Adds a goodwill term "entered by hand" (1 to 90 days) from the current end. |
| `GET /trials?status=&flagged=&limit=&offset=` | `LICENSE_READ` | Find a trial: dates, platform, the customer's GitHub organisation and addresses, open review flags. **Never the machine id.** Reading it is audited. |
| `POST /trials/{id}/extend` `{reason, days}` | `LICENSE_UPDATE` | 1 to 30 more days from the later of its end and now. Brings an ended trial back to ACTIVE. A trial that became a licence cannot be extended. |

The permission names in the right-hand column are the ones the screens check. Who may do what is **data**: permissions come from the identity database's `role_permission` table, so changing a role needs no deploy.
Staff roles are `SUPPORT` and `PLATFORM_ADMIN`.

## What it owns, and what it does not

- **Owns** the identity database (`db/identity`: users, roles, codes, sessions, sign-in history, and `admin_audit`).
- **Reads and answers** the support service's database (feedback and support requests), which belongs to `oasis-support-service`; its schema is read from that repository in the tests (`SUPPORT_SERVICE_DIR`, default `../oasis-support-service`).
- **Writes to** the customer and licence databases, which belong to `oasis-licence-service` (it creates and migrates them). Their schemas
  are not copied here: the tests read them from the licence service's repository (`LICENCE_SERVICE_DIR`, default `../oasis-licence-service`).
- The plan's rule is "a service never reads another's database"; this service breaks it on purpose, because the support routes are the
  licence data's second writer and an internal API in front of them would only move the same code. Revisit before production.

## Test

```bash
npm test
```

Real PostgreSQL, four throwaway databases per file (identity, customer, licence, support) (`TEST_PG_ADMIN_URL`, default `postgres://postgres:local-dev-only@localhost:5433/postgres`).
`test/licences.test.js` runs the licence service's own code against the same databases: a key or domain created here must work there.
`test/db-setup.test.js` checks `db/setup/01_identity_schema_and_seed.sql` is up to date with `db/identity` (fix with `npm run db:setup:build`). The demo's port is `DEMO_PORT` (default 4030).

## Rules this code keeps

- **Every change needs a reason and is audited before it is made.** `admin_audit` gets a `started` row first (if that cannot be written the
  change does not happen), then `done` or `failed`. A `started` row with no end means the service stopped midway: look at it. Reading the
  purchase-request list is recorded too, because it is personal data. The trail holds ids and codes, never a licence key, a code or a token.
- **Nobody learns who is staff.** Asking for a code always answers the same (even if the email cannot be sent), and every failed verification is one `bad_code` answer with no "tries left".
- **Sessions stop at once** when a staff member is disabled or loses their role (checked on every request), and an old session does not come back if they are re-enabled or re-granted; logout revokes.
- Codes (5 tries, 10 minutes, 3 per 15 minutes) and session tokens are stored only as keyed hashes. Codes go to the sender only.
- 4xx for refusals, 5xx for faults. Logs hold method, path, status, time and a request id: never a body, address, code, token or network address.
- Personal data: staff emails and names (identity), the Buy form's contact name and email (customer). Synthetic data only in tests (`example.test`).

## Decisions I made

1. **Direct database access** (see above), not an internal API.
2. **Sessions are opaque tokens, not JWTs**, so they can be revoked. They use the identity schema's `session` table: `refresh_token_hash` holds the hash of the bearer token; there is no refresh or rotation. A session is 8 hours, then sign in again. The browser portal holds that token in an HttpOnly cookie (see "How the browser is kept safe"); scripts may still use it as a bearer token.
3. **Creating a licence is two steps in two databases** (customer, then licence) and cannot be one transaction. Everything checkable is checked first; if the licence step fails the customer exists and the request is linked, so repeat the call with that `customerId`. A customer without a licence grants nothing. There is no `Idempotency-Key`: clicking twice makes two licences.
4. **One request makes one licence.** A repeat or double click gets 409 `request_linked` naming the customer; a further licence for that customer, or a retry after a failed one, uses `customerId` with no `purchaseRequest`. A licence is only created for an `AGREED` request (or for an existing customer, or a new one by name with no request).
5. **A domain is recorded as verified when someone with `DOMAIN_ATTACH` attaches it**, with who and why in the audit trail. **Users have this permission** (migration 007), because the app activates by work email and a customer cannot use OASIS until their domain is attached, and creating the licence is the user's job. Public mailbox domains, internet providers and public suffixes are refused. The list cannot be complete: ownership still has to be checked with the customer. To take it back from users: `DELETE FROM role_permission WHERE role_code = 'SUPPORT' AND permission_code = 'DOMAIN_ATTACH';`
6. **Notes are appended** with the date and who wrote them, so nobody's note is overwritten and a pasted line break cannot forge another person's note.
8. **Users can work any request** (your decision), so assignment is about ownership and tracking, not access. Only admins assign.
9. **The audit log is admin-only** (the identity design gave it to support; migration 007 takes it away).
10. **Plain HTML and JavaScript modules, served by the portal itself** (your decision): the same style as the OASIS app's own UI, almost nothing third-party to review, and same-origin so the session can be an HttpOnly cookie with no CORS opened up.
11. **The portal says "licence requests", "help requests" and "feedback"** to its users, not "purchase requests" and "support requests". The API and the databases keep their technical names.
13. **A user cannot mint a huge licence alone** (review finding): an enterprise licence, unlimited seats or a term over two years needs the `LICENSE_UNLIMITED` permission, admin-only by default (migration 008). Attaching a domain asks the person to **type how they checked** it: the reason is never pre-filled, so the record says what was actually done.
14. **Passwords** (migration 010): kept only as salted scrypt hashes, run through the server's secret first (`HASH_PEPPER`), so a copy of the database alone cannot be used to guess them. At least 12 characters, at most 128, no blocklist-style complexity rules; very common passwords and ones containing the person's email name are refused. A wrong address, a member with no password yet and a wrong password give the same answer and take the same time. Five wrong passwords pause the account for 15 minutes (counted per person, safe against simultaneous guesses). Setting a password from a link, or changing it, ends the person's other sessions. Sign-in, link requests, link use and change are all rate limited.
15. **Activation and reset links** (migration 011): each carries 256 bits of randomness, kept in the database only as a keyed hash (a copy of the database cannot open one). It is **single use**, **time limited** (3 days to activate, 1 hour to reset), **replaced** when a newer one is sent (one open link per person per purpose), and **bound to its purpose and to the account's state**: an activation link works only for a Pending account and a reset link only for an Active one; deactivating someone withdraws their links. The secret sits in the address's `#fragment` (`/#/activate/<secret>`), so it never reaches a server log or a `Referer`, and the page removes it from the address bar at once. A weak password or two that differ is refused *before* the link is used, so the person can try again. Asking for a link looks the same for any address, takes the same time, and is limited to 3 per person per 15 minutes.
12. **A new team member needs no password from us**: an admin adds their work address and the person activates the account themselves from an emailed link (so link delivery must work before anyone can sign in). Addresses must be on `STAFF_EMAIL_DOMAINS`.
7. **Licence-key issuing is copied** from `oasis-licence-service/src/issue-licence.js` (about 40 lines). Two copies is a known cost; the conformance test catches drift. A shared package is the better home once there are three consumers.

## Licences and trials: how renew, extend, suspend, cancel and block work

- A licence's dates live **only** in its terms, and terms are never edited. Renewing and extending both **add** a term. A renewal is a purchase
  (`source = renewal`, with the PO reference); an extension is entered by hand (`source = manual`, at most 90 days). If the licence has already
  ended the new term starts now: the time in between was not covered, and the licence service treats a gap as "ended".
- A licence the system had marked EXPIRED becomes ACTIVE again when a new term covers now; the reason and who are in the licence's status history.
- Suspending keeps the machines' seats, so reinstating restores everyone at their next check.
- **Cancel and revoke are final.** Both end the licence as `CANCELLED`, the schema's only terminal status, which the licence service tells the app
  as `revoked`. They differ in what they do to seats and in the audit trail (`licence.cancel` / `licence.revoke`): a revocation frees every seat,
  a cancellation leaves the seat record as it was (revoking a cancelled licence later frees them). Nothing can renew, extend, suspend or
  reinstate a cancelled licence; issue a new one. A licence already marked `EXPIRED` has nothing to cancel (the database has no such move).
- **Blocking the machines of an ended licence.** The block list lives in the licence service (`access_block`), keyed by hashes. This service reads
  the machine ids of the licence's seats, hashes them with `LICENCE_HASH_PEPPER` (the licence service's own secret) and stores only the hashes,
  so the ids are never shown, returned, logged or audited. The licence must be cancelled or revoked first, and the caller confirms as below.
  "Its machines" means the ones holding a seat when it ended: a seat freed by a revocation, or still open after a cancellation. A machine that
  deactivated earlier is not blocked. Blocks made here point back at the licence (migration `005_block_licence_link` in the licence service), so
  `unblock-machines` lifts them all together; a machine blocked earlier for another reason keeps that block and is counted as `alreadyBlocked`.
- **A block is on the machine, not the licence.** A blocked machine is refused on every route in the licence service, so if it also holds a seat on
  a different, good licence, that one stops working on that machine too until the block is lifted. The answer reports how many machines were
  blocked so this is not a surprise. A person who has been blocked cannot start a trial on that machine either; that is the point.
- **The caller must confirm** with `confirm`: the last four characters of the licence key (the licence list shows them). A missing or wrong
  confirmation changes nothing, so a wrong id pasted from the list cannot end the wrong customer. Repeating is harmless.
- Extending an ended trial needs the licence database's migration 004 (EXPIRED may move back to ACTIVE, with a reason). It lives in
  `oasis-licence-service/db/license/004_trial_reactivation.up.sql`; run that service's `npm run migrate` first.
- Concurrent renewals queue on the licence row, so term numbers never collide and terms never overlap.
- There is no cap on how many times a trial can be extended (30 days per call). Every extension is audited with who and why; if abuse matters, add a limit.

## Faked until IT approves them

The email sender for the activation and password-reset links is a fake. **`docs/fakes.md` lists it, its swap point and what the real one must do.** Production refuses to start with it.

## Known limits (not fixed)

- **Anyone who knows a staff address can make that person's mailbox busy**: asking for a link sends one (a newer link replaces the older, and three requests per person per 15 minutes then send nothing, silently). The limit is per person, but the sign-in routes' own limit is per network address and in one process, so rotating addresses defeats it. Put a rate limit and alerting on `login_event` at the gateway before this goes anywhere real.
- The "link sent" and "no such staff member" paths take slightly different time on the server (the email is sent in the background, so the answer itself is not delayed). The answer is identical; the timing is not.
- A customer's own status (prospect, churned) is not checked when issuing a licence, only that it is not deleted.
- The audit trail's closing row is best effort (see above); the opening row is not.
- `TRUST_PROXY` is only forced in production. Behind a proxy with it left at 0, every caller shares one address.

## More known limits (from the security review)

- A session lasts a fixed 8 hours with no idle timeout, and a person may have several at once; signing out ends only that one. The cookie's path is `/v1` (so it is not sent with the page itself), which means it cannot carry the `__Host-` prefix.
- Public suffixes are caught by a list plus general patterns, not by the full public-suffix list: an unusual one can still be attached by someone with `DOMAIN_ATTACH`. Every attach is on the record with who and how they checked.
- The screens move focus to the page heading on each change of screen, but not after an in-page reload (a note added, a status changed): a screen-reader user hears the toast, not the new state. A real assistive-technology audit is still to do.
- If a proxy rewrites the `Host` header, every change from the browser is refused by the origin check. Pass the original host through.

## Not built

- **Email delivery** (IT Helpdesk first): the activation and password-reset links (nobody can activate an account, or reset a forgotten password, without it), replies to customers (recorded but not delivered until then), the support-mailbox notice and any "your licence is ready" message.
- **Notifications by email or chat.** The bell is in the portal only; it does not reach anyone who has the portal closed.
- **Two-factor sign-in, blocking the re-use of old passwords**, and a "signed in elsewhere" notice.
- **An automated browser test in CI.** The screens were checked by hand in a real browser (`npm run demo`), and tests guard the API, the security headers and the rule that no module can build markup from data; a headless-browser suite would guard the screens themselves.
- **CA employee review of every word the screens show**, and an accessibility audit with real assistive technology.
- A rate limit shared across instances (the limit is per process), TLS, deployment, CI with scanning, an owner, and a **schedule** for `npm run retention`.
- Releasing a seat in bulk, plan changes that move a licence between customers, and deleting customer notes (they are append-only).
- Dependencies: `express` and `pg` (both MIT). The browser code has none.

## Email (SMTP) placeholder

Email sending is not implemented. `NOTIFIER=fake` is the only accepted value, and production refuses it until a provider is approved (IT Helpdesk, cainc.service-now.com). `.env.example` reserves the names `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD` and `SMTP_FROM`, commented out and blank. Nothing reads them yet. The owner configures SMTP later; real values belong in the untracked `.env` or a secret store, never in the repository.
