// Small line icons for the navigation. Built as DOM nodes (never from markup) and drawn in the surrounding text colour. They are decoration: hidden from screen readers.
// The SVG namespace is an identifier, not an address: nothing is fetched from it. It is written in two parts so the "no other site" check in test/static.test.js stays strict.
export const NS = ['http:', '', 'www.w3.org', '2000', 'svg'].join('/');
const circle = (cx, cy, r) => `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`;

const PATHS = {
  dashboard: ['M3 3h7v9H3z', 'M14 3h7v5h-7z', 'M14 12h7v9h-7z', 'M3 16h7v5H3z'],
  'licence-requests': ['M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z', 'M14 3v6h6', 'M8 13h8', 'M8 17h5'],
  'help-requests': [circle(12, 12, 10), 'M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3', 'M12 17h.01'],
  feedback: ['M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z'],
  licences: ['M21 2l-9.6 9.6', 'M15.5 7.5l3 3L22 7l-3-3', circle(7.5, 15.5, 5.5)],
  customers: ['M3 21h18', 'M5 21V7l8-4v18', 'M19 21V11l-6-4', 'M9 9h.01', 'M9 13h.01', 'M9 17h.01'],
  trials: [circle(12, 12, 10), 'M12 6v6l4 2'],
  blocks: [circle(12, 12, 10), 'M4.9 4.9l14.2 14.2'],
  team: ['M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2', circle(9, 7, 4), 'M23 21v-2a4 4 0 0 0-3-3.87', 'M16 3.13a4 4 0 0 1 0 7.75'],
  audit: ['M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z', 'M9 12l2 2 4-4'],
  reports: ['M3 3v18h18', 'M7 15l4-4 3 3 5-6'],
  'customer-users': ['M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', 'M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1'],
  key: ['M21 2l-9.6 9.6', 'M15.5 7.5l3 3L22 7l-3-3', circle(7.5, 15.5, 5.5)],
  bell: ['M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9', 'M13.7 21a2 2 0 0 1-3.4 0'],
  workload: ['M9 11l3 3L22 4', 'M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'],
  invoices: ['M14 3H6a2 2 0 0 0-2 2v14l3-2 3 2 3-2 3 2V9z', 'M14 3v6h6', 'M8 12h6', 'M8 16h4'],
  'follow-ups': [circle(12, 12, 10), 'M12 7v5l3 2'],
  billing: ['M3 3v18h18', 'M7 14v4', 'M12 9v9', 'M17 5v13'],
  menu: ['M4 6h16', 'M4 12h16', 'M4 18h16'],
  signout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'M16 17l5-5-5-5', 'M21 12H9'],
  logo: ['M12 3l8 4.5v9L12 21l-8-4.5v-9z', 'M12 12l8-4.5', 'M12 12v9', 'M12 12L4 7.5'],
};

export function icon(name, size = 20) {
  const svg = document.createElementNS(NS, 'svg');
  for (const [k, v] of Object.entries({ viewBox: '0 0 24 24', width: size, height: size, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false', class: 'icon' })) svg.setAttribute(k, String(v));
  for (const d of PATHS[name] || []) { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); svg.append(p); }
  return svg;
}

/** "Ada Admin" becomes "AA"; an address becomes its first letter. */
export function initials(name) {
  const parts = String(name || '?').split(/[\s@.]+/).filter(Boolean);
  return ((parts[0] || '?')[0] + (parts.length > 1 ? parts[1][0] : '')).toUpperCase();
}
