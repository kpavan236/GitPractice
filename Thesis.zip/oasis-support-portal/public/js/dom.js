// Small helpers for building the page. Everything that came from the server or a person goes in as TEXT (textContent / text nodes): there is no innerHTML anywhere in
// the portal, so what a customer wrote in a message can never run as script or change the page.

/** el('button', { class: 'primary', onclick: fn, 'aria-label': 'x' }, 'Save', otherNode) */
export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value === undefined || value === null || value === false) continue;
    // A link or source is never allowed to carry a script: whatever builds one from data, javascript:, data: and vbscript: are refused here as a last line of defence.
    if (['href', 'src', 'action', 'formaction', 'xlink:href'].includes(key) && /^[\s\u0000-\u001f]*(?:javascript|data|vbscript):/i.test(String(value))) throw new Error(`Refusing a ${key} that is not a link`);
    if (key.toLowerCase().startsWith('on') && typeof value !== 'function') throw new Error('Refusing an event handler that is not a function');
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
    else if (key === 'dataset') for (const [k, v] of Object.entries(value)) node.dataset[k] = v;
    else if (value === true) node.setAttribute(key, '');
    else node.setAttribute(key, String(value));
  }
  append(node, children);
  return node;
}

export function append(node, children) {
  for (const child of children.flat(Infinity)) {
    if (child === undefined || child === null || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

/** Adds children to a node, skipping null / undefined / false (the browser's own append() would print the word "null"). */
export function mount(parent, ...children) { return append(parent, children); }

/**
 * A mailto: link for an address a customer typed. The address is NOT trusted: "a?bcc=x@evil.test" is a valid-looking address that, pasted into a mailto: link as it
 * is, would add a hidden Bcc to the team's reply. So the address is percent-encoded (everything but letters, digits and a few safe marks, keeping the one @), and the subject is
 * encoded too; a mail program then sees exactly one recipient whatever the customer wrote.
 */
export function mailtoHref(address, subject) {
  const to = encodeURIComponent(String(address)).replace(/%40/g, '@');
  return `mailto:${to}${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`;
}

export function clear(node) { node.replaceChildren(); return node; }

// ── Words people read ───────────────────────────────────────────────────────

export const LABELS = {
  purchase: { NEW: 'New', CONTACTED: 'Contacted', AGREED: 'Agreed', DECLINED: 'Declined', DUPLICATE: 'Duplicate' },
  help: { NEW: 'New', IN_PROGRESS: 'In progress', RESOLVED: 'Answered', CLOSED: 'Closed' },
  licence: { DRAFT: 'Draft', PENDING_ACTIVATION: 'Waiting for first use', ACTIVE: 'Active', SUSPENDED: 'Suspended', EXPIRED: 'Ended', CANCELLED: 'Cancelled' },
  trial: { ACTIVE: 'Running', EXPIRED: 'Ended', CONVERTED: 'Became a licence' },
  role: { admin: 'Admin', user: 'User' },
  user: { ACTIVE: 'Active', DISABLED: 'Deactivated', INVITED: 'Pending activation', LOCKED: 'Locked' },
  invoice: { DRAFT: 'Draft', ISSUED: 'Issued', SENT: 'Sent', PAID: 'Paid', OVERDUE: 'Overdue', VOID: 'Void', CANCELLED: 'Cancelled' },
};
export const TONE = {
  NEW: 'info', CONTACTED: 'warn', AGREED: 'good', DECLINED: 'muted', DUPLICATE: 'muted', IN_PROGRESS: 'warn', RESOLVED: 'good', CLOSED: 'muted',
  PENDING_ACTIVATION: 'info', ACTIVE: 'good', SUSPENDED: 'warn', EXPIRED: 'muted', CANCELLED: 'bad', DRAFT: 'muted', CONVERTED: 'good', DISABLED: 'muted', INVITED: 'warn',
  ISSUED: 'info', SENT: 'info', PAID: 'good', OVERDUE: 'bad', VOID: 'muted',
};

export function badge(kind, code) {
  const label = (LABELS[kind] && LABELS[kind][code]) || code || '—';
  return el('span', { class: `badge ${TONE[code] || 'muted'}` }, label);
}

const two = n => String(n).padStart(2, '0');
export function fmtDate(value) {
  if (!value) return '—';
  // A plain calendar date ('2026-10-14') has no time zone: build it locally so it never shows as the day before west of UTC.
  const plain = typeof value === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  const d = plain ? new Date(Number(plain[1]), Number(plain[2]) - 1, Number(plain[3])) : new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return `${d.getDate()} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()]} ${d.getFullYear()}`;
}
export function fmtDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : `${fmtDate(d)}, ${two(d.getHours())}:${two(d.getMinutes())}`;
}
/** "3 hours", "2 days": how long something has waited. */
export function fmtWaiting(hours) {
  const h = Number(hours);
  if (!Number.isFinite(h) || h < 0) return '—';
  if (h < 1) return 'under an hour';
  if (h < 48) return `${Math.round(h)} hour${Math.round(h) === 1 ? '' : 's'}`;
  const days = Math.round(h / 24);
  return `${days} day${days === 1 ? '' : 's'}`;
}
/** "in 20 days" / "3 days ago" / "today" for a date. */
export function fmtRelativeDay(value) {
  if (!value) return '';
  const days = Math.round((new Date(value).getTime() - Date.now()) / 86_400_000);
  if (days === 0) return 'today';
  return days > 0 ? `in ${days} day${days === 1 ? '' : 's'}` : `${-days} day${days === -1 ? '' : 's'} ago`;
}
export const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

/**
 * For a screen that reloads its list when a filter changes: `const fresh = latest(); ... const ok = fresh(); const data = await get(...); if (!ok()) return;` An older, slower answer
 * must never overwrite what a newer filter has already drawn.
 */
export function latest() {
  let n = 0;
  return () => { const mine = ++n; return () => mine === n; };
}

/** Text a customer wrote (a name, a subject), isolated for bidirectional text so a right-to-left run cannot reorder the words around it. */
export const theirs = text => el('bdi', {}, text);

/** A heading each page starts with; the router moves keyboard focus to it so a screen reader announces where you are. */
export function pageHeader(title, subtitle, ...actions) {
  return el('div', { class: 'page-header' },
    el('div', {}, el('h1', { tabindex: '-1', id: 'page-title' }, title), subtitle ? el('p', { class: 'subtitle' }, subtitle) : null),
    actions.length ? el('div', { class: 'page-actions' }, ...actions) : null);
}

export const emptyState = (title, detail) => el('div', { class: 'empty' }, el('p', { class: 'empty-title' }, title), detail ? el('p', {}, detail) : null);
export const loading = () => el('p', { class: 'loading', role: 'status' }, 'Loading…');
export const errorBox = (err, retry) => el('div', { class: 'error-box', role: 'alert' },
  el('p', {}, err && err.message ? err.message : 'Something went wrong.'),
  err && err.requestId ? el('p', { class: 'small' }, `Reference for support: ${err.requestId}`) : null,
  retry ? el('button', { class: 'secondary', onclick: retry }, 'Try again') : null);

/** A labelled field. Returns { node, input } so a form can read the value. */
export function field(label, input, hint) {
  const id = input.id || `f-${Math.random().toString(36).slice(2, 9)}`;
  input.id = id;
  if (hint) input.setAttribute('aria-describedby', `${id}-hint`);        // a screen reader reads the hint with the field
  return { input, node: el('div', { class: 'field' }, el('label', { for: id }, label), input, hint ? el('p', { class: 'hint', id: `${id}-hint` }, hint) : null) };
}
export const textInput = (props = {}) => el('input', { type: 'text', autocomplete: 'off', ...props });
export const select = (options, value) => {
  const s = el('select', {}, options.map(([v, label]) => el('option', { value: v, selected: v === value }, label)));
  return s;
};
export function table(columns, rows, { caption, onRow } = {}) {
  return el('div', { class: 'table-wrap' }, el('table', {},
    caption ? el('caption', { class: 'visually-hidden' }, caption) : null,
    el('thead', {}, el('tr', {}, columns.map(c => el('th', { scope: 'col', class: c.class }, c.title)))),
    el('tbody', {}, rows.map(row => {
      const tr = el('tr', onRow ? { class: 'clickable' } : {}, columns.map(c => el('td', { class: c.class, 'data-label': c.title }, c.render(row))));
      if (onRow) { tr.addEventListener('click', e => { if (!e.target.closest('a, button, input, select')) onRow(row); }); }
      return tr;
    }))));
}
