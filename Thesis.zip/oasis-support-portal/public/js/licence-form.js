import { el, field, textInput, select, fmtDate, mount } from './dom.js';
import { get, post } from './api.js';
import { openDialog, showOnce, toast, guarded } from './dialogs.js';

const publicMail = d => /(^|\.)(gmail|googlemail|outlook|hotmail|live|msn|yahoo|ymail|icloud|me|aol|proton|protonmail)\.[a-z.]+$/i.test(d);

/**
 * "Create licence": the step after a customer has agreed. Used from a licence request (the customer is made from it), from a customer's page (a further licence) and
 * on its own. Shows the plan's defaults, creates the customer and licence, then shows the licence key ONCE and offers to attach the customer's email domain, because
 * the app activates by work email and cannot do it until the domain is attached.
 * Returns { licenseId, customerId } when a licence was made, or null.
 */
export const createLicenceFlow = guarded(async function createLicenceFlow(ctx, { request = null, customer = null } = {}) {
  const { plans } = await get('/plans');
  const knownCustomer = customer || (request && request.customer);
  const contactDomain = request && request.email ? request.email.split('@')[1] : '';
  let nameInput, planSelect, seatsInput, unlimited, daysInput, reasonInput, planInfo;

  const made = await openDialog({
    title: 'Create licence', wide: true, submitLabel: 'Create licence',
    intro: request ? `For ${request.organization_name}, agreed with ${request.contact_name}.` : knownCustomer ? `A further licence for ${knownCustomer.name}.` : 'For a customer you have agreed a licence with.',
    build: () => {
      const options = plans.map(p => [p.plan_code, p.label]);
      planSelect = select(options, options.some(o => o[0] === 'team') ? 'team' : options[0][0]);
      seatsInput = el('input', { type: 'number', min: 1, max: 1000000, step: 1 });
      unlimited = el('input', { type: 'checkbox' });
      daysInput = el('input', { type: 'number', min: 1, max: 3650, step: 1 });
      reasonInput = el('textarea', { rows: 2, maxlength: 500, required: true });
      reasonInput.value = request ? `Agreed with ${request.contact_name}` : 'Licence agreed with the customer';
      planInfo = el('p', { class: 'hint' });
      const apply = () => {
        const p = plans.find(x => x.plan_code === planSelect.value);
        seatsInput.value = p.default_seat_limit ?? '';
        unlimited.checked = p.default_seat_limit === null;
        seatsInput.disabled = unlimited.checked;
        unlimited.parentElement.hidden = p.plan_code !== 'enterprise';
        daysInput.value = p.default_term_days;
        planInfo.textContent = p.features.length ? `Includes: ${p.features.join(', ')}.` : 'Core OASIS only (no extra features).';
      };
      planSelect.addEventListener('change', apply);
      unlimited.addEventListener('change', () => { seatsInput.disabled = unlimited.checked; });
      const unlimitedRow = el('label', { class: 'check' }, unlimited, ' Unlimited seats (enterprise only)');
      const nameField = knownCustomer ? el('p', {}, el('strong', {}, 'Customer: '), knownCustomer.name)
        : (() => { nameInput = textInput({ maxlength: 200, required: true, value: request ? request.organization_name : '' }); return field('Customer name', nameInput, 'Shown to the customer in the app.').node; })();
      const body = el('div', {}, nameField,
        field('Plan', planSelect).node, planInfo,
        el('div', { class: 'row' }, field('Seats (people or machines who can use it)', seatsInput).node, field('Length in days', daysInput, 'The licence starts when it is created.').node), unlimitedRow,
        field('Reason (kept on the record with your name)', reasonInput).node);
      apply();
      return body;
    },
    onSubmit: async () => {
      const p = plans.find(x => x.plan_code === planSelect.value);
      const body = { reason: reasonInput.value.trim(), plan: p.plan_code, termDays: Number(daysInput.value) };
      if (!body.reason) throw new Error('Please give a reason.');
      if (!Number.isInteger(body.termDays) || body.termDays < 1) throw new Error('Enter the length in days.');
      if (p.plan_code === 'enterprise') { body.kind = 'enterprise'; body.seats = unlimited.checked ? null : Number(seatsInput.value); }
      else body.seats = Number(seatsInput.value);
      if (body.seats !== null && (!Number.isInteger(body.seats) || body.seats < 1)) throw new Error('Enter the number of seats.');
      if (knownCustomer) body.customerId = knownCustomer.id;
      else {
        const name = nameInput.value.trim();
        if (!name) throw new Error('Enter the customer name.');
        body.customer = { name };
        if (request) body.purchaseRequest = request.reference;
      }
      try { return await post('/licenses', body); }
      catch (err) { throw new Error(err.reason === 'request_not_agreed' ? 'Mark the request as Agreed first.' : err.message); }
    },
  });
  if (!made) return null;

  // The key is shown once, here, and never again.
  await showOnce({
    title: 'Licence created', secret: made.licenceKey, secretLabel: 'Licence key: shown once, so copy it now. Keep it with the customer record if they ask for it.',
    intro: `${made.customerName}: ${made.seats === null ? 'unlimited seats' : `${made.seats} seats`}, ${made.termDays} days.`,
    after: () => domainStep(ctx, made, contactDomain),
  });
  return { licenseId: made.licenseId, customerId: made.customerId };
});

/** Attaching the customer's email domain is what lets people at the company activate OASIS by their work address. */
function domainStep(ctx, made, suggested) {
  const box = el('div', { class: 'step' });
  mount(box, el('h3', {}, 'Let the customer activate'),
    el('p', {}, 'OASIS activates by work email address. Attach the company\'s email domain so anyone there can activate.'));
  if (!ctx.can('DOMAIN_ATTACH')) { mount(box, el('p', { class: 'notice' }, 'You do not have permission to attach a domain. Ask an admin to attach it.')); return box; }
  const domain = textInput({ maxlength: 253, value: suggested && !publicMail(suggested) ? suggested : '', placeholder: 'company.com', spellcheck: 'false' });
  const how = el('textarea', { rows: 2, maxlength: 500, placeholder: 'For example: Priya confirmed on the call that company.com is their domain' });
  const out = el('p', { role: 'status' });
  const button = el('button', { type: 'button', class: 'secondary', onclick: async () => {
    out.textContent = ''; out.className = '';
    const d = domain.value.trim().toLowerCase();
    if (!d) { out.textContent = 'Enter the domain, for example company.com.'; out.className = 'form-error'; return; }
    // The reason goes on the record under your name, so it must be what you actually did: it is never pre-filled.
    if (!how.value.trim()) { out.textContent = 'Say how you checked that this domain is theirs.'; out.className = 'form-error'; how.focus(); return; }
    button.disabled = true;
    try {
      await post('/domains', { customerId: made.customerId, domain: d, reason: how.value.trim() });
      out.textContent = `Attached ${d}. Anyone with an @${d} address can now activate.`; out.className = 'ok';
      toast(`Domain ${d} attached`);
      button.hidden = true;
    } catch (err) { out.textContent = err.message; out.className = 'form-error'; button.disabled = false; }
  } }, 'Attach domain');
  if (suggested && publicMail(suggested)) mount(box, el('p', { class: 'hint' }, `${suggested} is a public mailbox provider and cannot be attached. Ask the customer for their company domain.`));
  mount(box, field('Company email domain', domain, 'Check with the customer that this is theirs.').node, field('How did you check it? (kept on the record with your name)', how).node, button, out,
    el('h3', {}, 'What to tell the customer'),
    el('ol', { class: 'steps' }, el('li', {}, 'Open OASIS and choose Activate licence.'), el('li', {}, 'Enter their work email address.'), el('li', {}, 'Enter the 6-digit code we email them.')));
  return box;
}
