import { el } from './dom.js';
import { get } from './api.js';

export const nameOf = (names, id) => (names && names[id]) || 'Former team member';

/** The status as the screens show it: an invoice past its due date with a balance reads Overdue even if the nightly job has not run. */
export const invBadge = invoice => {
  const code = invoice.effectiveStatus || invoice.status;
  const label = { DRAFT: 'Draft', ISSUED: 'Issued', SENT: 'Sent', PAID: 'Paid', OVERDUE: 'Overdue', VOID: 'Void', CANCELLED: 'Cancelled' }[code] || code;
  const tone = { DRAFT: 'muted', ISSUED: 'info', SENT: 'info', PAID: 'good', OVERDUE: 'bad', VOID: 'muted', CANCELLED: 'bad' }[code] || 'muted';
  return el('span', { class: `badge ${tone}` }, label);
};

export const STATUS_OPTIONS = [['', 'Any status'], ['DRAFT', 'Draft'], ['ISSUED', 'Issued'], ['SENT', 'Sent'], ['OVERDUE', 'Overdue'], ['PAID', 'Paid'], ['VOID', 'Void'], ['CANCELLED', 'Cancelled']];

let statusPromise = null;
/** Whether billing is connected, the currency and the default link life. Asked once per page load; a failure is not remembered. */
export function getBillingStatus() {
  if (!statusPromise) statusPromise = get('/billing/status').catch(err => { statusPromise = null; throw err; });
  return statusPromise;
}

/** A link to the invoice list with some filters already applied. The query is encoded twice so a "+" or "&" survives the address bar. */
export const filterLink = params => `#/invoices/filter/${encodeURIComponent(new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== '')).toString())}`;

/** A form that is submitted twice must not act twice, but a CHANGED form is a new request: the same key is kept only while the body stays the same. */
export function keyFor(holder, body) {
  const text = JSON.stringify(body);
  if (holder.text !== text) { holder.text = text; holder.key = `ui-${crypto.randomUUID()}`; }
  return holder.key;
}

export const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
