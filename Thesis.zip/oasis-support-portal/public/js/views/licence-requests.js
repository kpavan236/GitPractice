import { replyDialog, repliesSection } from '../replies.js';
import { el, clear, pageHeader, badge, fmtDate, fmtDateTime, fmtWaiting, table, emptyState, loading, errorBox, field, select, plural, mount, mailtoHref, latest, theirs } from '../dom.js';
import { get, patch, qs } from '../api.js';
import { askReason, openDialog, toast, guarded } from '../dialogs.js';
import { createLicenceFlow } from '../licence-form.js';

const FILTERS = [['open', 'Open', 'NEW,CONTACTED'], ['agreed', 'Agreed', 'AGREED'], ['closed', 'Declined or duplicate', 'DECLINED,DUPLICATE'], ['all', 'All', '']];
const PAGE = 50;

export async function renderLicenceRequests(page, { id }, ctx) {
  return id ? detail(page, id, ctx) : list(page, ctx);
}

// ── The list ─────────────────────────────────────────────────────────────────

async function list(page, ctx) {
  let filter = 'open', who = 'everyone', offset = 0;
  mount(page, pageHeader('Licence requests', 'People who asked to buy OASIS from the app. Call them, agree the details, then create their licence.'));
  const chips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Show' });
  // Admins can also look at one person's work: that is how they track who has what.
  let people = [];
  if (ctx.can('REQUEST_ASSIGN')) { try { people = (await get('/users')).users.filter(u => u.status === 'ACTIVE'); } catch (_) { /* the filter is a convenience */ } }
  const whoSelect = select([['everyone', 'Everyone\'s requests'], ['me', 'Assigned to me'], ['none', 'Not assigned'], ...people.map(u => [u.id, `Assigned to ${u.displayName || u.email}`])], who);
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, chips, field('Show', whoSelect).node), box);

  const drawChips = () => { clear(chips); for (const [key, label] of FILTERS) mount(chips, el('button', { class: `chip ${key === filter ? 'on' : ''}`, 'aria-pressed': String(key === filter), onclick: () => { filter = key; offset = 0; drawChips(); load(); } }, label)); };
  whoSelect.addEventListener('change', () => { who = whoSelect.value; offset = 0; load(); });

  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const status = FILTERS.find(f => f[0] === filter)[2];
      const r = await get(`/purchase-requests${qs({ status, assignedTo: who === 'everyone' ? '' : who, limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.purchaseRequests.length) { mount(box, emptyState('Nothing here', filter === 'open' ? 'No open licence requests. New ones appear when someone uses Buy a licence in the app.' : 'No requests match.')); return; }
      mount(box, table([
        { title: 'Reference', render: p => el('a', { href: `#/licence-requests/${p.reference}` }, p.reference) },
        { title: 'Organisation', render: p => el('div', {}, el('strong', {}, theirs(p.organization_name)), el('div', { class: 'small muted' }, `${plural(p.employee_count, 'employee')} · ${p.size_band || ''}`)) },
        { title: 'Contact', render: p => el('div', {}, theirs(p.contact_name), el('div', { class: 'small muted' }, p.email)) },
        { title: 'Status', render: p => badge('purchase', p.status_code) },
        { title: 'Assigned to', render: p => p.assigned_to_name || el('span', { class: 'muted' }, 'Nobody') },
        { title: 'Waiting', render: p => (p.is_closed ? el('span', { class: 'muted' }, `took ${fmtWaiting(p.hours_open_or_to_close)}`) : fmtWaiting(p.hours_open_or_to_close)) },
        { title: 'Received', render: p => fmtDate(p.created_at) },
      ], r.purchaseRequests, { caption: 'Licence requests', onRow: p => ctx.go(`licence-requests/${p.reference}`) }));
      if (r.purchaseRequests.length === PAGE) mount(box, el('div', { class: 'pager' }, offset ? el('button', { class: 'secondary', onclick: () => { offset -= PAGE; load(); } }, 'Previous') : null, el('button', { class: 'secondary', onclick: () => { offset += PAGE; load(); } }, 'Next')));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  drawChips();
  await load();
}

// ── One request ──────────────────────────────────────────────────────────────

const NEXT = {
  NEW: [['CONTACTED', 'Mark as contacted', 'You have spoken to or emailed them.'], ['DUPLICATE', 'Mark as duplicate', 'This is the same request as another one.'], ['DECLINED', 'Decline', 'They are not going ahead.']],
  CONTACTED: [['AGREED', 'Mark as agreed', 'You and the customer have agreed the details.'], ['DECLINED', 'Decline', 'They are not going ahead.'], ['DUPLICATE', 'Mark as duplicate', 'This is the same request as another one.']],
};

async function detail(page, reference, ctx) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let r;
    try { r = await get(`/purchase-requests/${encodeURIComponent(reference)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Request not found', 'It may have been mistyped.') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${r.reference} · OASIS Support Portal`;

    const moves = NEXT[r.status_code] || [];
    const actions = [];
    for (const [to, label, hint] of moves) {
      actions.push(el('button', { class: to === 'AGREED' ? 'primary' : 'secondary', onclick: () => askReason({
        title: label, intro: hint, submitLabel: label,
        placeholder: to === 'CONTACTED' ? 'For example: called Pat on 12 Oct, asked about seats' : to === 'AGREED' ? 'For example: 25 seats for a year, agreed by phone' : 'Say why',
        run: async reason => { await patch(`/purchase-requests/${r.reference}`, { status: to, reason }); },
      }).then(done => { if (done) { toast(`${r.reference} is now ${label.replace('Mark as ', '').toLowerCase()}`); load(); } }) }, label));
    }

    // The note box
    const noteInput = el('textarea', { rows: 3, maxlength: 1000, placeholder: 'What did the customer say? Who did you speak to?' });
    const noteButton = el('button', { class: 'secondary', onclick: async () => {
      const text = noteInput.value.trim();
      if (!text) return;
      noteButton.disabled = true;
      try { await patch(`/purchase-requests/${r.reference}`, { note: text, reason: 'Added a note' }); toast('Note added'); load(); }
      catch (err) { toast(err.message, 'bad'); noteButton.disabled = false; }
    } }, 'Add note');

    // Assign (admins)
    let assignBlock = null;
    if (ctx.can('REQUEST_ASSIGN')) {
      assignBlock = el('button', { class: 'secondary', onclick: guarded(async () => {
        const { users } = await get('/users');
        let pick;
        const done = await openDialog({ title: 'Assign request', intro: `${r.reference}: ${r.organization_name}`, submitLabel: 'Assign',
          build: () => { pick = select([['', 'Nobody'], ...users.filter(u => u.status === 'ACTIVE').map(u => [u.id, `${u.displayName || u.email} (${u.role})`])], r.assigned_to_user_id || ''); return field('Assign to', pick).node; },
          onSubmit: async () => { await patch(`/purchase-requests/${r.reference}`, { assignedTo: pick.value || null, reason: pick.value ? 'Assigned' : 'Unassigned' }); } });
        if (done) { toast('Assignment saved'); load(); }
      }) }, r.assigned_to_name ? 'Change' : 'Assign');
    }

    const notes = (r.support_notes || '').split('\n').filter(Boolean);
    const canCreate = r.status_code === 'AGREED' && ctx.can('LICENSE_ACTIVATE');
    mount(box, 
      el('p', { class: 'crumbs' }, el('a', { href: '#/licence-requests' }, '← Licence requests')),
      pageHeader(theirs(r.organization_name), `${r.reference} · received ${fmtDateTime(r.created_at)}`, badge('purchase', r.status_code)),
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'The customer'),
            el('dl', { class: 'facts' },
              el('dt', {}, 'Organisation'), el('dd', {}, theirs(r.organization_name)),
              el('dt', {}, 'Size'), el('dd', {}, `${plural(r.employee_count, 'employee')}${r.size_band ? ` (${r.size_band})` : ''}`),
              el('dt', {}, 'Contact'), el('dd', {}, theirs(r.contact_name)),
              el('dt', {}, 'Email'), el('dd', {}, el('a', { href: mailtoHref(r.email, `Your OASIS licence request ${r.reference}`) }, r.email), ctx.can('CUSTOMER_UPDATE') ? el('div', {}, el('button', { class: 'secondary', onclick: async () => { if (await replyDialog({ path: `/purchase-requests/${encodeURIComponent(r.reference)}`, to: r.email, defaultSubject: `Your OASIS licence request ${r.reference}` })) load(); } }, 'Reply from the portal')) : null),
              el('dt', {}, 'App version'), el('dd', {}, r.app_version || '—')),
            el('p', { class: 'small muted' }, 'Contact is by email only: the Buy form does not collect a phone number. Ask for one when you write if you need to call.')),
          el('section', { class: 'card' }, el('h2', {}, 'Licence'),
            r.customer ? el('div', {},
              el('p', {}, 'Customer: ', el('a', { href: `#/customers/${r.customer.id}` }, r.customer.name)),
              r.licences.length ? el('ul', { class: 'plain' }, r.licences.map(l => el('li', {}, el('a', { href: `#/licences/${l.license_id}` }, `${l.plan_code} · ${l.seat_limit === null ? 'unlimited' : plural(l.seat_limit, 'seat')}`), ' ', badge('licence', l.status_code), ` until ${fmtDate(l.expires_at)}`))) : el('p', { class: 'muted' }, 'No licence yet.'),
              ctx.can('INVOICE_WRITE') ? el('p', {}, el('a', { class: 'button-link', href: `#/invoices/new/${encodeURIComponent(r.reference)}` }, 'Create invoice')) : null,
              canCreate ? el('button', { class: 'primary', onclick: async () => { if (await createLicenceFlow(ctx, { request: r })) load(); } }, 'Create another licence') : null)
              : r.status_code === 'AGREED' ? el('div', {}, el('p', {}, 'Agreed. Create the licence so the customer can use OASIS.'),
                canCreate ? el('button', { class: 'primary', onclick: async () => { if (await createLicenceFlow(ctx, { request: r })) load(); } }, 'Create licence') : el('p', { class: 'notice' }, 'You do not have permission to create licences.'))
              : el('p', { class: 'muted' }, r.status_code === 'DECLINED' || r.status_code === 'DUPLICATE' ? 'This request is closed, so there is no licence.' : 'Mark the request as agreed once you and the customer have agreed the details, then create the licence here.')),
          repliesSection(r.replies),
          el('section', { class: 'card' }, el('h2', {}, 'Notes'),
            notes.length ? el('ul', { class: 'notes' }, notes.map(n => el('li', {}, n))) : el('p', { class: 'muted' }, 'No notes yet. Write down what was said on the call.'),
            r.is_closed ? null : el('div', {}, field('Add a note', noteInput).node, noteButton))),
        el('aside', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'Status'),
            el('p', {}, badge('purchase', r.status_code), r.is_closed ? ` took ${fmtWaiting(r.hours_open_or_to_close)}` : ` waiting ${fmtWaiting(r.hours_open_or_to_close)}`),
            actions.length ? el('div', { class: 'stack' }, actions) : el('p', { class: 'muted' }, 'This request is finished.')),
          el('section', { class: 'card' }, el('h2', {}, 'Assigned to'),
            el('p', {}, r.assigned_to_name || el('span', { class: 'muted' }, 'Nobody yet')), assignBlock,
            !ctx.can('REQUEST_ASSIGN') ? el('p', { class: 'small muted' }, 'Only an admin can assign requests.') : null),
          el('section', { class: 'card' }, el('h2', {}, 'History'),
            el('ol', { class: 'timeline' }, r.history.map(h => el('li', {}, el('strong', {}, h.to_status_code === 'NEW' ? 'Received' : (({ CONTACTED: 'Contacted', AGREED: 'Agreed', DECLINED: 'Declined', DUPLICATE: 'Marked duplicate' })[h.to_status_code] || h.to_status_code)),
              el('div', { class: 'small muted' }, `${fmtDateTime(h.changed_at)}${h.changed_by_name ? ` · ${h.changed_by_name}` : ''}`), h.reason && h.reason !== 'Submitted' ? el('div', { class: 'small' }, h.reason) : null)))))));
  }
  await load();
}
