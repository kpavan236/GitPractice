import { el, clear, pageHeader, table, emptyState, loading, errorBox, field, select, mount, latest, fmtDate, theirs } from '../dom.js';
import { get, qs } from '../api.js';
import { fmtMoney } from '../money.js';
import { invBadge, nameOf, getBillingStatus, STATUS_OPTIONS } from '../billing-common.js';
import { renderInvoiceForm } from './invoice-form.js';
import { renderInvoicePage } from './invoice-page.js';

const PAGE = 50;
const EXTRA = { customerId: 'one customer', open: 'open invoices only', closed: 'deals closed', bucket: 'days past due', health: 'follow-up health', sourcePurchaseRequestId: 'one licence request' };

/** The Invoices router: one address, several screens. #/invoices/new, /new/<PR-reference>, /edit/<id>, /filter/<query> and /<id>. */
export async function renderInvoices(page, params, ctx) {
  const id = params.id || '';
  if (id === 'new' || id.startsWith('new/')) return renderInvoiceForm(page, { reference: id.slice(4) || null }, ctx);
  if (id.startsWith('edit/')) return renderInvoiceForm(page, { invoiceId: id.slice(5) }, ctx);
  if (id.startsWith('filter/')) return renderInvoiceList(page, ctx, id.slice(7));
  if (id) return renderInvoicePage(page, id, ctx);
  return renderInvoiceList(page, ctx, '');
}

async function renderInvoiceList(page, ctx, raw) {
  const status = await getBillingStatus().catch(err => { mount(page, errorBox(err)); return null; });
  if (!status) return;
  if (!status.enabled) { mount(page, pageHeader('Invoices'), emptyState('Billing is not set up', 'The billing service is not connected to this portal.')); return; }

  const preset = Object.fromEntries(new URLSearchParams(raw));
  const f = { status: preset.status || '', ownerId: preset.ownerId || '', overdue: preset.overdue || '', dueFrom: preset.dueFrom || '', dueTo: preset.dueTo || '' };
  const extra = Object.fromEntries(Object.keys(EXTRA).filter(k => preset[k]).map(k => [k, preset[k]]));
  let offset = 0;

  const { owners, meId } = await get('/invoice-owners').catch(() => ({ owners: [], meId: null }));
  const statusSel = select(STATUS_OPTIONS, f.status);
  const ownerSel = select([['', 'Everyone'], ...(meId && owners.some(o => o.id === meId) ? [[meId, 'Me']] : []), ...owners.filter(o => o.id !== meId).map(o => [o.id, o.name]), ...(f.ownerId && f.ownerId !== meId && !owners.some(o => o.id === f.ownerId) ? [[f.ownerId, 'Selected owner']] : [])], f.ownerId);
  const overdueBox = el('input', { type: 'checkbox', checked: f.overdue === '1' });
  const fromInput = el('input', { type: 'date', value: f.dueFrom }), toInput = el('input', { type: 'date', value: f.dueTo });
  const chips = el('div', { class: 'chip-row' });
  const csv = ctx.can('INVOICE_ADMIN') ? el('a', { class: 'button-link', href: '#', download: '' }, 'Download CSV') : null;
  const newButton = ctx.can('INVOICE_WRITE') ? el('a', { class: 'button-link primary', href: '#/invoices/new' }, 'New invoice') : null;
  const box = el('div');
  mount(page, pageHeader('Invoices', 'Every invoice, from a licence request or raised by hand. Overdue is worked out from the due date, so it is right even if nothing has run overnight.', newButton, csv),
    el('div', { class: 'toolbar' }, field('Status', statusSel).node, field('Owner', ownerSel).node, field('Due from', fromInput).node, field('Due to', toInput).node,
      el('label', { class: 'check' }, overdueBox, ' Overdue only')), chips, box);

  const query = () => ({ ...extra, status: statusSel.value, ownerId: ownerSel.value, overdue: overdueBox.checked ? '1' : '', dueFrom: fromInput.value, dueTo: toInput.value });
  const drawChips = () => {
    clear(chips);
    for (const k of Object.keys(extra)) mount(chips, el('span', { class: 'badge info' }, `Filtered: ${EXTRA[k]}`, ' ', el('button', { type: 'button', class: 'link', 'aria-label': `Remove the filter: ${EXTRA[k]}`, onclick: () => { delete extra[k]; offset = 0; load(); } }, '✕')));
  };
  const fresh = latest();
  async function load() {
    const ok = fresh();
    drawChips();
    clear(box); mount(box, loading());
    const q = query();
    if (csv) csv.setAttribute('href', `/v1/admin/billing/export.csv${qs(q)}`);
    try {
      const r = await get(`/invoices${qs({ ...q, limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.invoices.length) { mount(box, emptyState('No invoices match', 'Change the filters, or raise a new invoice.')); return; }
      mount(box, table([
        { title: 'Number', class: 'nowrap', render: i => el('a', { href: `#/invoices/${i.invoiceId}` }, i.invoiceNumber || 'Draft') },
        { title: 'Customer', render: i => theirs(i.billToName || '—') },
        { title: 'Total', class: 'num', render: i => fmtMoney(i.totalMinor, i.currency) },
        { title: 'Paid', class: 'num', render: i => fmtMoney(i.paidMinor, i.currency) },
        { title: 'Balance', class: 'num', render: i => fmtMoney(i.balanceMinor, i.currency) },
        { title: 'Due', class: 'nowrap', render: i => fmtDate(i.dueOn) },
        { title: 'Status', render: i => invBadge(i) },
        { title: 'Owner', render: i => nameOf(r.names, i.ownerUserId) },
        { title: 'Last follow-up', render: i => (i.lastFollowUpAt ? fmtDate(i.lastFollowUpAt) : '—') },
      ], r.invoices, { caption: 'Invoices', onRow: i => { location.hash = `#/invoices/${i.invoiceId}`; } }));
      const prev = el('button', { class: 'secondary', disabled: offset === 0, onclick: () => { offset = Math.max(0, offset - PAGE); load(); } }, 'Previous');
      const next = el('button', { class: 'secondary', disabled: offset + PAGE >= r.total, onclick: () => { offset += PAGE; load(); } }, 'Next');
      mount(box, el('div', { class: 'pager' }, prev, el('span', { class: 'muted small', role: 'status' }, `${offset + 1}–${offset + r.invoices.length} of ${r.total}`), next));
    } catch (err) { if (ok()) { clear(box); mount(box, errorBox(err, load)); } }
  }
  for (const control of [statusSel, ownerSel, overdueBox, fromInput, toInput]) control.addEventListener('change', () => { offset = 0; load(); });
  await load();
}
