import { el, clear, pageHeader, field, textInput, select, mount, loading, errorBox, emptyState, theirs } from '../dom.js';
import { get, post, patch } from '../api.js';
import { toMinor, toQuantity, toInput, lineAmount, fmtMoney } from '../money.js';
import { getBillingStatus, keyFor } from '../billing-common.js';
import { toast } from '../dialogs.js';

const BAD = 'Check the highlighted fields.';

/** Create a new invoice (blank, or pre-filled from a Buy-licence request) or edit a draft. Money is typed as 1,234.50 and sent as whole minor units; the server recomputes every total. */
export async function renderInvoiceForm(page, { reference = null, invoiceId = null }, ctx) {
  const status = await getBillingStatus().catch(err => { mount(page, errorBox(err)); return null; });
  if (!status) return;
  if (!status.enabled) { mount(page, pageHeader('Invoice'), emptyState('Billing is not set up', 'The billing service is not connected to this portal.')); return; }
  if (!ctx.can('INVOICE_WRITE')) { mount(page, pageHeader('Invoice'), emptyState('You cannot raise invoices', 'Ask an admin if you need to.')); return; }
  const currency = status.currency;

  mount(page, el('p', { class: 'crumbs' }, el('a', { href: '#/invoices' }, '← Invoices')), pageHeader(invoiceId ? 'Edit draft invoice' : 'New invoice', invoiceId ? 'Only a draft can be edited. Once it is issued it is locked.' : reference ? `Pre-filled from licence request ${reference}. Check the details and add the price.` : 'Raise an invoice for a renewal, an add-on or a one-off.'));
  const box = el('div'); mount(page, box, loading());

  let existing = null, draft = null;
  try {
    if (invoiceId) { existing = await get(`/invoices/${encodeURIComponent(invoiceId)}`); if (existing.invoice.status !== 'DRAFT') { clear(box); mount(box, emptyState('This invoice is no longer a draft', 'It cannot be edited.')); return; } }
    else if (reference) draft = await get(`/purchase-requests/${encodeURIComponent(reference)}/invoice-draft`);
  } catch (err) { clear(box); mount(box, errorBox(err)); return; }

  const customer = { id: existing ? existing.invoice.customerId : draft ? draft.customerId : '', name: existing ? existing.billTo && existing.billTo.name : draft ? draft.billTo.name : '' };
  const source = draft ? draft.sourcePurchaseRequestId : null;
  const b = (existing && existing.billTo) || (draft && draft.billTo) || {};
  const input = (value = '', props = {}) => textInput({ value, maxlength: 200, ...props });
  const bill = { name: input(b.name), line1: input(b.line1), line2: input(b.line2), city: input(b.city, { maxlength: 100 }), state: input(b.stateProvince, { maxlength: 100 }), postal: input(b.postalCode, { maxlength: 20 }), country: input(b.countryCode || 'IN', { maxlength: 2, class: 'short', autocapitalize: 'characters' }), taxId: input(b.taxId, { maxlength: 50 }) };
  const dueInput = el('input', { type: 'date', value: (existing && existing.invoice.dueOn) || '' });
  const notesInput = el('textarea', { rows: 2, maxlength: 1000 }); notesInput.value = (existing && existing.invoice.notes) || (draft && draft.notes) || '';
  const errorLine = el('p', { class: 'form-error', role: 'alert' });
  const holder = {};

  // ── Customer (only when raising by hand: from a request the customer is known) ──
  let customerBlock = null;
  if (customer.id) customerBlock = el('p', {}, 'Customer: ', theirs(customer.name || 'this customer'));
  else {
    const q = textInput({ type: 'search', placeholder: 'Start typing a customer name', maxlength: 100 });
    const results = select([['', 'Search first, then choose']], '');
    const runFind = async () => {
      const text = q.value.trim();
      if (text.length < 2) { errorLine.textContent = 'Type at least 2 characters of the customer name, then press Find.'; return; }
      errorLine.textContent = '';
      try {
        const r = await get(`/customers?q=${encodeURIComponent(q.value.trim())}&limit=20`);
        clear(results); mount(results, el('option', { value: '' }, r.customers.length ? 'Choose the customer' : 'No customer found'), r.customers.map(c => el('option', { value: c.customer_id }, c.name)));
      } catch (err) { errorLine.textContent = err.message; }
    };
    const find = el('button', { type: 'button', class: 'secondary', onclick: runFind }, 'Find');
    q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); runFind(); } });
    results.addEventListener('change', () => { customer.id = results.value; customer.name = results.options[results.selectedIndex].textContent; if (!bill.name.value) bill.name.value = customer.name; });
    customerBlock = el('div', {}, field('Customer', q, 'The invoice is raised for a customer that already exists.').node, el('div', { class: 'row' }, find, results));
  }

  // ── Lines ──
  const lines = [];
  const body = el('tbody');
  const preview = el('table', { class: 'totals-preview', 'aria-live': 'polite' });
  const addLine = (l = {}) => {
    const row = { description: input(l.description, { 'aria-label': 'Description' }), quantity: input(l.quantity === undefined ? '1' : String(l.quantity), { 'aria-label': 'Quantity', inputmode: 'decimal', maxlength: 9, class: 'short' }),
      price: input(l.unitPriceMinor === undefined || l.unitPriceMinor === null ? '' : toInput(l.unitPriceMinor), { 'aria-label': 'Unit price', inputmode: 'decimal', maxlength: 16, placeholder: '0.00' }) };
    row.node = el('tr', {}, el('td', {}, row.description), el('td', {}, row.quantity), el('td', {}, row.price),
      el('td', { class: 'num', 'data-label': 'Amount' }), el('td', {}, el('button', { type: 'button', class: 'secondary', 'aria-label': 'Remove this line', onclick: () => { if (lines.length > 1) { lines.splice(lines.indexOf(row), 1); row.node.remove(); recalc(); } } }, 'Remove')));
    for (const i of [row.quantity, row.price]) i.addEventListener('input', recalc);
    lines.push(row); body.append(row.node);
  };
  function recalc() {
    let charges = 0, discounts = 0;
    for (const l of lines) {
      const amount = lineAmount(toQuantity(l.quantity.value) || '', toMinor(l.price.value, { allowNegative: true }) ?? NaN);
      l.node.children[3].textContent = amount === null ? '—' : fmtMoney(amount, currency);
      if (amount > 0) charges += amount; else if (amount < 0) discounts -= amount;
    }
    clear(preview);
    mount(preview, el('tbody', {}, el('tr', {}, el('th', { scope: 'row' }, 'Charges'), el('td', { class: 'num' }, fmtMoney(charges, currency))),
      discounts ? el('tr', {}, el('th', { scope: 'row' }, 'Discounts'), el('td', { class: 'num' }, `-${fmtMoney(discounts, currency)}`)) : null,
      el('tr', { class: 'grand' }, el('th', { scope: 'row' }, 'Total'), el('td', { class: 'num' }, fmtMoney(charges - discounts, currency)))));
  }
  const start = existing ? existing.lines : draft ? draft.lines : [{}];
  for (const l of start) addLine({ description: l.description, quantity: l.quantity, unitPriceMinor: l.unitPriceMinor });
  recalc();

  // ── Submit ──
  const submit = el('button', { type: 'submit', class: 'primary' }, invoiceId ? 'Save draft' : 'Save as draft');
  const form = el('form', { novalidate: true }, errorLine);
  form.addEventListener('submit', async e => {
    e.preventDefault(); errorLine.textContent = '';
    const out = [];
    for (const [i, l] of lines.entries()) {
      const quantity = toQuantity(l.quantity.value), unit = toMinor(l.price.value, { allowNegative: true });
      if (!l.description.value.trim()) return fail(`Line ${i + 1} needs a description.`, l.description);
      if (quantity === null) return fail(`Line ${i + 1}: the quantity must be more than 0, with up to 3 decimals.`, l.quantity);
      if (unit === null) return fail(`Line ${i + 1}: enter the unit price like 1,234.50. Use a minus sign for a discount.`, l.price);
      out.push({ description: l.description.value.trim(), quantity: Number(quantity), unitPriceMinor: unit });
    }
    if (!customer.id) return fail('Choose the customer.', null);
    if (!bill.name.value.trim() || !bill.line1.value.trim() || !bill.city.value.trim()) return fail('The bill-to needs a name, an address line and a city.', bill.name);
    if (!/^[A-Za-z]{2}$/.test(bill.country.value.trim())) return fail('The bill-to country is two letters, such as IN.', bill.country);
    const payload = { billTo: { name: bill.name.value, line1: bill.line1.value, line2: bill.line2.value || undefined, city: bill.city.value, stateProvince: bill.state.value || undefined, postalCode: bill.postal.value || undefined, countryCode: bill.country.value.trim().toUpperCase(), taxId: bill.taxId.value || undefined },
      lines: out, dueOn: dueInput.value || (invoiceId ? null : undefined), notes: notesInput.value.trim() || (invoiceId ? null : undefined) };
    submit.disabled = true; submit.textContent = 'Saving…';
    try {
      const r = invoiceId ? await patch(`/invoices/${encodeURIComponent(invoiceId)}`, payload)
        : await post('/invoices', { ...payload, customerId: customer.id, ...(source ? { sourcePurchaseRequestId: source } : {}) }, { 'Idempotency-Key': keyFor(holder, { ...payload, customerId: customer.id, source }) });
      toast(invoiceId ? 'Draft saved' : 'Draft created');
      ctx.go(`invoices/${r.invoice.invoiceId}`);
    } catch (err) { errorLine.textContent = err.message || BAD; submit.disabled = false; submit.textContent = invoiceId ? 'Save draft' : 'Save as draft'; }
    function fail(message, focusOn) { errorLine.textContent = message; if (focusOn) focusOn.focus(); }
  });

  const section = (title, ...children) => el('section', { class: 'card' }, el('h2', {}, title), ...children);
  mount(form,
    section('Customer', customerBlock),
    section('Bill to', el('div', { class: 'grid-2' }, field('Name', bill.name).node, field('Tax id (optional)', bill.taxId).node, field('Address line 1', bill.line1).node, field('Address line 2 (optional)', bill.line2).node,
      field('City', bill.city).node, field('State or province (optional)', bill.state).node, field('Postal code (optional)', bill.postal).node, field('Country (two letters)', bill.country).node)),
    section('Items', el('div', { class: 'table-wrap' }, el('table', { class: 'line-table' }, el('thead', {}, el('tr', {}, ['Description', 'Quantity', `Unit price (${currency})`, 'Amount', ''].map(t => el('th', { scope: 'col' }, t)))), body)),
      el('p', {}, el('button', { type: 'button', class: 'secondary', onclick: () => { addLine({ quantity: 1 }); recalc(); } }, 'Add a line')),
      el('p', { class: 'hint' }, 'A discount is a line with a minus price, for example -500.00. Tax is an ordinary line. Totals are worked out again when you save.'), preview),
    section('Terms', el('div', { class: 'grid-2' }, field('Due date', dueInput, 'You can choose it now or when you issue the invoice.').node, field('Internal note (never shown to the customer)', notesInput).node)),
    el('div', { class: 'actions-bar' }, submit, el('a', { class: 'button-link', href: invoiceId ? `#/invoices/${invoiceId}` : '#/invoices' }, 'Cancel')));
  clear(box); mount(box, form);
}
