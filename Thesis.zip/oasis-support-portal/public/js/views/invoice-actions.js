import { el, field, textInput, select } from '../dom.js';
import { get, post } from '../api.js';
import { openDialog, askReason, showOnce, toast } from '../dialogs.js';
import { toMinor, toInput, fmtMoney } from '../money.js';
import { getBillingStatus, keyFor, today } from '../billing-common.js';

const url = (d, tail = '') => `/invoices/${encodeURIComponent(d.invoice.invoiceId)}${tail}`;
const METHODS = [['bank_transfer', 'Bank transfer'], ['po', 'Purchase order'], ['cheque', 'Cheque'], ['other', 'Other']];
const CHANNELS = [['email', 'Email'], ['call', 'Phone call'], ['meeting', 'Meeting'], ['other', 'Other']];

/** Issue: gives the invoice its number and locks it. */
export async function issueInvoice(d) {
  const due = el('input', { type: 'date', value: d.invoice.dueOn || '' });
  return openDialog({
    title: 'Issue this invoice', submitLabel: 'Issue invoice',
    intro: 'Issuing gives it an invoice number and locks it: it can no longer be edited. Fix any mistake with a credit note.',
    build: () => field('Due date', due).node,
    onSubmit: async () => { if (!due.value) throw new Error('Choose the due date.'); await post(url(d, '/issue'), { dueOn: due.value }); toast('Invoice issued'); },
  });
}

/** Mark sent: staff send the link themselves; this records that they did, and how. */
export async function markSent(d) {
  const channel = select(CHANNELS, 'email'), note = el('textarea', { rows: 2, maxlength: 500 });
  return openDialog({
    title: 'Mark as sent', submitLabel: 'Mark as sent', intro: 'Nothing is sent from here. This records that you sent the customer the invoice, and how.',
    build: () => el('div', {}, field('How you sent it', channel).node, field('Note (optional)', note).node),
    onSubmit: async () => { await post(url(d, '/mark-sent'), { channel: channel.value, ...(note.value.trim() ? { note: note.value.trim() } : {}) }); toast('Marked as sent'); },
  });
}

/** The customer's secure link. Shown ONCE: only a hash is kept. */
export async function shareLink(d) {
  const status = await getBillingStatus();
  const days = el('input', { type: 'number', min: 1, max: 365, step: 1, value: status.shareLinkDefaultDays });
  const made = await openDialog({
    title: 'Create a secure link', submitLabel: 'Create link',
    intro: 'The customer opens the link to see the invoice and its receipts, with no login. You send it to them yourself. Anyone who has the link can see this invoice until it expires or you revoke it.',
    build: () => field('Days the link works', days).node,
    onSubmit: async () => {
      const n = Number(days.value);
      if (!Number.isInteger(n) || n < 1 || n > 365) throw new Error('Choose from 1 to 365 days.');
      return post(url(d, '/links'), { days: n });
    },
  });
  if (!made || made === true) return false;
  await showOnce({ title: 'Your secure link', secretLabel: 'Copy this link and send it to the customer. It will not be shown again.', secret: made.link.url,
    intro: `It works until ${new Date(made.link.expiresAt).toLocaleDateString()}.` });
  return true;
}

/** Record a payment: gives a receipt. A double click or a retry records it once. */
export async function recordPayment(d) {
  const balance = d.invoice.balanceMinor, currency = d.invoice.currency, holder = {};
  const amount = textInput({ inputmode: 'decimal', maxlength: 16, value: toInput(balance) }), method = select(METHODS, 'bank_transfer'), reference = textInput({ maxlength: 100 }), when = el('input', { type: 'date', value: today() });
  const result = await openDialog({
    title: 'Record a payment', submitLabel: 'Record payment', intro: `${fmtMoney(balance, currency)} is still owed. A receipt number is given to every payment.`,
    build: () => el('div', {}, field('Amount received', amount, 'The balance is filled in. Change it to record only part of the amount.').node, field('Method', method).node,
      field('Reference (optional)', reference, 'A cheque or transfer number, or a purchase order number.').node, field('Received on', when).node),
    onSubmit: async () => {
      const minor = toMinor(amount.value);
      if (minor === null || minor <= 0) throw new Error('Enter the amount like 1,234.50.');
      if (minor > balance) throw new Error(`That is more than the ${fmtMoney(balance, currency)} still owed.`);
      const body = { amountMinor: minor, method: method.value, ...(reference.value.trim() ? { reference: reference.value.trim() } : {}), receivedOn: when.value || undefined };
      return post(url(d, '/payments'), body, { 'Idempotency-Key': keyFor(holder, body) });
    },
  });
  if (!result || result === true) return false;
  toast(`Payment recorded. Receipt ${result.payment.receiptNumber}`);
  return true;
}

/** A follow-up is a log of what staff did. Nothing is sent. */
export async function logFollowUp(d) {
  const channel = select([['call', 'Phone call'], ['email', 'Email'], ['meeting', 'Meeting'], ['other', 'Other']], 'call');
  const outcome = textInput({ maxlength: 200, placeholder: 'For example: finance office will pay on Friday' }), note = el('textarea', { rows: 2, maxlength: 1000 }), next = el('input', { type: 'date', min: today() });
  return openDialog({
    title: 'Log a follow-up', submitLabel: 'Save follow-up', intro: 'A record of what you did to chase this invoice. Nothing is sent from here.',
    build: () => el('div', {}, field('How', channel).node, field('What came of it', outcome).node, field('Note (optional)', note).node, field('Follow up again on (optional)', next).node),
    onSubmit: async () => {
      if (!outcome.value.trim()) throw new Error('Say what came of it.');
      await post(url(d, '/follow-ups'), { channel: channel.value, outcome: outcome.value.trim(), ...(note.value.trim() ? { note: note.value.trim() } : {}), ...(next.value ? { nextFollowUpOn: next.value } : {}) });
      toast('Follow-up saved');
    },
  });
}

export const cancelDraft = d => askReason({ title: 'Cancel this draft', submitLabel: 'Cancel draft', danger: true, intro: 'A cancelled draft is kept for the record but can no longer be issued.',
  placeholder: 'For example: raised for the wrong customer', run: async reason => { await post(url(d, '/cancel'), { reason }); toast('Draft cancelled'); } });

export const voidInvoice = d => askReason({ title: 'Void this invoice', submitLabel: 'Void invoice', danger: true,
  intro: `${d.invoice.invoiceNumber} keeps its number and stays on the record as void. Payments must be voided first.`,
  placeholder: 'For example: raised to the wrong district', run: async reason => { await post(url(d, '/void'), { reason }); toast('Invoice voided'); } });

export const voidPayment = (d, p) => askReason({ title: `Void receipt ${p.receiptNumber}`, submitLabel: 'Void payment', danger: true,
  intro: 'The payment stays on the record, cancelled by a reversal. The invoice is reopened if it was paid in full.', placeholder: 'For example: the cheque bounced',
  run: async reason => { await post(url(d, `/payments/${encodeURIComponent(p.paymentId)}/void`), { reason }); toast('Payment voided'); } });

export const revokeLink = async (d, link) => {
  await post(url(d, `/links/${encodeURIComponent(link.linkId)}/revoke`), {});
  toast('Link revoked: the customer can no longer open it');
  return true;
};

export const creditNote = d => askReason({
  title: 'Raise a credit note', submitLabel: 'Raise credit note', intro: 'A credit note reduces what the customer owes, for example for fewer seats. It cannot credit the whole of an unpaid invoice: void it instead.',
  placeholder: 'For example: 5 fewer seats than ordered',
  extra: () => { const amount = textInput({ inputmode: 'decimal', maxlength: 16 }); return { node: field(`Credit amount (${d.invoice.currency})`, amount).node, amount }; },
  run: async (reason, extras) => {
    const minor = toMinor(extras.amount.value);
    if (minor === null || minor <= 0) throw new Error('Enter the credit amount like 1,234.50.');
    const r = await post(url(d, '/credit-notes'), { amountMinor: minor, reason });
    toast(`Credit note ${r.creditNote.creditNoteNumber} raised`);
  },
});

export async function changeOwner(d) {
  const { owners } = await get('/invoice-owners');
  return askReason({
    title: 'Change the deal owner', submitLabel: 'Change owner', intro: 'The owner is who gets the credit when the invoice is paid. Every change is kept with who made it and why.',
    placeholder: 'For example: the account moved to the south region team',
    extra: () => { const who = select([['', 'Choose the new owner'], ...owners.filter(o => o.id !== d.invoice.ownerUserId).map(o => [o.id, o.name])], ''); return { node: field('New owner', who).node, who }; },
    run: async (reason, extras) => {
      if (!extras.who.value) throw new Error('Choose the new owner.');
      await post(url(d, '/owner'), { toUserId: extras.who.value, reason });
      toast('Owner changed');
    },
  });
}
