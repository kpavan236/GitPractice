import { el, clear, pageHeader, fmtDateTime, emptyState, loading, errorBox, field, select, mount, mailtoHref, latest } from '../dom.js';
import { get, qs } from '../api.js';

const PAGE = 30;
const CATS = { bug: 'Something is wrong', idea: 'An idea', praise: 'Works well', other: 'Something else' };

export async function renderFeedback(page) {
  let category = '', rating = '', withEmail = '', offset = 0;
  mount(page, pageHeader('Feedback', 'What people sent from the app. Read only: most is anonymous, so there is nobody to reply to unless they gave an address.'));
  const cat = select([['', 'All kinds'], ...Object.entries(CATS)], category);
  const rate = select([['', 'Any rating'], ...[1, 2, 3, 4, 5].map(n => [String(n), `${n} star${n === 1 ? '' : 's'}`])], rating);
  const mail = select([['', 'With or without an address'], ['true', 'Gave an address'], ['false', 'Anonymous']], withEmail);
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, field('Kind', cat).node, field('Rating', rate).node, field('Address', mail).node), box);
  for (const s of [cat, rate, mail]) s.addEventListener('change', () => { category = cat.value; rating = rate.value; withEmail = mail.value; offset = 0; load(); });
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const r = await get(`/feedback${qs({ category, rating, withEmail, limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.feedback.length) { mount(box, emptyState('No feedback matches', 'Try another filter.')); return; }
      mount(box, el('ul', { class: 'cards' }, r.feedback.map(f => el('li', { class: 'card' },
        el('div', { class: 'card-head' }, el('span', { class: `badge ${f.category_code === 'bug' ? 'warn' : f.category_code === 'praise' ? 'good' : 'info'}` }, CATS[f.category_code] || f.category_code),
          f.rating ? el('span', { class: 'rating', role: 'img', 'aria-label': `${f.rating} out of 5` }, '★'.repeat(f.rating) + '☆'.repeat(5 - f.rating)) : null,
          el('span', { class: 'small muted' }, `${f.reference} · ${fmtDateTime(f.created_at)}${f.screen ? ` · from the ${f.screen} tab` : ''}${f.app_version ? ` · version ${f.app_version}` : ''}`)),
        el('div', { class: 'message' }, f.message),
        f.email ? el('p', { class: 'small' }, 'Left an address: ', el('a', { href: mailtoHref(f.email) }, f.email)) : null))));
      if (r.feedback.length === PAGE || offset) mount(box, el('div', { class: 'pager' }, offset ? el('button', { class: 'secondary', onclick: () => { offset -= PAGE; load(); } }, 'Previous') : null, r.feedback.length === PAGE ? el('button', { class: 'secondary', onclick: () => { offset += PAGE; load(); } }, 'Next') : null));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
