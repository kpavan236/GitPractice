import { el, pageHeader, fmtWaiting, loading, errorBox, plural, clear, mount } from '../dom.js';
import { get } from '../api.js';

function greeting(name) {
  const h = new Date().getHours();
  return `${h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'}, ${(name || '').split(' ')[0] || 'there'}`;
}

/** A card with one number and where it leads. A zero is shown calmly; something waiting is shown with weight. */
function stat(label, value, href, { tone = 'calm', hint } = {}) {
  return el('a', { class: `stat ${value > 0 ? tone : 'calm'}`, href }, el('span', { class: 'stat-label' }, label), el('span', { class: 'stat-value' }, String(value)), el('span', { class: 'stat-hint' }, value > 0 && hint ? hint : ''));
}

export async function renderDashboard(page, _params, ctx) {
  mount(page, pageHeader(greeting(ctx.me.displayName), 'What is waiting for the team today.'));
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    try {
      const d = await get('/dashboard');
      clear(box);
      const pr = d.purchaseRequests, sr = d.supportRequests, li = d.licences, tr = d.trials;
      mount(box, 
        el('section', { 'aria-labelledby': 'h-lr' },
          el('h2', { id: 'h-lr' }, 'Licence requests', el('span', { class: 'h-hint' }, 'People who asked to buy')),
          el('div', { class: 'stats' },
            stat('New: call them', pr.new, '#/licence-requests', { tone: 'attention' }),
            stat('Agreed: create their licence', pr.agreedWithoutLicence, '#/licence-requests', { tone: 'attention', hint: pr.agreedWithoutLicence ? 'The customer cannot use OASIS until you do' : null }),
            stat('Being followed up', pr.contacted, '#/licence-requests'),
            stat('Not assigned to anyone', pr.unassigned, '#/licence-requests', { tone: 'warn' }),
            stat('Assigned to you', pr.mine, '#/licence-requests')),
          pr.new + pr.contacted ? el('p', { class: 'small' }, `The oldest open request has been waiting ${fmtWaiting(pr.oldestOpenHours)}.`) : null),
        el('section', { 'aria-labelledby': 'h-hr' },
          el('h2', { id: 'h-hr' }, 'Help requests', el('span', { class: 'h-hint' }, 'People asking for help')),
          el('div', { class: 'stats' },
            stat('New', sr.new, '#/help-requests', { tone: 'attention' }),
            stat('In progress', sr.inProgress, '#/help-requests'),
            stat('Answered, not closed', sr.resolved, '#/help-requests'),
            stat('Not assigned to anyone', sr.unassigned, '#/help-requests', { tone: 'warn' }),
            stat('Assigned to you', sr.mine, '#/help-requests')),
          sr.new + sr.inProgress ? el('p', { class: 'small' }, `The oldest open request has been waiting ${fmtWaiting(sr.oldestOpenHours)}.`) : null),
        el('section', { 'aria-labelledby': 'h-lic' },
          el('h2', { id: 'h-lic' }, 'Licences and trials'),
          el('div', { class: 'stats' },
            stat('Licences in use', li.live, '#/licences'),
            stat('Ending in 30 days', li.expiringIn30Days, '#/licences', { tone: 'warn', hint: 'Time to renew' }),
            stat('Suspended', li.suspended, '#/licences', { tone: 'warn' }),
            stat('Waiting for first use', li.waitingForFirstActivation, '#/licences'),
            stat('Trials running', tr.running, '#/trials'),
            stat('Trials ending in 3 days', tr.endingIn3Days, '#/trials', { tone: 'warn' }),
            stat('Trials flagged for review', tr.flaggedForReview, '#/trials', { tone: 'warn' }))),
        el('section', { 'aria-labelledby': 'h-fb' },
          el('h2', { id: 'h-fb' }, 'Feedback'),
          el('div', { class: 'stats' }, stat('Received in the last 7 days', d.feedback.last7Days, '#/feedback'), stat('Of those, bug reports', d.feedback.bugsLast7Days, '#/feedback', { tone: 'warn' }))),
        li.endedStillActive ? el('p', { class: 'small muted' }, `${plural(li.endedStillActive, 'licence')} marked active but past its end date (the app already refuses these).`) : null);
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
