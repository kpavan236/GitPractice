import { el, clear, pageHeader, table, emptyState, loading, errorBox, mount, fmtDate, fmtDateTime, theirs } from '../dom.js';
import { get } from '../api.js';
import { toast } from '../dialogs.js';
import { fmtMoney } from '../money.js';
import { invBadge, nameOf, getBillingStatus } from '../billing-common.js';
import { issueInvoice, markSent, shareLink, recordPayment, logFollowUp, cancelDraft, voidInvoice, voidPayment, revokeLink, creditNote, changeOwner } from './invoice-actions.js';

const ACTIONS = { 'invoice.create': 'Draft created', 'invoice.edit': 'Draft edited', 'invoice.cancel_draft': 'Draft cancelled', 'invoice.issue': 'Issued', 'invoice.mark_sent': 'Marked as sent', 'invoice.void': 'Voided',
  'payment.record': 'Payment recorded', 'payment.void': 'Payment voided', 'credit_note.create': 'Credit note raised', 'followup.log': 'Follow-up logged', 'link.create': 'Secure link created', 'link.revoke': 'Secure link revoked', 'owner.change': 'Owner changed' };
const METHOD = { bank_transfer: 'Bank transfer', po: 'Purchase order', cheque: 'Cheque', other: 'Other' };
const CHANNEL = { call: 'Phone call', email: 'Email', meeting: 'Meeting', other: 'Other' };

export async function renderInvoicePage(page, id, ctx) {
  const status = await getBillingStatus().catch(err => { mount(page, errorBox(err)); return null; });
  if (!status) return;
  if (!status.enabled) { mount(page, pageHeader('Invoice'), emptyState('Billing is not set up', 'The billing service is not connected to this portal.')); return; }
  const box = el('div'); mount(page, box);
  async function load() {
    clear(box); mount(box, loading());
    try { draw(await get(`/invoices/${encodeURIComponent(id)}`)); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('No such invoice', 'It may have been typed wrongly.') : errorBox(err, load)); }
  }
  const run = fn => async (...args) => { try { if (await fn(...args)) load(); } catch (err) { toast(err.message || 'That did not work. Please try again.', 'bad'); } };

  function draw(d) {
    const i = d.invoice, m = v => fmtMoney(v, i.currency), who = userId => nameOf(d.names, userId);
    const write = ctx.can('INVOICE_WRITE'), admin = ctx.can('INVOICE_ADMIN');
    const open = ['ISSUED', 'SENT', 'OVERDUE'].includes(i.status), isDraft = i.status === 'DRAFT';
    const button = (label, fn, cls = 'secondary') => el('button', { class: cls, onclick: run(fn) }, label);
    const actions = el('div', { class: 'actions-bar' },
      isDraft && write ? [el('a', { class: 'button-link primary', href: `#/invoices/edit/${i.invoiceId}` }, 'Edit draft'), button('Issue', () => issueInvoice(d), 'primary'), button('Cancel draft', () => cancelDraft(d))] : null,
      open && write ? [button('Record payment', () => recordPayment(d), 'primary'), button('Mark as sent', () => markSent(d)), button('Create secure link', () => shareLink(d)), button('Log follow-up', () => logFollowUp(d))] : null,
      i.status === 'PAID' && write ? button('Create secure link', () => shareLink(d)) : null,
      open && admin ? [button('Raise credit note', () => creditNote(d)), button('Void invoice', () => voidInvoice(d))] : null,
      !isDraft && i.status !== 'CANCELLED' && admin ? button('Change owner', () => changeOwner(d)) : null);

    const fact = (name, value) => [el('dt', {}, name), el('dd', {}, value)];
    clear(box);
    mount(box,
      el('p', { class: 'crumbs' }, el('a', { href: '#/invoices' }, '← Invoices')),
      pageHeader(i.invoiceNumber || 'Draft invoice', d.billTo ? theirs(d.billTo.name) : '', invBadge(i)),
      actions,
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'Items'),
            table([
              { title: 'Description', render: l => theirs(l.description) },
              { title: 'Quantity', class: 'num', render: l => l.quantity },
              { title: 'Unit price', class: 'num', render: l => m(l.unitPriceMinor) },
              { title: 'Amount', class: 'num', render: l => m(l.amountMinor) },
            ], d.lines, { caption: 'Invoice items' }),
            el('table', { class: 'totals-preview' }, el('tbody', {},
              el('tr', {}, el('th', { scope: 'row' }, 'Charges'), el('td', { class: 'num' }, m(i.subtotalMinor))),
              i.discountMinor ? el('tr', {}, el('th', { scope: 'row' }, 'Discounts'), el('td', { class: 'num' }, `-${m(i.discountMinor)}`)) : null,
              el('tr', {}, el('th', { scope: 'row' }, 'Total'), el('td', { class: 'num' }, m(i.totalMinor))),
              i.creditedMinor ? el('tr', {}, el('th', { scope: 'row' }, 'Credit notes'), el('td', { class: 'num' }, `-${m(i.creditedMinor)}`)) : null,
              i.paidMinor ? el('tr', {}, el('th', { scope: 'row' }, 'Paid'), el('td', { class: 'num' }, `-${m(i.paidMinor)}`)) : null,
              el('tr', { class: 'grand' }, el('th', { scope: 'row' }, 'Balance'), el('td', { class: 'num' }, m(i.balanceMinor)))))),

          el('section', { class: 'card' }, el('h2', {}, 'Payments and receipts'),
            d.payments.length ? table([
              { title: 'Receipt', render: p => p.receiptNumber || '—' },
              { title: 'Received', render: p => fmtDate(p.receivedOn) },
              { title: 'Method', render: p => METHOD[p.method] || p.method },
              { title: 'Reference', render: p => (p.reference ? theirs(p.reference) : '—') },
              { title: 'Amount', class: 'num', render: p => m(p.amountMinor) },
              { title: 'Recorded by', render: p => who(p.recordedByUserId) },
              { title: 'Status', render: p => (p.reversesPaymentId ? `Reversal: ${p.voidReason}` : p.isVoided ? 'Voided' : 'Counted') },
              { title: '', class: 'actions', render: p => (admin && p.amountMinor > 0 && !p.isVoided ? el('button', { class: 'secondary', onclick: run(() => voidPayment(d, p)) }, 'Void') : '') },
            ], d.payments, { caption: 'Payments' }) : el('p', { class: 'muted' }, 'No payments yet.'),
            d.creditNotes.length ? el('ul', { class: 'plain' }, d.creditNotes.map(c => el('li', {}, `${c.creditNoteNumber} · ${m(c.amountMinor)} · ${fmtDate(c.issuedOn)} · `, theirs(c.reason)))) : null),

          el('section', { class: 'card' }, el('h2', {}, 'Follow-ups'),
            d.followUps.length ? el('ul', { class: 'plain' }, d.followUps.map(f => el('li', {}, `${fmtDateTime(f.at)} · ${who(f.byUserId)} · ${CHANNEL[f.channel] || f.channel}: `, theirs(f.outcome), f.note ? [' — ', theirs(f.note)] : null, f.nextFollowUpOn ? ` · next on ${fmtDate(f.nextFollowUpOn)}` : ''))) : el('p', { class: 'muted' }, 'Nobody has followed this up yet.'),
            open && write ? button('Log follow-up', () => logFollowUp(d)) : null),

          el('section', { class: 'card' }, el('h2', {}, 'History'),
            el('ul', { class: 'plain' }, d.activity.map(a => el('li', {}, `${fmtDateTime(a.at)} · ${who(a.actorUserId)} · ${ACTIONS[a.action] || a.action}`, a.reason ? [' — ', theirs(a.reason)] : null))))),

        el('aside', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'Balance'),
            el('p', { class: 'balance-big' }, m(i.balanceMinor)),
            el('dl', { class: 'facts' }, fact('Status', invBadge(i)), fact('Owner', who(i.ownerUserId)), fact('Issued', fmtDate(i.issuedOn)), fact('Due', fmtDate(i.dueOn)), fact('Created by', who(i.createdByUserId)),
              i.closedAt ? fact('Closed (first paid)', fmtDate(i.closedAt)) : null,
              i.sourcePurchaseRequestId ? fact('From a licence request', el('a', { href: '#/licence-requests' }, 'See licence requests')) : null),
            i.notes ? el('p', { class: 'small' }, el('strong', {}, 'Internal note: '), theirs(i.notes)) : null),
          el('section', { class: 'card' }, el('h2', {}, 'Bill to'),
            d.billTo ? el('p', {}, [d.billTo.name, d.billTo.line1, d.billTo.line2, [d.billTo.city, d.billTo.stateProvince, d.billTo.postalCode].filter(Boolean).join(', '), d.billTo.countryCode, d.billTo.taxId ? `Tax id ${d.billTo.taxId}` : null].filter(Boolean).flatMap((t, n) => [n ? el('br') : null, theirs(t)])) : el('p', { class: 'muted' }, 'None yet.')),
          el('section', { class: 'card' }, el('h2', {}, 'Secure links'),
            d.shareLinks.length ? el('ul', { class: 'plain' }, d.shareLinks.map(l => el('li', {},
              `${fmtDate(l.createdAt)} by ${who(l.createdByUserId)} · ${l.state === 'active' ? `until ${fmtDate(l.expiresAt)}` : l.state === 'revoked' ? 'revoked' : 'expired'} · `,
              l.viewCount ? `opened ${l.viewCount} time${l.viewCount === 1 ? '' : 's'}, last ${fmtDateTime(l.lastViewedAt)}` : 'not opened yet',
              l.state === 'active' && write ? [' ', el('button', { class: 'secondary', onclick: run(() => revokeLink(d, l)) }, 'Revoke')] : null))) : el('p', { class: 'muted' }, 'No link yet. Create one to let the customer see the invoice.'),
            el('p', { class: 'hint' }, 'A link is shown once when it is made and cannot be shown again.')),
          d.ownerHistory.length ? el('section', { class: 'card' }, el('h2', {}, 'Owner history'),
            el('ul', { class: 'plain' }, d.ownerHistory.map(o => el('li', {}, `${fmtDate(o.at)} · ${who(o.fromUserId)} → ${who(o.toUserId)} by ${who(o.changedByUserId)} — `, theirs(o.reason))))) : null)));
    document.title = `${i.invoiceNumber || 'Draft invoice'} · OASIS Support Portal`;
  }
  await load();
}
