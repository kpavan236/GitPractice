import { el, clear, pageHeader, table, emptyState, loading, errorBox, mount, fmtDate, theirs, plural } from '../dom.js';
import { get, qs } from '../api.js';
import { fmtMoney } from '../money.js';
import { nameOf, getBillingStatus } from '../billing-common.js';

const WHY = { overdue: ['Overdue', 'bad'], overdue_and_due: ['Overdue, follow-up due', 'bad'], due_today: ['Follow-up due today', 'warn'], lapsed: ['Follow-up date has passed', 'warn'] };

/** Who to chase today: overdue invoices, and those whose next follow-up is due or has lapsed. Anyone can work any invoice. */
export async function renderFollowUps(page, _params, ctx) {
  const status = await getBillingStatus().catch(err => { mount(page, errorBox(err)); return null; });
  if (!status) return;
  if (!status.enabled) { mount(page, pageHeader('Follow-ups'), emptyState('Billing is not set up', 'The billing service is not connected to this portal.')); return; }
  const mine = el('input', { type: 'checkbox' });
  const box = el('div');
  mount(page, pageHeader('Follow-ups', 'Overdue invoices and the ones you planned to chase. Nothing is sent from here: log what you did on the invoice.'),
    el('div', { class: 'toolbar' }, el('label', { class: 'check' }, mine, ' Mine only')), box);
  async function load() {
    clear(box); mount(box, loading());
    try {
      const q = await get(`/invoice-follow-ups/queue${qs({ mine: mine.checked ? '1' : '' })}`);
      clear(box);
      if (!q.groups.length) { mount(box, emptyState('Nothing to chase', 'No invoice is overdue or due for a follow-up today.')); return; }
      for (const g of q.groups) {
        mount(box, el('section', { class: 'card' }, el('h2', {}, nameOf(q.names, g.ownerUserId), el('span', { class: 'h-hint' }, plural(g.invoices.length, 'invoice'))),
          table([
            { title: 'Invoice', render: i => el('a', { href: `#/invoices/${i.invoiceId}` }, i.invoiceNumber) },
            { title: 'Customer', render: i => theirs(i.billToName || '—') },
            { title: 'Balance', class: 'num', render: i => fmtMoney(i.balanceMinor, i.currency) },
            { title: 'Due', render: i => fmtDate(i.dueOn) },
            { title: 'Why', render: i => el('span', { class: `badge ${WHY[i.reason][1]}` }, WHY[i.reason][0]) },
            { title: 'Last follow-up', render: i => (i.lastFollowUpAt ? fmtDate(i.lastFollowUpAt) : 'Never') },
            { title: 'Next follow-up', render: i => (i.nextFollowUpOn ? fmtDate(i.nextFollowUpOn) : '—') },
          ], g.invoices, { caption: `Invoices to chase for ${nameOf(q.names, g.ownerUserId)}`, onRow: i => { location.hash = `#/invoices/${i.invoiceId}`; } })));
      }
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  mine.addEventListener('change', load);
  await load();
}
