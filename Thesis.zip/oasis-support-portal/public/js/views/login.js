import { el, clear, field, textInput, mount } from '../dom.js';
import { get, post, setCsrfToken } from '../api.js';
import { icon } from '../icons.js';

/**
 * Sign in: a work email address and a password. A password is chosen (the first time) or replaced (when forgotten) with a code we email. What is shown never says whether an address
 * belongs to the team: asking for a code always looks the same, and a wrong address and a wrong password give the same message.
 */
export function renderLogin(root, { message, start, onSignedIn }) {
  let email = '';
  // Whether emails really go out is learned in the background; the notice appears when it is known, without redrawing the form the person may already be typing in.
  const testNotice = el('p', { class: 'notice warn', role: 'status', hidden: true }, 'Email is not connected yet (test mode), so activation and password links are not delivered. Ask whoever runs the portal for your link.');
  get('/auth/config').then(c => { if (c.emailDelivery !== 'live') testNotice.hidden = false; }).catch(() => {});
  const card = el('div', { class: 'center-card' });
  mount(root, el('div', { class: 'login' },
    el('aside', { class: 'login-brand' },
      el('span', { class: 'brand' }, el('span', { class: 'brand-mark' }, icon('logo', 22)), el('span', { class: 'brand-text' }, el('strong', {}, 'OASIS'), el('small', {}, 'Support Portal'))),
      el('div', { class: 'login-pitch' }, el('h2', {}, 'Helping every customer get started.'), el('p', {}, 'Work licence requests, answer help requests and look after licences, all in one place.'))),
    el('main', { class: 'login-main' }, card)));

  /** Email address and password: the way in. */
  function stepSignIn(note) {
    clear(card);
    const emailInput = textInput({ type: 'email', autocomplete: 'username', inputmode: 'email', required: true, value: email, placeholder: 'you@company.com' });
    const passwordInput = textInput({ type: 'password', autocomplete: 'current-password', required: true, maxlength: 200 });
    const errorLine = el('p', { class: 'form-error', role: 'alert' });
    const button = el('button', { type: 'submit', class: 'primary wide' }, 'Sign in');
    mount(card,
      el('h1', {}, 'Sign in'),
      el('p', { class: 'subtitle' }, 'Use your work email address and your password.'),
      (message || note) ? el('p', { class: 'notice', role: 'status' }, note || message) : null,
      el('form', { novalidate: true, onsubmit: async e => {
        e.preventDefault();
        errorLine.textContent = '';
        email = emailInput.value.trim();
        if (!email) { errorLine.textContent = 'Enter your work email address.'; emailInput.focus(); return; }
        if (!passwordInput.value) { errorLine.textContent = 'Enter your password.'; passwordInput.focus(); return; }
        button.disabled = true; button.textContent = 'Signing in…';
        try { const r = await post('/auth/login', { email, password: passwordInput.value, cookie: true }); passwordInput.value = ''; setCsrfToken(r.csrfToken); onSignedIn(); }
        catch (err) { errorLine.textContent = err.message; button.disabled = false; button.textContent = 'Sign in'; passwordInput.select(); }
      } }, field('Work email address', emailInput).node, field('Password', passwordInput).node, errorLine, button),
      el('p', { class: 'small' }, el('button', { type: 'button', class: 'link', onclick: () => stepForgot() }, 'Forgot or set your password')));
    (email ? passwordInput : emailInput).focus();
  }

  /** Forgot a password, or a new team member who has not activated: we email a link. */
  function stepForgot() {
    clear(card);
    const input = textInput({ type: 'email', autocomplete: 'username', inputmode: 'email', required: true, value: email, placeholder: 'you@company.com' });
    const errorLine = el('p', { class: 'form-error', role: 'alert' });
    const button = el('button', { type: 'submit', class: 'primary wide' }, 'Email me a link');
    mount(card,
      el('h1', {}, 'Forgot or set your password'),
      el('p', { class: 'subtitle' }, 'Enter your work email address. If you are on the support team, we will email you a link to choose a new password, or to activate your account if you have not yet.'),
      testNotice,
      el('form', { novalidate: true, onsubmit: async e => {
        e.preventDefault();
        errorLine.textContent = '';
        email = input.value.trim();
        if (!email) { errorLine.textContent = 'Enter your work email address.'; input.focus(); return; }
        button.disabled = true; button.textContent = 'Sending…';
        try { await post('/auth/password/forgot', { email }); stepSent(); }
        catch (err) { errorLine.textContent = err.message; button.disabled = false; button.textContent = 'Email me a link'; }
      } }, field('Work email address', input).node, errorLine, button),
      el('p', { class: 'small' }, el('button', { type: 'button', class: 'link', onclick: () => stepSignIn() }, 'Back to sign in')));
    input.focus();
  }

  function stepSent() {
    clear(card);
    mount(card,
      el('h1', {}, 'Check your email'),
      el('p', { class: 'subtitle' }, 'If that address belongs to a member of the support team, we have emailed a link. It works once: the password link for 1 hour, the activation link for 3 days.'),
      testNotice,
      el('p', { class: 'small' }, 'Nothing there? Check your spam folder, or ', el('button', { type: 'button', class: 'link', onclick: () => stepForgot() }, 'send another'), '.'),
      el('p', { class: 'small' }, el('button', { type: 'button', class: 'link', onclick: () => stepSignIn() }, 'Back to sign in')));
  }

  if (start === 'forgot') stepForgot(); else stepSignIn();
}
