import { el, pageHeader, loading, errorBox, clear, mount, table, badge, emptyState, fmtDate, fmtDateTime, fmtRelativeDay, field, latest, theirs, plural } from '../dom.js';
import { get, post } from '../api.js';
import { askReason, toast } from '../dialogs.js';
import { lineChart, barChart, donut } from '../charts.js';

const RANGES = [[4, '4 weeks'], [12, '12 weeks'], [26, '26 weeks'], [52, '1 year']];
const FLAGS = { no_users: ['No users yet', 'warn'], dormant: ['No sign-in for 60 days', 'warn'], near_seat_limit: ['Seats almost full', 'info'] };
const FILTERS = [['all', 'All customers'], ['attention', 'Needs attention'], ['no_users', 'No users yet'], ['dormant', 'Dormant'], ['near_seat_limit', 'Seats almost full']];

const panel = (title, hint, ...body) => el('section', { class: 'card panel' }, el('h2', {}, title, hint ? el('span', { class: 'h-hint' }, hint) : null), ...body);
const kpi = (name, value, note) => el('div', { class: 'stat calm kpi' }, el('span', { class: 'stat-label' }, name), el('span', { class: 'stat-value' }, String(value)), el('span', { class: 'stat-hint muted' }, note || ''));
const seatCell = c => (c.liveLicences ? el('div', { class: 'seatbar' }, c.seatLimit ? el('progress', { max: c.seatLimit, value: Math.min(c.seatsInUse, c.seatLimit), 'aria-label': `${c.seatsInUse} of ${c.seatLimit} seats` }) : null,
  el('span', { class: 'small' }, c.seatLimit === null ? `${c.seatsInUse} (unlimited)` : `${c.seatsInUse} of ${c.seatLimit}`)) : el('span', { class: 'muted' }, 'No live licence'));
const flagBadges = c => (c.flags.length ? el('div', { class: 'row-actions left' }, c.flags.map(f => el('span', { class: `badge ${FLAGS[f][1]}` }, FLAGS[f][0]))) : el('span', { class: 'muted' }, 'Fine'));

export async function renderCustomerUsers(page, { id }, ctx) { return id ? detail(page, id, ctx) : overview(page, ctx); }

/** Admin: who is using OASIS at each customer, and where something needs a conversation. Counts here; names and addresses only on a customer's own page, where each read is recorded. */
async function overview(page, ctx) {
  let weeks = 12, filter = 'all';
  const chips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Time range' });
  const csv = el('a', { class: 'button-link', href: '/v1/admin/customer-users.csv?weeks=12', download: '' }, 'Download CSV');
  mount(page, pageHeader('Customer users', 'Who is using OASIS at each customer: accounts, recent sign-ins and seats. This page shows counts only.', chips, csv));
  const box = el('div'); mount(page, box);
  const drawChips = () => { csv.setAttribute('href', `/v1/admin/customer-users.csv?weeks=${weeks}`); clear(chips); for (const [n, name] of RANGES) mount(chips, el('button', { class: `chip${n === weeks ? ' on' : ''}`, 'aria-pressed': String(n === weeks), onclick: () => { weeks = n; drawChips(); load(); } }, name)); };
  const fresh = latest();

  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const r = await get(`/customer-users?weeks=${weeks}`);
      if (!ok()) return;
      clear(box);
      const t = r.totals;
      if (!r.customers.length) { mount(box, emptyState('No customers yet', 'Customers and their users appear here once a licence is created.')); return; }
      const top = r.customers.filter(c => c.users.total).slice(0, 6).map(c => ({ label: c.name.length > 18 ? `${c.name.slice(0, 17)}…` : c.name, value: c.users.total }));
      const states = [{ label: 'Active', value: t.active }, { label: 'Invited', value: t.invited }, { label: 'Locked or disabled', value: t.blocked }];
      const signups = [{ name: 'New users', points: r.signups }];
      const list = el('div'), search = el('input', { type: 'search', placeholder: 'Search customers', 'aria-label': 'Search customers' });
      const filterChips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Show' });
      const drawList = () => {
        clear(filterChips); clear(list);
        for (const [key, name] of FILTERS) mount(filterChips, el('button', { class: `chip${key === filter ? ' on' : ''}`, 'aria-pressed': String(key === filter), onclick: () => { filter = key; drawList(); } }, name));
        const term = search.value.trim().toLowerCase();
        const shown = r.customers.filter(c => (filter === 'all' || (filter === 'attention' ? c.flags.length : c.flags.includes(filter))) && (!term || c.name.toLowerCase().includes(term)));
        if (!shown.length) { mount(list, emptyState('Nothing matches', 'Try a different filter or search.')); return; }
        mount(list, table([
          { title: 'Customer', render: c => el('a', { href: `#/customer-users/${c.customerId}` }, theirs(c.name)) },
          { title: 'Users', class: 'num', render: c => String(c.users.total) },
          { title: 'Active (30 days)', class: 'num', render: c => String(c.users.active30d) },
          { title: 'Never signed in', class: 'num', render: c => String(c.users.neverSignedIn) },
          { title: 'Seats', render: seatCell },
          { title: 'Last sign-in', render: c => (c.lastSignIn ? el('span', {}, fmtDate(c.lastSignIn), el('span', { class: 'muted small' }, ` · ${fmtRelativeDay(c.lastSignIn)}`)) : el('span', { class: 'muted' }, 'Never')) },
          { title: 'Needs attention', render: flagBadges },
        ], shown, { caption: 'Customers and their users', onRow: c => ctx.go(`customer-users/${c.customerId}`) }));
      };
      search.addEventListener('input', drawList);
      mount(box,
        el('div', { class: 'stats kpis' },
          kpi('Customers with users', t.customers, `${t.averagePerCustomer} users each on average`),
          kpi('Customer users', t.users, `${t.active} active, ${t.invited} invited`),
          kpi('Signed in, last 30 days', t.active30d, t.users ? `${Math.round((100 * t.active30d) / t.users)}% of all users` : ''),
          kpi('Never signed in', t.neverSignedIn, 'Invited but not started'),
          kpi('Customers needing attention', t.needAttention, 'See the table below')),
        el('div', { class: 'grid-2' },
          panel(`New users, last ${weeks} weeks`, 'Accounts created each week', lineChart(signups, { label: `New customer users for each of the last ${weeks} weeks` })),
          el('div', { class: 'grid-stack' },
            panel('Users by status', null, t.users ? donut(states, { label: 'Customer users by status', centre: 'users' }) : el('p', { class: 'muted' }, 'No users yet.')),
            panel('Customers with most users', null, top.length ? barChart(top, { label: 'Customers with the most users' }) : el('p', { class: 'muted' }, 'No users yet.')))),
        el('section', { class: 'card panel' }, el('h2', {}, 'Every customer', el('span', { class: 'h-hint' }, 'Open one to see its people, licences and seats')),
          el('div', { class: 'toolbar' }, field('Search', search).node, filterChips), list));
      drawList();
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  drawChips();
  await load();
}

/** One customer's people. This is personal data (names and work addresses): it is for admins and every read is recorded. */
async function detail(page, id, ctx) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let r;
    try { r = await get(`/customer-users/${encodeURIComponent(id)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Customer not found') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${r.customer.name} · Customer users · OASIS Support Portal`;
    const act = (u, action, title, intro, label, danger) => askReason({ title: `${title} ${u.display_name || u.email}`, intro, submitLabel: label, danger, placeholder: 'For example: asked by their IT team',
      run: async reason => post(`/customer-users/${r.customer.id}/users/${u.user_id}/${action}`, { reason }) }).then(d => { if (d) { toast(`${label} done`); load(); } });
    const userActions = u => el('div', { class: 'row-actions' },
      u.status_code === 'DISABLED' || u.status_code === 'LOCKED' ? el('button', { class: 'secondary', onclick: () => act(u, 'enable', 'Enable', 'They can sign in to the app again. If they never signed in before, they stay waiting to activate.', 'Enable') }, 'Enable') : el('button', { class: 'secondary', onclick: () => act(u, 'disable', 'Disable', 'They cannot sign in to the app, and any session they have ends at once. You can enable them again later.', 'Disable', true) }, 'Disable'),
      u.status_code !== 'ACTIVE' ? el('button', { class: 'secondary', onclick: () => act(u, 'reinvite', 'Re-invite', 'They go back to "waiting to activate" and can activate again from the app with their work email address. The portal sends no email: ask them to open the app.', 'Re-invite') }, 'Re-invite') : null,
      el('button', { class: 'danger', onclick: () => act(u, 'remove', 'Remove', 'Closes their account and hides it from this list. Their address stays reserved so the same person cannot be added twice by mistake. History is kept.', 'Remove', true) }, 'Remove'));
    const never = r.users.filter(u => !u.first_login_at).length, recent = r.users.filter(u => u.last_login_at && Date.now() - new Date(u.last_login_at).getTime() < 30 * 86_400_000).length;
    mount(box,
      el('p', { class: 'crumbs' }, el('a', { href: '#/customer-users' }, '← Customer users')),
      pageHeader(theirs(r.customer.name), `${plural(r.users.length, 'user')} · ${recent} signed in in the last 30 days · ${never} never signed in`,
        ctx.can('CUSTOMER_READ') ? el('a', { class: 'button-link', href: `#/customers/${r.customer.id}` }, 'Open the customer') : null),
      el('p', { class: 'notice small' }, 'This list shows names and work email addresses. Use it only to support the customer. Each time it is opened, that is recorded.'),
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'People'),
            r.users.length ? table([
              { title: 'Name', render: u => theirs(u.display_name || '—') }, { title: 'Email', render: u => theirs(u.email) },
              { title: 'Status', render: u => badge('user', u.status_code) }, { title: 'First sign-in', render: u => fmtDate(u.first_login_at) }, { title: 'Last sign-in', render: u => fmtDateTime(u.last_login_at) },
              ...(ctx.can('CUSTOMER_USER_MANAGE') ? [{ title: '', class: 'actions', render: u => userActions(u) }] : []),
            ], r.users, { caption: 'People at this customer' }) : emptyState('No users yet', 'Nobody at this customer has an account. They create one when they activate with a work address on an attached domain.'))),
        el('div', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'Licences and seats'),
            r.licences.length ? el('ul', { class: 'plain' }, r.licences.map(l => el('li', {}, el('a', { href: `#/licences/${l.license_id}` }, l.plan_code), ' ', badge('licence', l.status_code), el('br'), el('span', { class: 'muted small' }, `${l.seats_in_use} of ${l.seat_limit === null ? 'unlimited' : l.seat_limit} seats · ends ${fmtDate(l.expires_at)}`)))) : el('p', { class: 'muted' }, 'No licences.')),
          el('section', { class: 'card' }, el('h2', {}, 'Email domains'),
            r.domains.length ? el('ul', { class: 'plain' }, r.domains.map(d => el('li', {}, d.domain, ' ', d.verified_at ? el('span', { class: 'badge good' }, 'Verified') : el('span', { class: 'badge muted' }, 'Not verified')))) : el('p', { class: 'muted' }, 'No domains attached.')))));
  }
  await load();
}
