import { el, clear, pageHeader, fmtDateTime, table, emptyState, loading, errorBox, field, select, textInput, mount, latest } from '../dom.js';
import { get, qs } from '../api.js';

const PAGE = 50;
const OUTCOME = { started: 'Started', done: 'Done', failed: 'Refused or failed', read: 'Looked at' };
const ACTIONS = [['', 'Anything'], ['licence.create', 'Licence created'], ['licence.renew', 'Licence renewed'], ['licence.extend', 'Licence extended'], ['licence.suspend', 'Licence suspended'], ['licence.reinstate', 'Licence reinstated'], ['licence.cancel', 'Licence cancelled'],
  ['licence.revoke', 'Licence revoked'], ['licence.block_machines', 'Machines blocked'], ['licence.unblock_machines', 'Machines unblocked'], ['block.lift', 'Block lifted'], ['domain.attach', 'Domain attached'],
  ['purchase_request.update', 'Licence request changed'], ['purchase_request.view', 'Licence request opened'], ['support_request.update', 'Help request changed'], ['support_request.note', 'Help request note'], ['support_request.view', 'Help request opened'],
  ['trial.extend', 'Trial extended'], ['user.create', 'Team member added'], ['user.update', 'Team member changed'], ['customer.view', 'Customer opened'], ['audit.list', 'Audit log opened'],
  ['licence.change', 'Licence seats or plan changed'], ['licence.release_seat', 'Seat released'], ['customer.update', 'Customer details changed'], ['customer.note', 'Customer note added'],
  ['customer_user.disable', 'Customer user disabled'], ['customer_user.enable', 'Customer user enabled'], ['customer_user.reinvite', 'Customer user re-invited'], ['customer_user.remove', 'Customer user removed'],
  ['user.send_link', 'Link emailed to a team member'], ['purchase_request.reply', 'Replied to a licence request'], ['support_request.reply', 'Replied to a help request'],
  ['report.export', 'Report downloaded'], ['customer_users.export', 'Customer users downloaded'], ['audit.export', 'Audit log downloaded']];

export async function renderAudit(page) {
  let action = '', outcome = '', subject = '', since = '', offset = 0;
  const csv = el('a', { class: 'button-link', href: '/v1/admin/audit.csv', download: '' }, 'Download CSV');
  mount(page, pageHeader('Audit log', 'Everything the team did, and who looked at customers\' details. Rows are kept for the retention period, and cannot be edited or deleted by anyone in the portal.', csv));
  const a = select(ACTIONS, action);
  const o = select([['', 'Any outcome'], ...Object.entries(OUTCOME)], outcome);
  const s = textInput({ placeholder: 'A reference such as PR-000123', maxlength: 100 });
  const d = el('input', { type: 'date' });
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, field('What', a).node, field('Outcome', o).node, field('About', s).node, field('Since', d).node), box);
  const change = () => { action = a.value; outcome = o.value; subject = s.value.trim(); since = d.value; offset = 0; load(); };
  a.addEventListener('change', change); o.addEventListener('change', change); d.addEventListener('change', change);
  let t; s.addEventListener('input', () => { clearTimeout(t); t = setTimeout(change, 400); });
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      csv.setAttribute('href', `/v1/admin/audit.csv${qs({ action, outcome, subject, since })}`);
      const r = await get(`/audit${qs({ action, outcome, subject, since, limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.entries.length) { mount(box, emptyState('Nothing matches')); return; }
      mount(box, table([
        { title: 'When', render: e => fmtDateTime(e.occurred_at) },
        { title: 'Who', render: e => e.actor_name || 'Someone who has left' },
        { title: 'What', render: e => (ACTIONS.find(x => x[0] === e.action) || [0, e.action])[1] },
        { title: 'About', render: e => el('code', {}, e.subject_ref || '—') },
        { title: 'Outcome', render: e => el('span', { class: `badge ${e.outcome === 'failed' ? 'bad' : e.outcome === 'done' ? 'good' : 'muted'}` }, OUTCOME[e.outcome] || e.outcome) },
        { title: 'Reason', render: e => e.reason || '—' },
        { title: 'Detail', render: e => el('span', { class: 'small muted' }, Object.entries(e.detail || {}).filter(([, v]) => v !== null && v !== false).map(([k, v]) => `${k}: ${v}`).join(', ') || '—') },
      ], r.entries, { caption: 'Audit log' }));
      if (r.entries.length === PAGE || offset) mount(box, el('div', { class: 'pager' }, offset ? el('button', { class: 'secondary', onclick: () => { offset -= PAGE; load(); } }, 'Newer') : null, r.entries.length === PAGE ? el('button', { class: 'secondary', onclick: () => { offset += PAGE; load(); } }, 'Older') : null));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
