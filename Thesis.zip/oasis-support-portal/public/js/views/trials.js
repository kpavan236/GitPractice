import { el, clear, pageHeader, badge, fmtDate, fmtDateTime, fmtRelativeDay, table, emptyState, loading, errorBox, field, select, mount, latest } from '../dom.js';
import { get, post, qs } from '../api.js';
import { askReason, toast } from '../dialogs.js';

const FLAGS = { weak_fingerprint: 'The machine could not be identified well, so this may be a repeat trial', many_first_trials_from_one_source: 'Many first trials came from the same place' };

export async function renderTrials(page, _params, ctx) {
  let status = 'ACTIVE', flagged = '';
  mount(page, pageHeader('Trials', 'People trying OASIS for the first time. You can give a trial more days. Machines are never shown here, only what the trial told us about the organisation.'));
  const st = select([['ACTIVE', 'Running'], ['EXPIRED', 'Ended'], ['CONVERTED', 'Became a licence'], ['', 'All']], status);
  const fl = select([['', 'Flagged or not'], ['true', 'Flagged for review'], ['false', 'Not flagged']], flagged);
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, field('Show', st).node, field('Review flags', fl).node), box);
  for (const s of [st, fl]) s.addEventListener('change', () => { status = st.value; flagged = fl.value; load(); });
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const r = await get(`/trials${qs({ status, flagged, limit: 100 })}`);
      if (!ok()) return;
      clear(box);
      if (!r.trials.length) { mount(box, emptyState('No trials match')); return; }
      mount(box, table([
        { title: 'Started', render: t => fmtDateTime(t.started_at) },
        { title: 'Status', render: t => badge('trial', t.status_code) },
        { title: 'Ends', render: t => el('div', {}, fmtDate(t.effective_expiry), el('div', { class: 'small muted' }, fmtRelativeDay(t.effective_expiry))) },
        { title: 'GitHub organisation', render: t => t.github_org || el('span', { class: 'muted' }, 'Not given') },
        { title: 'Computer', render: t => `${t.platform || '?'} ${t.arch || ''}` },
        { title: 'Flags', render: t => t.open_flags.length ? el('ul', { class: 'plain' }, t.open_flags.map(f => el('li', { class: 'small', title: FLAGS[f] || f }, FLAGS[f] || f))) : '—' },
        { title: '', class: 'actions', render: t => (t.status_code !== 'CONVERTED' && ctx.can('LICENSE_UPDATE')) ? el('button', { class: 'secondary', onclick: () => {
          let days;
          return askReason({ title: 'Extend trial', intro: t.has_ended ? 'This trial has ended. Extending it lets the person start again for the days you choose, counted from today.' : 'Adds days to the end of the trial.', submitLabel: 'Extend trial', placeholder: 'For example: the customer was away during their trial',
            extra: () => { days = el('input', { type: 'number', min: 1, max: 30, value: 7 }); return field('Extra days (1 to 30)', days); },
            run: async reason => { await post(`/trials/${t.trial_id}/extend`, { days: Number(days.value), reason }); } }).then(d => { if (d) { toast('Trial extended'); load(); } });
        } }, 'Extend') : '' },
      ], r.trials, { caption: 'Trials' }));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
