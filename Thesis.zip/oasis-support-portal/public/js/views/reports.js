import { el, pageHeader, loading, errorBox, clear, mount, LABELS, emptyState } from '../dom.js';
import { get } from '../api.js';
import { lineChart, barChart, donut, legend } from '../charts.js';

const RANGES = [[4, '4 weeks'], [12, '12 weeks'], [26, '26 weeks'], [52, '1 year']];
const pct = v => (v === null || v === undefined ? '—' : `${v}%`);
const label = (kind, code) => (LABELS[kind] && LABELS[kind][code]) || code;
const ORDER = { purchase: ['NEW', 'CONTACTED', 'AGREED', 'DECLINED', 'DUPLICATE'], help: ['NEW', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'], trial: ['ACTIVE', 'CONVERTED', 'EXPIRED'], licence: ['ACTIVE', 'PENDING_ACTIVATION', 'SUSPENDED', 'EXPIRED', 'CANCELLED'] };
const byStatus = (kind, counts) => ORDER[kind].map((code, i) => ({ label: label(kind, code), value: counts[code] || 0, tone: i }));

const panel = (title, hint, ...body) => el('section', { class: 'card panel' }, el('h2', {}, title, hint ? el('span', { class: 'h-hint' }, hint) : null), ...body);
const kpi = (name, value, note) => el('div', { class: 'stat calm kpi' }, el('span', { class: 'stat-label' }, name), el('span', { class: 'stat-value' }, String(value)), el('span', { class: 'stat-hint muted' }, note || ''));
const none = () => emptyState('Nothing yet', 'This fills in as requests and licences arrive.');
const sumOf = items => items.reduce((a, i) => a + i.value, 0);

/** Admin reports: how much work is coming in, where it stands, what is selling, and who holds what. Counts only. */
export async function renderReports(page, _params) {
  let weeks = 12;
  const chips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Time range' });
  const csv = el('a', { class: 'button-link', href: '/v1/admin/reports.csv?weeks=12', download: '' }, 'Download CSV');
  mount(page, pageHeader('Reports', 'How the support team and the licences are doing. Totals only: no customer names or messages.', chips, csv));
  const box = el('div'); mount(page, box);

  function drawChips() {
    csv.setAttribute('href', `/v1/admin/reports.csv?weeks=${weeks}`);
    clear(chips);
    for (const [n, name] of RANGES) mount(chips, el('button', { class: `chip${n === weeks ? ' on' : ''}`, 'aria-pressed': String(n === weeks), onclick: () => { weeks = n; drawChips(); load(); } }, name));
  }

  async function load() {
    clear(box); mount(box, loading());
    try {
      const r = await get(`/reports?weeks=${weeks}`);
      clear(box);
      const live = (r.licences.byStatus.ACTIVE || 0) + (r.licences.byStatus.PENDING_ACTIVATION || 0);
      const lr = byStatus('purchase', r.licenceRequests.byStatus), hr = byStatus('help', r.helpRequests.byStatus);
      const trialOutcome = byStatus('trial', r.trials.byStatus), plans = r.licences.byPlan.map(p => ({ label: p.label, value: p.n }));
      const series = [{ name: 'Licence requests', points: r.weekly.licenceRequests }, { name: 'Help requests', points: r.weekly.helpRequests }, { name: 'Trials started', points: r.weekly.trials }];
      const e = r.licences.expiring;
      mount(box,
        el('div', { class: 'stats kpis' },
          kpi('Licence requests, all time', r.licenceRequests.total, 'People who asked to buy'),
          kpi('Requests agreed', pct(r.licenceRequests.agreeRate), 'Of those agreed or declined'),
          kpi('Licences in use', live, `${r.licences.total} ever created`),
          kpi('Trials that became licences', pct(r.trials.conversionRate), `${r.trials.total} trials in all`),
          kpi('Average feedback rating', r.feedback.averageRating === null ? '—' : `${r.feedback.averageRating} / 5`, 'From rated feedback')),
        el('div', { class: 'grid-2' },
          panel(`Incoming work, last ${weeks} weeks`, 'New each week', legend(series), lineChart(series, { label: `New licence requests, help requests and trials for each of the last ${weeks} weeks` })),
          panel('Team workload', 'Open requests held now',
            r.workload.length ? el('div', { class: 'table-wrap flat' }, el('table', {}, el('thead', {}, el('tr', {}, ['Person', 'Licence', 'Help', 'Total'].map((t, i) => el('th', { scope: 'col', class: i ? 'num' : '' }, t)))),
              el('tbody', {}, r.workload.map(w => el('tr', {}, el('td', {}, w.name), el('td', { class: 'num' }, String(w.licenceRequests)), el('td', { class: 'num' }, String(w.helpRequests)), el('td', { class: 'num strong' }, String(w.licenceRequests + w.helpRequests))))))) : none())),
        el('div', { class: 'grid-3' },
          panel('Licence requests', 'Where they stand', sumOf(lr) ? barChart(lr, { label: 'Licence requests by status' }) : none()),
          panel('Help requests', 'Where they stand', sumOf(hr) ? barChart(hr, { label: 'Help requests by status' }) : none()),
          panel('Where requests come from', 'Licence requests by source', r.licenceRequests.bySource.length ? barChart(r.licenceRequests.bySource.map(s => ({ label: s.code, value: s.n })), { label: 'Licence requests by source' }) : none())),
        el('div', { class: 'grid-3' },
          panel('Licences in use by plan', null, plans.length ? donut(plans, { label: 'Licences in use by plan', centre: 'in use' }) : none()),
          panel('Licences ending soon', 'Time to renew', e.within30 + e.within60 + e.within90 ? barChart([{ label: 'Within 30 days', value: e.within30, tone: 1 }, { label: '31 to 60 days', value: e.within60, tone: 3 }, { label: '61 to 90 days', value: e.within90, tone: 0 }], { label: 'Licences ending in the next 90 days' }) : el('p', { class: 'muted' }, 'No licence ends in the next 90 days.')),
          panel('Trial outcomes', 'All trials', sumOf(trialOutcome) ? donut(trialOutcome, { label: 'Trials by outcome', centre: 'trials' }) : none())),
        el('div', { class: 'grid-2' },
          panel('Feedback by kind', 'All time', r.feedback.byCategory.length ? barChart(r.feedback.byCategory.map(c => ({ label: c.label, value: c.n })), { label: 'Feedback by kind' }) : none()),
          panel('Feedback ratings', 'Stars given', r.feedback.byRating.length ? barChart([1, 2, 3, 4, 5].map(n => ({ label: `${n} star${n === 1 ? '' : 's'}`, value: (r.feedback.byRating.find(x => x.rating === n) || { n: 0 }).n, tone: n - 1 })), { label: 'Feedback by star rating' }) : none())));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  drawChips();
  await load();
}
