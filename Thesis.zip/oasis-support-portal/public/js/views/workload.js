import { el, pageHeader, loading, errorBox, clear, mount, table, badge, emptyState, fmtWaiting, fmtDateTime, plural } from '../dom.js';
import { get } from '../api.js';

/** Who holds what, for the whole team: counts and ages only (no customer names or messages). A row opens that person's open requests. Everyone on the team can see it. */
export async function renderWorkload(page, { id }) { return id ? detail(page, id) : overview(page); }

async function overview(page) {
  mount(page, pageHeader('Workload', 'What each person holds right now, how long their oldest open request has waited, and what they finished in the last 7 days.'));
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    try {
      const { people } = await get('/workload');
      clear(box);
      const total = people.reduce((a, p) => a + p.open, 0);
      if (!total && people.length <= 1) { mount(box, emptyState('Nothing open', 'Every request has been worked.')); }
      mount(box, el('p', { class: 'small muted' }, `${plural(total, 'open request')} across the team.`),
        table([
          { title: 'Person', render: p => el('a', { href: `#/workload/${p.id || 'none'}` }, p.name) },
          { title: 'Licence requests', class: 'num', render: p => String(p.licenceRequests) },
          { title: 'Help requests', class: 'num', render: p => String(p.helpRequests) },
          { title: 'Open in all', class: 'num', render: p => el('strong', {}, String(p.open)) },
          { title: 'Oldest waiting', render: p => (p.oldestOpenHours === null ? '—' : fmtWaiting(p.oldestOpenHours)) },
          { title: 'Finished, last 7 days', class: 'num', render: p => String(p.closedLast7Days) },
        ], people, { caption: 'Workload per person', onRow: p => { location.hash = `#/workload/${p.id || 'none'}`; } }));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}

async function detail(page, id) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let w;
    try { w = await get(`/workload/${encodeURIComponent(id)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Person not found') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${w.name} · Workload · OASIS Support Portal`;
    const list = (rows, kind, path) => (rows.length
      ? table([{ title: 'Reference', render: r => el('a', { href: `#/${path}/${r.reference}` }, r.reference) }, { title: 'Status', render: r => badge(kind, r.status_code) }, { title: 'Received', render: r => fmtDateTime(r.created_at) }, { title: 'Waiting', render: r => fmtWaiting((Date.now() - new Date(r.created_at).getTime()) / 3_600_000) }], rows, { caption: kind === 'purchase' ? 'Licence requests' : 'Help requests' })
      : el('p', { class: 'muted' }, 'None open.'));
    mount(box,
      el('p', { class: 'crumbs' }, el('a', { href: '#/workload' }, '← Workload')),
      pageHeader(w.name, `${plural(w.licenceRequests.length + w.helpRequests.length, 'open request')}${w.licenceRequests.length === 100 || w.helpRequests.length === 100 ? ' (the first 100 of each are shown)' : ''}`),
      el('div', { class: 'cols' },
        el('section', { class: 'card' }, el('h2', {}, 'Licence requests'), list(w.licenceRequests, 'purchase', 'licence-requests')),
        el('section', { class: 'card' }, el('h2', {}, 'Help requests'), list(w.helpRequests, 'help', 'help-requests'))));
  }
  await load();
}
