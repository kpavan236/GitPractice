import { replyDialog, repliesSection } from '../replies.js';
import { el, clear, pageHeader, badge, fmtDate, fmtDateTime, fmtWaiting, table, emptyState, loading, errorBox, field, select, mount, mailtoHref, latest, theirs } from '../dom.js';
import { get, patch, post, qs } from '../api.js';
import { askReason, openDialog, toast, guarded } from '../dialogs.js';

const FILTERS = [['open', 'Open', 'NEW,IN_PROGRESS'], ['answered', 'Answered', 'RESOLVED'], ['closed', 'Closed', 'CLOSED'], ['all', 'All', '']];
const PAGE = 50;
const NEXT = {
  NEW: [['IN_PROGRESS', 'Start working on it', 'You are looking into it.'], ['RESOLVED', 'Mark as answered', 'You have replied to the person.'], ['CLOSED', 'Close', 'Nothing more to do.']],
  IN_PROGRESS: [['RESOLVED', 'Mark as answered', 'You have replied to the person.'], ['CLOSED', 'Close', 'Nothing more to do.']],
  RESOLVED: [['IN_PROGRESS', 'Reopen', 'The person wrote back or it needs more work.'], ['CLOSED', 'Close', 'Nothing more to do.']],
};

export async function renderHelpRequests(page, { id }, ctx) { return id ? detail(page, id, ctx) : list(page, ctx); }

async function list(page, ctx) {
  let filter = 'open', who = 'everyone', offset = 0;
  mount(page, pageHeader('Help requests', 'People who used Contact support in the app. Reply from your own email, then record it here.'));
  const chips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Show' });
  // Admins can also look at one person's work: that is how they track who has what.
  let people = [];
  if (ctx.can('REQUEST_ASSIGN')) { try { people = (await get('/users')).users.filter(u => u.status === 'ACTIVE'); } catch (_) { /* the filter is a convenience */ } }
  const whoSelect = select([['everyone', 'Everyone\'s requests'], ['me', 'Assigned to me'], ['none', 'Not assigned'], ...people.map(u => [u.id, `Assigned to ${u.displayName || u.email}`])], who);
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, chips, field('Show', whoSelect).node), box);
  const drawChips = () => { clear(chips); for (const [key, label] of FILTERS) mount(chips, el('button', { class: `chip ${key === filter ? 'on' : ''}`, 'aria-pressed': String(key === filter), onclick: () => { filter = key; offset = 0; drawChips(); load(); } }, label)); };
  whoSelect.addEventListener('change', () => { who = whoSelect.value; offset = 0; load(); });
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const status = FILTERS.find(f => f[0] === filter)[2];
      const r = await get(`/support-requests${qs({ status, assignedTo: who === 'everyone' ? '' : who, limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.supportRequests.length) { mount(box, emptyState('Nothing here', 'No help requests match.')); return; }
      mount(box, table([
        { title: 'Reference', render: s => el('a', { href: `#/help-requests/${s.reference}` }, s.reference) },
        { title: 'Subject', render: s => el('strong', {}, theirs(s.subject)) },
        { title: 'From', render: s => el('div', {}, theirs(s.contact_name), el('div', { class: 'small muted' }, s.email)) },
        { title: 'Status', render: s => badge('help', s.status_code) },
        { title: 'Assigned to', render: s => s.assigned_to_name || el('span', { class: 'muted' }, 'Nobody') },
        { title: 'Notes', render: s => String(s.notes) },
        { title: 'Waiting', render: s => (s.is_closed ? '—' : fmtWaiting(s.hours_open_or_to_close)) },
      ], r.supportRequests, { caption: 'Help requests', onRow: s => ctx.go(`help-requests/${s.reference}`) }));
      if (r.supportRequests.length === PAGE) mount(box, el('div', { class: 'pager' }, offset ? el('button', { class: 'secondary', onclick: () => { offset -= PAGE; load(); } }, 'Previous') : null, el('button', { class: 'secondary', onclick: () => { offset += PAGE; load(); } }, 'Next')));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  drawChips();
  await load();
}

async function detail(page, reference, ctx) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let r;
    try { r = await get(`/support-requests/${encodeURIComponent(reference)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Help request not found', 'It may have been mistyped.') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${r.reference} · OASIS Support Portal`;
    const moves = NEXT[r.status_code] || [];
    const noteInput = el('textarea', { rows: 3, maxlength: 4000, placeholder: 'What did you tell them? What did you find?' });
    const noteButton = el('button', { class: 'secondary', onclick: async () => {
      const text = noteInput.value.trim();
      if (!text) return;
      noteButton.disabled = true;
      try { await post(`/support-requests/${r.reference}/notes`, { body: text }); toast('Note added'); load(); }
      catch (err) { toast(err.message, 'bad'); noteButton.disabled = false; }
    } }, 'Add note');

    const linkButton = el('button', { class: 'secondary', onclick: async () => {
      let q, results = el('div'), chosen = null;
      const done = await openDialog({ title: 'Link to a customer', intro: 'So the customer\'s page shows this request.', submitLabel: 'Link', wide: true,
        build: () => {
          q = el('input', { type: 'search', placeholder: 'Search by customer name or email domain', 'aria-label': 'Search customers' });
          const run = async () => {
            clear(results);
            if (q.value.trim().length < 2) return;
            const { customers } = await get(`/customers${qs({ q: q.value.trim(), limit: 10 })}`);
            if (!customers.length) mount(results, el('p', { class: 'muted' }, 'No customers found.'));
            for (const c of customers) mount(results, el('label', { class: 'pick' }, el('input', { type: 'radio', name: 'cust', onchange: () => { chosen = c; } }), ` ${c.name}`));
          };
          let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => run().catch(() => {}), 250); });
          return el('div', {}, q, results);
        },
        onSubmit: async () => { if (!chosen) throw new Error('Choose a customer.'); await patch(`/support-requests/${r.reference}`, { customerRef: chosen.customer_id, reason: `Linked to ${chosen.name}` }); } });
      if (done) { toast('Linked'); load(); }
    } }, r.customer_ref ? 'Change customer' : 'Link to a customer');

    let assign = null;
    if (ctx.can('REQUEST_ASSIGN')) {
      assign = el('button', { class: 'secondary', onclick: guarded(async () => {
        const { users } = await get('/users');
        let pick;
        const done = await openDialog({ title: 'Assign request', intro: `${r.reference}: ${r.subject}`, submitLabel: 'Assign',
          build: () => { pick = select([['', 'Nobody'], ...users.filter(u => u.status === 'ACTIVE').map(u => [u.id, `${u.displayName || u.email} (${u.role})`])], r.assigned_to_user_id || ''); return field('Assign to', pick).node; },
          onSubmit: async () => { await patch(`/support-requests/${r.reference}`, { assignedTo: pick.value || null, reason: pick.value ? 'Assigned' : 'Unassigned' }); } });
        if (done) { toast('Assignment saved'); load(); }
      }) }, r.assigned_to_name ? 'Change' : 'Assign');
    }

    mount(box, 
      el('p', { class: 'crumbs' }, el('a', { href: '#/help-requests' }, '← Help requests')),
      pageHeader(theirs(r.subject), `${r.reference} · received ${fmtDateTime(r.created_at)}`, badge('help', r.status_code)),
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'From ', theirs(r.contact_name)),
            el('p', { class: 'action-row' }, ctx.can('SUPPORT_REQUEST_UPDATE') ? el('button', { class: 'primary', onclick: async () => { if (await replyDialog({ path: `/support-requests/${encodeURIComponent(r.reference)}`, to: r.email, defaultSubject: `Re: ${r.subject}` })) load(); } }, 'Reply from the portal') : null, el('a', { class: 'button-link', href: mailtoHref(r.email, `Re: ${r.subject} [${r.reference}]`) }, `Or write from your own email to ${r.email}`)),
            el('div', { class: 'message', lang: 'en' }, r.message),
            el('p', { class: 'small muted' }, `App version ${r.app_version || 'unknown'}. This is what the person wrote: it is shown as plain text.`)),
          repliesSection(r.replies),
          el('section', { class: 'card' }, el('h2', {}, 'Notes'),
            r.notes.length ? el('ul', { class: 'notes' }, r.notes.map(n => el('li', {}, el('div', { class: 'note-body' }, n.body), el('div', { class: 'small muted' }, `${n.author_name || 'Someone who has left'} · ${fmtDateTime(n.created_at)}`)))) : el('p', { class: 'muted' }, 'No notes yet.'),
            r.status_code === 'CLOSED' ? null : el('div', {}, field('Add a note', noteInput).node, noteButton))),
        el('aside', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'Status'),
            el('p', {}, badge('help', r.status_code), r.is_closed ? '' : ` waiting ${fmtWaiting((Date.now() - new Date(r.created_at).getTime()) / 3_600_000)}`),
            moves.length ? el('div', { class: 'stack' }, moves.map(([to, label, hint]) => el('button', { class: 'secondary', onclick: () => askReason({
              title: label, intro: hint, submitLabel: label, placeholder: 'For example: replied by email with the steps',
              run: async reason => { await patch(`/support-requests/${r.reference}`, { status: to, reason }); },
            }).then(done => { if (done) { toast(`${r.reference} updated`); load(); } }) }, label))) : el('p', { class: 'muted' }, 'This request is closed.')),
          el('section', { class: 'card' }, el('h2', {}, 'Assigned to'), el('p', {}, r.assigned_to_name || el('span', { class: 'muted' }, 'Nobody yet')), assign,
            !ctx.can('REQUEST_ASSIGN') ? el('p', { class: 'small muted' }, 'Only an admin can assign requests.') : null),
          ctx.can('SUPPORT_REQUEST_UPDATE') ? el('section', { class: 'card' }, el('h2', {}, 'Customer'),
            r.customer_ref ? el('p', {}, el('a', { href: `#/customers/${r.customer_ref}` }, 'View the customer')) : el('p', { class: 'muted' }, 'Not linked to a customer.'), linkButton) : null,
          el('section', { class: 'card' }, el('h2', {}, 'History'),
            el('ol', { class: 'timeline' }, r.history.map(h => el('li', {}, el('strong', {}, h.to_status_code === 'NEW' && !h.from_status_code ? 'Received' : (({ IN_PROGRESS: 'In progress', RESOLVED: 'Answered', CLOSED: 'Closed', NEW: 'Back to new' })[h.to_status_code])),
              el('div', { class: 'small muted' }, `${fmtDateTime(h.changed_at)}${h.changed_by_name ? ` · ${h.changed_by_name}` : ''}`), h.reason && h.reason !== 'Submitted' ? el('div', { class: 'small' }, h.reason) : null)))))));
  }
  await load();
}
