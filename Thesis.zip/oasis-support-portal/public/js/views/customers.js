import { el, clear, pageHeader, badge, fmtDate, fmtDateTime, table, emptyState, loading, errorBox, field, select, textInput, plural, mount, latest, theirs } from '../dom.js';
import { get, post, patch, qs } from '../api.js';
import { openDialog, toast } from '../dialogs.js';
import { createLicenceFlow } from '../licence-form.js';

export async function renderCustomers(page, { id }, ctx) { return id ? detail(page, id, ctx) : list(page, ctx); }

async function list(page, ctx) {
  mount(page, pageHeader('Customers', 'Organisations that have a licence or have been through a licence request.'));
  const q = el('input', { type: 'search', placeholder: 'Search by name or email domain', 'aria-label': 'Search customers' });
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, field('Search', q).node), box);
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const term = q.value.trim();
      if (term && term.length < 2) { clear(box); mount(box, emptyState('Keep typing', 'Search needs at least 2 characters.')); return; }
      const r = await get(`/customers${qs({ q: term, limit: 50 })}`);
      if (!ok()) return;
      clear(box);
      if (!r.customers.length) { mount(box, emptyState('No customers found', term ? 'Try a different name or domain.' : 'Customers appear when you create a licence.')); return; }
      mount(box, table([
        { title: 'Customer', render: c => el('a', { href: `#/customers/${c.customer_id}` }, theirs(c.name)) },
        { title: 'Licences', render: c => `${c.live_licences} in use of ${c.licences}` },
        { title: 'Email domains', render: c => String(c.domains) },
        { title: 'Since', render: c => fmtDate(c.created_at) },
      ], r.customers, { caption: 'Customers', onRow: c => ctx.go(`customers/${c.customer_id}`) }));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(load, 300); });
  await load();
}

async function detail(page, id, ctx) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let c;
    try { c = await get(`/customers/${encodeURIComponent(id)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Customer not found') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${c.name} · OASIS Support Portal`;
    const attach = el('button', { class: 'secondary', onclick: async () => {
      let domain, reason;
      const done = await openDialog({ title: 'Attach an email domain', intro: `So anyone with a work address at ${c.name} can activate OASIS.`, submitLabel: 'Attach domain',
        build: () => { domain = el('input', { type: 'text', maxlength: 253, placeholder: 'company.com', spellcheck: 'false' }); reason = el('textarea', { rows: 2, maxlength: 500, required: true }); reason.value = 'Domain confirmed with the customer';
          return el('div', {}, field('Domain', domain, 'Check with the customer that this domain is theirs. Public providers such as gmail.com are not allowed.').node, field('Reason (kept on the record with your name)', reason).node); },
        onSubmit: async () => { if (!reason.value.trim()) throw new Error('Please give a reason.'); await post('/domains', { customerId: c.customer_id, domain: domain.value.trim().toLowerCase(), reason: reason.value.trim() }); } });
      if (done) { toast('Domain attached'); load(); }
    } }, 'Attach a domain');
    const editDetails = ctx.can('CUSTOMER_MANAGE') ? el('button', { class: 'secondary', onclick: async () => {
      let opts = { industries: [], sizeBands: [], countries: [] };
      try { opts = await get('/customer-options'); } catch { /* the lists stay empty */ }
      let name, legal, website, industry, size, country, zone, reason;
      const withNone = (list, current) => select([['', 'Not set'], ...list.map(o => [o.code, o.label])], current || '');
      const done = await openDialog({ title: 'Edit customer details', intro: 'Correct what we hold about this customer. The customer\'s status (prospect, active, churned) is not changed here.', submitLabel: 'Save', wide: true,
        build: () => {
          name = textInput({ maxlength: 200, value: c.name, required: true }); legal = textInput({ maxlength: 200, value: c.legal_name || '' }); website = textInput({ maxlength: 300, value: c.website || '', placeholder: 'Their web address, starting with http or https' });
          industry = withNone(opts.industries, c.industry_code); size = withNone(opts.sizeBands, c.size_band_code); country = withNone(opts.countries, c.country_code); zone = textInput({ maxlength: 64, value: c.timezone || 'UTC', placeholder: 'Europe/London' });
          reason = el('textarea', { rows: 2, maxlength: 500, required: true });
          return el('div', {}, field('Name', name).node, field('Legal name', legal).node, field('Website', website).node, el('div', { class: 'row' }, field('Industry', industry).node, field('Size', size).node), el('div', { class: 'row' }, field('Country', country).node, field('Time zone', zone).node), field('Reason (kept on the record with your name)', reason).node);
        },
        onSubmit: async () => {
          if (!reason.value.trim()) throw new Error('Please give a reason.');
          return patch(`/customers/${c.customer_id}`, { reason: reason.value.trim(), name: name.value.trim(), legalName: legal.value.trim() || null, website: website.value.trim() || null, industry: industry.value || null, sizeBand: size.value || null, country: country.value || null, timezone: zone.value.trim() });
        } });
      if (done) { toast('Customer details saved'); load(); }
    } }, 'Edit details') : null;
    const noteInput = el('textarea', { rows: 3, maxlength: 4000, 'aria-label': 'Add a note about this customer', placeholder: 'For example: wants 3 more seats in March; asked for an invoice' });
    const noteButton = el('button', { class: 'secondary', onclick: async () => {
      if (!noteInput.value.trim()) return;
      noteButton.disabled = true;
      try { await post(`/customers/${c.customer_id}/notes`, { body: noteInput.value }); toast('Note added'); load(); }
      catch (err) { toast(err.message, 'bad'); noteButton.disabled = false; }
    } }, 'Add note');
    mount(box, 
      el('p', { class: 'crumbs' }, el('a', { href: '#/customers' }, '← Customers')),
      pageHeader(theirs(c.name), `Customer since ${fmtDate(c.created_at)}`, editDetails, ctx.can('LICENSE_ACTIVATE') ? el('button', { class: 'primary', onclick: async () => { if (await createLicenceFlow(ctx, { customer: { id: c.customer_id, name: c.name } })) load(); } }, 'Create a licence') : null),
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'Details'),
            el('dl', { class: 'facts' },
              el('dt', {}, 'Legal name'), el('dd', {}, c.legal_name ? theirs(c.legal_name) : '—'),
              el('dt', {}, 'Website'), el('dd', {}, c.website ? el('a', { href: c.website, rel: 'noopener noreferrer', target: '_blank' }, c.website) : '—'),
              el('dt', {}, 'Industry'), el('dd', {}, c.industry_code || '—'), el('dt', {}, 'Size'), el('dd', {}, c.size_band_code || '—'),
              el('dt', {}, 'Country'), el('dd', {}, c.country_code || '—'), el('dt', {}, 'Time zone'), el('dd', {}, c.timezone || '—'))),
          el('section', { class: 'card' }, el('h2', {}, 'Licences'),
            c.licences.length ? table([
              { title: 'Plan', render: l => el('a', { href: `#/licences/${l.license_id}` }, l.plan_code) }, { title: 'Status', render: l => badge('licence', l.status_code) },
              { title: 'Seats', render: l => `${l.seats_in_use} of ${l.seat_limit === null ? 'unlimited' : l.seat_limit}` }, { title: 'Ends', render: l => fmtDate(l.expires_at) },
            ], c.licences, { caption: 'Licences' }) : el('p', { class: 'muted' }, 'No licences yet.')),
          el('section', { class: 'card' }, el('h2', {}, 'Requests from this customer'),
            c.purchaseRequests.length || c.supportRequests.length ? el('ul', { class: 'plain' },
              c.purchaseRequests.map(p => el('li', {}, el('a', { href: `#/licence-requests/${p.reference}` }, p.reference), ' ', badge('purchase', p.status_code), ` ${p.organization_name}, ${fmtDate(p.created_at)}`)),
              c.supportRequests.map(s => el('li', {}, el('a', { href: `#/help-requests/${s.reference}` }, s.reference), ' ', badge('help', s.status_code), ` ${s.subject}, ${fmtDate(s.created_at)}`))) : el('p', { class: 'muted' }, 'None linked.'))),
        el('aside', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'Notes'),
            c.notes && c.notes.length ? el('ul', { class: 'notes' }, c.notes.map(n => el('li', {}, el('div', { class: 'note-body' }, n.body), el('div', { class: 'small muted' }, `${n.by || 'Someone who has left'} · ${fmtDateTime(n.createdAt)}`)))) : el('p', { class: 'muted' }, 'No notes yet.'),
            ctx.can('CUSTOMER_UPDATE') ? el('div', {}, noteInput, noteButton) : null),
          el('section', { class: 'card' }, el('h2', {}, 'Email domains'),
            c.domains.length ? el('ul', { class: 'plain' }, c.domains.map(d => el('li', {}, el('code', {}, `@${d.domain}`), d.verified_at ? '' : ' (not verified)'))) : el('p', { class: 'muted' }, 'None. Without a domain, the customer cannot activate OASIS by work email.'),
            ctx.can('DOMAIN_ATTACH') ? attach : el('p', { class: 'small muted' }, 'You do not have permission to attach a domain.')))));
  }
  await load();
}
