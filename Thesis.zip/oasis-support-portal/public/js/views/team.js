import { el, clear, pageHeader, badge, fmtDateTime, table, emptyState, loading, errorBox, field, textInput, select, mount } from '../dom.js';
import { get, post, patch } from '../api.js';
import { askReason, openDialog, toast } from '../dialogs.js';

export async function renderTeam(page, _params, ctx) {
  mount(page, pageHeader('Team', 'Who can sign in to the portal. A new person gets an email with a link to activate their account and choose a password. You never see or set a password for anyone.',
    el('button', { class: 'primary', onclick: addMember }, 'Add a team member')));
  const notice = el('p', { class: 'notice warn', role: 'status', hidden: true }, 'Email is not connected yet (test mode), so activation and reset links are not delivered. Ask whoever runs the portal for the link.');
  get('/auth/config').then(c => { if (c.emailDelivery !== 'live') notice.hidden = false; }).catch(() => {});
  const box = el('div'); mount(page, notice, box);
  const sentToast = (r, what) => toast(r && r.emailed === false ? `${what} could not be sent. Try again from the Team list.` : what, r && r.emailed === false ? 'bad' : 'good');

  async function addMember() {
    let email, name, role, reason;
    const done = await openDialog({ title: 'Add a team member', intro: 'We email them an activation link (it works for 3 days). They open it, choose a password and confirm it, and then their account is active. Until then it shows as Pending activation.', submitLabel: 'Add',
      build: () => {
        email = textInput({ type: 'email', required: true, placeholder: 'name@company.com', autocomplete: 'off' });
        name = textInput({ maxlength: 150, required: true });
        role = select([['user', 'User: works customer requests'], ['admin', 'Admin: also assigns requests, manages the team, and can suspend or cancel licences']], 'user');
        reason = el('textarea', { rows: 2, maxlength: 500, required: true }); reason.value = 'Joined the support team';
        return el('div', {}, field('Work email address', email).node, field('Name', name).node, field('Role', role).node, field('Reason (kept on the record with your name)', reason).node);
      },
      onSubmit: async () => {
        if (!reason.value.trim()) throw new Error('Please give a reason.');
        return post('/users', { email: email.value.trim(), displayName: name.value.trim(), role: role.value, reason: reason.value.trim() });
      } });
    if (done) { sentToast(done, `Activation link sent to ${done.email}`); load(); }
  }

  async function load() {
    clear(box); mount(box, loading());
    try {
      const { users } = await get('/users');
      clear(box);
      if (!users.length) { mount(box, emptyState('No team members')); return; }
      mount(box, table([
        { title: 'Name', render: u => el('div', {}, el('strong', {}, u.displayName || '—'), u.email === ctx.me.email ? ' (you)' : '', el('div', { class: 'small muted' }, u.email)) },
        { title: 'Role', render: u => el('span', { class: `badge ${u.role === 'admin' ? 'info' : 'muted'}` }, u.role === 'admin' ? 'Admin' : 'User') },
        { title: 'Status', render: u => badge('user', u.status) },
        { title: 'Last signed in', render: u => (u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : 'Never') },
        { title: '', class: 'actions', render: u => {
          if (u.email === ctx.me.email) return '';
          return el('div', { class: 'row-actions' },
            el('button', { class: 'secondary', onclick: async () => {
              let name, email, reason;
              const done = await openDialog({ title: `Edit ${u.displayName || u.email}`, intro: 'Correct their name or work email address. If you change the address they are signed out, and a person who has not activated yet gets a new activation link at the new address.', submitLabel: 'Save',
                build: () => {
                  name = textInput({ maxlength: 150, value: u.displayName || '', required: true }); email = textInput({ type: 'email', value: u.email, required: true, autocomplete: 'off' });
                  reason = el('textarea', { rows: 2, maxlength: 500, required: true }); reason.value = 'Corrected their details';
                  return el('div', {}, field('Name', name).node, field('Work email address', email).node, field('Reason (kept on the record with your name)', reason).node);
                },
                onSubmit: async () => {
                  if (!reason.value.trim()) throw new Error('Please give a reason.');
                  const body = { reason: reason.value.trim() };
                  if (name.value.trim() !== (u.displayName || '')) body.displayName = name.value.trim();
                  if (email.value.trim().toLowerCase() !== u.email) body.email = email.value.trim();
                  if (body.displayName === undefined && body.email === undefined) throw new Error('Change the name or the address first.');
                  return patch(`/users/${u.id}`, body);
                } });
              if (done) { sentToast(done, 'Saved'); load(); }
            } }, 'Edit'),
            el('button', { class: 'secondary', onclick: () => {
              const to = u.role === 'admin' ? 'user' : 'admin';
              return askReason({ title: `Make ${u.displayName || u.email} ${to === 'admin' ? 'an admin' : 'a user'}`, intro: 'They will be signed out and need to sign in again for it to take effect.', submitLabel: 'Change role', placeholder: 'Why are you changing the role?',
                run: async reason => { await patch(`/users/${u.id}`, { role: to, reason }); } }).then(d => { if (d) { toast('Role changed'); load(); } });
            } }, u.role === 'admin' ? 'Make user' : 'Make admin'),
            u.status === 'ACTIVE' || u.status === 'INVITED' ? el('button', { class: 'secondary', onclick: () => {
              const pendingUser = u.status === 'INVITED';
              return askReason({ title: pendingUser ? `Resend the activation link to ${u.displayName || u.email}` : `Send a password reset link to ${u.displayName || u.email}`,
                intro: pendingUser ? 'A new link is emailed and the earlier one stops working.' : 'We email them a link, valid for 1 hour, where they choose a new password. Their current password keeps working until they do. You do not see the link.',
                submitLabel: 'Send link', placeholder: pendingUser ? 'For example: they did not get the first email' : 'For example: they forgot their password',
                run: async reason => post(`/users/${u.id}/send-link`, { reason }) }).then(d => { if (d) { sentToast(d, pendingUser ? 'Activation link sent' : 'Password reset link sent'); load(); } });
            } }, u.status === 'INVITED' ? 'Resend activation link' : 'Send reset link') : null,
            el('button', { class: u.status === 'DISABLED' ? 'secondary' : 'danger', onclick: () => {
              const deactivating = u.status !== 'DISABLED';
              return askReason({ title: `${deactivating ? 'Deactivate' : 'Activate'} ${u.displayName || u.email}`, intro: deactivating ? 'They are signed out at once and cannot sign in until you activate them again. Any link we sent them stops working.' : 'They can sign in again. If they never chose a password, we email them a new activation link.', submitLabel: deactivating ? 'Deactivate' : 'Activate', danger: deactivating, placeholder: deactivating ? 'For example: left the team' : 'For example: back from leave',
                run: async reason => (await patch(`/users/${u.id}`, { status: deactivating ? 'DISABLED' : 'ACTIVE', reason })) }).then(d => { if (d) { sentToast(d, deactivating ? 'Deactivated' : (d.status === 'INVITED' ? 'Activated: they must choose a password, link sent' : 'Activated')); load(); } });
            } }, u.status === 'DISABLED' ? 'Activate' : 'Deactivate'));
        } },
      ], users, { caption: 'Team members' }));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
