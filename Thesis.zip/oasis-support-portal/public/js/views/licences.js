import { el, clear, pageHeader, badge, fmtDate, fmtDateTime, fmtRelativeDay, table, emptyState, loading, errorBox, field, select, plural, mount, latest } from '../dom.js';
import { get, post, qs } from '../api.js';
import { askReason, askTypedConfirm, openDialog, toast } from '../dialogs.js';

const FILTERS = [['live', 'In use', 'ACTIVE,PENDING_ACTIVATION'], ['suspended', 'Suspended', 'SUSPENDED'], ['ended', 'Ended or cancelled', 'EXPIRED,CANCELLED'], ['all', 'All', '']];
const PAGE = 50;

export async function renderLicences(page, { id }, ctx) { return id ? detail(page, id, ctx) : list(page, ctx); }

async function list(page, ctx) {
  let filter = 'live', offset = 0;
  mount(page, pageHeader('Licences', 'Every licence you have issued.'));
  const chips = el('div', { class: 'chips', role: 'group', 'aria-label': 'Show' });
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, chips), box);
  const drawChips = () => { clear(chips); for (const [key, label] of FILTERS) mount(chips, el('button', { class: `chip ${key === filter ? 'on' : ''}`, 'aria-pressed': String(key === filter), onclick: () => { filter = key; offset = 0; drawChips(); load(); } }, label)); };
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const r = await get(`/licenses${qs({ status: FILTERS.find(f => f[0] === filter)[2], limit: PAGE, offset })}`);
      if (!ok()) return;
      clear(box);
      if (!r.licences.length) { mount(box, emptyState('No licences here', 'Licences appear when you create them from an agreed licence request.')); return; }
      mount(box, table([
        { title: 'Customer', render: l => el('a', { href: `#/licences/${l.license_id}` }, l.customer_name || 'Unknown customer') },
        { title: 'Plan', render: l => l.plan_code },
        { title: 'Status', render: l => badge('licence', l.status_code) },
        { title: 'Seats used', render: l => `${l.seats_in_use} of ${l.seat_limit === null ? 'unlimited' : l.seat_limit}` },
        { title: 'Ends', render: l => el('div', {}, fmtDate(l.expires_at), el('div', { class: 'small muted' }, fmtRelativeDay(l.expires_at))) },
        { title: 'Key ends', render: l => el('code', {}, `…${l.key_hint}`) },
      ], r.licences, { caption: 'Licences', onRow: l => ctx.go(`licences/${l.license_id}`) }));
      if (r.licences.length === PAGE) mount(box, el('div', { class: 'pager' }, offset ? el('button', { class: 'secondary', onclick: () => { offset -= PAGE; load(); } }, 'Previous') : null, el('button', { class: 'secondary', onclick: () => { offset += PAGE; load(); } }, 'Next')));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  drawChips();
  await load();
}

async function detail(page, id, ctx) {
  const box = el('div'); mount(page, box); mount(box, loading());
  async function load() {
    let l;
    try { l = await get(`/licenses/${encodeURIComponent(id)}`); }
    catch (err) { clear(box); mount(box, err.status === 404 ? emptyState('Licence not found') : errorBox(err, load)); return; }
    clear(box);
    document.title = `${l.customer ? l.customer.name : 'Licence'} · OASIS Support Portal`;
    const refresh = done => { if (done) load(); };
    const ended = ['CANCELLED'].includes(l.status_code);
    const buttons = [];

    if (!ended && ctx.can('LICENSE_ACTIVATE')) buttons.push(el('button', { class: 'primary', onclick: () => {
      let days, ref, reasonBox;
      return openDialog({ title: 'Renew licence', intro: `${l.customer ? l.customer.name : 'This licence'}: adds a new paid term after the current one.`, submitLabel: 'Renew',
        build: () => { days = el('input', { type: 'number', min: 1, max: 3650, value: 365 }); ref = el('input', { type: 'text', maxlength: 100, placeholder: 'PO or invoice number (optional)' });
          reasonBox = el('textarea', { rows: 2, maxlength: 500, required: true }); reasonBox.value = 'Renewed';
          return el('div', {}, field('Length in days', days).node, field('Reference', ref).node, field('Reason (kept on the record with your name)', reasonBox).node); },
        onSubmit: async () => {
          const body = { reason: reasonBox.value.trim(), termDays: Number(days.value) };
          if (ref.value.trim()) body.reference = ref.value.trim();
          if (!body.reason) throw new Error('Please give a reason.');
          await post(`/licenses/${l.license_id}/renew`, body);
        } }).then(d => { if (d) toast('Licence renewed'); refresh(d); });
    } }, 'Renew'));
    if (!ended && ctx.can('LICENSE_MODIFY')) buttons.push(el('button', { class: 'secondary', onclick: async () => {
      let plans = [];
      try { plans = (await get('/plans')).plans; } catch { /* the form still offers the current plan */ }
      let seats, plan, unlimited, reasonBox;
      return openDialog({ title: 'Change seats or plan', intro: `${l.customer ? l.customer.name : 'This licence'}: ${l.seats_in_use} seats are in use. Seats cannot go below that: release some first. A new plan replaces the features the old plan included.`, submitLabel: 'Save changes',
        build: () => {
          seats = el('input', { type: 'number', min: Math.max(1, l.seats_in_use), max: 100000, value: l.seat_limit === null ? '' : l.seat_limit, disabled: l.seat_limit === null });
          unlimited = el('input', { type: 'checkbox', checked: l.seat_limit === null, disabled: l.kind_code !== 'enterprise' });
          unlimited.addEventListener('change', () => { seats.disabled = unlimited.checked; });
          plan = select([...new Map([[l.plan_code, l.plan_label], ...plans.map(p => [p.plan_code, p.label])])].map(([c, n]) => [c, n]), l.plan_code);
          reasonBox = el('textarea', { rows: 2, maxlength: 500, required: true });
          return el('div', {}, field('Seats', seats).node, l.kind_code === 'enterprise' ? el('label', { class: 'check' }, unlimited, ' Unlimited seats') : null, field('Plan', plan).node, field('Reason (kept on the record with your name)', reasonBox).node);
        },
        onSubmit: async () => {
          const body = { reason: reasonBox.value.trim() };
          if (!body.reason) throw new Error('Please give a reason.');
          const wantSeats = unlimited.checked ? null : Number(seats.value);
          if (wantSeats !== l.seat_limit) body.seats = wantSeats;
          if (plan.value !== l.plan_code) body.plan = plan.value;
          if (body.seats === undefined && body.plan === undefined) throw new Error('Change the seats or the plan first.');
          await post(`/licenses/${l.license_id}/change`, body);
        } }).then(d => { if (d) toast('Licence changed'); refresh(d); });
    } }, 'Change seats or plan'));
    if (!ended && ctx.can('LICENSE_UPDATE')) buttons.push(el('button', { class: 'secondary', onclick: () => {
      let days;
      return askReason({ title: 'Give extra days', intro: 'A goodwill extension (up to 90 days), for example while a renewal is being processed.', submitLabel: 'Extend', placeholder: 'Why are you extending?',
        extra: () => { days = el('input', { type: 'number', min: 1, max: 90, value: 14 }); return field('Extra days (1 to 90)', days); },
        run: async reason => { await post(`/licenses/${l.license_id}/extend`, { days: Number(days.value), reason }); } }).then(d => { if (d) toast('Licence extended'); refresh(d); });
    } }, 'Give extra days'));
    if (ctx.can('LICENSE_SUSPEND')) {
      if (l.status_code === 'ACTIVE') buttons.push(el('button', { class: 'secondary', onclick: () => askReason({ title: 'Suspend licence', intro: 'The app stops working for these customers at its next check. Their seats are kept. You can reinstate it later.', submitLabel: 'Suspend', placeholder: 'For example: invoice 4411 unpaid',
        run: async reason => { await post(`/licenses/${l.license_id}/suspend`, { reason }); } }).then(d => { if (d) toast('Licence suspended'); refresh(d); }) }, 'Suspend'));
      if (l.status_code === 'SUSPENDED') buttons.push(el('button', { class: 'primary', onclick: () => askReason({ title: 'Reinstate licence', intro: 'The customers can use the app again at its next check.', submitLabel: 'Reinstate', placeholder: 'For example: invoice paid',
        run: async reason => { await post(`/licenses/${l.license_id}/reinstate`, { reason }); } }).then(d => { if (d) toast('Licence reinstated'); refresh(d); }) }, 'Reinstate'));
      if (!ended && l.status_code !== 'EXPIRED') {
        buttons.push(el('button', { class: 'danger', onclick: () => askTypedConfirm({ title: 'Cancel licence', intro: 'Ends the licence for good, for example because the customer left. This cannot be undone. Seats stay as they are.', hint: `The key ends …${l.key_hint}`, submitLabel: 'Cancel licence',
          run: async (confirm, reason) => { await post(`/licenses/${l.license_id}/cancel`, { confirm, reason }); } }).then(d => { if (d) toast('Licence cancelled'); refresh(d); }) }, 'Cancel…'));
        buttons.push(el('button', { class: 'danger', onclick: () => askTypedConfirm({ title: 'Revoke licence', intro: 'Ends the licence for good because of misuse (for example a key that was shared). It also frees every seat at once. This cannot be undone.', hint: `The key ends …${l.key_hint}`, submitLabel: 'Revoke licence',
          run: async (confirm, reason) => { await post(`/licenses/${l.license_id}/revoke`, { confirm, reason }); } }).then(d => { if (d) toast('Licence revoked'); refresh(d); }) }, 'Revoke…'));
      }
    }
    if (ended && ctx.can('BLOCK_MANAGE')) {
      buttons.push(el('button', { class: 'danger', onclick: () => askTypedConfirm({ title: 'Block this licence\'s machines', intro: 'The machines that used this licence will be refused by OASIS entirely, including starting a trial, until you lift the block. If one of those machines also uses a different licence, that stops working on it too.', hint: `The key ends …${l.key_hint}`, submitLabel: 'Block machines',
        run: async (confirm, reason) => { const r = await post(`/licenses/${l.license_id}/block-machines`, { confirm, reason }); toast(`${plural(r.newlyBlocked, 'machine')} blocked`); } }).then(refresh) }, 'Block its machines…'));
      if (l.machines_blocked) buttons.push(el('button', { class: 'secondary', onclick: () => askReason({ title: 'Unblock machines', intro: 'Lifts every block made for this licence.', submitLabel: 'Unblock', placeholder: 'Why are you lifting the block?',
        run: async reason => { const r = await post(`/licenses/${l.license_id}/unblock-machines`, { reason }); toast(`${plural(r.lifted, 'block')} lifted`); } }).then(refresh) }, 'Unblock machines'));
    }

    mount(box, 
      el('p', { class: 'crumbs' }, el('a', { href: '#/licences' }, '← Licences')),
      pageHeader(l.customer ? l.customer.name : 'Licence', `${l.plan_label} · key ends …${l.key_hint}`, badge('licence', l.status_code)),
      buttons.length ? el('div', { class: 'action-row' }, buttons) : null,
      el('div', { class: 'cols' },
        el('div', { class: 'col-main' },
          el('section', { class: 'card' }, el('h2', {}, 'Licence'),
            el('dl', { class: 'facts' },
              el('dt', {}, 'Customer'), el('dd', {}, l.customer ? el('a', { href: `#/customers/${l.customer.id}` }, l.customer.name) : '—'),
              el('dt', {}, 'Plan'), el('dd', {}, l.plan_label),
              el('dt', {}, 'Seats'), el('dd', {}, `${l.seats_in_use} in use of ${l.seat_limit === null ? 'unlimited' : l.seat_limit}`),
              el('dt', {}, 'Runs'), el('dd', {}, `${fmtDate(l.starts_at)} to ${fmtDate(l.expires_at)} (${fmtRelativeDay(l.expires_at)})`),
              el('dt', {}, 'Grace period'), el('dd', {}, `${plural(l.grace_days, 'day')} of working offline`),
              el('dt', {}, 'Created'), el('dd', {}, `${fmtDate(l.created_at)}${l.created_by_name ? ` by ${l.created_by_name}` : ''}`),
              l.machines_blocked ? el('dt', {}, 'Blocked machines') : null, l.machines_blocked ? el('dd', {}, String(l.machines_blocked)) : null)),
          el('section', { class: 'card' }, el('h2', {}, 'Seats in use'),
            l.seats && l.seats.length ? table([
              { title: 'Platform', render: s => s.platform || '—' }, { title: 'App version', render: s => s.app_version || '—' }, { title: 'Took the seat', render: s => fmtDate(s.activated_at) }, { title: 'Last seen', render: s => fmtRelativeDay(s.last_seen_at) || fmtDate(s.last_seen_at) },
              { title: '', class: 'actions', render: s => (ctx.can('LICENSE_MODIFY') ? el('button', { class: 'secondary', onclick: () => askReason({ title: 'Release this seat', intro: 'Frees the seat so another machine can use it. The machine can take a seat again if there is room.', submitLabel: 'Release seat', placeholder: 'For example: laptop lost, person left',
                run: async reason => { await post(`/licenses/${l.license_id}/seats/${s.activation_id}/release`, { reason }); } }).then(d => { if (d) toast('Seat released'); refresh(d); }) }, 'Release') : '') },
            ], l.seats, { caption: 'Seats in use' }) : el('p', { class: 'muted' }, 'No seat is in use. A seat is taken when someone activates OASIS with this licence.'),
            el('p', { class: 'small muted' }, 'Machines are shown by platform and version only: the portal never shows a machine id.')),
          el('section', { class: 'card' }, el('h2', {}, 'Terms'),
            table([{ title: 'Term', render: t => String(t.term_no) }, { title: 'Starts', render: t => fmtDate(t.starts_at) }, { title: 'Ends', render: t => fmtDate(t.ends_at) },
              { title: 'Kind', render: t => ({ purchase: 'Purchase', renewal: 'Renewal', manual: 'Extra days' })[t.source_code] || t.source_code }, { title: 'Reference', render: t => t.reference || '—' }], l.terms, { caption: 'Terms' })),
          el('section', { class: 'card' }, el('h2', {}, 'Includes'),
            l.features.length ? el('ul', { class: 'plain' }, l.features.map(f => el('li', {}, f.name))) : el('p', { class: 'muted' }, l.plan_code === 'enterprise' ? 'Everything.' : 'Core OASIS only.'))),
        el('aside', { class: 'col-side' },
          el('section', { class: 'card' }, el('h2', {}, 'History'),
            el('ol', { class: 'timeline' }, l.history.map(h => el('li', {}, el('strong', {}, ({ DRAFT: 'Drafted', PENDING_ACTIVATION: 'Issued', ACTIVE: 'Active', SUSPENDED: 'Suspended', EXPIRED: 'Ended', CANCELLED: 'Cancelled' })[h.to_status_code] || h.to_status_code),
              el('div', { class: 'small muted' }, `${fmtDateTime(h.changed_at)}${h.changed_by_name ? ` · ${h.changed_by_name}` : ''}`), h.reason ? el('div', { class: 'small' }, h.reason) : null)))))));
  }
  await load();
}
