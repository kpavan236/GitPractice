import { el, clear, field, textInput, mount } from '../dom.js';
import { post } from '../api.js';
import { icon } from '../icons.js';

/**
 * The page behind an emailed link: "Activate your account" (a new team member) or "Reset your password". The secret in the link is sent in the body of a request, never put
 * in an address, and the page removes it from the address bar as soon as it has read it. The person types the new password twice; nothing happens until both match and the
 * password is strong enough. Nobody is signed in by this: afterwards they sign in with their new password.
 */
export function renderSetPassword(root, { token, onDone }) {
  const card = el('div', { class: 'center-card' });
  mount(root, el('div', { class: 'login' },
    el('aside', { class: 'login-brand' },
      el('span', { class: 'brand' }, el('span', { class: 'brand-mark' }, icon('logo', 22)), el('span', { class: 'brand-text' }, el('strong', {}, 'OASIS'), el('small', {}, 'Support Portal'))),
      el('div', { class: 'login-pitch' }, el('h2', {}, 'Helping every customer get started.'), el('p', {}, 'Work licence requests, answer help requests and look after licences, all in one place.'))),
    el('main', { class: 'login-main' }, card)));

  const invalid = () => {
    clear(card);
    mount(card, el('h1', {}, 'This link cannot be used'),
      el('p', { class: 'subtitle' }, 'It may have expired, or already been used. Links work once, for a limited time.'),
      el('button', { class: 'primary wide', onclick: () => onDone('forgot') }, 'Get a new link'),
      el('p', { class: 'small' }, el('button', { type: 'button', class: 'link', onclick: () => onDone() }, 'Back to sign in')));
  };

  clear(card); mount(card, el('p', { class: 'loading', role: 'status' }, 'Checking your link…'));
  post('/auth/link/check', { token }).then(info => {
    const activating = info.purpose === 'activate';
    const first = textInput({ type: 'password', autocomplete: 'new-password', required: true, maxlength: 128 });
    const again = textInput({ type: 'password', autocomplete: 'new-password', required: true, maxlength: 128 });
    const errorLine = el('p', { class: 'form-error', role: 'alert' });
    const button = el('button', { type: 'submit', class: 'primary wide' }, activating ? 'Activate my account' : 'Set my new password');
    clear(card);
    mount(card,
      el('h1', {}, activating ? 'Activate your account' : 'Reset your password'),
      el('p', { class: 'subtitle' }, activating ? `Welcome${info.displayName ? `, ${info.displayName.split(' ')[0]}` : ''}. Choose a password for ${info.email}.` : `Choose a new password for ${info.email}.`),
      el('form', { novalidate: true, onsubmit: async e => {
        e.preventDefault();
        errorLine.textContent = '';
        if (first.value !== again.value) { errorLine.textContent = 'The two passwords are not the same.'; again.focus(); return; }
        button.disabled = true; const label = button.textContent; button.textContent = 'Saving…';
        try {
          await post('/auth/link/complete', { token, newPassword: first.value, confirmPassword: again.value });
          first.value = again.value = '';
          clear(card);
          mount(card, el('h1', {}, activating ? 'Your account is active' : 'Your password is changed'), el('p', { class: 'subtitle' }, 'Sign in with your email address and your new password.'),
            el('button', { class: 'primary wide', onclick: () => onDone() }, 'Go to sign in'));
        } catch (err) {
          if (err.reason === 'bad_link') return invalid();
          errorLine.textContent = err.message; button.disabled = false; button.textContent = label;
        }
      } },
        field('New password', first, 'At least 12 characters. A few ordinary words together make a strong one. Not your email address.').node,
        field('Verify password', again, 'Type it again, exactly the same.').node, errorLine, button));
    first.focus();
  }).catch(() => invalid());
}
