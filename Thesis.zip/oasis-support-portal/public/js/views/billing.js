import { el, pageHeader, loading, errorBox, clear, mount, fmtDate, theirs, emptyState } from '../dom.js';
import { get } from '../api.js';
import { fmtMoney } from '../money.js';
import { nameOf, filterLink, getBillingStatus } from '../billing-common.js';

const TILES = [['DRAFT', 'Draft', 'muted'], ['ISSUED', 'Issued', ''], ['SENT', 'Sent', ''], ['OVERDUE', 'Overdue', 'warn'], ['PAID', 'Paid', ''], ['VOID', 'Void', 'muted']];
const BUCKETS = [['current', 'Not yet due'], ['1-30', '1 to 30 days overdue'], ['31-60', '31 to 60 days overdue'], ['61+', 'Over 60 days overdue']];
const panel = (title, hint, ...body) => el('section', { class: 'card panel' }, el('h2', {}, title, hint ? el('span', { class: 'h-hint' }, hint) : null), ...body);
const stat = (label, value, hint, href, tone = '') => el('a', { class: `stat ${tone}`, href }, el('span', { class: 'stat-label' }, label), el('span', { class: 'stat-value' }, value), el('span', { class: 'stat-hint muted' }, hint || ''));

/** Admin view of the money: where every invoice stands, what is outstanding and overdue, who closed deals, who owes what, and whether anyone is chasing. Every figure opens the invoices behind it. */
export async function renderBilling(page) {
  const status = await getBillingStatus().catch(err => { mount(page, errorBox(err)); return null; });
  if (!status) return;
  if (!status.enabled) { mount(page, pageHeader('Billing'), emptyState('Billing is not set up', 'The billing service is not connected to this portal.')); return; }
  const csv = el('a', { class: 'button-link', href: '/v1/admin/billing/export.csv', download: '' }, 'Download all invoices (CSV)');
  const box = el('div');
  mount(page, pageHeader('Billing', 'Invoices by status, money in and owed, and who is chasing it. Click any figure to see the invoices.', csv), box);
  async function load() {
    clear(box); mount(box, loading());
    try {
      const d = await get('/billing/dashboard');
      const m = v => fmtMoney(v, d.currency);
      clear(box);
      mount(box,
        el('div', { class: 'stats' }, TILES.map(([code, label, tone]) => stat(label, String(d.tiles[code].count), m(d.tiles[code].amountMinor), filterLink({ status: code }), d.tiles[code].count && tone ? tone : ''))),
        el('div', { class: 'stats' },
          stat('Outstanding', m(d.money.outstandingMinor), 'Open invoices, balance still owed', filterLink({ open: '1' })),
          stat('Overdue', m(d.money.overdueMinor), 'Past due and unpaid', filterLink({ overdue: '1' }), d.money.overdueMinor ? 'warn' : ''),
          el('div', { class: 'stat' }, el('span', { class: 'stat-label' }, 'Collected this month'), el('span', { class: 'stat-value' }, m(d.money.collectedThisMonthMinor)), el('span', { class: 'stat-hint muted' }, 'Payments received, net of any voided'))),
        panel('Aging', 'Balance still owed, by how late it is', el('div', { class: 'stats' }, BUCKETS.map(([b, label]) => stat(label, String(d.aging[b].count), m(d.aging[b].amountMinor), filterLink({ bucket: b }), b !== 'current' && d.aging[b].count ? 'warn' : '')))),
        panel('By owner', 'Who is working and closing deals. "Closed" counts invoices that were ever paid in full.',
          d.byOwner.length ? el('div', { class: 'table-wrap' }, el('table', {}, el('caption', { class: 'visually-hidden' }, 'Invoices by owner'),
            el('thead', {}, el('tr', {}, ['Owner', 'Invoices', 'Value', 'Paid', 'Deals closed', 'Value closed', 'Average days to pay'].map((t, n) => el('th', { scope: 'col', class: n ? 'num' : '' }, t)))),
            el('tbody', {}, d.byOwner.map(o => el('tr', {}, el('td', {}, nameOf(d.names, o.ownerUserId)),
              el('td', { class: 'num' }, el('a', { href: filterLink({ ownerId: o.ownerUserId }) }, String(o.invoices))), el('td', { class: 'num' }, m(o.valueMinor)), el('td', { class: 'num' }, m(o.paidValueMinor)),
              el('td', { class: 'num' }, o.closedCount ? el('a', { href: filterLink({ ownerId: o.ownerUserId, closed: '1' }) }, String(o.closedCount)) : '0'), el('td', { class: 'num' }, m(o.closedValueMinor)),
              el('td', { class: 'num' }, o.avgDaysToPay === null ? '—' : String(o.avgDaysToPay))))))) : emptyState('No invoices issued yet')),
        panel('By customer', 'What each customer owes', d.byCustomer.length ? el('div', { class: 'table-wrap' }, el('table', {}, el('caption', { class: 'visually-hidden' }, 'Invoices by customer'),
          el('thead', {}, el('tr', {}, ['Customer', 'Outstanding', 'Last payment', 'Last follow-up'].map((t, n) => el('th', { scope: 'col', class: n === 1 ? 'num' : '' }, t)))),
          el('tbody', {}, d.byCustomer.map(c => el('tr', {}, el('td', {}, el('a', { href: filterLink({ customerId: c.customerId }) }, theirs(c.billToName || 'Customer'))),
            el('td', { class: 'num' }, m(c.outstandingMinor)), el('td', {}, c.lastPaymentOn ? fmtDate(c.lastPaymentOn) : '—'), el('td', {}, c.lastFollowUpAt ? fmtDate(c.lastFollowUpAt) : '—')))))) : emptyState('No customers invoiced yet')),
        panel('Follow-up health', 'Is anyone chasing what is overdue?', el('div', { class: 'stats' },
          stat('Overdue, never followed up', String(d.followUpHealth.missing), 'Nobody has logged a follow-up', filterLink({ health: 'missing' }), d.followUpHealth.missing ? 'warn' : ''),
          stat('Follow-up date has passed', String(d.followUpHealth.lapsed), 'The planned next follow-up was missed', filterLink({ health: 'lapsed' }), d.followUpHealth.lapsed ? 'warn' : ''))));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
