import { el, clear, pageHeader, fmtDateTime, table, emptyState, loading, errorBox, field, select, mount, latest } from '../dom.js';
import { get, post, qs } from '../api.js';
import { askReason, toast } from '../dialogs.js';

const REASONS = { abuse: 'Abuse', licence_revoked: 'Licence revoked', payment: 'Payment', security: 'Security', support_request: 'Support request' };

export async function renderBlocks(page, _params, ctx) {
  let state = 'active';
  mount(page, pageHeader('Blocked machines', 'A blocked machine is refused by OASIS entirely, including starting a trial. Blocks are made from a cancelled or revoked licence\'s page. Machines are never shown, only why and when.'));
  const st = select([['active', 'Blocked now'], ['lifted', 'Lifted'], ['all', 'All']], state);
  const box = el('div');
  mount(page, el('div', { class: 'toolbar' }, field('Show', st).node), box);
  st.addEventListener('change', () => { state = st.value; load(); });
  const fresh = latest();
  async function load() {
    const ok = fresh();
    clear(box); mount(box, loading());
    try {
      const r = await get(`/blocks${qs({ state, limit: 100 })}`);
      if (!ok()) return;
      clear(box);
      if (!r.blocks.length) { mount(box, emptyState('Nothing blocked', 'No machines match.')); return; }
      mount(box, table([
        { title: 'Blocked', render: b => fmtDateTime(b.blocked_at) },
        { title: 'Why', render: b => REASONS[b.reason_code] || b.reason_code },
        { title: 'Licence', render: b => b.license_id ? el('a', { href: `#/licences/${b.license_id}` }, 'View licence') : '—' },
        { title: 'Note', render: b => el('span', { class: 'small' }, b.note || '—') },
        { title: 'Status', render: b => b.lifted_at ? `Lifted ${fmtDateTime(b.lifted_at)}` : 'Blocked' },
        { title: '', class: 'actions', render: b => !b.lifted_at ? el('button', { class: 'secondary', onclick: () => askReason({ title: 'Lift this block', intro: 'The machine can use OASIS again.', submitLabel: 'Lift block', placeholder: 'Why are you lifting it?',
          run: async reason => { await post(`/blocks/${b.block_id}/lift`, { reason }); } }).then(d => { if (d) { toast('Block lifted'); load(); } }) }, 'Lift') : '' },
      ], r.blocks, { caption: 'Blocks' }));
    } catch (err) { clear(box); mount(box, errorBox(err, load)); }
  }
  await load();
}
