// The portal's one way to talk to its server. The session is an HttpOnly cookie that this page's JavaScript cannot read; the browser sends it by itself. For every change the
// page must also send the CSRF token it was given at sign-in, which proves the request came from this page and not from another site the browser happens to have open.

let csrfToken = null;
let onSignedOut = () => {};

export const setCsrfToken = t => { csrfToken = t; };
export const setSignedOutHandler = fn => { onSignedOut = fn; };

export class ApiError extends Error {
  constructor(status, body) {
    super((body && body.message) || 'Something went wrong. Please try again.');
    this.status = status;
    this.reason = body && body.reason;
    this.requestId = body && body.requestId;
    this.errors = body && body.errors;
    this.extra = body || {};
  }
}

export async function api(method, path, body, extraHeaders = {}) {
  const headers = { Accept: 'application/json', ...extraHeaders };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET' && csrfToken) headers['X-CSRF-Token'] = csrfToken;
  let res;
  try {
    res = await fetch(`/v1/admin${path}`, { method, headers, credentials: 'same-origin', body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (_) {
    throw new ApiError(0, { message: 'Could not reach the portal. Check your connection and try again.' });
  }
  let data = {};
  try { data = await res.json(); } catch (_) { /* an empty or non-JSON answer */ }
  if (res.status === 401 && !path.startsWith('/auth/')) { onSignedOut(); throw new ApiError(401, { message: 'Your session has ended. Please sign in again.', reason: 'sign_in_required' }); }
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}
export const get = path => api('GET', path);
export const post = (path, body, headers) => api('POST', path, body ?? {}, headers);
export const patch = (path, body) => api('PATCH', path, body);

/** A query string from an object, leaving out anything empty. */
export function qs(params) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : '';
}
