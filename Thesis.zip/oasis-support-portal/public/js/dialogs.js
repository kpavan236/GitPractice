import { el, clear, field, textInput, mount } from './dom.js';

// Dialogs use the browser's own <dialog> element: it traps focus, closes on Escape, and is announced by screen readers.

let toastRegion;
/** The live region exists from the start (a screen reader only announces changes to a region it already knows). */
export function prepareToasts() { if (!toastRegion) { toastRegion = el('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(toastRegion); } }
export function toast(message, tone = 'good') {
  prepareToasts();
  const t = el('div', { class: `toast ${tone}` }, message);
  mount(toastRegion, t);
  setTimeout(() => t.remove(), tone === 'bad' ? 8000 : 4000);
}

/**
 * Opens a dialog and resolves with whatever `onSubmit` returns (or null if it is cancelled). `build(api)` returns the form body; `onSubmit` may throw: the message is shown in
 * the dialog and the person can correct and try again. While it runs the button is disabled so a double click cannot send twice.
 */
export function openDialog({ title, intro, build, submitLabel = 'Save', danger = false, wide = false, persistent = false, onSubmit }) {
  return new Promise(resolve => {
    const dialog = el('dialog', { class: wide ? 'wide' : '', 'aria-labelledby': 'dlg-title' });
    const errorLine = el('p', { class: 'form-error', role: 'alert' });
    const submit = el('button', { type: 'submit', class: danger ? 'danger' : 'primary' }, submitLabel);
    const cancel = el('button', { type: 'button', class: 'secondary', onclick: () => dialog.close('cancel') }, 'Cancel');
    const body = el('div', { class: 'dialog-body' });
    const form = el('form', { method: 'dialog', novalidate: true }, el('h2', { id: 'dlg-title' }, title), intro ? el('p', { class: 'intro' }, intro) : null, body, errorLine, el('div', { class: 'dialog-actions' }, persistent ? null : cancel, submit));
    let result = null;
    const ctl = { body, setError: m => { errorLine.textContent = m || ''; }, close: value => { result = value; dialog.close('done'); } };
    body.append(build(ctl));
    form.addEventListener('submit', async e => {
      e.preventDefault();
      ctl.setError('');
      submit.disabled = true;
      const original = submit.textContent;
      submit.textContent = 'Working…';
      try { const value = await onSubmit(ctl); result = value === undefined ? true : value; dialog.close('done'); }
      catch (err) { ctl.setError(err.message || 'That did not work. Please try again.'); submit.disabled = false; submit.textContent = original; }
    });
    // A persistent dialog (one that shows something only once, like a licence key) cannot be dismissed by Escape, by clicking away, or by pressing Enter in one of its fields:
    // only by its one button. (Some browsers close a dialog on a second Escape even when the first was cancelled, so a stray close re-opens it.)
    if (persistent) {
      dialog.addEventListener('cancel', e => e.preventDefault());
      dialog.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'TEXTAREA') e.preventDefault(); });
    }
    dialog.append(form);
    dialog.addEventListener('close', () => {
      if (persistent && dialog.returnValue !== 'done' && !dialog.dataset.forceClose) { dialog.showModal(); return; }
      dialog.remove(); resolve(dialog.returnValue === 'done' ? result : null);
    });
    document.body.append(dialog);
    dialog.showModal();
    const first = dialog.querySelector('input, select, textarea');
    if (first) first.focus();
  });
}

/** Asks for a reason (required, 500 characters) and then runs `run(reason)`. Every change in the portal needs one, and it goes on the record with the person's name. */
export function askReason({ title, intro, submitLabel = 'Confirm', danger = false, placeholder = 'For example: spoke to the customer, they agreed to 25 seats', extra, run }) {
  let reasonInput, extras;
  return openDialog({
    title, intro, submitLabel, danger,
    build: () => {
      reasonInput = el('textarea', { rows: 3, maxlength: 500, placeholder, required: true });
      extras = extra ? extra() : null;
      return el('div', {}, extras ? extras.node : null, field('Reason (kept on the record with your name)', reasonInput, 'Say what happened or why. It is shown to your team in the history.').node);
    },
    onSubmit: async () => {
      const reason = reasonInput.value.trim();
      if (!reason) throw new Error('Please give a reason.');
      return run(reason, extras);
    },
  });
}

/** For something that cannot be undone: the person must type the last four characters of the licence key to go ahead. */
export function askTypedConfirm({ title, intro, hint, submitLabel, run }) {
  let confirmInput, reasonInput;
  return openDialog({
    title, intro, submitLabel, danger: true,
    build: () => {
      confirmInput = textInput({ maxlength: 4, autocomplete: 'off', spellcheck: 'false', class: 'mono short', required: true });
      reasonInput = el('textarea', { rows: 3, maxlength: 500, required: true });
      return el('div', {}, field('Type the last four characters of the licence key to confirm', confirmInput, hint).node, field('Reason (kept on the record with your name)', reasonInput).node);
    },
    onSubmit: async () => {
      const reason = reasonInput.value.trim();
      if (!reason) throw new Error('Please give a reason.');
      if (!confirmInput.value.trim()) throw new Error('Type the last four characters of the key to confirm.');
      return run(confirmInput.value.trim(), reason);
    },
  });
}

/** Shows something once (a licence key) with a copy button. */
export function showOnce({ title, intro, secret, secretLabel, after }) {
  return openDialog({
    title, intro, submitLabel: 'I have copied it', wide: true, persistent: true,
    build: () => {
      const copy = el('button', { type: 'button', class: 'secondary', onclick: async () => {
        try { await navigator.clipboard.writeText(secret); toast('Copied to the clipboard'); } catch (_) { toast('Could not copy: select the key and copy it yourself', 'bad'); }
      } }, 'Copy');
      return el('div', {}, el('p', { class: 'small' }, secretLabel), el('div', { class: 'secret-row' }, el('code', { class: 'secret' }, secret), copy), after ? after() : null);
    },
    onSubmit: async () => true,
  });
}

/** Closes every open dialog, even a persistent one: used when the session ends and nothing on screen belongs to the person any more. */
export function closeAllDialogs() {
  for (const d of document.querySelectorAll('dialog[open]')) { d.dataset.forceClose = '1'; d.close('cancel'); }
}

/** Wraps a button's action so a second click while the first is still working does nothing, and a failure is shown instead of being an unhandled error. */
export function guarded(fn) {
  let busy = false;
  return async (...args) => {
    if (busy) return undefined;
    busy = true;
    try { return await fn(...args); }
    catch (err) { toast(err && err.message ? err.message : 'That did not work. Please try again.', 'bad'); return undefined; }
    finally { busy = false; }
  };
}
