import { el, field, fmtDateTime, mount } from './dom.js';
import { openDialog, toast } from './dialogs.js';
import { post } from './api.js';

const DELIVERY = { sent: 'Sent', failed: 'Not sent: the email failed', not_connected: 'Recorded, not delivered: email is not connected yet' };

/** "Reply to the customer": a subject and a message. It goes to the address on the request (never one typed here) and is recorded with the request. Resolves true when sent. */
export async function replyDialog({ path, to, defaultSubject }) {
  let subject, body;
  const done = await openDialog({ title: 'Reply to the customer', intro: `This is emailed to ${to} and recorded with the request. Write as yourself: plain text.`, submitLabel: 'Send reply', wide: true,
    build: () => {
      subject = el('input', { type: 'text', maxlength: 200, value: defaultSubject });
      body = el('textarea', { rows: 8, maxlength: 4000, required: true });
      return el('div', {}, field('Subject', subject).node, field('Message', body, 'Up to 4000 characters.').node);
    },
    onSubmit: async () => {
      if (!body.value.trim()) throw new Error('Write a message first.');
      return post(`${path}/reply`, { subject: subject.value.trim() || undefined, body: body.value });
    } });
  if (!done) return false;
  toast(done.delivery === 'sent' ? 'Reply sent' : done.delivery === 'failed' ? 'The email could not be sent. The reply is recorded; try again or write from your own email.' : 'Reply recorded. Email is not connected yet, so it was not delivered.', done.delivery === 'sent' ? 'good' : 'bad');
  return true;
}

/** The replies already sent for a request, oldest first, each with who wrote it and what happened to it. */
export function repliesSection(replies) {
  return el('section', { class: 'card' }, el('h2', {}, 'Replies sent'),
    replies && replies.length ? el('ul', { class: 'notes' }, replies.map(r => el('li', {},
      el('div', { class: 'small' }, el('strong', {}, r.subject)), el('div', { class: 'note-body' }, r.body),
      el('div', { class: 'small muted' }, `${r.by || 'Someone who has left'} · ${fmtDateTime(r.createdAt)} · ${DELIVERY[r.delivery] || r.delivery}`))))
      : el('p', { class: 'muted' }, 'No reply has been sent from the portal yet.'));
}
export { mount };
