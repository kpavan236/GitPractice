// Charts drawn as SVG, built node by node (never from markup), with no library. Colours come from the stylesheet (classes c1 to c6), so they follow light and dark.
import { el } from './dom.js';
import { NS } from './icons.js';

const svg = (tag, attrs = {}, ...kids) => {
  const n = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== undefined && v !== null) n.setAttribute(k, String(v));
  for (const k of kids) if (k) n.append(k);
  return n;
};
const text = (x, y, content, cls, anchor) => { const t = svg('text', { x, y, class: cls, 'text-anchor': anchor }); t.textContent = String(content); return t; };
const tip = (node, words) => { const t = svg('title'); t.textContent = words; node.append(t); return node; };

/** A round number at or above the largest value, so the axis has tidy steps. */
function niceMax(max) {
  if (max <= 5) return 5;
  const pow = 10 ** Math.floor(Math.log10(max)), f = max / pow;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * pow;
}
const shortDate = iso => { const [, m, d] = iso.split('-'); return `${Number(d)} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][Number(m) - 1]}`; };

/** Several weekly series on one set of axes: series = [{ name, points: [{ week, n }] }]. */
export function lineChart(series, { label }) {
  const W = 720, H = 260, L = 38, R = 14, T = 14, B = 30;
  const weeks = series[0].points.map(p => p.week);
  const top = niceMax(Math.max(1, ...series.flatMap(s => s.points.map(p => p.n))));
  const x = i => L + (weeks.length === 1 ? 0 : (i * (W - L - R)) / (weeks.length - 1));
  const y = v => T + (1 - v / top) * (H - T - B);
  const chart = svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart', role: 'img', 'aria-label': label, preserveAspectRatio: 'xMidYMid meet' });
  for (let i = 0; i <= 4; i++) {
    const v = (top * i) / 4;
    chart.append(svg('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), class: 'grid' }), text(L - 8, y(v) + 4, Math.round(v), 'tick', 'end'));
  }
  const every = Math.ceil(weeks.length / 8);
  weeks.forEach((w, i) => { if (i % every === 0 || i === weeks.length - 1) chart.append(text(x(i), H - 8, shortDate(w), 'tick', 'middle')); });
  series.forEach((s, k) => {
    const pts = s.points.map((p, i) => `${x(i).toFixed(1)},${y(p.n).toFixed(1)}`);
    if (k === 0) chart.append(svg('polygon', { points: `${x(0).toFixed(1)},${y(0)} ${pts.join(' ')} ${x(weeks.length - 1).toFixed(1)},${y(0)}`, class: `area c${k + 1}` }));
    chart.append(svg('polyline', { points: pts.join(' '), class: `line c${k + 1}` }));
    s.points.forEach((p, i) => chart.append(tip(svg('circle', { cx: x(i), cy: y(p.n), r: 3.5, class: `dot c${k + 1}` }), `${s.name}, week of ${shortDate(p.week)}: ${p.n}`)));
  });
  return chart;
}

/** Horizontal bars, one row per item: items = [{ label, value }]. */
export function barChart(items, { label, unit = '' }) {
  const rowH = 36, L = 140, R = 40, W = 440, H = Math.max(rowH, items.length * rowH) + 4;
  const top = Math.max(1, ...items.map(i => i.value));
  const chart = svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart bars', role: 'img', 'aria-label': label, preserveAspectRatio: 'xMinYMin meet' });
  items.forEach((it, i) => {
    const yy = i * rowH + 4, w = Math.max(it.value ? 3 : 0, ((W - L - R) * it.value) / top);
    chart.append(text(L - 10, yy + 18, it.label, 'bar-label', 'end'), svg('rect', { x: L, y: yy + 4, width: W - L - R, height: 18, rx: 9, class: 'track' }),
      tip(svg('rect', { x: L, y: yy + 4, width: w, height: 18, rx: 9, class: `bar c${(it.tone || i % 6) + 1}` }), `${it.label}: ${it.value}${unit}`), text(W - R + 10, yy + 18, `${it.value}${unit}`, 'bar-value', 'start'));
  });
  return chart;
}

/** A ring with the total in the middle, and a legend beside it: items = [{ label, value }]. */
export function donut(items, { label, centre }) {
  const total = items.reduce((a, i) => a + i.value, 0), R = 52, C = 2 * Math.PI * R;
  const chart = svg('svg', { viewBox: '0 0 140 140', class: 'chart donut', role: 'img', 'aria-label': label });
  chart.append(svg('circle', { cx: 70, cy: 70, r: R, class: 'track-ring' }));
  let offset = 0;
  items.forEach((it, i) => {
    if (!it.value) return;
    const len = (C * it.value) / total;
    chart.append(tip(svg('circle', { cx: 70, cy: 70, r: R, class: `ring c${i % 6 + 1}`, 'stroke-dasharray': `${len} ${C - len}`, 'stroke-dashoffset': -offset, transform: 'rotate(-90 70 70)' }), `${it.label}: ${it.value}`));
    offset += len;
  });
  chart.append(text(70, 72, total, 'donut-total', 'middle'), text(70, 90, centre || 'total', 'donut-sub', 'middle'));
  const legend = el('ul', { class: 'legend' }, items.map((it, i) => el('li', {}, el('span', { class: `swatch c${i % 6 + 1}` }), el('span', { class: 'legend-name' }, it.label), el('strong', {}, String(it.value)))));
  return el('div', { class: 'donut-wrap' }, chart, legend);
}

export const legend = series => el('ul', { class: 'legend inline' }, series.map((s, i) => el('li', {}, el('span', { class: `swatch c${i + 1}` }), s.name)));
