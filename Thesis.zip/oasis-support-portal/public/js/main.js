import { el, clear } from './dom.js';
import { get, post, setCsrfToken, setSignedOutHandler } from './api.js';
import { renderLogin } from './views/login.js';
import { renderSetPassword } from './views/set-password.js';
import { startShell } from './shell.js';
import { closeAllDialogs, toast } from './dialogs.js';

const root = document.getElementById('app');
let stopShell = null;

/** Tears down the signed-in portal completely: its address listener, anything half-loaded, and every open dialog (which may hold the last person's data). */
function endSession() {
  if (stopShell) { stopShell(); stopShell = null; }
  closeAllDialogs();
  setCsrfToken(null);
  document.title = 'OASIS Support Portal';
  clear(root);
}

function showLogin(message, start) {
  endSession();
  renderLogin(root, { message, start, onSignedIn: boot });
}

/** An emailed link (#/activate/<secret> or #/reset/<secret>). The secret is taken out of the address bar at once, and the page works whether or not anyone is signed in. */
function linkInAddress() {
  const m = /^#\/(?:activate|reset)\/([A-Za-z0-9_-]{20,100})$/.exec(location.hash);
  if (!m) return null;
  history.replaceState(null, '', location.pathname + location.search);
  return m[1];
}

setSignedOutHandler(() => showLogin('Your session has ended. Please sign in again.'));

async function signOut() {
  try { await post('/auth/logout', {}); }
  catch (err) {
    if (err.status !== 401) { toast('Could not sign you out. Check your connection and try again: your session is still open.', 'bad'); return; }       // 401: it had already ended
  }
  showLogin();
}

/** Works out whether there is a valid session (the cookie), and shows either the portal or the sign-in page. */
async function boot() {
  const token = linkInAddress();
  if (token) { endSession(); return renderSetPassword(root, { token, onDone: next => (next === 'forgot' ? showLogin(undefined, 'forgot') : showLogin()) }); }
  try {
    const me = await get('/auth/me');
    endSession();
    setCsrfToken(me.csrfToken);
    stopShell = startShell(root, me, { signOut });
  } catch (err) {
    if (err.status === 401 || err.reason === 'sign_in_required') return showLogin();
    endSession();
    root.append(el('div', { class: 'center-card' }, el('h1', {}, 'OASIS Support Portal'), el('p', { role: 'alert' }, err.message), el('button', { class: 'primary', onclick: boot }, 'Try again')));
  }
}

boot();
