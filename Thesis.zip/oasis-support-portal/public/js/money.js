// Money as people type and read it. Pure functions with no page in them, so they are tested on their own. Amounts are whole minor units (paise, cents): never a floating-point number.

const MAX_MINOR = 10_000_000_000;      // the billing service's limit for one unit price

/** "1,234.50" -> 123450. Null when it is not money, has more than two decimals, or is out of range. */
export function toMinor(text, { allowNegative = false } = {}) {
  if (typeof text !== 'string') return null;
  const m = /^(-?)(\d{1,12})(?:\.(\d{1,2}))?$/.exec(text.replace(/[\s,]/g, ''));
  if (!m || (m[1] && !allowNegative)) return null;
  const minor = Number(m[2]) * 100 + Number((m[3] || '').padEnd(2, '0'));
  if (minor > MAX_MINOR) return null;
  return m[1] ? -minor : minor;
}

/** 123450 -> "1234.50", for an input box. */
export function toInput(minor) {
  const n = Math.abs(minor);
  return `${minor < 0 ? '-' : ''}${Math.floor(n / 100)}.${String(n % 100).padStart(2, '0')}`;
}

/** For reading: "₹1,234.50" in the invoice's own currency (every currency used has two minor digits). */
export function fmtMoney(minor, currency) {
  try { return new Intl.NumberFormat('en-IN', { style: 'currency', currency, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(minor / 100); }
  catch (_) { return `${toInput(minor)} ${currency}`; }
}

/** A quantity: more than 0, at most 10000, up to three decimals. Returns the text trimmed, or null. */
export function toQuantity(text) {
  if (typeof text !== 'string') return null;
  const t = text.trim();
  const m = /^(\d{1,5})(?:\.(\d{1,3}))?$/.exec(t);
  if (!m) return null;
  const thousandths = Number(m[1]) * 1000 + Number((m[2] || '').padEnd(3, '0'));
  return thousandths > 0 && thousandths <= 10_000_000 ? t : null;
}

/** One line's amount in minor units: quantity x unit price, rounded half away from zero (exactly what the database does). For the preview only: the server recomputes. */
export function lineAmount(quantityText, unitMinor) {
  const q = toQuantity(quantityText);
  if (q === null || !Number.isSafeInteger(unitMinor)) return null;
  const [whole, frac = ''] = q.split('.');
  const product = BigInt(Number(whole) * 1000 + Number(frac.padEnd(3, '0'))) * BigInt(unitMinor);
  const negative = product < 0n;
  const half = ((negative ? -product : product) + 500n) / 1000n;
  return Number(negative ? -half : half);
}
