import { el, clear, mount } from './dom.js';
import { icon, initials } from './icons.js';
import { openDialog, toast } from './dialogs.js';
import { get, post } from './api.js';
import { field, textInput } from './dom.js';
import { prepareToasts } from './dialogs.js';
import { renderDashboard } from './views/dashboard.js';
import { renderLicenceRequests } from './views/licence-requests.js';
import { renderHelpRequests } from './views/help-requests.js';
import { renderFeedback } from './views/feedback.js';
import { renderLicences } from './views/licences.js';
import { renderCustomers } from './views/customers.js';
import { renderTrials } from './views/trials.js';
import { renderBlocks } from './views/blocks.js';
import { renderTeam } from './views/team.js';
import { renderAudit } from './views/audit.js';
import { renderReports } from './views/reports.js';
import { renderCustomerUsers } from './views/customer-users.js';
import { renderWorkload } from './views/workload.js';
import { renderInvoices } from './views/invoices.js';
import { renderFollowUps } from './views/follow-ups.js';
import { renderBilling } from './views/billing.js';

/** Which screens exist, who sees them (by permission, which the server decides), and what they are called in plain words. */
const SCREENS = [
  { path: 'dashboard', title: 'Dashboard', needs: 'CUSTOMER_READ', render: renderDashboard, group: 'Work' },
  { path: 'licence-requests', title: 'Licence requests', needs: 'CUSTOMER_READ', render: renderLicenceRequests, group: 'Work' },
  { path: 'help-requests', title: 'Help requests', needs: 'SUPPORT_REQUEST_READ', render: renderHelpRequests, group: 'Work' },
  { path: 'feedback', title: 'Feedback', needs: 'FEEDBACK_READ', render: renderFeedback, group: 'Work' },
  { path: 'workload', title: 'Workload', needs: 'CUSTOMER_READ', render: renderWorkload, group: 'Work' },
  { path: 'licences', title: 'Licences', needs: 'LICENSE_READ', render: renderLicences, group: 'Customers' },
  { path: 'customers', title: 'Customers', needs: 'CUSTOMER_READ', render: renderCustomers, group: 'Customers' },
  { path: 'trials', title: 'Trials', needs: 'LICENSE_READ', render: renderTrials, group: 'Customers' },
  { path: 'invoices', title: 'Invoices', needs: 'INVOICE_READ', render: renderInvoices, group: 'Billing' },
  { path: 'follow-ups', title: 'Follow-ups', needs: 'INVOICE_READ', render: renderFollowUps, group: 'Billing' },
  { path: 'billing', title: 'Billing', needs: 'INVOICE_ADMIN', render: renderBilling, group: 'Admin' },
  { path: 'reports', title: 'Reports', needs: 'REPORT_READ', render: renderReports, group: 'Admin' },
  { path: 'customer-users', title: 'Customer users', needs: 'REPORT_READ', render: renderCustomerUsers, group: 'Admin' },
  { path: 'blocks', title: 'Blocked machines', needs: 'BLOCK_MANAGE', render: renderBlocks, group: 'Admin' },
  { path: 'team', title: 'Team', needs: 'USER_MANAGE', render: renderTeam, group: 'Admin' },
  { path: 'audit', title: 'Audit log', needs: 'AUDIT_READ', render: renderAudit, group: 'Admin' },
];

export function startShell(root, me, { signOut }) {
  const perms = new Set(me.permissions);
  const can = p => perms.has(p);
  const isAdmin = me.roles.includes('PLATFORM_ADMIN');
  const visible = SCREENS.filter(s => can(s.needs));
  const ctx = { me, can, isAdmin, go: path => { location.hash = `#/${path}`; } };

  const content = el('main', { id: 'content', class: 'content', tabindex: '-1' });
  const nav = el('nav', { 'aria-label': 'Main', class: 'nav' });
  const menuButton = el('button', { class: 'menu-button secondary', 'aria-expanded': 'false', 'aria-controls': 'nav', onclick: () => { const open = nav.classList.toggle('open'); menuButton.setAttribute('aria-expanded', String(open)); } }, icon('menu'), el('span', {}, 'Menu'));
  nav.id = 'nav';

  let lastGroup = null;
  for (const s of visible) {
    if (s.group !== lastGroup) { mount(nav, el('p', { class: 'nav-group' }, s.group)); lastGroup = s.group; }
    mount(nav, el('a', { href: `#/${s.path}`, dataset: { path: s.path } }, icon(s.path), el('span', {}, s.title)));
  }

  async function changePassword() {
    let current, first, again;
    const done = await openDialog({ title: 'Change your password', intro: 'You stay signed in here. Anywhere else you are signed in will be signed out.', submitLabel: 'Change password',
      build: () => {
        current = textInput({ type: 'password', autocomplete: 'current-password', maxlength: 200 }); first = textInput({ type: 'password', autocomplete: 'new-password', maxlength: 128 }); again = textInput({ type: 'password', autocomplete: 'new-password', maxlength: 128 });
        return el('div', {}, field('Current password', current).node, field('New password', first, 'At least 12 characters. A few ordinary words together make a strong one.').node, field('New password again', again).node);
      },
      onSubmit: async () => {
        if (!current.value) throw new Error('Enter your current password.');
        if (first.value !== again.value) throw new Error('The two new passwords are not the same.');
        await post('/auth/password/change', { currentPassword: current.value, newPassword: first.value });
        current.value = first.value = again.value = '';
      } });
    if (done) toast('Your password was changed');
  }
  // ── The bell: requests assigned to you, and how many arrived since you last looked ──
  const bellCount = el('span', { class: 'bell-count', hidden: true });
  const panel = el('div', { class: 'bell-panel', role: 'region', 'aria-label': 'Notifications', hidden: true });
  const bell = el('button', { class: 'secondary bell', type: 'button', 'aria-expanded': 'false', 'aria-label': 'Notifications', onclick: () => toggleBell() }, icon('bell', 18), bellCount);
  let latestNotes = null;
  const setBell = n => {
    latestNotes = n;
    bellCount.hidden = !n.count; bellCount.textContent = n.count > 99 ? '99+' : String(n.count);
    bell.setAttribute('aria-label', n.count ? `Notifications, ${n.count} new` : 'Notifications');
    if (!panel.hidden) drawPanel();
  };
  const refreshBell = () => Promise.all([get('/notifications'), can('INVOICE_READ') ? get('/invoice-follow-ups/summary?mine=1').catch(() => null) : null])
    .then(([n, f]) => { const followUps = f ? f.followUpsDue : 0; setBell({ ...n, followUps, count: n.count + followUps }); }).catch(() => {});
  function drawPanel() {
    clear(panel);
    const n = latestNotes;
    const link = (href, text) => el('a', { href, onclick: () => closeBell() }, text);
    mount(panel, el('div', { class: 'bell-head' }, el('strong', {}, 'Notifications'),
      n && n.count - (n.followUps || 0) > 0 ? el('button', { type: 'button', class: 'link', onclick: async () => { await post('/notifications/read', {}).catch(() => {}); refreshBell(); } }, 'Mark all as read') : null));
    if (!n) { mount(panel, el('p', { class: 'muted small' }, 'Loading…')); return; }
    const rows = [];
    if (n.newRequests.licenceRequests) rows.push(el('li', { class: 'unread' }, link('#/licence-requests', `${n.newRequests.licenceRequests} new licence request${n.newRequests.licenceRequests === 1 ? '' : 's'} since you last looked`)));
    if (n.newRequests.helpRequests) rows.push(el('li', { class: 'unread' }, link('#/help-requests', `${n.newRequests.helpRequests} new help request${n.newRequests.helpRequests === 1 ? '' : 's'} since you last looked`)));
    if (n.followUps) rows.push(el('li', { class: 'unread' }, link('#/follow-ups', `${n.followUps} invoice follow-up${n.followUps === 1 ? '' : 's'} due`)));
    for (const i of n.items) rows.push(el('li', { class: i.read ? '' : 'unread' }, link(`#/${i.kind === 'licence_request' ? 'licence-requests' : 'help-requests'}/${encodeURIComponent(i.reference)}`, i.title), el('div', { class: 'small muted' }, fmtWhen(i.createdAt))));
    mount(panel, rows.length ? el('ul', { class: 'bell-list' }, rows) : el('p', { class: 'muted small' }, 'Nothing new. You will see requests assigned to you here.'));
  }
  const fmtWhen = v => { const m = Math.round((Date.now() - new Date(v).getTime()) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} d ago`; };
  function closeBell() { panel.hidden = true; bell.setAttribute('aria-expanded', 'false'); }
  function toggleBell() { const open = panel.hidden; panel.hidden = !open; bell.setAttribute('aria-expanded', String(open)); if (open) { drawPanel(); refreshBell(); } }
  const outside = e => { if (!panel.hidden && !e.target.closest('.bell-wrap')) closeBell(); };
  const escape = e => { if (e.key === 'Escape' && !panel.hidden) { closeBell(); bell.focus(); } };
  document.addEventListener('click', outside); document.addEventListener('keydown', escape);
  const poll = setInterval(refreshBell, 60_000);
  refreshBell();
  const name = me.displayName || me.email;
  const brand = () => el('span', { class: 'brand' }, el('span', { class: 'brand-mark' }, icon('logo', 20)), el('span', { class: 'brand-text' }, el('strong', {}, 'OASIS'), el('small', {}, 'Support Portal')));
  nav.prepend(brand());
  mount(root,
    el('a', { href: '#content', class: 'skip', onclick: e => { e.preventDefault(); content.focus(); } }, 'Skip to content'),       // moves focus; it must not change the address, which is the router's
    el('div', { class: 'layout' }, nav,
      el('div', { class: 'main-col' },
        el('header', { class: 'topbar' }, menuButton,
          el('span', { class: 'who' }, el('span', { class: 'avatar', 'aria-hidden': 'true' }, initials(name)),
            el('span', { class: 'who-text' }, el('span', { class: 'who-name' }, name), el('span', { class: `badge ${isAdmin ? 'info' : 'muted'}` }, isAdmin ? 'Admin' : 'User')),
            el('span', { class: 'bell-wrap' }, bell, panel),
            el('button', { class: 'secondary', 'aria-label': 'Change password', onclick: changePassword }, icon('key', 16), el('span', {}, 'Change password')),
            el('button', { class: 'secondary signout', 'aria-label': 'Sign out', onclick: signOut }, icon('signout', 16), el('span', {}, 'Sign out')))),
        content)));

  let renderToken = 0;
  async function route() {
    // Only addresses of the form #/screen are the router's. Anything else (a stray #fragment) is left alone rather than treated as "go to the dashboard".
    if (location.hash && !location.hash.startsWith('#/')) return;
    const [, path = 'dashboard', ...rest] = (location.hash || '#/dashboard').split('/');
    const screen = visible.find(s => s.path === path);
    nav.classList.remove('open'); menuButton.setAttribute('aria-expanded', 'false');
    for (const a of nav.querySelectorAll('a')) { if (a.dataset.path === path) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }
    clear(content);
    const mine = ++renderToken;
    // Each visit gets its own page node: a screen that is still loading when you move on writes into a node nobody can see, never into the new screen.
    const page = el('div', { class: 'page' });
    mount(content, page);
    if (!screen) {
      mount(page, el('div', { class: 'empty' }, el('h1', { tabindex: '-1', id: 'page-title' }, visible.some(s => s.path === path) ? 'Not found' : 'Page not found'),
        el('p', {}, 'That page does not exist, or you do not have access to it.'), el('a', { href: '#/dashboard' }, 'Go to the dashboard')));
    } else {
      document.title = `${screen.title} · OASIS Support Portal`;
      try { await screen.render(page, { id: rest.length ? decodeURIComponent(rest.join('/')) : null }, ctx); }
      catch (err) { mount(page, el('div', { class: 'error-box', role: 'alert' }, el('p', {}, err.message || 'Something went wrong.'), err.requestId ? el('p', { class: 'small' }, `Reference for support: ${err.requestId}`) : null)); }
    }
    if (mine === renderToken) { const h = page.querySelector('#page-title'); if (h) h.focus({ preventScroll: true }); window.scrollTo(0, 0); }
  }
  window.addEventListener('hashchange', route);
  prepareToasts();
  route();
  /** Stops this shell: signing out and in again must not leave the old one answering address changes against the new session. */
  return () => { window.removeEventListener('hashchange', route); renderToken++; clearInterval(poll); document.removeEventListener('click', outside); document.removeEventListener('keydown', escape); };
}
